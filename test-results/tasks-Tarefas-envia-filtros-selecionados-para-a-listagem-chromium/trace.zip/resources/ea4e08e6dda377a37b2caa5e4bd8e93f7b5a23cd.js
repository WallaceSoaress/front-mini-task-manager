import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/tasks/TaskBoard.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=df6b4f96";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=df6b4f96";
import { TASK_STATUSES } from "/src/interfaces/tasks/task.ts";
import { statusIcons, statusLabels } from "/src/components/tasks/labels.ts";
import { BoardGrid, BoardScroller, CardList, Column, ColumnHeader, CountBadge, EmptyColumn } from "/src/components/tasks/styles.ts";
import { TaskCard } from "/src/components/tasks/TaskCard.tsx";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskBoard.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=df6b4f96";
var _s = $RefreshSig$();
export function TaskBoard(t0) {
	_s();
	const $ = _c(22);
	if ($[0] !== "61ae233c10a393e223a7b6f3e3bbb8244bc6a58b9760d617ad294951716d1bcf") {
		for (let $i = 0; $i < 22; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "61ae233c10a393e223a7b6f3e3bbb8244bc6a58b9760d617ad294951716d1bcf";
	}
	const { tasks, onOpenTask, onMoveTask } = t0;
	const [draggedTask, setDraggedTask] = useState(null);
	const [dragOverStatus, setDragOverStatus] = useState(null);
	let T0;
	let T1;
	let t1;
	let t2;
	if ($[1] !== dragOverStatus || $[2] !== draggedTask || $[3] !== onMoveTask || $[4] !== onOpenTask || $[5] !== tasks) {
		let t3;
		if ($[10] !== tasks) {
			t3 = (acc, status) => ({
				...acc,
				[status]: tasks.filter((task) => task.status === status)
			});
			$[10] = tasks;
			$[11] = t3;
		} else {
			t3 = $[11];
		}
		const tasksByStatus = TASK_STATUSES.reduce(t3, {
			TODO: [],
			IN_PROGRESS: [],
			DONE: []
		});
		let t4;
		if ($[12] !== draggedTask || $[13] !== onMoveTask) {
			t4 = function handleDrop(status_0) {
				if (draggedTask && draggedTask.status !== status_0) {
					onMoveTask(draggedTask, status_0);
				}
				setDraggedTask(null);
				setDragOverStatus(null);
			};
			$[12] = draggedTask;
			$[13] = onMoveTask;
			$[14] = t4;
		} else {
			t4 = $[14];
		}
		const handleDrop = t4;
		T1 = BoardScroller;
		t2 = "Board de tarefas";
		T0 = BoardGrid;
		t1 = TASK_STATUSES.map((status_1) => /* @__PURE__ */ _jsxDEV(Column, {
			$isDropTarget: dragOverStatus === status_1,
			onDragLeave: () => setDragOverStatus((current) => current === status_1 ? null : current),
			onDragOver: (event) => {
				event.preventDefault();
				event.dataTransfer.dropEffect = "move";
				setDragOverStatus(status_1);
			},
			onDrop: (event_0) => {
				event_0.preventDefault();
				handleDrop(status_1);
			},
			children: [/* @__PURE__ */ _jsxDEV(ColumnHeader, { children: [/* @__PURE__ */ _jsxDEV("span", { children: [
				statusIcons[status_1],
				" ",
				statusLabels[status_1]
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 22
			}, this), /* @__PURE__ */ _jsxDEV(CountBadge, { children: tasksByStatus[status_1].length }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 83
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 8
			}, this), /* @__PURE__ */ _jsxDEV(CardList, { children: tasksByStatus[status_1].length ? tasksByStatus[status_1].map((task_0) => /* @__PURE__ */ _jsxDEV(TaskCard, {
				task: task_0,
				onOpen: onOpenTask,
				onDragEnd: () => {
					setDraggedTask(null);
					setDragOverStatus(null);
				},
				onDragStart: setDraggedTask
			}, task_0.id, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 237
			}, this)) : /* @__PURE__ */ _jsxDEV(EmptyColumn, { children: "Nenhuma tarefa nesta coluna." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 47
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 155
			}, this)]
		}, status_1, true, {
			fileName: _jsxFileName,
			lineNumber: 68,
			columnNumber: 40
		}, this));
		$[1] = dragOverStatus;
		$[2] = draggedTask;
		$[3] = onMoveTask;
		$[4] = onOpenTask;
		$[5] = tasks;
		$[6] = T0;
		$[7] = T1;
		$[8] = t1;
		$[9] = t2;
	} else {
		T0 = $[6];
		T1 = $[7];
		t1 = $[8];
		t2 = $[9];
	}
	let t3;
	if ($[15] !== T0 || $[16] !== t1) {
		t3 = /* @__PURE__ */ _jsxDEV(T0, { children: t1 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 96,
			columnNumber: 10
		}, this);
		$[15] = T0;
		$[16] = t1;
		$[17] = t3;
	} else {
		t3 = $[17];
	}
	let t4;
	if ($[18] !== T1 || $[19] !== t2 || $[20] !== t3) {
		t4 = /* @__PURE__ */ _jsxDEV(T1, {
			"aria-label": t2,
			children: t3
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 105,
			columnNumber: 10
		}, this);
		$[18] = T1;
		$[19] = t2;
		$[20] = t3;
		$[21] = t4;
	} else {
		t4 = $[21];
	}
	return t4;
}
_s(TaskBoard, "IxFw6Le96DlHetQvG1tXZWxoKg8=");
_c2 = TaskBoard;
var _c2;
$RefreshReg$(_c2, "TaskBoard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/tasks/TaskBoard.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskBoard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskBoard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskBoard.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLGdCQUFnQjtBQUV6QixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsYUFBYUMsb0JBQW9CO0FBQzFDLFNBQVNDLFdBQVdDLGVBQWVDLFVBQVVDLFFBQVFDLGNBQWNDLFlBQVlDLG1CQUFtQjtBQUNsRyxTQUFTQyxnQkFBZ0I7Ozs7QUFRekIsT0FBTyxTQUFBQyxVQUFBQyxJQUFBOztDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLElBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFtQixRQUFBSyxPQUFBQyxZQUFBQyxlQUFBUjtDQUN4QixPQUFBUyxhQUFBQyxrQkFBc0N2QixTQUFzQixJQUFJO0NBQ2hFLE9BQUF3QixnQkFBQUMscUJBQTRDekIsU0FBNEIsSUFBSTtDQUFFLElBQUEwQjtDQUFBLElBQUFDO0NBQUEsSUFBQUM7Q0FBQSxJQUFBQztDQUFBLElBQUFmLEVBQUEsT0FBQVUsa0JBQUFWLEVBQUEsT0FBQVEsZUFBQVIsRUFBQSxPQUFBTyxjQUFBUCxFQUFBLE9BQUFNLGNBQUFOLEVBQUEsT0FBQUssT0FBQTtFQUFBLElBQUFXO0VBQUEsSUFBQWhCLEVBQUEsUUFBQUssT0FBQTtHQUU1RVcsTUFBQUMsS0FBQUMsWUFBa0I7SUFBQSxHQUNiRDtLQUNGQyxTQUFTYixNQUFLYyxRQUFRQyxTQUFVQSxLQUFJRixXQUFZQSxNQUFNO0dBQ3pEO0dBQUVsQixFQUFBLE1BQUFLO0dBQUFMLEVBQUEsTUFBQWdCO0VBQUE7R0FBQUEsS0FBQWhCLEVBQUE7RUFBQTtFQUpKLE1BQUFxQixnQkFBc0JsQyxjQUFhbUMsT0FDakNOLElBSUE7R0FBQU8sTUFDUTtHQUFFQyxhQUNLO0dBQUVDLE1BQ1Q7RUFDUixDQUNGO0VBQUUsSUFBQUM7RUFBQSxJQUFBMUIsRUFBQSxRQUFBUSxlQUFBUixFQUFBLFFBQUFPLFlBQUE7R0FFRm1CLEtBQUEsU0FBQUMsV0FBQUMsVUFBQTtJQUNFLElBQUlwQixlQUFlQSxZQUFXVSxXQUFZQSxVQUFNO0tBQzlDWCxXQUFXQyxhQUFhVSxRQUFNO0lBQUM7SUFHakNULGVBQWUsSUFBSTtJQUNuQkUsa0JBQWtCLElBQUk7R0FBQztHQUN4QlgsRUFBQSxNQUFBUTtHQUFBUixFQUFBLE1BQUFPO0dBQUFQLEVBQUEsTUFBQTBCO0VBQUE7R0FBQUEsS0FBQTFCLEVBQUE7RUFBQTtFQVBELE1BQUEyQixhQUFBRDtFQVVHYixLQUFBdEI7RUFBeUJ3QixLQUFBO0VBQ3ZCSCxLQUFBdEI7RUFDRXdCLEtBQUEzQixjQUFhMEMsS0FBS0MsYUFDakIsd0JBQUMsUUFBRDtHQUVpQixlQUFBcEIsbUJBQW1CUTtHQUNyQixtQkFBTVAsbUJBQWtCb0IsWUFBY0EsWUFBWWIsV0FBWixPQUFBYSxPQUFvQztHQUMzRSxhQUFBQyxVQUFBO0lBQ1ZBLE1BQUtDLGVBQWdCO0lBQ3JCRCxNQUFLRSxhQUFhQyxhQUFjO0lBQ2hDeEIsa0JBQWtCTyxRQUFNO0dBQUM7R0FFbkIsU0FBQWtCLFlBQUE7SUFDTkosUUFBS0MsZUFBZ0I7SUFDckJOLFdBQVdULFFBQU07R0FBQzthQVh0QixDQWNFLHdCQUFDLGNBQUQsYUFDRTtJQUNHOUIsWUFBWThCO0lBQVE7SUFBRTdCLGFBQWE2QjtHQUMvQjs7OzthQUNQLHdCQUFDLFlBQUQsWUFBYUcsY0FBY0gsU0FBTyxDQUFBbUIsT0FBdkI7Ozs7V0FKQTs7OzthQU9iLHdCQUFDLFVBQUQsWUFDR2hCLGNBQWNILFNBQU8sQ0FBQW1CLFNBQ3BCaEIsY0FBY0gsU0FBTyxDQUFBVyxLQUFLUyxXQUN4Qix3QkFBQyxVQUFEO0lBRVFsQjtJQUNFZDtJQUNHO0tBQ1RHLGVBQWUsSUFBSTtLQUNuQkUsa0JBQWtCLElBQUk7SUFBQztJQUVaRjtHQUFjLEdBUHRCVyxPQUFJbUI7Ozs7VUFPa0IsQ0FLakMsSUFERSx3QkFBQyxhQUFELFlBQWEsK0JBQUQ7Ozs7WUFmUDs7OztXQXJCSjtLQUNBckI7Ozs7U0FEQSxDQXdDUjtFQUFDbEIsRUFBQSxLQUFBVTtFQUFBVixFQUFBLEtBQUFRO0VBQUFSLEVBQUEsS0FBQU87RUFBQVAsRUFBQSxLQUFBTTtFQUFBTixFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQVk7RUFBQVosRUFBQSxLQUFBYTtFQUFBYixFQUFBLEtBQUFjO0VBQUFkLEVBQUEsS0FBQWU7Q0FBQTtFQUFBSCxLQUFBWixFQUFBO0VBQUFhLEtBQUFiLEVBQUE7RUFBQWMsS0FBQWQsRUFBQTtFQUFBZSxLQUFBZixFQUFBO0NBQUE7Q0FBQSxJQUFBZ0I7Q0FBQSxJQUFBaEIsRUFBQSxRQUFBWSxNQUFBWixFQUFBLFFBQUFjLElBQUE7RUExQ0pFLEtBQUEsd0JBQUMsSUFBRCxZQUNHRixHQURPOzs7OztFQTJDRWQsRUFBQSxNQUFBWTtFQUFBWixFQUFBLE1BQUFjO0VBQUFkLEVBQUEsTUFBQWdCO0NBQUE7RUFBQUEsS0FBQWhCLEVBQUE7Q0FBQTtDQUFBLElBQUEwQjtDQUFBLElBQUExQixFQUFBLFFBQUFhLE1BQUFiLEVBQUEsUUFBQWUsTUFBQWYsRUFBQSxRQUFBZ0IsSUFBQTtFQTVDZFUsS0FBQSx3QkFBQyxJQUFEO0dBQTBCLGNBQUFYO2FBQ3hCQztFQURZOzs7OztFQTZDRWhCLEVBQUEsTUFBQWE7RUFBQWIsRUFBQSxNQUFBZTtFQUFBZixFQUFBLE1BQUFnQjtFQUFBaEIsRUFBQSxNQUFBMEI7Q0FBQTtFQUFBQSxLQUFBMUIsRUFBQTtDQUFBO0NBQUEsT0E3Q2hCMEI7QUE2Q2dCIiwibmFtZXMiOlsidXNlU3RhdGUiLCJUQVNLX1NUQVRVU0VTIiwic3RhdHVzSWNvbnMiLCJzdGF0dXNMYWJlbHMiLCJCb2FyZEdyaWQiLCJCb2FyZFNjcm9sbGVyIiwiQ2FyZExpc3QiLCJDb2x1bW4iLCJDb2x1bW5IZWFkZXIiLCJDb3VudEJhZGdlIiwiRW1wdHlDb2x1bW4iLCJUYXNrQ2FyZCIsIlRhc2tCb2FyZCIsInQwIiwiJCIsIl9jIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJ0YXNrcyIsIm9uT3BlblRhc2siLCJvbk1vdmVUYXNrIiwiZHJhZ2dlZFRhc2siLCJzZXREcmFnZ2VkVGFzayIsImRyYWdPdmVyU3RhdHVzIiwic2V0RHJhZ092ZXJTdGF0dXMiLCJUMCIsIlQxIiwidDEiLCJ0MiIsInQzIiwiYWNjIiwic3RhdHVzIiwiZmlsdGVyIiwidGFzayIsInRhc2tzQnlTdGF0dXMiLCJyZWR1Y2UiLCJUT0RPIiwiSU5fUFJPR1JFU1MiLCJET05FIiwidDQiLCJoYW5kbGVEcm9wIiwic3RhdHVzXzAiLCJtYXAiLCJzdGF0dXNfMSIsImN1cnJlbnQiLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwiZGF0YVRyYW5zZmVyIiwiZHJvcEVmZmVjdCIsImV2ZW50XzAiLCJsZW5ndGgiLCJ0YXNrXzAiLCJpZCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUYXNrQm9hcmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgdHlwZSB7IFRhc2ssIFRhc2tTdGF0dXMgfSBmcm9tIFwiLi4vLi4vaW50ZXJmYWNlcy90YXNrcy90YXNrXCI7XG5pbXBvcnQgeyBUQVNLX1NUQVRVU0VTIH0gZnJvbSBcIi4uLy4uL2ludGVyZmFjZXMvdGFza3MvdGFza1wiO1xuaW1wb3J0IHsgc3RhdHVzSWNvbnMsIHN0YXR1c0xhYmVscyB9IGZyb20gXCIuL2xhYmVsc1wiO1xuaW1wb3J0IHsgQm9hcmRHcmlkLCBCb2FyZFNjcm9sbGVyLCBDYXJkTGlzdCwgQ29sdW1uLCBDb2x1bW5IZWFkZXIsIENvdW50QmFkZ2UsIEVtcHR5Q29sdW1uIH0gZnJvbSBcIi4vc3R5bGVzXCI7XG5pbXBvcnQgeyBUYXNrQ2FyZCB9IGZyb20gXCIuL1Rhc2tDYXJkXCI7XG5cbnR5cGUgVGFza0JvYXJkUHJvcHMgPSB7XG4gIHRhc2tzOiBUYXNrW107XG4gIG9uT3BlblRhc2s6ICh0YXNrOiBUYXNrKSA9PiB2b2lkO1xuICBvbk1vdmVUYXNrOiAodGFzazogVGFzaywgc3RhdHVzOiBUYXNrU3RhdHVzKSA9PiB2b2lkO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIFRhc2tCb2FyZCh7IHRhc2tzLCBvbk9wZW5UYXNrLCBvbk1vdmVUYXNrIH06IFRhc2tCb2FyZFByb3BzKSB7XG4gIGNvbnN0IFtkcmFnZ2VkVGFzaywgc2V0RHJhZ2dlZFRhc2tdID0gdXNlU3RhdGU8VGFzayB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbZHJhZ092ZXJTdGF0dXMsIHNldERyYWdPdmVyU3RhdHVzXSA9IHVzZVN0YXRlPFRhc2tTdGF0dXMgfCBudWxsPihudWxsKTtcbiAgY29uc3QgdGFza3NCeVN0YXR1cyA9IFRBU0tfU1RBVFVTRVMucmVkdWNlPFJlY29yZDxUYXNrU3RhdHVzLCBUYXNrW10+PihcbiAgICAoYWNjLCBzdGF0dXMpID0+ICh7XG4gICAgICAuLi5hY2MsXG4gICAgICBbc3RhdHVzXTogdGFza3MuZmlsdGVyKCh0YXNrKSA9PiB0YXNrLnN0YXR1cyA9PT0gc3RhdHVzKSxcbiAgICB9KSxcbiAgICB7XG4gICAgICBUT0RPOiBbXSxcbiAgICAgIElOX1BST0dSRVNTOiBbXSxcbiAgICAgIERPTkU6IFtdLFxuICAgIH0sXG4gICk7XG5cbiAgZnVuY3Rpb24gaGFuZGxlRHJvcChzdGF0dXM6IFRhc2tTdGF0dXMpIHtcbiAgICBpZiAoZHJhZ2dlZFRhc2sgJiYgZHJhZ2dlZFRhc2suc3RhdHVzICE9PSBzdGF0dXMpIHtcbiAgICAgIG9uTW92ZVRhc2soZHJhZ2dlZFRhc2ssIHN0YXR1cyk7XG4gICAgfVxuXG4gICAgc2V0RHJhZ2dlZFRhc2sobnVsbCk7XG4gICAgc2V0RHJhZ092ZXJTdGF0dXMobnVsbCk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxCb2FyZFNjcm9sbGVyIGFyaWEtbGFiZWw9XCJCb2FyZCBkZSB0YXJlZmFzXCI+XG4gICAgICA8Qm9hcmRHcmlkPlxuICAgICAgICB7VEFTS19TVEFUVVNFUy5tYXAoKHN0YXR1cykgPT4gKFxuICAgICAgICAgIDxDb2x1bW5cbiAgICAgICAgICAgIGtleT17c3RhdHVzfVxuICAgICAgICAgICAgJGlzRHJvcFRhcmdldD17ZHJhZ092ZXJTdGF0dXMgPT09IHN0YXR1c31cbiAgICAgICAgICAgIG9uRHJhZ0xlYXZlPXsoKSA9PiBzZXREcmFnT3ZlclN0YXR1cygoY3VycmVudCkgPT4gKGN1cnJlbnQgPT09IHN0YXR1cyA/IG51bGwgOiBjdXJyZW50KSl9XG4gICAgICAgICAgICBvbkRyYWdPdmVyPXsoZXZlbnQpID0+IHtcbiAgICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgZXZlbnQuZGF0YVRyYW5zZmVyLmRyb3BFZmZlY3QgPSBcIm1vdmVcIjtcbiAgICAgICAgICAgICAgc2V0RHJhZ092ZXJTdGF0dXMoc3RhdHVzKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBvbkRyb3A9eyhldmVudCkgPT4ge1xuICAgICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICBoYW5kbGVEcm9wKHN0YXR1cyk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxDb2x1bW5IZWFkZXI+XG4gICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgIHtzdGF0dXNJY29uc1tzdGF0dXNdfSB7c3RhdHVzTGFiZWxzW3N0YXR1c119XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPENvdW50QmFkZ2U+e3Rhc2tzQnlTdGF0dXNbc3RhdHVzXS5sZW5ndGh9PC9Db3VudEJhZGdlPlxuICAgICAgICAgICAgPC9Db2x1bW5IZWFkZXI+XG5cbiAgICAgICAgICAgIDxDYXJkTGlzdD5cbiAgICAgICAgICAgICAge3Rhc2tzQnlTdGF0dXNbc3RhdHVzXS5sZW5ndGggPyAoXG4gICAgICAgICAgICAgICAgdGFza3NCeVN0YXR1c1tzdGF0dXNdLm1hcCgodGFzaykgPT4gKFxuICAgICAgICAgICAgICAgICAgPFRhc2tDYXJkXG4gICAgICAgICAgICAgICAgICAgIGtleT17dGFzay5pZH1cbiAgICAgICAgICAgICAgICAgICAgdGFzaz17dGFza31cbiAgICAgICAgICAgICAgICAgICAgb25PcGVuPXtvbk9wZW5UYXNrfVxuICAgICAgICAgICAgICAgICAgICBvbkRyYWdFbmQ9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBzZXREcmFnZ2VkVGFzayhudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICBzZXREcmFnT3ZlclN0YXR1cyhudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgb25EcmFnU3RhcnQ9e3NldERyYWdnZWRUYXNrfVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxFbXB0eUNvbHVtbj5OZW5odW1hIHRhcmVmYSBuZXN0YSBjb2x1bmEuPC9FbXB0eUNvbHVtbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvQ2FyZExpc3Q+XG4gICAgICAgICAgPC9Db2x1bW4+XG4gICAgICAgICkpfVxuICAgICAgPC9Cb2FyZEdyaWQ+XG4gICAgPC9Cb2FyZFNjcm9sbGVyPlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy93YWxsYS9EZXNrdG9wL1Byb2pldG9zLXBlc3NvYWlzL3Byb3ZhLXRlY25pY2EvZnJvbnQtbWluaS10YXNrLW1hbmFnZXIvc3JjL2NvbXBvbmVudHMvdGFza3MvVGFza0JvYXJkLnRzeCJ9