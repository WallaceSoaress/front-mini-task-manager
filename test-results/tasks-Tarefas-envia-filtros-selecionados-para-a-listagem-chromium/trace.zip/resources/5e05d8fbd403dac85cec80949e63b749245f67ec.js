import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/PrivateNavigation.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=df6b4f96";
import { NavLink } from "/node_modules/.vite/deps/react-router.js?v=01185dd1";
import { Navigation } from "/src/components/layout/styles.ts";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/layout/PrivateNavigation.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=df6b4f96";
export function PrivateNavigation() {
	const $ = _c(2);
	if ($[0] !== "1efdff5f37c754cb8ead4cfbc70984475d79b11ba1983315f67826cfa251dbe5") {
		for (let $i = 0; $i < 2; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "1efdff5f37c754cb8ead4cfbc70984475d79b11ba1983315f67826cfa251dbe5";
	}
	let t0;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ _jsxDEV(Navigation, {
			"aria-label": "Navegacao privada",
			children: [/* @__PURE__ */ _jsxDEV(NavLink, {
				to: "/",
				children: "Tarefas"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 53
			}, this), /* @__PURE__ */ _jsxDEV(NavLink, {
				to: "/teams",
				children: "Times"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 86
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 10
		}, this);
		$[1] = t0;
	} else {
		t0 = $[1];
	}
	return t0;
}
_c2 = PrivateNavigation;
var _c2;
$RefreshReg$(_c2, "PrivateNavigation");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/PrivateNavigation.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/layout/PrivateNavigation.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/layout/PrivateNavigation.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/layout/PrivateNavigation.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLGVBQWU7QUFDeEIsU0FBU0Msa0JBQWtCOzs7QUFFM0IsT0FBTyxTQUFBQyxvQkFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFLO0NBQUEsSUFBQUwsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBRUhDLEtBQUEsd0JBQUMsWUFBRDtHQUF1QjthQUF2QixDQUNFLHdCQUFDLFNBQUQ7SUFBWTtjQUFJO0dBQVI7Ozs7YUFDUix3QkFBQyxTQUFEO0lBQVk7Y0FBUztHQUFiOzs7O1dBRkM7Ozs7OztFQUdFTCxFQUFBLEtBQUFLO0NBQUE7RUFBQUEsS0FBQUwsRUFBQTtDQUFBO0NBQUEsT0FIYks7QUFHYSIsIm5hbWVzIjpbIk5hdkxpbmsiLCJOYXZpZ2F0aW9uIiwiUHJpdmF0ZU5hdmlnYXRpb24iLCIkIiwiX2MiLCIkaSIsIlN5bWJvbCIsImZvciIsInQwIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlByaXZhdGVOYXZpZ2F0aW9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOYXZMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlclwiO1xuaW1wb3J0IHsgTmF2aWdhdGlvbiB9IGZyb20gXCIuL3N0eWxlc1wiO1xuXG5leHBvcnQgZnVuY3Rpb24gUHJpdmF0ZU5hdmlnYXRpb24oKSB7XG4gIHJldHVybiAoXG4gICAgPE5hdmlnYXRpb24gYXJpYS1sYWJlbD1cIk5hdmVnYWNhbyBwcml2YWRhXCI+XG4gICAgICA8TmF2TGluayB0bz1cIi9cIj5UYXJlZmFzPC9OYXZMaW5rPlxuICAgICAgPE5hdkxpbmsgdG89XCIvdGVhbXNcIj5UaW1lczwvTmF2TGluaz5cbiAgICA8L05hdmlnYXRpb24+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3dhbGxhL0Rlc2t0b3AvUHJvamV0b3MtcGVzc29haXMvcHJvdmEtdGVjbmljYS9mcm9udC1taW5pLXRhc2stbWFuYWdlci9zcmMvY29tcG9uZW50cy9sYXlvdXQvUHJpdmF0ZU5hdmlnYXRpb24udHN4In0=