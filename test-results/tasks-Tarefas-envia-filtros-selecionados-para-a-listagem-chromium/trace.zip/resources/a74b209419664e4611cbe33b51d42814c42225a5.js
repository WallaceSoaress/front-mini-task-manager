import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/tasks/TaskFormModal.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const useEffect = __vite__cjsImport1_react["useEffect"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=df6b4f96";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=df6b4f96";
import { useForm, useWatch } from "/node_modules/.vite/deps/react-hook-form.js?v=629faa4b";
import { ValidationError } from "/node_modules/.vite/deps/yup.js?v=d00fe6e5";
import { normalizeDueDate, toTaskRequest, validateTaskForm } from "/src/validations/tasks/taskSchema.ts";
import { priorityLabels, statusLabels } from "/src/components/tasks/labels.ts";
import { Button, Field, FieldError, FormGrid, ModalActions, ModalBackdrop, ModalBody, ModalHeader, ModalPanel } from "/src/components/tasks/styles.ts";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskFormModal.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=df6b4f96";
var _s = $RefreshSig$();
const defaultValues = {
	title: "",
	description: "",
	status: "TODO",
	priority: "MEDIUM",
	responsibleId: "",
	teamId: "",
	dueDate: ""
};
export function TaskFormModal(t0) {
	_s();
	const $ = _c(148);
	if ($[0] !== "9f7615bb60615af2c8568330f1d088f302e46b2eaa41b5293437638fce8fa9b1") {
		for (let $i = 0; $i < 148; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "9f7615bb60615af2c8568330f1d088f302e46b2eaa41b5293437638fce8fa9b1";
	}
	const { task, teams, isLoading, apiError, onClose, onSubmit } = t0;
	const [formError, setFormError] = useState("");
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = { defaultValues };
		$[1] = t1;
	} else {
		t1 = $[1];
	}
	const { clearErrors, control, formState: t2, getValues, handleSubmit, register, reset, setError, setValue } = useForm(t1);
	const { errors } = t2;
	let t3;
	if ($[2] !== control) {
		t3 = {
			control,
			name: "teamId"
		};
		$[2] = control;
		$[3] = t3;
	} else {
		t3 = $[3];
	}
	const selectedTeamId = useWatch(t3);
	let t4;
	if ($[4] !== control) {
		t4 = {
			control,
			name: "responsibleId"
		};
		$[4] = control;
		$[5] = t4;
	} else {
		t4 = $[5];
	}
	const selectedResponsibleId = useWatch(t4);
	let t5;
	if ($[6] !== selectedTeamId) {
		t5 = (team) => team.id === selectedTeamId;
		$[6] = selectedTeamId;
		$[7] = t5;
	} else {
		t5 = $[7];
	}
	const selectedTeam = teams.find(t5);
	const responsibleOptions = selectedTeam?.members ?? [];
	let t6;
	let t7;
	if ($[8] !== reset || $[9] !== task) {
		t6 = () => {
			reset(task ? {
				title: task.title,
				description: task.description ?? "",
				status: task.status,
				priority: task.priority,
				responsibleId: task.responsible?.id ?? "",
				teamId: task.team.id,
				dueDate: task.dueDate ?? ""
			} : defaultValues);
		};
		t7 = [reset, task];
		$[8] = reset;
		$[9] = task;
		$[10] = t6;
		$[11] = t7;
	} else {
		t6 = $[10];
		t7 = $[11];
	}
	useEffect(t6, t7);
	let t8;
	if ($[12] !== getValues || $[13] !== setValue || $[14] !== task || $[15] !== teams[0]?.id) {
		t8 = () => {
			const firstTeamId = teams[0]?.id ?? "";
			if (!task && firstTeamId && !getValues("teamId")) {
				setValue("teamId", firstTeamId);
			}
		};
		$[12] = getValues;
		$[13] = setValue;
		$[14] = task;
		$[15] = teams[0]?.id;
		$[16] = t8;
	} else {
		t8 = $[16];
	}
	let t9;
	if ($[17] !== getValues || $[18] !== setValue || $[19] !== task || $[20] !== teams) {
		t9 = [
			getValues,
			setValue,
			task,
			teams
		];
		$[17] = getValues;
		$[18] = setValue;
		$[19] = task;
		$[20] = teams;
		$[21] = t9;
	} else {
		t9 = $[21];
	}
	useEffect(t8, t9);
	useEffect(() => {
		if (!selectedResponsibleId || !selectedTeam) {
			return;
		}
		const responsibleBelongsToTeam = selectedTeam.members.some((member) => member.id === selectedResponsibleId);
		if (!responsibleBelongsToTeam) {
			setValue("responsibleId", "", {
				shouldDirty: true,
				shouldValidate: true
			});
			clearErrors("responsibleId");
		}
	}, [
		clearErrors,
		selectedResponsibleId,
		selectedTeam,
		setValue
	]);
	let t10;
	if ($[22] !== clearErrors || $[23] !== register || $[24] !== setValue) {
		t10 = function registerField(field) {
			const registration = register(field);
			return {
				...registration,
				onChange: (event) => {
					registration.onChange(event);
					setValue(field, event.currentTarget.value, {
						shouldDirty: true,
						shouldTouch: true
					});
					clearErrors(field);
					setFormError("");
				}
			};
		};
		$[22] = clearErrors;
		$[23] = register;
		$[24] = setValue;
		$[25] = t10;
	} else {
		t10 = $[25];
	}
	const registerField = t10;
	let t11;
	if ($[26] !== clearErrors || $[27] !== onSubmit || $[28] !== setError) {
		t11 = async function submit(data) {
			setFormError("");
			clearErrors();
			;
			try {
				const validData = await validateTaskForm({
					...data,
					dueDate: normalizeDueDate(data.dueDate)
				});
				await onSubmit(toTaskRequest(validData));
			} catch (t12) {
				const err = t12;
				if (err instanceof ValidationError) {
					err.inner.forEach((issue) => {
						if (issue.path) {
							setError(issue.path, { message: issue.message });
						}
					});
					return;
				}
				setFormError("Nao foi possivel salvar a tarefa.");
			}
		};
		$[26] = clearErrors;
		$[27] = onSubmit;
		$[28] = setError;
		$[29] = t11;
	} else {
		t11 = $[29];
	}
	const submit = t11;
	const T0 = ModalBackdrop;
	const t12 = "presentation";
	const T1 = ModalPanel;
	const t13 = "dialog";
	const t14 = "true";
	const t15 = "task-form-title";
	const t16 = task ? "Editar tarefa" : "Criar tarefa";
	let t17;
	if ($[30] !== t16) {
		t17 = /* @__PURE__ */ _jsxDEV("h2", {
			id: "task-form-title",
			children: t16
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 237,
			columnNumber: 11
		}, this);
		$[30] = t16;
		$[31] = t17;
	} else {
		t17 = $[31];
	}
	const t18 = task ? "Atualize os dados da demanda." : "Cadastre uma nova demanda do time.";
	let t19;
	if ($[32] !== t18) {
		t19 = /* @__PURE__ */ _jsxDEV("p", { children: t18 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 246,
			columnNumber: 11
		}, this);
		$[32] = t18;
		$[33] = t19;
	} else {
		t19 = $[33];
	}
	let t20;
	if ($[34] !== t17 || $[35] !== t19) {
		t20 = /* @__PURE__ */ _jsxDEV("div", { children: [t17, t19] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 254,
			columnNumber: 11
		}, this);
		$[34] = t17;
		$[35] = t19;
		$[36] = t20;
	} else {
		t20 = $[36];
	}
	let t21;
	if ($[37] !== isLoading || $[38] !== onClose) {
		t21 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			$variant: "ghost",
			onClick: onClose,
			disabled: isLoading,
			children: "Fechar"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 263,
			columnNumber: 11
		}, this);
		$[37] = isLoading;
		$[38] = onClose;
		$[39] = t21;
	} else {
		t21 = $[39];
	}
	let t22;
	if ($[40] !== t20 || $[41] !== t21) {
		t22 = /* @__PURE__ */ _jsxDEV(ModalHeader, { children: [t20, t21] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 272,
			columnNumber: 11
		}, this);
		$[40] = t20;
		$[41] = t21;
		$[42] = t22;
	} else {
		t22 = $[42];
	}
	const T2 = ModalBody;
	const T3 = FormGrid;
	let t23;
	if ($[43] !== handleSubmit || $[44] !== submit) {
		t23 = handleSubmit(submit);
		$[43] = handleSubmit;
		$[44] = submit;
		$[45] = t23;
	} else {
		t23 = $[45];
	}
	let t24;
	if ($[46] !== registerField) {
		t24 = /* @__PURE__ */ _jsxDEV("input", {
			...registerField("title"),
			autoFocus: true,
			maxLength: 160
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 292,
			columnNumber: 11
		}, this);
		$[46] = registerField;
		$[47] = t24;
	} else {
		t24 = $[47];
	}
	let t25;
	if ($[48] !== errors.title) {
		t25 = errors.title?.message ? /* @__PURE__ */ _jsxDEV(FieldError, {
			role: "alert",
			children: errors.title.message
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 300,
			columnNumber: 35
		}, this) : null;
		$[48] = errors.title;
		$[49] = t25;
	} else {
		t25 = $[49];
	}
	let t26;
	if ($[50] !== t24 || $[51] !== t25) {
		t26 = /* @__PURE__ */ _jsxDEV(Field, { children: [
			"Titulo",
			t24,
			t25
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 308,
			columnNumber: 11
		}, this);
		$[50] = t24;
		$[51] = t25;
		$[52] = t26;
	} else {
		t26 = $[52];
	}
	let t27;
	if ($[53] !== registerField) {
		t27 = /* @__PURE__ */ _jsxDEV("textarea", { ...registerField("description") }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 317,
			columnNumber: 11
		}, this);
		$[53] = registerField;
		$[54] = t27;
	} else {
		t27 = $[54];
	}
	let t28;
	if ($[55] !== errors.description) {
		t28 = errors.description?.message ? /* @__PURE__ */ _jsxDEV(FieldError, {
			role: "alert",
			children: errors.description.message
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 325,
			columnNumber: 41
		}, this) : null;
		$[55] = errors.description;
		$[56] = t28;
	} else {
		t28 = $[56];
	}
	let t29;
	if ($[57] !== t27 || $[58] !== t28) {
		t29 = /* @__PURE__ */ _jsxDEV(Field, { children: [
			"Descricao",
			t27,
			t28
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 333,
			columnNumber: 11
		}, this);
		$[57] = t27;
		$[58] = t28;
		$[59] = t29;
	} else {
		t29 = $[59];
	}
	let t30;
	if ($[60] !== registerField) {
		t30 = registerField("status");
		$[60] = registerField;
		$[61] = t30;
	} else {
		t30 = $[61];
	}
	let t31;
	if ($[62] === Symbol.for("react.memo_cache_sentinel")) {
		t31 = Object.entries(statusLabels).map(_temp);
		$[62] = t31;
	} else {
		t31 = $[62];
	}
	let t32;
	if ($[63] !== t30) {
		t32 = /* @__PURE__ */ _jsxDEV("select", {
			...t30,
			children: t31
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 357,
			columnNumber: 11
		}, this);
		$[63] = t30;
		$[64] = t32;
	} else {
		t32 = $[64];
	}
	let t33;
	if ($[65] !== errors.status) {
		t33 = errors.status?.message ? /* @__PURE__ */ _jsxDEV(FieldError, {
			role: "alert",
			children: errors.status.message
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 365,
			columnNumber: 36
		}, this) : null;
		$[65] = errors.status;
		$[66] = t33;
	} else {
		t33 = $[66];
	}
	let t34;
	if ($[67] !== t32 || $[68] !== t33) {
		t34 = /* @__PURE__ */ _jsxDEV(Field, { children: [
			"Status",
			t32,
			t33
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 373,
			columnNumber: 11
		}, this);
		$[67] = t32;
		$[68] = t33;
		$[69] = t34;
	} else {
		t34 = $[69];
	}
	let t35;
	if ($[70] !== registerField) {
		t35 = registerField("priority");
		$[70] = registerField;
		$[71] = t35;
	} else {
		t35 = $[71];
	}
	let t36;
	if ($[72] === Symbol.for("react.memo_cache_sentinel")) {
		t36 = Object.entries(priorityLabels).map(_temp2);
		$[72] = t36;
	} else {
		t36 = $[72];
	}
	let t37;
	if ($[73] !== t35) {
		t37 = /* @__PURE__ */ _jsxDEV("select", {
			...t35,
			children: t36
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 397,
			columnNumber: 11
		}, this);
		$[73] = t35;
		$[74] = t37;
	} else {
		t37 = $[74];
	}
	let t38;
	if ($[75] !== errors.priority) {
		t38 = errors.priority?.message ? /* @__PURE__ */ _jsxDEV(FieldError, {
			role: "alert",
			children: errors.priority.message
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 405,
			columnNumber: 38
		}, this) : null;
		$[75] = errors.priority;
		$[76] = t38;
	} else {
		t38 = $[76];
	}
	let t39;
	if ($[77] !== t37 || $[78] !== t38) {
		t39 = /* @__PURE__ */ _jsxDEV(Field, { children: [
			"Prioridade",
			t37,
			t38
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 413,
			columnNumber: 11
		}, this);
		$[77] = t37;
		$[78] = t38;
		$[79] = t39;
	} else {
		t39 = $[79];
	}
	let t40;
	if ($[80] !== registerField) {
		t40 = registerField("teamId");
		$[80] = registerField;
		$[81] = t40;
	} else {
		t40 = $[81];
	}
	let t41;
	if ($[82] === Symbol.for("react.memo_cache_sentinel")) {
		t41 = /* @__PURE__ */ _jsxDEV("option", {
			value: "",
			children: "Selecione"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 430,
			columnNumber: 11
		}, this);
		$[82] = t41;
	} else {
		t41 = $[82];
	}
	let t42;
	if ($[83] !== teams) {
		t42 = teams.map(_temp3);
		$[83] = teams;
		$[84] = t42;
	} else {
		t42 = $[84];
	}
	let t43;
	if ($[85] !== t40 || $[86] !== t42) {
		t43 = /* @__PURE__ */ _jsxDEV("select", {
			...t40,
			children: [t41, t42]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 445,
			columnNumber: 11
		}, this);
		$[85] = t40;
		$[86] = t42;
		$[87] = t43;
	} else {
		t43 = $[87];
	}
	let t44;
	if ($[88] !== errors.teamId) {
		t44 = errors.teamId?.message ? /* @__PURE__ */ _jsxDEV(FieldError, {
			role: "alert",
			children: errors.teamId.message
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 454,
			columnNumber: 36
		}, this) : null;
		$[88] = errors.teamId;
		$[89] = t44;
	} else {
		t44 = $[89];
	}
	let t45;
	if ($[90] !== t43 || $[91] !== t44) {
		t45 = /* @__PURE__ */ _jsxDEV(Field, { children: [
			"Time",
			t43,
			t44
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 462,
			columnNumber: 11
		}, this);
		$[90] = t43;
		$[91] = t44;
		$[92] = t45;
	} else {
		t45 = $[92];
	}
	const T4 = Field;
	const t46 = "Responsavel";
	let t47;
	if ($[93] !== registerField) {
		t47 = registerField("responsibleId");
		$[93] = registerField;
		$[94] = t47;
	} else {
		t47 = $[94];
	}
	const t48 = !selectedTeamId;
	let t49;
	if ($[95] === Symbol.for("react.memo_cache_sentinel")) {
		t49 = /* @__PURE__ */ _jsxDEV("option", {
			value: "",
			children: "Nao atribuido"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 482,
			columnNumber: 11
		}, this);
		$[95] = t49;
	} else {
		t49 = $[95];
	}
	const t50 = responsibleOptions.map(_temp4);
	let t51;
	if ($[96] !== t47 || $[97] !== t48 || $[98] !== t49 || $[99] !== t50) {
		t51 = /* @__PURE__ */ _jsxDEV("select", {
			...t47,
			disabled: t48,
			children: [t49, t50]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 490,
			columnNumber: 11
		}, this);
		$[96] = t47;
		$[97] = t48;
		$[98] = t49;
		$[99] = t50;
		$[100] = t51;
	} else {
		t51 = $[100];
	}
	let t52;
	if ($[101] !== errors.responsibleId) {
		t52 = errors.responsibleId?.message ? /* @__PURE__ */ _jsxDEV(FieldError, {
			role: "alert",
			children: errors.responsibleId.message
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 501,
			columnNumber: 43
		}, this) : null;
		$[101] = errors.responsibleId;
		$[102] = t52;
	} else {
		t52 = $[102];
	}
	let t53;
	if ($[103] !== T4 || $[104] !== t51 || $[105] !== t52) {
		t53 = /* @__PURE__ */ _jsxDEV(T4, { children: [
			t46,
			t51,
			t52
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 509,
			columnNumber: 11
		}, this);
		$[103] = T4;
		$[104] = t51;
		$[105] = t52;
		$[106] = t53;
	} else {
		t53 = $[106];
	}
	let t54;
	if ($[107] !== registerField) {
		t54 = /* @__PURE__ */ _jsxDEV("input", {
			...registerField("dueDate"),
			type: "date"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 519,
			columnNumber: 11
		}, this);
		$[107] = registerField;
		$[108] = t54;
	} else {
		t54 = $[108];
	}
	let t55;
	if ($[109] !== errors.dueDate) {
		t55 = errors.dueDate?.message ? /* @__PURE__ */ _jsxDEV(FieldError, {
			role: "alert",
			children: errors.dueDate.message
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 527,
			columnNumber: 37
		}, this) : null;
		$[109] = errors.dueDate;
		$[110] = t55;
	} else {
		t55 = $[110];
	}
	let t56;
	if ($[111] !== t54 || $[112] !== t55) {
		t56 = /* @__PURE__ */ _jsxDEV(Field, {
			className: "full",
			children: [
				"Prazo",
				t54,
				t55
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 535,
			columnNumber: 11
		}, this);
		$[111] = t54;
		$[112] = t55;
		$[113] = t56;
	} else {
		t56 = $[113];
	}
	let t57;
	if ($[114] !== apiError || $[115] !== formError) {
		t57 = apiError || formError ? /* @__PURE__ */ _jsxDEV(FieldError, {
			className: "full",
			role: "alert",
			children: apiError || formError
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 544,
			columnNumber: 35
		}, this) : null;
		$[114] = apiError;
		$[115] = formError;
		$[116] = t57;
	} else {
		t57 = $[116];
	}
	let t58;
	if ($[117] !== isLoading || $[118] !== onClose) {
		t58 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			$variant: "ghost",
			onClick: onClose,
			disabled: isLoading,
			children: "Cancelar"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 553,
			columnNumber: 11
		}, this);
		$[117] = isLoading;
		$[118] = onClose;
		$[119] = t58;
	} else {
		t58 = $[119];
	}
	const t59 = isLoading || !teams.length;
	const t60 = isLoading ? "Salvando..." : "Salvar";
	let t61;
	if ($[120] !== t59 || $[121] !== t60) {
		t61 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "submit",
			disabled: t59,
			children: t60
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 564,
			columnNumber: 11
		}, this);
		$[120] = t59;
		$[121] = t60;
		$[122] = t61;
	} else {
		t61 = $[122];
	}
	let t62;
	if ($[123] !== t58 || $[124] !== t61) {
		t62 = /* @__PURE__ */ _jsxDEV(ModalActions, { children: [t58, t61] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 573,
			columnNumber: 11
		}, this);
		$[123] = t58;
		$[124] = t61;
		$[125] = t62;
	} else {
		t62 = $[125];
	}
	let t63;
	if ($[126] !== T3 || $[127] !== t23 || $[128] !== t26 || $[129] !== t29 || $[130] !== t34 || $[131] !== t39 || $[132] !== t45 || $[133] !== t53 || $[134] !== t56 || $[135] !== t57 || $[136] !== t62) {
		t63 = /* @__PURE__ */ _jsxDEV(T3, {
			onSubmit: t23,
			children: [
				t26,
				t29,
				t34,
				t39,
				t45,
				t53,
				t56,
				t57,
				t62
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 582,
			columnNumber: 11
		}, this);
		$[126] = T3;
		$[127] = t23;
		$[128] = t26;
		$[129] = t29;
		$[130] = t34;
		$[131] = t39;
		$[132] = t45;
		$[133] = t53;
		$[134] = t56;
		$[135] = t57;
		$[136] = t62;
		$[137] = t63;
	} else {
		t63 = $[137];
	}
	let t64;
	if ($[138] !== T2 || $[139] !== t63) {
		t64 = /* @__PURE__ */ _jsxDEV(T2, { children: t63 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 600,
			columnNumber: 11
		}, this);
		$[138] = T2;
		$[139] = t63;
		$[140] = t64;
	} else {
		t64 = $[140];
	}
	let t65;
	if ($[141] !== T1 || $[142] !== t22 || $[143] !== t64) {
		t65 = /* @__PURE__ */ _jsxDEV(T1, {
			role: t13,
			"aria-modal": t14,
			"aria-labelledby": t15,
			children: [t22, t64]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 609,
			columnNumber: 11
		}, this);
		$[141] = T1;
		$[142] = t22;
		$[143] = t64;
		$[144] = t65;
	} else {
		t65 = $[144];
	}
	let t66;
	if ($[145] !== T0 || $[146] !== t65) {
		t66 = /* @__PURE__ */ _jsxDEV(T0, {
			role: t12,
			children: t65
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 619,
			columnNumber: 11
		}, this);
		$[145] = T0;
		$[146] = t65;
		$[147] = t66;
	} else {
		t66 = $[147];
	}
	return t66;
}
_s(TaskFormModal, "Y/W2HkbtlOYgkxRI62Q/wBBN1Lc=", false, function() {
	return [
		useForm,
		useWatch,
		useWatch
	];
});
_c2 = TaskFormModal;
function _temp4(member_0) {
	return /* @__PURE__ */ _jsxDEV("option", {
		value: member_0.id,
		children: member_0.name
	}, member_0.id, false, {
		fileName: _jsxFileName,
		lineNumber: 629,
		columnNumber: 10
	}, this);
}
function _temp3(team_0) {
	return /* @__PURE__ */ _jsxDEV("option", {
		value: team_0.id,
		children: team_0.name
	}, team_0.id, false, {
		fileName: _jsxFileName,
		lineNumber: 632,
		columnNumber: 10
	}, this);
}
function _temp2(t0) {
	const [priority, label_0] = t0;
	return /* @__PURE__ */ _jsxDEV("option", {
		value: priority,
		children: label_0
	}, priority, false, {
		fileName: _jsxFileName,
		lineNumber: 636,
		columnNumber: 10
	}, this);
}
function _temp(t0) {
	const [status, label] = t0;
	return /* @__PURE__ */ _jsxDEV("option", {
		value: status,
		children: label
	}, status, false, {
		fileName: _jsxFileName,
		lineNumber: 640,
		columnNumber: 10
	}, this);
}
var _c2;
$RefreshReg$(_c2, "TaskFormModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/tasks/TaskFormModal.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskFormModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskFormModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskFormModal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQTJCQSxXQUFXQyxnQkFBZ0I7QUFDdEQsU0FBU0MsU0FBU0MsZ0JBQWdCO0FBQ2xDLFNBQVNDLHVCQUF1QjtBQUloQyxTQUNFQyxrQkFDQUMsZUFDQUMsd0JBQ0s7QUFDUCxTQUFTQyxnQkFBZ0JDLG9CQUFvQjtBQUM3QyxTQUNFQyxRQUNBQyxPQUNBQyxZQUNBQyxVQUNBQyxjQUNBQyxlQUNBQyxXQUNBQyxhQUNBQyxrQkFDSzs7OztBQVdQLE1BQU1DLGdCQUE4QjtDQUNsQ0MsT0FBTztDQUNQQyxhQUFhO0NBQ2JDLFFBQVE7Q0FDUkMsVUFBVTtDQUNWQyxlQUFlO0NBQ2ZDLFFBQVE7Q0FDUkMsU0FBUztBQUNYO0FBT0EsT0FBTyxTQUFBQyxjQUFBQyxJQUFBOztDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEtBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUF1QixRQUFBSyxNQUFBQyxPQUFBQyxXQUFBQyxVQUFBQyxTQUFBQyxhQUFBWDtDQVE1QixPQUFBWSxXQUFBQyxnQkFBa0N4QyxTQUFTLEVBQUU7Q0FBRSxJQUFBeUM7Q0FBQSxJQUFBYixFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFXckJTLEtBQUEsRUFBQXZCLGNBRTFCO0VBQUNVLEVBQUEsS0FBQWE7Q0FBQTtFQUFBQSxLQUFBYixFQUFBO0NBQUE7Q0FaRCxRQUFBYyxhQUFBQyxTQUFBQyxXQUFBQyxJQUFBQyxXQUFBQyxjQUFBQyxVQUFBQyxPQUFBQyxVQUFBQyxhQVVJbEQsUUFBc0J3QyxFQUV6QjtDQVRZLFFBQUFXLFdBQUFQO0NBQVUsSUFBQVE7Q0FBQSxJQUFBekIsRUFBQSxPQUFBZSxTQUFBO0VBVVNVLEtBQUE7R0FBQVY7R0FBQVcsTUFBaUI7RUFBUztFQUFDMUIsRUFBQSxLQUFBZTtFQUFBZixFQUFBLEtBQUF5QjtDQUFBO0VBQUFBLEtBQUF6QixFQUFBO0NBQUE7Q0FBM0QsTUFBQTJCLGlCQUF1QnJELFNBQVNtRCxFQUEyQjtDQUFFLElBQUFHO0NBQUEsSUFBQTVCLEVBQUEsT0FBQWUsU0FBQTtFQUN0QmEsS0FBQTtHQUFBYjtHQUFBVyxNQUFpQjtFQUFnQjtFQUFDMUIsRUFBQSxLQUFBZTtFQUFBZixFQUFBLEtBQUE0QjtDQUFBO0VBQUFBLEtBQUE1QixFQUFBO0NBQUE7Q0FBekUsTUFBQTZCLHdCQUE4QnZELFNBQVNzRCxFQUFrQztDQUFFLElBQUFFO0NBQUEsSUFBQTlCLEVBQUEsT0FBQTJCLGdCQUFBO0VBQzNDRyxNQUFBQyxTQUFVQSxLQUFJQyxPQUFRTDtFQUFjM0IsRUFBQSxLQUFBMkI7RUFBQTNCLEVBQUEsS0FBQThCO0NBQUE7RUFBQUEsS0FBQTlCLEVBQUE7Q0FBQTtDQUFwRSxNQUFBaUMsZUFBcUIzQixNQUFLNEIsS0FBTUosRUFBb0M7Q0FDcEUsTUFBQUsscUJBQTJCRixjQUFZRyxXQUFaO0NBQTRCLElBQUFDO0NBQUEsSUFBQUM7Q0FBQSxJQUFBdEMsRUFBQSxPQUFBcUIsU0FBQXJCLEVBQUEsT0FBQUssTUFBQTtFQUU3Q2dDLFdBQUE7R0FDUmhCLE1BQ0VoQixPQUFBO0lBQUFkLE9BRWFjLEtBQUlkO0lBQU1DLGFBQ0phLEtBQUliLGVBQUo7SUFBc0JDLFFBQzNCWSxLQUFJWjtJQUFPQyxVQUNUVyxLQUFJWDtJQUFTQyxlQUNSVSxLQUFJa0MsYUFBZ0JQLE1BQXBCO0lBQTBCcEMsUUFDakNTLEtBQUkwQixLQUFLQztJQUFHbkMsU0FDWFEsS0FBSVIsV0FBSjtHQUVDLElBVmhCUCxhQVdGO0VBQUM7RUFDQWdELEtBQUEsQ0FBQ2pCLE9BQU9oQixJQUFJO0VBQUNMLEVBQUEsS0FBQXFCO0VBQUFyQixFQUFBLEtBQUFLO0VBQUFMLEVBQUEsTUFBQXFDO0VBQUFyQyxFQUFBLE1BQUFzQztDQUFBO0VBQUFELEtBQUFyQyxFQUFBO0VBQUFzQyxLQUFBdEMsRUFBQTtDQUFBO0NBZGhCN0IsVUFBVWtFLElBY1BDLEVBQWE7Q0FBQyxJQUFBRTtDQUFBLElBQUF4QyxFQUFBLFFBQUFrQixhQUFBbEIsRUFBQSxRQUFBdUIsWUFBQXZCLEVBQUEsUUFBQUssUUFBQUwsRUFBQSxRQUFBTSxNQUFBLElBQUEwQixJQUFBO0VBRVBRLFdBQUE7R0FDUixNQUFBQyxjQUFvQm5DLE1BQUssRUFBTyxFQUFBMEIsTUFBWjtHQUVwQixJQUFJLENBQUMzQixRQUFEb0MsZUFBQSxDQUF5QnZCLFVBQVUsUUFBUSxHQUFDO0lBQzlDSyxTQUFTLFVBQVVrQixXQUFXO0dBQUM7RUFDaEM7RUFDRnpDLEVBQUEsTUFBQWtCO0VBQUFsQixFQUFBLE1BQUF1QjtFQUFBdkIsRUFBQSxNQUFBSztFQUFBTCxFQUFBLE1BQUFNLE1BQUEsSUFBQTBCO0VBQUFoQyxFQUFBLE1BQUF3QztDQUFBO0VBQUFBLEtBQUF4QyxFQUFBO0NBQUE7Q0FBQSxJQUFBMEM7Q0FBQSxJQUFBMUMsRUFBQSxRQUFBa0IsYUFBQWxCLEVBQUEsUUFBQXVCLFlBQUF2QixFQUFBLFFBQUFLLFFBQUFMLEVBQUEsUUFBQU0sT0FBQTtFQUFFb0MsS0FBQTtHQUFDeEI7R0FBV0s7R0FBVWxCO0dBQU1DO0VBQUs7RUFBQ04sRUFBQSxNQUFBa0I7RUFBQWxCLEVBQUEsTUFBQXVCO0VBQUF2QixFQUFBLE1BQUFLO0VBQUFMLEVBQUEsTUFBQU07RUFBQU4sRUFBQSxNQUFBMEM7Q0FBQTtFQUFBQSxLQUFBMUMsRUFBQTtDQUFBO0NBTnJDN0IsVUFBVXFFLElBTVBFLEVBQWtDO0NBRXJDdkUsZ0JBQVU7RUFDUixJQUFJLENBQUMwRCx5QkFBRCxDQUEyQkksY0FBWTtHQUFBO0VBQUE7RUFJM0MsTUFBQVUsMkJBQWlDVixhQUFZRyxRQUFRUSxNQUNuREMsV0FBWUEsT0FBTWIsT0FBUUgscUJBQzVCO0VBRUEsSUFBSSxDQUFDYywwQkFBd0I7R0FDM0JwQixTQUFTLGlCQUFpQixJQUFJO0lBQUF1QixhQUNmO0lBQUlDLGdCQUNEO0dBQ2xCLENBQUM7R0FDRGpDLFlBQVksZUFBZTtFQUFDO0NBQzdCLEdBQ0E7RUFBQ0E7RUFBYWU7RUFBdUJJO0VBQWNWO0NBQVEsQ0FBQztDQUFDLElBQUF5QjtDQUFBLElBQUFoRCxFQUFBLFFBQUFjLGVBQUFkLEVBQUEsUUFBQW9CLFlBQUFwQixFQUFBLFFBQUF1QixVQUFBO0VBRWhFeUIsTUFBQSxTQUFBQyxjQUFBQyxPQUFBO0dBQ0UsTUFBQUMsZUFBcUIvQixTQUFTOEIsS0FBSztHQUFFLE9BRTlCO0lBQUEsR0FDRkM7SUFBWUMsV0FDTEMsVUFBQTtLQUNIRixhQUFZQyxTQUFVQyxLQUFLO0tBQ2hDOUIsU0FBUzJCLE9BQU9HLE1BQUtDLGNBQWNDLE9BQVE7TUFBQVQsYUFDNUI7TUFBSVUsYUFDSjtLQUNmLENBQUM7S0FDRDFDLFlBQVlvQyxLQUFLO0tBQ2pCdEMsYUFBYSxFQUFFO0lBQUM7R0FFcEI7RUFBQztFQUNGWixFQUFBLE1BQUFjO0VBQUFkLEVBQUEsTUFBQW9CO0VBQUFwQixFQUFBLE1BQUF1QjtFQUFBdkIsRUFBQSxNQUFBZ0Q7Q0FBQTtFQUFBQSxNQUFBaEQsRUFBQTtDQUFBO0NBZkQsTUFBQWlELGdCQUFBRDtDQWVDLElBQUFTO0NBQUEsSUFBQXpELEVBQUEsUUFBQWMsZUFBQWQsRUFBQSxRQUFBVSxZQUFBVixFQUFBLFFBQUFzQixVQUFBO0VBRURtQyxNQUFBLGVBQUFDLE9BQUFDLE1BQUE7R0FDRS9DLGFBQWEsRUFBRTtHQUNmRSxZQUFZO0dBQUM7R0FFYjtJQUNFLE1BQUE4QyxZQUFrQixNQUFNbEYsaUJBQWlCO0tBQUEsR0FDcENpRjtLQUFJOUQsU0FDRXJCLGlCQUFpQm1GLEtBQUk5RCxPQUFRO0lBQ3hDLENBQUM7SUFDRCxNQUFNYSxTQUFTakMsY0FBY21GLFNBQVMsQ0FBQztHQUFDLFNBQUFDLEtBQUE7SUFDakNDO0lBQ1AsSUFBSUEsZUFBZXZGLGlCQUFlO0tBQ2hDdUYsSUFBR0MsTUFBTUMsU0FBU0MsVUFBQTtNQUNoQixJQUFJQSxNQUFLQyxNQUFLO09BQ1o1QyxTQUFTMkMsTUFBS0MsTUFBNkIsRUFBQUMsU0FDaENGLE1BQUtFLFFBQ2hCLENBQUM7TUFBQztLQUNILENBQ0Y7S0FBQztJQUFBO0lBSUp2RCxhQUFhLG1DQUFtQztHQUFDO0VBQ2xEO0VBQ0ZaLEVBQUEsTUFBQWM7RUFBQWQsRUFBQSxNQUFBVTtFQUFBVixFQUFBLE1BQUFzQjtFQUFBdEIsRUFBQSxNQUFBeUQ7Q0FBQTtFQUFBQSxNQUFBekQsRUFBQTtDQUFBO0NBeEJELE1BQUEwRCxTQUFBRDtDQTJCRyxNQUFBVyxLQUFBbEY7Q0FBbUIsTUFBQTJFLE1BQUE7Q0FDakIsTUFBQVEsS0FBQWhGO0NBQ00sTUFBQWlGLE1BQUE7Q0FDTSxNQUFBQyxNQUFBO0NBQ0ssTUFBQUMsTUFBQTtDQUtULE1BQUFDLE1BQUFwRSxPQUFBO0NBQXVDLElBQUFxRTtDQUFBLElBQUExRSxFQUFBLFFBQUF5RSxLQUFBO0VBRDFDQyxNQUFBO0dBQU87YUFDSkQ7RUFDRTs7Ozs7RUFBQXpFLEVBQUEsTUFBQXlFO0VBQUF6RSxFQUFBLE1BQUEwRTtDQUFBO0VBQUFBLE1BQUExRSxFQUFBO0NBQUE7Q0FFRixNQUFBMkUsTUFBQXRFLE9BQUE7Q0FFdUMsSUFBQXVFO0NBQUEsSUFBQTVFLEVBQUEsUUFBQTJFLEtBQUE7RUFIMUNDLE1BQUEseUNBQ0dELElBR0M7Ozs7O0VBQUEzRSxFQUFBLE1BQUEyRTtFQUFBM0UsRUFBQSxNQUFBNEU7Q0FBQTtFQUFBQSxNQUFBNUUsRUFBQTtDQUFBO0NBQUEsSUFBQTZFO0NBQUEsSUFBQTdFLEVBQUEsUUFBQTBFLE9BQUExRSxFQUFBLFFBQUE0RSxLQUFBO0VBUk5DLE1BQUEsNENBQ0VILEtBR0FFLEdBS0k7Ozs7O0VBQUE1RSxFQUFBLE1BQUEwRTtFQUFBMUUsRUFBQSxNQUFBNEU7RUFBQTVFLEVBQUEsTUFBQTZFO0NBQUE7RUFBQUEsTUFBQTdFLEVBQUE7Q0FBQTtDQUFBLElBQUE4RTtDQUFBLElBQUE5RSxFQUFBLFFBQUFPLGFBQUFQLEVBQUEsUUFBQVMsU0FBQTtFQUNOcUUsTUFBQSx3QkFBQyxRQUFEO0dBQ087R0FDSTtHQUNBckU7R0FDQ0Y7YUFDWDtFQUxNOzs7OztFQU9FUCxFQUFBLE1BQUFPO0VBQUFQLEVBQUEsTUFBQVM7RUFBQVQsRUFBQSxNQUFBOEU7Q0FBQTtFQUFBQSxNQUFBOUUsRUFBQTtDQUFBO0NBQUEsSUFBQStFO0NBQUEsSUFBQS9FLEVBQUEsUUFBQTZFLE9BQUE3RSxFQUFBLFFBQUE4RSxLQUFBO0VBbEJYQyxNQUFBLHdCQUFDLGFBQUQsYUFDRUYsS0FVQUMsR0FYVTs7Ozs7RUFtQkU5RSxFQUFBLE1BQUE2RTtFQUFBN0UsRUFBQSxNQUFBOEU7RUFBQTlFLEVBQUEsTUFBQStFO0NBQUE7RUFBQUEsTUFBQS9FLEVBQUE7Q0FBQTtDQUViLE1BQUFnRixLQUFBN0Y7Q0FDRSxNQUFBOEYsS0FBQWpHO0NBQVEsSUFBQWtHO0NBQUEsSUFBQWxGLEVBQUEsUUFBQW1CLGdCQUFBbkIsRUFBQSxRQUFBMEQsUUFBQTtFQUFXd0IsTUFBQS9ELGFBQWF1QyxNQUFNO0VBQUMxRCxFQUFBLE1BQUFtQjtFQUFBbkIsRUFBQSxNQUFBMEQ7RUFBQTFELEVBQUEsTUFBQWtGO0NBQUE7RUFBQUEsTUFBQWxGLEVBQUE7Q0FBQTtDQUFBLElBQUFtRjtDQUFBLElBQUFuRixFQUFBLFFBQUFpRCxlQUFBO0VBR3BDa0MsTUFBQTtHQUErRCxHQUFwRGxDLGNBQWMsT0FBTztHQUFHO0dBQXFCO0VBQUc7Ozs7O0VBQUlqRCxFQUFBLE1BQUFpRDtFQUFBakQsRUFBQSxNQUFBbUY7Q0FBQTtFQUFBQSxNQUFBbkYsRUFBQTtDQUFBO0NBQUEsSUFBQW9GO0NBQUEsSUFBQXBGLEVBQUEsUUFBQXdCLE9BQUFqQyxPQUFBO0VBQzlENkYsTUFBQTVELE9BQU1qQyxPQUFlNEUsVUFDcEIsd0JBQUMsWUFBRDtHQUFpQjthQUFTM0MsT0FBTWpDLE1BQU00RTtFQUEzQjs7OzthQURaO0VBRU9uRSxFQUFBLE1BQUF3QixPQUFBakM7RUFBQVMsRUFBQSxNQUFBb0Y7Q0FBQTtFQUFBQSxNQUFBcEYsRUFBQTtDQUFBO0NBQUEsSUFBQXFGO0NBQUEsSUFBQXJGLEVBQUEsUUFBQW1GLE9BQUFuRixFQUFBLFFBQUFvRixLQUFBO0VBTFZDLE1BQUEsd0JBQUMsT0FBRDtHQUFPO0dBRUxGO0dBQ0NDO0VBSEc7Ozs7O0VBTUVwRixFQUFBLE1BQUFtRjtFQUFBbkYsRUFBQSxNQUFBb0Y7RUFBQXBGLEVBQUEsTUFBQXFGO0NBQUE7RUFBQUEsTUFBQXJGLEVBQUE7Q0FBQTtDQUFBLElBQUFzRjtDQUFBLElBQUF0RixFQUFBLFFBQUFpRCxlQUFBO0VBSU5xQyxNQUFBLHNDQUE4QyxHQUFoQ3JDLGNBQWMsYUFBYSxFQUFDOzs7OztFQUFJakQsRUFBQSxNQUFBaUQ7RUFBQWpELEVBQUEsTUFBQXNGO0NBQUE7RUFBQUEsTUFBQXRGLEVBQUE7Q0FBQTtDQUFBLElBQUF1RjtDQUFBLElBQUF2RixFQUFBLFFBQUF3QixPQUFBaEMsYUFBQTtFQUM3QytGLE1BQUEvRCxPQUFNaEMsYUFBcUIyRSxVQUMxQix3QkFBQyxZQUFEO0dBQWlCO2FBQVMzQyxPQUFNaEMsWUFBWTJFO0VBQWpDOzs7O2FBRFo7RUFFT25FLEVBQUEsTUFBQXdCLE9BQUFoQztFQUFBUSxFQUFBLE1BQUF1RjtDQUFBO0VBQUFBLE1BQUF2RixFQUFBO0NBQUE7Q0FBQSxJQUFBd0Y7Q0FBQSxJQUFBeEYsRUFBQSxRQUFBc0YsT0FBQXRGLEVBQUEsUUFBQXVGLEtBQUE7RUFMVkMsTUFBQSx3QkFBQyxPQUFEO0dBQU87R0FFTEY7R0FDQ0M7RUFIRzs7Ozs7RUFNRXZGLEVBQUEsTUFBQXNGO0VBQUF0RixFQUFBLE1BQUF1RjtFQUFBdkYsRUFBQSxNQUFBd0Y7Q0FBQTtFQUFBQSxNQUFBeEYsRUFBQTtDQUFBO0NBQUEsSUFBQXlGO0NBQUEsSUFBQXpGLEVBQUEsUUFBQWlELGVBQUE7RUFJTXdDLE1BQUF4QyxjQUFjLFFBQVE7RUFBQ2pELEVBQUEsTUFBQWlEO0VBQUFqRCxFQUFBLE1BQUF5RjtDQUFBO0VBQUFBLE1BQUF6RixFQUFBO0NBQUE7Q0FBQSxJQUFBMEY7Q0FBQSxJQUFBMUYsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBQ2hDc0YsTUFBQUMsT0FBTUMsUUFBU2hILFlBQVksQ0FBQyxDQUFBaUgsSUFBS0MsS0FJakM7RUFBQzlGLEVBQUEsTUFBQTBGO0NBQUE7RUFBQUEsTUFBQTFGLEVBQUE7Q0FBQTtDQUFBLElBQUErRjtDQUFBLElBQUEvRixFQUFBLFFBQUF5RixLQUFBO0VBTEpNLE1BQUE7R0FNUyxHQU5HTjthQUNUQztFQUtNOzs7OztFQUFBMUYsRUFBQSxNQUFBeUY7RUFBQXpGLEVBQUEsTUFBQStGO0NBQUE7RUFBQUEsTUFBQS9GLEVBQUE7Q0FBQTtDQUFBLElBQUFnRztDQUFBLElBQUFoRyxFQUFBLFFBQUF3QixPQUFBL0IsUUFBQTtFQUNSdUcsTUFBQXhFLE9BQU0vQixRQUFnQjBFLFVBQ3JCLHdCQUFDLFlBQUQ7R0FBaUI7YUFBUzNDLE9BQU0vQixPQUFPMEU7RUFBNUI7Ozs7YUFEWjtFQUVPbkUsRUFBQSxNQUFBd0IsT0FBQS9CO0VBQUFPLEVBQUEsTUFBQWdHO0NBQUE7RUFBQUEsTUFBQWhHLEVBQUE7Q0FBQTtDQUFBLElBQUFpRztDQUFBLElBQUFqRyxFQUFBLFFBQUErRixPQUFBL0YsRUFBQSxRQUFBZ0csS0FBQTtFQVhWQyxNQUFBLHdCQUFDLE9BQUQ7R0FBTztHQUVMRjtHQU9DQztFQVRHOzs7OztFQVlFaEcsRUFBQSxNQUFBK0Y7RUFBQS9GLEVBQUEsTUFBQWdHO0VBQUFoRyxFQUFBLE1BQUFpRztDQUFBO0VBQUFBLE1BQUFqRyxFQUFBO0NBQUE7Q0FBQSxJQUFBa0c7Q0FBQSxJQUFBbEcsRUFBQSxRQUFBaUQsZUFBQTtFQUlNaUQsTUFBQWpELGNBQWMsVUFBVTtFQUFDakQsRUFBQSxNQUFBaUQ7RUFBQWpELEVBQUEsTUFBQWtHO0NBQUE7RUFBQUEsTUFBQWxHLEVBQUE7Q0FBQTtDQUFBLElBQUFtRztDQUFBLElBQUFuRyxFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFDbEMrRixNQUFBUixPQUFNQyxRQUFTakgsY0FBYyxDQUFDLENBQUFrSCxJQUFLTyxNQUluQztFQUFDcEcsRUFBQSxNQUFBbUc7Q0FBQTtFQUFBQSxNQUFBbkcsRUFBQTtDQUFBO0NBQUEsSUFBQXFHO0NBQUEsSUFBQXJHLEVBQUEsUUFBQWtHLEtBQUE7RUFMSkcsTUFBQTtHQU1TLEdBTkdIO2FBQ1RDO0VBS007Ozs7O0VBQUFuRyxFQUFBLE1BQUFrRztFQUFBbEcsRUFBQSxNQUFBcUc7Q0FBQTtFQUFBQSxNQUFBckcsRUFBQTtDQUFBO0NBQUEsSUFBQXNHO0NBQUEsSUFBQXRHLEVBQUEsUUFBQXdCLE9BQUE5QixVQUFBO0VBQ1I0RyxNQUFBOUUsT0FBTTlCLFVBQWtCeUUsVUFDdkIsd0JBQUMsWUFBRDtHQUFpQjthQUFTM0MsT0FBTTlCLFNBQVN5RTtFQUE5Qjs7OzthQURaO0VBRU9uRSxFQUFBLE1BQUF3QixPQUFBOUI7RUFBQU0sRUFBQSxNQUFBc0c7Q0FBQTtFQUFBQSxNQUFBdEcsRUFBQTtDQUFBO0NBQUEsSUFBQXVHO0NBQUEsSUFBQXZHLEVBQUEsUUFBQXFHLE9BQUFyRyxFQUFBLFFBQUFzRyxLQUFBO0VBWFZDLE1BQUEsd0JBQUMsT0FBRDtHQUFPO0dBRUxGO0dBT0NDO0VBVEc7Ozs7O0VBWUV0RyxFQUFBLE1BQUFxRztFQUFBckcsRUFBQSxNQUFBc0c7RUFBQXRHLEVBQUEsTUFBQXVHO0NBQUE7RUFBQUEsTUFBQXZHLEVBQUE7Q0FBQTtDQUFBLElBQUF3RztDQUFBLElBQUF4RyxFQUFBLFFBQUFpRCxlQUFBO0VBSU11RCxNQUFBdkQsY0FBYyxRQUFRO0VBQUNqRCxFQUFBLE1BQUFpRDtFQUFBakQsRUFBQSxNQUFBd0c7Q0FBQTtFQUFBQSxNQUFBeEcsRUFBQTtDQUFBO0NBQUEsSUFBQXlHO0NBQUEsSUFBQXpHLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQUNqQ3FHLE1BQUE7R0FBYzthQUFHO0VBQWtCOzs7OztFQUFBekcsRUFBQSxNQUFBeUc7Q0FBQTtFQUFBQSxNQUFBekcsRUFBQTtDQUFBO0NBQUEsSUFBQTBHO0NBQUEsSUFBQTFHLEVBQUEsUUFBQU0sT0FBQTtFQUNsQ29HLE1BQUFwRyxNQUFLdUYsSUFBS2MsTUFJVjtFQUFDM0csRUFBQSxNQUFBTTtFQUFBTixFQUFBLE1BQUEwRztDQUFBO0VBQUFBLE1BQUExRyxFQUFBO0NBQUE7Q0FBQSxJQUFBNEc7Q0FBQSxJQUFBNUcsRUFBQSxRQUFBd0csT0FBQXhHLEVBQUEsUUFBQTBHLEtBQUE7RUFOSkUsTUFBQTtHQU9TLEdBUEdKO2FBQVosQ0FDRUMsS0FDQ0MsR0FLTTs7Ozs7O0VBQUExRyxFQUFBLE1BQUF3RztFQUFBeEcsRUFBQSxNQUFBMEc7RUFBQTFHLEVBQUEsTUFBQTRHO0NBQUE7RUFBQUEsTUFBQTVHLEVBQUE7Q0FBQTtDQUFBLElBQUE2RztDQUFBLElBQUE3RyxFQUFBLFFBQUF3QixPQUFBNUIsUUFBQTtFQUNSaUgsTUFBQXJGLE9BQU01QixRQUFnQnVFLFVBQ3JCLHdCQUFDLFlBQUQ7R0FBaUI7YUFBUzNDLE9BQU01QixPQUFPdUU7RUFBNUI7Ozs7YUFEWjtFQUVPbkUsRUFBQSxNQUFBd0IsT0FBQTVCO0VBQUFJLEVBQUEsTUFBQTZHO0NBQUE7RUFBQUEsTUFBQTdHLEVBQUE7Q0FBQTtDQUFBLElBQUE4RztDQUFBLElBQUE5RyxFQUFBLFFBQUE0RyxPQUFBNUcsRUFBQSxRQUFBNkcsS0FBQTtFQVpWQyxNQUFBLHdCQUFDLE9BQUQ7R0FBTztHQUVMRjtHQVFDQztFQVZHOzs7OztFQWFFN0csRUFBQSxNQUFBNEc7RUFBQTVHLEVBQUEsTUFBQTZHO0VBQUE3RyxFQUFBLE1BQUE4RztDQUFBO0VBQUFBLE1BQUE5RyxFQUFBO0NBQUE7Q0FFUCxNQUFBK0csS0FBQWpJO0NBQU0sTUFBQWtJLE1BQUE7Q0FFTCxJQUFBQztDQUFBLElBQUFqSCxFQUFBLFFBQUFpRCxlQUFBO0VBQ01nRSxNQUFBaEUsY0FBYyxlQUFlO0VBQUNqRCxFQUFBLE1BQUFpRDtFQUFBakQsRUFBQSxNQUFBaUg7Q0FBQTtFQUFBQSxNQUFBakgsRUFBQTtDQUFBO0NBQ3hCLE1BQUFrSCxNQUFBLENBQUN2RjtDQUFjLElBQUF3RjtDQUFBLElBQUFuSCxFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFFekIrRyxNQUFBO0dBQWM7YUFBRztFQUFzQjs7Ozs7RUFBQW5ILEVBQUEsTUFBQW1IO0NBQUE7RUFBQUEsTUFBQW5ILEVBQUE7Q0FBQTtDQUN0QyxNQUFBb0gsTUFBQWpGLG1CQUFrQjBELElBQUt3QixNQUl2QjtDQUFDLElBQUFDO0NBQUEsSUFBQXRILEVBQUEsUUFBQWlILE9BQUFqSCxFQUFBLFFBQUFrSCxPQUFBbEgsRUFBQSxRQUFBbUgsT0FBQW5ILEVBQUEsUUFBQW9ILEtBQUE7RUFUSkUsTUFBQTtHQVVTLEdBVEhMO0dBQ00sVUFBQUM7YUFGWixDQUlFQyxLQUNDQyxHQUtNOzs7Ozs7RUFBQXBILEVBQUEsTUFBQWlIO0VBQUFqSCxFQUFBLE1BQUFrSDtFQUFBbEgsRUFBQSxNQUFBbUg7RUFBQW5ILEVBQUEsTUFBQW9IO0VBQUFwSCxFQUFBLE9BQUFzSDtDQUFBO0VBQUFBLE1BQUF0SCxFQUFBO0NBQUE7Q0FBQSxJQUFBdUg7Q0FBQSxJQUFBdkgsRUFBQSxTQUFBd0IsT0FBQTdCLGVBQUE7RUFDUjRILE1BQUEvRixPQUFNN0IsZUFBdUJ3RSxVQUM1Qix3QkFBQyxZQUFEO0dBQWlCO2FBQVMzQyxPQUFNN0IsY0FBY3dFO0VBQW5DOzs7O2FBRFo7RUFFT25FLEVBQUEsT0FBQXdCLE9BQUE3QjtFQUFBSyxFQUFBLE9BQUF1SDtDQUFBO0VBQUFBLE1BQUF2SCxFQUFBO0NBQUE7Q0FBQSxJQUFBd0g7Q0FBQSxJQUFBeEgsRUFBQSxTQUFBK0csTUFBQS9HLEVBQUEsU0FBQXNILE9BQUF0SCxFQUFBLFNBQUF1SCxLQUFBO0VBZlZDLE1BQUEsd0JBQUMsSUFBRDtHQUFPUjtHQUVMTTtHQVdDQztFQWJHOzs7OztFQWdCRXZILEVBQUEsT0FBQStHO0VBQUEvRyxFQUFBLE9BQUFzSDtFQUFBdEgsRUFBQSxPQUFBdUg7RUFBQXZILEVBQUEsT0FBQXdIO0NBQUE7RUFBQUEsTUFBQXhILEVBQUE7Q0FBQTtDQUFBLElBQUF5SDtDQUFBLElBQUF6SCxFQUFBLFNBQUFpRCxlQUFBO0VBSU53RSxNQUFBO0dBQW1ELEdBQXhDeEUsY0FBYyxTQUFTO0dBQVE7RUFBTTs7Ozs7RUFBR2pELEVBQUEsT0FBQWlEO0VBQUFqRCxFQUFBLE9BQUF5SDtDQUFBO0VBQUFBLE1BQUF6SCxFQUFBO0NBQUE7Q0FBQSxJQUFBMEg7Q0FBQSxJQUFBMUgsRUFBQSxTQUFBd0IsT0FBQTNCLFNBQUE7RUFDbEQ2SCxNQUFBbEcsT0FBTTNCLFNBQWlCc0UsVUFDdEIsd0JBQUMsWUFBRDtHQUFpQjthQUFTM0MsT0FBTTNCLFFBQVFzRTtFQUE3Qjs7OzthQURaO0VBRU9uRSxFQUFBLE9BQUF3QixPQUFBM0I7RUFBQUcsRUFBQSxPQUFBMEg7Q0FBQTtFQUFBQSxNQUFBMUgsRUFBQTtDQUFBO0NBQUEsSUFBQTJIO0NBQUEsSUFBQTNILEVBQUEsU0FBQXlILE9BQUF6SCxFQUFBLFNBQUEwSCxLQUFBO0VBTFZDLE1BQUEsd0JBQUMsT0FBRDtHQUFpQjthQUFqQjtJQUF3QjtJQUV0QkY7SUFDQ0M7R0FIRzs7Ozs7O0VBTUUxSCxFQUFBLE9BQUF5SDtFQUFBekgsRUFBQSxPQUFBMEg7RUFBQTFILEVBQUEsT0FBQTJIO0NBQUE7RUFBQUEsTUFBQTNILEVBQUE7Q0FBQTtDQUFBLElBQUE0SDtDQUFBLElBQUE1SCxFQUFBLFNBQUFRLFlBQUFSLEVBQUEsU0FBQVcsV0FBQTtFQUVQaUgsTUFBQXBILFlBQUFHLFlBQ0Msd0JBQUMsWUFBRDtHQUFzQjtHQUFZO2FBQy9CSCxZQUFBRztFQURROzs7O2FBRFo7RUFJT1gsRUFBQSxPQUFBUTtFQUFBUixFQUFBLE9BQUFXO0VBQUFYLEVBQUEsT0FBQTRIO0NBQUE7RUFBQUEsTUFBQTVILEVBQUE7Q0FBQTtDQUFBLElBQUE2SDtDQUFBLElBQUE3SCxFQUFBLFNBQUFPLGFBQUFQLEVBQUEsU0FBQVMsU0FBQTtFQUdOb0gsTUFBQSx3QkFBQyxRQUFEO0dBQ087R0FDSTtHQUNBcEg7R0FDQ0Y7YUFDWDtFQUxNOzs7OztFQU9FUCxFQUFBLE9BQUFPO0VBQUFQLEVBQUEsT0FBQVM7RUFBQVQsRUFBQSxPQUFBNkg7Q0FBQTtFQUFBQSxNQUFBN0gsRUFBQTtDQUFBO0NBQ3VCLE1BQUE4SCxNQUFBdkgsYUFBQSxDQUFjRCxNQUFLeUg7Q0FDaEQsTUFBQUMsTUFBQXpILFlBQUE7Q0FBb0MsSUFBQTBIO0NBQUEsSUFBQWpJLEVBQUEsU0FBQThILE9BQUE5SCxFQUFBLFNBQUFnSSxLQUFBO0VBRHZDQyxNQUFBLHdCQUFDLFFBQUQ7R0FBYTtHQUFtQixVQUFBSDthQUM3QkU7RUFESTs7Ozs7RUFFRWhJLEVBQUEsT0FBQThIO0VBQUE5SCxFQUFBLE9BQUFnSTtFQUFBaEksRUFBQSxPQUFBaUk7Q0FBQTtFQUFBQSxNQUFBakksRUFBQTtDQUFBO0NBQUEsSUFBQWtJO0NBQUEsSUFBQWxJLEVBQUEsU0FBQTZILE9BQUE3SCxFQUFBLFNBQUFpSSxLQUFBO0VBWFhDLE1BQUEsd0JBQUMsY0FBRCxhQUNFTCxLQVFBSSxHQVRXOzs7OztFQVlFakksRUFBQSxPQUFBNkg7RUFBQTdILEVBQUEsT0FBQWlJO0VBQUFqSSxFQUFBLE9BQUFrSTtDQUFBO0VBQUFBLE1BQUFsSSxFQUFBO0NBQUE7Q0FBQSxJQUFBbUk7Q0FBQSxJQUFBbkksRUFBQSxTQUFBaUYsTUFBQWpGLEVBQUEsU0FBQWtGLE9BQUFsRixFQUFBLFNBQUFxRixPQUFBckYsRUFBQSxTQUFBd0YsT0FBQXhGLEVBQUEsU0FBQWlHLE9BQUFqRyxFQUFBLFNBQUF1RyxPQUFBdkcsRUFBQSxTQUFBOEcsT0FBQTlHLEVBQUEsU0FBQXdILE9BQUF4SCxFQUFBLFNBQUEySCxPQUFBM0gsRUFBQSxTQUFBNEgsT0FBQTVILEVBQUEsU0FBQWtJLEtBQUE7RUF4R2pCQyxNQUFBLHdCQUFDLElBQUQ7R0FBb0IsVUFBQWpEO2FBQXBCO0lBQ0VHO0lBUUFHO0lBUUFTO0lBY0FNO0lBY0FPO0lBZUFVO0lBa0JBRztJQVFDQztJQU1ETTtHQTVGTzs7Ozs7O0VBeUdFbEksRUFBQSxPQUFBaUY7RUFBQWpGLEVBQUEsT0FBQWtGO0VBQUFsRixFQUFBLE9BQUFxRjtFQUFBckYsRUFBQSxPQUFBd0Y7RUFBQXhGLEVBQUEsT0FBQWlHO0VBQUFqRyxFQUFBLE9BQUF1RztFQUFBdkcsRUFBQSxPQUFBOEc7RUFBQTlHLEVBQUEsT0FBQXdIO0VBQUF4SCxFQUFBLE9BQUEySDtFQUFBM0gsRUFBQSxPQUFBNEg7RUFBQTVILEVBQUEsT0FBQWtJO0VBQUFsSSxFQUFBLE9BQUFtSTtDQUFBO0VBQUFBLE1BQUFuSSxFQUFBO0NBQUE7Q0FBQSxJQUFBb0k7Q0FBQSxJQUFBcEksRUFBQSxTQUFBZ0YsTUFBQWhGLEVBQUEsU0FBQW1JLEtBQUE7RUExR2JDLE1BQUEsd0JBQUMsSUFBRCxZQUNFRCxJQURROzs7OztFQTJHRW5JLEVBQUEsT0FBQWdGO0VBQUFoRixFQUFBLE9BQUFtSTtFQUFBbkksRUFBQSxPQUFBb0k7Q0FBQTtFQUFBQSxNQUFBcEksRUFBQTtDQUFBO0NBQUEsSUFBQXFJO0NBQUEsSUFBQXJJLEVBQUEsU0FBQXFFLE1BQUFyRSxFQUFBLFNBQUErRSxPQUFBL0UsRUFBQSxTQUFBb0ksS0FBQTtFQXJJZEMsTUFBQSx3QkFBQyxJQUFEO0dBQ08sTUFBQS9EO0dBQ00sY0FBQUM7R0FDSyxtQkFBQUM7YUFIbEIsQ0FLRU8sS0FxQkFxRCxHQTFCUzs7Ozs7O0VBc0lFcEksRUFBQSxPQUFBcUU7RUFBQXJFLEVBQUEsT0FBQStFO0VBQUEvRSxFQUFBLE9BQUFvSTtFQUFBcEksRUFBQSxPQUFBcUk7Q0FBQTtFQUFBQSxNQUFBckksRUFBQTtDQUFBO0NBQUEsSUFBQXNJO0NBQUEsSUFBQXRJLEVBQUEsU0FBQW9FLE1BQUFwRSxFQUFBLFNBQUFxSSxLQUFBO0VBdklmQyxNQUFBLHdCQUFDLElBQUQ7R0FBb0IsTUFBQXpFO2FBQ2xCd0U7RUFEWTs7Ozs7RUF3SUVySSxFQUFBLE9BQUFvRTtFQUFBcEUsRUFBQSxPQUFBcUk7RUFBQXJJLEVBQUEsT0FBQXNJO0NBQUE7RUFBQUEsTUFBQXRJLEVBQUE7Q0FBQTtDQUFBLE9BeEloQnNJO0FBd0lnQjs7Ozs7Ozs7O0FBelBiLFNBQUFqQixPQUFBa0IsVUFBQTtDQUFBLE9BaU5XO0VBQStCLE9BQUExRixTQUFNYjtZQUNsQ2EsU0FBTW5CO0NBQ0EsR0FGSW1CLFNBQU1iOzs7O1FBRVY7QUFBQTtBQW5OcEIsU0FBQTJFLE9BQUE2QixRQUFBO0NBQUEsT0ErTFc7RUFBNkIsT0FBQXpHLE9BQUlDO1lBQzlCRCxPQUFJTDtDQUNFLEdBRklLLE9BQUlDOzs7O1FBRVI7QUFBQTtBQWpNcEIsU0FBQW9FLE9BQUFyRyxJQUFBO0NBK0s4QyxPQUFBTCxVQUFBK0ksV0FBQTFJO0NBQWlCLE9BQ3BEO0VBQThCTDtZQUMzQmdKO0NBQ00sR0FGSWhKOzs7O1FBRUo7QUFBQTtBQWxMcEIsU0FBQW9HLE1BQUEvRixJQUFBO0NBaUs0QyxPQUFBTixRQUFBaUosU0FBQTNJO0NBQWUsT0FDaEQ7RUFBNEJOO1lBQ3pCaUo7Q0FDTSxHQUZJako7Ozs7UUFFSjtBQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VGb3JtIiwidXNlV2F0Y2giLCJWYWxpZGF0aW9uRXJyb3IiLCJub3JtYWxpemVEdWVEYXRlIiwidG9UYXNrUmVxdWVzdCIsInZhbGlkYXRlVGFza0Zvcm0iLCJwcmlvcml0eUxhYmVscyIsInN0YXR1c0xhYmVscyIsIkJ1dHRvbiIsIkZpZWxkIiwiRmllbGRFcnJvciIsIkZvcm1HcmlkIiwiTW9kYWxBY3Rpb25zIiwiTW9kYWxCYWNrZHJvcCIsIk1vZGFsQm9keSIsIk1vZGFsSGVhZGVyIiwiTW9kYWxQYW5lbCIsImRlZmF1bHRWYWx1ZXMiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwic3RhdHVzIiwicHJpb3JpdHkiLCJyZXNwb25zaWJsZUlkIiwidGVhbUlkIiwiZHVlRGF0ZSIsIlRhc2tGb3JtTW9kYWwiLCJ0MCIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwidGFzayIsInRlYW1zIiwiaXNMb2FkaW5nIiwiYXBpRXJyb3IiLCJvbkNsb3NlIiwib25TdWJtaXQiLCJmb3JtRXJyb3IiLCJzZXRGb3JtRXJyb3IiLCJ0MSIsImNsZWFyRXJyb3JzIiwiY29udHJvbCIsImZvcm1TdGF0ZSIsInQyIiwiZ2V0VmFsdWVzIiwiaGFuZGxlU3VibWl0IiwicmVnaXN0ZXIiLCJyZXNldCIsInNldEVycm9yIiwic2V0VmFsdWUiLCJlcnJvcnMiLCJ0MyIsIm5hbWUiLCJzZWxlY3RlZFRlYW1JZCIsInQ0Iiwic2VsZWN0ZWRSZXNwb25zaWJsZUlkIiwidDUiLCJ0ZWFtIiwiaWQiLCJzZWxlY3RlZFRlYW0iLCJmaW5kIiwicmVzcG9uc2libGVPcHRpb25zIiwibWVtYmVycyIsInQ2IiwidDciLCJyZXNwb25zaWJsZSIsInQ4IiwiZmlyc3RUZWFtSWQiLCJ0OSIsInJlc3BvbnNpYmxlQmVsb25nc1RvVGVhbSIsInNvbWUiLCJtZW1iZXIiLCJzaG91bGREaXJ0eSIsInNob3VsZFZhbGlkYXRlIiwidDEwIiwicmVnaXN0ZXJGaWVsZCIsImZpZWxkIiwicmVnaXN0cmF0aW9uIiwib25DaGFuZ2UiLCJldmVudCIsImN1cnJlbnRUYXJnZXQiLCJ2YWx1ZSIsInNob3VsZFRvdWNoIiwidDExIiwic3VibWl0IiwiZGF0YSIsInZhbGlkRGF0YSIsInQxMiIsImVyciIsImlubmVyIiwiZm9yRWFjaCIsImlzc3VlIiwicGF0aCIsIm1lc3NhZ2UiLCJUMCIsIlQxIiwidDEzIiwidDE0IiwidDE1IiwidDE2IiwidDE3IiwidDE4IiwidDE5IiwidDIwIiwidDIxIiwidDIyIiwiVDIiLCJUMyIsInQyMyIsInQyNCIsInQyNSIsInQyNiIsInQyNyIsInQyOCIsInQyOSIsInQzMCIsInQzMSIsIk9iamVjdCIsImVudHJpZXMiLCJtYXAiLCJfdGVtcCIsInQzMiIsInQzMyIsInQzNCIsInQzNSIsInQzNiIsIl90ZW1wMiIsInQzNyIsInQzOCIsInQzOSIsInQ0MCIsInQ0MSIsInQ0MiIsIl90ZW1wMyIsInQ0MyIsInQ0NCIsInQ0NSIsIlQ0IiwidDQ2IiwidDQ3IiwidDQ4IiwidDQ5IiwidDUwIiwiX3RlbXA0IiwidDUxIiwidDUyIiwidDUzIiwidDU0IiwidDU1IiwidDU2IiwidDU3IiwidDU4IiwidDU5IiwibGVuZ3RoIiwidDYwIiwidDYxIiwidDYyIiwidDYzIiwidDY0IiwidDY1IiwidDY2IiwibWVtYmVyXzAiLCJ0ZWFtXzAiLCJsYWJlbF8wIiwibGFiZWwiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVGFza0Zvcm1Nb2RhbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdHlwZSBDaGFuZ2VFdmVudCwgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlRm9ybSwgdXNlV2F0Y2ggfSBmcm9tIFwicmVhY3QtaG9vay1mb3JtXCI7XHJcbmltcG9ydCB7IFZhbGlkYXRpb25FcnJvciB9IGZyb20gXCJ5dXBcIjtcclxuaW1wb3J0IHR5cGUgeyBUYXNrIH0gZnJvbSBcIi4uLy4uL2ludGVyZmFjZXMvdGFza3MvdGFza1wiO1xyXG5pbXBvcnQgdHlwZSB7IFRlYW0gfSBmcm9tIFwiLi4vLi4vaW50ZXJmYWNlcy90YXNrcy90ZWFtXCI7XHJcbmltcG9ydCB0eXBlIHsgVGFza0Zvcm1EYXRhIH0gZnJvbSBcIi4uLy4uL3ZhbGlkYXRpb25zL3Rhc2tzL3Rhc2tTY2hlbWFcIjtcclxuaW1wb3J0IHtcclxuICBub3JtYWxpemVEdWVEYXRlLFxyXG4gIHRvVGFza1JlcXVlc3QsXHJcbiAgdmFsaWRhdGVUYXNrRm9ybSxcclxufSBmcm9tIFwiLi4vLi4vdmFsaWRhdGlvbnMvdGFza3MvdGFza1NjaGVtYVwiO1xyXG5pbXBvcnQgeyBwcmlvcml0eUxhYmVscywgc3RhdHVzTGFiZWxzIH0gZnJvbSBcIi4vbGFiZWxzXCI7XHJcbmltcG9ydCB7XHJcbiAgQnV0dG9uLFxyXG4gIEZpZWxkLFxyXG4gIEZpZWxkRXJyb3IsXHJcbiAgRm9ybUdyaWQsXHJcbiAgTW9kYWxBY3Rpb25zLFxyXG4gIE1vZGFsQmFja2Ryb3AsXHJcbiAgTW9kYWxCb2R5LFxyXG4gIE1vZGFsSGVhZGVyLFxyXG4gIE1vZGFsUGFuZWwsXHJcbn0gZnJvbSBcIi4vc3R5bGVzXCI7XHJcblxyXG50eXBlIFRhc2tGb3JtTW9kYWxQcm9wcyA9IHtcclxuICB0YXNrPzogVGFzayB8IG51bGw7XHJcbiAgdGVhbXM6IFRlYW1bXTtcclxuICBpc0xvYWRpbmc/OiBib29sZWFuO1xyXG4gIGFwaUVycm9yPzogc3RyaW5nO1xyXG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XHJcbiAgb25TdWJtaXQ6IChkYXRhOiBSZXR1cm5UeXBlPHR5cGVvZiB0b1Rhc2tSZXF1ZXN0PikgPT4gUHJvbWlzZTx2b2lkPjtcclxufTtcclxuXHJcbmNvbnN0IGRlZmF1bHRWYWx1ZXM6IFRhc2tGb3JtRGF0YSA9IHtcbiAgdGl0bGU6IFwiXCIsXHJcbiAgZGVzY3JpcHRpb246IFwiXCIsXHJcbiAgc3RhdHVzOiBcIlRPRE9cIixcclxuICBwcmlvcml0eTogXCJNRURJVU1cIixcclxuICByZXNwb25zaWJsZUlkOiBcIlwiLFxyXG4gIHRlYW1JZDogXCJcIixcclxuICBkdWVEYXRlOiBcIlwiLFxufTtcblxudHlwZSBUYXNrRmllbGRFbGVtZW50ID1cbiAgfCBIVE1MSW5wdXRFbGVtZW50XG4gIHwgSFRNTFNlbGVjdEVsZW1lbnRcbiAgfCBIVE1MVGV4dEFyZWFFbGVtZW50O1xuXG5leHBvcnQgZnVuY3Rpb24gVGFza0Zvcm1Nb2RhbCh7XG4gIHRhc2ssXHJcbiAgdGVhbXMsXHJcbiAgaXNMb2FkaW5nLFxyXG4gIGFwaUVycm9yLFxyXG4gIG9uQ2xvc2UsXHJcbiAgb25TdWJtaXQsXHJcbn06IFRhc2tGb3JtTW9kYWxQcm9wcykge1xyXG4gIGNvbnN0IFtmb3JtRXJyb3IsIHNldEZvcm1FcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCB7XHJcbiAgICBjbGVhckVycm9ycyxcclxuICAgIGNvbnRyb2wsXHJcbiAgICBmb3JtU3RhdGU6IHsgZXJyb3JzIH0sXHJcbiAgICBnZXRWYWx1ZXMsXHJcbiAgICBoYW5kbGVTdWJtaXQsXHJcbiAgICByZWdpc3RlcixcclxuICAgIHJlc2V0LFxyXG4gICAgc2V0RXJyb3IsXHJcbiAgICBzZXRWYWx1ZSxcclxuICB9ID0gdXNlRm9ybTxUYXNrRm9ybURhdGE+KHtcclxuICAgIGRlZmF1bHRWYWx1ZXMsXHJcbiAgfSk7XHJcbiAgY29uc3Qgc2VsZWN0ZWRUZWFtSWQgPSB1c2VXYXRjaCh7IGNvbnRyb2wsIG5hbWU6IFwidGVhbUlkXCIgfSk7XHJcbiAgY29uc3Qgc2VsZWN0ZWRSZXNwb25zaWJsZUlkID0gdXNlV2F0Y2goeyBjb250cm9sLCBuYW1lOiBcInJlc3BvbnNpYmxlSWRcIiB9KTtcclxuICBjb25zdCBzZWxlY3RlZFRlYW0gPSB0ZWFtcy5maW5kKCh0ZWFtKSA9PiB0ZWFtLmlkID09PSBzZWxlY3RlZFRlYW1JZCk7XHJcbiAgY29uc3QgcmVzcG9uc2libGVPcHRpb25zID0gc2VsZWN0ZWRUZWFtPy5tZW1iZXJzID8/IFtdO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgcmVzZXQoXHJcbiAgICAgIHRhc2tcclxuICAgICAgICA/IHtcclxuICAgICAgICAgICAgdGl0bGU6IHRhc2sudGl0bGUsXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiB0YXNrLmRlc2NyaXB0aW9uID8/IFwiXCIsXHJcbiAgICAgICAgICAgIHN0YXR1czogdGFzay5zdGF0dXMsXHJcbiAgICAgICAgICAgIHByaW9yaXR5OiB0YXNrLnByaW9yaXR5LFxyXG4gICAgICAgICAgICByZXNwb25zaWJsZUlkOiB0YXNrLnJlc3BvbnNpYmxlPy5pZCA/PyBcIlwiLFxyXG4gICAgICAgICAgICB0ZWFtSWQ6IHRhc2sudGVhbS5pZCxcclxuICAgICAgICAgICAgZHVlRGF0ZTogdGFzay5kdWVEYXRlID8/IFwiXCIsXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgOiBkZWZhdWx0VmFsdWVzLFxyXG4gICAgKTtcclxuICB9LCBbcmVzZXQsIHRhc2tdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZpcnN0VGVhbUlkID0gdGVhbXNbMF0/LmlkID8/IFwiXCI7XHJcblxyXG4gICAgaWYgKCF0YXNrICYmIGZpcnN0VGVhbUlkICYmICFnZXRWYWx1ZXMoXCJ0ZWFtSWRcIikpIHtcclxuICAgICAgc2V0VmFsdWUoXCJ0ZWFtSWRcIiwgZmlyc3RUZWFtSWQpO1xyXG4gICAgfVxyXG4gIH0sIFtnZXRWYWx1ZXMsIHNldFZhbHVlLCB0YXNrLCB0ZWFtc10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFzZWxlY3RlZFJlc3BvbnNpYmxlSWQgfHwgIXNlbGVjdGVkVGVhbSkge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgcmVzcG9uc2libGVCZWxvbmdzVG9UZWFtID0gc2VsZWN0ZWRUZWFtLm1lbWJlcnMuc29tZShcclxuICAgICAgKG1lbWJlcikgPT4gbWVtYmVyLmlkID09PSBzZWxlY3RlZFJlc3BvbnNpYmxlSWQsXHJcbiAgICApO1xyXG5cclxuICAgIGlmICghcmVzcG9uc2libGVCZWxvbmdzVG9UZWFtKSB7XHJcbiAgICAgIHNldFZhbHVlKFwicmVzcG9uc2libGVJZFwiLCBcIlwiLCB7XHJcbiAgICAgICAgc2hvdWxkRGlydHk6IHRydWUsXHJcbiAgICAgICAgc2hvdWxkVmFsaWRhdGU6IHRydWUsXHJcbiAgICAgIH0pO1xyXG4gICAgICBjbGVhckVycm9ycyhcInJlc3BvbnNpYmxlSWRcIik7XHJcbiAgICB9XHJcbiAgfSwgW2NsZWFyRXJyb3JzLCBzZWxlY3RlZFJlc3BvbnNpYmxlSWQsIHNlbGVjdGVkVGVhbSwgc2V0VmFsdWVdKTtcblxuICBmdW5jdGlvbiByZWdpc3RlckZpZWxkKGZpZWxkOiBrZXlvZiBUYXNrRm9ybURhdGEpIHtcbiAgICBjb25zdCByZWdpc3RyYXRpb24gPSByZWdpc3RlcihmaWVsZCk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgLi4ucmVnaXN0cmF0aW9uLFxuICAgICAgb25DaGFuZ2U6IChldmVudDogQ2hhbmdlRXZlbnQ8VGFza0ZpZWxkRWxlbWVudD4pID0+IHtcbiAgICAgICAgdm9pZCByZWdpc3RyYXRpb24ub25DaGFuZ2UoZXZlbnQpO1xuICAgICAgICBzZXRWYWx1ZShmaWVsZCwgZXZlbnQuY3VycmVudFRhcmdldC52YWx1ZSwge1xuICAgICAgICAgIHNob3VsZERpcnR5OiB0cnVlLFxuICAgICAgICAgIHNob3VsZFRvdWNoOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgY2xlYXJFcnJvcnMoZmllbGQpO1xuICAgICAgICBzZXRGb3JtRXJyb3IoXCJcIik7XG4gICAgICB9LFxuICAgIH07XG4gIH1cblxyXG4gIGFzeW5jIGZ1bmN0aW9uIHN1Ym1pdChkYXRhOiBUYXNrRm9ybURhdGEpIHtcclxuICAgIHNldEZvcm1FcnJvcihcIlwiKTtcclxuICAgIGNsZWFyRXJyb3JzKCk7XHJcblxyXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHZhbGlkRGF0YSA9IGF3YWl0IHZhbGlkYXRlVGFza0Zvcm0oe1xyXG4gICAgICAgIC4uLmRhdGEsXHJcbiAgICAgICAgZHVlRGF0ZTogbm9ybWFsaXplRHVlRGF0ZShkYXRhLmR1ZURhdGUpLFxyXG4gICAgICB9KTtcclxuICAgICAgYXdhaXQgb25TdWJtaXQodG9UYXNrUmVxdWVzdCh2YWxpZERhdGEpKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBpZiAoZXJyIGluc3RhbmNlb2YgVmFsaWRhdGlvbkVycm9yKSB7XHJcbiAgICAgICAgZXJyLmlubmVyLmZvckVhY2goKGlzc3VlKSA9PiB7XHJcbiAgICAgICAgICBpZiAoaXNzdWUucGF0aCkge1xyXG4gICAgICAgICAgICBzZXRFcnJvcihpc3N1ZS5wYXRoIGFzIGtleW9mIFRhc2tGb3JtRGF0YSwge1xyXG4gICAgICAgICAgICAgIG1lc3NhZ2U6IGlzc3VlLm1lc3NhZ2UsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG5cclxuICAgICAgc2V0Rm9ybUVycm9yKFwiTmFvIGZvaSBwb3NzaXZlbCBzYWx2YXIgYSB0YXJlZmEuXCIpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxNb2RhbEJhY2tkcm9wIHJvbGU9XCJwcmVzZW50YXRpb25cIj5cclxuICAgICAgPE1vZGFsUGFuZWxcclxuICAgICAgICByb2xlPVwiZGlhbG9nXCJcclxuICAgICAgICBhcmlhLW1vZGFsPVwidHJ1ZVwiXHJcbiAgICAgICAgYXJpYS1sYWJlbGxlZGJ5PVwidGFzay1mb3JtLXRpdGxlXCJcclxuICAgICAgPlxyXG4gICAgICAgIDxNb2RhbEhlYWRlcj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxoMiBpZD1cInRhc2stZm9ybS10aXRsZVwiPlxyXG4gICAgICAgICAgICAgIHt0YXNrID8gXCJFZGl0YXIgdGFyZWZhXCIgOiBcIkNyaWFyIHRhcmVmYVwifVxyXG4gICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICA8cD5cclxuICAgICAgICAgICAgICB7dGFza1xyXG4gICAgICAgICAgICAgICAgPyBcIkF0dWFsaXplIG9zIGRhZG9zIGRhIGRlbWFuZGEuXCJcclxuICAgICAgICAgICAgICAgIDogXCJDYWRhc3RyZSB1bWEgbm92YSBkZW1hbmRhIGRvIHRpbWUuXCJ9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgJHZhcmlhbnQ9XCJnaG9zdFwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIEZlY2hhclxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9Nb2RhbEhlYWRlcj5cclxuXHJcbiAgICAgICAgPE1vZGFsQm9keT5cclxuICAgICAgICAgIDxGb3JtR3JpZCBvblN1Ym1pdD17aGFuZGxlU3VibWl0KHN1Ym1pdCl9PlxyXG4gICAgICAgICAgICA8RmllbGQ+XHJcbiAgICAgICAgICAgICAgVGl0dWxvXHJcbiAgICAgICAgICAgICAgPGlucHV0IHsuLi5yZWdpc3RlckZpZWxkKFwidGl0bGVcIil9IGF1dG9Gb2N1cyBtYXhMZW5ndGg9ezE2MH0gLz5cclxuICAgICAgICAgICAgICB7ZXJyb3JzLnRpdGxlPy5tZXNzYWdlID8gKFxyXG4gICAgICAgICAgICAgICAgPEZpZWxkRXJyb3Igcm9sZT1cImFsZXJ0XCI+e2Vycm9ycy50aXRsZS5tZXNzYWdlfTwvRmllbGRFcnJvcj5cbiAgICAgICAgICAgICAgKSA6IG51bGx9XHJcbiAgICAgICAgICAgIDwvRmllbGQ+XHJcblxyXG4gICAgICAgICAgICA8RmllbGQ+XHJcbiAgICAgICAgICAgICAgRGVzY3JpY2FvXHJcbiAgICAgICAgICAgICAgPHRleHRhcmVhIHsuLi5yZWdpc3RlckZpZWxkKFwiZGVzY3JpcHRpb25cIil9IC8+XHJcbiAgICAgICAgICAgICAge2Vycm9ycy5kZXNjcmlwdGlvbj8ubWVzc2FnZSA/IChcclxuICAgICAgICAgICAgICAgIDxGaWVsZEVycm9yIHJvbGU9XCJhbGVydFwiPntlcnJvcnMuZGVzY3JpcHRpb24ubWVzc2FnZX08L0ZpZWxkRXJyb3I+XG4gICAgICAgICAgICAgICkgOiBudWxsfVxyXG4gICAgICAgICAgICA8L0ZpZWxkPlxyXG5cclxuICAgICAgICAgICAgPEZpZWxkPlxyXG4gICAgICAgICAgICAgIFN0YXR1c1xyXG4gICAgICAgICAgICAgIDxzZWxlY3Qgey4uLnJlZ2lzdGVyRmllbGQoXCJzdGF0dXNcIil9PlxyXG4gICAgICAgICAgICAgICAge09iamVjdC5lbnRyaWVzKHN0YXR1c0xhYmVscykubWFwKChbc3RhdHVzLCBsYWJlbF0pID0+IChcclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3N0YXR1c30gdmFsdWU9e3N0YXR1c30+XHJcbiAgICAgICAgICAgICAgICAgICAge2xhYmVsfVxyXG4gICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgIHtlcnJvcnMuc3RhdHVzPy5tZXNzYWdlID8gKFxyXG4gICAgICAgICAgICAgICAgPEZpZWxkRXJyb3Igcm9sZT1cImFsZXJ0XCI+e2Vycm9ycy5zdGF0dXMubWVzc2FnZX08L0ZpZWxkRXJyb3I+XG4gICAgICAgICAgICAgICkgOiBudWxsfVxyXG4gICAgICAgICAgICA8L0ZpZWxkPlxyXG5cclxuICAgICAgICAgICAgPEZpZWxkPlxyXG4gICAgICAgICAgICAgIFByaW9yaWRhZGVcclxuICAgICAgICAgICAgICA8c2VsZWN0IHsuLi5yZWdpc3RlckZpZWxkKFwicHJpb3JpdHlcIil9PlxyXG4gICAgICAgICAgICAgICAge09iamVjdC5lbnRyaWVzKHByaW9yaXR5TGFiZWxzKS5tYXAoKFtwcmlvcml0eSwgbGFiZWxdKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtwcmlvcml0eX0gdmFsdWU9e3ByaW9yaXR5fT5cclxuICAgICAgICAgICAgICAgICAgICB7bGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAge2Vycm9ycy5wcmlvcml0eT8ubWVzc2FnZSA/IChcclxuICAgICAgICAgICAgICAgIDxGaWVsZEVycm9yIHJvbGU9XCJhbGVydFwiPntlcnJvcnMucHJpb3JpdHkubWVzc2FnZX08L0ZpZWxkRXJyb3I+XG4gICAgICAgICAgICAgICkgOiBudWxsfVxyXG4gICAgICAgICAgICA8L0ZpZWxkPlxyXG5cclxuICAgICAgICAgICAgPEZpZWxkPlxyXG4gICAgICAgICAgICAgIFRpbWVcclxuICAgICAgICAgICAgICA8c2VsZWN0IHsuLi5yZWdpc3RlckZpZWxkKFwidGVhbUlkXCIpfT5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY2lvbmU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIHt0ZWFtcy5tYXAoKHRlYW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3RlYW0uaWR9IHZhbHVlPXt0ZWFtLmlkfT5cclxuICAgICAgICAgICAgICAgICAgICB7dGVhbS5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgIHtlcnJvcnMudGVhbUlkPy5tZXNzYWdlID8gKFxyXG4gICAgICAgICAgICAgICAgPEZpZWxkRXJyb3Igcm9sZT1cImFsZXJ0XCI+e2Vycm9ycy50ZWFtSWQubWVzc2FnZX08L0ZpZWxkRXJyb3I+XG4gICAgICAgICAgICAgICkgOiBudWxsfVxyXG4gICAgICAgICAgICA8L0ZpZWxkPlxyXG5cclxuICAgICAgICAgICAgPEZpZWxkPlxyXG4gICAgICAgICAgICAgIFJlc3BvbnNhdmVsXHJcbiAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyRmllbGQoXCJyZXNwb25zaWJsZUlkXCIpfVxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFzZWxlY3RlZFRlYW1JZH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+TmFvIGF0cmlidWlkbzwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAge3Jlc3BvbnNpYmxlT3B0aW9ucy5tYXAoKG1lbWJlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17bWVtYmVyLmlkfSB2YWx1ZT17bWVtYmVyLmlkfT5cclxuICAgICAgICAgICAgICAgICAgICB7bWVtYmVyLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAge2Vycm9ycy5yZXNwb25zaWJsZUlkPy5tZXNzYWdlID8gKFxyXG4gICAgICAgICAgICAgICAgPEZpZWxkRXJyb3Igcm9sZT1cImFsZXJ0XCI+e2Vycm9ycy5yZXNwb25zaWJsZUlkLm1lc3NhZ2V9PC9GaWVsZEVycm9yPlxuICAgICAgICAgICAgICApIDogbnVsbH1cclxuICAgICAgICAgICAgPC9GaWVsZD5cclxuXHJcbiAgICAgICAgICAgIDxGaWVsZCBjbGFzc05hbWU9XCJmdWxsXCI+XHJcbiAgICAgICAgICAgICAgUHJhem9cclxuICAgICAgICAgICAgICA8aW5wdXQgey4uLnJlZ2lzdGVyRmllbGQoXCJkdWVEYXRlXCIpfSB0eXBlPVwiZGF0ZVwiIC8+XHJcbiAgICAgICAgICAgICAge2Vycm9ycy5kdWVEYXRlPy5tZXNzYWdlID8gKFxyXG4gICAgICAgICAgICAgICAgPEZpZWxkRXJyb3Igcm9sZT1cImFsZXJ0XCI+e2Vycm9ycy5kdWVEYXRlLm1lc3NhZ2V9PC9GaWVsZEVycm9yPlxuICAgICAgICAgICAgICApIDogbnVsbH1cclxuICAgICAgICAgICAgPC9GaWVsZD5cclxuXHJcbiAgICAgICAgICAgIHthcGlFcnJvciB8fCBmb3JtRXJyb3IgPyAoXHJcbiAgICAgICAgICAgICAgPEZpZWxkRXJyb3IgY2xhc3NOYW1lPVwiZnVsbFwiIHJvbGU9XCJhbGVydFwiPlxuICAgICAgICAgICAgICAgIHthcGlFcnJvciB8fCBmb3JtRXJyb3J9XG4gICAgICAgICAgICAgIDwvRmllbGRFcnJvcj5cbiAgICAgICAgICAgICkgOiBudWxsfVxyXG5cclxuICAgICAgICAgICAgPE1vZGFsQWN0aW9ucz5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICR2YXJpYW50PVwiZ2hvc3RcIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ2FuY2VsYXJcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17aXNMb2FkaW5nIHx8ICF0ZWFtcy5sZW5ndGh9PlxyXG4gICAgICAgICAgICAgICAge2lzTG9hZGluZyA/IFwiU2FsdmFuZG8uLi5cIiA6IFwiU2FsdmFyXCJ9XHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvTW9kYWxBY3Rpb25zPlxyXG4gICAgICAgICAgPC9Gb3JtR3JpZD5cclxuICAgICAgICA8L01vZGFsQm9keT5cclxuICAgICAgPC9Nb2RhbFBhbmVsPlxyXG4gICAgPC9Nb2RhbEJhY2tkcm9wPlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy93YWxsYS9EZXNrdG9wL1Byb2pldG9zLXBlc3NvYWlzL3Byb3ZhLXRlY25pY2EvZnJvbnQtbWluaS10YXNrLW1hbmFnZXIvc3JjL2NvbXBvbmVudHMvdGFza3MvVGFza0Zvcm1Nb2RhbC50c3gifQ==