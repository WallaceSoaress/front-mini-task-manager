import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/public/Login/index.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=df6b4f96";
import { useAuth } from "/src/hooks/auth.tsx";
import { ApiRequestError } from "/src/services/api.ts";
import { ErrorMessage, Field, Form, HeaderGroup, LoginPanel, PageShell } from "/src/pages/public/Login/styles.ts";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/public/Login/index.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=df6b4f96";
var _s = $RefreshSig$();
const Login = () => {
	_s();
	const { signIn } = useAuth();
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [error, setError] = useState("");
	const [isSubmitting, setIsSubmitting] = useState(false);
	async function handleSubmit(event) {
		event.preventDefault();
		setError("");
		setIsSubmitting(true);
		try {
			await signIn({
				email,
				password
			});
		} catch (err) {
			const message = err instanceof ApiRequestError ? err.message : "Nao foi possivel realizar o login.";
			setError(message);
		} finally {
			setIsSubmitting(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV(PageShell, { children: /* @__PURE__ */ _jsxDEV(LoginPanel, { children: [/* @__PURE__ */ _jsxDEV(HeaderGroup, { children: /* @__PURE__ */ _jsxDEV("span", { children: "Mini Task Manager" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 33,
		columnNumber: 11
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 32,
		columnNumber: 9
	}, this), /* @__PURE__ */ _jsxDEV(Form, {
		onSubmit: handleSubmit,
		children: [
			/* @__PURE__ */ _jsxDEV(Field, { children: [/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "email",
				children: "E-mail"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 38,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("input", {
				id: "email",
				name: "email",
				type: "email",
				autoComplete: "email",
				value: email,
				onChange: (event_0) => setEmail(event_0.target.value),
				required: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV(Field, { children: [/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "password",
				children: "Senha"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("input", {
				id: "password",
				name: "password",
				type: "password",
				autoComplete: "current-password",
				value: password,
				onChange: (event_1) => setPassword(event_1.target.value),
				required: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 11
			}, this),
			error ? /* @__PURE__ */ _jsxDEV(ErrorMessage, {
				role: "alert",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 20
			}, this) : null,
			/* @__PURE__ */ _jsxDEV("button", {
				type: "submit",
				disabled: isSubmitting,
				children: isSubmitting ? "Entrando..." : "Entrar"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 11
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 36,
		columnNumber: 9
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 30,
		columnNumber: 10
	}, this);
};
_s(Login, "q2FaYeVAogikxggBaIlce61oWFY=", false, function() {
	return [useAuth];
});
_c = Login;
export default Login;
var _c;
$RefreshReg$(_c, "Login");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/public/Login/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/public/Login/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/public/Login/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/public/Login/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsU0FBU0EsZ0JBQWdCO0FBRXpCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQ0VDLGNBQ0FDLE9BQ0FDLE1BQ0FDLGFBQ0FDLFlBQ0FDLGlCQUNLOzs7O0FBRVAsTUFBTUMsY0FBYzs7Q0FDbEIsTUFBTSxFQUFFQyxXQUFXVCxRQUFRO0NBQzNCLE1BQU0sQ0FBQ1UsT0FBT0MsWUFBWVosU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQ2EsVUFBVUMsZUFBZWQsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQ2UsT0FBT0MsWUFBWWhCLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUNpQixjQUFjQyxtQkFBbUJsQixTQUFTLEtBQUs7Q0FFdEQsZUFBZW1CLGFBQWFDLE9BQW1DO0VBQzdEQSxNQUFNQyxlQUFlO0VBQ3JCTCxTQUFTLEVBQUU7RUFDWEUsZ0JBQWdCLElBQUk7RUFFcEIsSUFBSTtHQUNGLE1BQU1SLE9BQU87SUFBRUM7SUFBT0U7R0FBUyxDQUFDO0VBQ2xDLFNBQVNTLEtBQUs7R0FDWixNQUFNQyxVQUNKRCxlQUFlcEIsa0JBQ1hvQixJQUFJQyxVQUNKO0dBQ05QLFNBQVNPLE9BQU87RUFDbEIsVUFBVTtHQUNSTCxnQkFBZ0IsS0FBSztFQUN2QjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxXQUFELFlBQ0Usd0JBQUMsWUFBRCxhQUNFLHdCQUFDLGFBQUQsWUFDRSx3QkFBQyxRQUFELFlBQU0sb0JBQXVCOzs7O1VBQ2xCOzs7O1dBRWIsd0JBQUMsTUFBRDtFQUFNLFVBQVVDO1lBQWhCO0dBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7SUFBTyxTQUFRO2NBQVE7R0FBYTs7OzthQUNwQyx3QkFBQyxTQUFEO0lBQ0UsSUFBRztJQUNILE1BQUs7SUFDTCxNQUFLO0lBQ0wsY0FBYTtJQUNiLE9BQU9SO0lBQ1AsV0FBV1MsWUFBVVIsU0FBU1EsUUFBTUksT0FBT0MsS0FBSztJQUNoRDtHQUFROzs7O1dBRUw7Ozs7O0dBRVAsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7SUFBTyxTQUFRO2NBQVc7R0FBWTs7OzthQUN0Qyx3QkFBQyxTQUFEO0lBQ0UsSUFBRztJQUNILE1BQUs7SUFDTCxNQUFLO0lBQ0wsY0FBYTtJQUNiLE9BQU9aO0lBQ1AsV0FBV08sWUFBVU4sWUFBWU0sUUFBTUksT0FBT0MsS0FBSztJQUNuRDtHQUFROzs7O1dBRUw7Ozs7O0dBRU5WLFFBQVEsd0JBQUMsY0FBRDtJQUFjLE1BQUs7Y0FBU0E7R0FBb0I7Ozs7Y0FBSTtHQUU3RCx3QkFBQyxVQUFEO0lBQVEsTUFBSztJQUFTLFVBQVVFO2NBQzdCQSxlQUFlLGdCQUFnQjtHQUMxQjs7Ozs7RUFDSjs7Ozs7U0FDSTs7OztVQUNIOzs7OztBQUVmOzs7OztBQUVBLGVBQWVSIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VBdXRoIiwiQXBpUmVxdWVzdEVycm9yIiwiRXJyb3JNZXNzYWdlIiwiRmllbGQiLCJGb3JtIiwiSGVhZGVyR3JvdXAiLCJMb2dpblBhbmVsIiwiUGFnZVNoZWxsIiwiTG9naW4iLCJzaWduSW4iLCJlbWFpbCIsInNldEVtYWlsIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsImVycm9yIiwic2V0RXJyb3IiLCJpc1N1Ym1pdHRpbmciLCJzZXRJc1N1Ym1pdHRpbmciLCJoYW5kbGVTdWJtaXQiLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwiZXJyIiwibWVzc2FnZSIsInRhcmdldCIsInZhbHVlIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHR5cGUgeyBGb3JtRXZlbnQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vLi4vLi4vaG9va3MvYXV0aFwiO1xuaW1wb3J0IHsgQXBpUmVxdWVzdEVycm9yIH0gZnJvbSBcIi4uLy4uLy4uL3NlcnZpY2VzL2FwaVwiO1xuaW1wb3J0IHtcbiAgRXJyb3JNZXNzYWdlLFxuICBGaWVsZCxcbiAgRm9ybSxcbiAgSGVhZGVyR3JvdXAsXG4gIExvZ2luUGFuZWwsXG4gIFBhZ2VTaGVsbCxcbn0gZnJvbSBcIi4vc3R5bGVzXCI7XG5cbmNvbnN0IExvZ2luID0gKCkgPT4ge1xuICBjb25zdCB7IHNpZ25JbiB9ID0gdXNlQXV0aCgpO1xuICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbaXNTdWJtaXR0aW5nLCBzZXRJc1N1Ym1pdHRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChldmVudDogRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD4pIHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIHNldEVycm9yKFwiXCIpO1xuICAgIHNldElzU3VibWl0dGluZyh0cnVlKTtcblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCBzaWduSW4oeyBlbWFpbCwgcGFzc3dvcmQgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zdCBtZXNzYWdlID1cbiAgICAgICAgZXJyIGluc3RhbmNlb2YgQXBpUmVxdWVzdEVycm9yXG4gICAgICAgICAgPyBlcnIubWVzc2FnZVxuICAgICAgICAgIDogXCJOYW8gZm9pIHBvc3NpdmVsIHJlYWxpemFyIG8gbG9naW4uXCI7XG4gICAgICBzZXRFcnJvcihtZXNzYWdlKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNTdWJtaXR0aW5nKGZhbHNlKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxQYWdlU2hlbGw+XG4gICAgICA8TG9naW5QYW5lbD5cbiAgICAgICAgPEhlYWRlckdyb3VwPlxuICAgICAgICAgIDxzcGFuPk1pbmkgVGFzayBNYW5hZ2VyPC9zcGFuPlxuICAgICAgICA8L0hlYWRlckdyb3VwPlxuXG4gICAgICAgIDxGb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxuICAgICAgICAgIDxGaWVsZD5cbiAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiZW1haWxcIj5FLW1haWw8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIGlkPVwiZW1haWxcIlxuICAgICAgICAgICAgICBuYW1lPVwiZW1haWxcIlxuICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtlbWFpbH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0RW1haWwoZXZlbnQudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9GaWVsZD5cblxuICAgICAgICAgIDxGaWVsZD5cbiAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicGFzc3dvcmRcIj5TZW5oYTwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgaWQ9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgIG5hbWU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cImN1cnJlbnQtcGFzc3dvcmRcIlxuICAgICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFBhc3N3b3JkKGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvRmllbGQ+XG5cbiAgICAgICAgICB7ZXJyb3IgPyA8RXJyb3JNZXNzYWdlIHJvbGU9XCJhbGVydFwiPntlcnJvcn08L0Vycm9yTWVzc2FnZT4gOiBudWxsfVxuXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ30+XG4gICAgICAgICAgICB7aXNTdWJtaXR0aW5nID8gXCJFbnRyYW5kby4uLlwiIDogXCJFbnRyYXJcIn1cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9Gb3JtPlxuICAgICAgPC9Mb2dpblBhbmVsPlxuICAgIDwvUGFnZVNoZWxsPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgTG9naW47XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3dhbGxhL0Rlc2t0b3AvUHJvamV0b3MtcGVzc29haXMvcHJvdmEtdGVjbmljYS9mcm9udC1taW5pLXRhc2stbWFuYWdlci9zcmMvcGFnZXMvcHVibGljL0xvZ2luL2luZGV4LnRzeCJ9