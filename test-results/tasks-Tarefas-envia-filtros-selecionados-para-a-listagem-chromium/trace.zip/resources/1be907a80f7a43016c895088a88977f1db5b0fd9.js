import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/hooks/auth.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const createContext = __vite__cjsImport1_react["createContext"]; const useContext = __vite__cjsImport1_react["useContext"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useMemo = __vite__cjsImport1_react["useMemo"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=df6b4f96";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=df6b4f96";
import { getCurrentUser, login, logout } from "/src/services/authService.ts";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/hooks/auth.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=df6b4f96";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const AuthContext = createContext(null);
_c2 = AuthContext;
export function AuthProvider({ children }) {
	_s();
	const [user, setUser] = useState(null);
	const [isLoadingAuth, setIsLoadingAuth] = useState(true);
	useEffect(() => {
		let isMounted = true;
		async function loadCurrentUser() {
			try {
				const authenticatedUser = await getCurrentUser();
				if (isMounted) {
					setUser(authenticatedUser);
				}
			} catch {
				if (isMounted) {
					setUser(null);
				}
			} finally {
				if (isMounted) {
					setIsLoadingAuth(false);
				}
			}
		}
		loadCurrentUser();
		return () => {
			isMounted = false;
		};
	}, []);
	async function signIn(credentials) {
		const authenticatedUser_0 = await login(credentials);
		setUser(authenticatedUser_0);
	}
	async function signOut() {
		try {
			await logout();
		} finally {
			setUser(null);
		}
	}
	const value = useMemo(() => ({
		user,
		isAuthorized: Boolean(user),
		isLoadingAuth,
		signIn,
		signOut
	}), [isLoadingAuth, user]);
	return /* @__PURE__ */ _jsxDEV(AuthContext.Provider, {
		value,
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 67,
		columnNumber: 10
	}, this);
}
_s(AuthProvider, "EjUcZjtJvbEn8sYTIstOW/Ud07o=");
_c3 = AuthProvider;
// eslint-disable-next-line react-refresh/only-export-components
export function useAuth() {
	_s2();
	const $ = _c(1);
	if ($[0] !== "b3e408bf04c73c2bf7db6d37d2f718dcee5d52c1065856400e93c8c6da9430fa") {
		for (let $i = 0; $i < 1; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "b3e408bf04c73c2bf7db6d37d2f718dcee5d52c1065856400e93c8c6da9430fa";
	}
	const context = useContext(AuthContext);
	if (!context) {
		throw new Error("useAuth deve ser usado dentro de AuthProvider.");
	}
	return context;
}
_s2(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c2, _c3;
$RefreshReg$(_c2, "AuthContext");
$RefreshReg$(_c3, "AuthProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/hooks/auth.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/hooks/auth.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/hooks/auth.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/hooks/auth.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLGVBQWVDLFlBQVlDLFdBQVdDLFNBQVNDLGdCQUFnQjtBQUV4RSxTQUFTQyxnQkFBZ0JDLE9BQU9DLGNBQWM7Ozs7QUFnQjlDLE1BQU1DLGNBQWNSLGNBQXNDLElBQUk7O0FBTTlELE9BQU8sU0FBU1MsYUFBYSxFQUFFQyxZQUErQjs7Q0FDNUQsTUFBTSxDQUFDQyxNQUFNQyxXQUFXUixTQUFtQyxJQUFJO0NBQy9ELE1BQU0sQ0FBQ1MsZUFBZUMsb0JBQW9CVixTQUFTLElBQUk7Q0FFdkRGLGdCQUFnQjtFQUNkLElBQUlhLFlBQVk7RUFFaEIsZUFBZUMsa0JBQWtCO0dBQy9CLElBQUk7SUFDRixNQUFNQyxvQkFBb0IsTUFBTVosZUFBZTtJQUMvQyxJQUFJVSxXQUFXO0tBQ2JILFFBQVFLLGlCQUFpQjtJQUMzQjtHQUNGLFFBQVE7SUFDTixJQUFJRixXQUFXO0tBQ2JILFFBQVEsSUFBSTtJQUNkO0dBQ0YsVUFBVTtJQUNSLElBQUlHLFdBQVc7S0FDYkQsaUJBQWlCLEtBQUs7SUFDeEI7R0FDRjtFQUNGO0VBRUFFLGdCQUFnQjtFQUVoQixhQUFhO0dBQ1hELFlBQVk7RUFDZDtDQUNGLEdBQUcsRUFBRTtDQUVMLGVBQWVHLE9BQU9DLGFBQWdDO0VBQ3BELE1BQU1GLHNCQUFvQixNQUFNWCxNQUFNYSxXQUFXO0VBQ2pEUCxRQUFRSyxtQkFBaUI7Q0FDM0I7Q0FFQSxlQUFlRyxVQUFVO0VBQ3ZCLElBQUk7R0FDRixNQUFNYixPQUFPO0VBQ2YsVUFBVTtHQUNSSyxRQUFRLElBQUk7RUFDZDtDQUNGO0NBRUEsTUFBTVMsUUFBUWxCLGVBQ0w7RUFDTFE7RUFDQVcsY0FBY0MsUUFBUVosSUFBSTtFQUMxQkU7RUFDQUs7RUFDQUU7Q0FDRixJQUNBLENBQUNQLGVBQWVGLElBQUksQ0FDdEI7Q0FFQSxPQUFPLHdCQUFDLFlBQVksVUFBYjtFQUE2QlU7RUFBUVg7Q0FBK0I7Ozs7O0FBQzdFOzs7O0FBR0EsT0FBTyxTQUFBYyxVQUFBOztDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUNMLE1BQUFLLFVBQWdCN0IsV0FBV08sV0FBVztDQUV0QyxJQUFJLENBQUNzQixTQUFPO0VBQ1YsTUFBTSxJQUFJQyxNQUFNLGdEQUFnRDtDQUFFO0NBQ25FLE9BRU1EO0FBQU8iLCJuYW1lcyI6WyJjcmVhdGVDb250ZXh0IiwidXNlQ29udGV4dCIsInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsImdldEN1cnJlbnRVc2VyIiwibG9naW4iLCJsb2dvdXQiLCJBdXRoQ29udGV4dCIsIkF1dGhQcm92aWRlciIsImNoaWxkcmVuIiwidXNlciIsInNldFVzZXIiLCJpc0xvYWRpbmdBdXRoIiwic2V0SXNMb2FkaW5nQXV0aCIsImlzTW91bnRlZCIsImxvYWRDdXJyZW50VXNlciIsImF1dGhlbnRpY2F0ZWRVc2VyIiwic2lnbkluIiwiY3JlZGVudGlhbHMiLCJzaWduT3V0IiwidmFsdWUiLCJpc0F1dGhvcml6ZWQiLCJCb29sZWFuIiwidXNlQXV0aCIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwiY29udGV4dCIsIkVycm9yIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImF1dGgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUNvbnRleHQsIHVzZUNvbnRleHQsIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBnZXRDdXJyZW50VXNlciwgbG9naW4sIGxvZ291dCB9IGZyb20gXCIuLi9zZXJ2aWNlcy9hdXRoU2VydmljZVwiO1xuaW1wb3J0IHR5cGUgeyBBdXRoZW50aWNhdGVkVXNlciB9IGZyb20gXCIuLi9zZXJ2aWNlcy9hdXRoU2VydmljZVwiO1xuXG50eXBlIFNpZ25JbkNyZWRlbnRpYWxzID0ge1xuICBlbWFpbDogc3RyaW5nO1xuICBwYXNzd29yZDogc3RyaW5nO1xufTtcblxudHlwZSBBdXRoQ29udGV4dERhdGEgPSB7XG4gIHVzZXI6IEF1dGhlbnRpY2F0ZWRVc2VyIHwgbnVsbDtcbiAgaXNBdXRob3JpemVkOiBib29sZWFuO1xuICBpc0xvYWRpbmdBdXRoOiBib29sZWFuO1xuICBzaWduSW46IChjcmVkZW50aWFsczogU2lnbkluQ3JlZGVudGlhbHMpID0+IFByb21pc2U8dm9pZD47XG4gIHNpZ25PdXQ6ICgpID0+IFByb21pc2U8dm9pZD47XG59O1xuXG5jb25zdCBBdXRoQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQ8QXV0aENvbnRleHREYXRhIHwgbnVsbD4obnVsbCk7XG5cbnR5cGUgQXV0aFByb3ZpZGVyUHJvcHMgPSB7XG4gIGNoaWxkcmVuOiBSZWFjdE5vZGU7XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gQXV0aFByb3ZpZGVyKHsgY2hpbGRyZW4gfTogQXV0aFByb3ZpZGVyUHJvcHMpIHtcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGU8QXV0aGVudGljYXRlZFVzZXIgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2lzTG9hZGluZ0F1dGgsIHNldElzTG9hZGluZ0F1dGhdID0gdXNlU3RhdGUodHJ1ZSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsZXQgaXNNb3VudGVkID0gdHJ1ZTtcblxuICAgIGFzeW5jIGZ1bmN0aW9uIGxvYWRDdXJyZW50VXNlcigpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGF1dGhlbnRpY2F0ZWRVc2VyID0gYXdhaXQgZ2V0Q3VycmVudFVzZXIoKTtcbiAgICAgICAgaWYgKGlzTW91bnRlZCkge1xuICAgICAgICAgIHNldFVzZXIoYXV0aGVudGljYXRlZFVzZXIpO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgaWYgKGlzTW91bnRlZCkge1xuICAgICAgICAgIHNldFVzZXIobnVsbCk7XG4gICAgICAgIH1cbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIGlmIChpc01vdW50ZWQpIHtcbiAgICAgICAgICBzZXRJc0xvYWRpbmdBdXRoKGZhbHNlKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIGxvYWRDdXJyZW50VXNlcigpO1xuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGlzTW91bnRlZCA9IGZhbHNlO1xuICAgIH07XG4gIH0sIFtdKTtcblxuICBhc3luYyBmdW5jdGlvbiBzaWduSW4oY3JlZGVudGlhbHM6IFNpZ25JbkNyZWRlbnRpYWxzKSB7XG4gICAgY29uc3QgYXV0aGVudGljYXRlZFVzZXIgPSBhd2FpdCBsb2dpbihjcmVkZW50aWFscyk7XG4gICAgc2V0VXNlcihhdXRoZW50aWNhdGVkVXNlcik7XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBzaWduT3V0KCkge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBsb2dvdXQoKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0VXNlcihudWxsKTtcbiAgICB9XG4gIH1cblxuICBjb25zdCB2YWx1ZSA9IHVzZU1lbW8oXG4gICAgKCkgPT4gKHtcbiAgICAgIHVzZXIsXG4gICAgICBpc0F1dGhvcml6ZWQ6IEJvb2xlYW4odXNlciksXG4gICAgICBpc0xvYWRpbmdBdXRoLFxuICAgICAgc2lnbkluLFxuICAgICAgc2lnbk91dCxcbiAgICB9KSxcbiAgICBbaXNMb2FkaW5nQXV0aCwgdXNlcl0sXG4gICk7XG5cbiAgcmV0dXJuIDxBdXRoQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17dmFsdWV9PntjaGlsZHJlbn08L0F1dGhDb250ZXh0LlByb3ZpZGVyPjtcbn1cblxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LXJlZnJlc2gvb25seS1leHBvcnQtY29tcG9uZW50c1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUF1dGgoKSB7XG4gIGNvbnN0IGNvbnRleHQgPSB1c2VDb250ZXh0KEF1dGhDb250ZXh0KTtcblxuICBpZiAoIWNvbnRleHQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJ1c2VBdXRoIGRldmUgc2VyIHVzYWRvIGRlbnRybyBkZSBBdXRoUHJvdmlkZXIuXCIpO1xuICB9XG5cbiAgcmV0dXJuIGNvbnRleHQ7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3dhbGxhL0Rlc2t0b3AvUHJvamV0b3MtcGVzc29haXMvcHJvdmEtdGVjbmljYS9mcm9udC1taW5pLXRhc2stbWFuYWdlci9zcmMvaG9va3MvYXV0aC50c3gifQ==