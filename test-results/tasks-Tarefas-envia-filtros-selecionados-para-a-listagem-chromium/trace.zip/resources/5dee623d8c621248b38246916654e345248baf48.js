import styled from "/node_modules/.vite/deps/styled-components.js?v=b967f2da";
export const TasksShell = styled.main`
  min-height: 100svh;
  width: 100%;
  display: grid;
  align-content: start;
  gap: 16px;
  padding: 20px;
  box-sizing: border-box;
  background: ${({ theme }) => theme.colors.background};

  @media (max-width: 640px) {
    padding: 12px;
  }
`;
export const TopBar = styled.header`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
`;
export const UserInfo = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  color: ${({ theme }) => theme.colors.dark};
  font-size: 14px;

  strong {
    color: ${({ theme }) => theme.colors.text_black};
  }
`;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsT0FBT0EsWUFBWTtBQUVuQixPQUFPLE1BQU1DLGFBQWFELE9BQU9FLElBQUk7Ozs7Ozs7O2lCQVFwQixFQUFFQyxZQUFZQSxNQUFNQyxPQUFPQyxXQUFVOzs7Ozs7QUFPdEQsT0FBTyxNQUFNQyxTQUFTTixPQUFPTyxNQUFNOzs7Ozs7O0FBUW5DLE9BQU8sTUFBTUMsV0FBV1IsT0FBT1MsR0FBRzs7OztZQUl0QixFQUFFTixZQUFZQSxNQUFNQyxPQUFPTSxLQUFJOzs7O2NBSTdCLEVBQUVQLFlBQVlBLE1BQU1DLE9BQU9PLFdBQVUiLCJuYW1lcyI6WyJzdHlsZWQiLCJUYXNrc1NoZWxsIiwibWFpbiIsInRoZW1lIiwiY29sb3JzIiwiYmFja2dyb3VuZCIsIlRvcEJhciIsImhlYWRlciIsIlVzZXJJbmZvIiwiZGl2IiwiZGFyayIsInRleHRfYmxhY2siXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsic3R5bGVzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XG5cbmV4cG9ydCBjb25zdCBUYXNrc1NoZWxsID0gc3R5bGVkLm1haW5gXG4gIG1pbi1oZWlnaHQ6IDEwMHN2aDtcbiAgd2lkdGg6IDEwMCU7XG4gIGRpc3BsYXk6IGdyaWQ7XG4gIGFsaWduLWNvbnRlbnQ6IHN0YXJ0O1xuICBnYXA6IDE2cHg7XG4gIHBhZGRpbmc6IDIwcHg7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIGJhY2tncm91bmQ6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLmJhY2tncm91bmR9O1xuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA2NDBweCkge1xuICAgIHBhZGRpbmc6IDEycHg7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBUb3BCYXIgPSBzdHlsZWQuaGVhZGVyYFxuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIGdhcDogMTJweDtcbiAgZmxleC13cmFwOiB3cmFwO1xuYDtcblxuZXhwb3J0IGNvbnN0IFVzZXJJbmZvID0gc3R5bGVkLmRpdmBcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgZ2FwOiAxMHB4O1xuICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMuZGFya307XG4gIGZvbnQtc2l6ZTogMTRweDtcblxuICBzdHJvbmcge1xuICAgIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy50ZXh0X2JsYWNrfTtcbiAgfVxuYDtcbiJdLCJmaWxlIjoiQzovVXNlcnMvd2FsbGEvRGVza3RvcC9Qcm9qZXRvcy1wZXNzb2Fpcy9wcm92YS10ZWNuaWNhL2Zyb250LW1pbmktdGFzay1tYW5hZ2VyL3NyYy9wYWdlcy9wcml2YXRlL1Rhc2tzL3N0eWxlcy50cyJ9