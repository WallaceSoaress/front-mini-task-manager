import styled, { css } from "/node_modules/.vite/deps/styled-components.js?v=b967f2da";
export const Toolbar = styled.section`
  display: grid;
  gap: 16px;
  border: 1px solid ${({ theme }) => theme.colors.border};
  border-radius: 8px;
  padding: 16px;
  background: ${({ theme }) => theme.colors.white};
`;
export const ToolbarHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  flex-wrap: wrap;

  h1 {
    margin: 0;
    font-size: 28px;
  }

  p {
    color: ${({ theme }) => theme.colors.dark};
  }
`;
export const FilterGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(150px, 1fr));
  gap: 12px;

  @media (max-width: 900px) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  @media (max-width: 560px) {
    grid-template-columns: 1fr;
  }
`;
export const Field = styled.label`
  display: grid;
  gap: 6px;
  color: ${({ theme }) => theme.colors.text_black};
  font-size: ${({ theme }) => theme.fonts.size.small};
  font-weight: 700;

  input,
  select,
  textarea {
    width: 100%;
    min-height: 40px;
    border: 1px solid ${({ theme }) => theme.colors.border};
    border-radius: 8px;
    padding: 0 10px;
    color: ${({ theme }) => theme.colors.text_black};
    background: ${({ theme }) => theme.colors.white};
    box-sizing: border-box;
    font: inherit;
  }

  textarea {
    min-height: 92px;
    padding: 10px;
    resize: vertical;
  }

  input:focus,
  select:focus,
  textarea:focus {
    border-color: ${({ theme }) => theme.colors.primary_dark};
    outline: 3px solid rgba(67, 190, 198, 0.18);
  }
`;
export const FieldError = styled.span`
  color: ${({ theme }) => theme.colors.danger};
  font-size: 13px;
  font-weight: 600;
`;
export const Button = styled.button`
  min-height: 40px;
  border: 1px solid transparent;
  border-radius: 8px;
  padding: 0 14px;
  cursor: pointer;
  font: inherit;
  font-weight: 700;

  ${({ $variant = "primary", theme }) => {
	if ($variant === "danger") {
		return css`
        color: ${theme.colors.text_white};
        background: ${theme.colors.danger};
      `;
	}
	if ($variant === "ghost") {
		return css`
        color: ${theme.colors.text_black};
        border-color: ${theme.colors.border};
        background: ${theme.colors.white};
      `;
	}
	return css`
      color: ${theme.colors.text_white};
      background: ${theme.colors.primary_dark};
    `;
}}

  &:disabled {
    cursor: not-allowed;
    opacity: 0.65;
  }
`;
export const BoardScroller = styled.section`
  display: grid;
  gap: 16px;
  overflow-x: auto;
  padding: 4px 0 12px;
`;
export const BoardGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(280px, 1fr));
  gap: 14px;
  min-width: 900px;

  @media (max-width: 720px) {
    min-width: 840px;
  }
`;
export const Column = styled.article`
  min-height: 320px;
  border: 1px solid transparent;
  border-radius: 8px;
  background: #f7f7f8;

  ${({ $isDropTarget, theme }) => $isDropTarget && css`
      border-color: ${theme.colors.primary_dark};
      background: rgba(67, 190, 198, 0.08);
    `}
`;
export const ColumnHeader = styled.header`
  min-height: 44px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding: 0 14px;
  border-radius: 8px 8px 0 0;
  color: ${({ theme }) => theme.colors.text_black};
  background: #f3f3f4;
  font-weight: 700;
`;
export const CountBadge = styled.span`
  min-width: 24px;
  border-radius: 6px;
  padding: 1px 7px;
  color: ${({ theme }) => theme.colors.dark};
  background: ${({ theme }) => theme.colors.light};
  text-align: center;
  font-size: 13px;
`;
export const CardList = styled.div`
  display: grid;
  gap: 8px;
  padding: 8px;
`;
export const TaskCardButton = styled.button`
  display: grid;
  gap: 10px;
  width: 100%;
  border: 1px solid #d9dce1;
  border-radius: 8px;
  padding: 12px;
  color: ${({ theme }) => theme.colors.text_black};
  background: ${({ theme }) => theme.colors.white};
  text-align: left;
  cursor: pointer;
  box-shadow: 0 1px 2px rgba(9, 30, 66, 0.12);

  &:active {
    cursor: grabbing;
  }

  &:hover,
  &:focus-visible {
    border-color: ${({ theme }) => theme.colors.primary_dark};
    outline: none;
  }
`;
export const CardTitle = styled.h3`
  margin: 0;
  color: ${({ theme }) => theme.colors.text_black};
  font-size: 15px;
  font-weight: 600;
  line-height: 1.35;
`;
export const CardMeta = styled.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
  color: ${({ theme }) => theme.colors.dark};
  font-size: 13px;
`;
export const Chip = styled.span`
  display: inline-flex;
  align-items: center;
  min-height: 24px;
  border: 1px solid ${({ theme }) => theme.colors.border};
  border-radius: 6px;
  padding: 0 8px;
  background: ${({ theme }) => theme.colors.white};
  font-size: 12px;
  font-weight: 700;

  ${({ $tone }) => $tone === "low" && css`
      color: #157743;
      background: #f0fdf5;
    `}

  ${({ $tone }) => $tone === "medium" && css`
      color: #8a5a00;
      background: #fff7df;
    `}

  ${({ $tone }) => $tone === "high" && css`
      color: #b42318;
      background: #fff4f4;
    `}

  ${({ $tone }) => $tone === "danger" && css`
      color: #b42318;
      background: #fff4f4;
    `}

  ${({ $tone }) => $tone === "warning" && css`
      color: #8a5a00;
      background: #fff7df;
    `}
`;
export const EmptyColumn = styled.div`
  border: 1px dashed ${({ theme }) => theme.colors.border};
  border-radius: 8px;
  padding: 18px;
  color: ${({ theme }) => theme.colors.dark};
  background: rgba(255, 255, 255, 0.7);
  text-align: center;
  font-size: 14px;
`;
export const StateBox = styled.div`
  display: grid;
  place-items: center;
  gap: 12px;
  min-height: 220px;
  border: 1px dashed ${({ theme }) => theme.colors.border};
  border-radius: 8px;
  padding: 24px;
  background: ${({ theme }) => theme.colors.white};
  color: ${({ theme }) => theme.colors.dark};
  text-align: center;
`;
export const ModalBackdrop = styled.div`
  position: fixed;
  inset: 0;
  z-index: 30;
  display: grid;
  place-items: center;
  padding: 20px;
  background: rgba(0, 0, 0, 0.36);
`;
export const ModalPanel = styled.section`
  width: min(100%, 720px);
  max-height: calc(100svh - 40px);
  overflow: auto;
  border-radius: 8px;
  background: ${({ theme }) => theme.colors.white};
  box-shadow: 0 24px 70px rgba(9, 30, 66, 0.28);
`;
export const ModalHeader = styled.header`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
  padding: 20px 22px;
  border-bottom: 1px solid ${({ theme }) => theme.colors.border};

  h2 {
    margin: 0;
  }
`;
export const ModalBody = styled.div`
  display: grid;
  gap: 16px;
  padding: 22px;
`;
export const FormGrid = styled.form`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 14px;

  ${Field}:first-child,
  ${Field}:nth-child(2),
  .full {
    grid-column: 1 / -1;
  }

  @media (max-width: 640px) {
    grid-template-columns: 1fr;
  }
`;
export const ModalActions = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  flex-wrap: wrap;
  padding-top: 6px;
  grid-column: 1 / -1;
`;
export const DetailGrid = styled.dl`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
  margin: 0;

  div {
    display: grid;
    gap: 4px;
    border: 1px solid ${({ theme }) => theme.colors.border};
    border-radius: 8px;
    padding: 12px;
  }

  dt {
    color: ${({ theme }) => theme.colors.dark};
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
  }

  dd {
    margin: 0;
    color: ${({ theme }) => theme.colors.text_black};
  }

  @media (max-width: 640px) {
    grid-template-columns: 1fr;
  }
`;
export const Pagination = styled.nav`
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 10px;
  flex-wrap: wrap;
  color: ${({ theme }) => theme.colors.dark};
`;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsT0FBT0EsVUFBVUMsV0FBVztBQUU1QixPQUFPLE1BQU1DLFVBQVVGLE9BQU9HLE9BQU87Ozt1QkFHZCxFQUFFQyxZQUFZQSxNQUFNQyxPQUFPQyxPQUFNOzs7aUJBR3ZDLEVBQUVGLFlBQVlBLE1BQU1DLE9BQU9FLE1BQUs7O0FBR2pELE9BQU8sTUFBTUMsZ0JBQWdCUixPQUFPUyxHQUFHOzs7Ozs7Ozs7Ozs7O2NBYXpCLEVBQUVMLFlBQVlBLE1BQU1DLE9BQU9LLEtBQUk7OztBQUk3QyxPQUFPLE1BQU1DLGFBQWFYLE9BQU9TLEdBQUc7Ozs7Ozs7Ozs7Ozs7QUFjcEMsT0FBTyxNQUFNRyxRQUFRWixPQUFPYSxLQUFLOzs7WUFHckIsRUFBRVQsWUFBWUEsTUFBTUMsT0FBT1MsV0FBVTtnQkFDakMsRUFBRVYsWUFBWUEsTUFBTVcsTUFBTUMsS0FBS0MsTUFBSzs7Ozs7Ozs7eUJBUTNCLEVBQUViLFlBQVlBLE1BQU1DLE9BQU9DLE9BQU07OztjQUc1QyxFQUFFRixZQUFZQSxNQUFNQyxPQUFPUyxXQUFVO21CQUNoQyxFQUFFVixZQUFZQSxNQUFNQyxPQUFPRSxNQUFLOzs7Ozs7Ozs7Ozs7OztxQkFjOUIsRUFBRUgsWUFBWUEsTUFBTUMsT0FBT2EsYUFBWTs7OztBQUs1RCxPQUFPLE1BQU1DLGFBQWFuQixPQUFPb0IsSUFBSTtZQUN6QixFQUFFaEIsWUFBWUEsTUFBTUMsT0FBT2dCLE9BQU07Ozs7QUFLN0MsT0FBTyxNQUFNQyxTQUFTdEIsT0FBT3VCLE1BQXFEOzs7Ozs7Ozs7S0FTN0UsRUFBRUMsV0FBVyxXQUFXcEIsWUFBWTtDQUNyQyxJQUFJb0IsYUFBYSxVQUFVO0VBQ3pCLE9BQU92QixHQUFHO2lCQUNDRyxNQUFNQyxPQUFPb0IsV0FBVTtzQkFDbEJyQixNQUFNQyxPQUFPZ0IsT0FBTTs7Q0FFckM7Q0FFQSxJQUFJRyxhQUFhLFNBQVM7RUFDeEIsT0FBT3ZCLEdBQUc7aUJBQ0NHLE1BQU1DLE9BQU9TLFdBQVU7d0JBQ2hCVixNQUFNQyxPQUFPQyxPQUFNO3NCQUNyQkYsTUFBTUMsT0FBT0UsTUFBSzs7Q0FFcEM7Q0FFQSxPQUFPTixHQUFHO2VBQ0NHLE1BQU1DLE9BQU9vQixXQUFVO29CQUNsQnJCLE1BQU1DLE9BQU9hLGFBQVk7O0FBRTNDLEVBQUM7Ozs7Ozs7QUFRSCxPQUFPLE1BQU1RLGdCQUFnQjFCLE9BQU9HLE9BQU87Ozs7OztBQU8zQyxPQUFPLE1BQU13QixZQUFZM0IsT0FBT1MsR0FBRzs7Ozs7Ozs7OztBQVduQyxPQUFPLE1BQU1tQixTQUFTNUIsT0FBTzZCLE9BQW9DOzs7Ozs7S0FNNUQsRUFBRUMsZUFBZTFCLFlBQ2xCMEIsaUJBQ0E3QixHQUFHO3NCQUNlRyxNQUFNQyxPQUFPYSxhQUFZOztNQUUxQzs7QUFHTCxPQUFPLE1BQU1hLGVBQWUvQixPQUFPZ0MsTUFBTTs7Ozs7Ozs7WUFRN0IsRUFBRTVCLFlBQVlBLE1BQU1DLE9BQU9TLFdBQVU7Ozs7QUFLakQsT0FBTyxNQUFNbUIsYUFBYWpDLE9BQU9vQixJQUFJOzs7O1lBSXpCLEVBQUVoQixZQUFZQSxNQUFNQyxPQUFPSyxLQUFJO2lCQUMxQixFQUFFTixZQUFZQSxNQUFNQyxPQUFPNkIsTUFBSzs7OztBQUtqRCxPQUFPLE1BQU1DLFdBQVduQyxPQUFPUyxHQUFHOzs7OztBQU1sQyxPQUFPLE1BQU0yQixpQkFBaUJwQyxPQUFPdUIsTUFBTTs7Ozs7OztZQU8vQixFQUFFbkIsWUFBWUEsTUFBTUMsT0FBT1MsV0FBVTtpQkFDaEMsRUFBRVYsWUFBWUEsTUFBTUMsT0FBT0UsTUFBSzs7Ozs7Ozs7Ozs7cUJBVzVCLEVBQUVILFlBQVlBLE1BQU1DLE9BQU9hLGFBQVk7Ozs7QUFLNUQsT0FBTyxNQUFNbUIsWUFBWXJDLE9BQU9zQyxFQUFFOztZQUV0QixFQUFFbEMsWUFBWUEsTUFBTUMsT0FBT1MsV0FBVTs7Ozs7QUFNakQsT0FBTyxNQUFNeUIsV0FBV3ZDLE9BQU9TLEdBQUc7Ozs7O1lBS3RCLEVBQUVMLFlBQVlBLE1BQU1DLE9BQU9LLEtBQUk7OztBQUkzQyxPQUFPLE1BQU04QixPQUFPeEMsT0FBT29CLElBQThFOzs7O3VCQUlsRixFQUFFaEIsWUFBWUEsTUFBTUMsT0FBT0MsT0FBTTs7O2lCQUd2QyxFQUFFRixZQUFZQSxNQUFNQyxPQUFPRSxNQUFLOzs7O0tBSTVDLEVBQUVrQyxZQUNIQSxVQUFVLFNBQ1Z4QyxHQUFHOzs7TUFHRjs7S0FFQSxFQUFFd0MsWUFDSEEsVUFBVSxZQUNWeEMsR0FBRzs7O01BR0Y7O0tBRUEsRUFBRXdDLFlBQ0hBLFVBQVUsVUFDVnhDLEdBQUc7OztNQUdGOztLQUVBLEVBQUV3QyxZQUNIQSxVQUFVLFlBQ1Z4QyxHQUFHOzs7TUFHRjs7S0FFQSxFQUFFd0MsWUFDSEEsVUFBVSxhQUNWeEMsR0FBRzs7O01BR0Y7O0FBR0wsT0FBTyxNQUFNeUMsY0FBYzFDLE9BQU9TLEdBQUc7d0JBQ2IsRUFBRUwsWUFBWUEsTUFBTUMsT0FBT0MsT0FBTTs7O1lBRzdDLEVBQUVGLFlBQVlBLE1BQU1DLE9BQU9LLEtBQUk7Ozs7O0FBTTNDLE9BQU8sTUFBTWlDLFdBQVczQyxPQUFPUyxHQUFHOzs7Ozt3QkFLVixFQUFFTCxZQUFZQSxNQUFNQyxPQUFPQyxPQUFNOzs7aUJBR3hDLEVBQUVGLFlBQVlBLE1BQU1DLE9BQU9FLE1BQUs7WUFDckMsRUFBRUgsWUFBWUEsTUFBTUMsT0FBT0ssS0FBSTs7O0FBSTNDLE9BQU8sTUFBTWtDLGdCQUFnQjVDLE9BQU9TLEdBQUc7Ozs7Ozs7OztBQVV2QyxPQUFPLE1BQU1vQyxhQUFhN0MsT0FBT0csT0FBTzs7Ozs7aUJBS3ZCLEVBQUVDLFlBQVlBLE1BQU1DLE9BQU9FLE1BQUs7OztBQUlqRCxPQUFPLE1BQU11QyxjQUFjOUMsT0FBT2dDLE1BQU07Ozs7Ozs4QkFNVixFQUFFNUIsWUFBWUEsTUFBTUMsT0FBT0MsT0FBTTs7Ozs7O0FBTy9ELE9BQU8sTUFBTXlDLFlBQVkvQyxPQUFPUyxHQUFHOzs7OztBQU1uQyxPQUFPLE1BQU11QyxXQUFXaEQsT0FBT2lELElBQUk7Ozs7O0lBSy9CckMsTUFBSztJQUNMQSxNQUFLOzs7Ozs7Ozs7QUFVVCxPQUFPLE1BQU1zQyxlQUFlbEQsT0FBT1MsR0FBRzs7Ozs7Ozs7QUFTdEMsT0FBTyxNQUFNMEMsYUFBYW5ELE9BQU9vRCxFQUFFOzs7Ozs7Ozs7eUJBU1YsRUFBRWhELFlBQVlBLE1BQU1DLE9BQU9DLE9BQU07Ozs7OztjQU01QyxFQUFFRixZQUFZQSxNQUFNQyxPQUFPSyxLQUFJOzs7Ozs7OztjQVEvQixFQUFFTixZQUFZQSxNQUFNQyxPQUFPUyxXQUFVOzs7Ozs7O0FBUW5ELE9BQU8sTUFBTXVDLGFBQWFyRCxPQUFPc0QsR0FBRzs7Ozs7O1lBTXhCLEVBQUVsRCxZQUFZQSxNQUFNQyxPQUFPSyxLQUFJIiwibmFtZXMiOlsic3R5bGVkIiwiY3NzIiwiVG9vbGJhciIsInNlY3Rpb24iLCJ0aGVtZSIsImNvbG9ycyIsImJvcmRlciIsIndoaXRlIiwiVG9vbGJhckhlYWRlciIsImRpdiIsImRhcmsiLCJGaWx0ZXJHcmlkIiwiRmllbGQiLCJsYWJlbCIsInRleHRfYmxhY2siLCJmb250cyIsInNpemUiLCJzbWFsbCIsInByaW1hcnlfZGFyayIsIkZpZWxkRXJyb3IiLCJzcGFuIiwiZGFuZ2VyIiwiQnV0dG9uIiwiYnV0dG9uIiwiJHZhcmlhbnQiLCJ0ZXh0X3doaXRlIiwiQm9hcmRTY3JvbGxlciIsIkJvYXJkR3JpZCIsIkNvbHVtbiIsImFydGljbGUiLCIkaXNEcm9wVGFyZ2V0IiwiQ29sdW1uSGVhZGVyIiwiaGVhZGVyIiwiQ291bnRCYWRnZSIsImxpZ2h0IiwiQ2FyZExpc3QiLCJUYXNrQ2FyZEJ1dHRvbiIsIkNhcmRUaXRsZSIsImgzIiwiQ2FyZE1ldGEiLCJDaGlwIiwiJHRvbmUiLCJFbXB0eUNvbHVtbiIsIlN0YXRlQm94IiwiTW9kYWxCYWNrZHJvcCIsIk1vZGFsUGFuZWwiLCJNb2RhbEhlYWRlciIsIk1vZGFsQm9keSIsIkZvcm1HcmlkIiwiZm9ybSIsIk1vZGFsQWN0aW9ucyIsIkRldGFpbEdyaWQiLCJkbCIsIlBhZ2luYXRpb24iLCJuYXYiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsic3R5bGVzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZWQsIHsgY3NzIH0gZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XG5cbmV4cG9ydCBjb25zdCBUb29sYmFyID0gc3R5bGVkLnNlY3Rpb25gXG4gIGRpc3BsYXk6IGdyaWQ7XG4gIGdhcDogMTZweDtcbiAgYm9yZGVyOiAxcHggc29saWQgJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMuYm9yZGVyfTtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBwYWRkaW5nOiAxNnB4O1xuICBiYWNrZ3JvdW5kOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy53aGl0ZX07XG5gO1xuXG5leHBvcnQgY29uc3QgVG9vbGJhckhlYWRlciA9IHN0eWxlZC5kaXZgXG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgZ2FwOiAxNnB4O1xuICBmbGV4LXdyYXA6IHdyYXA7XG5cbiAgaDEge1xuICAgIG1hcmdpbjogMDtcbiAgICBmb250LXNpemU6IDI4cHg7XG4gIH1cblxuICBwIHtcbiAgICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMuZGFya307XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBGaWx0ZXJHcmlkID0gc3R5bGVkLmRpdmBcbiAgZGlzcGxheTogZ3JpZDtcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiByZXBlYXQoNCwgbWlubWF4KDE1MHB4LCAxZnIpKTtcbiAgZ2FwOiAxMnB4O1xuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA5MDBweCkge1xuICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogcmVwZWF0KDIsIG1pbm1heCgwLCAxZnIpKTtcbiAgfVxuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1NjBweCkge1xuICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogMWZyO1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgRmllbGQgPSBzdHlsZWQubGFiZWxgXG4gIGRpc3BsYXk6IGdyaWQ7XG4gIGdhcDogNnB4O1xuICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMudGV4dF9ibGFja307XG4gIGZvbnQtc2l6ZTogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5mb250cy5zaXplLnNtYWxsfTtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcblxuICBpbnB1dCxcbiAgc2VsZWN0LFxuICB0ZXh0YXJlYSB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgbWluLWhlaWdodDogNDBweDtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy5ib3JkZXJ9O1xuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICBwYWRkaW5nOiAwIDEwcHg7XG4gICAgY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLnRleHRfYmxhY2t9O1xuICAgIGJhY2tncm91bmQ6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLndoaXRlfTtcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICAgIGZvbnQ6IGluaGVyaXQ7XG4gIH1cblxuICB0ZXh0YXJlYSB7XG4gICAgbWluLWhlaWdodDogOTJweDtcbiAgICBwYWRkaW5nOiAxMHB4O1xuICAgIHJlc2l6ZTogdmVydGljYWw7XG4gIH1cblxuICBpbnB1dDpmb2N1cyxcbiAgc2VsZWN0OmZvY3VzLFxuICB0ZXh0YXJlYTpmb2N1cyB7XG4gICAgYm9yZGVyLWNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy5wcmltYXJ5X2Rhcmt9O1xuICAgIG91dGxpbmU6IDNweCBzb2xpZCByZ2JhKDY3LCAxOTAsIDE5OCwgMC4xOCk7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBGaWVsZEVycm9yID0gc3R5bGVkLnNwYW5gXG4gIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy5kYW5nZXJ9O1xuICBmb250LXNpemU6IDEzcHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG5gO1xuXG5leHBvcnQgY29uc3QgQnV0dG9uID0gc3R5bGVkLmJ1dHRvbjx7ICR2YXJpYW50PzogXCJwcmltYXJ5XCIgfCBcImdob3N0XCIgfCBcImRhbmdlclwiIH0+YFxuICBtaW4taGVpZ2h0OiA0MHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCB0cmFuc3BhcmVudDtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBwYWRkaW5nOiAwIDE0cHg7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgZm9udDogaW5oZXJpdDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcblxuICAkeyh7ICR2YXJpYW50ID0gXCJwcmltYXJ5XCIsIHRoZW1lIH0pID0+IHtcbiAgICBpZiAoJHZhcmlhbnQgPT09IFwiZGFuZ2VyXCIpIHtcbiAgICAgIHJldHVybiBjc3NgXG4gICAgICAgIGNvbG9yOiAke3RoZW1lLmNvbG9ycy50ZXh0X3doaXRlfTtcbiAgICAgICAgYmFja2dyb3VuZDogJHt0aGVtZS5jb2xvcnMuZGFuZ2VyfTtcbiAgICAgIGA7XG4gICAgfVxuXG4gICAgaWYgKCR2YXJpYW50ID09PSBcImdob3N0XCIpIHtcbiAgICAgIHJldHVybiBjc3NgXG4gICAgICAgIGNvbG9yOiAke3RoZW1lLmNvbG9ycy50ZXh0X2JsYWNrfTtcbiAgICAgICAgYm9yZGVyLWNvbG9yOiAke3RoZW1lLmNvbG9ycy5ib3JkZXJ9O1xuICAgICAgICBiYWNrZ3JvdW5kOiAke3RoZW1lLmNvbG9ycy53aGl0ZX07XG4gICAgICBgO1xuICAgIH1cblxuICAgIHJldHVybiBjc3NgXG4gICAgICBjb2xvcjogJHt0aGVtZS5jb2xvcnMudGV4dF93aGl0ZX07XG4gICAgICBiYWNrZ3JvdW5kOiAke3RoZW1lLmNvbG9ycy5wcmltYXJ5X2Rhcmt9O1xuICAgIGA7XG4gIH19XG5cbiAgJjpkaXNhYmxlZCB7XG4gICAgY3Vyc29yOiBub3QtYWxsb3dlZDtcbiAgICBvcGFjaXR5OiAwLjY1O1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgQm9hcmRTY3JvbGxlciA9IHN0eWxlZC5zZWN0aW9uYFxuICBkaXNwbGF5OiBncmlkO1xuICBnYXA6IDE2cHg7XG4gIG92ZXJmbG93LXg6IGF1dG87XG4gIHBhZGRpbmc6IDRweCAwIDEycHg7XG5gO1xuXG5leHBvcnQgY29uc3QgQm9hcmRHcmlkID0gc3R5bGVkLmRpdmBcbiAgZGlzcGxheTogZ3JpZDtcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiByZXBlYXQoMywgbWlubWF4KDI4MHB4LCAxZnIpKTtcbiAgZ2FwOiAxNHB4O1xuICBtaW4td2lkdGg6IDkwMHB4O1xuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3MjBweCkge1xuICAgIG1pbi13aWR0aDogODQwcHg7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBDb2x1bW4gPSBzdHlsZWQuYXJ0aWNsZTx7ICRpc0Ryb3BUYXJnZXQ/OiBib29sZWFuIH0+YFxuICBtaW4taGVpZ2h0OiAzMjBweDtcbiAgYm9yZGVyOiAxcHggc29saWQgdHJhbnNwYXJlbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgYmFja2dyb3VuZDogI2Y3ZjdmODtcblxuICAkeyh7ICRpc0Ryb3BUYXJnZXQsIHRoZW1lIH0pID0+XG4gICAgJGlzRHJvcFRhcmdldCAmJlxuICAgIGNzc2BcbiAgICAgIGJvcmRlci1jb2xvcjogJHt0aGVtZS5jb2xvcnMucHJpbWFyeV9kYXJrfTtcbiAgICAgIGJhY2tncm91bmQ6IHJnYmEoNjcsIDE5MCwgMTk4LCAwLjA4KTtcbiAgICBgfVxuYDtcblxuZXhwb3J0IGNvbnN0IENvbHVtbkhlYWRlciA9IHN0eWxlZC5oZWFkZXJgXG4gIG1pbi1oZWlnaHQ6IDQ0cHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgZ2FwOiA4cHg7XG4gIHBhZGRpbmc6IDAgMTRweDtcbiAgYm9yZGVyLXJhZGl1czogOHB4IDhweCAwIDA7XG4gIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy50ZXh0X2JsYWNrfTtcbiAgYmFja2dyb3VuZDogI2YzZjNmNDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbmA7XG5cbmV4cG9ydCBjb25zdCBDb3VudEJhZGdlID0gc3R5bGVkLnNwYW5gXG4gIG1pbi13aWR0aDogMjRweDtcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xuICBwYWRkaW5nOiAxcHggN3B4O1xuICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMuZGFya307XG4gIGJhY2tncm91bmQ6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLmxpZ2h0fTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXNpemU6IDEzcHg7XG5gO1xuXG5leHBvcnQgY29uc3QgQ2FyZExpc3QgPSBzdHlsZWQuZGl2YFxuICBkaXNwbGF5OiBncmlkO1xuICBnYXA6IDhweDtcbiAgcGFkZGluZzogOHB4O1xuYDtcblxuZXhwb3J0IGNvbnN0IFRhc2tDYXJkQnV0dG9uID0gc3R5bGVkLmJ1dHRvbmBcbiAgZGlzcGxheTogZ3JpZDtcbiAgZ2FwOiAxMHB4O1xuICB3aWR0aDogMTAwJTtcbiAgYm9yZGVyOiAxcHggc29saWQgI2Q5ZGNlMTtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBwYWRkaW5nOiAxMnB4O1xuICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMudGV4dF9ibGFja307XG4gIGJhY2tncm91bmQ6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLndoaXRlfTtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBib3gtc2hhZG93OiAwIDFweCAycHggcmdiYSg5LCAzMCwgNjYsIDAuMTIpO1xuXG4gICY6YWN0aXZlIHtcbiAgICBjdXJzb3I6IGdyYWJiaW5nO1xuICB9XG5cbiAgJjpob3ZlcixcbiAgJjpmb2N1cy12aXNpYmxlIHtcbiAgICBib3JkZXItY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLnByaW1hcnlfZGFya307XG4gICAgb3V0bGluZTogbm9uZTtcbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IENhcmRUaXRsZSA9IHN0eWxlZC5oM2BcbiAgbWFyZ2luOiAwO1xuICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMudGV4dF9ibGFja307XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgbGluZS1oZWlnaHQ6IDEuMzU7XG5gO1xuXG5leHBvcnQgY29uc3QgQ2FyZE1ldGEgPSBzdHlsZWQuZGl2YFxuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBmbGV4LXdyYXA6IHdyYXA7XG4gIGdhcDogOHB4O1xuICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMuZGFya307XG4gIGZvbnQtc2l6ZTogMTNweDtcbmA7XG5cbmV4cG9ydCBjb25zdCBDaGlwID0gc3R5bGVkLnNwYW48eyAkdG9uZT86IFwiZGVmYXVsdFwiIHwgXCJsb3dcIiB8IFwibWVkaXVtXCIgfCBcImhpZ2hcIiB8IFwiZGFuZ2VyXCIgfCBcIndhcm5pbmdcIiB9PmBcbiAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIG1pbi1oZWlnaHQ6IDI0cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLmJvcmRlcn07XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgcGFkZGluZzogMCA4cHg7XG4gIGJhY2tncm91bmQ6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLndoaXRlfTtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBmb250LXdlaWdodDogNzAwO1xuXG4gICR7KHsgJHRvbmUgfSkgPT5cbiAgICAkdG9uZSA9PT0gXCJsb3dcIiAmJlxuICAgIGNzc2BcbiAgICAgIGNvbG9yOiAjMTU3NzQzO1xuICAgICAgYmFja2dyb3VuZDogI2YwZmRmNTtcbiAgICBgfVxuXG4gICR7KHsgJHRvbmUgfSkgPT5cbiAgICAkdG9uZSA9PT0gXCJtZWRpdW1cIiAmJlxuICAgIGNzc2BcbiAgICAgIGNvbG9yOiAjOGE1YTAwO1xuICAgICAgYmFja2dyb3VuZDogI2ZmZjdkZjtcbiAgICBgfVxuXG4gICR7KHsgJHRvbmUgfSkgPT5cbiAgICAkdG9uZSA9PT0gXCJoaWdoXCIgJiZcbiAgICBjc3NgXG4gICAgICBjb2xvcjogI2I0MjMxODtcbiAgICAgIGJhY2tncm91bmQ6ICNmZmY0ZjQ7XG4gICAgYH1cblxuICAkeyh7ICR0b25lIH0pID0+XG4gICAgJHRvbmUgPT09IFwiZGFuZ2VyXCIgJiZcbiAgICBjc3NgXG4gICAgICBjb2xvcjogI2I0MjMxODtcbiAgICAgIGJhY2tncm91bmQ6ICNmZmY0ZjQ7XG4gICAgYH1cblxuICAkeyh7ICR0b25lIH0pID0+XG4gICAgJHRvbmUgPT09IFwid2FybmluZ1wiICYmXG4gICAgY3NzYFxuICAgICAgY29sb3I6ICM4YTVhMDA7XG4gICAgICBiYWNrZ3JvdW5kOiAjZmZmN2RmO1xuICAgIGB9XG5gO1xuXG5leHBvcnQgY29uc3QgRW1wdHlDb2x1bW4gPSBzdHlsZWQuZGl2YFxuICBib3JkZXI6IDFweCBkYXNoZWQgJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMuYm9yZGVyfTtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBwYWRkaW5nOiAxOHB4O1xuICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMuZGFya307XG4gIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC43KTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXNpemU6IDE0cHg7XG5gO1xuXG5leHBvcnQgY29uc3QgU3RhdGVCb3ggPSBzdHlsZWQuZGl2YFxuICBkaXNwbGF5OiBncmlkO1xuICBwbGFjZS1pdGVtczogY2VudGVyO1xuICBnYXA6IDEycHg7XG4gIG1pbi1oZWlnaHQ6IDIyMHB4O1xuICBib3JkZXI6IDFweCBkYXNoZWQgJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMuYm9yZGVyfTtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBwYWRkaW5nOiAyNHB4O1xuICBiYWNrZ3JvdW5kOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy53aGl0ZX07XG4gIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy5kYXJrfTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuYDtcblxuZXhwb3J0IGNvbnN0IE1vZGFsQmFja2Ryb3AgPSBzdHlsZWQuZGl2YFxuICBwb3NpdGlvbjogZml4ZWQ7XG4gIGluc2V0OiAwO1xuICB6LWluZGV4OiAzMDtcbiAgZGlzcGxheTogZ3JpZDtcbiAgcGxhY2UtaXRlbXM6IGNlbnRlcjtcbiAgcGFkZGluZzogMjBweDtcbiAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwLjM2KTtcbmA7XG5cbmV4cG9ydCBjb25zdCBNb2RhbFBhbmVsID0gc3R5bGVkLnNlY3Rpb25gXG4gIHdpZHRoOiBtaW4oMTAwJSwgNzIwcHgpO1xuICBtYXgtaGVpZ2h0OiBjYWxjKDEwMHN2aCAtIDQwcHgpO1xuICBvdmVyZmxvdzogYXV0bztcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBiYWNrZ3JvdW5kOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy53aGl0ZX07XG4gIGJveC1zaGFkb3c6IDAgMjRweCA3MHB4IHJnYmEoOSwgMzAsIDY2LCAwLjI4KTtcbmA7XG5cbmV4cG9ydCBjb25zdCBNb2RhbEhlYWRlciA9IHN0eWxlZC5oZWFkZXJgXG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIGdhcDogMTZweDtcbiAgcGFkZGluZzogMjBweCAyMnB4O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMuYm9yZGVyfTtcblxuICBoMiB7XG4gICAgbWFyZ2luOiAwO1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgTW9kYWxCb2R5ID0gc3R5bGVkLmRpdmBcbiAgZGlzcGxheTogZ3JpZDtcbiAgZ2FwOiAxNnB4O1xuICBwYWRkaW5nOiAyMnB4O1xuYDtcblxuZXhwb3J0IGNvbnN0IEZvcm1HcmlkID0gc3R5bGVkLmZvcm1gXG4gIGRpc3BsYXk6IGdyaWQ7XG4gIGdyaWQtdGVtcGxhdGUtY29sdW1uczogcmVwZWF0KDIsIG1pbm1heCgwLCAxZnIpKTtcbiAgZ2FwOiAxNHB4O1xuXG4gICR7RmllbGR9OmZpcnN0LWNoaWxkLFxuICAke0ZpZWxkfTpudGgtY2hpbGQoMiksXG4gIC5mdWxsIHtcbiAgICBncmlkLWNvbHVtbjogMSAvIC0xO1xuICB9XG5cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDY0MHB4KSB7XG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxZnI7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBNb2RhbEFjdGlvbnMgPSBzdHlsZWQuZGl2YFxuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xuICBnYXA6IDEwcHg7XG4gIGZsZXgtd3JhcDogd3JhcDtcbiAgcGFkZGluZy10b3A6IDZweDtcbiAgZ3JpZC1jb2x1bW46IDEgLyAtMTtcbmA7XG5cbmV4cG9ydCBjb25zdCBEZXRhaWxHcmlkID0gc3R5bGVkLmRsYFxuICBkaXNwbGF5OiBncmlkO1xuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdCgyLCBtaW5tYXgoMCwgMWZyKSk7XG4gIGdhcDogMTJweDtcbiAgbWFyZ2luOiAwO1xuXG4gIGRpdiB7XG4gICAgZGlzcGxheTogZ3JpZDtcbiAgICBnYXA6IDRweDtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy5ib3JkZXJ9O1xuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICBwYWRkaW5nOiAxMnB4O1xuICB9XG5cbiAgZHQge1xuICAgIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy5kYXJrfTtcbiAgICBmb250LXNpemU6IDEycHg7XG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICB9XG5cbiAgZGQge1xuICAgIG1hcmdpbjogMDtcbiAgICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMudGV4dF9ibGFja307XG4gIH1cblxuICBAbWVkaWEgKG1heC13aWR0aDogNjQwcHgpIHtcbiAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmcjtcbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IFBhZ2luYXRpb24gPSBzdHlsZWQubmF2YFxuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xuICBnYXA6IDEwcHg7XG4gIGZsZXgtd3JhcDogd3JhcDtcbiAgY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLmRhcmt9O1xuYDtcbiJdLCJmaWxlIjoiQzovVXNlcnMvd2FsbGEvRGVza3RvcC9Qcm9qZXRvcy1wZXNzb2Fpcy9wcm92YS10ZWNuaWNhL2Zyb250LW1pbmktdGFzay1tYW5hZ2VyL3NyYy9jb21wb25lbnRzL3Rhc2tzL3N0eWxlcy50cyJ9