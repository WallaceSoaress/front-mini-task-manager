import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/teams/TeamFormModal.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=df6b4f96";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=df6b4f96";
import { useForm, useWatch } from "/node_modules/.vite/deps/react-hook-form.js?v=629faa4b";
import { ValidationError } from "/node_modules/.vite/deps/yup.js?v=d00fe6e5";
import { toTeamRequest, validateTeamForm } from "/src/validations/teams/teamSchema.ts";
import { Button, Field, FieldError, FormGrid, ModalActions, ModalBackdrop, ModalBody, ModalHeader, ModalPanel } from "/src/components/tasks/styles.ts";
import { HelperText } from "/src/components/teams/styles.ts";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/teams/TeamFormModal.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=df6b4f96";
var _s = $RefreshSig$();
const defaultValues = {
	name: "",
	memberIds: []
};
export function TeamFormModal(t0) {
	_s();
	const $ = _c(61);
	if ($[0] !== "c5d5775e4b5b0b399a4927828ed7f62eb022a4bc9f64b83615d5b2cc496eec06") {
		for (let $i = 0; $i < 61; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "c5d5775e4b5b0b399a4927828ed7f62eb022a4bc9f64b83615d5b2cc496eec06";
	}
	const { users, isLoading, isLoadingUsers, usersError, apiError, onClose, onSubmit } = t0;
	const [formError, setFormError] = useState("");
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = { defaultValues };
		$[1] = t1;
	} else {
		t1 = $[1];
	}
	const { control, formState: t2, handleSubmit, register, setError, setValue } = useForm(t1);
	const { errors } = t2;
	const selectedMemberIds = useWatch({
		control,
		name: "memberIds"
	}) ?? [];
	let t3;
	if ($[2] !== onSubmit || $[3] !== selectedMemberIds || $[4] !== setError) {
		t3 = async function submit(data) {
			setFormError("");
			;
			try {
				const validData = await validateTeamForm({
					...data,
					memberIds: selectedMemberIds
				});
				await onSubmit(toTeamRequest(validData));
			} catch (t4) {
				const err = t4;
				if (err instanceof ValidationError) {
					err.inner.forEach((issue) => {
						if (issue.path) {
							setError(issue.path, { message: issue.message });
						}
					});
					return;
				}
				setFormError("Nao foi possivel salvar o time.");
			}
		};
		$[2] = onSubmit;
		$[3] = selectedMemberIds;
		$[4] = setError;
		$[5] = t3;
	} else {
		t3 = $[5];
	}
	const submit = t3;
	let t4;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
			id: "team-form-title",
			children: "Novo Time"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 101,
			columnNumber: 15
		}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Cadastre um time e selecione os membros disponiveis." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 101,
			columnNumber: 54
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 101,
			columnNumber: 10
		}, this);
		$[6] = t4;
	} else {
		t4 = $[6];
	}
	let t5;
	if ($[7] !== isLoading || $[8] !== onClose) {
		t5 = /* @__PURE__ */ _jsxDEV(ModalHeader, { children: [t4, /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			$variant: "ghost",
			onClick: onClose,
			disabled: isLoading,
			children: "Fechar"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 108,
			columnNumber: 27
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 108,
			columnNumber: 10
		}, this);
		$[7] = isLoading;
		$[8] = onClose;
		$[9] = t5;
	} else {
		t5 = $[9];
	}
	let t6;
	if ($[10] !== handleSubmit || $[11] !== submit) {
		t6 = handleSubmit(submit);
		$[10] = handleSubmit;
		$[11] = submit;
		$[12] = t6;
	} else {
		t6 = $[12];
	}
	let t7;
	if ($[13] !== register) {
		t7 = register("name");
		$[13] = register;
		$[14] = t7;
	} else {
		t7 = $[14];
	}
	let t8;
	if ($[15] !== t7) {
		t8 = /* @__PURE__ */ _jsxDEV("input", {
			...t7,
			autoFocus: true,
			maxLength: 120,
			placeholder: "Time Front-end"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 134,
			columnNumber: 10
		}, this);
		$[15] = t7;
		$[16] = t8;
	} else {
		t8 = $[16];
	}
	let t9;
	if ($[17] !== errors.name) {
		t9 = errors.name?.message ? /* @__PURE__ */ _jsxDEV(FieldError, { children: errors.name.message }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 142,
			columnNumber: 33
		}, this) : null;
		$[17] = errors.name;
		$[18] = t9;
	} else {
		t9 = $[18];
	}
	let t10;
	if ($[19] !== t8 || $[20] !== t9) {
		t10 = /* @__PURE__ */ _jsxDEV(Field, {
			className: "full",
			children: [
				"Nome do time",
				t8,
				t9
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 150,
			columnNumber: 11
		}, this);
		$[19] = t8;
		$[20] = t9;
		$[21] = t10;
	} else {
		t10 = $[21];
	}
	const t11 = Math.min(Math.max(users.length, 3), 8);
	let t12;
	if ($[22] !== setValue) {
		t12 = (event) => {
			const memberIds = Array.from(event.currentTarget.selectedOptions, _temp);
			setValue("memberIds", memberIds, {
				shouldDirty: true,
				shouldValidate: true
			});
		};
		$[22] = setValue;
		$[23] = t12;
	} else {
		t12 = $[23];
	}
	const t13 = isLoadingUsers || Boolean(usersError);
	let t14;
	if ($[24] !== users) {
		t14 = users.map(_temp2);
		$[24] = users;
		$[25] = t14;
	} else {
		t14 = $[25];
	}
	let t15;
	if ($[26] !== selectedMemberIds || $[27] !== t11 || $[28] !== t12 || $[29] !== t13 || $[30] !== t14) {
		t15 = /* @__PURE__ */ _jsxDEV("select", {
			multiple: true,
			size: t11,
			value: selectedMemberIds,
			onChange: t12,
			disabled: t13,
			children: t14
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 183,
			columnNumber: 11
		}, this);
		$[26] = selectedMemberIds;
		$[27] = t11;
		$[28] = t12;
		$[29] = t13;
		$[30] = t14;
		$[31] = t15;
	} else {
		t15 = $[31];
	}
	const t16 = usersError || (isLoadingUsers ? "Carregando usuarios..." : "Selecione um ou mais membros. Este campo e opcional.");
	let t17;
	if ($[32] !== t16) {
		t17 = /* @__PURE__ */ _jsxDEV(HelperText, { children: t16 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 196,
			columnNumber: 11
		}, this);
		$[32] = t16;
		$[33] = t17;
	} else {
		t17 = $[33];
	}
	let t18;
	if ($[34] !== errors.memberIds) {
		t18 = errors.memberIds?.message ? /* @__PURE__ */ _jsxDEV(FieldError, { children: errors.memberIds.message }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 204,
			columnNumber: 39
		}, this) : null;
		$[34] = errors.memberIds;
		$[35] = t18;
	} else {
		t18 = $[35];
	}
	let t19;
	if ($[36] !== t15 || $[37] !== t17 || $[38] !== t18) {
		t19 = /* @__PURE__ */ _jsxDEV(Field, {
			className: "full",
			children: [
				"Membros",
				t15,
				t17,
				t18
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 212,
			columnNumber: 11
		}, this);
		$[36] = t15;
		$[37] = t17;
		$[38] = t18;
		$[39] = t19;
	} else {
		t19 = $[39];
	}
	let t20;
	if ($[40] !== apiError || $[41] !== formError) {
		t20 = apiError || formError ? /* @__PURE__ */ _jsxDEV(FieldError, {
			className: "full",
			children: apiError || formError
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 222,
			columnNumber: 35
		}, this) : null;
		$[40] = apiError;
		$[41] = formError;
		$[42] = t20;
	} else {
		t20 = $[42];
	}
	let t21;
	if ($[43] !== isLoading || $[44] !== onClose) {
		t21 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			$variant: "ghost",
			onClick: onClose,
			disabled: isLoading,
			children: "Cancelar"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 231,
			columnNumber: 11
		}, this);
		$[43] = isLoading;
		$[44] = onClose;
		$[45] = t21;
	} else {
		t21 = $[45];
	}
	const t22 = isLoading ? "Salvando..." : "Salvar";
	let t23;
	if ($[46] !== isLoading || $[47] !== t22) {
		t23 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "submit",
			disabled: isLoading,
			children: t22
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 241,
			columnNumber: 11
		}, this);
		$[46] = isLoading;
		$[47] = t22;
		$[48] = t23;
	} else {
		t23 = $[48];
	}
	let t24;
	if ($[49] !== t21 || $[50] !== t23) {
		t24 = /* @__PURE__ */ _jsxDEV(ModalActions, { children: [t21, t23] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 250,
			columnNumber: 11
		}, this);
		$[49] = t21;
		$[50] = t23;
		$[51] = t24;
	} else {
		t24 = $[51];
	}
	let t25;
	if ($[52] !== t10 || $[53] !== t19 || $[54] !== t20 || $[55] !== t24 || $[56] !== t6) {
		t25 = /* @__PURE__ */ _jsxDEV(ModalBody, { children: /* @__PURE__ */ _jsxDEV(FormGrid, {
			onSubmit: t6,
			children: [
				t10,
				t19,
				t20,
				t24
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 259,
			columnNumber: 22
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 259,
			columnNumber: 11
		}, this);
		$[52] = t10;
		$[53] = t19;
		$[54] = t20;
		$[55] = t24;
		$[56] = t6;
		$[57] = t25;
	} else {
		t25 = $[57];
	}
	let t26;
	if ($[58] !== t25 || $[59] !== t5) {
		t26 = /* @__PURE__ */ _jsxDEV(ModalBackdrop, {
			role: "presentation",
			children: /* @__PURE__ */ _jsxDEV(ModalPanel, {
				role: "dialog",
				"aria-modal": "true",
				"aria-labelledby": "team-form-title",
				children: [t5, t25]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 271,
				columnNumber: 46
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 271,
			columnNumber: 11
		}, this);
		$[58] = t25;
		$[59] = t5;
		$[60] = t26;
	} else {
		t26 = $[60];
	}
	return t26;
}
_s(TeamFormModal, "le6xYMK3C+1DafnUn/stzWU6eYs=", false, function() {
	return [useForm, useWatch];
});
_c2 = TeamFormModal;
function _temp2(user) {
	return /* @__PURE__ */ _jsxDEV("option", {
		value: user.id,
		children: [
			user.name,
			" - ",
			user.email
		]
	}, user.id, true, {
		fileName: _jsxFileName,
		lineNumber: 281,
		columnNumber: 10
	}, this);
}
function _temp(option) {
	return option.value;
}
var _c2;
$RefreshReg$(_c2, "TeamFormModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/teams/TeamFormModal.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/teams/TeamFormModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/teams/TeamFormModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/teams/TeamFormModal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxTQUFTQyxnQkFBZ0I7QUFDbEMsU0FBU0MsdUJBQXVCO0FBR2hDLFNBQVNDLGVBQWVDLHdCQUF3QjtBQUNoRCxTQUFTQyxRQUFRQyxPQUFPQyxZQUFZQyxVQUFVQyxjQUFjQyxlQUFlQyxXQUFXQyxhQUFhQyxrQkFBa0I7QUFDckgsU0FBU0Msa0JBQWtCOzs7O0FBWTNCLE1BQU1DLGdCQUE4QjtDQUNsQ0MsTUFBTTtDQUNOQyxXQUFXO0FBQ2I7QUFFQSxPQUFPLFNBQUFDLGNBQUFDLElBQUE7O0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsSUFBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQXVCLFFBQUFLLE9BQUFDLFdBQUFDLGdCQUFBQyxZQUFBQyxVQUFBQyxTQUFBQyxhQUFBWjtDQUM1QixPQUFBYSxXQUFBQyxnQkFBa0NsQyxTQUFTLEVBQUU7Q0FBRSxJQUFBbUM7Q0FBQSxJQUFBZCxFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFRckJVLEtBQUEsRUFBQW5CLGNBRTFCO0VBQUNLLEVBQUEsS0FBQWM7Q0FBQTtFQUFBQSxLQUFBZCxFQUFBO0NBQUE7Q0FURCxRQUFBZSxTQUFBQyxXQUFBQyxJQUFBQyxjQUFBQyxVQUFBQyxVQUFBQyxhQU9JekMsUUFBc0JrQyxFQUV6QjtDQVBZLFFBQUFRLFdBQUFMO0NBUWIsTUFBQU0sb0JBQTBCMUMsU0FBUztFQUFBa0M7RUFBQW5CLE1BQWlCO0NBQVksQ0FBTyxLQUE3QztDQUErQyxJQUFBNEI7Q0FBQSxJQUFBeEIsRUFBQSxPQUFBVyxZQUFBWCxFQUFBLE9BQUF1QixxQkFBQXZCLEVBQUEsT0FBQW9CLFVBQUE7RUFFekVJLEtBQUEsZUFBQUMsT0FBQUMsTUFBQTtHQUNFYixhQUFhLEVBQUU7R0FBQztHQUVoQjtJQUNFLE1BQUFjLFlBQWtCLE1BQU0zQyxpQkFBaUI7S0FBQSxHQUNwQzBDO0tBQUk3QixXQUNJMEI7SUFDYixDQUFDO0lBQ0QsTUFBTVosU0FBUzVCLGNBQWM0QyxTQUFTLENBQUM7R0FBQyxTQUFBQyxJQUFBO0lBQ2pDQztJQUNQLElBQUlBLGVBQWUvQyxpQkFBZTtLQUNoQytDLElBQUdDLE1BQU1DLFNBQVNDLFVBQUE7TUFDaEIsSUFBSUEsTUFBS0MsTUFBSztPQUNaYixTQUFTWSxNQUFLQyxNQUE2QixFQUFBQyxTQUFXRixNQUFLRSxRQUFTLENBQUM7TUFBQztLQUN2RSxDQUNGO0tBQUM7SUFBQTtJQUlKckIsYUFBYSxpQ0FBaUM7R0FBQztFQUNoRDtFQUNGYixFQUFBLEtBQUFXO0VBQUFYLEVBQUEsS0FBQXVCO0VBQUF2QixFQUFBLEtBQUFvQjtFQUFBcEIsRUFBQSxLQUFBd0I7Q0FBQTtFQUFBQSxLQUFBeEIsRUFBQTtDQUFBO0NBckJELE1BQUF5QixTQUFBRDtDQXFCQyxJQUFBSTtDQUFBLElBQUE1QixFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFNT3dCLEtBQUEsNENBQ0U7R0FBTzthQUFrQjtFQUFjOzs7O1lBQ3ZDLHlDQUFHLHVEQUF3RDs7OztVQUN2RDs7Ozs7RUFBQTVCLEVBQUEsS0FBQTRCO0NBQUE7RUFBQUEsS0FBQTVCLEVBQUE7Q0FBQTtDQUFBLElBQUFtQztDQUFBLElBQUFuQyxFQUFBLE9BQUFNLGFBQUFOLEVBQUEsT0FBQVUsU0FBQTtFQUpSeUIsS0FBQSx3QkFBQyxhQUFELGFBQ0VQLElBSUEsd0JBQUMsUUFBRDtHQUFhO0dBQWtCO0dBQWlCbEI7R0FBbUJKO2FBQVc7RUFBdkU7Ozs7VUFMRzs7Ozs7RUFRRU4sRUFBQSxLQUFBTTtFQUFBTixFQUFBLEtBQUFVO0VBQUFWLEVBQUEsS0FBQW1DO0NBQUE7RUFBQUEsS0FBQW5DLEVBQUE7Q0FBQTtDQUFBLElBQUFvQztDQUFBLElBQUFwQyxFQUFBLFFBQUFrQixnQkFBQWxCLEVBQUEsUUFBQXlCLFFBQUE7RUFHUVcsS0FBQWxCLGFBQWFPLE1BQU07RUFBQ3pCLEVBQUEsTUFBQWtCO0VBQUFsQixFQUFBLE1BQUF5QjtFQUFBekIsRUFBQSxNQUFBb0M7Q0FBQTtFQUFBQSxLQUFBcEMsRUFBQTtDQUFBO0NBQUEsSUFBQXFDO0NBQUEsSUFBQXJDLEVBQUEsUUFBQW1CLFVBQUE7RUFHekJrQixLQUFBbEIsU0FBUyxNQUFNO0VBQUNuQixFQUFBLE1BQUFtQjtFQUFBbkIsRUFBQSxNQUFBcUM7Q0FBQTtFQUFBQSxLQUFBckMsRUFBQTtDQUFBO0NBQUEsSUFBQXNDO0NBQUEsSUFBQXRDLEVBQUEsUUFBQXFDLElBQUE7RUFBM0JDLEtBQUE7R0FBc0YsR0FBM0VEO0dBQWtCO0dBQXFCO0dBQWlCO0VBQWdCOzs7OztFQUFHckMsRUFBQSxNQUFBcUM7RUFBQXJDLEVBQUEsTUFBQXNDO0NBQUE7RUFBQUEsS0FBQXRDLEVBQUE7Q0FBQTtDQUFBLElBQUF1QztDQUFBLElBQUF2QyxFQUFBLFFBQUFzQixPQUFBMUIsTUFBQTtFQUNyRjJDLEtBQUFqQixPQUFNMUIsTUFBY3NDLFVBQUcsd0JBQUMsWUFBRCxZQUFhWixPQUFNMUIsS0FBS3NDLFFBQWI7Ozs7YUFBbEM7RUFBNEVsQyxFQUFBLE1BQUFzQixPQUFBMUI7RUFBQUksRUFBQSxNQUFBdUM7Q0FBQTtFQUFBQSxLQUFBdkMsRUFBQTtDQUFBO0NBQUEsSUFBQXdDO0NBQUEsSUFBQXhDLEVBQUEsUUFBQXNDLE1BQUF0QyxFQUFBLFFBQUF1QyxJQUFBO0VBSC9FQyxNQUFBLHdCQUFDLE9BQUQ7R0FBaUI7YUFBakI7SUFBd0I7SUFFdEJGO0lBQ0NDO0dBSEc7Ozs7OztFQUlFdkMsRUFBQSxNQUFBc0M7RUFBQXRDLEVBQUEsTUFBQXVDO0VBQUF2QyxFQUFBLE1BQUF3QztDQUFBO0VBQUFBLE1BQUF4QyxFQUFBO0NBQUE7Q0FNRSxNQUFBeUMsTUFBQUMsS0FBSUMsSUFBS0QsS0FBSUUsSUFBS3ZDLE1BQUt3QyxRQUFTLENBQUMsR0FBRyxDQUFDO0NBQUMsSUFBQUM7Q0FBQSxJQUFBOUMsRUFBQSxRQUFBcUIsVUFBQTtFQUVsQ3lCLE9BQUFDLFVBQUE7R0FDUixNQUFBbEQsWUFBa0JtRCxNQUFLQyxLQUFNRixNQUFLRyxjQUFjQyxpQkFBa0JDLEtBQXdCO0dBQzFGL0IsU0FBUyxhQUFheEIsV0FBVztJQUFBd0QsYUFBZTtJQUFJQyxnQkFBa0I7R0FBSyxDQUFDO0VBQUM7RUFDOUV0RCxFQUFBLE1BQUFxQjtFQUFBckIsRUFBQSxNQUFBOEM7Q0FBQTtFQUFBQSxNQUFBOUMsRUFBQTtDQUFBO0NBQ1MsTUFBQXVELE1BQUFoRCxrQkFBa0JpRCxRQUFRaEQsVUFBVTtDQUFDLElBQUFpRDtDQUFBLElBQUF6RCxFQUFBLFFBQUFLLE9BQUE7RUFFOUNvRCxNQUFBcEQsTUFBS3FELElBQUtDLE1BSVY7RUFBQzNELEVBQUEsTUFBQUs7RUFBQUwsRUFBQSxNQUFBeUQ7Q0FBQTtFQUFBQSxNQUFBekQsRUFBQTtDQUFBO0NBQUEsSUFBQTREO0NBQUEsSUFBQTVELEVBQUEsUUFBQXVCLHFCQUFBdkIsRUFBQSxRQUFBeUMsT0FBQXpDLEVBQUEsUUFBQThDLE9BQUE5QyxFQUFBLFFBQUF1RCxPQUFBdkQsRUFBQSxRQUFBeUQsS0FBQTtFQWRKRyxNQUFBO0dBQ0U7R0FDTSxNQUFBbkI7R0FDQ2xCO0dBQ0csVUFBQXVCO0dBSUEsVUFBQVM7YUFFVEU7RUFLTTs7Ozs7RUFBQXpELEVBQUEsTUFBQXVCO0VBQUF2QixFQUFBLE1BQUF5QztFQUFBekMsRUFBQSxNQUFBOEM7RUFBQTlDLEVBQUEsTUFBQXVEO0VBQUF2RCxFQUFBLE1BQUF5RDtFQUFBekQsRUFBQSxNQUFBNEQ7Q0FBQTtFQUFBQSxNQUFBNUQsRUFBQTtDQUFBO0NBRU4sTUFBQTZELE1BQUFyRCxlQUNFRCxpQkFBQTtDQUUwRCxJQUFBdUQ7Q0FBQSxJQUFBOUQsRUFBQSxRQUFBNkQsS0FBQTtFQUovREMsTUFBQSx3QkFBQyxZQUFELFlBQ0dELElBRFE7Ozs7O0VBS0U3RCxFQUFBLE1BQUE2RDtFQUFBN0QsRUFBQSxNQUFBOEQ7Q0FBQTtFQUFBQSxNQUFBOUQsRUFBQTtDQUFBO0NBQUEsSUFBQStEO0NBQUEsSUFBQS9ELEVBQUEsUUFBQXNCLE9BQUF6QixXQUFBO0VBQ1prRSxNQUFBekMsT0FBTXpCLFdBQW1CcUMsVUFBRyx3QkFBQyxZQUFELFlBQWFaLE9BQU16QixVQUFVcUMsUUFBbEI7Ozs7YUFBdkM7RUFBc0ZsQyxFQUFBLE1BQUFzQixPQUFBekI7RUFBQUcsRUFBQSxNQUFBK0Q7Q0FBQTtFQUFBQSxNQUFBL0QsRUFBQTtDQUFBO0NBQUEsSUFBQWdFO0NBQUEsSUFBQWhFLEVBQUEsUUFBQTRELE9BQUE1RCxFQUFBLFFBQUE4RCxPQUFBOUQsRUFBQSxRQUFBK0QsS0FBQTtFQXhCekZDLE1BQUEsd0JBQUMsT0FBRDtHQUFpQjthQUFqQjtJQUF3QjtJQUV0Qko7SUFnQkFFO0lBTUNDO0dBeEJHOzs7Ozs7RUF5QkUvRCxFQUFBLE1BQUE0RDtFQUFBNUQsRUFBQSxNQUFBOEQ7RUFBQTlELEVBQUEsTUFBQStEO0VBQUEvRCxFQUFBLE1BQUFnRTtDQUFBO0VBQUFBLE1BQUFoRSxFQUFBO0NBQUE7Q0FBQSxJQUFBaUU7Q0FBQSxJQUFBakUsRUFBQSxRQUFBUyxZQUFBVCxFQUFBLFFBQUFZLFdBQUE7RUFFUHFELE1BQUF4RCxZQUFBRyxZQUF3Qix3QkFBQyxZQUFEO0dBQXNCO2FBQVFILFlBQUFHO0VBQW5COzs7O2FBQW5DO0VBQWdHWixFQUFBLE1BQUFTO0VBQUFULEVBQUEsTUFBQVk7RUFBQVosRUFBQSxNQUFBaUU7Q0FBQTtFQUFBQSxNQUFBakUsRUFBQTtDQUFBO0NBQUEsSUFBQWtFO0NBQUEsSUFBQWxFLEVBQUEsUUFBQU0sYUFBQU4sRUFBQSxRQUFBVSxTQUFBO0VBRy9Gd0QsTUFBQSx3QkFBQyxRQUFEO0dBQWE7R0FBa0I7R0FBaUJ4RDtHQUFtQko7YUFBVztFQUF2RTs7Ozs7RUFFRU4sRUFBQSxNQUFBTTtFQUFBTixFQUFBLE1BQUFVO0VBQUFWLEVBQUEsTUFBQWtFO0NBQUE7RUFBQUEsTUFBQWxFLEVBQUE7Q0FBQTtDQUVOLE1BQUFtRSxNQUFBN0QsWUFBQTtDQUFvQyxJQUFBOEQ7Q0FBQSxJQUFBcEUsRUFBQSxRQUFBTSxhQUFBTixFQUFBLFFBQUFtRSxLQUFBO0VBRHZDQyxNQUFBLHdCQUFDLFFBQUQ7R0FBYTtHQUFtQjlEO2FBQzdCNkQ7RUFESTs7Ozs7RUFFRW5FLEVBQUEsTUFBQU07RUFBQU4sRUFBQSxNQUFBbUU7RUFBQW5FLEVBQUEsTUFBQW9FO0NBQUE7RUFBQUEsTUFBQXBFLEVBQUE7Q0FBQTtDQUFBLElBQUFxRTtDQUFBLElBQUFyRSxFQUFBLFFBQUFrRSxPQUFBbEUsRUFBQSxRQUFBb0UsS0FBQTtFQU5YQyxNQUFBLHdCQUFDLGNBQUQsYUFDRUgsS0FHQUUsR0FKVzs7Ozs7RUFPRXBFLEVBQUEsTUFBQWtFO0VBQUFsRSxFQUFBLE1BQUFvRTtFQUFBcEUsRUFBQSxNQUFBcUU7Q0FBQTtFQUFBQSxNQUFBckUsRUFBQTtDQUFBO0NBQUEsSUFBQXNFO0NBQUEsSUFBQXRFLEVBQUEsUUFBQXdDLE9BQUF4QyxFQUFBLFFBQUFnRSxPQUFBaEUsRUFBQSxRQUFBaUUsT0FBQWpFLEVBQUEsUUFBQXFFLE9BQUFyRSxFQUFBLFFBQUFvQyxJQUFBO0VBNUNuQmtDLE1BQUEsd0JBQUMsV0FBRCxZQUNFLHdCQUFDLFVBQUQ7R0FBb0IsVUFBQWxDO2FBQXBCO0lBQ0VJO0lBTUF3QjtJQTJCQ0M7SUFFREk7R0FwQ087Ozs7O1dBREQ7Ozs7O0VBOENFckUsRUFBQSxNQUFBd0M7RUFBQXhDLEVBQUEsTUFBQWdFO0VBQUFoRSxFQUFBLE1BQUFpRTtFQUFBakUsRUFBQSxNQUFBcUU7RUFBQXJFLEVBQUEsTUFBQW9DO0VBQUFwQyxFQUFBLE1BQUFzRTtDQUFBO0VBQUFBLE1BQUF0RSxFQUFBO0NBQUE7Q0FBQSxJQUFBdUU7Q0FBQSxJQUFBdkUsRUFBQSxRQUFBc0UsT0FBQXRFLEVBQUEsUUFBQW1DLElBQUE7RUExRGhCb0MsTUFBQSx3QkFBQyxlQUFEO0dBQW9CO2FBQ2xCLHdCQUFDLFlBQUQ7SUFBaUI7SUFBb0I7SUFBdUI7Y0FBNUQsQ0FDRXBDLElBVUFtQyxHQVhTOzs7Ozs7RUFEQzs7Ozs7RUE0REV0RSxFQUFBLE1BQUFzRTtFQUFBdEUsRUFBQSxNQUFBbUM7RUFBQW5DLEVBQUEsTUFBQXVFO0NBQUE7RUFBQUEsTUFBQXZFLEVBQUE7Q0FBQTtDQUFBLE9BNURoQnVFO0FBNERnQjs7Ozs7QUFsR2IsU0FBQVosT0FBQWEsTUFBQTtDQUFBLE9BdUVXO0VBQTZCLE9BQUFBLEtBQUlDO1lBQWpDO0dBQ0dELEtBQUk1RTtHQUFNO0dBQUk0RSxLQUFJRTtFQUNaO0lBRklGLEtBQUlDOzs7O1FBRVI7QUFBQTtBQXpFcEIsU0FBQXJCLE1BQUF1QixRQUFBO0NBQUEsT0FpRXlGQSxPQUFNQztBQUFNIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VGb3JtIiwidXNlV2F0Y2giLCJWYWxpZGF0aW9uRXJyb3IiLCJ0b1RlYW1SZXF1ZXN0IiwidmFsaWRhdGVUZWFtRm9ybSIsIkJ1dHRvbiIsIkZpZWxkIiwiRmllbGRFcnJvciIsIkZvcm1HcmlkIiwiTW9kYWxBY3Rpb25zIiwiTW9kYWxCYWNrZHJvcCIsIk1vZGFsQm9keSIsIk1vZGFsSGVhZGVyIiwiTW9kYWxQYW5lbCIsIkhlbHBlclRleHQiLCJkZWZhdWx0VmFsdWVzIiwibmFtZSIsIm1lbWJlcklkcyIsIlRlYW1Gb3JtTW9kYWwiLCJ0MCIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwidXNlcnMiLCJpc0xvYWRpbmciLCJpc0xvYWRpbmdVc2VycyIsInVzZXJzRXJyb3IiLCJhcGlFcnJvciIsIm9uQ2xvc2UiLCJvblN1Ym1pdCIsImZvcm1FcnJvciIsInNldEZvcm1FcnJvciIsInQxIiwiY29udHJvbCIsImZvcm1TdGF0ZSIsInQyIiwiaGFuZGxlU3VibWl0IiwicmVnaXN0ZXIiLCJzZXRFcnJvciIsInNldFZhbHVlIiwiZXJyb3JzIiwic2VsZWN0ZWRNZW1iZXJJZHMiLCJ0MyIsInN1Ym1pdCIsImRhdGEiLCJ2YWxpZERhdGEiLCJ0NCIsImVyciIsImlubmVyIiwiZm9yRWFjaCIsImlzc3VlIiwicGF0aCIsIm1lc3NhZ2UiLCJ0NSIsInQ2IiwidDciLCJ0OCIsInQ5IiwidDEwIiwidDExIiwiTWF0aCIsIm1pbiIsIm1heCIsImxlbmd0aCIsInQxMiIsImV2ZW50IiwiQXJyYXkiLCJmcm9tIiwiY3VycmVudFRhcmdldCIsInNlbGVjdGVkT3B0aW9ucyIsIl90ZW1wIiwic2hvdWxkRGlydHkiLCJzaG91bGRWYWxpZGF0ZSIsInQxMyIsIkJvb2xlYW4iLCJ0MTQiLCJtYXAiLCJfdGVtcDIiLCJ0MTUiLCJ0MTYiLCJ0MTciLCJ0MTgiLCJ0MTkiLCJ0MjAiLCJ0MjEiLCJ0MjIiLCJ0MjMiLCJ0MjQiLCJ0MjUiLCJ0MjYiLCJ1c2VyIiwiaWQiLCJlbWFpbCIsIm9wdGlvbiIsInZhbHVlIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlRlYW1Gb3JtTW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VGb3JtLCB1c2VXYXRjaCB9IGZyb20gXCJyZWFjdC1ob29rLWZvcm1cIjtcbmltcG9ydCB7IFZhbGlkYXRpb25FcnJvciB9IGZyb20gXCJ5dXBcIjtcbmltcG9ydCB0eXBlIHsgVXNlciB9IGZyb20gXCIuLi8uLi9pbnRlcmZhY2VzL3Rhc2tzL3VzZXJcIjtcbmltcG9ydCB0eXBlIHsgVGVhbUZvcm1EYXRhIH0gZnJvbSBcIi4uLy4uL3ZhbGlkYXRpb25zL3RlYW1zL3RlYW1TY2hlbWFcIjtcbmltcG9ydCB7IHRvVGVhbVJlcXVlc3QsIHZhbGlkYXRlVGVhbUZvcm0gfSBmcm9tIFwiLi4vLi4vdmFsaWRhdGlvbnMvdGVhbXMvdGVhbVNjaGVtYVwiO1xuaW1wb3J0IHsgQnV0dG9uLCBGaWVsZCwgRmllbGRFcnJvciwgRm9ybUdyaWQsIE1vZGFsQWN0aW9ucywgTW9kYWxCYWNrZHJvcCwgTW9kYWxCb2R5LCBNb2RhbEhlYWRlciwgTW9kYWxQYW5lbCB9IGZyb20gXCIuLi90YXNrcy9zdHlsZXNcIjtcbmltcG9ydCB7IEhlbHBlclRleHQgfSBmcm9tIFwiLi9zdHlsZXNcIjtcblxudHlwZSBUZWFtRm9ybU1vZGFsUHJvcHMgPSB7XG4gIHVzZXJzOiBVc2VyW107XG4gIGlzTG9hZGluZz86IGJvb2xlYW47XG4gIGlzTG9hZGluZ1VzZXJzPzogYm9vbGVhbjtcbiAgdXNlcnNFcnJvcj86IHN0cmluZztcbiAgYXBpRXJyb3I/OiBzdHJpbmc7XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG4gIG9uU3VibWl0OiAoZGF0YTogUmV0dXJuVHlwZTx0eXBlb2YgdG9UZWFtUmVxdWVzdD4pID0+IFByb21pc2U8dm9pZD47XG59O1xuXG5jb25zdCBkZWZhdWx0VmFsdWVzOiBUZWFtRm9ybURhdGEgPSB7XG4gIG5hbWU6IFwiXCIsXG4gIG1lbWJlcklkczogW10sXG59O1xuXG5leHBvcnQgZnVuY3Rpb24gVGVhbUZvcm1Nb2RhbCh7IHVzZXJzLCBpc0xvYWRpbmcsIGlzTG9hZGluZ1VzZXJzLCB1c2Vyc0Vycm9yLCBhcGlFcnJvciwgb25DbG9zZSwgb25TdWJtaXQgfTogVGVhbUZvcm1Nb2RhbFByb3BzKSB7XG4gIGNvbnN0IFtmb3JtRXJyb3IsIHNldEZvcm1FcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3Qge1xuICAgIGNvbnRyb2wsXG4gICAgZm9ybVN0YXRlOiB7IGVycm9ycyB9LFxuICAgIGhhbmRsZVN1Ym1pdCxcbiAgICByZWdpc3RlcixcbiAgICBzZXRFcnJvcixcbiAgICBzZXRWYWx1ZSxcbiAgfSA9IHVzZUZvcm08VGVhbUZvcm1EYXRhPih7XG4gICAgZGVmYXVsdFZhbHVlcyxcbiAgfSk7XG4gIGNvbnN0IHNlbGVjdGVkTWVtYmVySWRzID0gdXNlV2F0Y2goeyBjb250cm9sLCBuYW1lOiBcIm1lbWJlcklkc1wiIH0pID8/IFtdO1xuXG4gIGFzeW5jIGZ1bmN0aW9uIHN1Ym1pdChkYXRhOiBUZWFtRm9ybURhdGEpIHtcbiAgICBzZXRGb3JtRXJyb3IoXCJcIik7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgdmFsaWREYXRhID0gYXdhaXQgdmFsaWRhdGVUZWFtRm9ybSh7XG4gICAgICAgIC4uLmRhdGEsXG4gICAgICAgIG1lbWJlcklkczogc2VsZWN0ZWRNZW1iZXJJZHMsXG4gICAgICB9KTtcbiAgICAgIGF3YWl0IG9uU3VibWl0KHRvVGVhbVJlcXVlc3QodmFsaWREYXRhKSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBpZiAoZXJyIGluc3RhbmNlb2YgVmFsaWRhdGlvbkVycm9yKSB7XG4gICAgICAgIGVyci5pbm5lci5mb3JFYWNoKChpc3N1ZSkgPT4ge1xuICAgICAgICAgIGlmIChpc3N1ZS5wYXRoKSB7XG4gICAgICAgICAgICBzZXRFcnJvcihpc3N1ZS5wYXRoIGFzIGtleW9mIFRlYW1Gb3JtRGF0YSwgeyBtZXNzYWdlOiBpc3N1ZS5tZXNzYWdlIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgc2V0Rm9ybUVycm9yKFwiTmFvIGZvaSBwb3NzaXZlbCBzYWx2YXIgbyB0aW1lLlwiKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxNb2RhbEJhY2tkcm9wIHJvbGU9XCJwcmVzZW50YXRpb25cIj5cbiAgICAgIDxNb2RhbFBhbmVsIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiIGFyaWEtbGFiZWxsZWRieT1cInRlYW0tZm9ybS10aXRsZVwiPlxuICAgICAgICA8TW9kYWxIZWFkZXI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMiBpZD1cInRlYW0tZm9ybS10aXRsZVwiPk5vdm8gVGltZTwvaDI+XG4gICAgICAgICAgICA8cD5DYWRhc3RyZSB1bSB0aW1lIGUgc2VsZWNpb25lIG9zIG1lbWJyb3MgZGlzcG9uaXZlaXMuPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiICR2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXtvbkNsb3NlfSBkaXNhYmxlZD17aXNMb2FkaW5nfT5cbiAgICAgICAgICAgIEZlY2hhclxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L01vZGFsSGVhZGVyPlxuXG4gICAgICAgIDxNb2RhbEJvZHk+XG4gICAgICAgICAgPEZvcm1HcmlkIG9uU3VibWl0PXtoYW5kbGVTdWJtaXQoc3VibWl0KX0+XG4gICAgICAgICAgICA8RmllbGQgY2xhc3NOYW1lPVwiZnVsbFwiPlxuICAgICAgICAgICAgICBOb21lIGRvIHRpbWVcbiAgICAgICAgICAgICAgPGlucHV0IHsuLi5yZWdpc3RlcihcIm5hbWVcIil9IGF1dG9Gb2N1cyBtYXhMZW5ndGg9ezEyMH0gcGxhY2Vob2xkZXI9XCJUaW1lIEZyb250LWVuZFwiIC8+XG4gICAgICAgICAgICAgIHtlcnJvcnMubmFtZT8ubWVzc2FnZSA/IDxGaWVsZEVycm9yPntlcnJvcnMubmFtZS5tZXNzYWdlfTwvRmllbGRFcnJvcj4gOiBudWxsfVxuICAgICAgICAgICAgPC9GaWVsZD5cblxuICAgICAgICAgICAgPEZpZWxkIGNsYXNzTmFtZT1cImZ1bGxcIj5cbiAgICAgICAgICAgICAgTWVtYnJvc1xuICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgbXVsdGlwbGVcbiAgICAgICAgICAgICAgICBzaXplPXtNYXRoLm1pbihNYXRoLm1heCh1c2Vycy5sZW5ndGgsIDMpLCA4KX1cbiAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRNZW1iZXJJZHN9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgbWVtYmVySWRzID0gQXJyYXkuZnJvbShldmVudC5jdXJyZW50VGFyZ2V0LnNlbGVjdGVkT3B0aW9ucywgKG9wdGlvbikgPT4gb3B0aW9uLnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgIHNldFZhbHVlKFwibWVtYmVySWRzXCIsIG1lbWJlcklkcywgeyBzaG91bGREaXJ0eTogdHJ1ZSwgc2hvdWxkVmFsaWRhdGU6IHRydWUgfSk7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNMb2FkaW5nVXNlcnMgfHwgQm9vbGVhbih1c2Vyc0Vycm9yKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXt1c2VyLmlkfSB2YWx1ZT17dXNlci5pZH0+XG4gICAgICAgICAgICAgICAgICAgIHt1c2VyLm5hbWV9IC0ge3VzZXIuZW1haWx9XG4gICAgICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgIDxIZWxwZXJUZXh0PlxuICAgICAgICAgICAgICAgIHt1c2Vyc0Vycm9yIHx8XG4gICAgICAgICAgICAgICAgICAoaXNMb2FkaW5nVXNlcnNcbiAgICAgICAgICAgICAgICAgICAgPyBcIkNhcnJlZ2FuZG8gdXN1YXJpb3MuLi5cIlxuICAgICAgICAgICAgICAgICAgICA6IFwiU2VsZWNpb25lIHVtIG91IG1haXMgbWVtYnJvcy4gRXN0ZSBjYW1wbyBlIG9wY2lvbmFsLlwiKX1cbiAgICAgICAgICAgICAgPC9IZWxwZXJUZXh0PlxuICAgICAgICAgICAgICB7ZXJyb3JzLm1lbWJlcklkcz8ubWVzc2FnZSA/IDxGaWVsZEVycm9yPntlcnJvcnMubWVtYmVySWRzLm1lc3NhZ2V9PC9GaWVsZEVycm9yPiA6IG51bGx9XG4gICAgICAgICAgICA8L0ZpZWxkPlxuXG4gICAgICAgICAgICB7YXBpRXJyb3IgfHwgZm9ybUVycm9yID8gPEZpZWxkRXJyb3IgY2xhc3NOYW1lPVwiZnVsbFwiPnthcGlFcnJvciB8fCBmb3JtRXJyb3J9PC9GaWVsZEVycm9yPiA6IG51bGx9XG5cbiAgICAgICAgICAgIDxNb2RhbEFjdGlvbnM+XG4gICAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiICR2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXtvbkNsb3NlfSBkaXNhYmxlZD17aXNMb2FkaW5nfT5cbiAgICAgICAgICAgICAgICBDYW5jZWxhclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e2lzTG9hZGluZ30+XG4gICAgICAgICAgICAgICAge2lzTG9hZGluZyA/IFwiU2FsdmFuZG8uLi5cIiA6IFwiU2FsdmFyXCJ9XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPC9Nb2RhbEFjdGlvbnM+XG4gICAgICAgICAgPC9Gb3JtR3JpZD5cbiAgICAgICAgPC9Nb2RhbEJvZHk+XG4gICAgICA8L01vZGFsUGFuZWw+XG4gICAgPC9Nb2RhbEJhY2tkcm9wPlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy93YWxsYS9EZXNrdG9wL1Byb2pldG9zLXBlc3NvYWlzL3Byb3ZhLXRlY25pY2EvZnJvbnQtbWluaS10YXNrLW1hbmFnZXIvc3JjL2NvbXBvbmVudHMvdGVhbXMvVGVhbUZvcm1Nb2RhbC50c3gifQ==