import styled from "/node_modules/.vite/deps/styled-components.js?v=b967f2da";
export const VersionBadge = styled.div`
  position: fixed;
  right: 16px;
  bottom: 12px;
  z-index: 10;
  max-width: calc(100vw - 32px);
  border: 1px solid ${({ theme }) => theme.colors.border};
  border-radius: 8px;
  padding: 4px 8px;
  color: ${({ theme }) => theme.colors.dark};
  background: rgba(255, 255, 255, 0.82);
  box-shadow: 0 8px 24px rgba(41, 67, 78, 0.12);
  font-size: 12px;
  line-height: 1.4;
  pointer-events: none;
`;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsT0FBT0EsWUFBWTtBQUVuQixPQUFPLE1BQU1DLGVBQWVELE9BQU9FLEdBQUc7Ozs7Ozt1QkFNZixFQUFFQyxZQUFZQSxNQUFNQyxPQUFPQyxPQUFNOzs7WUFHNUMsRUFBRUYsWUFBWUEsTUFBTUMsT0FBT0UsS0FBSSIsIm5hbWVzIjpbInN0eWxlZCIsIlZlcnNpb25CYWRnZSIsImRpdiIsInRoZW1lIiwiY29sb3JzIiwiYm9yZGVyIiwiZGFyayJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJzdHlsZXMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcblxuZXhwb3J0IGNvbnN0IFZlcnNpb25CYWRnZSA9IHN0eWxlZC5kaXZgXG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgcmlnaHQ6IDE2cHg7XG4gIGJvdHRvbTogMTJweDtcbiAgei1pbmRleDogMTA7XG4gIG1heC13aWR0aDogY2FsYygxMDB2dyAtIDMycHgpO1xuICBib3JkZXI6IDFweCBzb2xpZCAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy5ib3JkZXJ9O1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIHBhZGRpbmc6IDRweCA4cHg7XG4gIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy5kYXJrfTtcbiAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjgyKTtcbiAgYm94LXNoYWRvdzogMCA4cHggMjRweCByZ2JhKDQxLCA2NywgNzgsIDAuMTIpO1xuICBmb250LXNpemU6IDEycHg7XG4gIGxpbmUtaGVpZ2h0OiAxLjQ7XG4gIHBvaW50ZXItZXZlbnRzOiBub25lO1xuYDtcbiJdLCJmaWxlIjoiQzovVXNlcnMvd2FsbGEvRGVza3RvcC9Qcm9qZXRvcy1wZXNzb2Fpcy9wcm92YS10ZWNuaWNhL2Zyb250LW1pbmktdGFzay1tYW5hZ2VyL3NyYy9zdHlsZXMvc3R5bGVzLnRzIn0=