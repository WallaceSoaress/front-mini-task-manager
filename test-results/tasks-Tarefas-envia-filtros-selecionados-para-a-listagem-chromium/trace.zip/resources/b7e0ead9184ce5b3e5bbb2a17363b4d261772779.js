import styled from "/node_modules/.vite/deps/styled-components.js?v=b967f2da";
export const PageShell = styled.main`
  min-height: 100svh;
  width: 100%;
  display: grid;
  place-items: center;
  padding: 32px 16px;
  box-sizing: border-box;
  background:
    linear-gradient(135deg, rgba(67, 190, 198, 0.12), rgba(21, 119, 67, 0.08)),
    ${({ theme }) => theme.colors.background};
`;
export const LoginPanel = styled.section`
  width: min(100%, 420px);
  border: 1px solid ${({ theme }) => theme.colors.border};
  border-radius: 8px;
  padding: 32px;
  box-sizing: border-box;
  background: ${({ theme }) => theme.colors.white};
  box-shadow: 0 18px 50px rgba(41, 67, 78, 0.12);
  text-align: left;
`;
export const HeaderGroup = styled.header`
  display: grid;
  gap: 8px;
  margin-bottom: 28px;

  span {
    color: ${({ theme }) => theme.colors.primary_dark};
    font-size: ${({ theme }) => theme.fonts.size.small};
    font-weight: 700;
    text-transform: uppercase;
  }

  h1 {
    margin: 0;
  }
`;
export const Form = styled.form`
  display: grid;
  gap: 18px;

  button {
    min-height: 48px;
    border: 0;
    border-radius: 8px;
    background: ${({ theme }) => theme.colors.primary_dark};
    color: ${({ theme }) => theme.colors.text_white};
    cursor: pointer;
    font: inherit;
    font-weight: 700;
  }

  button:disabled {
    cursor: not-allowed;
    opacity: 0.65;
  }
`;
export const Field = styled.div`
  display: grid;
  gap: 8px;

  label {
    color: ${({ theme }) => theme.colors.text_black};
    font-size: ${({ theme }) => theme.fonts.size.small};
    font-weight: 700;
  }

  input {
    min-height: 46px;
    border: 1px solid ${({ theme }) => theme.colors.border};
    border-radius: 8px;
    padding: 0 14px;
    color: ${({ theme }) => theme.colors.text_black};
    background: ${({ theme }) => theme.colors.white};
    font: inherit;
    box-sizing: border-box;
  }

  input:focus {
    border-color: ${({ theme }) => theme.colors.primary_dark};
    outline: 3px solid rgba(67, 190, 198, 0.18);
  }
`;
export const ErrorMessage = styled.p`
  border-radius: 8px;
  padding: 12px 14px;
  color: ${({ theme }) => theme.colors.danger};
  background: ${({ theme }) => theme.colors.error_light};
  font-size: ${({ theme }) => theme.fonts.size.small};
`;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsT0FBT0EsWUFBWTtBQUVuQixPQUFPLE1BQU1DLFlBQVlELE9BQU9FLElBQUk7Ozs7Ozs7OztPQVM3QixFQUFFQyxZQUFZQSxNQUFNQyxPQUFPQyxXQUFVOztBQUc1QyxPQUFPLE1BQU1DLGFBQWFOLE9BQU9PLE9BQU87O3VCQUVqQixFQUFFSixZQUFZQSxNQUFNQyxPQUFPSSxPQUFNOzs7O2lCQUl2QyxFQUFFTCxZQUFZQSxNQUFNQyxPQUFPSyxNQUFLOzs7O0FBS2pELE9BQU8sTUFBTUMsY0FBY1YsT0FBT1csTUFBTTs7Ozs7O2NBTTFCLEVBQUVSLFlBQVlBLE1BQU1DLE9BQU9RLGFBQVk7a0JBQ25DLEVBQUVULFlBQVlBLE1BQU1VLE1BQU1DLEtBQUtDLE1BQUs7Ozs7Ozs7OztBQVV0RCxPQUFPLE1BQU1DLE9BQU9oQixPQUFPaUIsSUFBSTs7Ozs7Ozs7bUJBUVosRUFBRWQsWUFBWUEsTUFBTUMsT0FBT1EsYUFBWTtjQUM1QyxFQUFFVCxZQUFZQSxNQUFNQyxPQUFPYyxXQUFVOzs7Ozs7Ozs7OztBQVluRCxPQUFPLE1BQU1DLFFBQVFuQixPQUFPb0IsR0FBRzs7Ozs7Y0FLakIsRUFBRWpCLFlBQVlBLE1BQU1DLE9BQU9pQixXQUFVO2tCQUNqQyxFQUFFbEIsWUFBWUEsTUFBTVUsTUFBTUMsS0FBS0MsTUFBSzs7Ozs7O3lCQU03QixFQUFFWixZQUFZQSxNQUFNQyxPQUFPSSxPQUFNOzs7Y0FHNUMsRUFBRUwsWUFBWUEsTUFBTUMsT0FBT2lCLFdBQVU7bUJBQ2hDLEVBQUVsQixZQUFZQSxNQUFNQyxPQUFPSyxNQUFLOzs7Ozs7cUJBTTlCLEVBQUVOLFlBQVlBLE1BQU1DLE9BQU9RLGFBQVk7Ozs7QUFLNUQsT0FBTyxNQUFNVSxlQUFldEIsT0FBT3VCLENBQUM7OztZQUd4QixFQUFFcEIsWUFBWUEsTUFBTUMsT0FBT29CLE9BQU07aUJBQzVCLEVBQUVyQixZQUFZQSxNQUFNQyxPQUFPcUIsWUFBVztnQkFDdkMsRUFBRXRCLFlBQVlBLE1BQU1VLE1BQU1DLEtBQUtDLE1BQUsiLCJuYW1lcyI6WyJzdHlsZWQiLCJQYWdlU2hlbGwiLCJtYWluIiwidGhlbWUiLCJjb2xvcnMiLCJiYWNrZ3JvdW5kIiwiTG9naW5QYW5lbCIsInNlY3Rpb24iLCJib3JkZXIiLCJ3aGl0ZSIsIkhlYWRlckdyb3VwIiwiaGVhZGVyIiwicHJpbWFyeV9kYXJrIiwiZm9udHMiLCJzaXplIiwic21hbGwiLCJGb3JtIiwiZm9ybSIsInRleHRfd2hpdGUiLCJGaWVsZCIsImRpdiIsInRleHRfYmxhY2siLCJFcnJvck1lc3NhZ2UiLCJwIiwiZGFuZ2VyIiwiZXJyb3JfbGlnaHQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsic3R5bGVzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XG5cbmV4cG9ydCBjb25zdCBQYWdlU2hlbGwgPSBzdHlsZWQubWFpbmBcbiAgbWluLWhlaWdodDogMTAwc3ZoO1xuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZ3JpZDtcbiAgcGxhY2UtaXRlbXM6IGNlbnRlcjtcbiAgcGFkZGluZzogMzJweCAxNnB4O1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBiYWNrZ3JvdW5kOlxuICAgIGxpbmVhci1ncmFkaWVudCgxMzVkZWcsIHJnYmEoNjcsIDE5MCwgMTk4LCAwLjEyKSwgcmdiYSgyMSwgMTE5LCA2NywgMC4wOCkpLFxuICAgICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLmJhY2tncm91bmR9O1xuYDtcblxuZXhwb3J0IGNvbnN0IExvZ2luUGFuZWwgPSBzdHlsZWQuc2VjdGlvbmBcbiAgd2lkdGg6IG1pbigxMDAlLCA0MjBweCk7XG4gIGJvcmRlcjogMXB4IHNvbGlkICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLmJvcmRlcn07XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgcGFkZGluZzogMzJweDtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgYmFja2dyb3VuZDogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMud2hpdGV9O1xuICBib3gtc2hhZG93OiAwIDE4cHggNTBweCByZ2JhKDQxLCA2NywgNzgsIDAuMTIpO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuYDtcblxuZXhwb3J0IGNvbnN0IEhlYWRlckdyb3VwID0gc3R5bGVkLmhlYWRlcmBcbiAgZGlzcGxheTogZ3JpZDtcbiAgZ2FwOiA4cHg7XG4gIG1hcmdpbi1ib3R0b206IDI4cHg7XG5cbiAgc3BhbiB7XG4gICAgY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLnByaW1hcnlfZGFya307XG4gICAgZm9udC1zaXplOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmZvbnRzLnNpemUuc21hbGx9O1xuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XG4gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgfVxuXG4gIGgxIHtcbiAgICBtYXJnaW46IDA7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBGb3JtID0gc3R5bGVkLmZvcm1gXG4gIGRpc3BsYXk6IGdyaWQ7XG4gIGdhcDogMThweDtcblxuICBidXR0b24ge1xuICAgIG1pbi1oZWlnaHQ6IDQ4cHg7XG4gICAgYm9yZGVyOiAwO1xuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICBiYWNrZ3JvdW5kOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy5wcmltYXJ5X2Rhcmt9O1xuICAgIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy50ZXh0X3doaXRlfTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgZm9udDogaW5oZXJpdDtcbiAgICBmb250LXdlaWdodDogNzAwO1xuICB9XG5cbiAgYnV0dG9uOmRpc2FibGVkIHtcbiAgICBjdXJzb3I6IG5vdC1hbGxvd2VkO1xuICAgIG9wYWNpdHk6IDAuNjU7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBGaWVsZCA9IHN0eWxlZC5kaXZgXG4gIGRpc3BsYXk6IGdyaWQ7XG4gIGdhcDogOHB4O1xuXG4gIGxhYmVsIHtcbiAgICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMudGV4dF9ibGFja307XG4gICAgZm9udC1zaXplOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmZvbnRzLnNpemUuc21hbGx9O1xuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIH1cblxuICBpbnB1dCB7XG4gICAgbWluLWhlaWdodDogNDZweDtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy5ib3JkZXJ9O1xuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICBwYWRkaW5nOiAwIDE0cHg7XG4gICAgY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLnRleHRfYmxhY2t9O1xuICAgIGJhY2tncm91bmQ6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLndoaXRlfTtcbiAgICBmb250OiBpbmhlcml0O1xuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIH1cblxuICBpbnB1dDpmb2N1cyB7XG4gICAgYm9yZGVyLWNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy5wcmltYXJ5X2Rhcmt9O1xuICAgIG91dGxpbmU6IDNweCBzb2xpZCByZ2JhKDY3LCAxOTAsIDE5OCwgMC4xOCk7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBFcnJvck1lc3NhZ2UgPSBzdHlsZWQucGBcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBwYWRkaW5nOiAxMnB4IDE0cHg7XG4gIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy5kYW5nZXJ9O1xuICBiYWNrZ3JvdW5kOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy5lcnJvcl9saWdodH07XG4gIGZvbnQtc2l6ZTogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5mb250cy5zaXplLnNtYWxsfTtcbmA7XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3dhbGxhL0Rlc2t0b3AvUHJvamV0b3MtcGVzc29haXMvcHJvdmEtdGVjbmljYS9mcm9udC1taW5pLXRhc2stbWFuYWdlci9zcmMvcGFnZXMvcHVibGljL0xvZ2luL3N0eWxlcy50cyJ9