import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/private/Teams/index.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport14_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=df6b4f96";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=df6b4f96";
import { PrivateNavigation } from "/src/components/layout/PrivateNavigation.tsx";
import { ConfirmDialog } from "/src/components/tasks/ConfirmDialog.tsx";
import { Button, Toolbar, ToolbarHeader } from "/src/components/tasks/styles.ts";
import { ErrorState, LoadingState } from "/src/components/tasks/TaskStates.tsx";
import { TeamFormModal } from "/src/components/teams/TeamFormModal.tsx";
import { TeamList } from "/src/components/teams/TeamList.tsx";
import { EmptyTeamsState } from "/src/components/teams/TeamStates.tsx";
import { SuccessMessage } from "/src/components/teams/styles.ts";
import { useAuth } from "/src/hooks/auth.tsx";
import { useCreateTeam, useDeleteTeam, useTeams, useUsers } from "/src/hooks/tasks/useTasks.ts";
import { ApiRequestError } from "/src/services/api.ts";
import { HeaderActions, TeamsShell, TeamsTopBar, TeamsUserInfo } from "/src/pages/private/Teams/styles.ts";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/private/Teams/index.tsx";
import __vite__cjsImport14_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=df6b4f96";
var _s = $RefreshSig$();
function getErrorMessage(error) {
	if (error instanceof ApiRequestError) {
		return error.message;
	}
	return "Nao foi possivel concluir a operacao.";
}
const Teams = () => {
	_s();
	const $ = _c(64);
	if ($[0] !== "1e125c31d0c86cdc79986163f8e0416250fe62d92a6f70224e3653b0da5adaa5") {
		for (let $i = 0; $i < 64; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "1e125c31d0c86cdc79986163f8e0416250fe62d92a6f70224e3653b0da5adaa5";
	}
	const { signOut, user } = useAuth();
	const teamsQuery = useTeams();
	const usersQuery = useUsers();
	const createTeam = useCreateTeam();
	const deleteTeam = useDeleteTeam();
	const [isFormOpen, setIsFormOpen] = useState(false);
	const [formError, setFormError] = useState("");
	const [listError, setListError] = useState("");
	const [successMessage, setSuccessMessage] = useState("");
	const [teamToDelete, setTeamToDelete] = useState(null);
	let t0;
	if ($[1] !== teamsQuery.data) {
		t0 = teamsQuery.data ?? [];
		$[1] = teamsQuery.data;
		$[2] = t0;
	} else {
		t0 = $[2];
	}
	const teams = t0;
	let t1;
	if ($[3] !== usersQuery.data) {
		t1 = usersQuery.data ?? [];
		$[3] = usersQuery.data;
		$[4] = t1;
	} else {
		t1 = $[4];
	}
	const users = t1;
	let t2;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = function openForm() {
			setFormError("");
			setListError("");
			setSuccessMessage("");
			setIsFormOpen(true);
		};
		$[5] = t2;
	} else {
		t2 = $[5];
	}
	const openForm = t2;
	let t3;
	if ($[6] !== createTeam) {
		t3 = async function handleSubmitTeam(payload) {
			setFormError("");
			;
			try {
				await createTeam.mutateAsync(payload);
				setIsFormOpen(false);
				setSuccessMessage("Time cadastrado com sucesso.");
			} catch (t4) {
				const error = t4;
				setFormError(getErrorMessage(error));
			}
		};
		$[6] = createTeam;
		$[7] = t3;
	} else {
		t3 = $[7];
	}
	const handleSubmitTeam = t3;
	let t4;
	if ($[8] !== deleteTeam || $[9] !== teamToDelete) {
		t4 = async function handleDeleteTeam() {
			if (!teamToDelete) {
				return;
			}
			setListError("");
			setSuccessMessage("");
			;
			try {
				await deleteTeam.mutateAsync(teamToDelete.id);
				setTeamToDelete(null);
				setSuccessMessage("Time excluido com sucesso.");
			} catch (t5) {
				const error_0 = t5;
				setListError(getErrorMessage(error_0));
			}
		};
		$[8] = deleteTeam;
		$[9] = teamToDelete;
		$[10] = t4;
	} else {
		t4 = $[10];
	}
	const handleDeleteTeam = t4;
	const t5 = user?.name;
	let t6;
	if ($[11] !== t5) {
		t6 = /* @__PURE__ */ _jsxDEV("strong", { children: t5 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 122,
			columnNumber: 10
		}, this);
		$[11] = t5;
		$[12] = t6;
	} else {
		t6 = $[12];
	}
	const t7 = user?.email;
	let t8;
	if ($[13] !== t7) {
		t8 = /* @__PURE__ */ _jsxDEV("span", { children: t7 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 131,
			columnNumber: 10
		}, this);
		$[13] = t7;
		$[14] = t8;
	} else {
		t8 = $[14];
	}
	let t9;
	if ($[15] !== t6 || $[16] !== t8) {
		t9 = /* @__PURE__ */ _jsxDEV(TeamsUserInfo, { children: [t6, t8] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 139,
			columnNumber: 10
		}, this);
		$[15] = t6;
		$[16] = t8;
		$[17] = t9;
	} else {
		t9 = $[17];
	}
	let t10;
	if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
		t10 = /* @__PURE__ */ _jsxDEV(PrivateNavigation, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 148,
			columnNumber: 11
		}, this);
		$[18] = t10;
	} else {
		t10 = $[18];
	}
	let t11;
	if ($[19] !== signOut) {
		t11 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			$variant: "ghost",
			onClick: signOut,
			children: "Sair"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 155,
			columnNumber: 11
		}, this);
		$[19] = signOut;
		$[20] = t11;
	} else {
		t11 = $[20];
	}
	let t12;
	if ($[21] !== t11 || $[22] !== t9) {
		t12 = /* @__PURE__ */ _jsxDEV(TeamsTopBar, { children: [
			t9,
			t10,
			t11
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 163,
			columnNumber: 11
		}, this);
		$[21] = t11;
		$[22] = t9;
		$[23] = t12;
	} else {
		t12 = $[23];
	}
	let t13;
	if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
		t13 = /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", { children: "Times" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 172,
			columnNumber: 16
		}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Gerencie equipes e membros disponiveis para as tarefas." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 172,
			columnNumber: 30
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 172,
			columnNumber: 11
		}, this);
		$[24] = t13;
	} else {
		t13 = $[24];
	}
	let t14;
	if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
		t14 = /* @__PURE__ */ _jsxDEV(Toolbar, { children: /* @__PURE__ */ _jsxDEV(ToolbarHeader, { children: [t13, /* @__PURE__ */ _jsxDEV(HeaderActions, { children: /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			onClick: openForm,
			children: "Novo Time"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 179,
			columnNumber: 55
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 179,
			columnNumber: 40
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 179,
			columnNumber: 20
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 179,
			columnNumber: 11
		}, this);
		$[25] = t14;
	} else {
		t14 = $[25];
	}
	let t15;
	if ($[26] !== successMessage) {
		t15 = successMessage ? /* @__PURE__ */ _jsxDEV(SuccessMessage, {
			role: "status",
			children: successMessage
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 186,
			columnNumber: 28
		}, this) : null;
		$[26] = successMessage;
		$[27] = t15;
	} else {
		t15 = $[27];
	}
	let t16;
	if ($[28] !== listError) {
		t16 = listError ? /* @__PURE__ */ _jsxDEV(ErrorState, { message: listError }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 194,
			columnNumber: 23
		}, this) : null;
		$[28] = listError;
		$[29] = t16;
	} else {
		t16 = $[29];
	}
	let t17;
	if ($[30] !== teamsQuery.isLoading) {
		t17 = teamsQuery.isLoading ? /* @__PURE__ */ _jsxDEV(LoadingState, { message: "Carregando times..." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 202,
			columnNumber: 34
		}, this) : null;
		$[30] = teamsQuery.isLoading;
		$[31] = t17;
	} else {
		t17 = $[31];
	}
	let t18;
	if ($[32] !== teamsQuery) {
		t18 = teamsQuery.isError ? /* @__PURE__ */ _jsxDEV(ErrorState, {
			message: getErrorMessage(teamsQuery.error),
			onRetry: () => teamsQuery.refetch()
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 210,
			columnNumber: 32
		}, this) : null;
		$[32] = teamsQuery;
		$[33] = t18;
	} else {
		t18 = $[33];
	}
	let t19;
	if ($[34] !== teams || $[35] !== teamsQuery.isSuccess) {
		t19 = teamsQuery.isSuccess && teams.length === 0 ? /* @__PURE__ */ _jsxDEV(EmptyTeamsState, { onCreate: openForm }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 218,
			columnNumber: 56
		}, this) : null;
		$[34] = teams;
		$[35] = teamsQuery.isSuccess;
		$[36] = t19;
	} else {
		t19 = $[36];
	}
	let t20;
	if ($[37] !== teams || $[38] !== teamsQuery.isSuccess) {
		t20 = teamsQuery.isSuccess && teams.length > 0 ? /* @__PURE__ */ _jsxDEV(TeamList, {
			teams,
			onDeleteTeam: (team) => {
				setListError("");
				setSuccessMessage("");
				setTeamToDelete(team);
			}
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 227,
			columnNumber: 54
		}, this) : null;
		$[37] = teams;
		$[38] = teamsQuery.isSuccess;
		$[39] = t20;
	} else {
		t20 = $[39];
	}
	let t21;
	if ($[40] !== createTeam || $[41] !== formError || $[42] !== handleSubmitTeam || $[43] !== isFormOpen || $[44] !== users || $[45] !== usersQuery.error || $[46] !== usersQuery.isError || $[47] !== usersQuery.isLoading) {
		t21 = isFormOpen ? /* @__PURE__ */ _jsxDEV(TeamFormModal, {
			users,
			usersError: usersQuery.isError ? getErrorMessage(usersQuery.error) : "",
			isLoadingUsers: usersQuery.isLoading,
			apiError: formError,
			isLoading: createTeam.isPending,
			onClose: () => setIsFormOpen(false),
			onSubmit: handleSubmitTeam
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 240,
			columnNumber: 24
		}, this) : null;
		$[40] = createTeam;
		$[41] = formError;
		$[42] = handleSubmitTeam;
		$[43] = isFormOpen;
		$[44] = users;
		$[45] = usersQuery.error;
		$[46] = usersQuery.isError;
		$[47] = usersQuery.isLoading;
		$[48] = t21;
	} else {
		t21 = $[48];
	}
	let t22;
	if ($[49] !== deleteTeam || $[50] !== handleDeleteTeam || $[51] !== listError || $[52] !== teamToDelete) {
		t22 = teamToDelete ? /* @__PURE__ */ _jsxDEV(ConfirmDialog, {
			title: "Excluir time",
			message: `Tem certeza que deseja excluir "${teamToDelete.name}"? Essa acao so sera concluida se nao houver demandas vinculadas ao time.`,
			confirmLabel: "Excluir",
			errorMessage: listError,
			isLoading: deleteTeam.isPending,
			onCancel: () => {
				if (!deleteTeam.isPending) {
					setTeamToDelete(null);
					setListError("");
				}
			},
			onConfirm: handleDeleteTeam
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 255,
			columnNumber: 26
		}, this) : null;
		$[49] = deleteTeam;
		$[50] = handleDeleteTeam;
		$[51] = listError;
		$[52] = teamToDelete;
		$[53] = t22;
	} else {
		t22 = $[53];
	}
	let t23;
	if ($[54] !== t12 || $[55] !== t15 || $[56] !== t16 || $[57] !== t17 || $[58] !== t18 || $[59] !== t19 || $[60] !== t20 || $[61] !== t21 || $[62] !== t22) {
		t23 = /* @__PURE__ */ _jsxDEV(TeamsShell, { children: [
			t12,
			t14,
			t15,
			t16,
			t17,
			t18,
			t19,
			t20,
			t21,
			t22
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 271,
			columnNumber: 11
		}, this);
		$[54] = t12;
		$[55] = t15;
		$[56] = t16;
		$[57] = t17;
		$[58] = t18;
		$[59] = t19;
		$[60] = t20;
		$[61] = t21;
		$[62] = t22;
		$[63] = t23;
	} else {
		t23 = $[63];
	}
	return t23;
};
_s(Teams, "GMBynTZkGPzGeUoJN9EC8SN0wpk=", false, function() {
	return [
		useAuth,
		useTeams,
		useUsers,
		useCreateTeam,
		useDeleteTeam
	];
});
_c2 = Teams;
export default Teams;
var _c2;
$RefreshReg$(_c2, "Teams");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/private/Teams/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/private/Teams/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/private/Teams/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/private/Teams/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLFFBQVFDLFNBQVNDLHFCQUFxQjtBQUMvQyxTQUFTQyxZQUFZQyxvQkFBb0I7QUFDekMsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsZUFBZUMsZUFBZUMsVUFBVUMsZ0JBQWdCO0FBRWpFLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxlQUFlQyxZQUFZQyxhQUFhQyxxQkFBcUI7Ozs7QUFFdEUsU0FBU0MsZ0JBQWdCQyxPQUFnQjtDQUN2QyxJQUFJQSxpQkFBaUJOLGlCQUFpQjtFQUNwQyxPQUFPTSxNQUFNQztDQUNmO0NBRUEsT0FBTztBQUNUO0FBRUEsTUFBTUMsY0FBUTs7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxJQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FDWixRQUFBSyxTQUFBQyxTQUEwQnBCLFFBQVE7Q0FDbEMsTUFBQXFCLGFBQW1CbEIsU0FBUztDQUM1QixNQUFBbUIsYUFBbUJsQixTQUFTO0NBQzVCLE1BQUFtQixhQUFtQnRCLGNBQWM7Q0FDakMsTUFBQXVCLGFBQW1CdEIsY0FBYztDQUNqQyxPQUFBdUIsWUFBQUMsaUJBQW9DdEMsU0FBUyxLQUFLO0NBQ2xELE9BQUF1QyxXQUFBQyxnQkFBa0N4QyxTQUFTLEVBQUU7Q0FDN0MsT0FBQXlDLFdBQUFDLGdCQUFrQzFDLFNBQVMsRUFBRTtDQUM3QyxPQUFBMkMsZ0JBQUFDLHFCQUE0QzVDLFNBQVMsRUFBRTtDQUN2RCxPQUFBNkMsY0FBQUMsbUJBQXdDOUMsU0FBc0IsSUFBSTtDQUFFLElBQUErQztDQUFBLElBQUFyQixFQUFBLE9BQUFPLFdBQUFlLE1BQUE7RUFFdERELEtBQUFkLFdBQVVlLFFBQVY7RUFBcUJ0QixFQUFBLEtBQUFPLFdBQUFlO0VBQUF0QixFQUFBLEtBQUFxQjtDQUFBO0VBQUFBLEtBQUFyQixFQUFBO0NBQUE7Q0FBbkMsTUFBQXVCLFFBQWNGO0NBQXNCLElBQUFHO0NBQUEsSUFBQXhCLEVBQUEsT0FBQVEsV0FBQWMsTUFBQTtFQUN0QkUsS0FBQWhCLFdBQVVjLFFBQVY7RUFBcUJ0QixFQUFBLEtBQUFRLFdBQUFjO0VBQUF0QixFQUFBLEtBQUF3QjtDQUFBO0VBQUFBLEtBQUF4QixFQUFBO0NBQUE7Q0FBbkMsTUFBQXlCLFFBQWNEO0NBQXNCLElBQUFFO0NBQUEsSUFBQTFCLEVBQUEsT0FBQUcsT0FBQUMsSUFBQTtFQUVwQ3NCLEtBQUEsU0FBQUMsV0FBQTtHQUNFYixhQUFhLEVBQUU7R0FDZkUsYUFBYSxFQUFFO0dBQ2ZFLGtCQUFrQixFQUFFO0dBQ3BCTixjQUFjLElBQUk7RUFBQztFQUNwQlosRUFBQSxLQUFBMEI7Q0FBQTtFQUFBQSxLQUFBMUIsRUFBQTtDQUFBO0NBTEQsTUFBQTJCLFdBQUFEO0NBS0MsSUFBQUU7Q0FBQSxJQUFBNUIsRUFBQSxPQUFBUyxZQUFBO0VBRURtQixLQUFBLGVBQUFDLGlCQUFBQyxTQUFBO0dBQ0VoQixhQUFhLEVBQUU7R0FBQztHQUVoQjtJQUNFLE1BQU1MLFdBQVVzQixZQUFhRCxPQUFPO0lBQ3BDbEIsY0FBYyxLQUFLO0lBQ25CTSxrQkFBa0IsOEJBQThCO0dBQUMsU0FBQWMsSUFBQTtJQUMxQ25DO0lBQ1BpQixhQUFhbEIsZ0JBQWdCQyxLQUFLLENBQUM7R0FBQztFQUNyQztFQUNGRyxFQUFBLEtBQUFTO0VBQUFULEVBQUEsS0FBQTRCO0NBQUE7RUFBQUEsS0FBQTVCLEVBQUE7Q0FBQTtDQVZELE1BQUE2QixtQkFBQUQ7Q0FVQyxJQUFBSTtDQUFBLElBQUFoQyxFQUFBLE9BQUFVLGNBQUFWLEVBQUEsT0FBQW1CLGNBQUE7RUFFRGEsS0FBQSxlQUFBQyxtQkFBQTtHQUNFLElBQUksQ0FBQ2QsY0FBWTtJQUFBO0dBQUE7R0FJakJILGFBQWEsRUFBRTtHQUNmRSxrQkFBa0IsRUFBRTtHQUFDO0dBRXJCO0lBQ0UsTUFBTVIsV0FBVXFCLFlBQWFaLGFBQVllLEVBQUc7SUFDNUNkLGdCQUFnQixJQUFJO0lBQ3BCRixrQkFBa0IsNEJBQTRCO0dBQUMsU0FBQWlCLElBQUE7SUFDeEN0QztJQUNQbUIsYUFBYXBCLGdCQUFnQkMsT0FBSyxDQUFDO0dBQUM7RUFDckM7RUFDRkcsRUFBQSxLQUFBVTtFQUFBVixFQUFBLEtBQUFtQjtFQUFBbkIsRUFBQSxNQUFBZ0M7Q0FBQTtFQUFBQSxLQUFBaEMsRUFBQTtDQUFBO0NBZkQsTUFBQWlDLG1CQUFBRDtDQXFCaUIsTUFBQUcsS0FBQTdCLE1BQUk4QjtDQUFNLElBQUFDO0NBQUEsSUFBQXJDLEVBQUEsUUFBQW1DLElBQUE7RUFBbkJFLEtBQUEsOENBQVNGLEdBQW9COzs7OztFQUFBbkMsRUFBQSxNQUFBbUM7RUFBQW5DLEVBQUEsTUFBQXFDO0NBQUE7RUFBQUEsS0FBQXJDLEVBQUE7Q0FBQTtDQUN0QixNQUFBc0MsS0FBQWhDLE1BQUlpQztDQUFPLElBQUFDO0NBQUEsSUFBQXhDLEVBQUEsUUFBQXNDLElBQUE7RUFBbEJFLEtBQUEsNENBQU9GLEdBQW1COzs7OztFQUFBdEMsRUFBQSxNQUFBc0M7RUFBQXRDLEVBQUEsTUFBQXdDO0NBQUE7RUFBQUEsS0FBQXhDLEVBQUE7Q0FBQTtDQUFBLElBQUF5QztDQUFBLElBQUF6QyxFQUFBLFFBQUFxQyxNQUFBckMsRUFBQSxRQUFBd0MsSUFBQTtFQUY1QkMsS0FBQSx3QkFBQyxlQUFELGFBQ0VKLElBQ0FHLEVBRlk7Ozs7O0VBR0V4QyxFQUFBLE1BQUFxQztFQUFBckMsRUFBQSxNQUFBd0M7RUFBQXhDLEVBQUEsTUFBQXlDO0NBQUE7RUFBQUEsS0FBQXpDLEVBQUE7Q0FBQTtDQUFBLElBQUEwQztDQUFBLElBQUExQyxFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFDaEJzQyxNQUFBLHdCQUFDLG1CQUFELENBQWtCOzs7OztFQUFHMUMsRUFBQSxNQUFBMEM7Q0FBQTtFQUFBQSxNQUFBMUMsRUFBQTtDQUFBO0NBQUEsSUFBQTJDO0NBQUEsSUFBQTNDLEVBQUEsUUFBQUssU0FBQTtFQUNyQnNDLE1BQUEsd0JBQUMsUUFBRDtHQUFhO0dBQWtCO0dBQWlCdEM7YUFBUztFQUFsRDs7Ozs7RUFFRUwsRUFBQSxNQUFBSztFQUFBTCxFQUFBLE1BQUEyQztDQUFBO0VBQUFBLE1BQUEzQyxFQUFBO0NBQUE7Q0FBQSxJQUFBNEM7Q0FBQSxJQUFBNUMsRUFBQSxRQUFBMkMsT0FBQTNDLEVBQUEsUUFBQXlDLElBQUE7RUFSWEcsTUFBQSx3QkFBQyxhQUFEO0dBQ0VIO0dBSUFDO0dBQ0FDO0VBTlU7Ozs7O0VBU0UzQyxFQUFBLE1BQUEyQztFQUFBM0MsRUFBQSxNQUFBeUM7RUFBQXpDLEVBQUEsTUFBQTRDO0NBQUE7RUFBQUEsTUFBQTVDLEVBQUE7Q0FBQTtDQUFBLElBQUE2QztDQUFBLElBQUE3QyxFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFJVnlDLE1BQUEsNENBQ0UsMENBQUksUUFBVTs7OztZQUNkLHlDQUFHLDBEQUEyRDs7OztVQUMxRDs7Ozs7RUFBQTdDLEVBQUEsTUFBQTZDO0NBQUE7RUFBQUEsTUFBQTdDLEVBQUE7Q0FBQTtDQUFBLElBQUE4QztDQUFBLElBQUE5QyxFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFMVjBDLE1BQUEsd0JBQUMsU0FBRCxZQUNFLHdCQUFDLGVBQUQsYUFDRUQsS0FLQSx3QkFBQyxlQUFELFlBQ0Usd0JBQUMsUUFBRDtHQUFhO0dBQWtCbEI7YUFBVTtFQUFsQzs7OztXQURLOzs7O1VBTkY7Ozs7V0FEUjs7Ozs7RUFhRTNCLEVBQUEsTUFBQThDO0NBQUE7RUFBQUEsTUFBQTlDLEVBQUE7Q0FBQTtDQUFBLElBQUErQztDQUFBLElBQUEvQyxFQUFBLFFBQUFpQixnQkFBQTtFQUVUOEIsTUFBQTlCLGlCQUFpQix3QkFBQyxnQkFBRDtHQUFxQjthQUFVQTtFQUFoQjs7OzthQUFoQztFQUF1RmpCLEVBQUEsTUFBQWlCO0VBQUFqQixFQUFBLE1BQUErQztDQUFBO0VBQUFBLE1BQUEvQyxFQUFBO0NBQUE7Q0FBQSxJQUFBZ0Q7Q0FBQSxJQUFBaEQsRUFBQSxRQUFBZSxXQUFBO0VBQ3ZGaUMsTUFBQWpDLFlBQVksd0JBQUMsWUFBRCxFQUFxQkEsbUJBQVM7Ozs7YUFBMUM7RUFBcURmLEVBQUEsTUFBQWU7RUFBQWYsRUFBQSxNQUFBZ0Q7Q0FBQTtFQUFBQSxNQUFBaEQsRUFBQTtDQUFBO0NBQUEsSUFBQWlEO0NBQUEsSUFBQWpELEVBQUEsUUFBQU8sV0FBQTJDLFdBQUE7RUFFckRELE1BQUExQyxXQUFVMkMsWUFBYSx3QkFBQyxjQUFELEVBQXNCLCtCQUFxQjs7OzthQUFsRTtFQUE0RWxELEVBQUEsTUFBQU8sV0FBQTJDO0VBQUFsRCxFQUFBLE1BQUFpRDtDQUFBO0VBQUFBLE1BQUFqRCxFQUFBO0NBQUE7Q0FBQSxJQUFBbUQ7Q0FBQSxJQUFBbkQsRUFBQSxRQUFBTyxZQUFBO0VBRTVFNEMsTUFBQTVDLFdBQVU2QyxVQUNULHdCQUFDLFlBQUQ7R0FBcUIsU0FBQXhELGdCQUFnQlcsV0FBVVYsS0FBTTtHQUFZLGVBQU1VLFdBQVU4QyxRQUFTO0VBQUM7Ozs7YUFENUY7RUFFT3JELEVBQUEsTUFBQU87RUFBQVAsRUFBQSxNQUFBbUQ7Q0FBQTtFQUFBQSxNQUFBbkQsRUFBQTtDQUFBO0NBQUEsSUFBQXNEO0NBQUEsSUFBQXRELEVBQUEsUUFBQXVCLFNBQUF2QixFQUFBLFFBQUFPLFdBQUFnRCxXQUFBO0VBRVBELE1BQUEvQyxXQUFVZ0QsYUFBY2hDLE1BQUtpQyxXQUFZLElBQUksd0JBQUMsaUJBQUQsRUFBMkI3QixtQkFBUTs7OzthQUFoRjtFQUEyRjNCLEVBQUEsTUFBQXVCO0VBQUF2QixFQUFBLE1BQUFPLFdBQUFnRDtFQUFBdkQsRUFBQSxNQUFBc0Q7Q0FBQTtFQUFBQSxNQUFBdEQsRUFBQTtDQUFBO0NBQUEsSUFBQXlEO0NBQUEsSUFBQXpELEVBQUEsUUFBQXVCLFNBQUF2QixFQUFBLFFBQUFPLFdBQUFnRCxXQUFBO0VBRTNGRSxNQUFBbEQsV0FBVWdELGFBQWNoQyxNQUFLaUMsU0FBVSxJQUN0Qyx3QkFBQyxVQUFEO0dBQ1NqQztHQUNPLGVBQUFtQyxTQUFBO0lBQ1oxQyxhQUFhLEVBQUU7SUFDZkUsa0JBQWtCLEVBQUU7SUFDcEJFLGdCQUFnQnNDLElBQUk7R0FBQztFQUN0Qjs7OzthQVBKO0VBU08xRCxFQUFBLE1BQUF1QjtFQUFBdkIsRUFBQSxNQUFBTyxXQUFBZ0Q7RUFBQXZELEVBQUEsTUFBQXlEO0NBQUE7RUFBQUEsTUFBQXpELEVBQUE7Q0FBQTtDQUFBLElBQUEyRDtDQUFBLElBQUEzRCxFQUFBLFFBQUFTLGNBQUFULEVBQUEsUUFBQWEsYUFBQWIsRUFBQSxRQUFBNkIsb0JBQUE3QixFQUFBLFFBQUFXLGNBQUFYLEVBQUEsUUFBQXlCLFNBQUF6QixFQUFBLFFBQUFRLFdBQUFYLFNBQUFHLEVBQUEsUUFBQVEsV0FBQTRDLFdBQUFwRCxFQUFBLFFBQUFRLFdBQUEwQyxXQUFBO0VBRVBTLE1BQUFoRCxhQUNDLHdCQUFDLGVBQUQ7R0FDU2M7R0FDSyxZQUFBakIsV0FBVTRDLFVBQVd4RCxnQkFBZ0JZLFdBQVVYLEtBQVcsSUFBMUQ7R0FDSSxnQkFBQVcsV0FBVTBDO0dBQ2hCckM7R0FDQyxXQUFBSixXQUFVbUQ7R0FDWixlQUFNaEQsY0FBYyxLQUFLO0dBQ3hCaUI7RUFBZ0I7Ozs7YUFSN0I7RUFVTzdCLEVBQUEsTUFBQVM7RUFBQVQsRUFBQSxNQUFBYTtFQUFBYixFQUFBLE1BQUE2QjtFQUFBN0IsRUFBQSxNQUFBVztFQUFBWCxFQUFBLE1BQUF5QjtFQUFBekIsRUFBQSxNQUFBUSxXQUFBWDtFQUFBRyxFQUFBLE1BQUFRLFdBQUE0QztFQUFBcEQsRUFBQSxNQUFBUSxXQUFBMEM7RUFBQWxELEVBQUEsTUFBQTJEO0NBQUE7RUFBQUEsTUFBQTNELEVBQUE7Q0FBQTtDQUFBLElBQUE2RDtDQUFBLElBQUE3RCxFQUFBLFFBQUFVLGNBQUFWLEVBQUEsUUFBQWlDLG9CQUFBakMsRUFBQSxRQUFBZSxhQUFBZixFQUFBLFFBQUFtQixjQUFBO0VBRVAwQyxNQUFBMUMsZUFDQyx3QkFBQyxlQUFEO0dBQ1E7R0FDRyw0Q0FBbUNBLGFBQVlpQixLQUFLO0dBQ2hEO0dBQ0NyQjtHQUNILFdBQUFMLFdBQVVrRDtHQUNYO0lBQ1IsSUFBSSxDQUFDbEQsV0FBVWtELFdBQVU7S0FDdkJ4QyxnQkFBZ0IsSUFBSTtLQUNwQkosYUFBYSxFQUFFO0lBQUM7R0FDakI7R0FFUWlCO0VBQWdCOzs7O2FBYjlCO0VBZU9qQyxFQUFBLE1BQUFVO0VBQUFWLEVBQUEsTUFBQWlDO0VBQUFqQyxFQUFBLE1BQUFlO0VBQUFmLEVBQUEsTUFBQW1CO0VBQUFuQixFQUFBLE1BQUE2RDtDQUFBO0VBQUFBLE1BQUE3RCxFQUFBO0NBQUE7Q0FBQSxJQUFBOEQ7Q0FBQSxJQUFBOUQsRUFBQSxRQUFBNEMsT0FBQTVDLEVBQUEsUUFBQStDLE9BQUEvQyxFQUFBLFFBQUFnRCxPQUFBaEQsRUFBQSxRQUFBaUQsT0FBQWpELEVBQUEsUUFBQW1ELE9BQUFuRCxFQUFBLFFBQUFzRCxPQUFBdEQsRUFBQSxRQUFBeUQsT0FBQXpELEVBQUEsUUFBQTJELE9BQUEzRCxFQUFBLFFBQUE2RCxLQUFBO0VBNUVWQyxNQUFBLHdCQUFDLFlBQUQ7R0FDRWxCO0dBV0FFO0dBZUNDO0dBQ0FDO0dBRUFDO0dBRUFFO0dBSUFHO0dBRUFHO0dBV0FFO0dBWUFFO0VBN0RROzs7OztFQTZFRTdELEVBQUEsTUFBQTRDO0VBQUE1QyxFQUFBLE1BQUErQztFQUFBL0MsRUFBQSxNQUFBZ0Q7RUFBQWhELEVBQUEsTUFBQWlEO0VBQUFqRCxFQUFBLE1BQUFtRDtFQUFBbkQsRUFBQSxNQUFBc0Q7RUFBQXRELEVBQUEsTUFBQXlEO0VBQUF6RCxFQUFBLE1BQUEyRDtFQUFBM0QsRUFBQSxNQUFBNkQ7RUFBQTdELEVBQUEsTUFBQThEO0NBQUE7RUFBQUEsTUFBQTlELEVBQUE7Q0FBQTtDQUFBLE9BN0ViOEQ7QUE2RWE7Ozs7Ozs7Ozs7O0FBSWpCLGVBQWUvRCIsIm5hbWVzIjpbInVzZVN0YXRlIiwiUHJpdmF0ZU5hdmlnYXRpb24iLCJDb25maXJtRGlhbG9nIiwiQnV0dG9uIiwiVG9vbGJhciIsIlRvb2xiYXJIZWFkZXIiLCJFcnJvclN0YXRlIiwiTG9hZGluZ1N0YXRlIiwiVGVhbUZvcm1Nb2RhbCIsIlRlYW1MaXN0IiwiRW1wdHlUZWFtc1N0YXRlIiwiU3VjY2Vzc01lc3NhZ2UiLCJ1c2VBdXRoIiwidXNlQ3JlYXRlVGVhbSIsInVzZURlbGV0ZVRlYW0iLCJ1c2VUZWFtcyIsInVzZVVzZXJzIiwiQXBpUmVxdWVzdEVycm9yIiwiSGVhZGVyQWN0aW9ucyIsIlRlYW1zU2hlbGwiLCJUZWFtc1RvcEJhciIsIlRlYW1zVXNlckluZm8iLCJnZXRFcnJvck1lc3NhZ2UiLCJlcnJvciIsIm1lc3NhZ2UiLCJUZWFtcyIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwic2lnbk91dCIsInVzZXIiLCJ0ZWFtc1F1ZXJ5IiwidXNlcnNRdWVyeSIsImNyZWF0ZVRlYW0iLCJkZWxldGVUZWFtIiwiaXNGb3JtT3BlbiIsInNldElzRm9ybU9wZW4iLCJmb3JtRXJyb3IiLCJzZXRGb3JtRXJyb3IiLCJsaXN0RXJyb3IiLCJzZXRMaXN0RXJyb3IiLCJzdWNjZXNzTWVzc2FnZSIsInNldFN1Y2Nlc3NNZXNzYWdlIiwidGVhbVRvRGVsZXRlIiwic2V0VGVhbVRvRGVsZXRlIiwidDAiLCJkYXRhIiwidGVhbXMiLCJ0MSIsInVzZXJzIiwidDIiLCJvcGVuRm9ybSIsInQzIiwiaGFuZGxlU3VibWl0VGVhbSIsInBheWxvYWQiLCJtdXRhdGVBc3luYyIsInQ0IiwiaGFuZGxlRGVsZXRlVGVhbSIsImlkIiwidDUiLCJuYW1lIiwidDYiLCJ0NyIsImVtYWlsIiwidDgiLCJ0OSIsInQxMCIsInQxMSIsInQxMiIsInQxMyIsInQxNCIsInQxNSIsInQxNiIsInQxNyIsImlzTG9hZGluZyIsInQxOCIsImlzRXJyb3IiLCJyZWZldGNoIiwidDE5IiwiaXNTdWNjZXNzIiwibGVuZ3RoIiwidDIwIiwidGVhbSIsInQyMSIsImlzUGVuZGluZyIsInQyMiIsInQyMyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IFByaXZhdGVOYXZpZ2F0aW9uIH0gZnJvbSBcIi4uLy4uLy4uL2NvbXBvbmVudHMvbGF5b3V0L1ByaXZhdGVOYXZpZ2F0aW9uXCI7XG5pbXBvcnQgeyBDb25maXJtRGlhbG9nIH0gZnJvbSBcIi4uLy4uLy4uL2NvbXBvbmVudHMvdGFza3MvQ29uZmlybURpYWxvZ1wiO1xuaW1wb3J0IHsgQnV0dG9uLCBUb29sYmFyLCBUb29sYmFySGVhZGVyIH0gZnJvbSBcIi4uLy4uLy4uL2NvbXBvbmVudHMvdGFza3Mvc3R5bGVzXCI7XG5pbXBvcnQgeyBFcnJvclN0YXRlLCBMb2FkaW5nU3RhdGUgfSBmcm9tIFwiLi4vLi4vLi4vY29tcG9uZW50cy90YXNrcy9UYXNrU3RhdGVzXCI7XG5pbXBvcnQgeyBUZWFtRm9ybU1vZGFsIH0gZnJvbSBcIi4uLy4uLy4uL2NvbXBvbmVudHMvdGVhbXMvVGVhbUZvcm1Nb2RhbFwiO1xuaW1wb3J0IHsgVGVhbUxpc3QgfSBmcm9tIFwiLi4vLi4vLi4vY29tcG9uZW50cy90ZWFtcy9UZWFtTGlzdFwiO1xuaW1wb3J0IHsgRW1wdHlUZWFtc1N0YXRlIH0gZnJvbSBcIi4uLy4uLy4uL2NvbXBvbmVudHMvdGVhbXMvVGVhbVN0YXRlc1wiO1xuaW1wb3J0IHsgU3VjY2Vzc01lc3NhZ2UgfSBmcm9tIFwiLi4vLi4vLi4vY29tcG9uZW50cy90ZWFtcy9zdHlsZXNcIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vLi4vLi4vaG9va3MvYXV0aFwiO1xuaW1wb3J0IHsgdXNlQ3JlYXRlVGVhbSwgdXNlRGVsZXRlVGVhbSwgdXNlVGVhbXMsIHVzZVVzZXJzIH0gZnJvbSBcIi4uLy4uLy4uL2hvb2tzL3Rhc2tzL3VzZVRhc2tzXCI7XG5pbXBvcnQgdHlwZSB7IFRlYW0sIFRlYW1SZXF1ZXN0IH0gZnJvbSBcIi4uLy4uLy4uL2ludGVyZmFjZXMvdGFza3MvdGVhbVwiO1xuaW1wb3J0IHsgQXBpUmVxdWVzdEVycm9yIH0gZnJvbSBcIi4uLy4uLy4uL3NlcnZpY2VzL2FwaVwiO1xuaW1wb3J0IHsgSGVhZGVyQWN0aW9ucywgVGVhbXNTaGVsbCwgVGVhbXNUb3BCYXIsIFRlYW1zVXNlckluZm8gfSBmcm9tIFwiLi9zdHlsZXNcIjtcblxuZnVuY3Rpb24gZ2V0RXJyb3JNZXNzYWdlKGVycm9yOiB1bmtub3duKSB7XG4gIGlmIChlcnJvciBpbnN0YW5jZW9mIEFwaVJlcXVlc3RFcnJvcikge1xuICAgIHJldHVybiBlcnJvci5tZXNzYWdlO1xuICB9XG5cbiAgcmV0dXJuIFwiTmFvIGZvaSBwb3NzaXZlbCBjb25jbHVpciBhIG9wZXJhY2FvLlwiO1xufVxuXG5jb25zdCBUZWFtcyA9ICgpID0+IHtcbiAgY29uc3QgeyBzaWduT3V0LCB1c2VyIH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IHRlYW1zUXVlcnkgPSB1c2VUZWFtcygpO1xuICBjb25zdCB1c2Vyc1F1ZXJ5ID0gdXNlVXNlcnMoKTtcbiAgY29uc3QgY3JlYXRlVGVhbSA9IHVzZUNyZWF0ZVRlYW0oKTtcbiAgY29uc3QgZGVsZXRlVGVhbSA9IHVzZURlbGV0ZVRlYW0oKTtcbiAgY29uc3QgW2lzRm9ybU9wZW4sIHNldElzRm9ybU9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZm9ybUVycm9yLCBzZXRGb3JtRXJyb3JdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtsaXN0RXJyb3IsIHNldExpc3RFcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3N1Y2Nlc3NNZXNzYWdlLCBzZXRTdWNjZXNzTWVzc2FnZV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3RlYW1Ub0RlbGV0ZSwgc2V0VGVhbVRvRGVsZXRlXSA9IHVzZVN0YXRlPFRlYW0gfCBudWxsPihudWxsKTtcblxuICBjb25zdCB0ZWFtcyA9IHRlYW1zUXVlcnkuZGF0YSA/PyBbXTtcbiAgY29uc3QgdXNlcnMgPSB1c2Vyc1F1ZXJ5LmRhdGEgPz8gW107XG5cbiAgZnVuY3Rpb24gb3BlbkZvcm0oKSB7XG4gICAgc2V0Rm9ybUVycm9yKFwiXCIpO1xuICAgIHNldExpc3RFcnJvcihcIlwiKTtcbiAgICBzZXRTdWNjZXNzTWVzc2FnZShcIlwiKTtcbiAgICBzZXRJc0Zvcm1PcGVuKHRydWUpO1xuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlU3VibWl0VGVhbShwYXlsb2FkOiBUZWFtUmVxdWVzdCkge1xuICAgIHNldEZvcm1FcnJvcihcIlwiKTtcblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCBjcmVhdGVUZWFtLm11dGF0ZUFzeW5jKHBheWxvYWQpO1xuICAgICAgc2V0SXNGb3JtT3BlbihmYWxzZSk7XG4gICAgICBzZXRTdWNjZXNzTWVzc2FnZShcIlRpbWUgY2FkYXN0cmFkbyBjb20gc3VjZXNzby5cIik7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHNldEZvcm1FcnJvcihnZXRFcnJvck1lc3NhZ2UoZXJyb3IpKTtcbiAgICB9XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVEZWxldGVUZWFtKCkge1xuICAgIGlmICghdGVhbVRvRGVsZXRlKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgc2V0TGlzdEVycm9yKFwiXCIpO1xuICAgIHNldFN1Y2Nlc3NNZXNzYWdlKFwiXCIpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGRlbGV0ZVRlYW0ubXV0YXRlQXN5bmModGVhbVRvRGVsZXRlLmlkKTtcbiAgICAgIHNldFRlYW1Ub0RlbGV0ZShudWxsKTtcbiAgICAgIHNldFN1Y2Nlc3NNZXNzYWdlKFwiVGltZSBleGNsdWlkbyBjb20gc3VjZXNzby5cIik7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHNldExpc3RFcnJvcihnZXRFcnJvck1lc3NhZ2UoZXJyb3IpKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxUZWFtc1NoZWxsPlxuICAgICAgPFRlYW1zVG9wQmFyPlxuICAgICAgICA8VGVhbXNVc2VySW5mbz5cbiAgICAgICAgICA8c3Ryb25nPnt1c2VyPy5uYW1lfTwvc3Ryb25nPlxuICAgICAgICAgIDxzcGFuPnt1c2VyPy5lbWFpbH08L3NwYW4+XG4gICAgICAgIDwvVGVhbXNVc2VySW5mbz5cbiAgICAgICAgPFByaXZhdGVOYXZpZ2F0aW9uIC8+XG4gICAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiICR2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXtzaWduT3V0fT5cbiAgICAgICAgICBTYWlyXG4gICAgICAgIDwvQnV0dG9uPlxuICAgICAgPC9UZWFtc1RvcEJhcj5cblxuICAgICAgPFRvb2xiYXI+XG4gICAgICAgIDxUb29sYmFySGVhZGVyPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDE+VGltZXM8L2gxPlxuICAgICAgICAgICAgPHA+R2VyZW5jaWUgZXF1aXBlcyBlIG1lbWJyb3MgZGlzcG9uaXZlaXMgcGFyYSBhcyB0YXJlZmFzLjwvcD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxIZWFkZXJBY3Rpb25zPlxuICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17b3BlbkZvcm19PlxuICAgICAgICAgICAgICBOb3ZvIFRpbWVcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvSGVhZGVyQWN0aW9ucz5cbiAgICAgICAgPC9Ub29sYmFySGVhZGVyPlxuICAgICAgPC9Ub29sYmFyPlxuXG4gICAgICB7c3VjY2Vzc01lc3NhZ2UgPyA8U3VjY2Vzc01lc3NhZ2Ugcm9sZT1cInN0YXR1c1wiPntzdWNjZXNzTWVzc2FnZX08L1N1Y2Nlc3NNZXNzYWdlPiA6IG51bGx9XG4gICAgICB7bGlzdEVycm9yID8gPEVycm9yU3RhdGUgbWVzc2FnZT17bGlzdEVycm9yfSAvPiA6IG51bGx9XG5cbiAgICAgIHt0ZWFtc1F1ZXJ5LmlzTG9hZGluZyA/IDxMb2FkaW5nU3RhdGUgbWVzc2FnZT1cIkNhcnJlZ2FuZG8gdGltZXMuLi5cIiAvPiA6IG51bGx9XG5cbiAgICAgIHt0ZWFtc1F1ZXJ5LmlzRXJyb3IgPyAoXG4gICAgICAgIDxFcnJvclN0YXRlIG1lc3NhZ2U9e2dldEVycm9yTWVzc2FnZSh0ZWFtc1F1ZXJ5LmVycm9yKX0gb25SZXRyeT17KCkgPT4gdGVhbXNRdWVyeS5yZWZldGNoKCl9IC8+XG4gICAgICApIDogbnVsbH1cblxuICAgICAge3RlYW1zUXVlcnkuaXNTdWNjZXNzICYmIHRlYW1zLmxlbmd0aCA9PT0gMCA/IDxFbXB0eVRlYW1zU3RhdGUgb25DcmVhdGU9e29wZW5Gb3JtfSAvPiA6IG51bGx9XG5cbiAgICAgIHt0ZWFtc1F1ZXJ5LmlzU3VjY2VzcyAmJiB0ZWFtcy5sZW5ndGggPiAwID8gKFxuICAgICAgICA8VGVhbUxpc3RcbiAgICAgICAgICB0ZWFtcz17dGVhbXN9XG4gICAgICAgICAgb25EZWxldGVUZWFtPXsodGVhbSkgPT4ge1xuICAgICAgICAgICAgc2V0TGlzdEVycm9yKFwiXCIpO1xuICAgICAgICAgICAgc2V0U3VjY2Vzc01lc3NhZ2UoXCJcIik7XG4gICAgICAgICAgICBzZXRUZWFtVG9EZWxldGUodGVhbSk7XG4gICAgICAgICAgfX1cbiAgICAgICAgLz5cbiAgICAgICkgOiBudWxsfVxuXG4gICAgICB7aXNGb3JtT3BlbiA/IChcbiAgICAgICAgPFRlYW1Gb3JtTW9kYWxcbiAgICAgICAgICB1c2Vycz17dXNlcnN9XG4gICAgICAgICAgdXNlcnNFcnJvcj17dXNlcnNRdWVyeS5pc0Vycm9yID8gZ2V0RXJyb3JNZXNzYWdlKHVzZXJzUXVlcnkuZXJyb3IpIDogXCJcIn1cbiAgICAgICAgICBpc0xvYWRpbmdVc2Vycz17dXNlcnNRdWVyeS5pc0xvYWRpbmd9XG4gICAgICAgICAgYXBpRXJyb3I9e2Zvcm1FcnJvcn1cbiAgICAgICAgICBpc0xvYWRpbmc9e2NyZWF0ZVRlYW0uaXNQZW5kaW5nfVxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldElzRm9ybU9wZW4oZmFsc2UpfVxuICAgICAgICAgIG9uU3VibWl0PXtoYW5kbGVTdWJtaXRUZWFtfVxuICAgICAgICAvPlxuICAgICAgKSA6IG51bGx9XG5cbiAgICAgIHt0ZWFtVG9EZWxldGUgPyAoXG4gICAgICAgIDxDb25maXJtRGlhbG9nXG4gICAgICAgICAgdGl0bGU9XCJFeGNsdWlyIHRpbWVcIlxuICAgICAgICAgIG1lc3NhZ2U9e2BUZW0gY2VydGV6YSBxdWUgZGVzZWphIGV4Y2x1aXIgXCIke3RlYW1Ub0RlbGV0ZS5uYW1lfVwiPyBFc3NhIGFjYW8gc28gc2VyYSBjb25jbHVpZGEgc2UgbmFvIGhvdXZlciBkZW1hbmRhcyB2aW5jdWxhZGFzIGFvIHRpbWUuYH1cbiAgICAgICAgICBjb25maXJtTGFiZWw9XCJFeGNsdWlyXCJcbiAgICAgICAgICBlcnJvck1lc3NhZ2U9e2xpc3RFcnJvcn1cbiAgICAgICAgICBpc0xvYWRpbmc9e2RlbGV0ZVRlYW0uaXNQZW5kaW5nfVxuICAgICAgICAgIG9uQ2FuY2VsPXsoKSA9PiB7XG4gICAgICAgICAgICBpZiAoIWRlbGV0ZVRlYW0uaXNQZW5kaW5nKSB7XG4gICAgICAgICAgICAgIHNldFRlYW1Ub0RlbGV0ZShudWxsKTtcbiAgICAgICAgICAgICAgc2V0TGlzdEVycm9yKFwiXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH19XG4gICAgICAgICAgb25Db25maXJtPXtoYW5kbGVEZWxldGVUZWFtfVxuICAgICAgICAvPlxuICAgICAgKSA6IG51bGx9XG4gICAgPC9UZWFtc1NoZWxsPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgVGVhbXM7XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3dhbGxhL0Rlc2t0b3AvUHJvamV0b3MtcGVzc29haXMvcHJvdmEtdGVjbmljYS9mcm9udC1taW5pLXRhc2stbWFuYWdlci9zcmMvcGFnZXMvcHJpdmF0ZS9UZWFtcy9pbmRleC50c3gifQ==