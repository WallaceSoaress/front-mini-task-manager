import { n as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-BPOCksWG.js?v=7c503575";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=df6b4f96";
//#region node_modules/@emotion/memoize/dist/emotion-memoize.esm.js
function memoize(fn) {
	var cache = Object.create(null);
	return function(arg) {
		if (cache[arg] === void 0) cache[arg] = fn(arg);
		return cache[arg];
	};
}
//#endregion
//#region node_modules/@emotion/is-prop-valid/dist/emotion-is-prop-valid.esm.js
var reactPropsRegex = /^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|abbr|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|disableRemotePlayback|download|draggable|encType|enterKeyHint|fetchpriority|fetchPriority|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|popover|popoverTarget|popoverTargetAction|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|translate|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|incremental|fallback|inert|itemProp|itemScope|itemType|itemID|itemRef|on|option|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/;
var isPropValid = /* #__PURE__ */ memoize(function(prop) {
	return reactPropsRegex.test(prop) || prop.charCodeAt(0) === 111 && prop.charCodeAt(1) === 110 && prop.charCodeAt(2) < 91;
});
//#endregion
//#region node_modules/stylis/src/Enum.js
var MS = "-ms-";
var MOZ = "-moz-";
var WEBKIT = "-webkit-";
var COMMENT = "comm";
var RULESET = "rule";
var DECLARATION = "decl";
var IMPORT = "@import";
var NAMESPACE = "@namespace";
var KEYFRAMES = "@keyframes";
var LAYER = "@layer";
//#endregion
//#region node_modules/stylis/src/Utility.js
/**
* @param {number}
* @return {number}
*/
var abs = Math.abs;
/**
* @param {number}
* @return {string}
*/
var from = String.fromCharCode;
/**
* @param {object}
* @return {object}
*/
var assign = Object.assign;
/**
* @param {string} value
* @param {number} length
* @return {number}
*/
function hash(value, length) {
	return charat(value, 0) ^ 45 ? (((length << 2 ^ charat(value, 0)) << 2 ^ charat(value, 1)) << 2 ^ charat(value, 2)) << 2 ^ charat(value, 3) : 0;
}
/**
* @param {string} value
* @return {string}
*/
function trim(value) {
	return value.trim();
}
/**
* @param {string} value
* @param {RegExp} pattern
* @return {string?}
*/
function match(value, pattern) {
	return (value = pattern.exec(value)) ? value[0] : value;
}
/**
* @param {string} value
* @param {(string|RegExp)} pattern
* @param {string} replacement
* @return {string}
*/
function replace(value, pattern, replacement) {
	return value.replace(pattern, replacement);
}
/**
* @param {string} value
* @param {string} search
* @param {number} position
* @return {number}
*/
function indexof(value, search, position) {
	return value.indexOf(search, position);
}
/**
* @param {string} value
* @param {number} index
* @return {number}
*/
function charat(value, index) {
	return value.charCodeAt(index) | 0;
}
/**
* @param {string} value
* @param {number} begin
* @param {number} end
* @return {string}
*/
function substr(value, begin, end) {
	return value.slice(begin, end);
}
/**
* @param {string} value
* @return {number}
*/
function strlen(value) {
	return value.length;
}
/**
* @param {any[]} value
* @return {number}
*/
function sizeof(value) {
	return value.length;
}
/**
* @param {any} value
* @param {any[]} array
* @return {any}
*/
function append(value, array) {
	return array.push(value), value;
}
/**
* @param {string[]} array
* @param {function} callback
* @return {string}
*/
function combine(array, callback) {
	return array.map(callback).join("");
}
/**
* @param {string[]} array
* @param {RegExp} pattern
* @return {string[]}
*/
function filter(array, pattern) {
	return array.filter(function(value) {
		return !match(value, pattern);
	});
}
//#endregion
//#region node_modules/stylis/src/Tokenizer.js
var line = 1;
var column = 1;
var length = 0;
var position = 0;
var character = 0;
var characters = "";
/**
* @param {string} value
* @param {object | null} root
* @param {object | null} parent
* @param {string} type
* @param {string[] | string} props
* @param {object[] | string} children
* @param {object[]} siblings
* @param {number} length
*/
function node(value, root, parent, type, props, children, length, siblings) {
	return {
		value,
		root,
		parent,
		type,
		props,
		children,
		line,
		column,
		length,
		return: "",
		siblings
	};
}
/**
* @param {object} root
* @param {object} props
* @return {object}
*/
function copy(root, props) {
	return assign(node("", null, null, "", null, null, 0, root.siblings), root, { length: -root.length }, props);
}
/**
* @param {object} root
*/
function lift(root) {
	while (root.root) root = copy(root.root, { children: [root] });
	append(root, root.siblings);
}
/**
* @return {number}
*/
function char() {
	return character;
}
/**
* @return {number}
*/
function prev() {
	character = position > 0 ? charat(characters, --position) : 0;
	if (column--, character === 10) column = 1, line--;
	return character;
}
/**
* @return {number}
*/
function next() {
	character = position < length ? charat(characters, position++) : 0;
	if (column++, character === 10) column = 1, line++;
	return character;
}
/**
* @return {number}
*/
function peek() {
	return charat(characters, position);
}
/**
* @return {number}
*/
function caret() {
	return position;
}
/**
* @param {number} begin
* @param {number} end
* @return {string}
*/
function slice(begin, end) {
	return substr(characters, begin, end);
}
/**
* @param {number} type
* @return {number}
*/
function token(type) {
	switch (type) {
		case 0:
		case 9:
		case 10:
		case 13:
		case 32: return 5;
		case 33:
		case 43:
		case 44:
		case 47:
		case 62:
		case 64:
		case 126:
		case 59:
		case 123:
		case 125: return 4;
		case 58: return 3;
		case 34:
		case 39:
		case 40:
		case 91: return 2;
		case 41:
		case 93: return 1;
	}
	return 0;
}
/**
* @param {string} value
* @return {any[]}
*/
function alloc(value) {
	return line = column = 1, length = strlen(characters = value), position = 0, [];
}
/**
* @param {any} value
* @return {any}
*/
function dealloc(value) {
	return characters = "", value;
}
/**
* @param {number} type
* @return {string}
*/
function delimit(type) {
	return trim(slice(position - 1, delimiter(type === 91 ? type + 2 : type === 40 ? type + 1 : type)));
}
/**
* @param {number} type
* @return {string}
*/
function whitespace(type) {
	while (character = peek()) if (character < 33) next();
	else break;
	return token(type) > 2 || token(character) > 3 ? "" : " ";
}
/**
* @param {number} index
* @param {number} count
* @return {string}
*/
function escaping(index, count) {
	while (--count && next()) if (character < 48 || character > 102 || character > 57 && character < 65 || character > 70 && character < 97) break;
	return slice(index, caret() + (count < 6 && peek() == 32 && next() == 32));
}
/**
* @param {number} type
* @return {number}
*/
function delimiter(type) {
	while (next()) switch (character) {
		case type: return position;
		case 34:
		case 39:
			if (type !== 34 && type !== 39) delimiter(character);
			break;
		case 40:
			if (type === 41) delimiter(type);
			break;
		case 92:
			next();
			break;
	}
	return position;
}
/**
* @param {number} type
* @param {number} index
* @return {number}
*/
function commenter(type, index) {
	while (next()) if (type + character === 57) break;
	else if (type + character === 84 && peek() === 47) break;
	return "/*" + slice(index, position - 1) + "*" + from(type === 47 ? type : next());
}
/**
* @param {number} index
* @return {string}
*/
function identifier(index) {
	while (!token(peek())) next();
	return slice(index, position);
}
//#endregion
//#region node_modules/stylis/src/Parser.js
/**
* @param {string} value
* @return {object[]}
*/
function compile(value) {
	return dealloc(parse("", null, null, null, [""], value = alloc(value), 0, [0], value));
}
/**
* @param {string} value
* @param {object} root
* @param {object?} parent
* @param {string[]} rule
* @param {string[]} rules
* @param {string[]} rulesets
* @param {number[]} pseudo
* @param {number[]} points
* @param {string[]} declarations
* @return {object}
*/
function parse(value, root, parent, rule, rules, rulesets, pseudo, points, declarations) {
	var index = 0;
	var offset = 0;
	var length = pseudo;
	var atrule = 0;
	var property = 0;
	var previous = 0;
	var variable = 1;
	var scanning = 1;
	var ampersand = 1;
	var character = 0;
	var type = "";
	var props = rules;
	var children = rulesets;
	var reference = rule;
	var characters = type;
	while (scanning) switch (previous = character, character = next()) {
		case 40: if (previous != 108 && charat(characters, length - 1) == 58) {
			if (indexof(characters += replace(delimit(character), "&", "&\f"), "&\f", abs(index ? points[index - 1] : 0)) != -1) ampersand = -1;
			break;
		}
		case 34:
		case 39:
		case 91:
			characters += delimit(character);
			break;
		case 9:
		case 10:
		case 13:
		case 32:
			characters += whitespace(previous);
			break;
		case 92:
			characters += escaping(caret() - 1, 7);
			continue;
		case 47:
			switch (peek()) {
				case 42:
				case 47:
					append(comment(commenter(next(), caret()), root, parent, declarations), declarations);
					if ((token(previous || 1) == 5 || token(peek() || 1) == 5) && strlen(characters) && substr(characters, -1, void 0) !== " ") characters += " ";
					break;
				default: characters += "/";
			}
			break;
		case 123 * variable: points[index++] = strlen(characters) * ampersand;
		case 125 * variable:
		case 59:
		case 0:
			switch (character) {
				case 0:
				case 125: scanning = 0;
				case 59 + offset:
					if (ampersand == -1) characters = replace(characters, /\f/g, "");
					if (property > 0 && (strlen(characters) - length || variable === 0 && previous === 47)) append(property > 32 ? declaration(characters + ";", rule, parent, length - 1, declarations) : declaration(replace(characters, " ", "") + ";", rule, parent, length - 2, declarations), declarations);
					break;
				case 59: characters += ";";
				default:
					append(reference = ruleset(characters, root, parent, index, offset, rules, points, type, props = [], children = [], length, rulesets), rulesets);
					if (character === 123) if (offset === 0) parse(characters, root, reference, reference, props, rulesets, length, points, children);
					else {
						switch (atrule) {
							case 99: if (charat(characters, 3) === 110) break;
							case 108: if (charat(characters, 2) === 97) break;
							default: offset = 0;
							case 100:
							case 109:
							case 115:
						}
						if (offset) parse(value, reference, reference, rule && append(ruleset(value, reference, reference, 0, 0, rules, points, type, rules, props = [], length, children), children), rules, children, length, points, rule ? props : children);
						else parse(characters, reference, reference, reference, [""], children, 0, points, children);
					}
			}
			index = offset = property = 0, variable = ampersand = 1, type = characters = "", length = pseudo;
			break;
		case 58: length = 1 + strlen(characters), property = previous;
		default:
			if (variable < 1) {
				if (character == 123) --variable;
				else if (character == 125 && variable++ == 0 && prev() == 125) continue;
			}
			switch (characters += from(character), character * variable) {
				case 38:
					ampersand = offset > 0 ? 1 : (characters += "\f", -1);
					break;
				case 44:
					points[index++] = (strlen(characters) - 1) * ampersand, ampersand = 1;
					break;
				case 64:
					if (peek() === 45) characters += delimit(next());
					atrule = peek(), offset = length = strlen(type = characters += identifier(caret())), character++;
					break;
				case 45: if (previous === 45 && strlen(characters) == 2) variable = 0;
			}
	}
	return rulesets;
}
/**
* @param {string} value
* @param {object} root
* @param {object?} parent
* @param {number} index
* @param {number} offset
* @param {string[]} rules
* @param {number[]} points
* @param {string} type
* @param {string[]} props
* @param {string[]} children
* @param {number} length
* @param {object[]} siblings
* @return {object}
*/
function ruleset(value, root, parent, index, offset, rules, points, type, props, children, length, siblings) {
	var post = offset - 1;
	var rule = offset === 0 ? rules : [""];
	var size = sizeof(rule);
	for (var i = 0, j = 0, k = 0; i < index; ++i) for (var x = 0, y = substr(value, post + 1, post = abs(j = points[i])), z = value; x < size; ++x) if (z = trim(j > 0 ? rule[x] + " " + y : replace(y, /&\f/g, rule[x]))) props[k++] = z;
	return node(value, root, parent, offset === 0 ? RULESET : type, props, children, length, siblings);
}
/**
* @param {number} value
* @param {object} root
* @param {object?} parent
* @param {object[]} siblings
* @return {object}
*/
function comment(value, root, parent, siblings) {
	return node(value, root, parent, COMMENT, from(char()), substr(value, 2, -2), 0, siblings);
}
/**
* @param {string} value
* @param {object} root
* @param {object?} parent
* @param {number} length
* @param {object[]} siblings
* @return {object}
*/
function declaration(value, root, parent, length, siblings) {
	return node(value, root, parent, DECLARATION, substr(value, 0, length), substr(value, length + 1, -1), length, siblings);
}
//#endregion
//#region node_modules/stylis/src/Prefixer.js
/**
* @param {string} value
* @param {number} length
* @param {object[]} children
* @return {string}
*/
function prefix(value, length, children) {
	switch (hash(value, length)) {
		case 5103: return WEBKIT + "print-" + value + value;
		case 5737:
		case 4201:
		case 3177:
		case 3433:
		case 1641:
		case 4457:
		case 2921:
		case 5572:
		case 6356:
		case 5844:
		case 3191:
		case 6645:
		case 3005:
		case 4215:
		case 6389:
		case 5109:
		case 5365:
		case 5621:
		case 3829:
		case 6391:
		case 5879:
		case 5623:
		case 6135:
		case 4599: return WEBKIT + value + value;
		case 4855: return WEBKIT + value.replace("add", "source-over").replace("substract", "source-out").replace("intersect", "source-in").replace("exclude", "xor") + value;
		case 4789: return MOZ + value + value;
		case 5349:
		case 4246:
		case 4810:
		case 6968:
		case 2756: return WEBKIT + value + MOZ + value + MS + value + value;
		case 5936: switch (charat(value, length + 11)) {
			case 114: return WEBKIT + value + MS + replace(value, /[svh]\w+-[tblr]{2}/, "tb") + value;
			case 108: return WEBKIT + value + MS + replace(value, /[svh]\w+-[tblr]{2}/, "tb-rl") + value;
			case 45: return WEBKIT + value + MS + replace(value, /[svh]\w+-[tblr]{2}/, "lr") + value;
		}
		case 6828:
		case 4268:
		case 2903: return WEBKIT + value + MS + value + value;
		case 6165: return WEBKIT + value + MS + "flex-" + value + value;
		case 5187: return WEBKIT + value + replace(value, /(\w+).+(:[^]+)/, WEBKIT + "box-$1$2" + MS + "flex-$1$2") + value;
		case 5443: return WEBKIT + value + MS + "flex-item-" + replace(value, /flex-|-self/g, "") + (!match(value, /flex-|baseline/) ? MS + "grid-row-" + replace(value, /flex-|-self/g, "") : "") + value;
		case 4675: return WEBKIT + value + MS + "flex-line-pack" + replace(value, /align-content|flex-|-self/g, "") + value;
		case 5548: return WEBKIT + value + MS + replace(value, "shrink", "negative") + value;
		case 5292: return WEBKIT + value + MS + replace(value, "basis", "preferred-size") + value;
		case 6060: return WEBKIT + "box-" + replace(value, "-grow", "") + WEBKIT + value + MS + replace(value, "grow", "positive") + value;
		case 4554: return WEBKIT + replace(value, /([^-])(transform)/g, "$1" + WEBKIT + "$2") + value;
		case 6187: return replace(replace(replace(value, /(zoom-|grab)/, WEBKIT + "$1"), /(image-set)/, WEBKIT + "$1"), value, "") + value;
		case 5495:
		case 3959: return replace(value, /(image-set\([^]*)/, WEBKIT + "$1$`$1");
		case 4968: return replace(replace(value, /(.+:)(flex-)?(.*)/, WEBKIT + "box-pack:$3" + MS + "flex-pack:$3"), /space-between/, "justify") + WEBKIT + value + value;
		case 4200:
			if (!match(value, /flex-|baseline/)) return MS + "grid-column-align" + substr(value, length) + value;
			break;
		case 2592:
		case 3360: return MS + replace(value, "template-", "") + value;
		case 4384:
		case 3616:
			if (children && children.some(function(element, index) {
				return length = index, match(element.props, /grid-\w+-end/);
			})) return ~indexof(value + (children = children[length].value), "span", 0) ? value : MS + replace(value, "-start", "") + value + MS + "grid-row-span:" + (~indexof(children, "span", 0) ? match(children, /\d+/) : +match(children, /\d+/) - +match(value, /\d+/)) + ";";
			return MS + replace(value, "-start", "") + value;
		case 4896:
		case 4128: return children && children.some(function(element) {
			return match(element.props, /grid-\w+-start/);
		}) ? value : MS + replace(replace(value, "-end", "-span"), "span ", "") + value;
		case 4095:
		case 3583:
		case 4068:
		case 2532: return replace(value, /(.+)-inline(.+)/, WEBKIT + "$1$2") + value;
		case 8116:
		case 7059:
		case 5753:
		case 5535:
		case 5445:
		case 5701:
		case 4933:
		case 4677:
		case 5533:
		case 5789:
		case 5021:
		case 4765:
			if (strlen(value) - 1 - length > 6) switch (charat(value, length + 1)) {
				case 109: if (charat(value, length + 4) !== 45) break;
				case 102: return replace(value, /(.+:)(.+)-([^]+)/, "$1" + WEBKIT + "$2-$3$1" + MOZ + (charat(value, length + 3) == 108 ? "$3" : "$2-$3")) + value;
				case 115: return ~indexof(value, "stretch", 0) ? prefix(replace(value, "stretch", "fill-available"), length, children) + value : value;
			}
			break;
		case 5152:
		case 5920: return replace(value, /(.+?):(\d+)(\s*\/\s*(span)?\s*(\d+))?(.*)/, function(_, a, b, c, d, e, f) {
			return MS + a + ":" + b + f + (c ? MS + a + "-span:" + (d ? e : +e - +b) + f : "") + value;
		});
		case 4949:
			if (charat(value, length + 6) === 121) return replace(value, ":", ":" + WEBKIT) + value;
			break;
		case 6444:
			switch (charat(value, charat(value, 14) === 45 ? 18 : 11)) {
				case 120: return replace(value, /(.+:)([^;\s!]+)(;|(\s+)?!.+)?/, "$1" + WEBKIT + (charat(value, 14) === 45 ? "inline-" : "") + "box$3$1" + WEBKIT + "$2$3$1" + MS + "$2box$3") + value;
				case 100: return replace(value, ":", ":" + MS) + value;
			}
			break;
		case 5719:
		case 2647:
		case 2135:
		case 3927:
		case 2391: return replace(value, "scroll-", "scroll-snap-") + value;
	}
	return value;
}
//#endregion
//#region node_modules/stylis/src/Serializer.js
/**
* @param {object[]} children
* @param {function} callback
* @return {string}
*/
function serialize(children, callback) {
	var output = "";
	for (var i = 0; i < children.length; i++) output += callback(children[i], i, children, callback) || "";
	return output;
}
/**
* @param {object} element
* @param {number} index
* @param {object[]} children
* @param {function} callback
* @return {string}
*/
function stringify(element, index, children, callback) {
	switch (element.type) {
		case LAYER: if (element.children.length) break;
		case IMPORT:
		case NAMESPACE:
		case DECLARATION: return element.return = element.return || element.value;
		case COMMENT: return "";
		case KEYFRAMES: return element.return = element.value + "{" + serialize(element.children, callback) + "}";
		case RULESET: if (!strlen(element.value = element.props.join(","))) return "";
	}
	return strlen(children = serialize(element.children, callback)) ? element.return = element.value + "{" + children + "}" : "";
}
//#endregion
//#region node_modules/stylis/src/Middleware.js
/**
* @param {function[]} collection
* @return {function}
*/
function middleware(collection) {
	var length = sizeof(collection);
	return function(element, index, children, callback) {
		var output = "";
		for (var i = 0; i < length; i++) output += collection[i](element, index, children, callback) || "";
		return output;
	};
}
/**
* @param {function} callback
* @return {function}
*/
function rulesheet(callback) {
	return function(element) {
		if (!element.root) {
			if (element = element.return) callback(element);
		}
	};
}
/**
* @param {object} element
* @param {number} index
* @param {object[]} children
* @param {function} callback
*/
function prefixer(element, index, children, callback) {
	if (element.length > -1) {
		if (!element.return) switch (element.type) {
			case DECLARATION:
				element.return = prefix(element.value, element.length, children);
				return;
			case KEYFRAMES: return serialize([copy(element, { value: replace(element.value, "@", "@" + WEBKIT) })], callback);
			case RULESET: if (element.length) return combine(children = element.props, function(value) {
				switch (match(value, callback = /(::plac\w+|:read-\w+)/)) {
					case ":read-only":
					case ":read-write":
						lift(copy(element, { props: [replace(value, /:(read-\w+)/, ":" + MOZ + "$1")] }));
						lift(copy(element, { props: [value] }));
						assign(element, { props: filter(children, callback) });
						break;
					case "::placeholder":
						lift(copy(element, { props: [replace(value, /:(plac\w+)/, ":" + WEBKIT + "input-$1")] }));
						lift(copy(element, { props: [replace(value, /:(plac\w+)/, ":" + MOZ + "$1")] }));
						lift(copy(element, { props: [replace(value, /:(plac\w+)/, MS + "input-$1")] }));
						lift(copy(element, { props: [value] }));
						assign(element, { props: filter(children, callback) });
				}
				return "";
			});
		}
	}
}
//#endregion
//#region node_modules/styled-components/dist/styled-components.browser.esm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var r;
var i;
var c = "undefined" != typeof process && void 0 !== process.env && (process.env.REACT_APP_SC_ATTR || process.env.SC_ATTR) || "data-styled";
var a = "active";
var l = "data-styled-version";
var u = "6.5.3";
var h = "/*!sc*/\n";
var d = "undefined" != typeof window && "undefined" != typeof document;
function p(e) {
	if ("undefined" != typeof process && void 0 !== process.env) {
		const t = process.env[e];
		if (void 0 !== t && "" !== t) return "false" !== t;
	}
}
var f = Boolean("boolean" == typeof SC_DISABLE_SPEEDY ? SC_DISABLE_SPEEDY : null !== (i = null !== (r = p("REACT_APP_SC_DISABLE_SPEEDY")) && void 0 !== r ? r : p("SC_DISABLE_SPEEDY")) && void 0 !== i ? i : "undefined" != typeof process && void 0 !== process.env && true);
var m = "sc-keyframes-";
var y = {};
var g = {
	1: "Cannot create styled-component for component: %s.\n\n",
	2: "Can't collect styles once you've consumed a `ServerStyleSheet`'s styles! `ServerStyleSheet` is a one off instance for each server-side render cycle.\n\n- Are you trying to reuse it across renders?\n- Are you accidentally calling collectStyles twice?\n\n",
	3: "Streaming SSR is only supported in a Node.js environment; Please do not try to call this method in the browser.\n\n",
	4: "The `StyleSheetManager` expects a valid target or sheet prop!\n\n- Does this error occur on the client and is your target falsy?\n- Does this error occur on the server and is the sheet falsy?\n\n",
	5: "The clone method cannot be used on the client!\n\n- Are you running in a client-like environment on the server?\n- Are you trying to run SSR on the client?\n\n",
	6: "Trying to insert a new style tag, but the given Node is unmounted!\n\n- Are you using a custom target that isn't mounted?\n- Does your document not have a valid head element?\n- Have you accidentally removed a style tag manually?\n\n",
	7: "ThemeProvider: Please return an object from your \"theme\" prop function, e.g.\n\n```js\ntheme={() => ({})}\n```\n\n",
	8: "ThemeProvider: Please make your \"theme\" prop an object.\n\n",
	9: "Missing document `<head>`\n\n",
	10: "Cannot find a StyleSheet instance. Usually this happens if there are multiple copies of styled-components loaded at once. Check out this issue for how to troubleshoot and fix the common cases where this situation can happen: https://github.com/styled-components/styled-components/issues/1941#issuecomment-417862021\n\n",
	11: "_This error was replaced with a dev-time warning, it will be deleted for v4 final._ [createGlobalStyle] received children which will not be rendered. Please use the component without passing children elements.\n\n",
	12: "It seems you are interpolating a keyframe declaration (%s) into an untagged string. Please wrap your string in the css\\`\\` helper which ensures the styles are injected correctly. See https://styled-components.com/docs/api#css\n\n",
	13: "%s is not a styled component and cannot be referred to via component selector. See https://styled-components.com/docs/advanced#referring-to-other-components for more details.\n\n",
	14: "ThemeProvider: \"theme\" prop is required.\n\n",
	15: "A stylis plugin has been supplied that is not named. We need a name for each plugin to be able to prevent styling collisions between different stylis configurations within the same app. Before you pass your plugin to `<StyleSheetManager stylisPlugins={[]}>`, please make sure each plugin is uniquely-named, e.g.\n\n```js\nObject.defineProperty(importedPlugin, 'name', { value: 'some-unique-name' });\n```\n\n",
	16: "Reached the limit of how many styled components may be created at group %s.\nYou may only create up to 1,073,741,824 components. If you're creating components dynamically,\nas for instance in your render method then you may be running into this limitation.\n\n",
	17: "CSSStyleSheet could not be found on HTMLStyleElement.\nHas styled-components' style tag been unmounted or altered by another script?\n\n",
	18: "Accessing `useTheme` hook outside of a `<ThemeProvider>` element.\n\n```jsx\nimport { useTheme } from 'styled-components';\nexport function StyledCompoent({ children }) {\n  const theme = useTheme();\n  return <div style={{ width: theme.sizes.full }}>{children}</div>;\n}\n\nimport { StyledComponent } from './StyledComponent';\nimport { theme } from './theme';\nexport function App() {\n  return (\n    <ThemeProvider theme={theme}>\n      <StyledComponent />\n    </ThemeProvider>\n  );\n}\n```\n\nIf you need access to the theme in an uncertain composition scenario, `React.useContext(ThemeContext)` will not emit an error if there is no `ThemeProvider` ancestor.\n"
};
function v(e, ...t) {
	return new Error(function(...e) {
		let t = e[0];
		const n = [];
		for (let t = 1, o = e.length; t < o; t += 1) n.push(e[t]);
		return n.forEach((e) => {
			t = t.replace(/%[a-z]/, e);
		}), t;
	}(g[e], ...t).trim());
}
var S = 1 << 30;
var b = /* @__PURE__ */ new Map();
var w = /* @__PURE__ */ new Map();
var N = 1;
var C = (e) => {
	if (b.has(e)) return b.get(e);
	for (; w.has(N);) N++;
	const t = N++;
	if ((0 | t) < 0 || t > S) throw v(16, `${t}`);
	return b.set(e, t), w.set(t, e), t;
};
var O = (e) => w.get(e);
var E = (e, t) => {
	N = t + 1, b.set(e, t), w.set(t, e);
};
var A = /invalid hook call/i;
var P = /* @__PURE__ */ new Set();
var _ = (e, n) => {
	{
		const o = `The component ${e}${n ? ` with the id of "${n}"` : ""} has been created dynamically.\nYou may see this warning because you've called styled inside another component.\nTo resolve this only create new StyledComponents outside of any render method and function component.\nSee https://styled-components.com/docs/basics#define-styled-components-outside-of-the-render-method for more info.\n`, s = console.error;
		try {
			let e = !0;
			console.error = (t, ...n) => {
				A.test(t) ? (e = !1, P.delete(o)) : s(t, ...n);
			}, "function" == typeof import_react.useState && import_react.useState(null), e && !P.has(o) && (console.warn(o), P.add(o));
		} catch (e) {
			A.test(e.message) && P.delete(o);
		} finally {
			console.error = s;
		}
	}
};
var I = Object.freeze([]);
var $ = Object.freeze({});
function R(e, t, n = $) {
	return e.theme !== n.theme && e.theme || t || n.theme;
}
var j = /[!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~-]+/g;
var x = /(^-|-$)/g;
function T(e) {
	return e.replace(j, "-").replace(x, "");
}
var k = /(a)(d)/gi;
var D = (e) => String.fromCharCode(e + (e > 25 ? 39 : 97));
function V(e) {
	let t, n = "";
	for (t = Math.abs(e); t > 52; t = t / 52 | 0) n = D(t % 52) + n;
	return (D(t % 52) + n).replace(k, "$1-$2");
}
var M = 5381;
var G = (e, t) => {
	let n = t.length;
	for (; n;) e = 33 * e ^ t.charCodeAt(--n);
	return e;
};
var F = (e) => G(M, e);
function z(e) {
	return V(F(e) >>> 0);
}
function W(e) {
	return "string" == typeof e && e || e.displayName || e.name || "Component";
}
function L(e) {
	return "string" == typeof e && e.charAt(0) === e.charAt(0).toLowerCase();
}
function B(e) {
	return L(e) ? `styled.${e}` : `Styled(${W(e)})`;
}
var q = Symbol.for("react.memo");
var H = Symbol.for("react.forward_ref");
var Y = {
	contextType: !0,
	defaultProps: !0,
	displayName: !0,
	getDerivedStateFromError: !0,
	getDerivedStateFromProps: !0,
	propTypes: !0,
	type: !0
};
var U = {
	name: !0,
	length: !0,
	prototype: !0,
	caller: !0,
	callee: !0,
	arguments: !0,
	arity: !0
};
var J = {
	$$typeof: !0,
	compare: !0,
	defaultProps: !0,
	displayName: !0,
	propTypes: !0,
	type: !0
};
var X = {
	[H]: {
		$$typeof: !0,
		render: !0,
		defaultProps: !0,
		displayName: !0,
		propTypes: !0
	},
	[q]: J
};
function K(e) {
	return ("type" in (t = e) && t.type.$$typeof) === q ? J : "$$typeof" in e ? X[e.$$typeof] : Y;
	var t;
}
var Q = Object.defineProperty;
var Z = Object.getOwnPropertyNames;
var ee = Object.getOwnPropertySymbols;
var te = Object.getOwnPropertyDescriptor;
var ne = Object.getPrototypeOf;
var oe = Object.prototype;
function se(e, t, n) {
	if ("string" != typeof t) {
		const o = ne(t);
		o && o !== oe && se(e, o, n);
		const s = Z(t).concat(ee(t)), r = K(e), i = K(t);
		for (let o = 0; o < s.length; ++o) {
			const c = s[o];
			if (!(c in U || n && n[c] || i && c in i || r && c in r)) {
				const n = te(t, c);
				try {
					Q(e, c, n);
				} catch (e) {}
			}
		}
	}
	return e;
}
function re(e) {
	return "function" == typeof e;
}
var ie = Symbol.for("react.forward_ref");
function ce(e) {
	return null != e && ("object" == typeof e || "function" == typeof e) && e.$$typeof === ie && "styledComponentId" in e;
}
function ae(e, t) {
	return e && t ? e + " " + t : e || t || "";
}
function le(e, t) {
	return e.join(t || "");
}
function ue(e) {
	return null !== e && "object" == typeof e && e.constructor.name === Object.name && !("props" in e && e.$$typeof);
}
function he(e, t, n = !1) {
	if (!n && !ue(e) && !Array.isArray(e)) return t;
	if (Array.isArray(t)) for (let n = 0; n < t.length; n++) e[n] = he(e[n], t[n]);
	else if (ue(t)) for (const n in t) e[n] = he(e[n], t[n]);
	return e;
}
function de(e, t) {
	Object.defineProperty(e, "toString", { value: t });
}
var pe = class {
	constructor(e) {
		this.groupSizes = /* @__PURE__ */ new Uint32Array(512), this.length = 512, this.tag = e, this._cGroup = 0, this._cIndex = 0;
	}
	indexOfGroup(e) {
		if (e === this._cGroup) return this._cIndex;
		let t = this._cIndex;
		if (e > this._cGroup) for (let n = this._cGroup; n < e; n++) t += this.groupSizes[n];
		else for (let n = this._cGroup - 1; n >= e; n--) t -= this.groupSizes[n];
		return this._cGroup = e, this._cIndex = t, t;
	}
	insertRules(e, t) {
		if (e >= this.groupSizes.length) {
			const t = this.groupSizes, n = t.length;
			let o = n;
			for (; e >= o;) if (o <<= 1, o < 0) throw v(16, `${e}`);
			this.groupSizes = new Uint32Array(o), this.groupSizes.set(t), this.length = o;
			for (let e = n; e < o; e++) this.groupSizes[e] = 0;
		}
		let n = this.indexOfGroup(e + 1), o = 0;
		for (let s = 0, r = t.length; s < r; s++) this.tag.insertRule(n, t[s]) && (this.groupSizes[e]++, n++, o++);
		o > 0 && this._cGroup > e && (this._cIndex += o);
	}
	clearGroup(e) {
		if (e < this.length) {
			const t = this.groupSizes[e], n = this.indexOfGroup(e), o = n + t;
			this.groupSizes[e] = 0;
			for (let e = n; e < o; e++) this.tag.deleteRule(n);
			t > 0 && this._cGroup > e && (this._cIndex -= t);
		}
	}
	getGroup(e) {
		let t = "";
		if (e >= this.length || 0 === this.groupSizes[e]) return t;
		const n = this.groupSizes[e], o = this.indexOfGroup(e), s = o + n;
		for (let e = o; e < s; e++) t += this.tag.getRule(e) + h;
		return t;
	}
};
var fe = `style[${c}][${l}="${u}"]`;
var me = new RegExp(`^${c}\\.g(\\d+)\\[id="([\\w\\d-]+)"\\].*?"([^"]*)`);
var ye = (e) => "undefined" != typeof ShadowRoot && e instanceof ShadowRoot || "host" in e && 11 === e.nodeType;
var ge = (e) => {
	if (!e) return document;
	if (ye(e)) return e;
	if ("getRootNode" in e) {
		const t = e.getRootNode();
		if (ye(t)) return t;
	}
	return document;
};
var ve = (e, t, n) => {
	const o = n.split(",");
	let s;
	for (let n = 0, r = o.length; n < r; n++) (s = o[n]) && e.registerName(t, s);
};
var Se = (e, t) => {
	var n;
	const o = (null !== (n = t.textContent) && void 0 !== n ? n : "").split(h), s = [];
	for (let t = 0, n = o.length; t < n; t++) {
		const n = o[t].trim();
		if (!n) continue;
		const r = n.match(me);
		if (r) {
			const t = 0 | parseInt(r[1], 10), n = r[2];
			0 !== t && (E(n, t), ve(e, n, r[3]), e.getTag().insertRules(t, s)), s.length = 0;
		} else s.push(n);
	}
};
var be = (e) => {
	const t = ge(e.options.target).querySelectorAll(fe);
	for (let n = 0, o = t.length; n < o; n++) {
		const o = t[n];
		o && o.getAttribute(c) !== a && (Se(e, o), o.parentNode && o.parentNode.removeChild(o));
	}
};
var we = !1;
function Ne() {
	if (!1 !== we) return we;
	if ("undefined" != typeof document) {
		const e = document.head.querySelector("meta[property=\"csp-nonce\"]");
		if (e) return we = e.nonce || e.getAttribute("content") || void 0;
		const t = document.head.querySelector("meta[name=\"sc-nonce\"]");
		if (t) return we = t.getAttribute("content") || void 0;
	}
	return we = "undefined" != typeof __webpack_nonce__ ? __webpack_nonce__ : void 0;
}
var Ce = (e, t) => {
	const n = document.head, o = e || n, s = document.createElement("style"), r = ((e) => {
		const t = Array.from(e.querySelectorAll(`style[${c}]`));
		return t[t.length - 1];
	})(o), i = void 0 !== r ? r.nextSibling : null;
	s.setAttribute(c, a), s.setAttribute(l, u);
	const h = t || Ne();
	return h && s.setAttribute("nonce", h), o.insertBefore(s, i), s;
};
var Oe = class {
	constructor(e, t) {
		this.element = Ce(e, t), this.element.appendChild(document.createTextNode("")), this.sheet = ((e) => {
			var t;
			if (e.sheet) return e.sheet;
			const n = null !== (t = e.getRootNode().styleSheets) && void 0 !== t ? t : document.styleSheets;
			for (let t = 0, o = n.length; t < o; t++) {
				const o = n[t];
				if (o.ownerNode === e) return o;
			}
			throw v(17);
		})(this.element), this.length = 0;
	}
	insertRule(e, t) {
		try {
			return this.sheet.insertRule(t, e), this.length++, !0;
		} catch (e) {
			return !1;
		}
	}
	deleteRule(e) {
		this.sheet.deleteRule(e), this.length--;
	}
	getRule(e) {
		const t = this.sheet.cssRules[e];
		return t && t.cssText ? t.cssText : "";
	}
};
var Ee = class {
	constructor(e, t) {
		this.element = Ce(e, t), this.nodes = this.element.childNodes, this.length = 0;
	}
	insertRule(e, t) {
		if (e <= this.length && e >= 0) {
			const n = document.createTextNode(t);
			return this.element.insertBefore(n, this.nodes[e] || null), this.length++, !0;
		}
		return !1;
	}
	deleteRule(e) {
		this.element.removeChild(this.nodes[e]), this.length--;
	}
	getRule(e) {
		return e < this.length ? this.nodes[e].textContent : "";
	}
};
var Ae = d;
var Pe = {
	isServer: !d,
	useCSSOMInjection: !f
};
var _e = class _e {
	static registerId(e) {
		return C(e);
	}
	constructor(e = $, t = {}, n) {
		this.options = Object.assign(Object.assign({}, Pe), e), this.gs = t, this.keyframeIds = /* @__PURE__ */ new Set(), this.names = new Map(n), this.server = !!e.isServer, !this.server && d && Ae && (Ae = !1, be(this)), de(this, () => ((e) => {
			const t = e.getTag(), { length: n } = t;
			let o = "";
			for (let s = 0; s < n; s++) {
				const n = O(s);
				if (void 0 === n) continue;
				const r = e.names.get(n);
				if (void 0 === r || !r.size) continue;
				const i = t.getGroup(s);
				if (0 === i.length) continue;
				const a = c + ".g" + s + "[id=\"" + n + "\"]";
				let l = "";
				for (const e of r) e.length > 0 && (l += e + ",");
				o += i + a + "{content:\"" + l + "\"}/*!sc*/\n";
			}
			return o;
		})(this));
	}
	rehydrate() {
		!this.server && d && be(this);
	}
	reconstructWithOptions(e, t = !0) {
		const n = new _e(Object.assign(Object.assign({}, this.options), e), this.gs, t && this.names || void 0);
		return n.keyframeIds = new Set(this.keyframeIds), !this.server && d && e.target !== this.options.target && ge(this.options.target) !== ge(e.target) && be(n), n;
	}
	allocateGSInstance(e) {
		return this.gs[e] = (this.gs[e] || 0) + 1;
	}
	getTag() {
		return this.tag || (this.tag = (e = (({ useCSSOMInjection: e, target: t, nonce: n }) => e ? new Oe(t, n) : new Ee(t, n))(this.options), new pe(e)));
		var e;
	}
	hasNameForId(e, t) {
		var n, o;
		return null !== (o = null === (n = this.names.get(e)) || void 0 === n ? void 0 : n.has(t)) && void 0 !== o && o;
	}
	registerName(e, t) {
		C(e), e.startsWith(m) && this.keyframeIds.add(e);
		const n = this.names.get(e);
		n ? n.add(t) : this.names.set(e, /* @__PURE__ */ new Set([t]));
	}
	insertRules(e, t, n) {
		this.registerName(e, t), this.getTag().insertRules(C(e), n);
	}
	clearNames(e) {
		this.names.has(e) && this.names.get(e).clear();
	}
	clearRules(e) {
		this.getTag().clearGroup(C(e)), this.clearNames(e);
	}
	clearTag() {
		this.tag = void 0;
	}
};
var Ie = /* @__PURE__ */ new WeakSet();
var $e = {
	animationIterationCount: 1,
	aspectRatio: 1,
	borderImageOutset: 1,
	borderImageSlice: 1,
	borderImageWidth: 1,
	columnCount: 1,
	columns: 1,
	flex: 1,
	flexGrow: 1,
	flexShrink: 1,
	gridRow: 1,
	gridRowEnd: 1,
	gridRowSpan: 1,
	gridRowStart: 1,
	gridColumn: 1,
	gridColumnEnd: 1,
	gridColumnSpan: 1,
	gridColumnStart: 1,
	fontWeight: 1,
	lineHeight: 1,
	opacity: 1,
	order: 1,
	orphans: 1,
	scale: 1,
	tabSize: 1,
	widows: 1,
	zIndex: 1,
	zoom: 1,
	WebkitLineClamp: 1,
	fillOpacity: 1,
	floodOpacity: 1,
	stopOpacity: 1,
	strokeDasharray: 1,
	strokeDashoffset: 1,
	strokeMiterlimit: 1,
	strokeOpacity: 1,
	strokeWidth: 1
};
function Re(e, t) {
	return null == t || "boolean" == typeof t || "" === t ? "" : "number" != typeof t || 0 === t || e in $e || e.startsWith("--") ? String(t).trim() : t + "px";
}
var je = 47;
function xe(e) {
	if (45 === e.charCodeAt(0) && 45 === e.charCodeAt(1)) return e;
	let t = "";
	for (let n = 0; n < e.length; n++) {
		const o = e.charCodeAt(n);
		t += o >= 65 && o <= 90 ? "-" + String.fromCharCode(o + 32) : e[n];
	}
	return t.startsWith("ms-") ? "-" + t : t;
}
var Te = Symbol.for("sc-keyframes");
function ke(e) {
	return "object" == typeof e && null !== e && Te in e;
}
function De(e) {
	return re(e) && !(e.prototype && e.prototype.isReactComponent);
}
var Ve = (e) => null == e || !1 === e || "" === e;
var Me = Symbol.for("react.client.reference");
function Ge(e) {
	return e.$$typeof === Me;
}
function Fe(e) {
	const t = e.$$id, n = (t && t.includes("#") ? t.split("#").pop() : t) || e.name || "unknown";
	console.warn(`Interpolating a client component (${n}) as a selector is not supported in server components. The component selector pattern requires access to the component's internal class name, which is not available across the server/client boundary. Use a plain CSS class selector instead.`);
}
function ze(e, t) {
	for (const n in e) {
		const o = e[n];
		e.hasOwnProperty(n) && !Ve(o) && (Array.isArray(o) && Ie.has(o) || re(o) ? t.push(xe(n) + ":", o, ";") : ue(o) ? (t.push(n + " {"), ze(o, t), t.push("}")) : t.push(xe(n) + ": " + Re(n, o) + ";"));
	}
}
function We(e, t, n, o, s = []) {
	if (Ve(e)) return s;
	const r = typeof e;
	if ("string" === r) return s.push(e), s;
	if ("function" === r) {
		if (Ge(e)) return Fe(e), s;
		if (De(e) && t) {
			const r = e(t);
			return "object" != typeof r || Array.isArray(r) || ke(r) || ue(r) || null === r || console.error(`${W(e)} is not a styled component and cannot be referred to via component selector. See https://styled-components.com/docs/advanced#referring-to-other-components for more details.`), We(r, t, n, o, s);
		}
		return s.push(e), s;
	}
	if (Array.isArray(e)) {
		for (let r = 0; r < e.length; r++) We(e[r], t, n, o, s);
		return s;
	}
	return ce(e) ? (s.push(`.${e.styledComponentId}`), s) : ke(e) ? (n ? (e.inject(n, o), s.push(e.getName(o))) : s.push(e), s) : Ge(e) ? (Fe(e), s) : ue(e) ? e.toString !== Object.prototype.toString ? (s.push(e.toString()), s) : (ze(e, s), s) : (s.push(e.toString()), s);
}
var Le = F(u);
var Be = class {
	constructor(e, t, n) {
		this.rules = e, this.componentId = t, this.baseHash = G(Le, t), this.baseStyle = n, _e.registerId(t);
	}
	generateAndInjectStyles(e, t, n) {
		let o = this.baseStyle ? this.baseStyle.generateAndInjectStyles(e, t, n) : "";
		{
			let s = "";
			for (let o = 0; o < this.rules.length; o++) {
				const r = this.rules[o];
				if ("string" == typeof r) s += r;
				else if (r) if (De(r)) {
					const o = r(e);
					"string" == typeof o ? s += o : null != o && !1 !== o && ("object" != typeof o || Array.isArray(o) || ke(o) || ue(o) || console.error(`${W(r)} is not a styled component and cannot be referred to via component selector. See https://styled-components.com/docs/advanced#referring-to-other-components for more details.`), s += le(We(o, e, t, n)));
				} else s += le(We(r, e, t, n));
			}
			if (s) {
				this.dynamicNameCache || (this.dynamicNameCache = /* @__PURE__ */ new Map());
				const e = n.hash ? n.hash + s : s;
				let r = this.dynamicNameCache.get(e);
				if (!r) {
					if (r = V(G(G(this.baseHash, n.hash), s) >>> 0), this.dynamicNameCache.size >= 200) {
						const e = this.dynamicNameCache.keys().next().value;
						void 0 !== e && this.dynamicNameCache.delete(e);
					}
					this.dynamicNameCache.set(e, r);
				}
				if (!t.hasNameForId(this.componentId, r)) {
					const e = n(s, "." + r, void 0, this.componentId);
					t.insertRules(this.componentId, r, e);
				}
				o = ae(o, r);
			}
		}
		return o;
	}
};
var qe = /&/g;
function He(e, t) {
	let n = 0;
	for (; --t >= 0 && 92 === e.charCodeAt(t);) n++;
	return !(1 & ~n);
}
function Ye(e) {
	const t = e.length;
	let n = "", o = 0, s = 0, r = 0, i = !1, c = !1;
	for (let a = 0; a < t; a++) {
		const l = e.charCodeAt(a);
		if (0 !== r || i || l !== je || 42 !== e.charCodeAt(a + 1)) if (i) 42 === l && e.charCodeAt(a + 1) === je && (i = !1, a++);
		else if (34 !== l && 39 !== l || He(e, a)) {
			if (0 === r) if (123 === l) s++;
			else if (125 === l) {
				if (s--, s < 0) {
					c = !0;
					let n = a + 1;
					for (; n < t;) {
						const t = e.charCodeAt(n);
						if (59 === t || 10 === t) break;
						n++;
					}
					n < t && 59 === e.charCodeAt(n) && n++, s = 0, a = n - 1, o = n;
					continue;
				}
				0 === s && (n += e.substring(o, a + 1), o = a + 1);
			} else 59 === l && 0 === s && (n += e.substring(o, a + 1), o = a + 1);
		} else 0 === r ? r = l : r === l && (r = 0);
		else i = !0, a++;
	}
	return c || 0 !== s || 0 !== r ? (o < t && 0 === s && 0 === r && (n += e.substring(o)), n) : e;
}
function Ue(e, t) {
	const n = t + " ", o = "," + n;
	for (let s = 0; s < e.length; s++) {
		const r = e[s];
		if ("rule" === r.type) {
			r.value = (n + r.value).replaceAll(",", o);
			const e = r.props, t = [];
			for (let o = 0; o < e.length; o++) t[o] = n + e[o];
			r.props = t;
		}
		Array.isArray(r.children) && "@keyframes" !== r.type && Ue(r.children, t);
	}
	return e;
}
function Je({ options: e = $, plugins: t = I } = $) {
	let n, s, r;
	const i = (e, t, o) => o.startsWith(s) && o.endsWith(s) && o.replaceAll(s, "").length > 0 ? `.${n}` : e, c = t.slice();
	c.push((e) => {
		e.type === "rule" && e.value.includes("&") && (r || (r = new RegExp(`\\${s}\\b`, "g")), e.props[0] = e.props[0].replace(qe, s).replace(r, i));
	}), e.prefix && c.push(prefixer), c.push(stringify);
	let a = [];
	const l = middleware(c.concat(rulesheet((e) => a.push(e)))), u = (t, i = "", c = "", u = "&") => {
		n = u, s = i, r = void 0;
		const h = function(e) {
			const t = -1 !== e.indexOf("//"), n = -1 !== e.indexOf("}");
			if (!t && !n) return e;
			if (!t) return Ye(e);
			const o = e.length;
			let s = "", r = 0, i = 0, c = 0, a = 0, l = 0, u = !1;
			for (; i < o;) {
				const t = e.charCodeAt(i);
				if (34 !== t && 39 !== t || He(e, i)) if (0 === c) if (t === je && i + 1 < o && 42 === e.charCodeAt(i + 1)) {
					for (i += 2; i + 1 < o && (42 !== e.charCodeAt(i) || e.charCodeAt(i + 1) !== je);) i++;
					i += 2;
				} else if (40 !== t) if (41 !== t) if (a > 0) i++;
				else if (42 === t && i + 1 < o && e.charCodeAt(i + 1) === je) s += e.substring(r, i), i += 2, r = i, u = !0;
				else if (t === je && i + 1 < o && e.charCodeAt(i + 1) === je) {
					for (s += e.substring(r, i); i < o && 10 !== e.charCodeAt(i);) i++;
					r = i, u = !0;
				} else 123 === t ? l++ : 125 === t && l--, i++;
				else a > 0 && a--, i++;
				else a++, i++;
				else i++;
				else 0 === c ? c = t : c === t && (c = 0), i++;
			}
			return u ? (r < o && (s += e.substring(r)), 0 === l ? s : Ye(s)) : 0 === l ? e : Ye(e);
		}(t);
		let d = compile(c || i ? c + " " + i + " { " + h + " }" : h);
		return e.namespace && (d = Ue(d, e.namespace)), a = [], serialize(d, l), a;
	}, h = e;
	let d = M;
	for (let e = 0; e < t.length; e++) t[e].name || v(15), d = G(d, t[e].name);
	return null != h && h.namespace && (d = G(d, h.namespace)), null != h && h.prefix && (d = G(d, "p")), u.hash = d !== M ? d.toString() : "", u;
}
var Xe = new _e();
var Ke = Je();
var Qe = import_react.createContext({
	shouldForwardProp: void 0,
	styleSheet: Xe,
	stylis: Ke,
	stylisPlugins: void 0
});
var Ze = Qe.Consumer;
function et() {
	return import_react.useContext(Qe);
}
function tt(e) {
	var n;
	const o = et(), { styleSheet: s } = o, r = import_react.useMemo(() => {
		let t = s;
		return e.sheet ? t = e.sheet : e.target ? t = t.reconstructWithOptions(void 0 !== e.nonce ? {
			target: e.target,
			nonce: e.nonce
		} : { target: e.target }, !1) : void 0 !== e.nonce && (t = t.reconstructWithOptions({ nonce: e.nonce })), e.disableCSSOMInjection && (t = t.reconstructWithOptions({ useCSSOMInjection: !1 })), t;
	}, [
		e.disableCSSOMInjection,
		e.nonce,
		e.sheet,
		e.target,
		s
	]), i = import_react.useMemo(() => {
		var t;
		return void 0 === e.stylisPlugins && void 0 === e.namespace && void 0 === e.enableVendorPrefixes ? o.stylis : Je({
			options: {
				namespace: e.namespace,
				prefix: e.enableVendorPrefixes
			},
			plugins: null !== (t = e.stylisPlugins) && void 0 !== t ? t : o.stylisPlugins
		});
	}, [
		e.enableVendorPrefixes,
		e.namespace,
		e.stylisPlugins,
		o.stylis,
		o.stylisPlugins
	]), c = "shouldForwardProp" in e ? e.shouldForwardProp : o.shouldForwardProp, a = null !== (n = e.stylisPlugins) && void 0 !== n ? n : o.stylisPlugins, l = import_react.useMemo(() => ({
		shouldForwardProp: c,
		styleSheet: r,
		stylis: i,
		stylisPlugins: a
	}), [
		c,
		r,
		i,
		a
	]);
	return import_react.createElement(Qe.Provider, { value: l }, e.children);
}
var nt = import_react.createContext(void 0);
var ot = nt.Consumer;
function st() {
	const e = import_react.useContext(nt);
	if (!e) throw v(18);
	return e;
}
function rt(e) {
	const n = import_react.useContext(nt), o = import_react.useMemo(() => function(e, t) {
		if (!e) throw v(14);
		if (re(e)) {
			const n = e(t);
			if (null === n || Array.isArray(n) || "object" != typeof n) throw v(7);
			return n;
		}
		if (Array.isArray(e) || "object" != typeof e) throw v(8);
		return t ? Object.assign(Object.assign({}, t), e) : e;
	}(e.theme, n), [e.theme, n]);
	return e.children ? import_react.createElement(nt.Provider, { value: o }, e.children) : null;
}
var it = Object.prototype.hasOwnProperty;
var ct = {};
function at(e, t) {
	const n = "string" != typeof e ? "sc" : T(e);
	ct[n] = (ct[n] || 0) + 1;
	const o = n + "-" + z(u + n + ct[n]);
	return t ? t + "-" + o : o;
}
var lt;
function ut(o, s, r) {
	const i = ce(o), c = o, a = !L(o), { attrs: l = I, componentId: u = at(s.displayName, s.parentComponentId), displayName: h = B(o) } = s, d = s.displayName && s.componentId ? T(s.displayName) + "-" + s.componentId : s.componentId || u, p = i && c.attrs ? c.attrs.concat(l).filter(Boolean) : l;
	let { shouldForwardProp: f } = s;
	if (i && c.shouldForwardProp) {
		const e = c.shouldForwardProp;
		if (s.shouldForwardProp) {
			const t = s.shouldForwardProp;
			f = (n, o) => e(n, o) && t(n, o);
		} else f = e;
	}
	const m = new Be(r, d, i ? c.componentStyle : void 0);
	function y(o, s) {
		return function(o, s, r) {
			const { attrs: i, componentStyle: c, defaultProps: a, foldedComponentIds: l, styledComponentId: u, target: h } = o, d = import_react.useContext(nt), p = et(), f = o.shouldForwardProp || p.shouldForwardProp;
			import_react.useDebugValue && import_react.useDebugValue(u);
			const m = R(s, d, a) || $;
			let y, g;
			{
				const e = import_react.useRef(null), n = e.current;
				if (null !== n && n[1] === m && n[2] === p.styleSheet && n[3] === p.stylis && n[7] === c && function(e, t, n) {
					const o = e, s = t;
					let r = 0;
					for (const e in s) if (it.call(s, e) && (r++, o[e] !== s[e])) return !1;
					return r === n;
				}(n[0], s, n[4])) y = n[5], g = n[6];
				else {
					y = function(e, t, n) {
						const o = Object.assign(Object.assign({}, t), {
							className: void 0,
							theme: n
						}), s = e.length > 1;
						for (let n = 0; n < e.length; n++) {
							const r = e[n], i = re(r) ? r(s ? Object.assign({}, o) : o) : r;
							for (const e in i) "className" === e ? o.className = ae(o.className, i[e]) : "style" === e ? o.style = Object.assign(Object.assign({}, o.style), i[e]) : e in t && void 0 === t[e] || (o[e] = i[e]);
						}
						return "className" in t && "string" == typeof t.className && (o.className = ae(o.className, t.className)), o;
					}(i, s, m), g = c.generateAndInjectStyles(y, p.styleSheet, p.stylis);
					let t = 0;
					for (const e in s) it.call(s, e) && t++;
					e.current = [
						s,
						m,
						p.styleSheet,
						p.stylis,
						t,
						y,
						g,
						c
					];
				}
			}
			import_react.useDebugValue && import_react.useDebugValue(g), o.warnTooManyClasses && o.warnTooManyClasses(g);
			const v = y.as || h, S = function(t, n, o, s) {
				const r = {};
				for (const i in t) void 0 === t[i] || "$" === i[0] || "as" === i || "theme" === i && t.theme === o || ("forwardedAs" === i ? r.as = t.forwardedAs : s && !s(i, n) || (r[i] = t[i], s || isPropValid(i) || (lt || (lt = /* @__PURE__ */ new Set())).has(i) || !L(n) || n.includes("-") || (lt.add(i), console.warn(`styled-components: it looks like an unknown prop "${i}" is being sent through to the DOM, which will likely trigger a React console error. If you would like automatic filtering of unknown props, you can opt-into that behavior via \`<StyleSheetManager shouldForwardProp={...}>\` (connect an API like \`@emotion/is-prop-valid\`) or consider using transient props (\`$\` prefix for automatic filtering.)`))));
				return r;
			}(y, v, m, f);
			let b = ae(l, u);
			return g && (b += " " + g), y.className && (b += " " + y.className), S[L(v) && v.includes("-") ? "class" : "className"] = b, r && (S.ref = r), (0, import_react.createElement)(v, S);
		}(g, o, s);
	}
	y.displayName = h;
	let g = import_react.forwardRef(y);
	return g.attrs = p, g.componentStyle = m, g.displayName = h, g.shouldForwardProp = f, g.foldedComponentIds = i ? ae(c.foldedComponentIds, c.styledComponentId) : "", g.styledComponentId = d, g.target = i ? c.target : o, Object.defineProperty(g, "defaultProps", {
		get() {
			return this._foldedDefaultProps;
		},
		set(e) {
			this._foldedDefaultProps = i ? function(e, ...t) {
				for (const n of t) he(e, n, !0);
				return e;
			}({}, c.defaultProps, e) : e;
		}
	}), _(h, d), g.warnTooManyClasses = ((e, t) => {
		let n = {}, o = !1;
		return (s) => {
			!o && (n[s] = !0, Object.keys(n).length >= 200) && (console.warn(`Over 200 classes were generated for component ${e}${t ? ` with the id of "${t}"` : ""}.\nConsider using the attrs method, together with a style object for frequently changed styles.\nExample:\n  const Component = styled.div.attrs(props => ({\n    style: {\n      background: props.background,\n    },\n  }))\`width: 100%;\`\n\n  <Component />`), o = !0, n = {});
		};
	})(h, d), de(g, () => `.${g.styledComponentId}`), a && se(g, o, {
		attrs: !0,
		componentStyle: !0,
		displayName: !0,
		foldedComponentIds: !0,
		shouldForwardProp: !0,
		styledComponentId: !0,
		target: !0
	}), g;
}
var ht = /* @__PURE__ */ new Set([
	"a",
	"abbr",
	"address",
	"area",
	"article",
	"aside",
	"audio",
	"b",
	"bdi",
	"bdo",
	"blockquote",
	"body",
	"button",
	"br",
	"canvas",
	"caption",
	"cite",
	"code",
	"col",
	"colgroup",
	"data",
	"datalist",
	"dd",
	"del",
	"details",
	"dfn",
	"dialog",
	"div",
	"dl",
	"dt",
	"em",
	"embed",
	"fieldset",
	"figcaption",
	"figure",
	"footer",
	"form",
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6",
	"header",
	"hgroup",
	"hr",
	"html",
	"i",
	"iframe",
	"img",
	"input",
	"ins",
	"kbd",
	"label",
	"legend",
	"li",
	"main",
	"map",
	"mark",
	"menu",
	"meter",
	"nav",
	"object",
	"ol",
	"optgroup",
	"option",
	"output",
	"p",
	"picture",
	"pre",
	"progress",
	"q",
	"rp",
	"rt",
	"ruby",
	"s",
	"samp",
	"search",
	"section",
	"select",
	"slot",
	"small",
	"span",
	"strong",
	"sub",
	"summary",
	"sup",
	"table",
	"tbody",
	"td",
	"template",
	"textarea",
	"tfoot",
	"th",
	"thead",
	"time",
	"tr",
	"u",
	"ul",
	"var",
	"video",
	"wbr",
	"circle",
	"clipPath",
	"defs",
	"ellipse",
	"feBlend",
	"feColorMatrix",
	"feComponentTransfer",
	"feComposite",
	"feConvolveMatrix",
	"feDiffuseLighting",
	"feDisplacementMap",
	"feDistantLight",
	"feDropShadow",
	"feFlood",
	"feFuncA",
	"feFuncB",
	"feFuncG",
	"feFuncR",
	"feGaussianBlur",
	"feImage",
	"feMerge",
	"feMergeNode",
	"feMorphology",
	"feOffset",
	"fePointLight",
	"feSpecularLighting",
	"feSpotLight",
	"feTile",
	"feTurbulence",
	"filter",
	"foreignObject",
	"g",
	"image",
	"line",
	"linearGradient",
	"marker",
	"mask",
	"path",
	"pattern",
	"polygon",
	"polyline",
	"radialGradient",
	"rect",
	"stop",
	"svg",
	"switch",
	"symbol",
	"text",
	"textPath",
	"tspan",
	"use"
]);
function dt(e, t) {
	const n = [e[0]];
	for (let o = 0, s = t.length; o < s; o += 1) n.push(t[o], e[o + 1]);
	return n;
}
var pt = (e) => (Ie.add(e), e);
function ft(e, ...t) {
	if (re(e) || ue(e)) return pt(We(dt(I, [e, ...t])));
	const n = e;
	return 0 === t.length && 1 === n.length && "string" == typeof n[0] ? We(n) : pt(We(dt(n, t)));
}
function mt(e, t, n = $) {
	if (!t) throw v(1, t);
	const o = (o, ...s) => e(t, n, ft(o, ...s));
	return o.attrs = (o) => mt(e, t, Object.assign(Object.assign({}, n), { attrs: Array.prototype.concat(n.attrs, o).filter(Boolean) })), o.withConfig = (o) => mt(e, t, Object.assign(Object.assign({}, n), o)), o;
}
var yt = (e) => mt(ut, e);
var gt = yt;
ht.forEach((e) => {
	gt[e] = yt(e);
});
var vt = class {
	constructor(e, t) {
		this.instanceRules = /* @__PURE__ */ new Map(), this.rules = e, this.componentId = t, this.isStatic = function(e) {
			for (let t = 0; t < e.length; t += 1) {
				const n = e[t];
				if (re(n) && !ce(n)) return !1;
			}
			return !0;
		}(e), _e.registerId(this.componentId);
	}
	removeStyles(e, t) {
		this.instanceRules.delete(e), this.rebuildGroup(t);
	}
	renderStyles(e, t, n, o) {
		const s = this.componentId;
		if (this.isStatic) {
			if (n.hasNameForId(s, s + e)) this.instanceRules.has(e) || this.computeRules(e, t, n, o);
			else {
				const r = this.computeRules(e, t, n, o);
				n.insertRules(s, r.name, r.rules);
			}
			return;
		}
		const r = this.instanceRules.get(e);
		if (this.computeRules(e, t, n, o), !n.server && r) {
			const t = r.rules, n = this.instanceRules.get(e).rules;
			if (t.length === n.length) {
				let e = !0;
				for (let o = 0; o < t.length; o++) if (t[o] !== n[o]) {
					e = !1;
					break;
				}
				if (e) return;
			}
		}
		this.rebuildGroup(n);
	}
	computeRules(e, t, n, o) {
		const s = le(We(this.rules, t, n, o)), r = {
			name: this.componentId + e,
			rules: o(s, "")
		};
		return this.instanceRules.set(e, r), r;
	}
	rebuildGroup(e) {
		const t = this.componentId;
		e.clearRules(t);
		for (const n of this.instanceRules.values()) e.insertRules(t, n.name, n.rules);
	}
};
function St(e, ...n) {
	const o = ft(e, ...n), s = `sc-global-${z(JSON.stringify(o))}`, r = new vt(o, s);
	_(s);
	const i = (e) => {
		const n = et(), i = import_react.useContext(nt);
		let a;
		{
			const e = import_react.useRef(null);
			null === e.current && (e.current = n.styleSheet.allocateGSInstance(s)), a = e.current;
		}
		import_react.Children.count(e.children) && console.warn(`The global style component ${s} was given child JSX. createGlobalStyle does not render children.`), o.some((e) => "string" == typeof e && -1 !== e.indexOf("@import")) && console.warn("Please do not use @import CSS syntax in createGlobalStyle at this time, as the CSSOM APIs we use in production do not handle it well. Instead, we recommend using a library such as react-helmet to inject a typical <link> meta tag to the stylesheet, or simply embedding it manually in your index.html <head> section for a simpler app."), n.styleSheet.server && c(a, e, n.styleSheet, i, n.stylis);
		{
			const o = r.isStatic ? [
				a,
				n.styleSheet,
				r
			] : [
				a,
				e,
				n.styleSheet,
				i,
				n.stylis,
				r
			], l = import_react.useRef(r);
			import_react.useLayoutEffect(() => {
				n.styleSheet.server || (l.current !== r && (n.styleSheet.clearRules(s), l.current = r), c(a, e, n.styleSheet, i, n.stylis));
			}, o), import_react.useLayoutEffect(() => () => {
				n.styleSheet.server || r.removeStyles(a, n.styleSheet);
			}, [
				a,
				n.styleSheet,
				r
			]);
		}
		return n.styleSheet.server && r.instanceRules.delete(a), null;
	};
	function c(e, t, n, o, s) {
		if (r.isStatic) r.renderStyles(e, y, n, s);
		else {
			const c = Object.assign(Object.assign({}, t), { theme: R(t, o, i.defaultProps) });
			r.renderStyles(e, c, n, s);
		}
	}
	return import_react.memo(i);
}
function bt(e, t, n, o, s) {
	for (const r in e) {
		const i = e[r], c = s ? s + "-" + r : r;
		if ("object" == typeof i && null !== i) {
			const e = {};
			bt(i, t, e, o, c), n[r] = e;
		} else n[r] = o(c, i, r);
	}
}
function wt(e, t, n, o) {
	let s = "";
	for (const r in e) {
		const i = e[r], c = t[r], a = o ? o + "-" + r : r;
		"object" == typeof i && null !== i ? "object" == typeof c && null !== c && (s += wt(i, c, n, a)) : void 0 !== c && "function" != typeof c && (s += "--" + n + a + ":" + c + ";");
	}
	return s;
}
function Nt(e, t) {
	var n, o;
	const s = (null !== (n = null == t ? void 0 : t.prefix) && void 0 !== n ? n : "sc") + "-", r = null !== (o = null == t ? void 0 : t.selector) && void 0 !== o ? o : ":root", i = function(e, t) {
		const n = {};
		return bt(e, t, n, (e) => "--" + t + e), n;
	}(e, s), c = function(e, t) {
		const n = {};
		return bt(e, t, n, (e, n) => {
			{
				const t = String(n);
				let o = 0;
				for (let e = 0; e < t.length && (40 === t.charCodeAt(e) ? o++ : 41 === t.charCodeAt(e) && o--, !(o < 0)); e++);
				0 !== o && console.warn(`createTheme: value "${t}" at "${e}" contains unbalanced parentheses and may break the var() fallback`);
			}
			return "var(--" + t + e + ", " + n + ")";
		}), n;
	}(e, s), a = St`
    ${r} {
      ${(t) => wt(e, t.theme, s)}
    }
  `;
	return Object.assign(c, {
		GlobalStyle: a,
		raw: e,
		vars: i,
		resolve(t) {
			if (!d) throw new Error("createTheme.resolve() is client-only");
			const n = null != t ? t : document.documentElement;
			return function(e, t, n) {
				const o = {};
				return bt(e, t, o, (e, o) => n.getPropertyValue("--" + t + e).trim() || o), o;
			}(e, s, getComputedStyle(n));
		}
	});
}
var Ct;
var Ot = class {
	constructor(e, t) {
		this[Ct] = !0, this.inject = (e, t = Ke) => {
			const n = this.getName(t);
			if (!e.hasNameForId(this.id, n)) {
				const o = t(this.rules, n, "@keyframes");
				e.insertRules(this.id, n, o);
			}
		}, this.name = e, this.id = m + e, this.rules = t, C(this.id), de(this, () => {
			throw v(12, String(this.name));
		});
	}
	getName(e = Ke) {
		return e.hash ? this.name + V(+e.hash >>> 0) : this.name;
	}
};
function Et(e, ...t) {
	"undefined" != typeof navigator && "ReactNative" === navigator.product && console.warn("`keyframes` cannot be used on ReactNative, only on the web. To do animation in ReactNative please use Animated.");
	const n = le(ft(e, ...t));
	return new Ot(z(n), n);
}
function At(e) {
	const n = import_react.forwardRef((n, o) => {
		const s = R(n, import_react.useContext(nt), e.defaultProps);
		return void 0 === s && console.warn(`[withTheme] You are not using a ThemeProvider nor passing a theme prop or a theme in defaultProps in component class "${W(e)}"`), import_react.createElement(e, Object.assign(Object.assign({}, n), {
			theme: s,
			ref: o
		}));
	});
	return n.displayName = `WithTheme(${W(e)})`, se(n, e);
}
Ct = Te;
var Pt = class {
	constructor({ nonce: e } = {}) {
		this._emitSheetCSS = () => {
			const e = this.instance.toString();
			if (!e) return "";
			const t = this.instance.options.nonce || Ne();
			return `<style ${le([
				t && `nonce="${t}"`,
				`${c}="true"`,
				`${l}="${u}"`
			].filter(Boolean), " ")}>${e}</style>`;
		}, this.getStyleTags = () => {
			if (this.sealed) throw v(2);
			return this._emitSheetCSS();
		}, this.getStyleElement = () => {
			if (this.sealed) throw v(2);
			const e = this.instance.toString();
			if (!e) return [];
			const n = {
				[c]: "",
				[l]: u,
				dangerouslySetInnerHTML: { __html: e }
			}, o = this.instance.options.nonce || Ne();
			return o && (n.nonce = o), [import_react.createElement("style", Object.assign({}, n, { key: "sc-0-0" }))];
		}, this.seal = () => {
			this.sealed = !0;
		}, this.instance = new _e({
			isServer: !0,
			nonce: e
		}), this.sealed = !1;
	}
	collectStyles(e) {
		if (this.sealed) throw v(2);
		return import_react.createElement(tt, { sheet: this.instance }, e);
	}
	interleaveWithNodeStream(e) {
		throw v(3);
	}
};
var _t = {
	StyleSheet: _e,
	mainSheet: Xe
};
"undefined" != typeof navigator && "ReactNative" === navigator.product && console.warn("It looks like you've imported 'styled-components' on React Native.\nPerhaps you're looking to import 'styled-components/native'?\nRead more about this at https://styled-components.com/docs/basics#react-native");
var It = `__sc-${c}__`;
"undefined" != typeof window && (window[It] || (window[It] = 0), 1 === window[It] && console.warn("It looks like there are several instances of 'styled-components' initialized in this application. This may cause dynamic styles to not render properly, errors during the rehydration process, a missing theme prop, and makes your application bigger without good reason.\n\nSee https://styled-components.com/docs/faqs#why-am-i-getting-a-warning-about-several-instances-of-module-on-the-page for more info."), window[It] += 1);
var $t = /:(?:(first)-child|(last)-child|(only)-child|(nth-child)\(([^()]+)\)|(nth-last-child)\(([^()]+)\))/g;
var Rt = `:not(style[${c}])`;
var jt = `style[${c}]`;
function xt(e) {
	return -1 === e.indexOf("-child") ? e : ($t.lastIndex = 0, e.replace($t, (e, t, n, o, s, r, i, c) => t ? `:nth-child(1 of ${Rt})` : n ? `:nth-last-child(1 of ${Rt})` : o ? `:nth-child(1 of ${Rt}):nth-last-child(1 of ${Rt})` : s ? -1 !== r.indexOf(" of ") ? e : `:nth-child(${r} of ${Rt})` : -1 !== c.indexOf(" of ") ? e : `:nth-last-child(${c} of ${Rt})`));
}
function Tt(e, t) {
	if (-1 === e.indexOf("+")) return;
	let n = 0, o = 0;
	for (let s = 0; s < e.length; s++) {
		const r = e.charCodeAt(s);
		if (40 === r) n++;
		else if (41 === r) n--;
		else if (91 === r) o++;
		else if (93 === r) o--;
		else if (43 === r && 0 === n && 0 === o && !He(e, s)) {
			const n = e.substring(0, s), o = e.substring(s + 1);
			t.push(n + "+" + jt + "+" + o), t.push(n + "+" + jt + "+" + jt + "+" + o);
		}
	}
}
function kt(e) {
	if (e.type === "rule") {
		const t = e.props, n = [];
		for (let e = 0; e < t.length; e++) {
			const o = xt(t[e]);
			n.push(o), Tt(o, n);
		}
		e.props = n;
	}
}
//#endregion
export { Pt as ServerStyleSheet, Ze as StyleSheetConsumer, Qe as StyleSheetContext, tt as StyleSheetManager, ot as ThemeConsumer, nt as ThemeContext, rt as ThemeProvider, _t as __PRIVATE__, St as createGlobalStyle, Nt as createTheme, ft as css, gt as default, gt as styled, ce as isStyledComponent, Et as keyframes, kt as stylisPluginRSC, st as useTheme, u as version, At as withTheme };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3R5bGVkLWNvbXBvbmVudHMuanMiLCJuYW1lcyI6WyJvLnByZWZpeGVyIiwiby5zdHJpbmdpZnkiLCJvLm1pZGRsZXdhcmUiLCJvLnJ1bGVzaGVldCIsIm8uY29tcGlsZSIsIm8uc2VyaWFsaXplIiwiZSIsIm4iXSwic291cmNlcyI6WyIuLi8uLi9AZW1vdGlvbi9tZW1vaXplL2Rpc3QvZW1vdGlvbi1tZW1vaXplLmVzbS5qcyIsIi4uLy4uL0BlbW90aW9uL2lzLXByb3AtdmFsaWQvZGlzdC9lbW90aW9uLWlzLXByb3AtdmFsaWQuZXNtLmpzIiwiLi4vLi4vc3R5bGlzL3NyYy9FbnVtLmpzIiwiLi4vLi4vc3R5bGlzL3NyYy9VdGlsaXR5LmpzIiwiLi4vLi4vc3R5bGlzL3NyYy9Ub2tlbml6ZXIuanMiLCIuLi8uLi9zdHlsaXMvc3JjL1BhcnNlci5qcyIsIi4uLy4uL3N0eWxpcy9zcmMvUHJlZml4ZXIuanMiLCIuLi8uLi9zdHlsaXMvc3JjL1NlcmlhbGl6ZXIuanMiLCIuLi8uLi9zdHlsaXMvc3JjL01pZGRsZXdhcmUuanMiLCIuLi8uLi9zdHlsZWQtY29tcG9uZW50cy9kaXN0L3N0eWxlZC1jb21wb25lbnRzLmJyb3dzZXIuZXNtLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImZ1bmN0aW9uIG1lbW9pemUoZm4pIHtcbiAgdmFyIGNhY2hlID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgcmV0dXJuIGZ1bmN0aW9uIChhcmcpIHtcbiAgICBpZiAoY2FjaGVbYXJnXSA9PT0gdW5kZWZpbmVkKSBjYWNoZVthcmddID0gZm4oYXJnKTtcbiAgICByZXR1cm4gY2FjaGVbYXJnXTtcbiAgfTtcbn1cblxuZXhwb3J0IHsgbWVtb2l6ZSBhcyBkZWZhdWx0IH07XG4iLCJpbXBvcnQgbWVtb2l6ZSBmcm9tICdAZW1vdGlvbi9tZW1vaXplJztcblxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVuZGVmXG52YXIgcmVhY3RQcm9wc1JlZ2V4ID0gL14oKGNoaWxkcmVufGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MfGtleXxyZWZ8YXV0b0ZvY3VzfGRlZmF1bHRWYWx1ZXxkZWZhdWx0Q2hlY2tlZHxpbm5lckhUTUx8c3VwcHJlc3NDb250ZW50RWRpdGFibGVXYXJuaW5nfHN1cHByZXNzSHlkcmF0aW9uV2FybmluZ3x2YWx1ZUxpbmt8YWJicnxhY2NlcHR8YWNjZXB0Q2hhcnNldHxhY2Nlc3NLZXl8YWN0aW9ufGFsbG93fGFsbG93VXNlck1lZGlhfGFsbG93UGF5bWVudFJlcXVlc3R8YWxsb3dGdWxsU2NyZWVufGFsbG93VHJhbnNwYXJlbmN5fGFsdHxhc3luY3xhdXRvQ29tcGxldGV8YXV0b1BsYXl8Y2FwdHVyZXxjZWxsUGFkZGluZ3xjZWxsU3BhY2luZ3xjaGFsbGVuZ2V8Y2hhclNldHxjaGVja2VkfGNpdGV8Y2xhc3NJRHxjbGFzc05hbWV8Y29sc3xjb2xTcGFufGNvbnRlbnR8Y29udGVudEVkaXRhYmxlfGNvbnRleHRNZW51fGNvbnRyb2xzfGNvbnRyb2xzTGlzdHxjb29yZHN8Y3Jvc3NPcmlnaW58ZGF0YXxkYXRlVGltZXxkZWNvZGluZ3xkZWZhdWx0fGRlZmVyfGRpcnxkaXNhYmxlZHxkaXNhYmxlUGljdHVyZUluUGljdHVyZXxkaXNhYmxlUmVtb3RlUGxheWJhY2t8ZG93bmxvYWR8ZHJhZ2dhYmxlfGVuY1R5cGV8ZW50ZXJLZXlIaW50fGZldGNocHJpb3JpdHl8ZmV0Y2hQcmlvcml0eXxmb3JtfGZvcm1BY3Rpb258Zm9ybUVuY1R5cGV8Zm9ybU1ldGhvZHxmb3JtTm9WYWxpZGF0ZXxmb3JtVGFyZ2V0fGZyYW1lQm9yZGVyfGhlYWRlcnN8aGVpZ2h0fGhpZGRlbnxoaWdofGhyZWZ8aHJlZkxhbmd8aHRtbEZvcnxodHRwRXF1aXZ8aWR8aW5wdXRNb2RlfGludGVncml0eXxpc3xrZXlQYXJhbXN8a2V5VHlwZXxraW5kfGxhYmVsfGxhbmd8bGlzdHxsb2FkaW5nfGxvb3B8bG93fG1hcmdpbkhlaWdodHxtYXJnaW5XaWR0aHxtYXh8bWF4TGVuZ3RofG1lZGlhfG1lZGlhR3JvdXB8bWV0aG9kfG1pbnxtaW5MZW5ndGh8bXVsdGlwbGV8bXV0ZWR8bmFtZXxub25jZXxub1ZhbGlkYXRlfG9wZW58b3B0aW11bXxwYXR0ZXJufHBsYWNlaG9sZGVyfHBsYXlzSW5saW5lfHBvcG92ZXJ8cG9wb3ZlclRhcmdldHxwb3BvdmVyVGFyZ2V0QWN0aW9ufHBvc3RlcnxwcmVsb2FkfHByb2ZpbGV8cmFkaW9Hcm91cHxyZWFkT25seXxyZWZlcnJlclBvbGljeXxyZWx8cmVxdWlyZWR8cmV2ZXJzZWR8cm9sZXxyb3dzfHJvd1NwYW58c2FuZGJveHxzY29wZXxzY29wZWR8c2Nyb2xsaW5nfHNlYW1sZXNzfHNlbGVjdGVkfHNoYXBlfHNpemV8c2l6ZXN8c2xvdHxzcGFufHNwZWxsQ2hlY2t8c3JjfHNyY0RvY3xzcmNMYW5nfHNyY1NldHxzdGFydHxzdGVwfHN0eWxlfHN1bW1hcnl8dGFiSW5kZXh8dGFyZ2V0fHRpdGxlfHRyYW5zbGF0ZXx0eXBlfHVzZU1hcHx2YWx1ZXx3aWR0aHx3bW9kZXx3cmFwfGFib3V0fGRhdGF0eXBlfGlubGlzdHxwcmVmaXh8cHJvcGVydHl8cmVzb3VyY2V8dHlwZW9mfHZvY2FifGF1dG9DYXBpdGFsaXplfGF1dG9Db3JyZWN0fGF1dG9TYXZlfGNvbG9yfGluY3JlbWVudGFsfGZhbGxiYWNrfGluZXJ0fGl0ZW1Qcm9wfGl0ZW1TY29wZXxpdGVtVHlwZXxpdGVtSUR8aXRlbVJlZnxvbnxvcHRpb258cmVzdWx0c3xzZWN1cml0eXx1bnNlbGVjdGFibGV8YWNjZW50SGVpZ2h0fGFjY3VtdWxhdGV8YWRkaXRpdmV8YWxpZ25tZW50QmFzZWxpbmV8YWxsb3dSZW9yZGVyfGFscGhhYmV0aWN8YW1wbGl0dWRlfGFyYWJpY0Zvcm18YXNjZW50fGF0dHJpYnV0ZU5hbWV8YXR0cmlidXRlVHlwZXxhdXRvUmV2ZXJzZXxhemltdXRofGJhc2VGcmVxdWVuY3l8YmFzZWxpbmVTaGlmdHxiYXNlUHJvZmlsZXxiYm94fGJlZ2lufGJpYXN8Ynl8Y2FsY01vZGV8Y2FwSGVpZ2h0fGNsaXB8Y2xpcFBhdGhVbml0c3xjbGlwUGF0aHxjbGlwUnVsZXxjb2xvckludGVycG9sYXRpb258Y29sb3JJbnRlcnBvbGF0aW9uRmlsdGVyc3xjb2xvclByb2ZpbGV8Y29sb3JSZW5kZXJpbmd8Y29udGVudFNjcmlwdFR5cGV8Y29udGVudFN0eWxlVHlwZXxjdXJzb3J8Y3h8Y3l8ZHxkZWNlbGVyYXRlfGRlc2NlbnR8ZGlmZnVzZUNvbnN0YW50fGRpcmVjdGlvbnxkaXNwbGF5fGRpdmlzb3J8ZG9taW5hbnRCYXNlbGluZXxkdXJ8ZHh8ZHl8ZWRnZU1vZGV8ZWxldmF0aW9ufGVuYWJsZUJhY2tncm91bmR8ZW5kfGV4cG9uZW50fGV4dGVybmFsUmVzb3VyY2VzUmVxdWlyZWR8ZmlsbHxmaWxsT3BhY2l0eXxmaWxsUnVsZXxmaWx0ZXJ8ZmlsdGVyUmVzfGZpbHRlclVuaXRzfGZsb29kQ29sb3J8Zmxvb2RPcGFjaXR5fGZvY3VzYWJsZXxmb250RmFtaWx5fGZvbnRTaXplfGZvbnRTaXplQWRqdXN0fGZvbnRTdHJldGNofGZvbnRTdHlsZXxmb250VmFyaWFudHxmb250V2VpZ2h0fGZvcm1hdHxmcm9tfGZyfGZ4fGZ5fGcxfGcyfGdseXBoTmFtZXxnbHlwaE9yaWVudGF0aW9uSG9yaXpvbnRhbHxnbHlwaE9yaWVudGF0aW9uVmVydGljYWx8Z2x5cGhSZWZ8Z3JhZGllbnRUcmFuc2Zvcm18Z3JhZGllbnRVbml0c3xoYW5naW5nfGhvcml6QWR2WHxob3Jpek9yaWdpblh8aWRlb2dyYXBoaWN8aW1hZ2VSZW5kZXJpbmd8aW58aW4yfGludGVyY2VwdHxrfGsxfGsyfGszfGs0fGtlcm5lbE1hdHJpeHxrZXJuZWxVbml0TGVuZ3RofGtlcm5pbmd8a2V5UG9pbnRzfGtleVNwbGluZXN8a2V5VGltZXN8bGVuZ3RoQWRqdXN0fGxldHRlclNwYWNpbmd8bGlnaHRpbmdDb2xvcnxsaW1pdGluZ0NvbmVBbmdsZXxsb2NhbHxtYXJrZXJFbmR8bWFya2VyTWlkfG1hcmtlclN0YXJ0fG1hcmtlckhlaWdodHxtYXJrZXJVbml0c3xtYXJrZXJXaWR0aHxtYXNrfG1hc2tDb250ZW50VW5pdHN8bWFza1VuaXRzfG1hdGhlbWF0aWNhbHxtb2RlfG51bU9jdGF2ZXN8b2Zmc2V0fG9wYWNpdHl8b3BlcmF0b3J8b3JkZXJ8b3JpZW50fG9yaWVudGF0aW9ufG9yaWdpbnxvdmVyZmxvd3xvdmVybGluZVBvc2l0aW9ufG92ZXJsaW5lVGhpY2tuZXNzfHBhbm9zZTF8cGFpbnRPcmRlcnxwYXRoTGVuZ3RofHBhdHRlcm5Db250ZW50VW5pdHN8cGF0dGVyblRyYW5zZm9ybXxwYXR0ZXJuVW5pdHN8cG9pbnRlckV2ZW50c3xwb2ludHN8cG9pbnRzQXRYfHBvaW50c0F0WXxwb2ludHNBdFp8cHJlc2VydmVBbHBoYXxwcmVzZXJ2ZUFzcGVjdFJhdGlvfHByaW1pdGl2ZVVuaXRzfHJ8cmFkaXVzfHJlZlh8cmVmWXxyZW5kZXJpbmdJbnRlbnR8cmVwZWF0Q291bnR8cmVwZWF0RHVyfHJlcXVpcmVkRXh0ZW5zaW9uc3xyZXF1aXJlZEZlYXR1cmVzfHJlc3RhcnR8cmVzdWx0fHJvdGF0ZXxyeHxyeXxzY2FsZXxzZWVkfHNoYXBlUmVuZGVyaW5nfHNsb3BlfHNwYWNpbmd8c3BlY3VsYXJDb25zdGFudHxzcGVjdWxhckV4cG9uZW50fHNwZWVkfHNwcmVhZE1ldGhvZHxzdGFydE9mZnNldHxzdGREZXZpYXRpb258c3RlbWh8c3RlbXZ8c3RpdGNoVGlsZXN8c3RvcENvbG9yfHN0b3BPcGFjaXR5fHN0cmlrZXRocm91Z2hQb3NpdGlvbnxzdHJpa2V0aHJvdWdoVGhpY2tuZXNzfHN0cmluZ3xzdHJva2V8c3Ryb2tlRGFzaGFycmF5fHN0cm9rZURhc2hvZmZzZXR8c3Ryb2tlTGluZWNhcHxzdHJva2VMaW5lam9pbnxzdHJva2VNaXRlcmxpbWl0fHN0cm9rZU9wYWNpdHl8c3Ryb2tlV2lkdGh8c3VyZmFjZVNjYWxlfHN5c3RlbUxhbmd1YWdlfHRhYmxlVmFsdWVzfHRhcmdldFh8dGFyZ2V0WXx0ZXh0QW5jaG9yfHRleHREZWNvcmF0aW9ufHRleHRSZW5kZXJpbmd8dGV4dExlbmd0aHx0b3x0cmFuc2Zvcm18dTF8dTJ8dW5kZXJsaW5lUG9zaXRpb258dW5kZXJsaW5lVGhpY2tuZXNzfHVuaWNvZGV8dW5pY29kZUJpZGl8dW5pY29kZVJhbmdlfHVuaXRzUGVyRW18dkFscGhhYmV0aWN8dkhhbmdpbmd8dklkZW9ncmFwaGljfHZNYXRoZW1hdGljYWx8dmFsdWVzfHZlY3RvckVmZmVjdHx2ZXJzaW9ufHZlcnRBZHZZfHZlcnRPcmlnaW5YfHZlcnRPcmlnaW5ZfHZpZXdCb3h8dmlld1RhcmdldHx2aXNpYmlsaXR5fHdpZHRoc3x3b3JkU3BhY2luZ3x3cml0aW5nTW9kZXx4fHhIZWlnaHR8eDF8eDJ8eENoYW5uZWxTZWxlY3Rvcnx4bGlua0FjdHVhdGV8eGxpbmtBcmNyb2xlfHhsaW5rSHJlZnx4bGlua1JvbGV8eGxpbmtTaG93fHhsaW5rVGl0bGV8eGxpbmtUeXBlfHhtbEJhc2V8eG1sbnN8eG1sbnNYbGlua3x4bWxMYW5nfHhtbFNwYWNlfHl8eTF8eTJ8eUNoYW5uZWxTZWxlY3Rvcnx6fHpvb21BbmRQYW58Zm9yfGNsYXNzfGF1dG9mb2N1cyl8KChbRGRdW0FhXVtUdF1bQWFdfFtBYV1bUnJdW0lpXVtBYV18eCktLiopKSQvOyAvLyBodHRwczovL2VzYmVuY2guY29tL2JlbmNoLzViZmVlNjhhNGNkN2U2MDA5ZWY2MWQyM1xuXG52YXIgaXNQcm9wVmFsaWQgPSAvKiAjX19QVVJFX18gKi9tZW1vaXplKGZ1bmN0aW9uIChwcm9wKSB7XG4gIHJldHVybiByZWFjdFByb3BzUmVnZXgudGVzdChwcm9wKSB8fCBwcm9wLmNoYXJDb2RlQXQoMCkgPT09IDExMVxuICAvKiBvICovXG4gICYmIHByb3AuY2hhckNvZGVBdCgxKSA9PT0gMTEwXG4gIC8qIG4gKi9cbiAgJiYgcHJvcC5jaGFyQ29kZUF0KDIpIDwgOTE7XG59XG4vKiBaKzEgKi9cbik7XG5cbmV4cG9ydCB7IGlzUHJvcFZhbGlkIGFzIGRlZmF1bHQgfTtcbiIsImV4cG9ydCB2YXIgTVMgPSAnLW1zLSdcbmV4cG9ydCB2YXIgTU9aID0gJy1tb3otJ1xuZXhwb3J0IHZhciBXRUJLSVQgPSAnLXdlYmtpdC0nXG5cbmV4cG9ydCB2YXIgQ09NTUVOVCA9ICdjb21tJ1xuZXhwb3J0IHZhciBSVUxFU0VUID0gJ3J1bGUnXG5leHBvcnQgdmFyIERFQ0xBUkFUSU9OID0gJ2RlY2wnXG5cbmV4cG9ydCB2YXIgUEFHRSA9ICdAcGFnZSdcbmV4cG9ydCB2YXIgTUVESUEgPSAnQG1lZGlhJ1xuZXhwb3J0IHZhciBJTVBPUlQgPSAnQGltcG9ydCdcbmV4cG9ydCB2YXIgQ0hBUlNFVCA9ICdAY2hhcnNldCdcbmV4cG9ydCB2YXIgVklFV1BPUlQgPSAnQHZpZXdwb3J0J1xuZXhwb3J0IHZhciBTVVBQT1JUUyA9ICdAc3VwcG9ydHMnXG5leHBvcnQgdmFyIERPQ1VNRU5UID0gJ0Bkb2N1bWVudCdcbmV4cG9ydCB2YXIgTkFNRVNQQUNFID0gJ0BuYW1lc3BhY2UnXG5leHBvcnQgdmFyIEtFWUZSQU1FUyA9ICdAa2V5ZnJhbWVzJ1xuZXhwb3J0IHZhciBGT05UX0ZBQ0UgPSAnQGZvbnQtZmFjZSdcbmV4cG9ydCB2YXIgQ09VTlRFUl9TVFlMRSA9ICdAY291bnRlci1zdHlsZSdcbmV4cG9ydCB2YXIgRk9OVF9GRUFUVVJFX1ZBTFVFUyA9ICdAZm9udC1mZWF0dXJlLXZhbHVlcydcbmV4cG9ydCB2YXIgTEFZRVIgPSAnQGxheWVyJ1xuZXhwb3J0IHZhciBTQ09QRSA9ICdAc2NvcGUnXG4iLCIvKipcbiAqIEBwYXJhbSB7bnVtYmVyfVxuICogQHJldHVybiB7bnVtYmVyfVxuICovXG5leHBvcnQgdmFyIGFicyA9IE1hdGguYWJzXG5cbi8qKlxuICogQHBhcmFtIHtudW1iZXJ9XG4gKiBAcmV0dXJuIHtzdHJpbmd9XG4gKi9cbmV4cG9ydCB2YXIgZnJvbSA9IFN0cmluZy5mcm9tQ2hhckNvZGVcblxuLyoqXG4gKiBAcGFyYW0ge29iamVjdH1cbiAqIEByZXR1cm4ge29iamVjdH1cbiAqL1xuZXhwb3J0IHZhciBhc3NpZ24gPSBPYmplY3QuYXNzaWduXG5cbi8qKlxuICogQHBhcmFtIHtzdHJpbmd9IHZhbHVlXG4gKiBAcGFyYW0ge251bWJlcn0gbGVuZ3RoXG4gKiBAcmV0dXJuIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBoYXNoICh2YWx1ZSwgbGVuZ3RoKSB7XG5cdHJldHVybiBjaGFyYXQodmFsdWUsIDApIF4gNDUgPyAoKCgoKCgobGVuZ3RoIDw8IDIpIF4gY2hhcmF0KHZhbHVlLCAwKSkgPDwgMikgXiBjaGFyYXQodmFsdWUsIDEpKSA8PCAyKSBeIGNoYXJhdCh2YWx1ZSwgMikpIDw8IDIpIF4gY2hhcmF0KHZhbHVlLCAzKSA6IDBcbn1cblxuLyoqXG4gKiBAcGFyYW0ge3N0cmluZ30gdmFsdWVcbiAqIEByZXR1cm4ge3N0cmluZ31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRyaW0gKHZhbHVlKSB7XG5cdHJldHVybiB2YWx1ZS50cmltKClcbn1cblxuLyoqXG4gKiBAcGFyYW0ge3N0cmluZ30gdmFsdWVcbiAqIEBwYXJhbSB7UmVnRXhwfSBwYXR0ZXJuXG4gKiBAcmV0dXJuIHtzdHJpbmc/fVxuICovXG5leHBvcnQgZnVuY3Rpb24gbWF0Y2ggKHZhbHVlLCBwYXR0ZXJuKSB7XG5cdHJldHVybiAodmFsdWUgPSBwYXR0ZXJuLmV4ZWModmFsdWUpKSA/IHZhbHVlWzBdIDogdmFsdWVcbn1cblxuLyoqXG4gKiBAcGFyYW0ge3N0cmluZ30gdmFsdWVcbiAqIEBwYXJhbSB7KHN0cmluZ3xSZWdFeHApfSBwYXR0ZXJuXG4gKiBAcGFyYW0ge3N0cmluZ30gcmVwbGFjZW1lbnRcbiAqIEByZXR1cm4ge3N0cmluZ31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlcGxhY2UgKHZhbHVlLCBwYXR0ZXJuLCByZXBsYWNlbWVudCkge1xuXHRyZXR1cm4gdmFsdWUucmVwbGFjZShwYXR0ZXJuLCByZXBsYWNlbWVudClcbn1cblxuLyoqXG4gKiBAcGFyYW0ge3N0cmluZ30gdmFsdWVcbiAqIEBwYXJhbSB7c3RyaW5nfSBzZWFyY2hcbiAqIEBwYXJhbSB7bnVtYmVyfSBwb3NpdGlvblxuICogQHJldHVybiB7bnVtYmVyfVxuICovXG5leHBvcnQgZnVuY3Rpb24gaW5kZXhvZiAodmFsdWUsIHNlYXJjaCwgcG9zaXRpb24pIHtcblx0cmV0dXJuIHZhbHVlLmluZGV4T2Yoc2VhcmNoLCBwb3NpdGlvbilcbn1cblxuLyoqXG4gKiBAcGFyYW0ge3N0cmluZ30gdmFsdWVcbiAqIEBwYXJhbSB7bnVtYmVyfSBpbmRleFxuICogQHJldHVybiB7bnVtYmVyfVxuICovXG5leHBvcnQgZnVuY3Rpb24gY2hhcmF0ICh2YWx1ZSwgaW5kZXgpIHtcblx0cmV0dXJuIHZhbHVlLmNoYXJDb2RlQXQoaW5kZXgpIHwgMFxufVxuXG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nfSB2YWx1ZVxuICogQHBhcmFtIHtudW1iZXJ9IGJlZ2luXG4gKiBAcGFyYW0ge251bWJlcn0gZW5kXG4gKiBAcmV0dXJuIHtzdHJpbmd9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzdWJzdHIgKHZhbHVlLCBiZWdpbiwgZW5kKSB7XG5cdHJldHVybiB2YWx1ZS5zbGljZShiZWdpbiwgZW5kKVxufVxuXG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nfSB2YWx1ZVxuICogQHJldHVybiB7bnVtYmVyfVxuICovXG5leHBvcnQgZnVuY3Rpb24gc3RybGVuICh2YWx1ZSkge1xuXHRyZXR1cm4gdmFsdWUubGVuZ3RoXG59XG5cbi8qKlxuICogQHBhcmFtIHthbnlbXX0gdmFsdWVcbiAqIEByZXR1cm4ge251bWJlcn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNpemVvZiAodmFsdWUpIHtcblx0cmV0dXJuIHZhbHVlLmxlbmd0aFxufVxuXG4vKipcbiAqIEBwYXJhbSB7YW55fSB2YWx1ZVxuICogQHBhcmFtIHthbnlbXX0gYXJyYXlcbiAqIEByZXR1cm4ge2FueX1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFwcGVuZCAodmFsdWUsIGFycmF5KSB7XG5cdHJldHVybiBhcnJheS5wdXNoKHZhbHVlKSwgdmFsdWVcbn1cblxuLyoqXG4gKiBAcGFyYW0ge3N0cmluZ1tdfSBhcnJheVxuICogQHBhcmFtIHtmdW5jdGlvbn0gY2FsbGJhY2tcbiAqIEByZXR1cm4ge3N0cmluZ31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNvbWJpbmUgKGFycmF5LCBjYWxsYmFjaykge1xuXHRyZXR1cm4gYXJyYXkubWFwKGNhbGxiYWNrKS5qb2luKCcnKVxufVxuXG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nW119IGFycmF5XG4gKiBAcGFyYW0ge1JlZ0V4cH0gcGF0dGVyblxuICogQHJldHVybiB7c3RyaW5nW119XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmaWx0ZXIgKGFycmF5LCBwYXR0ZXJuKSB7XG5cdHJldHVybiBhcnJheS5maWx0ZXIoZnVuY3Rpb24gKHZhbHVlKSB7IHJldHVybiAhbWF0Y2godmFsdWUsIHBhdHRlcm4pIH0pXG59XG4iLCJpbXBvcnQge2Zyb20sIHRyaW0sIGNoYXJhdCwgc3RybGVuLCBzdWJzdHIsIGFwcGVuZCwgYXNzaWdufSBmcm9tICcuL1V0aWxpdHkuanMnXG5cbmV4cG9ydCB2YXIgbGluZSA9IDFcbmV4cG9ydCB2YXIgY29sdW1uID0gMVxuZXhwb3J0IHZhciBsZW5ndGggPSAwXG5leHBvcnQgdmFyIHBvc2l0aW9uID0gMFxuZXhwb3J0IHZhciBjaGFyYWN0ZXIgPSAwXG5leHBvcnQgdmFyIGNoYXJhY3RlcnMgPSAnJ1xuXG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nfSB2YWx1ZVxuICogQHBhcmFtIHtvYmplY3QgfCBudWxsfSByb290XG4gKiBAcGFyYW0ge29iamVjdCB8IG51bGx9IHBhcmVudFxuICogQHBhcmFtIHtzdHJpbmd9IHR5cGVcbiAqIEBwYXJhbSB7c3RyaW5nW10gfCBzdHJpbmd9IHByb3BzXG4gKiBAcGFyYW0ge29iamVjdFtdIHwgc3RyaW5nfSBjaGlsZHJlblxuICogQHBhcmFtIHtvYmplY3RbXX0gc2libGluZ3NcbiAqIEBwYXJhbSB7bnVtYmVyfSBsZW5ndGhcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG5vZGUgKHZhbHVlLCByb290LCBwYXJlbnQsIHR5cGUsIHByb3BzLCBjaGlsZHJlbiwgbGVuZ3RoLCBzaWJsaW5ncykge1xuXHRyZXR1cm4ge3ZhbHVlOiB2YWx1ZSwgcm9vdDogcm9vdCwgcGFyZW50OiBwYXJlbnQsIHR5cGU6IHR5cGUsIHByb3BzOiBwcm9wcywgY2hpbGRyZW46IGNoaWxkcmVuLCBsaW5lOiBsaW5lLCBjb2x1bW46IGNvbHVtbiwgbGVuZ3RoOiBsZW5ndGgsIHJldHVybjogJycsIHNpYmxpbmdzOiBzaWJsaW5nc31cbn1cblxuLyoqXG4gKiBAcGFyYW0ge29iamVjdH0gcm9vdFxuICogQHBhcmFtIHtvYmplY3R9IHByb3BzXG4gKiBAcmV0dXJuIHtvYmplY3R9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb3B5IChyb290LCBwcm9wcykge1xuXHRyZXR1cm4gYXNzaWduKG5vZGUoJycsIG51bGwsIG51bGwsICcnLCBudWxsLCBudWxsLCAwLCByb290LnNpYmxpbmdzKSwgcm9vdCwge2xlbmd0aDogLXJvb3QubGVuZ3RofSwgcHJvcHMpXG59XG5cbi8qKlxuICogQHBhcmFtIHtvYmplY3R9IHJvb3RcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGxpZnQgKHJvb3QpIHtcblx0d2hpbGUgKHJvb3Qucm9vdClcblx0XHRyb290ID0gY29weShyb290LnJvb3QsIHtjaGlsZHJlbjogW3Jvb3RdfSlcblxuXHRhcHBlbmQocm9vdCwgcm9vdC5zaWJsaW5ncylcbn1cblxuLyoqXG4gKiBAcmV0dXJuIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjaGFyICgpIHtcblx0cmV0dXJuIGNoYXJhY3RlclxufVxuXG4vKipcbiAqIEByZXR1cm4ge251bWJlcn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHByZXYgKCkge1xuXHRjaGFyYWN0ZXIgPSBwb3NpdGlvbiA+IDAgPyBjaGFyYXQoY2hhcmFjdGVycywgLS1wb3NpdGlvbikgOiAwXG5cblx0aWYgKGNvbHVtbi0tLCBjaGFyYWN0ZXIgPT09IDEwKVxuXHRcdGNvbHVtbiA9IDEsIGxpbmUtLVxuXG5cdHJldHVybiBjaGFyYWN0ZXJcbn1cblxuLyoqXG4gKiBAcmV0dXJuIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBuZXh0ICgpIHtcblx0Y2hhcmFjdGVyID0gcG9zaXRpb24gPCBsZW5ndGggPyBjaGFyYXQoY2hhcmFjdGVycywgcG9zaXRpb24rKykgOiAwXG5cblx0aWYgKGNvbHVtbisrLCBjaGFyYWN0ZXIgPT09IDEwKVxuXHRcdGNvbHVtbiA9IDEsIGxpbmUrK1xuXG5cdHJldHVybiBjaGFyYWN0ZXJcbn1cblxuLyoqXG4gKiBAcmV0dXJuIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwZWVrICgpIHtcblx0cmV0dXJuIGNoYXJhdChjaGFyYWN0ZXJzLCBwb3NpdGlvbilcbn1cblxuLyoqXG4gKiBAcmV0dXJuIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjYXJldCAoKSB7XG5cdHJldHVybiBwb3NpdGlvblxufVxuXG4vKipcbiAqIEBwYXJhbSB7bnVtYmVyfSBiZWdpblxuICogQHBhcmFtIHtudW1iZXJ9IGVuZFxuICogQHJldHVybiB7c3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gc2xpY2UgKGJlZ2luLCBlbmQpIHtcblx0cmV0dXJuIHN1YnN0cihjaGFyYWN0ZXJzLCBiZWdpbiwgZW5kKVxufVxuXG4vKipcbiAqIEBwYXJhbSB7bnVtYmVyfSB0eXBlXG4gKiBAcmV0dXJuIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0b2tlbiAodHlwZSkge1xuXHRzd2l0Y2ggKHR5cGUpIHtcblx0XHQvLyBcXDAgXFx0IFxcbiBcXHIgXFxzIHdoaXRlc3BhY2UgdG9rZW5cblx0XHRjYXNlIDA6IGNhc2UgOTogY2FzZSAxMDogY2FzZSAxMzogY2FzZSAzMjpcblx0XHRcdHJldHVybiA1XG5cdFx0Ly8gISArICwgLyA+IEAgfiBpc29sYXRlIHRva2VuXG5cdFx0Y2FzZSAzMzogY2FzZSA0MzogY2FzZSA0NDogY2FzZSA0NzogY2FzZSA2MjogY2FzZSA2NDogY2FzZSAxMjY6XG5cdFx0Ly8gOyB7IH0gYnJlYWtwb2ludCB0b2tlblxuXHRcdGNhc2UgNTk6IGNhc2UgMTIzOiBjYXNlIDEyNTpcblx0XHRcdHJldHVybiA0XG5cdFx0Ly8gOiBhY2NvbXBhbmllZCB0b2tlblxuXHRcdGNhc2UgNTg6XG5cdFx0XHRyZXR1cm4gM1xuXHRcdC8vIFwiICcgKCBbIG9wZW5pbmcgZGVsaW1pdCB0b2tlblxuXHRcdGNhc2UgMzQ6IGNhc2UgMzk6IGNhc2UgNDA6IGNhc2UgOTE6XG5cdFx0XHRyZXR1cm4gMlxuXHRcdC8vICkgXSBjbG9zaW5nIGRlbGltaXQgdG9rZW5cblx0XHRjYXNlIDQxOiBjYXNlIDkzOlxuXHRcdFx0cmV0dXJuIDFcblx0fVxuXG5cdHJldHVybiAwXG59XG5cbi8qKlxuICogQHBhcmFtIHtzdHJpbmd9IHZhbHVlXG4gKiBAcmV0dXJuIHthbnlbXX1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFsbG9jICh2YWx1ZSkge1xuXHRyZXR1cm4gbGluZSA9IGNvbHVtbiA9IDEsIGxlbmd0aCA9IHN0cmxlbihjaGFyYWN0ZXJzID0gdmFsdWUpLCBwb3NpdGlvbiA9IDAsIFtdXG59XG5cbi8qKlxuICogQHBhcmFtIHthbnl9IHZhbHVlXG4gKiBAcmV0dXJuIHthbnl9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZWFsbG9jICh2YWx1ZSkge1xuXHRyZXR1cm4gY2hhcmFjdGVycyA9ICcnLCB2YWx1ZVxufVxuXG4vKipcbiAqIEBwYXJhbSB7bnVtYmVyfSB0eXBlXG4gKiBAcmV0dXJuIHtzdHJpbmd9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZWxpbWl0ICh0eXBlKSB7XG5cdHJldHVybiB0cmltKHNsaWNlKHBvc2l0aW9uIC0gMSwgZGVsaW1pdGVyKHR5cGUgPT09IDkxID8gdHlwZSArIDIgOiB0eXBlID09PSA0MCA/IHR5cGUgKyAxIDogdHlwZSkpKVxufVxuXG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nfSB2YWx1ZVxuICogQHJldHVybiB7c3RyaW5nW119XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0b2tlbml6ZSAodmFsdWUpIHtcblx0cmV0dXJuIGRlYWxsb2ModG9rZW5pemVyKGFsbG9jKHZhbHVlKSkpXG59XG5cbi8qKlxuICogQHBhcmFtIHtudW1iZXJ9IHR5cGVcbiAqIEByZXR1cm4ge3N0cmluZ31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHdoaXRlc3BhY2UgKHR5cGUpIHtcblx0d2hpbGUgKGNoYXJhY3RlciA9IHBlZWsoKSlcblx0XHRpZiAoY2hhcmFjdGVyIDwgMzMpXG5cdFx0XHRuZXh0KClcblx0XHRlbHNlXG5cdFx0XHRicmVha1xuXG5cdHJldHVybiB0b2tlbih0eXBlKSA+IDIgfHwgdG9rZW4oY2hhcmFjdGVyKSA+IDMgPyAnJyA6ICcgJ1xufVxuXG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nW119IGNoaWxkcmVuXG4gKiBAcmV0dXJuIHtzdHJpbmdbXX1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRva2VuaXplciAoY2hpbGRyZW4pIHtcblx0d2hpbGUgKG5leHQoKSlcblx0XHRzd2l0Y2ggKHRva2VuKGNoYXJhY3RlcikpIHtcblx0XHRcdGNhc2UgMDogYXBwZW5kKGlkZW50aWZpZXIocG9zaXRpb24gLSAxKSwgY2hpbGRyZW4pXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlIDI6IGFwcGVuZChkZWxpbWl0KGNoYXJhY3RlciksIGNoaWxkcmVuKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0ZGVmYXVsdDogYXBwZW5kKGZyb20oY2hhcmFjdGVyKSwgY2hpbGRyZW4pXG5cdFx0fVxuXG5cdHJldHVybiBjaGlsZHJlblxufVxuXG4vKipcbiAqIEBwYXJhbSB7bnVtYmVyfSBpbmRleFxuICogQHBhcmFtIHtudW1iZXJ9IGNvdW50XG4gKiBAcmV0dXJuIHtzdHJpbmd9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBlc2NhcGluZyAoaW5kZXgsIGNvdW50KSB7XG5cdHdoaWxlICgtLWNvdW50ICYmIG5leHQoKSlcblx0XHQvLyBub3QgMC05IEEtRiBhLWZcblx0XHRpZiAoY2hhcmFjdGVyIDwgNDggfHwgY2hhcmFjdGVyID4gMTAyIHx8IChjaGFyYWN0ZXIgPiA1NyAmJiBjaGFyYWN0ZXIgPCA2NSkgfHwgKGNoYXJhY3RlciA+IDcwICYmIGNoYXJhY3RlciA8IDk3KSlcblx0XHRcdGJyZWFrXG5cblx0cmV0dXJuIHNsaWNlKGluZGV4LCBjYXJldCgpICsgKGNvdW50IDwgNiAmJiBwZWVrKCkgPT0gMzIgJiYgbmV4dCgpID09IDMyKSlcbn1cblxuLyoqXG4gKiBAcGFyYW0ge251bWJlcn0gdHlwZVxuICogQHJldHVybiB7bnVtYmVyfVxuICovXG5leHBvcnQgZnVuY3Rpb24gZGVsaW1pdGVyICh0eXBlKSB7XG5cdHdoaWxlIChuZXh0KCkpXG5cdFx0c3dpdGNoIChjaGFyYWN0ZXIpIHtcblx0XHRcdC8vIF0gKSBcIiAnXG5cdFx0XHRjYXNlIHR5cGU6XG5cdFx0XHRcdHJldHVybiBwb3NpdGlvblxuXHRcdFx0Ly8gXCIgJ1xuXHRcdFx0Y2FzZSAzNDogY2FzZSAzOTpcblx0XHRcdFx0aWYgKHR5cGUgIT09IDM0ICYmIHR5cGUgIT09IDM5KVxuXHRcdFx0XHRcdGRlbGltaXRlcihjaGFyYWN0ZXIpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHQvLyAoXG5cdFx0XHRjYXNlIDQwOlxuXHRcdFx0XHRpZiAodHlwZSA9PT0gNDEpXG5cdFx0XHRcdFx0ZGVsaW1pdGVyKHR5cGUpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHQvLyBcXFxuXHRcdFx0Y2FzZSA5Mjpcblx0XHRcdFx0bmV4dCgpXG5cdFx0XHRcdGJyZWFrXG5cdFx0fVxuXG5cdHJldHVybiBwb3NpdGlvblxufVxuXG4vKipcbiAqIEBwYXJhbSB7bnVtYmVyfSB0eXBlXG4gKiBAcGFyYW0ge251bWJlcn0gaW5kZXhcbiAqIEByZXR1cm4ge251bWJlcn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNvbW1lbnRlciAodHlwZSwgaW5kZXgpIHtcblx0d2hpbGUgKG5leHQoKSlcblx0XHQvLyAvL1xuXHRcdGlmICh0eXBlICsgY2hhcmFjdGVyID09PSA0NyArIDEwKVxuXHRcdFx0YnJlYWtcblx0XHQvLyAvKlxuXHRcdGVsc2UgaWYgKHR5cGUgKyBjaGFyYWN0ZXIgPT09IDQyICsgNDIgJiYgcGVlaygpID09PSA0Nylcblx0XHRcdGJyZWFrXG5cblx0cmV0dXJuICcvKicgKyBzbGljZShpbmRleCwgcG9zaXRpb24gLSAxKSArICcqJyArIGZyb20odHlwZSA9PT0gNDcgPyB0eXBlIDogbmV4dCgpKVxufVxuXG4vKipcbiAqIEBwYXJhbSB7bnVtYmVyfSBpbmRleFxuICogQHJldHVybiB7c3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gaWRlbnRpZmllciAoaW5kZXgpIHtcblx0d2hpbGUgKCF0b2tlbihwZWVrKCkpKVxuXHRcdG5leHQoKVxuXG5cdHJldHVybiBzbGljZShpbmRleCwgcG9zaXRpb24pXG59XG4iLCJpbXBvcnQge0NPTU1FTlQsIFJVTEVTRVQsIERFQ0xBUkFUSU9OfSBmcm9tICcuL0VudW0uanMnXG5pbXBvcnQge2FicywgY2hhcmF0LCB0cmltLCBmcm9tLCBzaXplb2YsIHN0cmxlbiwgc3Vic3RyLCBhcHBlbmQsIHJlcGxhY2UsIGluZGV4b2Z9IGZyb20gJy4vVXRpbGl0eS5qcydcbmltcG9ydCB7bm9kZSwgY2hhciwgcHJldiwgbmV4dCwgcGVlaywgdG9rZW4sIGNhcmV0LCBhbGxvYywgZGVhbGxvYywgZGVsaW1pdCwgd2hpdGVzcGFjZSwgZXNjYXBpbmcsIGlkZW50aWZpZXIsIGNvbW1lbnRlcn0gZnJvbSAnLi9Ub2tlbml6ZXIuanMnXG5cbi8qKlxuICogQHBhcmFtIHtzdHJpbmd9IHZhbHVlXG4gKiBAcmV0dXJuIHtvYmplY3RbXX1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNvbXBpbGUgKHZhbHVlKSB7XG5cdHJldHVybiBkZWFsbG9jKHBhcnNlKCcnLCBudWxsLCBudWxsLCBudWxsLCBbJyddLCB2YWx1ZSA9IGFsbG9jKHZhbHVlKSwgMCwgWzBdLCB2YWx1ZSkpXG59XG5cbi8qKlxuICogQHBhcmFtIHtzdHJpbmd9IHZhbHVlXG4gKiBAcGFyYW0ge29iamVjdH0gcm9vdFxuICogQHBhcmFtIHtvYmplY3Q/fSBwYXJlbnRcbiAqIEBwYXJhbSB7c3RyaW5nW119IHJ1bGVcbiAqIEBwYXJhbSB7c3RyaW5nW119IHJ1bGVzXG4gKiBAcGFyYW0ge3N0cmluZ1tdfSBydWxlc2V0c1xuICogQHBhcmFtIHtudW1iZXJbXX0gcHNldWRvXG4gKiBAcGFyYW0ge251bWJlcltdfSBwb2ludHNcbiAqIEBwYXJhbSB7c3RyaW5nW119IGRlY2xhcmF0aW9uc1xuICogQHJldHVybiB7b2JqZWN0fVxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2UgKHZhbHVlLCByb290LCBwYXJlbnQsIHJ1bGUsIHJ1bGVzLCBydWxlc2V0cywgcHNldWRvLCBwb2ludHMsIGRlY2xhcmF0aW9ucykge1xuXHR2YXIgaW5kZXggPSAwXG5cdHZhciBvZmZzZXQgPSAwXG5cdHZhciBsZW5ndGggPSBwc2V1ZG9cblx0dmFyIGF0cnVsZSA9IDBcblx0dmFyIHByb3BlcnR5ID0gMFxuXHR2YXIgcHJldmlvdXMgPSAwXG5cdHZhciB2YXJpYWJsZSA9IDFcblx0dmFyIHNjYW5uaW5nID0gMVxuXHR2YXIgYW1wZXJzYW5kID0gMVxuXHR2YXIgY2hhcmFjdGVyID0gMFxuXHR2YXIgdHlwZSA9ICcnXG5cdHZhciBwcm9wcyA9IHJ1bGVzXG5cdHZhciBjaGlsZHJlbiA9IHJ1bGVzZXRzXG5cdHZhciByZWZlcmVuY2UgPSBydWxlXG5cdHZhciBjaGFyYWN0ZXJzID0gdHlwZVxuXG5cdHdoaWxlIChzY2FubmluZylcblx0XHRzd2l0Y2ggKHByZXZpb3VzID0gY2hhcmFjdGVyLCBjaGFyYWN0ZXIgPSBuZXh0KCkpIHtcblx0XHRcdC8vIChcblx0XHRcdGNhc2UgNDA6XG5cdFx0XHRcdGlmIChwcmV2aW91cyAhPSAxMDggJiYgY2hhcmF0KGNoYXJhY3RlcnMsIGxlbmd0aCAtIDEpID09IDU4KSB7XG5cdFx0XHRcdFx0aWYgKGluZGV4b2YoY2hhcmFjdGVycyArPSByZXBsYWNlKGRlbGltaXQoY2hhcmFjdGVyKSwgJyYnLCAnJlxcZicpLCAnJlxcZicsIGFicyhpbmRleCA/IHBvaW50c1tpbmRleCAtIDFdIDogMCkpICE9IC0xKVxuXHRcdFx0XHRcdFx0YW1wZXJzYW5kID0gLTFcblx0XHRcdFx0XHRicmVha1xuXHRcdFx0XHR9XG5cdFx0XHQvLyBcIiAnIFtcblx0XHRcdGNhc2UgMzQ6IGNhc2UgMzk6IGNhc2UgOTE6XG5cdFx0XHRcdGNoYXJhY3RlcnMgKz0gZGVsaW1pdChjaGFyYWN0ZXIpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHQvLyBcXHQgXFxuIFxcciBcXHNcblx0XHRcdGNhc2UgOTogY2FzZSAxMDogY2FzZSAxMzogY2FzZSAzMjpcblx0XHRcdFx0Y2hhcmFjdGVycyArPSB3aGl0ZXNwYWNlKHByZXZpb3VzKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0Ly8gXFxcblx0XHRcdGNhc2UgOTI6XG5cdFx0XHRcdGNoYXJhY3RlcnMgKz0gZXNjYXBpbmcoY2FyZXQoKSAtIDEsIDcpXG5cdFx0XHRcdGNvbnRpbnVlXG5cdFx0XHQvLyAvXG5cdFx0XHRjYXNlIDQ3OlxuXHRcdFx0XHRzd2l0Y2ggKHBlZWsoKSkge1xuXHRcdFx0XHRcdGNhc2UgNDI6IGNhc2UgNDc6XG5cdFx0XHRcdFx0XHRhcHBlbmQoY29tbWVudChjb21tZW50ZXIobmV4dCgpLCBjYXJldCgpKSwgcm9vdCwgcGFyZW50LCBkZWNsYXJhdGlvbnMpLCBkZWNsYXJhdGlvbnMpXG5cdFx0XHRcdFx0XHRpZiAoKHRva2VuKHByZXZpb3VzIHx8IDEpID09IDUgfHwgdG9rZW4ocGVlaygpIHx8IDEpID09IDUpICYmIHN0cmxlbihjaGFyYWN0ZXJzKSAmJiBzdWJzdHIoY2hhcmFjdGVycywgLTEsIHZvaWQgMCkgIT09ICcgJykgY2hhcmFjdGVycyArPSAnICdcblx0XHRcdFx0XHRcdGJyZWFrXG5cdFx0XHRcdFx0ZGVmYXVsdDpcblx0XHRcdFx0XHRcdGNoYXJhY3RlcnMgKz0gJy8nXG5cdFx0XHRcdH1cblx0XHRcdFx0YnJlYWtcblx0XHRcdC8vIHtcblx0XHRcdGNhc2UgMTIzICogdmFyaWFibGU6XG5cdFx0XHRcdHBvaW50c1tpbmRleCsrXSA9IHN0cmxlbihjaGFyYWN0ZXJzKSAqIGFtcGVyc2FuZFxuXHRcdFx0Ly8gfSA7IFxcMFxuXHRcdFx0Y2FzZSAxMjUgKiB2YXJpYWJsZTogY2FzZSA1OTogY2FzZSAwOlxuXHRcdFx0XHRzd2l0Y2ggKGNoYXJhY3Rlcikge1xuXHRcdFx0XHRcdC8vIFxcMCB9XG5cdFx0XHRcdFx0Y2FzZSAwOiBjYXNlIDEyNTogc2Nhbm5pbmcgPSAwXG5cdFx0XHRcdFx0Ly8gO1xuXHRcdFx0XHRcdGNhc2UgNTkgKyBvZmZzZXQ6IGlmIChhbXBlcnNhbmQgPT0gLTEpIGNoYXJhY3RlcnMgPSByZXBsYWNlKGNoYXJhY3RlcnMsIC9cXGYvZywgJycpXG5cdFx0XHRcdFx0XHRpZiAocHJvcGVydHkgPiAwICYmIChzdHJsZW4oY2hhcmFjdGVycykgLSBsZW5ndGggfHwgKHZhcmlhYmxlID09PSAwICYmIHByZXZpb3VzID09PSA0NykpKVxuXHRcdFx0XHRcdFx0XHRhcHBlbmQocHJvcGVydHkgPiAzMiA/IGRlY2xhcmF0aW9uKGNoYXJhY3RlcnMgKyAnOycsIHJ1bGUsIHBhcmVudCwgbGVuZ3RoIC0gMSwgZGVjbGFyYXRpb25zKSA6IGRlY2xhcmF0aW9uKHJlcGxhY2UoY2hhcmFjdGVycywgJyAnLCAnJykgKyAnOycsIHJ1bGUsIHBhcmVudCwgbGVuZ3RoIC0gMiwgZGVjbGFyYXRpb25zKSwgZGVjbGFyYXRpb25zKVxuXHRcdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0XHQvLyBAIDtcblx0XHRcdFx0XHRjYXNlIDU5OiBjaGFyYWN0ZXJzICs9ICc7J1xuXHRcdFx0XHRcdC8vIHsgcnVsZS9hdC1ydWxlXG5cdFx0XHRcdFx0ZGVmYXVsdDpcblx0XHRcdFx0XHRcdGFwcGVuZChyZWZlcmVuY2UgPSBydWxlc2V0KGNoYXJhY3RlcnMsIHJvb3QsIHBhcmVudCwgaW5kZXgsIG9mZnNldCwgcnVsZXMsIHBvaW50cywgdHlwZSwgcHJvcHMgPSBbXSwgY2hpbGRyZW4gPSBbXSwgbGVuZ3RoLCBydWxlc2V0cyksIHJ1bGVzZXRzKVxuXG5cdFx0XHRcdFx0XHRpZiAoY2hhcmFjdGVyID09PSAxMjMpXG5cdFx0XHRcdFx0XHRcdGlmIChvZmZzZXQgPT09IDApXG5cdFx0XHRcdFx0XHRcdFx0cGFyc2UoY2hhcmFjdGVycywgcm9vdCwgcmVmZXJlbmNlLCByZWZlcmVuY2UsIHByb3BzLCBydWxlc2V0cywgbGVuZ3RoLCBwb2ludHMsIGNoaWxkcmVuKVxuXHRcdFx0XHRcdFx0XHRlbHNlIHtcblx0XHRcdFx0XHRcdFx0XHRzd2l0Y2ggKGF0cnVsZSkge1xuXHRcdFx0XHRcdFx0XHRcdFx0Ly8gYyhvbnRhaW5lcilcblx0XHRcdFx0XHRcdFx0XHRcdGNhc2UgOTk6XG5cdFx0XHRcdFx0XHRcdFx0XHRcdGlmIChjaGFyYXQoY2hhcmFjdGVycywgMykgPT09IDExMCkgYnJlYWtcblx0XHRcdFx0XHRcdFx0XHRcdC8vIGwoYXllcilcblx0XHRcdFx0XHRcdFx0XHRcdGNhc2UgMTA4OlxuXHRcdFx0XHRcdFx0XHRcdFx0XHRpZiAoY2hhcmF0KGNoYXJhY3RlcnMsIDIpID09PSA5NykgYnJlYWtcblx0XHRcdFx0XHRcdFx0XHRcdGRlZmF1bHQ6XG5cdFx0XHRcdFx0XHRcdFx0XHRcdG9mZnNldCA9IDBcblx0XHRcdFx0XHRcdFx0XHRcdC8vIGQob2N1bWVudCkgbShlZGlhKSBzKHVwcG9ydHMpXG5cdFx0XHRcdFx0XHRcdFx0XHRjYXNlIDEwMDogY2FzZSAxMDk6IGNhc2UgMTE1OlxuXHRcdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdFx0XHRpZiAob2Zmc2V0KSBwYXJzZSh2YWx1ZSwgcmVmZXJlbmNlLCByZWZlcmVuY2UsIHJ1bGUgJiYgYXBwZW5kKHJ1bGVzZXQodmFsdWUsIHJlZmVyZW5jZSwgcmVmZXJlbmNlLCAwLCAwLCBydWxlcywgcG9pbnRzLCB0eXBlLCBydWxlcywgcHJvcHMgPSBbXSwgbGVuZ3RoLCBjaGlsZHJlbiksIGNoaWxkcmVuKSwgcnVsZXMsIGNoaWxkcmVuLCBsZW5ndGgsIHBvaW50cywgcnVsZSA/IHByb3BzIDogY2hpbGRyZW4pXG5cdFx0XHRcdFx0XHRcdFx0ZWxzZSBwYXJzZShjaGFyYWN0ZXJzLCByZWZlcmVuY2UsIHJlZmVyZW5jZSwgcmVmZXJlbmNlLCBbJyddLCBjaGlsZHJlbiwgMCwgcG9pbnRzLCBjaGlsZHJlbilcblx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cblx0XHRcdFx0aW5kZXggPSBvZmZzZXQgPSBwcm9wZXJ0eSA9IDAsIHZhcmlhYmxlID0gYW1wZXJzYW5kID0gMSwgdHlwZSA9IGNoYXJhY3RlcnMgPSAnJywgbGVuZ3RoID0gcHNldWRvXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHQvLyA6XG5cdFx0XHRjYXNlIDU4OlxuXHRcdFx0XHRsZW5ndGggPSAxICsgc3RybGVuKGNoYXJhY3RlcnMpLCBwcm9wZXJ0eSA9IHByZXZpb3VzXG5cdFx0XHRkZWZhdWx0OlxuXHRcdFx0XHRpZiAodmFyaWFibGUgPCAxKVxuXHRcdFx0XHRcdGlmIChjaGFyYWN0ZXIgPT0gMTIzKVxuXHRcdFx0XHRcdFx0LS12YXJpYWJsZVxuXHRcdFx0XHRcdGVsc2UgaWYgKGNoYXJhY3RlciA9PSAxMjUgJiYgdmFyaWFibGUrKyA9PSAwICYmIHByZXYoKSA9PSAxMjUpXG5cdFx0XHRcdFx0XHRjb250aW51ZVxuXG5cdFx0XHRcdHN3aXRjaCAoY2hhcmFjdGVycyArPSBmcm9tKGNoYXJhY3RlciksIGNoYXJhY3RlciAqIHZhcmlhYmxlKSB7XG5cdFx0XHRcdFx0Ly8gJlxuXHRcdFx0XHRcdGNhc2UgMzg6XG5cdFx0XHRcdFx0XHRhbXBlcnNhbmQgPSBvZmZzZXQgPiAwID8gMSA6IChjaGFyYWN0ZXJzICs9ICdcXGYnLCAtMSlcblx0XHRcdFx0XHRcdGJyZWFrXG5cdFx0XHRcdFx0Ly8gLFxuXHRcdFx0XHRcdGNhc2UgNDQ6XG5cdFx0XHRcdFx0XHRwb2ludHNbaW5kZXgrK10gPSAoc3RybGVuKGNoYXJhY3RlcnMpIC0gMSkgKiBhbXBlcnNhbmQsIGFtcGVyc2FuZCA9IDFcblx0XHRcdFx0XHRcdGJyZWFrXG5cdFx0XHRcdFx0Ly8gQFxuXHRcdFx0XHRcdGNhc2UgNjQ6XG5cdFx0XHRcdFx0XHQvLyAtXG5cdFx0XHRcdFx0XHRpZiAocGVlaygpID09PSA0NSlcblx0XHRcdFx0XHRcdFx0Y2hhcmFjdGVycyArPSBkZWxpbWl0KG5leHQoKSlcblxuXHRcdFx0XHRcdFx0YXRydWxlID0gcGVlaygpLCBvZmZzZXQgPSBsZW5ndGggPSBzdHJsZW4odHlwZSA9IGNoYXJhY3RlcnMgKz0gaWRlbnRpZmllcihjYXJldCgpKSksIGNoYXJhY3RlcisrXG5cdFx0XHRcdFx0XHRicmVha1xuXHRcdFx0XHRcdC8vIC1cblx0XHRcdFx0XHRjYXNlIDQ1OlxuXHRcdFx0XHRcdFx0aWYgKHByZXZpb3VzID09PSA0NSAmJiBzdHJsZW4oY2hhcmFjdGVycykgPT0gMilcblx0XHRcdFx0XHRcdFx0dmFyaWFibGUgPSAwXG5cdFx0XHRcdH1cblx0XHR9XG5cblx0cmV0dXJuIHJ1bGVzZXRzXG59XG5cbi8qKlxuICogQHBhcmFtIHtzdHJpbmd9IHZhbHVlXG4gKiBAcGFyYW0ge29iamVjdH0gcm9vdFxuICogQHBhcmFtIHtvYmplY3Q/fSBwYXJlbnRcbiAqIEBwYXJhbSB7bnVtYmVyfSBpbmRleFxuICogQHBhcmFtIHtudW1iZXJ9IG9mZnNldFxuICogQHBhcmFtIHtzdHJpbmdbXX0gcnVsZXNcbiAqIEBwYXJhbSB7bnVtYmVyW119IHBvaW50c1xuICogQHBhcmFtIHtzdHJpbmd9IHR5cGVcbiAqIEBwYXJhbSB7c3RyaW5nW119IHByb3BzXG4gKiBAcGFyYW0ge3N0cmluZ1tdfSBjaGlsZHJlblxuICogQHBhcmFtIHtudW1iZXJ9IGxlbmd0aFxuICogQHBhcmFtIHtvYmplY3RbXX0gc2libGluZ3NcbiAqIEByZXR1cm4ge29iamVjdH1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJ1bGVzZXQgKHZhbHVlLCByb290LCBwYXJlbnQsIGluZGV4LCBvZmZzZXQsIHJ1bGVzLCBwb2ludHMsIHR5cGUsIHByb3BzLCBjaGlsZHJlbiwgbGVuZ3RoLCBzaWJsaW5ncykge1xuXHR2YXIgcG9zdCA9IG9mZnNldCAtIDFcblx0dmFyIHJ1bGUgPSBvZmZzZXQgPT09IDAgPyBydWxlcyA6IFsnJ11cblx0dmFyIHNpemUgPSBzaXplb2YocnVsZSlcblxuXHRmb3IgKHZhciBpID0gMCwgaiA9IDAsIGsgPSAwOyBpIDwgaW5kZXg7ICsraSlcblx0XHRmb3IgKHZhciB4ID0gMCwgeSA9IHN1YnN0cih2YWx1ZSwgcG9zdCArIDEsIHBvc3QgPSBhYnMoaiA9IHBvaW50c1tpXSkpLCB6ID0gdmFsdWU7IHggPCBzaXplOyArK3gpXG5cdFx0XHRpZiAoeiA9IHRyaW0oaiA+IDAgPyBydWxlW3hdICsgJyAnICsgeSA6IHJlcGxhY2UoeSwgLyZcXGYvZywgcnVsZVt4XSkpKVxuXHRcdFx0XHRwcm9wc1trKytdID0gelxuXG5cdHJldHVybiBub2RlKHZhbHVlLCByb290LCBwYXJlbnQsIG9mZnNldCA9PT0gMCA/IFJVTEVTRVQgOiB0eXBlLCBwcm9wcywgY2hpbGRyZW4sIGxlbmd0aCwgc2libGluZ3MpXG59XG5cbi8qKlxuICogQHBhcmFtIHtudW1iZXJ9IHZhbHVlXG4gKiBAcGFyYW0ge29iamVjdH0gcm9vdFxuICogQHBhcmFtIHtvYmplY3Q/fSBwYXJlbnRcbiAqIEBwYXJhbSB7b2JqZWN0W119IHNpYmxpbmdzXG4gKiBAcmV0dXJuIHtvYmplY3R9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb21tZW50ICh2YWx1ZSwgcm9vdCwgcGFyZW50LCBzaWJsaW5ncykge1xuXHRyZXR1cm4gbm9kZSh2YWx1ZSwgcm9vdCwgcGFyZW50LCBDT01NRU5ULCBmcm9tKGNoYXIoKSksIHN1YnN0cih2YWx1ZSwgMiwgLTIpLCAwLCBzaWJsaW5ncylcbn1cblxuLyoqXG4gKiBAcGFyYW0ge3N0cmluZ30gdmFsdWVcbiAqIEBwYXJhbSB7b2JqZWN0fSByb290XG4gKiBAcGFyYW0ge29iamVjdD99IHBhcmVudFxuICogQHBhcmFtIHtudW1iZXJ9IGxlbmd0aFxuICogQHBhcmFtIHtvYmplY3RbXX0gc2libGluZ3NcbiAqIEByZXR1cm4ge29iamVjdH1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRlY2xhcmF0aW9uICh2YWx1ZSwgcm9vdCwgcGFyZW50LCBsZW5ndGgsIHNpYmxpbmdzKSB7XG5cdHJldHVybiBub2RlKHZhbHVlLCByb290LCBwYXJlbnQsIERFQ0xBUkFUSU9OLCBzdWJzdHIodmFsdWUsIDAsIGxlbmd0aCksIHN1YnN0cih2YWx1ZSwgbGVuZ3RoICsgMSwgLTEpLCBsZW5ndGgsIHNpYmxpbmdzKVxufVxuIiwiaW1wb3J0IHtNUywgTU9aLCBXRUJLSVR9IGZyb20gJy4vRW51bS5qcydcbmltcG9ydCB7aGFzaCwgY2hhcmF0LCBzdHJsZW4sIGluZGV4b2YsIHJlcGxhY2UsIHN1YnN0ciwgbWF0Y2h9IGZyb20gJy4vVXRpbGl0eS5qcydcblxuLyoqXG4gKiBAcGFyYW0ge3N0cmluZ30gdmFsdWVcbiAqIEBwYXJhbSB7bnVtYmVyfSBsZW5ndGhcbiAqIEBwYXJhbSB7b2JqZWN0W119IGNoaWxkcmVuXG4gKiBAcmV0dXJuIHtzdHJpbmd9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwcmVmaXggKHZhbHVlLCBsZW5ndGgsIGNoaWxkcmVuKSB7XG5cdHN3aXRjaCAoaGFzaCh2YWx1ZSwgbGVuZ3RoKSkge1xuXHRcdC8vIGNvbG9yLWFkanVzdFxuXHRcdGNhc2UgNTEwMzpcblx0XHRcdHJldHVybiBXRUJLSVQgKyAncHJpbnQtJyArIHZhbHVlICsgdmFsdWVcblx0XHQvLyBhbmltYXRpb24sIGFuaW1hdGlvbi0oZGVsYXl8ZGlyZWN0aW9ufGR1cmF0aW9ufGZpbGwtbW9kZXxpdGVyYXRpb24tY291bnR8bmFtZXxwbGF5LXN0YXRlfHRpbWluZy1mdW5jdGlvbilcblx0XHRjYXNlIDU3Mzc6IGNhc2UgNDIwMTogY2FzZSAzMTc3OiBjYXNlIDM0MzM6IGNhc2UgMTY0MTogY2FzZSA0NDU3OiBjYXNlIDI5MjE6XG5cdFx0Ly8gdGV4dC1kZWNvcmF0aW9uLCBmaWx0ZXIsIGNsaXAtcGF0aCwgYmFja2ZhY2UtdmlzaWJpbGl0eSwgY29sdW1uLCBib3gtZGVjb3JhdGlvbi1icmVha1xuXHRcdGNhc2UgNTU3MjogY2FzZSA2MzU2OiBjYXNlIDU4NDQ6IGNhc2UgMzE5MTogY2FzZSA2NjQ1OiBjYXNlIDMwMDU6XG5cdFx0Ly8gYmFja2dyb3VuZC1jbGlwLCBjb2x1bW5zLCBjb2x1bW4tKGNvdW50fGZpbGx8Z2FwfHJ1bGV8cnVsZS1jb2xvcnxydWxlLXN0eWxlfHJ1bGUtd2lkdGh8c3Bhbnx3aWR0aClcblx0XHRjYXNlIDQyMTU6IGNhc2UgNjM4OTogY2FzZSA1MTA5OiBjYXNlIDUzNjU6IGNhc2UgNTYyMTogY2FzZSAzODI5OlxuXHRcdC8vIG1hc2ssIG1hc2staW1hZ2UsIG1hc2stKG1vZGV8Y2xpcHxzaXplKSwgbWFzay0ocmVwZWF0fG9yaWdpbiksIG1hc2stcG9zaXRpb25cblx0XHRjYXNlIDYzOTE6IGNhc2UgNTg3OTogY2FzZSA1NjIzOiBjYXNlIDYxMzU6IGNhc2UgNDU5OTpcblx0XHRcdHJldHVybiBXRUJLSVQgKyB2YWx1ZSArIHZhbHVlXG5cdFx0Ly8gbWFzay1jb21wb3NpdGVcblx0XHRjYXNlIDQ4NTU6XG5cdFx0XHRyZXR1cm4gV0VCS0lUICsgdmFsdWUucmVwbGFjZSgnYWRkJywgJ3NvdXJjZS1vdmVyJykucmVwbGFjZSgnc3Vic3RyYWN0JywgJ3NvdXJjZS1vdXQnKS5yZXBsYWNlKCdpbnRlcnNlY3QnLCAnc291cmNlLWluJykucmVwbGFjZSgnZXhjbHVkZScsICd4b3InKSArIHZhbHVlXG5cdFx0Ly8gdGFiLXNpemVcblx0XHRjYXNlIDQ3ODk6XG5cdFx0XHRyZXR1cm4gTU9aICsgdmFsdWUgKyB2YWx1ZVxuXHRcdC8vIGFwcGVhcmFuY2UsIHVzZXItc2VsZWN0LCB0cmFuc2Zvcm0sIGh5cGhlbnMsIHRleHQtc2l6ZS1hZGp1c3Rcblx0XHRjYXNlIDUzNDk6IGNhc2UgNDI0NjogY2FzZSA0ODEwOiBjYXNlIDY5Njg6IGNhc2UgMjc1Njpcblx0XHRcdHJldHVybiBXRUJLSVQgKyB2YWx1ZSArIE1PWiArIHZhbHVlICsgTVMgKyB2YWx1ZSArIHZhbHVlXG5cdFx0Ly8gd3JpdGluZy1tb2RlXG5cdFx0Y2FzZSA1OTM2OlxuXHRcdFx0c3dpdGNoIChjaGFyYXQodmFsdWUsIGxlbmd0aCArIDExKSkge1xuXHRcdFx0XHQvLyB2ZXJ0aWNhbC1sKHIpXG5cdFx0XHRcdGNhc2UgMTE0OlxuXHRcdFx0XHRcdHJldHVybiBXRUJLSVQgKyB2YWx1ZSArIE1TICsgcmVwbGFjZSh2YWx1ZSwgL1tzdmhdXFx3Ky1bdGJscl17Mn0vLCAndGInKSArIHZhbHVlXG5cdFx0XHRcdC8vIHZlcnRpY2FsLXIobClcblx0XHRcdFx0Y2FzZSAxMDg6XG5cdFx0XHRcdFx0cmV0dXJuIFdFQktJVCArIHZhbHVlICsgTVMgKyByZXBsYWNlKHZhbHVlLCAvW3N2aF1cXHcrLVt0YmxyXXsyfS8sICd0Yi1ybCcpICsgdmFsdWVcblx0XHRcdFx0Ly8gaG9yaXpvbnRhbCgtKXRiXG5cdFx0XHRcdGNhc2UgNDU6XG5cdFx0XHRcdFx0cmV0dXJuIFdFQktJVCArIHZhbHVlICsgTVMgKyByZXBsYWNlKHZhbHVlLCAvW3N2aF1cXHcrLVt0YmxyXXsyfS8sICdscicpICsgdmFsdWVcblx0XHRcdFx0Ly8gZGVmYXVsdDogZmFsbHRocm91Z2ggdG8gYmVsb3dcblx0XHRcdH1cblx0XHQvLyBmbGV4LCBmbGV4LWRpcmVjdGlvbiwgc2Nyb2xsLXNuYXAtdHlwZSwgd3JpdGluZy1tb2RlXG5cdFx0Y2FzZSA2ODI4OiBjYXNlIDQyNjg6IGNhc2UgMjkwMzpcblx0XHRcdHJldHVybiBXRUJLSVQgKyB2YWx1ZSArIE1TICsgdmFsdWUgKyB2YWx1ZVxuXHRcdC8vIG9yZGVyXG5cdFx0Y2FzZSA2MTY1OlxuXHRcdFx0cmV0dXJuIFdFQktJVCArIHZhbHVlICsgTVMgKyAnZmxleC0nICsgdmFsdWUgKyB2YWx1ZVxuXHRcdC8vIGFsaWduLWl0ZW1zXG5cdFx0Y2FzZSA1MTg3OlxuXHRcdFx0cmV0dXJuIFdFQktJVCArIHZhbHVlICsgcmVwbGFjZSh2YWx1ZSwgLyhcXHcrKS4rKDpbXl0rKS8sIFdFQktJVCArICdib3gtJDEkMicgKyBNUyArICdmbGV4LSQxJDInKSArIHZhbHVlXG5cdFx0Ly8gYWxpZ24tc2VsZlxuXHRcdGNhc2UgNTQ0Mzpcblx0XHRcdHJldHVybiBXRUJLSVQgKyB2YWx1ZSArIE1TICsgJ2ZsZXgtaXRlbS0nICsgcmVwbGFjZSh2YWx1ZSwgL2ZsZXgtfC1zZWxmL2csICcnKSArICghbWF0Y2godmFsdWUsIC9mbGV4LXxiYXNlbGluZS8pID8gTVMgKyAnZ3JpZC1yb3ctJyArIHJlcGxhY2UodmFsdWUsIC9mbGV4LXwtc2VsZi9nLCAnJykgOiAnJykgKyB2YWx1ZVxuXHRcdC8vIGFsaWduLWNvbnRlbnRcblx0XHRjYXNlIDQ2NzU6XG5cdFx0XHRyZXR1cm4gV0VCS0lUICsgdmFsdWUgKyBNUyArICdmbGV4LWxpbmUtcGFjaycgKyByZXBsYWNlKHZhbHVlLCAvYWxpZ24tY29udGVudHxmbGV4LXwtc2VsZi9nLCAnJykgKyB2YWx1ZVxuXHRcdC8vIGZsZXgtc2hyaW5rXG5cdFx0Y2FzZSA1NTQ4OlxuXHRcdFx0cmV0dXJuIFdFQktJVCArIHZhbHVlICsgTVMgKyByZXBsYWNlKHZhbHVlLCAnc2hyaW5rJywgJ25lZ2F0aXZlJykgKyB2YWx1ZVxuXHRcdC8vIGZsZXgtYmFzaXNcblx0XHRjYXNlIDUyOTI6XG5cdFx0XHRyZXR1cm4gV0VCS0lUICsgdmFsdWUgKyBNUyArIHJlcGxhY2UodmFsdWUsICdiYXNpcycsICdwcmVmZXJyZWQtc2l6ZScpICsgdmFsdWVcblx0XHQvLyBmbGV4LWdyb3dcblx0XHRjYXNlIDYwNjA6XG5cdFx0XHRyZXR1cm4gV0VCS0lUICsgJ2JveC0nICsgcmVwbGFjZSh2YWx1ZSwgJy1ncm93JywgJycpICsgV0VCS0lUICsgdmFsdWUgKyBNUyArIHJlcGxhY2UodmFsdWUsICdncm93JywgJ3Bvc2l0aXZlJykgKyB2YWx1ZVxuXHRcdC8vIHRyYW5zaXRpb25cblx0XHRjYXNlIDQ1NTQ6XG5cdFx0XHRyZXR1cm4gV0VCS0lUICsgcmVwbGFjZSh2YWx1ZSwgLyhbXi1dKSh0cmFuc2Zvcm0pL2csICckMScgKyBXRUJLSVQgKyAnJDInKSArIHZhbHVlXG5cdFx0Ly8gY3Vyc29yXG5cdFx0Y2FzZSA2MTg3OlxuXHRcdFx0cmV0dXJuIHJlcGxhY2UocmVwbGFjZShyZXBsYWNlKHZhbHVlLCAvKHpvb20tfGdyYWIpLywgV0VCS0lUICsgJyQxJyksIC8oaW1hZ2Utc2V0KS8sIFdFQktJVCArICckMScpLCB2YWx1ZSwgJycpICsgdmFsdWVcblx0XHQvLyBiYWNrZ3JvdW5kLCBiYWNrZ3JvdW5kLWltYWdlXG5cdFx0Y2FzZSA1NDk1OiBjYXNlIDM5NTk6XG5cdFx0XHRyZXR1cm4gcmVwbGFjZSh2YWx1ZSwgLyhpbWFnZS1zZXRcXChbXl0qKS8sIFdFQktJVCArICckMScgKyAnJGAkMScpXG5cdFx0Ly8ganVzdGlmeS1jb250ZW50XG5cdFx0Y2FzZSA0OTY4OlxuXHRcdFx0cmV0dXJuIHJlcGxhY2UocmVwbGFjZSh2YWx1ZSwgLyguKzopKGZsZXgtKT8oLiopLywgV0VCS0lUICsgJ2JveC1wYWNrOiQzJyArIE1TICsgJ2ZsZXgtcGFjazokMycpLCAvc3BhY2UtYmV0d2Vlbi8sICdqdXN0aWZ5JykgKyBXRUJLSVQgKyB2YWx1ZSArIHZhbHVlXG5cdFx0Ly8ganVzdGlmeS1zZWxmXG5cdFx0Y2FzZSA0MjAwOlxuXHRcdFx0aWYgKCFtYXRjaCh2YWx1ZSwgL2ZsZXgtfGJhc2VsaW5lLykpIHJldHVybiBNUyArICdncmlkLWNvbHVtbi1hbGlnbicgKyBzdWJzdHIodmFsdWUsIGxlbmd0aCkgKyB2YWx1ZVxuXHRcdFx0YnJlYWtcblx0XHQvLyBncmlkLXRlbXBsYXRlLShjb2x1bW5zfHJvd3MpXG5cdFx0Y2FzZSAyNTkyOiBjYXNlIDMzNjA6XG5cdFx0XHRyZXR1cm4gTVMgKyByZXBsYWNlKHZhbHVlLCAndGVtcGxhdGUtJywgJycpICsgdmFsdWVcblx0XHQvLyBncmlkLShyb3d8Y29sdW1uKS1zdGFydFxuXHRcdGNhc2UgNDM4NDogY2FzZSAzNjE2OlxuXHRcdFx0aWYgKGNoaWxkcmVuICYmIGNoaWxkcmVuLnNvbWUoZnVuY3Rpb24gKGVsZW1lbnQsIGluZGV4KSB7IHJldHVybiBsZW5ndGggPSBpbmRleCwgbWF0Y2goZWxlbWVudC5wcm9wcywgL2dyaWQtXFx3Ky1lbmQvKSB9KSkge1xuXHRcdFx0XHRyZXR1cm4gfmluZGV4b2YodmFsdWUgKyAoY2hpbGRyZW4gPSBjaGlsZHJlbltsZW5ndGhdLnZhbHVlKSwgJ3NwYW4nLCAwKSA/IHZhbHVlIDogKE1TICsgcmVwbGFjZSh2YWx1ZSwgJy1zdGFydCcsICcnKSArIHZhbHVlICsgTVMgKyAnZ3JpZC1yb3ctc3BhbjonICsgKH5pbmRleG9mKGNoaWxkcmVuLCAnc3BhbicsIDApID8gbWF0Y2goY2hpbGRyZW4sIC9cXGQrLykgOiArbWF0Y2goY2hpbGRyZW4sIC9cXGQrLykgLSArbWF0Y2godmFsdWUsIC9cXGQrLykpICsgJzsnKVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIE1TICsgcmVwbGFjZSh2YWx1ZSwgJy1zdGFydCcsICcnKSArIHZhbHVlXG5cdFx0Ly8gZ3JpZC0ocm93fGNvbHVtbiktZW5kXG5cdFx0Y2FzZSA0ODk2OiBjYXNlIDQxMjg6XG5cdFx0XHRyZXR1cm4gKGNoaWxkcmVuICYmIGNoaWxkcmVuLnNvbWUoZnVuY3Rpb24gKGVsZW1lbnQpIHsgcmV0dXJuIG1hdGNoKGVsZW1lbnQucHJvcHMsIC9ncmlkLVxcdystc3RhcnQvKSB9KSkgPyB2YWx1ZSA6IE1TICsgcmVwbGFjZShyZXBsYWNlKHZhbHVlLCAnLWVuZCcsICctc3BhbicpLCAnc3BhbiAnLCAnJykgKyB2YWx1ZVxuXHRcdC8vIChtYXJnaW58cGFkZGluZyktaW5saW5lLShzdGFydHxlbmQpXG5cdFx0Y2FzZSA0MDk1OiBjYXNlIDM1ODM6IGNhc2UgNDA2ODogY2FzZSAyNTMyOlxuXHRcdFx0cmV0dXJuIHJlcGxhY2UodmFsdWUsIC8oLispLWlubGluZSguKykvLCBXRUJLSVQgKyAnJDEkMicpICsgdmFsdWVcblx0XHQvLyAobWlufG1heCk/KHdpZHRofGhlaWdodHxpbmxpbmUtc2l6ZXxibG9jay1zaXplKVxuXHRcdGNhc2UgODExNjogY2FzZSA3MDU5OiBjYXNlIDU3NTM6IGNhc2UgNTUzNTpcblx0XHRjYXNlIDU0NDU6IGNhc2UgNTcwMTogY2FzZSA0OTMzOiBjYXNlIDQ2Nzc6XG5cdFx0Y2FzZSA1NTMzOiBjYXNlIDU3ODk6IGNhc2UgNTAyMTogY2FzZSA0NzY1OlxuXHRcdFx0Ly8gc3RyZXRjaCwgbWF4LWNvbnRlbnQsIG1pbi1jb250ZW50LCBmaWxsLWF2YWlsYWJsZVxuXHRcdFx0aWYgKHN0cmxlbih2YWx1ZSkgLSAxIC0gbGVuZ3RoID4gNilcblx0XHRcdFx0c3dpdGNoIChjaGFyYXQodmFsdWUsIGxlbmd0aCArIDEpKSB7XG5cdFx0XHRcdFx0Ly8gKG0pYXgtY29udGVudCwgKG0paW4tY29udGVudFxuXHRcdFx0XHRcdGNhc2UgMTA5OlxuXHRcdFx0XHRcdFx0Ly8gLVxuXHRcdFx0XHRcdFx0aWYgKGNoYXJhdCh2YWx1ZSwgbGVuZ3RoICsgNCkgIT09IDQ1KVxuXHRcdFx0XHRcdFx0XHRicmVha1xuXHRcdFx0XHRcdC8vIChmKWlsbC1hdmFpbGFibGUsIChmKWl0LWNvbnRlbnRcblx0XHRcdFx0XHRjYXNlIDEwMjpcblx0XHRcdFx0XHRcdHJldHVybiByZXBsYWNlKHZhbHVlLCAvKC4rOikoLispLShbXl0rKS8sICckMScgKyBXRUJLSVQgKyAnJDItJDMnICsgJyQxJyArIE1PWiArIChjaGFyYXQodmFsdWUsIGxlbmd0aCArIDMpID09IDEwOCA/ICckMycgOiAnJDItJDMnKSkgKyB2YWx1ZVxuXHRcdFx0XHRcdC8vIChzKXRyZXRjaFxuXHRcdFx0XHRcdGNhc2UgMTE1OlxuXHRcdFx0XHRcdFx0cmV0dXJuIH5pbmRleG9mKHZhbHVlLCAnc3RyZXRjaCcsIDApID8gcHJlZml4KHJlcGxhY2UodmFsdWUsICdzdHJldGNoJywgJ2ZpbGwtYXZhaWxhYmxlJyksIGxlbmd0aCwgY2hpbGRyZW4pICsgdmFsdWUgOiB2YWx1ZVxuXHRcdFx0XHR9XG5cdFx0XHRicmVha1xuXHRcdC8vIGdyaWQtKGNvbHVtbnxyb3cpXG5cdFx0Y2FzZSA1MTUyOiBjYXNlIDU5MjA6XG5cdFx0XHRyZXR1cm4gcmVwbGFjZSh2YWx1ZSwgLyguKz8pOihcXGQrKShcXHMqXFwvXFxzKihzcGFuKT9cXHMqKFxcZCspKT8oLiopLywgZnVuY3Rpb24gKF8sIGEsIGIsIGMsIGQsIGUsIGYpIHsgcmV0dXJuIChNUyArIGEgKyAnOicgKyBiICsgZikgKyAoYyA/IChNUyArIGEgKyAnLXNwYW46JyArIChkID8gZSA6ICtlIC0gK2IpKSArIGYgOiAnJykgKyB2YWx1ZSB9KVxuXHRcdC8vIHBvc2l0aW9uOiBzdGlja3lcblx0XHRjYXNlIDQ5NDk6XG5cdFx0XHQvLyBzdGljayh5KT9cblx0XHRcdGlmIChjaGFyYXQodmFsdWUsIGxlbmd0aCArIDYpID09PSAxMjEpXG5cdFx0XHRcdHJldHVybiByZXBsYWNlKHZhbHVlLCAnOicsICc6JyArIFdFQktJVCkgKyB2YWx1ZVxuXHRcdFx0YnJlYWtcblx0XHQvLyBkaXNwbGF5OiAoZmxleHxpbmxpbmUtZmxleHxncmlkfGlubGluZS1ncmlkKVxuXHRcdGNhc2UgNjQ0NDpcblx0XHRcdHN3aXRjaCAoY2hhcmF0KHZhbHVlLCBjaGFyYXQodmFsdWUsIDE0KSA9PT0gNDUgPyAxOCA6IDExKSkge1xuXHRcdFx0XHQvLyAoaW5saW5lLSk/ZmxlKHgpXG5cdFx0XHRcdGNhc2UgMTIwOlxuXHRcdFx0XHRcdHJldHVybiByZXBsYWNlKHZhbHVlLCAvKC4rOikoW147XFxzIV0rKSg7fChcXHMrKT8hLispPy8sICckMScgKyBXRUJLSVQgKyAoY2hhcmF0KHZhbHVlLCAxNCkgPT09IDQ1ID8gJ2lubGluZS0nIDogJycpICsgJ2JveCQzJyArICckMScgKyBXRUJLSVQgKyAnJDIkMycgKyAnJDEnICsgTVMgKyAnJDJib3gkMycpICsgdmFsdWVcblx0XHRcdFx0Ly8gKGlubGluZS0pP2dyaShkKVxuXHRcdFx0XHRjYXNlIDEwMDpcblx0XHRcdFx0XHRyZXR1cm4gcmVwbGFjZSh2YWx1ZSwgJzonLCAnOicgKyBNUykgKyB2YWx1ZVxuXHRcdFx0fVxuXHRcdFx0YnJlYWtcblx0XHQvLyBzY3JvbGwtbWFyZ2luLCBzY3JvbGwtbWFyZ2luLSh0b3B8cmlnaHR8Ym90dG9tfGxlZnQpXG5cdFx0Y2FzZSA1NzE5OiBjYXNlIDI2NDc6IGNhc2UgMjEzNTogY2FzZSAzOTI3OiBjYXNlIDIzOTE6XG5cdFx0XHRyZXR1cm4gcmVwbGFjZSh2YWx1ZSwgJ3Njcm9sbC0nLCAnc2Nyb2xsLXNuYXAtJykgKyB2YWx1ZVxuXHR9XG5cblx0cmV0dXJuIHZhbHVlXG59XG4iLCJpbXBvcnQge0lNUE9SVCwgTEFZRVIsIENPTU1FTlQsIFJVTEVTRVQsIERFQ0xBUkFUSU9OLCBLRVlGUkFNRVMsIE5BTUVTUEFDRX0gZnJvbSAnLi9FbnVtLmpzJ1xuaW1wb3J0IHtzdHJsZW59IGZyb20gJy4vVXRpbGl0eS5qcydcblxuLyoqXG4gKiBAcGFyYW0ge29iamVjdFtdfSBjaGlsZHJlblxuICogQHBhcmFtIHtmdW5jdGlvbn0gY2FsbGJhY2tcbiAqIEByZXR1cm4ge3N0cmluZ31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNlcmlhbGl6ZSAoY2hpbGRyZW4sIGNhbGxiYWNrKSB7XG5cdHZhciBvdXRwdXQgPSAnJ1xuXG5cdGZvciAodmFyIGkgPSAwOyBpIDwgY2hpbGRyZW4ubGVuZ3RoOyBpKyspXG5cdFx0b3V0cHV0ICs9IGNhbGxiYWNrKGNoaWxkcmVuW2ldLCBpLCBjaGlsZHJlbiwgY2FsbGJhY2spIHx8ICcnXG5cblx0cmV0dXJuIG91dHB1dFxufVxuXG4vKipcbiAqIEBwYXJhbSB7b2JqZWN0fSBlbGVtZW50XG4gKiBAcGFyYW0ge251bWJlcn0gaW5kZXhcbiAqIEBwYXJhbSB7b2JqZWN0W119IGNoaWxkcmVuXG4gKiBAcGFyYW0ge2Z1bmN0aW9ufSBjYWxsYmFja1xuICogQHJldHVybiB7c3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gc3RyaW5naWZ5IChlbGVtZW50LCBpbmRleCwgY2hpbGRyZW4sIGNhbGxiYWNrKSB7XG5cdHN3aXRjaCAoZWxlbWVudC50eXBlKSB7XG5cdFx0Y2FzZSBMQVlFUjogaWYgKGVsZW1lbnQuY2hpbGRyZW4ubGVuZ3RoKSBicmVha1xuXHRcdGNhc2UgSU1QT1JUOiBjYXNlIE5BTUVTUEFDRTogY2FzZSBERUNMQVJBVElPTjogcmV0dXJuIGVsZW1lbnQucmV0dXJuID0gZWxlbWVudC5yZXR1cm4gfHwgZWxlbWVudC52YWx1ZVxuXHRcdGNhc2UgQ09NTUVOVDogcmV0dXJuICcnXG5cdFx0Y2FzZSBLRVlGUkFNRVM6IHJldHVybiBlbGVtZW50LnJldHVybiA9IGVsZW1lbnQudmFsdWUgKyAneycgKyBzZXJpYWxpemUoZWxlbWVudC5jaGlsZHJlbiwgY2FsbGJhY2spICsgJ30nXG5cdFx0Y2FzZSBSVUxFU0VUOiBpZiAoIXN0cmxlbihlbGVtZW50LnZhbHVlID0gZWxlbWVudC5wcm9wcy5qb2luKCcsJykpKSByZXR1cm4gJydcblx0fVxuXG5cdHJldHVybiBzdHJsZW4oY2hpbGRyZW4gPSBzZXJpYWxpemUoZWxlbWVudC5jaGlsZHJlbiwgY2FsbGJhY2spKSA/IGVsZW1lbnQucmV0dXJuID0gZWxlbWVudC52YWx1ZSArICd7JyArIGNoaWxkcmVuICsgJ30nIDogJydcbn1cbiIsImltcG9ydCB7TVMsIE1PWiwgV0VCS0lULCBSVUxFU0VULCBLRVlGUkFNRVMsIERFQ0xBUkFUSU9OfSBmcm9tICcuL0VudW0uanMnXG5pbXBvcnQge21hdGNoLCBjaGFyYXQsIHN1YnN0ciwgc3RybGVuLCBzaXplb2YsIHJlcGxhY2UsIGNvbWJpbmUsIGZpbHRlciwgYXNzaWdufSBmcm9tICcuL1V0aWxpdHkuanMnXG5pbXBvcnQge2NvcHksIGxpZnQsIHRva2VuaXplfSBmcm9tICcuL1Rva2VuaXplci5qcydcbmltcG9ydCB7c2VyaWFsaXplfSBmcm9tICcuL1NlcmlhbGl6ZXIuanMnXG5pbXBvcnQge3ByZWZpeH0gZnJvbSAnLi9QcmVmaXhlci5qcydcblxuLyoqXG4gKiBAcGFyYW0ge2Z1bmN0aW9uW119IGNvbGxlY3Rpb25cbiAqIEByZXR1cm4ge2Z1bmN0aW9ufVxuICovXG5leHBvcnQgZnVuY3Rpb24gbWlkZGxld2FyZSAoY29sbGVjdGlvbikge1xuXHR2YXIgbGVuZ3RoID0gc2l6ZW9mKGNvbGxlY3Rpb24pXG5cblx0cmV0dXJuIGZ1bmN0aW9uIChlbGVtZW50LCBpbmRleCwgY2hpbGRyZW4sIGNhbGxiYWNrKSB7XG5cdFx0dmFyIG91dHB1dCA9ICcnXG5cblx0XHRmb3IgKHZhciBpID0gMDsgaSA8IGxlbmd0aDsgaSsrKVxuXHRcdFx0b3V0cHV0ICs9IGNvbGxlY3Rpb25baV0oZWxlbWVudCwgaW5kZXgsIGNoaWxkcmVuLCBjYWxsYmFjaykgfHwgJydcblxuXHRcdHJldHVybiBvdXRwdXRcblx0fVxufVxuXG4vKipcbiAqIEBwYXJhbSB7ZnVuY3Rpb259IGNhbGxiYWNrXG4gKiBAcmV0dXJuIHtmdW5jdGlvbn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJ1bGVzaGVldCAoY2FsbGJhY2spIHtcblx0cmV0dXJuIGZ1bmN0aW9uIChlbGVtZW50KSB7XG5cdFx0aWYgKCFlbGVtZW50LnJvb3QpXG5cdFx0XHRpZiAoZWxlbWVudCA9IGVsZW1lbnQucmV0dXJuKVxuXHRcdFx0XHRjYWxsYmFjayhlbGVtZW50KVxuXHR9XG59XG5cbi8qKlxuICogQHBhcmFtIHtvYmplY3R9IGVsZW1lbnRcbiAqIEBwYXJhbSB7bnVtYmVyfSBpbmRleFxuICogQHBhcmFtIHtvYmplY3RbXX0gY2hpbGRyZW5cbiAqIEBwYXJhbSB7ZnVuY3Rpb259IGNhbGxiYWNrXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwcmVmaXhlciAoZWxlbWVudCwgaW5kZXgsIGNoaWxkcmVuLCBjYWxsYmFjaykge1xuXHRpZiAoZWxlbWVudC5sZW5ndGggPiAtMSlcblx0XHRpZiAoIWVsZW1lbnQucmV0dXJuKVxuXHRcdFx0c3dpdGNoIChlbGVtZW50LnR5cGUpIHtcblx0XHRcdFx0Y2FzZSBERUNMQVJBVElPTjogZWxlbWVudC5yZXR1cm4gPSBwcmVmaXgoZWxlbWVudC52YWx1ZSwgZWxlbWVudC5sZW5ndGgsIGNoaWxkcmVuKVxuXHRcdFx0XHRcdHJldHVyblxuXHRcdFx0XHRjYXNlIEtFWUZSQU1FUzpcblx0XHRcdFx0XHRyZXR1cm4gc2VyaWFsaXplKFtjb3B5KGVsZW1lbnQsIHt2YWx1ZTogcmVwbGFjZShlbGVtZW50LnZhbHVlLCAnQCcsICdAJyArIFdFQktJVCl9KV0sIGNhbGxiYWNrKVxuXHRcdFx0XHRjYXNlIFJVTEVTRVQ6XG5cdFx0XHRcdFx0aWYgKGVsZW1lbnQubGVuZ3RoKVxuXHRcdFx0XHRcdFx0cmV0dXJuIGNvbWJpbmUoY2hpbGRyZW4gPSBlbGVtZW50LnByb3BzLCBmdW5jdGlvbiAodmFsdWUpIHtcblx0XHRcdFx0XHRcdFx0c3dpdGNoIChtYXRjaCh2YWx1ZSwgY2FsbGJhY2sgPSAvKDo6cGxhY1xcdyt8OnJlYWQtXFx3KykvKSkge1xuXHRcdFx0XHRcdFx0XHRcdC8vIDpyZWFkLShvbmx5fHdyaXRlKVxuXHRcdFx0XHRcdFx0XHRcdGNhc2UgJzpyZWFkLW9ubHknOiBjYXNlICc6cmVhZC13cml0ZSc6XG5cdFx0XHRcdFx0XHRcdFx0XHRsaWZ0KGNvcHkoZWxlbWVudCwge3Byb3BzOiBbcmVwbGFjZSh2YWx1ZSwgLzoocmVhZC1cXHcrKS8sICc6JyArIE1PWiArICckMScpXX0pKVxuXHRcdFx0XHRcdFx0XHRcdFx0bGlmdChjb3B5KGVsZW1lbnQsIHtwcm9wczogW3ZhbHVlXX0pKVxuXHRcdFx0XHRcdFx0XHRcdFx0YXNzaWduKGVsZW1lbnQsIHtwcm9wczogZmlsdGVyKGNoaWxkcmVuLCBjYWxsYmFjayl9KVxuXHRcdFx0XHRcdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0XHRcdFx0XHQvLyA6cGxhY2Vob2xkZXJcblx0XHRcdFx0XHRcdFx0XHRjYXNlICc6OnBsYWNlaG9sZGVyJzpcblx0XHRcdFx0XHRcdFx0XHRcdGxpZnQoY29weShlbGVtZW50LCB7cHJvcHM6IFtyZXBsYWNlKHZhbHVlLCAvOihwbGFjXFx3KykvLCAnOicgKyBXRUJLSVQgKyAnaW5wdXQtJDEnKV19KSlcblx0XHRcdFx0XHRcdFx0XHRcdGxpZnQoY29weShlbGVtZW50LCB7cHJvcHM6IFtyZXBsYWNlKHZhbHVlLCAvOihwbGFjXFx3KykvLCAnOicgKyBNT1ogKyAnJDEnKV19KSlcblx0XHRcdFx0XHRcdFx0XHRcdGxpZnQoY29weShlbGVtZW50LCB7cHJvcHM6IFtyZXBsYWNlKHZhbHVlLCAvOihwbGFjXFx3KykvLCBNUyArICdpbnB1dC0kMScpXX0pKVxuXHRcdFx0XHRcdFx0XHRcdFx0bGlmdChjb3B5KGVsZW1lbnQsIHtwcm9wczogW3ZhbHVlXX0pKVxuXHRcdFx0XHRcdFx0XHRcdFx0YXNzaWduKGVsZW1lbnQsIHtwcm9wczogZmlsdGVyKGNoaWxkcmVuLCBjYWxsYmFjayl9KVxuXHRcdFx0XHRcdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0XHRcdHJldHVybiAnJ1xuXHRcdFx0XHRcdFx0fSlcblx0XHRcdH1cbn1cblxuLyoqXG4gKiBAcGFyYW0ge29iamVjdH0gZWxlbWVudFxuICogQHBhcmFtIHtudW1iZXJ9IGluZGV4XG4gKiBAcGFyYW0ge29iamVjdFtdfSBjaGlsZHJlblxuICovXG5leHBvcnQgZnVuY3Rpb24gbmFtZXNwYWNlIChlbGVtZW50KSB7XG5cdHN3aXRjaCAoZWxlbWVudC50eXBlKSB7XG5cdFx0Y2FzZSBSVUxFU0VUOlxuXHRcdFx0ZWxlbWVudC5wcm9wcyA9IGVsZW1lbnQucHJvcHMubWFwKGZ1bmN0aW9uICh2YWx1ZSkge1xuXHRcdFx0XHRyZXR1cm4gY29tYmluZSh0b2tlbml6ZSh2YWx1ZSksIGZ1bmN0aW9uICh2YWx1ZSwgaW5kZXgsIGNoaWxkcmVuKSB7XG5cdFx0XHRcdFx0c3dpdGNoIChjaGFyYXQodmFsdWUsIDApKSB7XG5cdFx0XHRcdFx0XHQvLyBcXGZcblx0XHRcdFx0XHRcdGNhc2UgMTI6XG5cdFx0XHRcdFx0XHRcdHJldHVybiBzdWJzdHIodmFsdWUsIDEsIHN0cmxlbih2YWx1ZSkpXG5cdFx0XHRcdFx0XHQvLyBcXDAgKCArID4gflxuXHRcdFx0XHRcdFx0Y2FzZSAwOiBjYXNlIDQwOiBjYXNlIDQzOiBjYXNlIDYyOiBjYXNlIDEyNjpcblx0XHRcdFx0XHRcdFx0cmV0dXJuIHZhbHVlXG5cdFx0XHRcdFx0XHQvLyA6XG5cdFx0XHRcdFx0XHRjYXNlIDU4OlxuXHRcdFx0XHRcdFx0XHRpZiAoY2hpbGRyZW5bKytpbmRleF0gPT09ICdnbG9iYWwnKVxuXHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuW2luZGV4XSA9ICcnLCBjaGlsZHJlblsrK2luZGV4XSA9ICdcXGYnICsgc3Vic3RyKGNoaWxkcmVuW2luZGV4XSwgaW5kZXggPSAxLCAtMSlcblx0XHRcdFx0XHRcdC8vIFxcc1xuXHRcdFx0XHRcdFx0Y2FzZSAzMjpcblx0XHRcdFx0XHRcdFx0cmV0dXJuIGluZGV4ID09PSAxID8gJycgOiB2YWx1ZVxuXHRcdFx0XHRcdFx0ZGVmYXVsdDpcblx0XHRcdFx0XHRcdFx0c3dpdGNoIChpbmRleCkge1xuXHRcdFx0XHRcdFx0XHRcdGNhc2UgMDogZWxlbWVudCA9IHZhbHVlXG5cdFx0XHRcdFx0XHRcdFx0XHRyZXR1cm4gc2l6ZW9mKGNoaWxkcmVuKSA+IDEgPyAnJyA6IHZhbHVlXG5cdFx0XHRcdFx0XHRcdFx0Y2FzZSBpbmRleCA9IHNpemVvZihjaGlsZHJlbikgLSAxOiBjYXNlIDI6XG5cdFx0XHRcdFx0XHRcdFx0XHRyZXR1cm4gaW5kZXggPT09IDIgPyB2YWx1ZSArIGVsZW1lbnQgKyBlbGVtZW50IDogdmFsdWUgKyBlbGVtZW50XG5cdFx0XHRcdFx0XHRcdFx0ZGVmYXVsdDpcblx0XHRcdFx0XHRcdFx0XHRcdHJldHVybiB2YWx1ZVxuXHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9KVxuXHRcdFx0fSlcblx0fVxufVxuIiwiaW1wb3J0IGUgZnJvbVwiQGVtb3Rpb24vaXMtcHJvcC12YWxpZFwiO2ltcG9ydCB0LHtjcmVhdGVFbGVtZW50IGFzIG59ZnJvbVwicmVhY3RcIjtpbXBvcnQqYXMgbyBmcm9tXCJzdHlsaXNcIjtpbXBvcnR7UlVMRVNFVCBhcyBzfWZyb21cInN0eWxpc1wiO3ZhciByLGk7Y29uc3QgYz1cInVuZGVmaW5lZFwiIT10eXBlb2YgcHJvY2VzcyYmdm9pZCAwIT09cHJvY2Vzcy5lbnYmJihwcm9jZXNzLmVudi5SRUFDVF9BUFBfU0NfQVRUUnx8cHJvY2Vzcy5lbnYuU0NfQVRUUil8fFwiZGF0YS1zdHlsZWRcIixhPVwiYWN0aXZlXCIsbD1cImRhdGEtc3R5bGVkLXZlcnNpb25cIix1PVwiNi41LjNcIixoPVwiLyohc2MqL1xcblwiLGQ9XCJ1bmRlZmluZWRcIiE9dHlwZW9mIHdpbmRvdyYmXCJ1bmRlZmluZWRcIiE9dHlwZW9mIGRvY3VtZW50O2Z1bmN0aW9uIHAoZSl7aWYoXCJ1bmRlZmluZWRcIiE9dHlwZW9mIHByb2Nlc3MmJnZvaWQgMCE9PXByb2Nlc3MuZW52KXtjb25zdCB0PXByb2Nlc3MuZW52W2VdO2lmKHZvaWQgMCE9PXQmJlwiXCIhPT10KXJldHVyblwiZmFsc2VcIiE9PXR9fWNvbnN0IGY9Qm9vbGVhbihcImJvb2xlYW5cIj09dHlwZW9mIFNDX0RJU0FCTEVfU1BFRURZP1NDX0RJU0FCTEVfU1BFRURZOm51bGwhPT0oaT1udWxsIT09KHI9cChcIlJFQUNUX0FQUF9TQ19ESVNBQkxFX1NQRUVEWVwiKSkmJnZvaWQgMCE9PXI/cjpwKFwiU0NfRElTQUJMRV9TUEVFRFlcIikpJiZ2b2lkIDAhPT1pP2k6XCJ1bmRlZmluZWRcIiE9dHlwZW9mIHByb2Nlc3MmJnZvaWQgMCE9PXByb2Nlc3MuZW52JiZcInByb2R1Y3Rpb25cIiE9PXByb2Nlc3MuZW52Lk5PREVfRU5WKSxtPVwic2Mta2V5ZnJhbWVzLVwiLHk9e30sZz1cInByb2R1Y3Rpb25cIiE9PXByb2Nlc3MuZW52Lk5PREVfRU5WP3sxOlwiQ2Fubm90IGNyZWF0ZSBzdHlsZWQtY29tcG9uZW50IGZvciBjb21wb25lbnQ6ICVzLlxcblxcblwiLDI6XCJDYW4ndCBjb2xsZWN0IHN0eWxlcyBvbmNlIHlvdSd2ZSBjb25zdW1lZCBhIGBTZXJ2ZXJTdHlsZVNoZWV0YCdzIHN0eWxlcyEgYFNlcnZlclN0eWxlU2hlZXRgIGlzIGEgb25lIG9mZiBpbnN0YW5jZSBmb3IgZWFjaCBzZXJ2ZXItc2lkZSByZW5kZXIgY3ljbGUuXFxuXFxuLSBBcmUgeW91IHRyeWluZyB0byByZXVzZSBpdCBhY3Jvc3MgcmVuZGVycz9cXG4tIEFyZSB5b3UgYWNjaWRlbnRhbGx5IGNhbGxpbmcgY29sbGVjdFN0eWxlcyB0d2ljZT9cXG5cXG5cIiwzOlwiU3RyZWFtaW5nIFNTUiBpcyBvbmx5IHN1cHBvcnRlZCBpbiBhIE5vZGUuanMgZW52aXJvbm1lbnQ7IFBsZWFzZSBkbyBub3QgdHJ5IHRvIGNhbGwgdGhpcyBtZXRob2QgaW4gdGhlIGJyb3dzZXIuXFxuXFxuXCIsNDpcIlRoZSBgU3R5bGVTaGVldE1hbmFnZXJgIGV4cGVjdHMgYSB2YWxpZCB0YXJnZXQgb3Igc2hlZXQgcHJvcCFcXG5cXG4tIERvZXMgdGhpcyBlcnJvciBvY2N1ciBvbiB0aGUgY2xpZW50IGFuZCBpcyB5b3VyIHRhcmdldCBmYWxzeT9cXG4tIERvZXMgdGhpcyBlcnJvciBvY2N1ciBvbiB0aGUgc2VydmVyIGFuZCBpcyB0aGUgc2hlZXQgZmFsc3k/XFxuXFxuXCIsNTpcIlRoZSBjbG9uZSBtZXRob2QgY2Fubm90IGJlIHVzZWQgb24gdGhlIGNsaWVudCFcXG5cXG4tIEFyZSB5b3UgcnVubmluZyBpbiBhIGNsaWVudC1saWtlIGVudmlyb25tZW50IG9uIHRoZSBzZXJ2ZXI/XFxuLSBBcmUgeW91IHRyeWluZyB0byBydW4gU1NSIG9uIHRoZSBjbGllbnQ/XFxuXFxuXCIsNjpcIlRyeWluZyB0byBpbnNlcnQgYSBuZXcgc3R5bGUgdGFnLCBidXQgdGhlIGdpdmVuIE5vZGUgaXMgdW5tb3VudGVkIVxcblxcbi0gQXJlIHlvdSB1c2luZyBhIGN1c3RvbSB0YXJnZXQgdGhhdCBpc24ndCBtb3VudGVkP1xcbi0gRG9lcyB5b3VyIGRvY3VtZW50IG5vdCBoYXZlIGEgdmFsaWQgaGVhZCBlbGVtZW50P1xcbi0gSGF2ZSB5b3UgYWNjaWRlbnRhbGx5IHJlbW92ZWQgYSBzdHlsZSB0YWcgbWFudWFsbHk/XFxuXFxuXCIsNzonVGhlbWVQcm92aWRlcjogUGxlYXNlIHJldHVybiBhbiBvYmplY3QgZnJvbSB5b3VyIFwidGhlbWVcIiBwcm9wIGZ1bmN0aW9uLCBlLmcuXFxuXFxuYGBganNcXG50aGVtZT17KCkgPT4gKHt9KX1cXG5gYGBcXG5cXG4nLDg6J1RoZW1lUHJvdmlkZXI6IFBsZWFzZSBtYWtlIHlvdXIgXCJ0aGVtZVwiIHByb3AgYW4gb2JqZWN0LlxcblxcbicsOTpcIk1pc3NpbmcgZG9jdW1lbnQgYDxoZWFkPmBcXG5cXG5cIiwxMDpcIkNhbm5vdCBmaW5kIGEgU3R5bGVTaGVldCBpbnN0YW5jZS4gVXN1YWxseSB0aGlzIGhhcHBlbnMgaWYgdGhlcmUgYXJlIG11bHRpcGxlIGNvcGllcyBvZiBzdHlsZWQtY29tcG9uZW50cyBsb2FkZWQgYXQgb25jZS4gQ2hlY2sgb3V0IHRoaXMgaXNzdWUgZm9yIGhvdyB0byB0cm91Ymxlc2hvb3QgYW5kIGZpeCB0aGUgY29tbW9uIGNhc2VzIHdoZXJlIHRoaXMgc2l0dWF0aW9uIGNhbiBoYXBwZW46IGh0dHBzOi8vZ2l0aHViLmNvbS9zdHlsZWQtY29tcG9uZW50cy9zdHlsZWQtY29tcG9uZW50cy9pc3N1ZXMvMTk0MSNpc3N1ZWNvbW1lbnQtNDE3ODYyMDIxXFxuXFxuXCIsMTE6XCJfVGhpcyBlcnJvciB3YXMgcmVwbGFjZWQgd2l0aCBhIGRldi10aW1lIHdhcm5pbmcsIGl0IHdpbGwgYmUgZGVsZXRlZCBmb3IgdjQgZmluYWwuXyBbY3JlYXRlR2xvYmFsU3R5bGVdIHJlY2VpdmVkIGNoaWxkcmVuIHdoaWNoIHdpbGwgbm90IGJlIHJlbmRlcmVkLiBQbGVhc2UgdXNlIHRoZSBjb21wb25lbnQgd2l0aG91dCBwYXNzaW5nIGNoaWxkcmVuIGVsZW1lbnRzLlxcblxcblwiLDEyOlwiSXQgc2VlbXMgeW91IGFyZSBpbnRlcnBvbGF0aW5nIGEga2V5ZnJhbWUgZGVjbGFyYXRpb24gKCVzKSBpbnRvIGFuIHVudGFnZ2VkIHN0cmluZy4gUGxlYXNlIHdyYXAgeW91ciBzdHJpbmcgaW4gdGhlIGNzc1xcXFxgXFxcXGAgaGVscGVyIHdoaWNoIGVuc3VyZXMgdGhlIHN0eWxlcyBhcmUgaW5qZWN0ZWQgY29ycmVjdGx5LiBTZWUgaHR0cHM6Ly9zdHlsZWQtY29tcG9uZW50cy5jb20vZG9jcy9hcGkjY3NzXFxuXFxuXCIsMTM6XCIlcyBpcyBub3QgYSBzdHlsZWQgY29tcG9uZW50IGFuZCBjYW5ub3QgYmUgcmVmZXJyZWQgdG8gdmlhIGNvbXBvbmVudCBzZWxlY3Rvci4gU2VlIGh0dHBzOi8vc3R5bGVkLWNvbXBvbmVudHMuY29tL2RvY3MvYWR2YW5jZWQjcmVmZXJyaW5nLXRvLW90aGVyLWNvbXBvbmVudHMgZm9yIG1vcmUgZGV0YWlscy5cXG5cXG5cIiwxNDonVGhlbWVQcm92aWRlcjogXCJ0aGVtZVwiIHByb3AgaXMgcmVxdWlyZWQuXFxuXFxuJywxNTpcIkEgc3R5bGlzIHBsdWdpbiBoYXMgYmVlbiBzdXBwbGllZCB0aGF0IGlzIG5vdCBuYW1lZC4gV2UgbmVlZCBhIG5hbWUgZm9yIGVhY2ggcGx1Z2luIHRvIGJlIGFibGUgdG8gcHJldmVudCBzdHlsaW5nIGNvbGxpc2lvbnMgYmV0d2VlbiBkaWZmZXJlbnQgc3R5bGlzIGNvbmZpZ3VyYXRpb25zIHdpdGhpbiB0aGUgc2FtZSBhcHAuIEJlZm9yZSB5b3UgcGFzcyB5b3VyIHBsdWdpbiB0byBgPFN0eWxlU2hlZXRNYW5hZ2VyIHN0eWxpc1BsdWdpbnM9e1tdfT5gLCBwbGVhc2UgbWFrZSBzdXJlIGVhY2ggcGx1Z2luIGlzIHVuaXF1ZWx5LW5hbWVkLCBlLmcuXFxuXFxuYGBganNcXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoaW1wb3J0ZWRQbHVnaW4sICduYW1lJywgeyB2YWx1ZTogJ3NvbWUtdW5pcXVlLW5hbWUnIH0pO1xcbmBgYFxcblxcblwiLDE2OlwiUmVhY2hlZCB0aGUgbGltaXQgb2YgaG93IG1hbnkgc3R5bGVkIGNvbXBvbmVudHMgbWF5IGJlIGNyZWF0ZWQgYXQgZ3JvdXAgJXMuXFxuWW91IG1heSBvbmx5IGNyZWF0ZSB1cCB0byAxLDA3Myw3NDEsODI0IGNvbXBvbmVudHMuIElmIHlvdSdyZSBjcmVhdGluZyBjb21wb25lbnRzIGR5bmFtaWNhbGx5LFxcbmFzIGZvciBpbnN0YW5jZSBpbiB5b3VyIHJlbmRlciBtZXRob2QgdGhlbiB5b3UgbWF5IGJlIHJ1bm5pbmcgaW50byB0aGlzIGxpbWl0YXRpb24uXFxuXFxuXCIsMTc6XCJDU1NTdHlsZVNoZWV0IGNvdWxkIG5vdCBiZSBmb3VuZCBvbiBIVE1MU3R5bGVFbGVtZW50LlxcbkhhcyBzdHlsZWQtY29tcG9uZW50cycgc3R5bGUgdGFnIGJlZW4gdW5tb3VudGVkIG9yIGFsdGVyZWQgYnkgYW5vdGhlciBzY3JpcHQ/XFxuXFxuXCIsMTg6XCJBY2Nlc3NpbmcgYHVzZVRoZW1lYCBob29rIG91dHNpZGUgb2YgYSBgPFRoZW1lUHJvdmlkZXI+YCBlbGVtZW50LlxcblxcbmBgYGpzeFxcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnO1xcbmV4cG9ydCBmdW5jdGlvbiBTdHlsZWRDb21wb2VudCh7IGNoaWxkcmVuIH0pIHtcXG4gIGNvbnN0IHRoZW1lID0gdXNlVGhlbWUoKTtcXG4gIHJldHVybiA8ZGl2IHN0eWxlPXt7IHdpZHRoOiB0aGVtZS5zaXplcy5mdWxsIH19PntjaGlsZHJlbn08L2Rpdj47XFxufVxcblxcbmltcG9ydCB7IFN0eWxlZENvbXBvbmVudCB9IGZyb20gJy4vU3R5bGVkQ29tcG9uZW50JztcXG5pbXBvcnQgeyB0aGVtZSB9IGZyb20gJy4vdGhlbWUnO1xcbmV4cG9ydCBmdW5jdGlvbiBBcHAoKSB7XFxuICByZXR1cm4gKFxcbiAgICA8VGhlbWVQcm92aWRlciB0aGVtZT17dGhlbWV9PlxcbiAgICAgIDxTdHlsZWRDb21wb25lbnQgLz5cXG4gICAgPC9UaGVtZVByb3ZpZGVyPlxcbiAgKTtcXG59XFxuYGBgXFxuXFxuSWYgeW91IG5lZWQgYWNjZXNzIHRvIHRoZSB0aGVtZSBpbiBhbiB1bmNlcnRhaW4gY29tcG9zaXRpb24gc2NlbmFyaW8sIGBSZWFjdC51c2VDb250ZXh0KFRoZW1lQ29udGV4dClgIHdpbGwgbm90IGVtaXQgYW4gZXJyb3IgaWYgdGhlcmUgaXMgbm8gYFRoZW1lUHJvdmlkZXJgIGFuY2VzdG9yLlxcblwifTp7fTtmdW5jdGlvbiB2KGUsLi4udCl7cmV0dXJuXCJwcm9kdWN0aW9uXCI9PT1wcm9jZXNzLmVudi5OT0RFX0VOVj9uZXcgRXJyb3IoYEFuIGVycm9yIG9jY3VycmVkLiBTZWUgaHR0cHM6Ly9naXRodWIuY29tL3N0eWxlZC1jb21wb25lbnRzL3N0eWxlZC1jb21wb25lbnRzL2Jsb2IvbWFpbi9wYWNrYWdlcy9zdHlsZWQtY29tcG9uZW50cy9zcmMvdXRpbHMvZXJyb3JzLm1kIyR7ZX0gZm9yIG1vcmUgaW5mb3JtYXRpb24uJHt0Lmxlbmd0aD4wP2AgQXJnczogJHt0LmpvaW4oXCIsIFwiKX1gOlwiXCJ9YCk6bmV3IEVycm9yKGZ1bmN0aW9uKC4uLmUpe2xldCB0PWVbMF07Y29uc3Qgbj1bXTtmb3IobGV0IHQ9MSxvPWUubGVuZ3RoO3Q8bzt0Kz0xKW4ucHVzaChlW3RdKTtyZXR1cm4gbi5mb3JFYWNoKGU9Pnt0PXQucmVwbGFjZSgvJVthLXpdLyxlKX0pLHR9KGdbZV0sLi4udCkudHJpbSgpKX1jb25zdCBTPTE8PDMwO2xldCBiPW5ldyBNYXAsdz1uZXcgTWFwLE49MTtjb25zdCBDPWU9PntpZihiLmhhcyhlKSlyZXR1cm4gYi5nZXQoZSk7Zm9yKDt3LmhhcyhOKTspTisrO2NvbnN0IHQ9TisrO2lmKFwicHJvZHVjdGlvblwiIT09cHJvY2Vzcy5lbnYuTk9ERV9FTlYmJigoMHx0KTwwfHx0PlMpKXRocm93IHYoMTYsYCR7dH1gKTtyZXR1cm4gYi5zZXQoZSx0KSx3LnNldCh0LGUpLHR9LE89ZT0+dy5nZXQoZSksRT0oZSx0KT0+e049dCsxLGIuc2V0KGUsdCksdy5zZXQodCxlKX0sQT0vaW52YWxpZCBob29rIGNhbGwvaSxQPW5ldyBTZXQsXz0oZSxuKT0+e2lmKFwicHJvZHVjdGlvblwiIT09cHJvY2Vzcy5lbnYuTk9ERV9FTlYpe2NvbnN0IG89YFRoZSBjb21wb25lbnQgJHtlfSR7bj9gIHdpdGggdGhlIGlkIG9mIFwiJHtufVwiYDpcIlwifSBoYXMgYmVlbiBjcmVhdGVkIGR5bmFtaWNhbGx5LlxcbllvdSBtYXkgc2VlIHRoaXMgd2FybmluZyBiZWNhdXNlIHlvdSd2ZSBjYWxsZWQgc3R5bGVkIGluc2lkZSBhbm90aGVyIGNvbXBvbmVudC5cXG5UbyByZXNvbHZlIHRoaXMgb25seSBjcmVhdGUgbmV3IFN0eWxlZENvbXBvbmVudHMgb3V0c2lkZSBvZiBhbnkgcmVuZGVyIG1ldGhvZCBhbmQgZnVuY3Rpb24gY29tcG9uZW50LlxcblNlZSBodHRwczovL3N0eWxlZC1jb21wb25lbnRzLmNvbS9kb2NzL2Jhc2ljcyNkZWZpbmUtc3R5bGVkLWNvbXBvbmVudHMtb3V0c2lkZS1vZi10aGUtcmVuZGVyLW1ldGhvZCBmb3IgbW9yZSBpbmZvLlxcbmAscz1jb25zb2xlLmVycm9yO3RyeXtsZXQgZT0hMDtjb25zb2xlLmVycm9yPSh0LC4uLm4pPT57QS50ZXN0KHQpPyhlPSExLFAuZGVsZXRlKG8pKTpzKHQsLi4ubil9LFwiZnVuY3Rpb25cIj09dHlwZW9mIHQudXNlU3RhdGUmJnQudXNlU3RhdGUobnVsbCksZSYmIVAuaGFzKG8pJiYoY29uc29sZS53YXJuKG8pLFAuYWRkKG8pKX1jYXRjaChlKXtBLnRlc3QoZS5tZXNzYWdlKSYmUC5kZWxldGUobyl9ZmluYWxseXtjb25zb2xlLmVycm9yPXN9fX0sST1PYmplY3QuZnJlZXplKFtdKSwkPU9iamVjdC5mcmVlemUoe30pO2Z1bmN0aW9uIFIoZSx0LG49JCl7cmV0dXJuIGUudGhlbWUhPT1uLnRoZW1lJiZlLnRoZW1lfHx0fHxuLnRoZW1lfWNvbnN0IGo9L1shXCIjJCUmJygpKissLi86Ozw9Pj9AW1xcXFxcXF1eYHt8fX4tXSsvZyx4PS8oXi18LSQpL2c7ZnVuY3Rpb24gVChlKXtyZXR1cm4gZS5yZXBsYWNlKGosXCItXCIpLnJlcGxhY2UoeCxcIlwiKX1jb25zdCBrPS8oYSkoZCkvZ2ksRD1lPT5TdHJpbmcuZnJvbUNoYXJDb2RlKGUrKGU+MjU/Mzk6OTcpKTtmdW5jdGlvbiBWKGUpe2xldCB0LG49XCJcIjtmb3IodD1NYXRoLmFicyhlKTt0PjUyO3Q9dC81MnwwKW49RCh0JTUyKStuO3JldHVybihEKHQlNTIpK24pLnJlcGxhY2UoayxcIiQxLSQyXCIpfWNvbnN0IE09NTM4MSxHPShlLHQpPT57bGV0IG49dC5sZW5ndGg7Zm9yKDtuOyllPTMzKmVedC5jaGFyQ29kZUF0KC0tbik7cmV0dXJuIGV9LEY9ZT0+RyhNLGUpO2Z1bmN0aW9uIHooZSl7cmV0dXJuIFYoRihlKT4+PjApfWZ1bmN0aW9uIFcoZSl7cmV0dXJuXCJwcm9kdWN0aW9uXCIhPT1wcm9jZXNzLmVudi5OT0RFX0VOViYmXCJzdHJpbmdcIj09dHlwZW9mIGUmJmV8fGUuZGlzcGxheU5hbWV8fGUubmFtZXx8XCJDb21wb25lbnRcIn1mdW5jdGlvbiBMKGUpe3JldHVyblwic3RyaW5nXCI9PXR5cGVvZiBlJiYoXCJwcm9kdWN0aW9uXCI9PT1wcm9jZXNzLmVudi5OT0RFX0VOVnx8ZS5jaGFyQXQoMCk9PT1lLmNoYXJBdCgwKS50b0xvd2VyQ2FzZSgpKX1mdW5jdGlvbiBCKGUpe3JldHVybiBMKGUpP2BzdHlsZWQuJHtlfWA6YFN0eWxlZCgke1coZSl9KWB9Y29uc3QgcT1TeW1ib2wuZm9yKFwicmVhY3QubWVtb1wiKSxIPVN5bWJvbC5mb3IoXCJyZWFjdC5mb3J3YXJkX3JlZlwiKSxZPXtjb250ZXh0VHlwZTohMCxkZWZhdWx0UHJvcHM6ITAsZGlzcGxheU5hbWU6ITAsZ2V0RGVyaXZlZFN0YXRlRnJvbUVycm9yOiEwLGdldERlcml2ZWRTdGF0ZUZyb21Qcm9wczohMCxwcm9wVHlwZXM6ITAsdHlwZTohMH0sVT17bmFtZTohMCxsZW5ndGg6ITAscHJvdG90eXBlOiEwLGNhbGxlcjohMCxjYWxsZWU6ITAsYXJndW1lbnRzOiEwLGFyaXR5OiEwfSxKPXskJHR5cGVvZjohMCxjb21wYXJlOiEwLGRlZmF1bHRQcm9wczohMCxkaXNwbGF5TmFtZTohMCxwcm9wVHlwZXM6ITAsdHlwZTohMH0sWD17W0hdOnskJHR5cGVvZjohMCxyZW5kZXI6ITAsZGVmYXVsdFByb3BzOiEwLGRpc3BsYXlOYW1lOiEwLHByb3BUeXBlczohMH0sW3FdOkp9O2Z1bmN0aW9uIEsoZSl7cmV0dXJuKFwidHlwZVwiaW4odD1lKSYmdC50eXBlLiQkdHlwZW9mKT09PXE/SjpcIiQkdHlwZW9mXCJpbiBlP1hbZS4kJHR5cGVvZl06WTt2YXIgdH1jb25zdCBRPU9iamVjdC5kZWZpbmVQcm9wZXJ0eSxaPU9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzLGVlPU9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMsdGU9T2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcixuZT1PYmplY3QuZ2V0UHJvdG90eXBlT2Ysb2U9T2JqZWN0LnByb3RvdHlwZTtmdW5jdGlvbiBzZShlLHQsbil7aWYoXCJzdHJpbmdcIiE9dHlwZW9mIHQpe2NvbnN0IG89bmUodCk7byYmbyE9PW9lJiZzZShlLG8sbik7Y29uc3Qgcz1aKHQpLmNvbmNhdChlZSh0KSkscj1LKGUpLGk9Syh0KTtmb3IobGV0IG89MDtvPHMubGVuZ3RoOysrbyl7Y29uc3QgYz1zW29dO2lmKCEoYyBpbiBVfHxuJiZuW2NdfHxpJiZjIGluIGl8fHImJmMgaW4gcikpe2NvbnN0IG49dGUodCxjKTt0cnl7UShlLGMsbil9Y2F0Y2goZSl7fX19fXJldHVybiBlfWZ1bmN0aW9uIHJlKGUpe3JldHVyblwiZnVuY3Rpb25cIj09dHlwZW9mIGV9Y29uc3QgaWU9U3ltYm9sLmZvcihcInJlYWN0LmZvcndhcmRfcmVmXCIpO2Z1bmN0aW9uIGNlKGUpe3JldHVybiBudWxsIT1lJiYoXCJvYmplY3RcIj09dHlwZW9mIGV8fFwiZnVuY3Rpb25cIj09dHlwZW9mIGUpJiZlLiQkdHlwZW9mPT09aWUmJlwic3R5bGVkQ29tcG9uZW50SWRcImluIGV9ZnVuY3Rpb24gYWUoZSx0KXtyZXR1cm4gZSYmdD9lK1wiIFwiK3Q6ZXx8dHx8XCJcIn1mdW5jdGlvbiBsZShlLHQpe3JldHVybiBlLmpvaW4odHx8XCJcIil9ZnVuY3Rpb24gdWUoZSl7cmV0dXJuIG51bGwhPT1lJiZcIm9iamVjdFwiPT10eXBlb2YgZSYmZS5jb25zdHJ1Y3Rvci5uYW1lPT09T2JqZWN0Lm5hbWUmJiEoXCJwcm9wc1wiaW4gZSYmZS4kJHR5cGVvZil9ZnVuY3Rpb24gaGUoZSx0LG49ITEpe2lmKCFuJiYhdWUoZSkmJiFBcnJheS5pc0FycmF5KGUpKXJldHVybiB0O2lmKEFycmF5LmlzQXJyYXkodCkpZm9yKGxldCBuPTA7bjx0Lmxlbmd0aDtuKyspZVtuXT1oZShlW25dLHRbbl0pO2Vsc2UgaWYodWUodCkpZm9yKGNvbnN0IG4gaW4gdCllW25dPWhlKGVbbl0sdFtuXSk7cmV0dXJuIGV9ZnVuY3Rpb24gZGUoZSx0KXtPYmplY3QuZGVmaW5lUHJvcGVydHkoZSxcInRvU3RyaW5nXCIse3ZhbHVlOnR9KX1jb25zdCBwZT1jbGFzc3tjb25zdHJ1Y3RvcihlKXt0aGlzLmdyb3VwU2l6ZXM9bmV3IFVpbnQzMkFycmF5KDUxMiksdGhpcy5sZW5ndGg9NTEyLHRoaXMudGFnPWUsdGhpcy5fY0dyb3VwPTAsdGhpcy5fY0luZGV4PTB9aW5kZXhPZkdyb3VwKGUpe2lmKGU9PT10aGlzLl9jR3JvdXApcmV0dXJuIHRoaXMuX2NJbmRleDtsZXQgdD10aGlzLl9jSW5kZXg7aWYoZT50aGlzLl9jR3JvdXApZm9yKGxldCBuPXRoaXMuX2NHcm91cDtuPGU7bisrKXQrPXRoaXMuZ3JvdXBTaXplc1tuXTtlbHNlIGZvcihsZXQgbj10aGlzLl9jR3JvdXAtMTtuPj1lO24tLSl0LT10aGlzLmdyb3VwU2l6ZXNbbl07cmV0dXJuIHRoaXMuX2NHcm91cD1lLHRoaXMuX2NJbmRleD10LHR9aW5zZXJ0UnVsZXMoZSx0KXtpZihlPj10aGlzLmdyb3VwU2l6ZXMubGVuZ3RoKXtjb25zdCB0PXRoaXMuZ3JvdXBTaXplcyxuPXQubGVuZ3RoO2xldCBvPW47Zm9yKDtlPj1vOylpZihvPDw9MSxvPDApdGhyb3cgdigxNixgJHtlfWApO3RoaXMuZ3JvdXBTaXplcz1uZXcgVWludDMyQXJyYXkobyksdGhpcy5ncm91cFNpemVzLnNldCh0KSx0aGlzLmxlbmd0aD1vO2ZvcihsZXQgZT1uO2U8bztlKyspdGhpcy5ncm91cFNpemVzW2VdPTB9bGV0IG49dGhpcy5pbmRleE9mR3JvdXAoZSsxKSxvPTA7Zm9yKGxldCBzPTAscj10Lmxlbmd0aDtzPHI7cysrKXRoaXMudGFnLmluc2VydFJ1bGUobix0W3NdKSYmKHRoaXMuZ3JvdXBTaXplc1tlXSsrLG4rKyxvKyspO28+MCYmdGhpcy5fY0dyb3VwPmUmJih0aGlzLl9jSW5kZXgrPW8pfWNsZWFyR3JvdXAoZSl7aWYoZTx0aGlzLmxlbmd0aCl7Y29uc3QgdD10aGlzLmdyb3VwU2l6ZXNbZV0sbj10aGlzLmluZGV4T2ZHcm91cChlKSxvPW4rdDt0aGlzLmdyb3VwU2l6ZXNbZV09MDtmb3IobGV0IGU9bjtlPG87ZSsrKXRoaXMudGFnLmRlbGV0ZVJ1bGUobik7dD4wJiZ0aGlzLl9jR3JvdXA+ZSYmKHRoaXMuX2NJbmRleC09dCl9fWdldEdyb3VwKGUpe2xldCB0PVwiXCI7aWYoZT49dGhpcy5sZW5ndGh8fDA9PT10aGlzLmdyb3VwU2l6ZXNbZV0pcmV0dXJuIHQ7Y29uc3Qgbj10aGlzLmdyb3VwU2l6ZXNbZV0sbz10aGlzLmluZGV4T2ZHcm91cChlKSxzPW8rbjtmb3IobGV0IGU9bztlPHM7ZSsrKXQrPXRoaXMudGFnLmdldFJ1bGUoZSkraDtyZXR1cm4gdH19LGZlPWBzdHlsZVske2N9XVske2x9PVwiJHt1fVwiXWAsbWU9bmV3IFJlZ0V4cChgXiR7Y31cXFxcLmcoXFxcXGQrKVxcXFxbaWQ9XCIoW1xcXFx3XFxcXGQtXSspXCJcXFxcXS4qP1wiKFteXCJdKilgKSx5ZT1lPT5cInVuZGVmaW5lZFwiIT10eXBlb2YgU2hhZG93Um9vdCYmZSBpbnN0YW5jZW9mIFNoYWRvd1Jvb3R8fFwiaG9zdFwiaW4gZSYmMTE9PT1lLm5vZGVUeXBlLGdlPWU9PntpZighZSlyZXR1cm4gZG9jdW1lbnQ7aWYoeWUoZSkpcmV0dXJuIGU7aWYoXCJnZXRSb290Tm9kZVwiaW4gZSl7Y29uc3QgdD1lLmdldFJvb3ROb2RlKCk7aWYoeWUodCkpcmV0dXJuIHR9cmV0dXJuIGRvY3VtZW50fSx2ZT0oZSx0LG4pPT57Y29uc3Qgbz1uLnNwbGl0KFwiLFwiKTtsZXQgcztmb3IobGV0IG49MCxyPW8ubGVuZ3RoO248cjtuKyspKHM9b1tuXSkmJmUucmVnaXN0ZXJOYW1lKHQscyl9LFNlPShlLHQpPT57dmFyIG47Y29uc3Qgbz0obnVsbCE9PShuPXQudGV4dENvbnRlbnQpJiZ2b2lkIDAhPT1uP246XCJcIikuc3BsaXQoaCkscz1bXTtmb3IobGV0IHQ9MCxuPW8ubGVuZ3RoO3Q8bjt0Kyspe2NvbnN0IG49b1t0XS50cmltKCk7aWYoIW4pY29udGludWU7Y29uc3Qgcj1uLm1hdGNoKG1lKTtpZihyKXtjb25zdCB0PTB8cGFyc2VJbnQoclsxXSwxMCksbj1yWzJdOzAhPT10JiYoRShuLHQpLHZlKGUsbixyWzNdKSxlLmdldFRhZygpLmluc2VydFJ1bGVzKHQscykpLHMubGVuZ3RoPTB9ZWxzZSBzLnB1c2gobil9fSxiZT1lPT57Y29uc3QgdD1nZShlLm9wdGlvbnMudGFyZ2V0KS5xdWVyeVNlbGVjdG9yQWxsKGZlKTtmb3IobGV0IG49MCxvPXQubGVuZ3RoO248bztuKyspe2NvbnN0IG89dFtuXTtvJiZvLmdldEF0dHJpYnV0ZShjKSE9PWEmJihTZShlLG8pLG8ucGFyZW50Tm9kZSYmby5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKG8pKX19O2xldCB3ZT0hMTtmdW5jdGlvbiBOZSgpe2lmKCExIT09d2UpcmV0dXJuIHdlO2lmKFwidW5kZWZpbmVkXCIhPXR5cGVvZiBkb2N1bWVudCl7Y29uc3QgZT1kb2N1bWVudC5oZWFkLnF1ZXJ5U2VsZWN0b3IoJ21ldGFbcHJvcGVydHk9XCJjc3Atbm9uY2VcIl0nKTtpZihlKXJldHVybiB3ZT1lLm5vbmNlfHxlLmdldEF0dHJpYnV0ZShcImNvbnRlbnRcIil8fHZvaWQgMDtjb25zdCB0PWRvY3VtZW50LmhlYWQucXVlcnlTZWxlY3RvcignbWV0YVtuYW1lPVwic2Mtbm9uY2VcIl0nKTtpZih0KXJldHVybiB3ZT10LmdldEF0dHJpYnV0ZShcImNvbnRlbnRcIil8fHZvaWQgMH1yZXR1cm4gd2U9XCJ1bmRlZmluZWRcIiE9dHlwZW9mIF9fd2VicGFja19ub25jZV9fP19fd2VicGFja19ub25jZV9fOnZvaWQgMH1jb25zdCBDZT0oZSx0KT0+e2NvbnN0IG49ZG9jdW1lbnQuaGVhZCxvPWV8fG4scz1kb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3R5bGVcIikscj0oZT0+e2NvbnN0IHQ9QXJyYXkuZnJvbShlLnF1ZXJ5U2VsZWN0b3JBbGwoYHN0eWxlWyR7Y31dYCkpO3JldHVybiB0W3QubGVuZ3RoLTFdfSkobyksaT12b2lkIDAhPT1yP3IubmV4dFNpYmxpbmc6bnVsbDtzLnNldEF0dHJpYnV0ZShjLGEpLHMuc2V0QXR0cmlidXRlKGwsdSk7Y29uc3QgaD10fHxOZSgpO3JldHVybiBoJiZzLnNldEF0dHJpYnV0ZShcIm5vbmNlXCIsaCksby5pbnNlcnRCZWZvcmUocyxpKSxzfSxPZT1jbGFzc3tjb25zdHJ1Y3RvcihlLHQpe3RoaXMuZWxlbWVudD1DZShlLHQpLHRoaXMuZWxlbWVudC5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShcIlwiKSksdGhpcy5zaGVldD0oZT0+e3ZhciB0O2lmKGUuc2hlZXQpcmV0dXJuIGUuc2hlZXQ7Y29uc3Qgbj1udWxsIT09KHQ9ZS5nZXRSb290Tm9kZSgpLnN0eWxlU2hlZXRzKSYmdm9pZCAwIT09dD90OmRvY3VtZW50LnN0eWxlU2hlZXRzO2ZvcihsZXQgdD0wLG89bi5sZW5ndGg7dDxvO3QrKyl7Y29uc3Qgbz1uW3RdO2lmKG8ub3duZXJOb2RlPT09ZSlyZXR1cm4gb310aHJvdyB2KDE3KX0pKHRoaXMuZWxlbWVudCksdGhpcy5sZW5ndGg9MH1pbnNlcnRSdWxlKGUsdCl7dHJ5e3JldHVybiB0aGlzLnNoZWV0Lmluc2VydFJ1bGUodCxlKSx0aGlzLmxlbmd0aCsrLCEwfWNhdGNoKGUpe3JldHVybiExfX1kZWxldGVSdWxlKGUpe3RoaXMuc2hlZXQuZGVsZXRlUnVsZShlKSx0aGlzLmxlbmd0aC0tfWdldFJ1bGUoZSl7Y29uc3QgdD10aGlzLnNoZWV0LmNzc1J1bGVzW2VdO3JldHVybiB0JiZ0LmNzc1RleHQ/dC5jc3NUZXh0OlwiXCJ9fSxFZT1jbGFzc3tjb25zdHJ1Y3RvcihlLHQpe3RoaXMuZWxlbWVudD1DZShlLHQpLHRoaXMubm9kZXM9dGhpcy5lbGVtZW50LmNoaWxkTm9kZXMsdGhpcy5sZW5ndGg9MH1pbnNlcnRSdWxlKGUsdCl7aWYoZTw9dGhpcy5sZW5ndGgmJmU+PTApe2NvbnN0IG49ZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUodCk7cmV0dXJuIHRoaXMuZWxlbWVudC5pbnNlcnRCZWZvcmUobix0aGlzLm5vZGVzW2VdfHxudWxsKSx0aGlzLmxlbmd0aCsrLCEwfXJldHVybiExfWRlbGV0ZVJ1bGUoZSl7dGhpcy5lbGVtZW50LnJlbW92ZUNoaWxkKHRoaXMubm9kZXNbZV0pLHRoaXMubGVuZ3RoLS19Z2V0UnVsZShlKXtyZXR1cm4gZTx0aGlzLmxlbmd0aD90aGlzLm5vZGVzW2VdLnRleHRDb250ZW50OlwiXCJ9fTtsZXQgQWU9ZDtjb25zdCBQZT17aXNTZXJ2ZXI6IWQsdXNlQ1NTT01JbmplY3Rpb246IWZ9O2NsYXNzIF9le3N0YXRpYyByZWdpc3RlcklkKGUpe3JldHVybiBDKGUpfWNvbnN0cnVjdG9yKGU9JCx0PXt9LG4pe3RoaXMub3B0aW9ucz1PYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sUGUpLGUpLHRoaXMuZ3M9dCx0aGlzLmtleWZyYW1lSWRzPW5ldyBTZXQsdGhpcy5uYW1lcz1uZXcgTWFwKG4pLHRoaXMuc2VydmVyPSEhZS5pc1NlcnZlciwhdGhpcy5zZXJ2ZXImJmQmJkFlJiYoQWU9ITEsYmUodGhpcykpLGRlKHRoaXMsKCk9PihlPT57Y29uc3QgdD1lLmdldFRhZygpLHtsZW5ndGg6bn09dDtsZXQgbz1cIlwiO2ZvcihsZXQgcz0wO3M8bjtzKyspe2NvbnN0IG49TyhzKTtpZih2b2lkIDA9PT1uKWNvbnRpbnVlO2NvbnN0IHI9ZS5uYW1lcy5nZXQobik7aWYodm9pZCAwPT09cnx8IXIuc2l6ZSljb250aW51ZTtjb25zdCBpPXQuZ2V0R3JvdXAocyk7aWYoMD09PWkubGVuZ3RoKWNvbnRpbnVlO2NvbnN0IGE9YytcIi5nXCIrcysnW2lkPVwiJytuKydcIl0nO2xldCBsPVwiXCI7Zm9yKGNvbnN0IGUgb2YgcillLmxlbmd0aD4wJiYobCs9ZStcIixcIik7bys9aSthKyd7Y29udGVudDpcIicrbCsnXCJ9JytofXJldHVybiBvfSkodGhpcykpfXJlaHlkcmF0ZSgpeyF0aGlzLnNlcnZlciYmZCYmYmUodGhpcyl9cmVjb25zdHJ1Y3RXaXRoT3B0aW9ucyhlLHQ9ITApe2NvbnN0IG49bmV3IF9lKE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSx0aGlzLm9wdGlvbnMpLGUpLHRoaXMuZ3MsdCYmdGhpcy5uYW1lc3x8dm9pZCAwKTtyZXR1cm4gbi5rZXlmcmFtZUlkcz1uZXcgU2V0KHRoaXMua2V5ZnJhbWVJZHMpLCF0aGlzLnNlcnZlciYmZCYmZS50YXJnZXQhPT10aGlzLm9wdGlvbnMudGFyZ2V0JiZnZSh0aGlzLm9wdGlvbnMudGFyZ2V0KSE9PWdlKGUudGFyZ2V0KSYmYmUobiksbn1hbGxvY2F0ZUdTSW5zdGFuY2UoZSl7cmV0dXJuIHRoaXMuZ3NbZV09KHRoaXMuZ3NbZV18fDApKzF9Z2V0VGFnKCl7cmV0dXJuIHRoaXMudGFnfHwodGhpcy50YWc9KGU9KCh7dXNlQ1NTT01JbmplY3Rpb246ZSx0YXJnZXQ6dCxub25jZTpufSk9PmU/bmV3IE9lKHQsbik6bmV3IEVlKHQsbikpKHRoaXMub3B0aW9ucyksbmV3IHBlKGUpKSk7dmFyIGV9aGFzTmFtZUZvcklkKGUsdCl7dmFyIG4sbztyZXR1cm4gbnVsbCE9PShvPW51bGw9PT0obj10aGlzLm5hbWVzLmdldChlKSl8fHZvaWQgMD09PW4/dm9pZCAwOm4uaGFzKHQpKSYmdm9pZCAwIT09byYmb31yZWdpc3Rlck5hbWUoZSx0KXtDKGUpLGUuc3RhcnRzV2l0aChtKSYmdGhpcy5rZXlmcmFtZUlkcy5hZGQoZSk7Y29uc3Qgbj10aGlzLm5hbWVzLmdldChlKTtuP24uYWRkKHQpOnRoaXMubmFtZXMuc2V0KGUsbmV3IFNldChbdF0pKX1pbnNlcnRSdWxlcyhlLHQsbil7dGhpcy5yZWdpc3Rlck5hbWUoZSx0KSx0aGlzLmdldFRhZygpLmluc2VydFJ1bGVzKEMoZSksbil9Y2xlYXJOYW1lcyhlKXt0aGlzLm5hbWVzLmhhcyhlKSYmdGhpcy5uYW1lcy5nZXQoZSkuY2xlYXIoKX1jbGVhclJ1bGVzKGUpe3RoaXMuZ2V0VGFnKCkuY2xlYXJHcm91cChDKGUpKSx0aGlzLmNsZWFyTmFtZXMoZSl9Y2xlYXJUYWcoKXt0aGlzLnRhZz12b2lkIDB9fWNvbnN0IEllPW5ldyBXZWFrU2V0LCRlPXthbmltYXRpb25JdGVyYXRpb25Db3VudDoxLGFzcGVjdFJhdGlvOjEsYm9yZGVySW1hZ2VPdXRzZXQ6MSxib3JkZXJJbWFnZVNsaWNlOjEsYm9yZGVySW1hZ2VXaWR0aDoxLGNvbHVtbkNvdW50OjEsY29sdW1uczoxLGZsZXg6MSxmbGV4R3JvdzoxLGZsZXhTaHJpbms6MSxncmlkUm93OjEsZ3JpZFJvd0VuZDoxLGdyaWRSb3dTcGFuOjEsZ3JpZFJvd1N0YXJ0OjEsZ3JpZENvbHVtbjoxLGdyaWRDb2x1bW5FbmQ6MSxncmlkQ29sdW1uU3BhbjoxLGdyaWRDb2x1bW5TdGFydDoxLGZvbnRXZWlnaHQ6MSxsaW5lSGVpZ2h0OjEsb3BhY2l0eToxLG9yZGVyOjEsb3JwaGFuczoxLHNjYWxlOjEsdGFiU2l6ZToxLHdpZG93czoxLHpJbmRleDoxLHpvb206MSxXZWJraXRMaW5lQ2xhbXA6MSxmaWxsT3BhY2l0eToxLGZsb29kT3BhY2l0eToxLHN0b3BPcGFjaXR5OjEsc3Ryb2tlRGFzaGFycmF5OjEsc3Ryb2tlRGFzaG9mZnNldDoxLHN0cm9rZU1pdGVybGltaXQ6MSxzdHJva2VPcGFjaXR5OjEsc3Ryb2tlV2lkdGg6MX07ZnVuY3Rpb24gUmUoZSx0KXtyZXR1cm4gbnVsbD09dHx8XCJib29sZWFuXCI9PXR5cGVvZiB0fHxcIlwiPT09dD9cIlwiOlwibnVtYmVyXCIhPXR5cGVvZiB0fHwwPT09dHx8ZSBpbiAkZXx8ZS5zdGFydHNXaXRoKFwiLS1cIik/U3RyaW5nKHQpLnRyaW0oKTp0K1wicHhcIn1jb25zdCBqZT00NztmdW5jdGlvbiB4ZShlKXtpZig0NT09PWUuY2hhckNvZGVBdCgwKSYmNDU9PT1lLmNoYXJDb2RlQXQoMSkpcmV0dXJuIGU7bGV0IHQ9XCJcIjtmb3IobGV0IG49MDtuPGUubGVuZ3RoO24rKyl7Y29uc3Qgbz1lLmNoYXJDb2RlQXQobik7dCs9bz49NjUmJm88PTkwP1wiLVwiK1N0cmluZy5mcm9tQ2hhckNvZGUobyszMik6ZVtuXX1yZXR1cm4gdC5zdGFydHNXaXRoKFwibXMtXCIpP1wiLVwiK3Q6dH1jb25zdCBUZT1TeW1ib2wuZm9yKFwic2Mta2V5ZnJhbWVzXCIpO2Z1bmN0aW9uIGtlKGUpe3JldHVyblwib2JqZWN0XCI9PXR5cGVvZiBlJiZudWxsIT09ZSYmVGUgaW4gZX1mdW5jdGlvbiBEZShlKXtyZXR1cm4gcmUoZSkmJiEoZS5wcm90b3R5cGUmJmUucHJvdG90eXBlLmlzUmVhY3RDb21wb25lbnQpfWNvbnN0IFZlPWU9Pm51bGw9PWV8fCExPT09ZXx8XCJcIj09PWUsTWU9U3ltYm9sLmZvcihcInJlYWN0LmNsaWVudC5yZWZlcmVuY2VcIik7ZnVuY3Rpb24gR2UoZSl7cmV0dXJuIGUuJCR0eXBlb2Y9PT1NZX1mdW5jdGlvbiBGZShlKXtjb25zdCB0PWUuJCRpZCxuPSh0JiZ0LmluY2x1ZGVzKFwiI1wiKT90LnNwbGl0KFwiI1wiKS5wb3AoKTp0KXx8ZS5uYW1lfHxcInVua25vd25cIjtjb25zb2xlLndhcm4oYEludGVycG9sYXRpbmcgYSBjbGllbnQgY29tcG9uZW50ICgke259KSBhcyBhIHNlbGVjdG9yIGlzIG5vdCBzdXBwb3J0ZWQgaW4gc2VydmVyIGNvbXBvbmVudHMuIFRoZSBjb21wb25lbnQgc2VsZWN0b3IgcGF0dGVybiByZXF1aXJlcyBhY2Nlc3MgdG8gdGhlIGNvbXBvbmVudCdzIGludGVybmFsIGNsYXNzIG5hbWUsIHdoaWNoIGlzIG5vdCBhdmFpbGFibGUgYWNyb3NzIHRoZSBzZXJ2ZXIvY2xpZW50IGJvdW5kYXJ5LiBVc2UgYSBwbGFpbiBDU1MgY2xhc3Mgc2VsZWN0b3IgaW5zdGVhZC5gKX1mdW5jdGlvbiB6ZShlLHQpe2Zvcihjb25zdCBuIGluIGUpe2NvbnN0IG89ZVtuXTtlLmhhc093blByb3BlcnR5KG4pJiYhVmUobykmJihBcnJheS5pc0FycmF5KG8pJiZJZS5oYXMobyl8fHJlKG8pP3QucHVzaCh4ZShuKStcIjpcIixvLFwiO1wiKTp1ZShvKT8odC5wdXNoKG4rXCIge1wiKSx6ZShvLHQpLHQucHVzaChcIn1cIikpOnQucHVzaCh4ZShuKStcIjogXCIrUmUobixvKStcIjtcIikpfX1mdW5jdGlvbiBXZShlLHQsbixvLHM9W10pe2lmKFZlKGUpKXJldHVybiBzO2NvbnN0IHI9dHlwZW9mIGU7aWYoXCJzdHJpbmdcIj09PXIpcmV0dXJuIHMucHVzaChlKSxzO2lmKFwiZnVuY3Rpb25cIj09PXIpe2lmKEdlKGUpKXJldHVyblwicHJvZHVjdGlvblwiIT09cHJvY2Vzcy5lbnYuTk9ERV9FTlYmJkZlKGUpLHM7aWYoRGUoZSkmJnQpe2NvbnN0IHI9ZSh0KTtyZXR1cm5cInByb2R1Y3Rpb25cIj09PXByb2Nlc3MuZW52Lk5PREVfRU5WfHxcIm9iamVjdFwiIT10eXBlb2Ygcnx8QXJyYXkuaXNBcnJheShyKXx8a2Uocil8fHVlKHIpfHxudWxsPT09cnx8Y29uc29sZS5lcnJvcihgJHtXKGUpfSBpcyBub3QgYSBzdHlsZWQgY29tcG9uZW50IGFuZCBjYW5ub3QgYmUgcmVmZXJyZWQgdG8gdmlhIGNvbXBvbmVudCBzZWxlY3Rvci4gU2VlIGh0dHBzOi8vc3R5bGVkLWNvbXBvbmVudHMuY29tL2RvY3MvYWR2YW5jZWQjcmVmZXJyaW5nLXRvLW90aGVyLWNvbXBvbmVudHMgZm9yIG1vcmUgZGV0YWlscy5gKSxXZShyLHQsbixvLHMpfXJldHVybiBzLnB1c2goZSksc31pZihBcnJheS5pc0FycmF5KGUpKXtmb3IobGV0IHI9MDtyPGUubGVuZ3RoO3IrKylXZShlW3JdLHQsbixvLHMpO3JldHVybiBzfXJldHVybiBjZShlKT8ocy5wdXNoKGAuJHtlLnN0eWxlZENvbXBvbmVudElkfWApLHMpOmtlKGUpPyhuPyhlLmluamVjdChuLG8pLHMucHVzaChlLmdldE5hbWUobykpKTpzLnB1c2goZSkscyk6R2UoZSk/KFwicHJvZHVjdGlvblwiIT09cHJvY2Vzcy5lbnYuTk9ERV9FTlYmJkZlKGUpLHMpOnVlKGUpP2UudG9TdHJpbmchPT1PYmplY3QucHJvdG90eXBlLnRvU3RyaW5nPyhzLnB1c2goZS50b1N0cmluZygpKSxzKTooemUoZSxzKSxzKToocy5wdXNoKGUudG9TdHJpbmcoKSkscyl9Y29uc3QgTGU9Rih1KTtjbGFzcyBCZXtjb25zdHJ1Y3RvcihlLHQsbil7dGhpcy5ydWxlcz1lLHRoaXMuY29tcG9uZW50SWQ9dCx0aGlzLmJhc2VIYXNoPUcoTGUsdCksdGhpcy5iYXNlU3R5bGU9bixfZS5yZWdpc3RlcklkKHQpfWdlbmVyYXRlQW5kSW5qZWN0U3R5bGVzKGUsdCxuKXtsZXQgbz10aGlzLmJhc2VTdHlsZT90aGlzLmJhc2VTdHlsZS5nZW5lcmF0ZUFuZEluamVjdFN0eWxlcyhlLHQsbik6XCJcIjt7bGV0IHM9XCJcIjtmb3IobGV0IG89MDtvPHRoaXMucnVsZXMubGVuZ3RoO28rKyl7Y29uc3Qgcj10aGlzLnJ1bGVzW29dO2lmKFwic3RyaW5nXCI9PXR5cGVvZiByKXMrPXI7ZWxzZSBpZihyKWlmKERlKHIpKXtjb25zdCBvPXIoZSk7XCJzdHJpbmdcIj09dHlwZW9mIG8/cys9bzpudWxsIT1vJiYhMSE9PW8mJihcInByb2R1Y3Rpb25cIj09PXByb2Nlc3MuZW52Lk5PREVfRU5WfHxcIm9iamVjdFwiIT10eXBlb2Ygb3x8QXJyYXkuaXNBcnJheShvKXx8a2Uobyl8fHVlKG8pfHxjb25zb2xlLmVycm9yKGAke1cocil9IGlzIG5vdCBhIHN0eWxlZCBjb21wb25lbnQgYW5kIGNhbm5vdCBiZSByZWZlcnJlZCB0byB2aWEgY29tcG9uZW50IHNlbGVjdG9yLiBTZWUgaHR0cHM6Ly9zdHlsZWQtY29tcG9uZW50cy5jb20vZG9jcy9hZHZhbmNlZCNyZWZlcnJpbmctdG8tb3RoZXItY29tcG9uZW50cyBmb3IgbW9yZSBkZXRhaWxzLmApLHMrPWxlKFdlKG8sZSx0LG4pKSl9ZWxzZSBzKz1sZShXZShyLGUsdCxuKSl9aWYocyl7dGhpcy5keW5hbWljTmFtZUNhY2hlfHwodGhpcy5keW5hbWljTmFtZUNhY2hlPW5ldyBNYXApO2NvbnN0IGU9bi5oYXNoP24uaGFzaCtzOnM7bGV0IHI9dGhpcy5keW5hbWljTmFtZUNhY2hlLmdldChlKTtpZighcil7aWYocj1WKEcoRyh0aGlzLmJhc2VIYXNoLG4uaGFzaCkscyk+Pj4wKSx0aGlzLmR5bmFtaWNOYW1lQ2FjaGUuc2l6ZT49MjAwKXtjb25zdCBlPXRoaXMuZHluYW1pY05hbWVDYWNoZS5rZXlzKCkubmV4dCgpLnZhbHVlO3ZvaWQgMCE9PWUmJnRoaXMuZHluYW1pY05hbWVDYWNoZS5kZWxldGUoZSl9dGhpcy5keW5hbWljTmFtZUNhY2hlLnNldChlLHIpfWlmKCF0Lmhhc05hbWVGb3JJZCh0aGlzLmNvbXBvbmVudElkLHIpKXtjb25zdCBlPW4ocyxcIi5cIityLHZvaWQgMCx0aGlzLmNvbXBvbmVudElkKTt0Lmluc2VydFJ1bGVzKHRoaXMuY29tcG9uZW50SWQscixlKX1vPWFlKG8scil9fXJldHVybiBvfX1jb25zdCBxZT0vJi9nO2Z1bmN0aW9uIEhlKGUsdCl7bGV0IG49MDtmb3IoOy0tdD49MCYmOTI9PT1lLmNoYXJDb2RlQXQodCk7KW4rKztyZXR1cm4hKDEmfm4pfWZ1bmN0aW9uIFllKGUpe2NvbnN0IHQ9ZS5sZW5ndGg7bGV0IG49XCJcIixvPTAscz0wLHI9MCxpPSExLGM9ITE7Zm9yKGxldCBhPTA7YTx0O2ErKyl7Y29uc3QgbD1lLmNoYXJDb2RlQXQoYSk7aWYoMCE9PXJ8fGl8fGwhPT1qZXx8NDIhPT1lLmNoYXJDb2RlQXQoYSsxKSlpZihpKTQyPT09bCYmZS5jaGFyQ29kZUF0KGErMSk9PT1qZSYmKGk9ITEsYSsrKTtlbHNlIGlmKDM0IT09bCYmMzkhPT1sfHxIZShlLGEpKXtpZigwPT09cilpZigxMjM9PT1sKXMrKztlbHNlIGlmKDEyNT09PWwpe2lmKHMtLSxzPDApe2M9ITA7bGV0IG49YSsxO2Zvcig7bjx0Oyl7Y29uc3QgdD1lLmNoYXJDb2RlQXQobik7aWYoNTk9PT10fHwxMD09PXQpYnJlYWs7bisrfW48dCYmNTk9PT1lLmNoYXJDb2RlQXQobikmJm4rKyxzPTAsYT1uLTEsbz1uO2NvbnRpbnVlfTA9PT1zJiYobis9ZS5zdWJzdHJpbmcobyxhKzEpLG89YSsxKX1lbHNlIDU5PT09bCYmMD09PXMmJihuKz1lLnN1YnN0cmluZyhvLGErMSksbz1hKzEpfWVsc2UgMD09PXI/cj1sOnI9PT1sJiYocj0wKTtlbHNlIGk9ITAsYSsrfXJldHVybiBjfHwwIT09c3x8MCE9PXI/KG88dCYmMD09PXMmJjA9PT1yJiYobis9ZS5zdWJzdHJpbmcobykpLG4pOmV9ZnVuY3Rpb24gVWUoZSx0KXtjb25zdCBuPXQrXCIgXCIsbz1cIixcIituO2ZvcihsZXQgcz0wO3M8ZS5sZW5ndGg7cysrKXtjb25zdCByPWVbc107aWYoXCJydWxlXCI9PT1yLnR5cGUpe3IudmFsdWU9KG4rci52YWx1ZSkucmVwbGFjZUFsbChcIixcIixvKTtjb25zdCBlPXIucHJvcHMsdD1bXTtmb3IobGV0IG89MDtvPGUubGVuZ3RoO28rKyl0W29dPW4rZVtvXTtyLnByb3BzPXR9QXJyYXkuaXNBcnJheShyLmNoaWxkcmVuKSYmXCJAa2V5ZnJhbWVzXCIhPT1yLnR5cGUmJlVlKHIuY2hpbGRyZW4sdCl9cmV0dXJuIGV9ZnVuY3Rpb24gSmUoe29wdGlvbnM6ZT0kLHBsdWdpbnM6dD1JfT0kKXtsZXQgbixzLHI7Y29uc3QgaT0oZSx0LG8pPT5vLnN0YXJ0c1dpdGgocykmJm8uZW5kc1dpdGgocykmJm8ucmVwbGFjZUFsbChzLFwiXCIpLmxlbmd0aD4wP2AuJHtufWA6ZSxjPXQuc2xpY2UoKTtjLnB1c2goZT0+e2UudHlwZT09PW8uUlVMRVNFVCYmZS52YWx1ZS5pbmNsdWRlcyhcIiZcIikmJihyfHwocj1uZXcgUmVnRXhwKGBcXFxcJHtzfVxcXFxiYCxcImdcIikpLGUucHJvcHNbMF09ZS5wcm9wc1swXS5yZXBsYWNlKHFlLHMpLnJlcGxhY2UocixpKSl9KSxlLnByZWZpeCYmYy5wdXNoKG8ucHJlZml4ZXIpLGMucHVzaChvLnN0cmluZ2lmeSk7bGV0IGE9W107Y29uc3QgbD1vLm1pZGRsZXdhcmUoYy5jb25jYXQoby5ydWxlc2hlZXQoZT0+YS5wdXNoKGUpKSkpLHU9KHQsaT1cIlwiLGM9XCJcIix1PVwiJlwiKT0+e249dSxzPWkscj12b2lkIDA7Y29uc3QgaD1mdW5jdGlvbihlKXtjb25zdCB0PS0xIT09ZS5pbmRleE9mKFwiLy9cIiksbj0tMSE9PWUuaW5kZXhPZihcIn1cIik7aWYoIXQmJiFuKXJldHVybiBlO2lmKCF0KXJldHVybiBZZShlKTtjb25zdCBvPWUubGVuZ3RoO2xldCBzPVwiXCIscj0wLGk9MCxjPTAsYT0wLGw9MCx1PSExO2Zvcig7aTxvOyl7Y29uc3QgdD1lLmNoYXJDb2RlQXQoaSk7aWYoMzQhPT10JiYzOSE9PXR8fEhlKGUsaSkpaWYoMD09PWMpaWYodD09PWplJiZpKzE8byYmNDI9PT1lLmNoYXJDb2RlQXQoaSsxKSl7Zm9yKGkrPTI7aSsxPG8mJig0MiE9PWUuY2hhckNvZGVBdChpKXx8ZS5jaGFyQ29kZUF0KGkrMSkhPT1qZSk7KWkrKztpKz0yfWVsc2UgaWYoNDAhPT10KWlmKDQxIT09dClpZihhPjApaSsrO2Vsc2UgaWYoNDI9PT10JiZpKzE8byYmZS5jaGFyQ29kZUF0KGkrMSk9PT1qZSlzKz1lLnN1YnN0cmluZyhyLGkpLGkrPTIscj1pLHU9ITA7ZWxzZSBpZih0PT09amUmJmkrMTxvJiZlLmNoYXJDb2RlQXQoaSsxKT09PWplKXtmb3Iocys9ZS5zdWJzdHJpbmcocixpKTtpPG8mJjEwIT09ZS5jaGFyQ29kZUF0KGkpOylpKys7cj1pLHU9ITB9ZWxzZSAxMjM9PT10P2wrKzoxMjU9PT10JiZsLS0saSsrO2Vsc2UgYT4wJiZhLS0saSsrO2Vsc2UgYSsrLGkrKztlbHNlIGkrKztlbHNlIDA9PT1jP2M9dDpjPT09dCYmKGM9MCksaSsrfXJldHVybiB1PyhyPG8mJihzKz1lLnN1YnN0cmluZyhyKSksMD09PWw/czpZZShzKSk6MD09PWw/ZTpZZShlKX0odCk7bGV0IGQ9by5jb21waWxlKGN8fGk/YytcIiBcIitpK1wiIHsgXCIraCtcIiB9XCI6aCk7cmV0dXJuIGUubmFtZXNwYWNlJiYoZD1VZShkLGUubmFtZXNwYWNlKSksYT1bXSxvLnNlcmlhbGl6ZShkLGwpLGF9LGg9ZTtsZXQgZD1NO2ZvcihsZXQgZT0wO2U8dC5sZW5ndGg7ZSsrKXRbZV0ubmFtZXx8digxNSksZD1HKGQsdFtlXS5uYW1lKTtyZXR1cm4obnVsbD09aD92b2lkIDA6aC5uYW1lc3BhY2UpJiYoZD1HKGQsaC5uYW1lc3BhY2UpKSwobnVsbD09aD92b2lkIDA6aC5wcmVmaXgpJiYoZD1HKGQsXCJwXCIpKSx1Lmhhc2g9ZCE9PU0/ZC50b1N0cmluZygpOlwiXCIsdX1jb25zdCBYZT1uZXcgX2UsS2U9SmUoKSxRZT10LmNyZWF0ZUNvbnRleHQoe3Nob3VsZEZvcndhcmRQcm9wOnZvaWQgMCxzdHlsZVNoZWV0OlhlLHN0eWxpczpLZSxzdHlsaXNQbHVnaW5zOnZvaWQgMH0pLFplPVFlLkNvbnN1bWVyO2Z1bmN0aW9uIGV0KCl7cmV0dXJuIHQudXNlQ29udGV4dChRZSl9ZnVuY3Rpb24gdHQoZSl7dmFyIG47Y29uc3Qgbz1ldCgpLHtzdHlsZVNoZWV0OnN9PW8scj10LnVzZU1lbW8oKCk9PntsZXQgdD1zO3JldHVybiBlLnNoZWV0P3Q9ZS5zaGVldDplLnRhcmdldD90PXQucmVjb25zdHJ1Y3RXaXRoT3B0aW9ucyh2b2lkIDAhPT1lLm5vbmNlP3t0YXJnZXQ6ZS50YXJnZXQsbm9uY2U6ZS5ub25jZX06e3RhcmdldDplLnRhcmdldH0sITEpOnZvaWQgMCE9PWUubm9uY2UmJih0PXQucmVjb25zdHJ1Y3RXaXRoT3B0aW9ucyh7bm9uY2U6ZS5ub25jZX0pKSxlLmRpc2FibGVDU1NPTUluamVjdGlvbiYmKHQ9dC5yZWNvbnN0cnVjdFdpdGhPcHRpb25zKHt1c2VDU1NPTUluamVjdGlvbjohMX0pKSx0fSxbZS5kaXNhYmxlQ1NTT01JbmplY3Rpb24sZS5ub25jZSxlLnNoZWV0LGUudGFyZ2V0LHNdKSxpPXQudXNlTWVtbygoKT0+e3ZhciB0O3JldHVybiB2b2lkIDA9PT1lLnN0eWxpc1BsdWdpbnMmJnZvaWQgMD09PWUubmFtZXNwYWNlJiZ2b2lkIDA9PT1lLmVuYWJsZVZlbmRvclByZWZpeGVzP28uc3R5bGlzOkplKHtvcHRpb25zOntuYW1lc3BhY2U6ZS5uYW1lc3BhY2UscHJlZml4OmUuZW5hYmxlVmVuZG9yUHJlZml4ZXN9LHBsdWdpbnM6bnVsbCE9PSh0PWUuc3R5bGlzUGx1Z2lucykmJnZvaWQgMCE9PXQ/dDpvLnN0eWxpc1BsdWdpbnN9KX0sW2UuZW5hYmxlVmVuZG9yUHJlZml4ZXMsZS5uYW1lc3BhY2UsZS5zdHlsaXNQbHVnaW5zLG8uc3R5bGlzLG8uc3R5bGlzUGx1Z2luc10pLGM9XCJzaG91bGRGb3J3YXJkUHJvcFwiaW4gZT9lLnNob3VsZEZvcndhcmRQcm9wOm8uc2hvdWxkRm9yd2FyZFByb3AsYT1udWxsIT09KG49ZS5zdHlsaXNQbHVnaW5zKSYmdm9pZCAwIT09bj9uOm8uc3R5bGlzUGx1Z2lucyxsPXQudXNlTWVtbygoKT0+KHtzaG91bGRGb3J3YXJkUHJvcDpjLHN0eWxlU2hlZXQ6cixzdHlsaXM6aSxzdHlsaXNQbHVnaW5zOmF9KSxbYyxyLGksYV0pO3JldHVybiB0LmNyZWF0ZUVsZW1lbnQoUWUuUHJvdmlkZXIse3ZhbHVlOmx9LGUuY2hpbGRyZW4pfWNvbnN0IG50PXQuY3JlYXRlQ29udGV4dCh2b2lkIDApLG90PW50LkNvbnN1bWVyO2Z1bmN0aW9uIHN0KCl7Y29uc3QgZT10LnVzZUNvbnRleHQobnQpO2lmKCFlKXRocm93IHYoMTgpO3JldHVybiBlfWZ1bmN0aW9uIHJ0KGUpe2NvbnN0IG49dC51c2VDb250ZXh0KG50KSxvPXQudXNlTWVtbygoKT0+ZnVuY3Rpb24oZSx0KXtpZighZSl0aHJvdyB2KDE0KTtpZihyZShlKSl7Y29uc3Qgbj1lKHQpO2lmKFwicHJvZHVjdGlvblwiIT09cHJvY2Vzcy5lbnYuTk9ERV9FTlYmJihudWxsPT09bnx8QXJyYXkuaXNBcnJheShuKXx8XCJvYmplY3RcIiE9dHlwZW9mIG4pKXRocm93IHYoNyk7cmV0dXJuIG59aWYoQXJyYXkuaXNBcnJheShlKXx8XCJvYmplY3RcIiE9dHlwZW9mIGUpdGhyb3cgdig4KTtyZXR1cm4gdD9PYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sdCksZSk6ZX0oZS50aGVtZSxuKSxbZS50aGVtZSxuXSk7cmV0dXJuIGUuY2hpbGRyZW4/dC5jcmVhdGVFbGVtZW50KG50LlByb3ZpZGVyLHt2YWx1ZTpvfSxlLmNoaWxkcmVuKTpudWxsfWNvbnN0IGl0PU9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHksY3Q9e307ZnVuY3Rpb24gYXQoZSx0KXtjb25zdCBuPVwic3RyaW5nXCIhPXR5cGVvZiBlP1wic2NcIjpUKGUpO2N0W25dPShjdFtuXXx8MCkrMTtjb25zdCBvPW4rXCItXCIreih1K24rY3Rbbl0pO3JldHVybiB0P3QrXCItXCIrbzpvfWxldCBsdDtmdW5jdGlvbiB1dChvLHMscil7Y29uc3QgaT1jZShvKSxjPW8sYT0hTChvKSx7YXR0cnM6bD1JLGNvbXBvbmVudElkOnU9YXQocy5kaXNwbGF5TmFtZSxzLnBhcmVudENvbXBvbmVudElkKSxkaXNwbGF5TmFtZTpoPUIobyl9PXMsZD1zLmRpc3BsYXlOYW1lJiZzLmNvbXBvbmVudElkP1Qocy5kaXNwbGF5TmFtZSkrXCItXCIrcy5jb21wb25lbnRJZDpzLmNvbXBvbmVudElkfHx1LHA9aSYmYy5hdHRycz9jLmF0dHJzLmNvbmNhdChsKS5maWx0ZXIoQm9vbGVhbik6bDtsZXR7c2hvdWxkRm9yd2FyZFByb3A6Zn09cztpZihpJiZjLnNob3VsZEZvcndhcmRQcm9wKXtjb25zdCBlPWMuc2hvdWxkRm9yd2FyZFByb3A7aWYocy5zaG91bGRGb3J3YXJkUHJvcCl7Y29uc3QgdD1zLnNob3VsZEZvcndhcmRQcm9wO2Y9KG4sbyk9PmUobixvKSYmdChuLG8pfWVsc2UgZj1lfWNvbnN0IG09bmV3IEJlKHIsZCxpP2MuY29tcG9uZW50U3R5bGU6dm9pZCAwKTtmdW5jdGlvbiB5KG8scyl7cmV0dXJuIGZ1bmN0aW9uKG8scyxyKXtjb25zdHthdHRyczppLGNvbXBvbmVudFN0eWxlOmMsZGVmYXVsdFByb3BzOmEsZm9sZGVkQ29tcG9uZW50SWRzOmwsc3R5bGVkQ29tcG9uZW50SWQ6dSx0YXJnZXQ6aH09byxkPXQudXNlQ29udGV4dChudCkscD1ldCgpLGY9by5zaG91bGRGb3J3YXJkUHJvcHx8cC5zaG91bGRGb3J3YXJkUHJvcDtcInByb2R1Y3Rpb25cIiE9PXByb2Nlc3MuZW52Lk5PREVfRU5WJiZ0LnVzZURlYnVnVmFsdWUmJnQudXNlRGVidWdWYWx1ZSh1KTtjb25zdCBtPVIocyxkLGEpfHwkO2xldCB5LGc7e2NvbnN0IGU9dC51c2VSZWYobnVsbCksbj1lLmN1cnJlbnQ7aWYobnVsbCE9PW4mJm5bMV09PT1tJiZuWzJdPT09cC5zdHlsZVNoZWV0JiZuWzNdPT09cC5zdHlsaXMmJm5bN109PT1jJiZmdW5jdGlvbihlLHQsbil7Y29uc3Qgbz1lLHM9dDtsZXQgcj0wO2Zvcihjb25zdCBlIGluIHMpaWYoaXQuY2FsbChzLGUpJiYocisrLG9bZV0hPT1zW2VdKSlyZXR1cm4hMTtyZXR1cm4gcj09PW59KG5bMF0scyxuWzRdKSl5PW5bNV0sZz1uWzZdO2Vsc2V7eT1mdW5jdGlvbihlLHQsbil7Y29uc3Qgbz1PYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sdCkse2NsYXNzTmFtZTp2b2lkIDAsdGhlbWU6bn0pLHM9ZS5sZW5ndGg+MTtmb3IobGV0IG49MDtuPGUubGVuZ3RoO24rKyl7Y29uc3Qgcj1lW25dLGk9cmUocik/cihzP09iamVjdC5hc3NpZ24oe30sbyk6byk6cjtmb3IoY29uc3QgZSBpbiBpKVwiY2xhc3NOYW1lXCI9PT1lP28uY2xhc3NOYW1lPWFlKG8uY2xhc3NOYW1lLGlbZV0pOlwic3R5bGVcIj09PWU/by5zdHlsZT1PYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sby5zdHlsZSksaVtlXSk6ZSBpbiB0JiZ2b2lkIDA9PT10W2VdfHwob1tlXT1pW2VdKX1yZXR1cm5cImNsYXNzTmFtZVwiaW4gdCYmXCJzdHJpbmdcIj09dHlwZW9mIHQuY2xhc3NOYW1lJiYoby5jbGFzc05hbWU9YWUoby5jbGFzc05hbWUsdC5jbGFzc05hbWUpKSxvfShpLHMsbSksZz1jLmdlbmVyYXRlQW5kSW5qZWN0U3R5bGVzKHkscC5zdHlsZVNoZWV0LHAuc3R5bGlzKTtsZXQgdD0wO2Zvcihjb25zdCBlIGluIHMpaXQuY2FsbChzLGUpJiZ0Kys7ZS5jdXJyZW50PVtzLG0scC5zdHlsZVNoZWV0LHAuc3R5bGlzLHQseSxnLGNdfX1cInByb2R1Y3Rpb25cIiE9PXByb2Nlc3MuZW52Lk5PREVfRU5WJiZ0LnVzZURlYnVnVmFsdWUmJnQudXNlRGVidWdWYWx1ZShnKSxcInByb2R1Y3Rpb25cIiE9PXByb2Nlc3MuZW52Lk5PREVfRU5WJiZvLndhcm5Ub29NYW55Q2xhc3NlcyYmby53YXJuVG9vTWFueUNsYXNzZXMoZyk7Y29uc3Qgdj15LmFzfHxoLFM9ZnVuY3Rpb24odCxuLG8scyl7Y29uc3Qgcj17fTtmb3IoY29uc3QgaSBpbiB0KXZvaWQgMD09PXRbaV18fFwiJFwiPT09aVswXXx8XCJhc1wiPT09aXx8XCJ0aGVtZVwiPT09aSYmdC50aGVtZT09PW98fChcImZvcndhcmRlZEFzXCI9PT1pP3IuYXM9dC5mb3J3YXJkZWRBczpzJiYhcyhpLG4pfHwocltpXT10W2ldLHN8fFwiZGV2ZWxvcG1lbnRcIiE9PXByb2Nlc3MuZW52Lk5PREVfRU5WfHxlKGkpfHwobHR8fChsdD1uZXcgU2V0KSkuaGFzKGkpfHwhTChuKXx8bi5pbmNsdWRlcyhcIi1cIil8fChsdC5hZGQoaSksY29uc29sZS53YXJuKGBzdHlsZWQtY29tcG9uZW50czogaXQgbG9va3MgbGlrZSBhbiB1bmtub3duIHByb3AgXCIke2l9XCIgaXMgYmVpbmcgc2VudCB0aHJvdWdoIHRvIHRoZSBET00sIHdoaWNoIHdpbGwgbGlrZWx5IHRyaWdnZXIgYSBSZWFjdCBjb25zb2xlIGVycm9yLiBJZiB5b3Ugd291bGQgbGlrZSBhdXRvbWF0aWMgZmlsdGVyaW5nIG9mIHVua25vd24gcHJvcHMsIHlvdSBjYW4gb3B0LWludG8gdGhhdCBiZWhhdmlvciB2aWEgXFxgPFN0eWxlU2hlZXRNYW5hZ2VyIHNob3VsZEZvcndhcmRQcm9wPXsuLi59PlxcYCAoY29ubmVjdCBhbiBBUEkgbGlrZSBcXGBAZW1vdGlvbi9pcy1wcm9wLXZhbGlkXFxgKSBvciBjb25zaWRlciB1c2luZyB0cmFuc2llbnQgcHJvcHMgKFxcYCRcXGAgcHJlZml4IGZvciBhdXRvbWF0aWMgZmlsdGVyaW5nLilgKSkpKTtyZXR1cm4gcn0oeSx2LG0sZik7bGV0IGI9YWUobCx1KTtyZXR1cm4gZyYmKGIrPVwiIFwiK2cpLHkuY2xhc3NOYW1lJiYoYis9XCIgXCIreS5jbGFzc05hbWUpLFNbTCh2KSYmdi5pbmNsdWRlcyhcIi1cIik/XCJjbGFzc1wiOlwiY2xhc3NOYW1lXCJdPWIsciYmKFMucmVmPXIpLG4odixTKX0oZyxvLHMpfXkuZGlzcGxheU5hbWU9aDtsZXQgZz10LmZvcndhcmRSZWYoeSk7cmV0dXJuIGcuYXR0cnM9cCxnLmNvbXBvbmVudFN0eWxlPW0sZy5kaXNwbGF5TmFtZT1oLGcuc2hvdWxkRm9yd2FyZFByb3A9ZixnLmZvbGRlZENvbXBvbmVudElkcz1pP2FlKGMuZm9sZGVkQ29tcG9uZW50SWRzLGMuc3R5bGVkQ29tcG9uZW50SWQpOlwiXCIsZy5zdHlsZWRDb21wb25lbnRJZD1kLGcudGFyZ2V0PWk/Yy50YXJnZXQ6byxPYmplY3QuZGVmaW5lUHJvcGVydHkoZyxcImRlZmF1bHRQcm9wc1wiLHtnZXQoKXtyZXR1cm4gdGhpcy5fZm9sZGVkRGVmYXVsdFByb3BzfSxzZXQoZSl7dGhpcy5fZm9sZGVkRGVmYXVsdFByb3BzPWk/ZnVuY3Rpb24oZSwuLi50KXtmb3IoY29uc3QgbiBvZiB0KWhlKGUsbiwhMCk7cmV0dXJuIGV9KHt9LGMuZGVmYXVsdFByb3BzLGUpOmV9fSksXCJwcm9kdWN0aW9uXCIhPT1wcm9jZXNzLmVudi5OT0RFX0VOViYmKF8oaCxkKSxnLndhcm5Ub29NYW55Q2xhc3Nlcz0oKGUsdCk9PntsZXQgbj17fSxvPSExO3JldHVybiBzPT57IW8mJihuW3NdPSEwLE9iamVjdC5rZXlzKG4pLmxlbmd0aD49MjAwKSYmKGNvbnNvbGUud2FybihgT3ZlciAyMDAgY2xhc3NlcyB3ZXJlIGdlbmVyYXRlZCBmb3IgY29tcG9uZW50ICR7ZX0ke3Q/YCB3aXRoIHRoZSBpZCBvZiBcIiR7dH1cImA6XCJcIn0uXFxuQ29uc2lkZXIgdXNpbmcgdGhlIGF0dHJzIG1ldGhvZCwgdG9nZXRoZXIgd2l0aCBhIHN0eWxlIG9iamVjdCBmb3IgZnJlcXVlbnRseSBjaGFuZ2VkIHN0eWxlcy5cXG5FeGFtcGxlOlxcbiAgY29uc3QgQ29tcG9uZW50ID0gc3R5bGVkLmRpdi5hdHRycyhwcm9wcyA9PiAoe1xcbiAgICBzdHlsZToge1xcbiAgICAgIGJhY2tncm91bmQ6IHByb3BzLmJhY2tncm91bmQsXFxuICAgIH0sXFxuICB9KSlcXGB3aWR0aDogMTAwJTtcXGBcXG5cXG4gIDxDb21wb25lbnQgLz5gKSxvPSEwLG49e30pfX0pKGgsZCkpLGRlKGcsKCk9PmAuJHtnLnN0eWxlZENvbXBvbmVudElkfWApLGEmJnNlKGcsbyx7YXR0cnM6ITAsY29tcG9uZW50U3R5bGU6ITAsZGlzcGxheU5hbWU6ITAsZm9sZGVkQ29tcG9uZW50SWRzOiEwLHNob3VsZEZvcndhcmRQcm9wOiEwLHN0eWxlZENvbXBvbmVudElkOiEwLHRhcmdldDohMH0pLGd9dmFyIGh0PW5ldyBTZXQoW1wiYVwiLFwiYWJiclwiLFwiYWRkcmVzc1wiLFwiYXJlYVwiLFwiYXJ0aWNsZVwiLFwiYXNpZGVcIixcImF1ZGlvXCIsXCJiXCIsXCJiZGlcIixcImJkb1wiLFwiYmxvY2txdW90ZVwiLFwiYm9keVwiLFwiYnV0dG9uXCIsXCJiclwiLFwiY2FudmFzXCIsXCJjYXB0aW9uXCIsXCJjaXRlXCIsXCJjb2RlXCIsXCJjb2xcIixcImNvbGdyb3VwXCIsXCJkYXRhXCIsXCJkYXRhbGlzdFwiLFwiZGRcIixcImRlbFwiLFwiZGV0YWlsc1wiLFwiZGZuXCIsXCJkaWFsb2dcIixcImRpdlwiLFwiZGxcIixcImR0XCIsXCJlbVwiLFwiZW1iZWRcIixcImZpZWxkc2V0XCIsXCJmaWdjYXB0aW9uXCIsXCJmaWd1cmVcIixcImZvb3RlclwiLFwiZm9ybVwiLFwiaDFcIixcImgyXCIsXCJoM1wiLFwiaDRcIixcImg1XCIsXCJoNlwiLFwiaGVhZGVyXCIsXCJoZ3JvdXBcIixcImhyXCIsXCJodG1sXCIsXCJpXCIsXCJpZnJhbWVcIixcImltZ1wiLFwiaW5wdXRcIixcImluc1wiLFwia2JkXCIsXCJsYWJlbFwiLFwibGVnZW5kXCIsXCJsaVwiLFwibWFpblwiLFwibWFwXCIsXCJtYXJrXCIsXCJtZW51XCIsXCJtZXRlclwiLFwibmF2XCIsXCJvYmplY3RcIixcIm9sXCIsXCJvcHRncm91cFwiLFwib3B0aW9uXCIsXCJvdXRwdXRcIixcInBcIixcInBpY3R1cmVcIixcInByZVwiLFwicHJvZ3Jlc3NcIixcInFcIixcInJwXCIsXCJydFwiLFwicnVieVwiLFwic1wiLFwic2FtcFwiLFwic2VhcmNoXCIsXCJzZWN0aW9uXCIsXCJzZWxlY3RcIixcInNsb3RcIixcInNtYWxsXCIsXCJzcGFuXCIsXCJzdHJvbmdcIixcInN1YlwiLFwic3VtbWFyeVwiLFwic3VwXCIsXCJ0YWJsZVwiLFwidGJvZHlcIixcInRkXCIsXCJ0ZW1wbGF0ZVwiLFwidGV4dGFyZWFcIixcInRmb290XCIsXCJ0aFwiLFwidGhlYWRcIixcInRpbWVcIixcInRyXCIsXCJ1XCIsXCJ1bFwiLFwidmFyXCIsXCJ2aWRlb1wiLFwid2JyXCIsXCJjaXJjbGVcIixcImNsaXBQYXRoXCIsXCJkZWZzXCIsXCJlbGxpcHNlXCIsXCJmZUJsZW5kXCIsXCJmZUNvbG9yTWF0cml4XCIsXCJmZUNvbXBvbmVudFRyYW5zZmVyXCIsXCJmZUNvbXBvc2l0ZVwiLFwiZmVDb252b2x2ZU1hdHJpeFwiLFwiZmVEaWZmdXNlTGlnaHRpbmdcIixcImZlRGlzcGxhY2VtZW50TWFwXCIsXCJmZURpc3RhbnRMaWdodFwiLFwiZmVEcm9wU2hhZG93XCIsXCJmZUZsb29kXCIsXCJmZUZ1bmNBXCIsXCJmZUZ1bmNCXCIsXCJmZUZ1bmNHXCIsXCJmZUZ1bmNSXCIsXCJmZUdhdXNzaWFuQmx1clwiLFwiZmVJbWFnZVwiLFwiZmVNZXJnZVwiLFwiZmVNZXJnZU5vZGVcIixcImZlTW9ycGhvbG9neVwiLFwiZmVPZmZzZXRcIixcImZlUG9pbnRMaWdodFwiLFwiZmVTcGVjdWxhckxpZ2h0aW5nXCIsXCJmZVNwb3RMaWdodFwiLFwiZmVUaWxlXCIsXCJmZVR1cmJ1bGVuY2VcIixcImZpbHRlclwiLFwiZm9yZWlnbk9iamVjdFwiLFwiZ1wiLFwiaW1hZ2VcIixcImxpbmVcIixcImxpbmVhckdyYWRpZW50XCIsXCJtYXJrZXJcIixcIm1hc2tcIixcInBhdGhcIixcInBhdHRlcm5cIixcInBvbHlnb25cIixcInBvbHlsaW5lXCIsXCJyYWRpYWxHcmFkaWVudFwiLFwicmVjdFwiLFwic3RvcFwiLFwic3ZnXCIsXCJzd2l0Y2hcIixcInN5bWJvbFwiLFwidGV4dFwiLFwidGV4dFBhdGhcIixcInRzcGFuXCIsXCJ1c2VcIl0pO2Z1bmN0aW9uIGR0KGUsdCl7Y29uc3Qgbj1bZVswXV07Zm9yKGxldCBvPTAscz10Lmxlbmd0aDtvPHM7bys9MSluLnB1c2godFtvXSxlW28rMV0pO3JldHVybiBufWNvbnN0IHB0PWU9PihJZS5hZGQoZSksZSk7ZnVuY3Rpb24gZnQoZSwuLi50KXtpZihyZShlKXx8dWUoZSkpcmV0dXJuIHB0KFdlKGR0KEksW2UsLi4udF0pKSk7Y29uc3Qgbj1lO3JldHVybiAwPT09dC5sZW5ndGgmJjE9PT1uLmxlbmd0aCYmXCJzdHJpbmdcIj09dHlwZW9mIG5bMF0/V2Uobik6cHQoV2UoZHQobix0KSkpfWZ1bmN0aW9uIG10KGUsdCxuPSQpe2lmKCF0KXRocm93IHYoMSx0KTtjb25zdCBvPShvLC4uLnMpPT5lKHQsbixmdChvLC4uLnMpKTtyZXR1cm4gby5hdHRycz1vPT5tdChlLHQsT2JqZWN0LmFzc2lnbihPYmplY3QuYXNzaWduKHt9LG4pLHthdHRyczpBcnJheS5wcm90b3R5cGUuY29uY2F0KG4uYXR0cnMsbykuZmlsdGVyKEJvb2xlYW4pfSkpLG8ud2l0aENvbmZpZz1vPT5tdChlLHQsT2JqZWN0LmFzc2lnbihPYmplY3QuYXNzaWduKHt9LG4pLG8pKSxvfWNvbnN0IHl0PWU9Pm10KHV0LGUpLGd0PXl0O2h0LmZvckVhY2goZT0+e2d0W2VdPXl0KGUpfSk7Y2xhc3MgdnR7Y29uc3RydWN0b3IoZSx0KXt0aGlzLmluc3RhbmNlUnVsZXM9bmV3IE1hcCx0aGlzLnJ1bGVzPWUsdGhpcy5jb21wb25lbnRJZD10LHRoaXMuaXNTdGF0aWM9ZnVuY3Rpb24oZSl7Zm9yKGxldCB0PTA7dDxlLmxlbmd0aDt0Kz0xKXtjb25zdCBuPWVbdF07aWYocmUobikmJiFjZShuKSlyZXR1cm4hMX1yZXR1cm4hMH0oZSksX2UucmVnaXN0ZXJJZCh0aGlzLmNvbXBvbmVudElkKX1yZW1vdmVTdHlsZXMoZSx0KXt0aGlzLmluc3RhbmNlUnVsZXMuZGVsZXRlKGUpLHRoaXMucmVidWlsZEdyb3VwKHQpfXJlbmRlclN0eWxlcyhlLHQsbixvKXtjb25zdCBzPXRoaXMuY29tcG9uZW50SWQ7aWYodGhpcy5pc1N0YXRpYyl7aWYobi5oYXNOYW1lRm9ySWQocyxzK2UpKXRoaXMuaW5zdGFuY2VSdWxlcy5oYXMoZSl8fHRoaXMuY29tcHV0ZVJ1bGVzKGUsdCxuLG8pO2Vsc2V7Y29uc3Qgcj10aGlzLmNvbXB1dGVSdWxlcyhlLHQsbixvKTtuLmluc2VydFJ1bGVzKHMsci5uYW1lLHIucnVsZXMpfXJldHVybn1jb25zdCByPXRoaXMuaW5zdGFuY2VSdWxlcy5nZXQoZSk7aWYodGhpcy5jb21wdXRlUnVsZXMoZSx0LG4sbyksIW4uc2VydmVyJiZyKXtjb25zdCB0PXIucnVsZXMsbj10aGlzLmluc3RhbmNlUnVsZXMuZ2V0KGUpLnJ1bGVzO2lmKHQubGVuZ3RoPT09bi5sZW5ndGgpe2xldCBlPSEwO2ZvcihsZXQgbz0wO288dC5sZW5ndGg7bysrKWlmKHRbb10hPT1uW29dKXtlPSExO2JyZWFrfWlmKGUpcmV0dXJufX10aGlzLnJlYnVpbGRHcm91cChuKX1jb21wdXRlUnVsZXMoZSx0LG4sbyl7Y29uc3Qgcz1sZShXZSh0aGlzLnJ1bGVzLHQsbixvKSkscj17bmFtZTp0aGlzLmNvbXBvbmVudElkK2UscnVsZXM6byhzLFwiXCIpfTtyZXR1cm4gdGhpcy5pbnN0YW5jZVJ1bGVzLnNldChlLHIpLHJ9cmVidWlsZEdyb3VwKGUpe2NvbnN0IHQ9dGhpcy5jb21wb25lbnRJZDtlLmNsZWFyUnVsZXModCk7Zm9yKGNvbnN0IG4gb2YgdGhpcy5pbnN0YW5jZVJ1bGVzLnZhbHVlcygpKWUuaW5zZXJ0UnVsZXModCxuLm5hbWUsbi5ydWxlcyl9fWZ1bmN0aW9uIFN0KGUsLi4ubil7Y29uc3Qgbz1mdChlLC4uLm4pLHM9YHNjLWdsb2JhbC0ke3ooSlNPTi5zdHJpbmdpZnkobykpfWAscj1uZXcgdnQobyxzKTtcInByb2R1Y3Rpb25cIiE9PXByb2Nlc3MuZW52Lk5PREVfRU5WJiZfKHMpO2NvbnN0IGk9ZT0+e2NvbnN0IG49ZXQoKSxpPXQudXNlQ29udGV4dChudCk7bGV0IGE7e2NvbnN0IGU9dC51c2VSZWYobnVsbCk7bnVsbD09PWUuY3VycmVudCYmKGUuY3VycmVudD1uLnN0eWxlU2hlZXQuYWxsb2NhdGVHU0luc3RhbmNlKHMpKSxhPWUuY3VycmVudH1cInByb2R1Y3Rpb25cIiE9PXByb2Nlc3MuZW52Lk5PREVfRU5WJiZ0LkNoaWxkcmVuLmNvdW50KGUuY2hpbGRyZW4pJiZjb25zb2xlLndhcm4oYFRoZSBnbG9iYWwgc3R5bGUgY29tcG9uZW50ICR7c30gd2FzIGdpdmVuIGNoaWxkIEpTWC4gY3JlYXRlR2xvYmFsU3R5bGUgZG9lcyBub3QgcmVuZGVyIGNoaWxkcmVuLmApLFwicHJvZHVjdGlvblwiIT09cHJvY2Vzcy5lbnYuTk9ERV9FTlYmJm8uc29tZShlPT5cInN0cmluZ1wiPT10eXBlb2YgZSYmLTEhPT1lLmluZGV4T2YoXCJAaW1wb3J0XCIpKSYmY29uc29sZS53YXJuKFwiUGxlYXNlIGRvIG5vdCB1c2UgQGltcG9ydCBDU1Mgc3ludGF4IGluIGNyZWF0ZUdsb2JhbFN0eWxlIGF0IHRoaXMgdGltZSwgYXMgdGhlIENTU09NIEFQSXMgd2UgdXNlIGluIHByb2R1Y3Rpb24gZG8gbm90IGhhbmRsZSBpdCB3ZWxsLiBJbnN0ZWFkLCB3ZSByZWNvbW1lbmQgdXNpbmcgYSBsaWJyYXJ5IHN1Y2ggYXMgcmVhY3QtaGVsbWV0IHRvIGluamVjdCBhIHR5cGljYWwgPGxpbms+IG1ldGEgdGFnIHRvIHRoZSBzdHlsZXNoZWV0LCBvciBzaW1wbHkgZW1iZWRkaW5nIGl0IG1hbnVhbGx5IGluIHlvdXIgaW5kZXguaHRtbCA8aGVhZD4gc2VjdGlvbiBmb3IgYSBzaW1wbGVyIGFwcC5cIiksbi5zdHlsZVNoZWV0LnNlcnZlciYmYyhhLGUsbi5zdHlsZVNoZWV0LGksbi5zdHlsaXMpO3tjb25zdCBvPXIuaXNTdGF0aWM/W2Esbi5zdHlsZVNoZWV0LHJdOlthLGUsbi5zdHlsZVNoZWV0LGksbi5zdHlsaXMscl0sbD10LnVzZVJlZihyKTt0LnVzZUxheW91dEVmZmVjdCgoKT0+e24uc3R5bGVTaGVldC5zZXJ2ZXJ8fChsLmN1cnJlbnQhPT1yJiYobi5zdHlsZVNoZWV0LmNsZWFyUnVsZXMocyksbC5jdXJyZW50PXIpLGMoYSxlLG4uc3R5bGVTaGVldCxpLG4uc3R5bGlzKSl9LG8pLHQudXNlTGF5b3V0RWZmZWN0KCgpPT4oKT0+e24uc3R5bGVTaGVldC5zZXJ2ZXJ8fHIucmVtb3ZlU3R5bGVzKGEsbi5zdHlsZVNoZWV0KX0sW2Esbi5zdHlsZVNoZWV0LHJdKX1yZXR1cm4gbi5zdHlsZVNoZWV0LnNlcnZlciYmci5pbnN0YW5jZVJ1bGVzLmRlbGV0ZShhKSxudWxsfTtmdW5jdGlvbiBjKGUsdCxuLG8scyl7aWYoci5pc1N0YXRpYylyLnJlbmRlclN0eWxlcyhlLHksbixzKTtlbHNle2NvbnN0IGM9T2JqZWN0LmFzc2lnbihPYmplY3QuYXNzaWduKHt9LHQpLHt0aGVtZTpSKHQsbyxpLmRlZmF1bHRQcm9wcyl9KTtyLnJlbmRlclN0eWxlcyhlLGMsbixzKX19cmV0dXJuIHQubWVtbyhpKX1mdW5jdGlvbiBidChlLHQsbixvLHMpe2Zvcihjb25zdCByIGluIGUpe2NvbnN0IGk9ZVtyXSxjPXM/cytcIi1cIityOnI7aWYoXCJvYmplY3RcIj09dHlwZW9mIGkmJm51bGwhPT1pKXtjb25zdCBlPXt9O2J0KGksdCxlLG8sYyksbltyXT1lfWVsc2UgbltyXT1vKGMsaSxyKX19ZnVuY3Rpb24gd3QoZSx0LG4sbyl7bGV0IHM9XCJcIjtmb3IoY29uc3QgciBpbiBlKXtjb25zdCBpPWVbcl0sYz10W3JdLGE9bz9vK1wiLVwiK3I6cjtcIm9iamVjdFwiPT10eXBlb2YgaSYmbnVsbCE9PWk/XCJvYmplY3RcIj09dHlwZW9mIGMmJm51bGwhPT1jJiYocys9d3QoaSxjLG4sYSkpOnZvaWQgMCE9PWMmJlwiZnVuY3Rpb25cIiE9dHlwZW9mIGMmJihzKz1cIi0tXCIrbithK1wiOlwiK2MrXCI7XCIpfXJldHVybiBzfWZ1bmN0aW9uIE50KGUsdCl7dmFyIG4sbztjb25zdCBzPShudWxsIT09KG49bnVsbD09dD92b2lkIDA6dC5wcmVmaXgpJiZ2b2lkIDAhPT1uP246XCJzY1wiKStcIi1cIixyPW51bGwhPT0obz1udWxsPT10P3ZvaWQgMDp0LnNlbGVjdG9yKSYmdm9pZCAwIT09bz9vOlwiOnJvb3RcIixpPWZ1bmN0aW9uKGUsdCl7Y29uc3Qgbj17fTtyZXR1cm4gYnQoZSx0LG4sZT0+XCItLVwiK3QrZSksbn0oZSxzKSxjPWZ1bmN0aW9uKGUsdCl7Y29uc3Qgbj17fTtyZXR1cm4gYnQoZSx0LG4sKGUsbik9PntpZihcInByb2R1Y3Rpb25cIiE9PXByb2Nlc3MuZW52Lk5PREVfRU5WKXtjb25zdCB0PVN0cmluZyhuKTtsZXQgbz0wO2ZvcihsZXQgZT0wO2U8dC5sZW5ndGgmJig0MD09PXQuY2hhckNvZGVBdChlKT9vKys6NDE9PT10LmNoYXJDb2RlQXQoZSkmJm8tLSwhKG88MCkpO2UrKyk7MCE9PW8mJmNvbnNvbGUud2FybihgY3JlYXRlVGhlbWU6IHZhbHVlIFwiJHt0fVwiIGF0IFwiJHtlfVwiIGNvbnRhaW5zIHVuYmFsYW5jZWQgcGFyZW50aGVzZXMgYW5kIG1heSBicmVhayB0aGUgdmFyKCkgZmFsbGJhY2tgKX1yZXR1cm5cInZhcigtLVwiK3QrZStcIiwgXCIrbitcIilcIn0pLG59KGUscyksYT1TdGBcbiAgICAke3J9IHtcbiAgICAgICR7dD0+d3QoZSx0LnRoZW1lLHMpfVxuICAgIH1cbiAgYDtyZXR1cm4gT2JqZWN0LmFzc2lnbihjLHtHbG9iYWxTdHlsZTphLHJhdzplLHZhcnM6aSxyZXNvbHZlKHQpe2lmKCFkKXRocm93IG5ldyBFcnJvcihcImNyZWF0ZVRoZW1lLnJlc29sdmUoKSBpcyBjbGllbnQtb25seVwiKTtjb25zdCBuPW51bGwhPXQ/dDpkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQ7cmV0dXJuIGZ1bmN0aW9uKGUsdCxuKXtjb25zdCBvPXt9O3JldHVybiBidChlLHQsbywoZSxvKT0+bi5nZXRQcm9wZXJ0eVZhbHVlKFwiLS1cIit0K2UpLnRyaW0oKXx8byksb30oZSxzLGdldENvbXB1dGVkU3R5bGUobikpfX0pfXZhciBDdDtjbGFzcyBPdHtjb25zdHJ1Y3RvcihlLHQpe3RoaXNbQ3RdPSEwLHRoaXMuaW5qZWN0PShlLHQ9S2UpPT57Y29uc3Qgbj10aGlzLmdldE5hbWUodCk7aWYoIWUuaGFzTmFtZUZvcklkKHRoaXMuaWQsbikpe2NvbnN0IG89dCh0aGlzLnJ1bGVzLG4sXCJAa2V5ZnJhbWVzXCIpO2UuaW5zZXJ0UnVsZXModGhpcy5pZCxuLG8pfX0sdGhpcy5uYW1lPWUsdGhpcy5pZD1tK2UsdGhpcy5ydWxlcz10LEModGhpcy5pZCksZGUodGhpcywoKT0+e3Rocm93IHYoMTIsU3RyaW5nKHRoaXMubmFtZSkpfSl9Z2V0TmFtZShlPUtlKXtyZXR1cm4gZS5oYXNoP3RoaXMubmFtZStWKCtlLmhhc2g+Pj4wKTp0aGlzLm5hbWV9fWZ1bmN0aW9uIEV0KGUsLi4udCl7XCJwcm9kdWN0aW9uXCIhPT1wcm9jZXNzLmVudi5OT0RFX0VOViYmXCJ1bmRlZmluZWRcIiE9dHlwZW9mIG5hdmlnYXRvciYmXCJSZWFjdE5hdGl2ZVwiPT09bmF2aWdhdG9yLnByb2R1Y3QmJmNvbnNvbGUud2FybihcImBrZXlmcmFtZXNgIGNhbm5vdCBiZSB1c2VkIG9uIFJlYWN0TmF0aXZlLCBvbmx5IG9uIHRoZSB3ZWIuIFRvIGRvIGFuaW1hdGlvbiBpbiBSZWFjdE5hdGl2ZSBwbGVhc2UgdXNlIEFuaW1hdGVkLlwiKTtjb25zdCBuPWxlKGZ0KGUsLi4udCkpLG89eihuKTtyZXR1cm4gbmV3IE90KG8sbil9ZnVuY3Rpb24gQXQoZSl7Y29uc3Qgbj10LmZvcndhcmRSZWYoKG4sbyk9Pntjb25zdCBzPVIobix0LnVzZUNvbnRleHQobnQpLGUuZGVmYXVsdFByb3BzKTtyZXR1cm5cInByb2R1Y3Rpb25cIiE9PXByb2Nlc3MuZW52Lk5PREVfRU5WJiZ2b2lkIDA9PT1zJiZjb25zb2xlLndhcm4oYFt3aXRoVGhlbWVdIFlvdSBhcmUgbm90IHVzaW5nIGEgVGhlbWVQcm92aWRlciBub3IgcGFzc2luZyBhIHRoZW1lIHByb3Agb3IgYSB0aGVtZSBpbiBkZWZhdWx0UHJvcHMgaW4gY29tcG9uZW50IGNsYXNzIFwiJHtXKGUpfVwiYCksdC5jcmVhdGVFbGVtZW50KGUsT2JqZWN0LmFzc2lnbihPYmplY3QuYXNzaWduKHt9LG4pLHt0aGVtZTpzLHJlZjpvfSkpfSk7cmV0dXJuIG4uZGlzcGxheU5hbWU9YFdpdGhUaGVtZSgke1coZSl9KWAsc2UobixlKX1DdD1UZTtjbGFzcyBQdHtjb25zdHJ1Y3Rvcih7bm9uY2U6ZX09e30pe3RoaXMuX2VtaXRTaGVldENTUz0oKT0+e2NvbnN0IGU9dGhpcy5pbnN0YW5jZS50b1N0cmluZygpO2lmKCFlKXJldHVyblwiXCI7Y29uc3QgdD10aGlzLmluc3RhbmNlLm9wdGlvbnMubm9uY2V8fE5lKCk7cmV0dXJuYDxzdHlsZSAke2xlKFt0JiZgbm9uY2U9XCIke3R9XCJgLGAke2N9PVwidHJ1ZVwiYCxgJHtsfT1cIiR7dX1cImBdLmZpbHRlcihCb29sZWFuKSxcIiBcIil9PiR7ZX08L3N0eWxlPmB9LHRoaXMuZ2V0U3R5bGVUYWdzPSgpPT57aWYodGhpcy5zZWFsZWQpdGhyb3cgdigyKTtyZXR1cm4gdGhpcy5fZW1pdFNoZWV0Q1NTKCl9LHRoaXMuZ2V0U3R5bGVFbGVtZW50PSgpPT57aWYodGhpcy5zZWFsZWQpdGhyb3cgdigyKTtjb25zdCBlPXRoaXMuaW5zdGFuY2UudG9TdHJpbmcoKTtpZighZSlyZXR1cm5bXTtjb25zdCBuPXtbY106XCJcIixbbF06dSxkYW5nZXJvdXNseVNldElubmVySFRNTDp7X19odG1sOmV9fSxvPXRoaXMuaW5zdGFuY2Uub3B0aW9ucy5ub25jZXx8TmUoKTtyZXR1cm4gbyYmKG4ubm9uY2U9byksW3QuY3JlYXRlRWxlbWVudChcInN0eWxlXCIsT2JqZWN0LmFzc2lnbih7fSxuLHtrZXk6XCJzYy0wLTBcIn0pKV19LHRoaXMuc2VhbD0oKT0+e3RoaXMuc2VhbGVkPSEwfSx0aGlzLmluc3RhbmNlPW5ldyBfZSh7aXNTZXJ2ZXI6ITAsbm9uY2U6ZX0pLHRoaXMuc2VhbGVkPSExfWNvbGxlY3RTdHlsZXMoZSl7aWYodGhpcy5zZWFsZWQpdGhyb3cgdigyKTtyZXR1cm4gdC5jcmVhdGVFbGVtZW50KHR0LHtzaGVldDp0aGlzLmluc3RhbmNlfSxlKX1pbnRlcmxlYXZlV2l0aE5vZGVTdHJlYW0oZSl7dGhyb3cgdigzKX19Y29uc3QgX3Q9e1N0eWxlU2hlZXQ6X2UsbWFpblNoZWV0OlhlfTtcInByb2R1Y3Rpb25cIiE9PXByb2Nlc3MuZW52Lk5PREVfRU5WJiZcInVuZGVmaW5lZFwiIT10eXBlb2YgbmF2aWdhdG9yJiZcIlJlYWN0TmF0aXZlXCI9PT1uYXZpZ2F0b3IucHJvZHVjdCYmY29uc29sZS53YXJuKFwiSXQgbG9va3MgbGlrZSB5b3UndmUgaW1wb3J0ZWQgJ3N0eWxlZC1jb21wb25lbnRzJyBvbiBSZWFjdCBOYXRpdmUuXFxuUGVyaGFwcyB5b3UncmUgbG9va2luZyB0byBpbXBvcnQgJ3N0eWxlZC1jb21wb25lbnRzL25hdGl2ZSc/XFxuUmVhZCBtb3JlIGFib3V0IHRoaXMgYXQgaHR0cHM6Ly9zdHlsZWQtY29tcG9uZW50cy5jb20vZG9jcy9iYXNpY3MjcmVhY3QtbmF0aXZlXCIpO2NvbnN0IEl0PWBfX3NjLSR7Y31fX2A7XCJwcm9kdWN0aW9uXCIhPT1wcm9jZXNzLmVudi5OT0RFX0VOViYmXCJ0ZXN0XCIhPT1wcm9jZXNzLmVudi5OT0RFX0VOViYmXCJ1bmRlZmluZWRcIiE9dHlwZW9mIHdpbmRvdyYmKHdpbmRvd1tJdF18fCh3aW5kb3dbSXRdPTApLDE9PT13aW5kb3dbSXRdJiZjb25zb2xlLndhcm4oXCJJdCBsb29rcyBsaWtlIHRoZXJlIGFyZSBzZXZlcmFsIGluc3RhbmNlcyBvZiAnc3R5bGVkLWNvbXBvbmVudHMnIGluaXRpYWxpemVkIGluIHRoaXMgYXBwbGljYXRpb24uIFRoaXMgbWF5IGNhdXNlIGR5bmFtaWMgc3R5bGVzIHRvIG5vdCByZW5kZXIgcHJvcGVybHksIGVycm9ycyBkdXJpbmcgdGhlIHJlaHlkcmF0aW9uIHByb2Nlc3MsIGEgbWlzc2luZyB0aGVtZSBwcm9wLCBhbmQgbWFrZXMgeW91ciBhcHBsaWNhdGlvbiBiaWdnZXIgd2l0aG91dCBnb29kIHJlYXNvbi5cXG5cXG5TZWUgaHR0cHM6Ly9zdHlsZWQtY29tcG9uZW50cy5jb20vZG9jcy9mYXFzI3doeS1hbS1pLWdldHRpbmctYS13YXJuaW5nLWFib3V0LXNldmVyYWwtaW5zdGFuY2VzLW9mLW1vZHVsZS1vbi10aGUtcGFnZSBmb3IgbW9yZSBpbmZvLlwiKSx3aW5kb3dbSXRdKz0xKTtjb25zdCAkdD0vOig/OihmaXJzdCktY2hpbGR8KGxhc3QpLWNoaWxkfChvbmx5KS1jaGlsZHwobnRoLWNoaWxkKVxcKChbXigpXSspXFwpfChudGgtbGFzdC1jaGlsZClcXCgoW14oKV0rKVxcKSkvZyxSdD1gOm5vdChzdHlsZVske2N9XSlgLGp0PWBzdHlsZVske2N9XWA7ZnVuY3Rpb24geHQoZSl7cmV0dXJuLTE9PT1lLmluZGV4T2YoXCItY2hpbGRcIik/ZTooJHQubGFzdEluZGV4PTAsZS5yZXBsYWNlKCR0LChlLHQsbixvLHMscixpLGMpPT50P2A6bnRoLWNoaWxkKDEgb2YgJHtSdH0pYDpuP2A6bnRoLWxhc3QtY2hpbGQoMSBvZiAke1J0fSlgOm8/YDpudGgtY2hpbGQoMSBvZiAke1J0fSk6bnRoLWxhc3QtY2hpbGQoMSBvZiAke1J0fSlgOnM/LTEhPT1yLmluZGV4T2YoXCIgb2YgXCIpP2U6YDpudGgtY2hpbGQoJHtyfSBvZiAke1J0fSlgOi0xIT09Yy5pbmRleE9mKFwiIG9mIFwiKT9lOmA6bnRoLWxhc3QtY2hpbGQoJHtjfSBvZiAke1J0fSlgKSl9ZnVuY3Rpb24gVHQoZSx0KXtpZigtMT09PWUuaW5kZXhPZihcIitcIikpcmV0dXJuO2xldCBuPTAsbz0wO2ZvcihsZXQgcz0wO3M8ZS5sZW5ndGg7cysrKXtjb25zdCByPWUuY2hhckNvZGVBdChzKTtpZig0MD09PXIpbisrO2Vsc2UgaWYoNDE9PT1yKW4tLTtlbHNlIGlmKDkxPT09cilvKys7ZWxzZSBpZig5Mz09PXIpby0tO2Vsc2UgaWYoNDM9PT1yJiYwPT09biYmMD09PW8mJiFIZShlLHMpKXtjb25zdCBuPWUuc3Vic3RyaW5nKDAscyksbz1lLnN1YnN0cmluZyhzKzEpO3QucHVzaChuK1wiK1wiK2p0K1wiK1wiK28pLHQucHVzaChuK1wiK1wiK2p0K1wiK1wiK2p0K1wiK1wiK28pfX19ZnVuY3Rpb24ga3QoZSl7aWYoZS50eXBlPT09cyl7Y29uc3QgdD1lLnByb3BzLG49W107Zm9yKGxldCBlPTA7ZTx0Lmxlbmd0aDtlKyspe2NvbnN0IG89eHQodFtlXSk7bi5wdXNoKG8pLFR0KG8sbil9ZS5wcm9wcz1ufX1leHBvcnR7UHQgYXMgU2VydmVyU3R5bGVTaGVldCxaZSBhcyBTdHlsZVNoZWV0Q29uc3VtZXIsUWUgYXMgU3R5bGVTaGVldENvbnRleHQsdHQgYXMgU3R5bGVTaGVldE1hbmFnZXIsb3QgYXMgVGhlbWVDb25zdW1lcixudCBhcyBUaGVtZUNvbnRleHQscnQgYXMgVGhlbWVQcm92aWRlcixfdCBhcyBfX1BSSVZBVEVfXyxTdCBhcyBjcmVhdGVHbG9iYWxTdHlsZSxOdCBhcyBjcmVhdGVUaGVtZSxmdCBhcyBjc3MsZ3QgYXMgZGVmYXVsdCxjZSBhcyBpc1N0eWxlZENvbXBvbmVudCxFdCBhcyBrZXlmcmFtZXMsZ3QgYXMgc3R5bGVkLGt0IGFzIHN0eWxpc1BsdWdpblJTQyxzdCBhcyB1c2VUaGVtZSx1IGFzIHZlcnNpb24sQXQgYXMgd2l0aFRoZW1lfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXN0eWxlZC1jb21wb25lbnRzLmJyb3dzZXIuZXNtLmpzLm1hcFxuIl0sIm1hcHBpbmdzIjoiOzs7QUFBQSxTQUFTLFFBQVEsSUFBSTtDQUNuQixJQUFJLFFBQVEsT0FBTyxPQUFPLElBQUk7Q0FDOUIsT0FBTyxTQUFVLEtBQUs7RUFDcEIsSUFBSSxNQUFNLFNBQVMsS0FBQSxHQUFXLE1BQU0sT0FBTyxHQUFHLEdBQUc7RUFDakQsT0FBTyxNQUFNO0NBQ2Y7QUFDRjs7O0FDSEEsSUFBSSxrQkFBa0I7QUFFdEIsSUFBSSxjQUE2Qix3QkFBUSxTQUFVLE1BQU07Q0FDdkQsT0FBTyxnQkFBZ0IsS0FBSyxJQUFJLEtBQUssS0FBSyxXQUFXLENBQUMsTUFBTSxPQUV6RCxLQUFLLFdBQVcsQ0FBQyxNQUFNLE9BRXZCLEtBQUssV0FBVyxDQUFDLElBQUk7QUFDMUIsQ0FFQTs7O0FDYkEsSUFBVyxLQUFLO0FBQ2hCLElBQVcsTUFBTTtBQUNqQixJQUFXLFNBQVM7QUFFcEIsSUFBVyxVQUFVO0FBQ3JCLElBQVcsVUFBVTtBQUNyQixJQUFXLGNBQWM7QUFJekIsSUFBVyxTQUFTO0FBS3BCLElBQVcsWUFBWTtBQUN2QixJQUFXLFlBQVk7QUFJdkIsSUFBVyxRQUFROzs7Ozs7O0FDaEJuQixJQUFXLE1BQU0sS0FBSzs7Ozs7QUFNdEIsSUFBVyxPQUFPLE9BQU87Ozs7O0FBTXpCLElBQVcsU0FBUyxPQUFPOzs7Ozs7QUFPM0IsU0FBZ0IsS0FBTSxPQUFPLFFBQVE7Q0FDcEMsT0FBTyxPQUFPLE9BQU8sQ0FBQyxJQUFJLFFBQVksVUFBVSxJQUFLLE9BQU8sT0FBTyxDQUFDLE1BQU0sSUFBSyxPQUFPLE9BQU8sQ0FBQyxNQUFNLElBQUssT0FBTyxPQUFPLENBQUMsTUFBTSxJQUFLLE9BQU8sT0FBTyxDQUFDLElBQUk7QUFDdko7Ozs7O0FBTUEsU0FBZ0IsS0FBTSxPQUFPO0NBQzVCLE9BQU8sTUFBTSxLQUFLO0FBQ25COzs7Ozs7QUFPQSxTQUFnQixNQUFPLE9BQU8sU0FBUztDQUN0QyxRQUFRLFFBQVEsUUFBUSxLQUFLLEtBQUssS0FBSyxNQUFNLEtBQUs7QUFDbkQ7Ozs7Ozs7QUFRQSxTQUFnQixRQUFTLE9BQU8sU0FBUyxhQUFhO0NBQ3JELE9BQU8sTUFBTSxRQUFRLFNBQVMsV0FBVztBQUMxQzs7Ozs7OztBQVFBLFNBQWdCLFFBQVMsT0FBTyxRQUFRLFVBQVU7Q0FDakQsT0FBTyxNQUFNLFFBQVEsUUFBUSxRQUFRO0FBQ3RDOzs7Ozs7QUFPQSxTQUFnQixPQUFRLE9BQU8sT0FBTztDQUNyQyxPQUFPLE1BQU0sV0FBVyxLQUFLLElBQUk7QUFDbEM7Ozs7Ozs7QUFRQSxTQUFnQixPQUFRLE9BQU8sT0FBTyxLQUFLO0NBQzFDLE9BQU8sTUFBTSxNQUFNLE9BQU8sR0FBRztBQUM5Qjs7Ozs7QUFNQSxTQUFnQixPQUFRLE9BQU87Q0FDOUIsT0FBTyxNQUFNO0FBQ2Q7Ozs7O0FBTUEsU0FBZ0IsT0FBUSxPQUFPO0NBQzlCLE9BQU8sTUFBTTtBQUNkOzs7Ozs7QUFPQSxTQUFnQixPQUFRLE9BQU8sT0FBTztDQUNyQyxPQUFPLE1BQU0sS0FBSyxLQUFLLEdBQUc7QUFDM0I7Ozs7OztBQU9BLFNBQWdCLFFBQVMsT0FBTyxVQUFVO0NBQ3pDLE9BQU8sTUFBTSxJQUFJLFFBQVEsQ0FBQyxDQUFDLEtBQUssRUFBRTtBQUNuQzs7Ozs7O0FBT0EsU0FBZ0IsT0FBUSxPQUFPLFNBQVM7Q0FDdkMsT0FBTyxNQUFNLE9BQU8sU0FBVSxPQUFPO0VBQUUsT0FBTyxDQUFDLE1BQU0sT0FBTyxPQUFPO0NBQUUsQ0FBQztBQUN2RTs7O0FDMUhBLElBQVcsT0FBTztBQUNsQixJQUFXLFNBQVM7QUFDcEIsSUFBVyxTQUFTO0FBQ3BCLElBQVcsV0FBVztBQUN0QixJQUFXLFlBQVk7QUFDdkIsSUFBVyxhQUFhOzs7Ozs7Ozs7OztBQVl4QixTQUFnQixLQUFNLE9BQU8sTUFBTSxRQUFRLE1BQU0sT0FBTyxVQUFVLFFBQVEsVUFBVTtDQUNuRixPQUFPO0VBQVE7RUFBYTtFQUFjO0VBQWM7RUFBYTtFQUFpQjtFQUFnQjtFQUFjO0VBQWdCO0VBQVEsUUFBUTtFQUFjO0NBQVE7QUFDM0s7Ozs7OztBQU9BLFNBQWdCLEtBQU0sTUFBTSxPQUFPO0NBQ2xDLE9BQU8sT0FBTyxLQUFLLElBQUksTUFBTSxNQUFNLElBQUksTUFBTSxNQUFNLEdBQUcsS0FBSyxRQUFRLEdBQUcsTUFBTSxFQUFDLFFBQVEsQ0FBQyxLQUFLLE9BQU0sR0FBRyxLQUFLO0FBQzFHOzs7O0FBS0EsU0FBZ0IsS0FBTSxNQUFNO0NBQzNCLE9BQU8sS0FBSyxNQUNYLE9BQU8sS0FBSyxLQUFLLE1BQU0sRUFBQyxVQUFVLENBQUMsSUFBSSxFQUFDLENBQUM7Q0FFMUMsT0FBTyxNQUFNLEtBQUssUUFBUTtBQUMzQjs7OztBQUtBLFNBQWdCLE9BQVE7Q0FDdkIsT0FBTztBQUNSOzs7O0FBS0EsU0FBZ0IsT0FBUTtDQUN2QixZQUFZLFdBQVcsSUFBSSxPQUFPLFlBQVksRUFBRSxRQUFRLElBQUk7Q0FFNUQsSUFBSSxVQUFVLGNBQWMsSUFDM0IsU0FBUyxHQUFHO0NBRWIsT0FBTztBQUNSOzs7O0FBS0EsU0FBZ0IsT0FBUTtDQUN2QixZQUFZLFdBQVcsU0FBUyxPQUFPLFlBQVksVUFBVSxJQUFJO0NBRWpFLElBQUksVUFBVSxjQUFjLElBQzNCLFNBQVMsR0FBRztDQUViLE9BQU87QUFDUjs7OztBQUtBLFNBQWdCLE9BQVE7Q0FDdkIsT0FBTyxPQUFPLFlBQVksUUFBUTtBQUNuQzs7OztBQUtBLFNBQWdCLFFBQVM7Q0FDeEIsT0FBTztBQUNSOzs7Ozs7QUFPQSxTQUFnQixNQUFPLE9BQU8sS0FBSztDQUNsQyxPQUFPLE9BQU8sWUFBWSxPQUFPLEdBQUc7QUFDckM7Ozs7O0FBTUEsU0FBZ0IsTUFBTyxNQUFNO0NBQzVCLFFBQVEsTUFBUjtFQUVDLEtBQUs7RUFBRyxLQUFLO0VBQUcsS0FBSztFQUFJLEtBQUs7RUFBSSxLQUFLLElBQ3RDLE9BQU87RUFFUixLQUFLO0VBQUksS0FBSztFQUFJLEtBQUs7RUFBSSxLQUFLO0VBQUksS0FBSztFQUFJLEtBQUs7RUFBSSxLQUFLO0VBRTNELEtBQUs7RUFBSSxLQUFLO0VBQUssS0FBSyxLQUN2QixPQUFPO0VBRVIsS0FBSyxJQUNKLE9BQU87RUFFUixLQUFLO0VBQUksS0FBSztFQUFJLEtBQUs7RUFBSSxLQUFLLElBQy9CLE9BQU87RUFFUixLQUFLO0VBQUksS0FBSyxJQUNiLE9BQU87Q0FDVDtDQUVBLE9BQU87QUFDUjs7Ozs7QUFNQSxTQUFnQixNQUFPLE9BQU87Q0FDN0IsT0FBTyxPQUFPLFNBQVMsR0FBRyxTQUFTLE9BQU8sYUFBYSxLQUFLLEdBQUcsV0FBVyxHQUFHLENBQUM7QUFDL0U7Ozs7O0FBTUEsU0FBZ0IsUUFBUyxPQUFPO0NBQy9CLE9BQU8sYUFBYSxJQUFJO0FBQ3pCOzs7OztBQU1BLFNBQWdCLFFBQVMsTUFBTTtDQUM5QixPQUFPLEtBQUssTUFBTSxXQUFXLEdBQUcsVUFBVSxTQUFTLEtBQUssT0FBTyxJQUFJLFNBQVMsS0FBSyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUM7QUFDbkc7Ozs7O0FBY0EsU0FBZ0IsV0FBWSxNQUFNO0NBQ2pDLE9BQU8sWUFBWSxLQUFLLEdBQ3ZCLElBQUksWUFBWSxJQUNmLEtBQUs7TUFFTDtDQUVGLE9BQU8sTUFBTSxJQUFJLElBQUksS0FBSyxNQUFNLFNBQVMsSUFBSSxJQUFJLEtBQUs7QUFDdkQ7Ozs7OztBQXdCQSxTQUFnQixTQUFVLE9BQU8sT0FBTztDQUN2QyxPQUFPLEVBQUUsU0FBUyxLQUFLLEdBRXRCLElBQUksWUFBWSxNQUFNLFlBQVksT0FBUSxZQUFZLE1BQU0sWUFBWSxNQUFRLFlBQVksTUFBTSxZQUFZLElBQzdHO0NBRUYsT0FBTyxNQUFNLE9BQU8sTUFBTSxLQUFLLFFBQVEsS0FBSyxLQUFLLEtBQUssTUFBTSxLQUFLLEtBQUssR0FBRztBQUMxRTs7Ozs7QUFNQSxTQUFnQixVQUFXLE1BQU07Q0FDaEMsT0FBTyxLQUFLLEdBQ1gsUUFBUSxXQUFSO0VBRUMsS0FBSyxNQUNKLE9BQU87RUFFUixLQUFLO0VBQUksS0FBSztHQUNiLElBQUksU0FBUyxNQUFNLFNBQVMsSUFDM0IsVUFBVSxTQUFTO0dBQ3BCO0VBRUQsS0FBSztHQUNKLElBQUksU0FBUyxJQUNaLFVBQVUsSUFBSTtHQUNmO0VBRUQsS0FBSztHQUNKLEtBQUs7R0FDTDtDQUNGO0NBRUQsT0FBTztBQUNSOzs7Ozs7QUFPQSxTQUFnQixVQUFXLE1BQU0sT0FBTztDQUN2QyxPQUFPLEtBQUssR0FFWCxJQUFJLE9BQU8sY0FBYyxJQUN4QjtNQUVJLElBQUksT0FBTyxjQUFjLE1BQVcsS0FBSyxNQUFNLElBQ25EO0NBRUYsT0FBTyxPQUFPLE1BQU0sT0FBTyxXQUFXLENBQUMsSUFBSSxNQUFNLEtBQUssU0FBUyxLQUFLLE9BQU8sS0FBSyxDQUFDO0FBQ2xGOzs7OztBQU1BLFNBQWdCLFdBQVksT0FBTztDQUNsQyxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUMsR0FDbkIsS0FBSztDQUVOLE9BQU8sTUFBTSxPQUFPLFFBQVE7QUFDN0I7Ozs7Ozs7QUN4UEEsU0FBZ0IsUUFBUyxPQUFPO0NBQy9CLE9BQU8sUUFBUSxNQUFNLElBQUksTUFBTSxNQUFNLE1BQU0sQ0FBQyxFQUFFLEdBQUcsUUFBUSxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQztBQUN0Rjs7Ozs7Ozs7Ozs7OztBQWNBLFNBQWdCLE1BQU8sT0FBTyxNQUFNLFFBQVEsTUFBTSxPQUFPLFVBQVUsUUFBUSxRQUFRLGNBQWM7Q0FDaEcsSUFBSSxRQUFRO0NBQ1osSUFBSSxTQUFTO0NBQ2IsSUFBSSxTQUFTO0NBQ2IsSUFBSSxTQUFTO0NBQ2IsSUFBSSxXQUFXO0NBQ2YsSUFBSSxXQUFXO0NBQ2YsSUFBSSxXQUFXO0NBQ2YsSUFBSSxXQUFXO0NBQ2YsSUFBSSxZQUFZO0NBQ2hCLElBQUksWUFBWTtDQUNoQixJQUFJLE9BQU87Q0FDWCxJQUFJLFFBQVE7Q0FDWixJQUFJLFdBQVc7Q0FDZixJQUFJLFlBQVk7Q0FDaEIsSUFBSSxhQUFhO0NBRWpCLE9BQU8sVUFDTixRQUFRLFdBQVcsV0FBVyxZQUFZLEtBQUssR0FBL0M7RUFFQyxLQUFLLElBQ0osSUFBSSxZQUFZLE9BQU8sT0FBTyxZQUFZLFNBQVMsQ0FBQyxLQUFLLElBQUk7R0FDNUQsSUFBSSxRQUFRLGNBQWMsUUFBUSxRQUFRLFNBQVMsR0FBRyxLQUFLLEtBQUssR0FBRyxPQUFPLElBQUksUUFBUSxPQUFPLFFBQVEsS0FBSyxDQUFDLENBQUMsS0FBSyxJQUNoSCxZQUFZO0dBQ2I7RUFDRDtFQUVELEtBQUs7RUFBSSxLQUFLO0VBQUksS0FBSztHQUN0QixjQUFjLFFBQVEsU0FBUztHQUMvQjtFQUVELEtBQUs7RUFBRyxLQUFLO0VBQUksS0FBSztFQUFJLEtBQUs7R0FDOUIsY0FBYyxXQUFXLFFBQVE7R0FDakM7RUFFRCxLQUFLO0dBQ0osY0FBYyxTQUFTLE1BQU0sSUFBSSxHQUFHLENBQUM7R0FDckM7RUFFRCxLQUFLO0dBQ0osUUFBUSxLQUFLLEdBQWI7SUFDQyxLQUFLO0lBQUksS0FBSztLQUNiLE9BQU8sUUFBUSxVQUFVLEtBQUssR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLFFBQVEsWUFBWSxHQUFHLFlBQVk7S0FDcEYsS0FBSyxNQUFNLFlBQVksQ0FBQyxLQUFLLEtBQUssTUFBTSxLQUFLLEtBQUssQ0FBQyxLQUFLLE1BQU0sT0FBTyxVQUFVLEtBQUssT0FBTyxZQUFZLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxjQUFjO0tBQzFJO0lBQ0QsU0FDQyxjQUFjO0dBQ2hCO0dBQ0E7RUFFRCxLQUFLLE1BQU0sVUFDVixPQUFPLFdBQVcsT0FBTyxVQUFVLElBQUk7RUFFeEMsS0FBSyxNQUFNO0VBQVUsS0FBSztFQUFJLEtBQUs7R0FDbEMsUUFBUSxXQUFSO0lBRUMsS0FBSztJQUFHLEtBQUssS0FBSyxXQUFXO0lBRTdCLEtBQUssS0FBSztLQUFRLElBQUksYUFBYSxJQUFJLGFBQWEsUUFBUSxZQUFZLE9BQU8sRUFBRTtLQUNoRixJQUFJLFdBQVcsTUFBTSxPQUFPLFVBQVUsSUFBSSxVQUFXLGFBQWEsS0FBSyxhQUFhLEtBQ25GLE9BQU8sV0FBVyxLQUFLLFlBQVksYUFBYSxLQUFLLE1BQU0sUUFBUSxTQUFTLEdBQUcsWUFBWSxJQUFJLFlBQVksUUFBUSxZQUFZLEtBQUssRUFBRSxJQUFJLEtBQUssTUFBTSxRQUFRLFNBQVMsR0FBRyxZQUFZLEdBQUcsWUFBWTtLQUNyTTtJQUVELEtBQUssSUFBSSxjQUFjO0lBRXZCO0tBQ0MsT0FBTyxZQUFZLFFBQVEsWUFBWSxNQUFNLFFBQVEsT0FBTyxRQUFRLE9BQU8sUUFBUSxNQUFNLFFBQVEsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxHQUFHLFFBQVEsUUFBUSxHQUFHLFFBQVE7S0FFL0ksSUFBSSxjQUFjLEtBQ2pCLElBQUksV0FBVyxHQUNkLE1BQU0sWUFBWSxNQUFNLFdBQVcsV0FBVyxPQUFPLFVBQVUsUUFBUSxRQUFRLFFBQVE7VUFDbkY7TUFDSixRQUFRLFFBQVI7T0FFQyxLQUFLLElBQ0osSUFBSSxPQUFPLFlBQVksQ0FBQyxNQUFNLEtBQUs7T0FFcEMsS0FBSyxLQUNKLElBQUksT0FBTyxZQUFZLENBQUMsTUFBTSxJQUFJO09BQ25DLFNBQ0MsU0FBUztPQUVWLEtBQUs7T0FBSyxLQUFLO09BQUssS0FBSztNQUMxQjtNQUNBLElBQUksUUFBUSxNQUFNLE9BQU8sV0FBVyxXQUFXLFFBQVEsT0FBTyxRQUFRLE9BQU8sV0FBVyxXQUFXLEdBQUcsR0FBRyxPQUFPLFFBQVEsTUFBTSxPQUFPLFFBQVEsQ0FBQyxHQUFHLFFBQVEsUUFBUSxHQUFHLFFBQVEsR0FBRyxPQUFPLFVBQVUsUUFBUSxRQUFRLE9BQU8sUUFBUSxRQUFRO1dBQ2xPLE1BQU0sWUFBWSxXQUFXLFdBQVcsV0FBVyxDQUFDLEVBQUUsR0FBRyxVQUFVLEdBQUcsUUFBUSxRQUFRO0tBQzVGO0dBQ0g7R0FFQSxRQUFRLFNBQVMsV0FBVyxHQUFHLFdBQVcsWUFBWSxHQUFHLE9BQU8sYUFBYSxJQUFJLFNBQVM7R0FDMUY7RUFFRCxLQUFLLElBQ0osU0FBUyxJQUFJLE9BQU8sVUFBVSxHQUFHLFdBQVc7RUFDN0M7R0FDQyxJQUFJLFdBQVcsR0FDZDtJQUFJLElBQUEsYUFBYSxLQUNoQixFQUFFO1NBQ0UsSUFBSSxhQUFhLE9BQU8sY0FBYyxLQUFLLEtBQUssS0FBSyxLQUN6RDtHQUFPO0dBRVQsUUFBUSxjQUFjLEtBQUssU0FBUyxHQUFHLFlBQVksVUFBbkQ7SUFFQyxLQUFLO0tBQ0osWUFBWSxTQUFTLElBQUksS0FBSyxjQUFjLE1BQU07S0FDbEQ7SUFFRCxLQUFLO0tBQ0osT0FBTyxZQUFZLE9BQU8sVUFBVSxJQUFJLEtBQUssV0FBVyxZQUFZO0tBQ3BFO0lBRUQsS0FBSztLQUVKLElBQUksS0FBSyxNQUFNLElBQ2QsY0FBYyxRQUFRLEtBQUssQ0FBQztLQUU3QixTQUFTLEtBQUssR0FBRyxTQUFTLFNBQVMsT0FBTyxPQUFPLGNBQWMsV0FBVyxNQUFNLENBQUMsQ0FBQyxHQUFHO0tBQ3JGO0lBRUQsS0FBSyxJQUNKLElBQUksYUFBYSxNQUFNLE9BQU8sVUFBVSxLQUFLLEdBQzVDLFdBQVc7R0FDZDtDQUNGO0NBRUQsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7Ozs7O0FBaUJBLFNBQWdCLFFBQVMsT0FBTyxNQUFNLFFBQVEsT0FBTyxRQUFRLE9BQU8sUUFBUSxNQUFNLE9BQU8sVUFBVSxRQUFRLFVBQVU7Q0FDcEgsSUFBSSxPQUFPLFNBQVM7Q0FDcEIsSUFBSSxPQUFPLFdBQVcsSUFBSSxRQUFRLENBQUMsRUFBRTtDQUNyQyxJQUFJLE9BQU8sT0FBTyxJQUFJO0NBRXRCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLE9BQU8sRUFBRSxHQUMxQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxPQUFPLE9BQU8sR0FBRyxPQUFPLElBQUksSUFBSSxPQUFPLEVBQUUsQ0FBQyxHQUFHLElBQUksT0FBTyxJQUFJLE1BQU0sRUFBRSxHQUM5RixJQUFJLElBQUksS0FBSyxJQUFJLElBQUksS0FBSyxLQUFLLE1BQU0sSUFBSSxRQUFRLEdBQUcsUUFBUSxLQUFLLEVBQUUsQ0FBQyxHQUNuRSxNQUFNLE9BQU87Q0FFaEIsT0FBTyxLQUFLLE9BQU8sTUFBTSxRQUFRLFdBQVcsSUFBSSxVQUFVLE1BQU0sT0FBTyxVQUFVLFFBQVEsUUFBUTtBQUNsRzs7Ozs7Ozs7QUFTQSxTQUFnQixRQUFTLE9BQU8sTUFBTSxRQUFRLFVBQVU7Q0FDdkQsT0FBTyxLQUFLLE9BQU8sTUFBTSxRQUFRLFNBQVMsS0FBSyxLQUFLLENBQUMsR0FBRyxPQUFPLE9BQU8sR0FBRyxFQUFFLEdBQUcsR0FBRyxRQUFRO0FBQzFGOzs7Ozs7Ozs7QUFVQSxTQUFnQixZQUFhLE9BQU8sTUFBTSxRQUFRLFFBQVEsVUFBVTtDQUNuRSxPQUFPLEtBQUssT0FBTyxNQUFNLFFBQVEsYUFBYSxPQUFPLE9BQU8sR0FBRyxNQUFNLEdBQUcsT0FBTyxPQUFPLFNBQVMsR0FBRyxFQUFFLEdBQUcsUUFBUSxRQUFRO0FBQ3hIOzs7Ozs7Ozs7QUNoTUEsU0FBZ0IsT0FBUSxPQUFPLFFBQVEsVUFBVTtDQUNoRCxRQUFRLEtBQUssT0FBTyxNQUFNLEdBQTFCO0VBRUMsS0FBSyxNQUNKLE9BQU8sU0FBUyxXQUFXLFFBQVE7RUFFcEMsS0FBSztFQUFNLEtBQUs7RUFBTSxLQUFLO0VBQU0sS0FBSztFQUFNLEtBQUs7RUFBTSxLQUFLO0VBQU0sS0FBSztFQUV2RSxLQUFLO0VBQU0sS0FBSztFQUFNLEtBQUs7RUFBTSxLQUFLO0VBQU0sS0FBSztFQUFNLEtBQUs7RUFFNUQsS0FBSztFQUFNLEtBQUs7RUFBTSxLQUFLO0VBQU0sS0FBSztFQUFNLEtBQUs7RUFBTSxLQUFLO0VBRTVELEtBQUs7RUFBTSxLQUFLO0VBQU0sS0FBSztFQUFNLEtBQUs7RUFBTSxLQUFLLE1BQ2hELE9BQU8sU0FBUyxRQUFRO0VBRXpCLEtBQUssTUFDSixPQUFPLFNBQVMsTUFBTSxRQUFRLE9BQU8sYUFBYSxDQUFDLENBQUMsUUFBUSxhQUFhLFlBQVksQ0FBQyxDQUFDLFFBQVEsYUFBYSxXQUFXLENBQUMsQ0FBQyxRQUFRLFdBQVcsS0FBSyxJQUFJO0VBRXRKLEtBQUssTUFDSixPQUFPLE1BQU0sUUFBUTtFQUV0QixLQUFLO0VBQU0sS0FBSztFQUFNLEtBQUs7RUFBTSxLQUFLO0VBQU0sS0FBSyxNQUNoRCxPQUFPLFNBQVMsUUFBUSxNQUFNLFFBQVEsS0FBSyxRQUFRO0VBRXBELEtBQUssTUFDSixRQUFRLE9BQU8sT0FBTyxTQUFTLEVBQUUsR0FBakM7R0FFQyxLQUFLLEtBQ0osT0FBTyxTQUFTLFFBQVEsS0FBSyxRQUFRLE9BQU8sc0JBQXNCLElBQUksSUFBSTtHQUUzRSxLQUFLLEtBQ0osT0FBTyxTQUFTLFFBQVEsS0FBSyxRQUFRLE9BQU8sc0JBQXNCLE9BQU8sSUFBSTtHQUU5RSxLQUFLLElBQ0osT0FBTyxTQUFTLFFBQVEsS0FBSyxRQUFRLE9BQU8sc0JBQXNCLElBQUksSUFBSTtFQUU1RTtFQUVELEtBQUs7RUFBTSxLQUFLO0VBQU0sS0FBSyxNQUMxQixPQUFPLFNBQVMsUUFBUSxLQUFLLFFBQVE7RUFFdEMsS0FBSyxNQUNKLE9BQU8sU0FBUyxRQUFRLEtBQUssVUFBVSxRQUFRO0VBRWhELEtBQUssTUFDSixPQUFPLFNBQVMsUUFBUSxRQUFRLE9BQU8sa0JBQWtCLFNBQVMsYUFBYSxLQUFLLFdBQVcsSUFBSTtFQUVwRyxLQUFLLE1BQ0osT0FBTyxTQUFTLFFBQVEsS0FBSyxlQUFlLFFBQVEsT0FBTyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsTUFBTSxPQUFPLGdCQUFnQixJQUFJLEtBQUssY0FBYyxRQUFRLE9BQU8sZ0JBQWdCLEVBQUUsSUFBSSxNQUFNO0VBRW5MLEtBQUssTUFDSixPQUFPLFNBQVMsUUFBUSxLQUFLLG1CQUFtQixRQUFRLE9BQU8sOEJBQThCLEVBQUUsSUFBSTtFQUVwRyxLQUFLLE1BQ0osT0FBTyxTQUFTLFFBQVEsS0FBSyxRQUFRLE9BQU8sVUFBVSxVQUFVLElBQUk7RUFFckUsS0FBSyxNQUNKLE9BQU8sU0FBUyxRQUFRLEtBQUssUUFBUSxPQUFPLFNBQVMsZ0JBQWdCLElBQUk7RUFFMUUsS0FBSyxNQUNKLE9BQU8sU0FBUyxTQUFTLFFBQVEsT0FBTyxTQUFTLEVBQUUsSUFBSSxTQUFTLFFBQVEsS0FBSyxRQUFRLE9BQU8sUUFBUSxVQUFVLElBQUk7RUFFbkgsS0FBSyxNQUNKLE9BQU8sU0FBUyxRQUFRLE9BQU8sc0JBQXNCLE9BQU8sU0FBUyxJQUFJLElBQUk7RUFFOUUsS0FBSyxNQUNKLE9BQU8sUUFBUSxRQUFRLFFBQVEsT0FBTyxnQkFBZ0IsU0FBUyxJQUFJLEdBQUcsZUFBZSxTQUFTLElBQUksR0FBRyxPQUFPLEVBQUUsSUFBSTtFQUVuSCxLQUFLO0VBQU0sS0FBSyxNQUNmLE9BQU8sUUFBUSxPQUFPLHFCQUFxQixTQUFTLFFBQWE7RUFFbEUsS0FBSyxNQUNKLE9BQU8sUUFBUSxRQUFRLE9BQU8scUJBQXFCLFNBQVMsZ0JBQWdCLEtBQUssY0FBYyxHQUFHLGlCQUFpQixTQUFTLElBQUksU0FBUyxRQUFRO0VBRWxKLEtBQUs7R0FDSixJQUFJLENBQUMsTUFBTSxPQUFPLGdCQUFnQixHQUFHLE9BQU8sS0FBSyxzQkFBc0IsT0FBTyxPQUFPLE1BQU0sSUFBSTtHQUMvRjtFQUVELEtBQUs7RUFBTSxLQUFLLE1BQ2YsT0FBTyxLQUFLLFFBQVEsT0FBTyxhQUFhLEVBQUUsSUFBSTtFQUUvQyxLQUFLO0VBQU0sS0FBSztHQUNmLElBQUksWUFBWSxTQUFTLEtBQUssU0FBVSxTQUFTLE9BQU87SUFBRSxPQUFPLFNBQVMsT0FBTyxNQUFNLFFBQVEsT0FBTyxjQUFjO0dBQUUsQ0FBQyxHQUN0SCxPQUFPLENBQUMsUUFBUSxTQUFTLFdBQVcsU0FBUyxPQUFPLENBQUMsUUFBUSxRQUFRLENBQUMsSUFBSSxRQUFTLEtBQUssUUFBUSxPQUFPLFVBQVUsRUFBRSxJQUFJLFFBQVEsS0FBSyxvQkFBb0IsQ0FBQyxRQUFRLFVBQVUsUUFBUSxDQUFDLElBQUksTUFBTSxVQUFVLEtBQUssSUFBSSxDQUFDLE1BQU0sVUFBVSxLQUFLLElBQUksQ0FBQyxNQUFNLE9BQU8sS0FBSyxLQUFLO0dBRXBRLE9BQU8sS0FBSyxRQUFRLE9BQU8sVUFBVSxFQUFFLElBQUk7RUFFNUMsS0FBSztFQUFNLEtBQUssTUFDZixPQUFRLFlBQVksU0FBUyxLQUFLLFNBQVUsU0FBUztHQUFFLE9BQU8sTUFBTSxRQUFRLE9BQU8sZ0JBQWdCO0VBQUUsQ0FBQyxJQUFLLFFBQVEsS0FBSyxRQUFRLFFBQVEsT0FBTyxRQUFRLE9BQU8sR0FBRyxTQUFTLEVBQUUsSUFBSTtFQUVqTCxLQUFLO0VBQU0sS0FBSztFQUFNLEtBQUs7RUFBTSxLQUFLLE1BQ3JDLE9BQU8sUUFBUSxPQUFPLG1CQUFtQixTQUFTLE1BQU0sSUFBSTtFQUU3RCxLQUFLO0VBQU0sS0FBSztFQUFNLEtBQUs7RUFBTSxLQUFLO0VBQ3RDLEtBQUs7RUFBTSxLQUFLO0VBQU0sS0FBSztFQUFNLEtBQUs7RUFDdEMsS0FBSztFQUFNLEtBQUs7RUFBTSxLQUFLO0VBQU0sS0FBSztHQUVyQyxJQUFJLE9BQU8sS0FBSyxJQUFJLElBQUksU0FBUyxHQUNoQyxRQUFRLE9BQU8sT0FBTyxTQUFTLENBQUMsR0FBaEM7SUFFQyxLQUFLLEtBRUosSUFBSSxPQUFPLE9BQU8sU0FBUyxDQUFDLE1BQU0sSUFDakM7SUFFRixLQUFLLEtBQ0osT0FBTyxRQUFRLE9BQU8sb0JBQW9CLE9BQU8sU0FBUyxZQUFpQixPQUFPLE9BQU8sT0FBTyxTQUFTLENBQUMsS0FBSyxNQUFNLE9BQU8sUUFBUSxJQUFJO0lBRXpJLEtBQUssS0FDSixPQUFPLENBQUMsUUFBUSxPQUFPLFdBQVcsQ0FBQyxJQUFJLE9BQU8sUUFBUSxPQUFPLFdBQVcsZ0JBQWdCLEdBQUcsUUFBUSxRQUFRLElBQUksUUFBUTtHQUN6SDtHQUNEO0VBRUQsS0FBSztFQUFNLEtBQUssTUFDZixPQUFPLFFBQVEsT0FBTyw2Q0FBNkMsU0FBVSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0dBQUUsT0FBUSxLQUFLLElBQUksTUFBTSxJQUFJLEtBQU0sSUFBSyxLQUFLLElBQUksWUFBWSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBTSxJQUFJLE1BQU07RUFBTSxDQUFDO0VBRXJNLEtBQUs7R0FFSixJQUFJLE9BQU8sT0FBTyxTQUFTLENBQUMsTUFBTSxLQUNqQyxPQUFPLFFBQVEsT0FBTyxLQUFLLE1BQU0sTUFBTSxJQUFJO0dBQzVDO0VBRUQsS0FBSztHQUNKLFFBQVEsT0FBTyxPQUFPLE9BQU8sT0FBTyxFQUFFLE1BQU0sS0FBSyxLQUFLLEVBQUUsR0FBeEQ7SUFFQyxLQUFLLEtBQ0osT0FBTyxRQUFRLE9BQU8saUNBQWlDLE9BQU8sVUFBVSxPQUFPLE9BQU8sRUFBRSxNQUFNLEtBQUssWUFBWSxNQUFNLFlBQWlCLFNBQVMsV0FBZ0IsS0FBSyxTQUFTLElBQUk7SUFFbEwsS0FBSyxLQUNKLE9BQU8sUUFBUSxPQUFPLEtBQUssTUFBTSxFQUFFLElBQUk7R0FDekM7R0FDQTtFQUVELEtBQUs7RUFBTSxLQUFLO0VBQU0sS0FBSztFQUFNLEtBQUs7RUFBTSxLQUFLLE1BQ2hELE9BQU8sUUFBUSxPQUFPLFdBQVcsY0FBYyxJQUFJO0NBQ3JEO0NBRUEsT0FBTztBQUNSOzs7Ozs7OztBQzNJQSxTQUFnQixVQUFXLFVBQVUsVUFBVTtDQUM5QyxJQUFJLFNBQVM7Q0FFYixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQ3BDLFVBQVUsU0FBUyxTQUFTLElBQUksR0FBRyxVQUFVLFFBQVEsS0FBSztDQUUzRCxPQUFPO0FBQ1I7Ozs7Ozs7O0FBU0EsU0FBZ0IsVUFBVyxTQUFTLE9BQU8sVUFBVSxVQUFVO0NBQzlELFFBQVEsUUFBUSxNQUFoQjtFQUNDLEtBQUssT0FBTyxJQUFJLFFBQVEsU0FBUyxRQUFRO0VBQ3pDLEtBQUs7RUFBUSxLQUFLO0VBQVcsS0FBSyxhQUFhLE9BQU8sUUFBUSxTQUFTLFFBQVEsVUFBVSxRQUFRO0VBQ2pHLEtBQUssU0FBUyxPQUFPO0VBQ3JCLEtBQUssV0FBVyxPQUFPLFFBQVEsU0FBUyxRQUFRLFFBQVEsTUFBTSxVQUFVLFFBQVEsVUFBVSxRQUFRLElBQUk7RUFDdEcsS0FBSyxTQUFTLElBQUksQ0FBQyxPQUFPLFFBQVEsUUFBUSxRQUFRLE1BQU0sS0FBSyxHQUFHLENBQUMsR0FBRyxPQUFPO0NBQzVFO0NBRUEsT0FBTyxPQUFPLFdBQVcsVUFBVSxRQUFRLFVBQVUsUUFBUSxDQUFDLElBQUksUUFBUSxTQUFTLFFBQVEsUUFBUSxNQUFNLFdBQVcsTUFBTTtBQUMzSDs7Ozs7OztBQ3hCQSxTQUFnQixXQUFZLFlBQVk7Q0FDdkMsSUFBSSxTQUFTLE9BQU8sVUFBVTtDQUU5QixPQUFPLFNBQVUsU0FBUyxPQUFPLFVBQVUsVUFBVTtFQUNwRCxJQUFJLFNBQVM7RUFFYixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxLQUMzQixVQUFVLFdBQVcsRUFBRSxDQUFDLFNBQVMsT0FBTyxVQUFVLFFBQVEsS0FBSztFQUVoRSxPQUFPO0NBQ1I7QUFDRDs7Ozs7QUFNQSxTQUFnQixVQUFXLFVBQVU7Q0FDcEMsT0FBTyxTQUFVLFNBQVM7RUFDekIsSUFBSSxDQUFDLFFBQVEsTUFDUjtPQUFBLFVBQVUsUUFBUSxRQUNyQixTQUFTLE9BQU87RUFBQTtDQUNuQjtBQUNEOzs7Ozs7O0FBUUEsU0FBZ0IsU0FBVSxTQUFTLE9BQU8sVUFBVSxVQUFVO0NBQzdELElBQUksUUFBUSxTQUFTLElBQ2hCO01BQUEsQ0FBQyxRQUFRLFFBQ1osUUFBUSxRQUFRLE1BQWhCO0dBQ0MsS0FBSztJQUFhLFFBQVEsU0FBUyxPQUFPLFFBQVEsT0FBTyxRQUFRLFFBQVEsUUFBUTtJQUNoRjtHQUNELEtBQUssV0FDSixPQUFPLFVBQVUsQ0FBQyxLQUFLLFNBQVMsRUFBQyxPQUFPLFFBQVEsUUFBUSxPQUFPLEtBQUssTUFBTSxNQUFNLEVBQUMsQ0FBQyxDQUFDLEdBQUcsUUFBUTtHQUMvRixLQUFLLFNBQ0osSUFBSSxRQUFRLFFBQ1gsT0FBTyxRQUFRLFdBQVcsUUFBUSxPQUFPLFNBQVUsT0FBTztJQUN6RCxRQUFRLE1BQU0sT0FBTyxXQUFXLHVCQUF1QixHQUF2RDtLQUVDLEtBQUs7S0FBYyxLQUFLO01BQ3ZCLEtBQUssS0FBSyxTQUFTLEVBQUMsT0FBTyxDQUFDLFFBQVEsT0FBTyxlQUFlLE1BQU0sTUFBTSxJQUFJLENBQUMsRUFBQyxDQUFDLENBQUM7TUFDOUUsS0FBSyxLQUFLLFNBQVMsRUFBQyxPQUFPLENBQUMsS0FBSyxFQUFDLENBQUMsQ0FBQztNQUNwQyxPQUFPLFNBQVMsRUFBQyxPQUFPLE9BQU8sVUFBVSxRQUFRLEVBQUMsQ0FBQztNQUNuRDtLQUVELEtBQUs7TUFDSixLQUFLLEtBQUssU0FBUyxFQUFDLE9BQU8sQ0FBQyxRQUFRLE9BQU8sY0FBYyxNQUFNLFNBQVMsVUFBVSxDQUFDLEVBQUMsQ0FBQyxDQUFDO01BQ3RGLEtBQUssS0FBSyxTQUFTLEVBQUMsT0FBTyxDQUFDLFFBQVEsT0FBTyxjQUFjLE1BQU0sTUFBTSxJQUFJLENBQUMsRUFBQyxDQUFDLENBQUM7TUFDN0UsS0FBSyxLQUFLLFNBQVMsRUFBQyxPQUFPLENBQUMsUUFBUSxPQUFPLGNBQWMsS0FBSyxVQUFVLENBQUMsRUFBQyxDQUFDLENBQUM7TUFDNUUsS0FBSyxLQUFLLFNBQVMsRUFBQyxPQUFPLENBQUMsS0FBSyxFQUFDLENBQUMsQ0FBQztNQUNwQyxPQUFPLFNBQVMsRUFBQyxPQUFPLE9BQU8sVUFBVSxRQUFRLEVBQUMsQ0FBQztJQUVyRDtJQUVBLE9BQU87R0FDUixDQUFDO0VBQ0o7O0FBQ0g7Ozs7QUN4RXlJLElBQUk7QUFBRSxJQUFBO0FBQUUsSUFBTSxJQUFFLGVBQWEsT0FBTyxXQUFTLEtBQUssTUFBSSxRQUFRLFFBQU0sUUFBUSxJQUFJLHFCQUFtQixRQUFRLElBQUksWUFBVTtBQUFjLElBQUEsSUFBRTtBQUFTLElBQUEsSUFBRTtBQUFzQixJQUFBLElBQUU7QUFBUSxJQUFBLElBQUU7QUFBWSxJQUFBLElBQUUsZUFBYSxPQUFPLFVBQVEsZUFBYSxPQUFPO0FBQVMsU0FBUyxFQUFFLEdBQUU7Q0FBQyxJQUFHLGVBQWEsT0FBTyxXQUFTLEtBQUssTUFBSSxRQUFRLEtBQUk7RUFBQyxNQUFNLElBQUUsUUFBUSxJQUFJO0VBQUcsSUFBRyxLQUFLLE1BQUksS0FBRyxPQUFLLEdBQUUsT0FBTSxZQUFVO0NBQUM7QUFBQztBQUFDLElBQU0sSUFBRSxRQUFRLGFBQVcsT0FBTyxvQkFBa0Isb0JBQWtCLFVBQVEsSUFBRSxVQUFRLElBQUUsRUFBRSw2QkFBNkIsTUFBSSxLQUFLLE1BQUksSUFBRSxJQUFFLEVBQUUsbUJBQW1CLE1BQUksS0FBSyxNQUFJLElBQUUsSUFBRSxlQUFhLE9BQU8sV0FBUyxLQUFLLE1BQUksUUFBUSxPQUFLLElBQW1DO0FBQUUsSUFBQSxJQUFFO0FBQWdCLElBQUEsSUFBRSxDQUFDO0FBQUUsSUFBQSxJQUFzQztDQUFDLEdBQUU7Q0FBd0QsR0FBRTtDQUFnUSxHQUFFO0NBQXNILEdBQUU7Q0FBc00sR0FBRTtDQUFrSyxHQUFFO0NBQTRPLEdBQUU7Q0FBcUgsR0FBRTtDQUE4RCxHQUFFO0NBQWdDLElBQUc7Q0FBaVUsSUFBRztDQUF3TixJQUFHO0NBQTBPLElBQUc7Q0FBcUwsSUFBRztDQUErQyxJQUFHO0NBQTJaLElBQUc7Q0FBdVEsSUFBRztDQUEySSxJQUFHO0FBQThwQjtBQUFLLFNBQVMsRUFBRSxHQUFFLEdBQUcsR0FBRTtDQUFDLE9BQWtRLElBQUksTUFBTSxTQUFTLEdBQUcsR0FBRTtFQUFDLElBQUksSUFBRSxFQUFFO0VBQUcsTUFBTSxJQUFFLENBQUM7RUFBRSxLQUFJLElBQUksSUFBRSxHQUFFLElBQUUsRUFBRSxRQUFPLElBQUUsR0FBRSxLQUFHLEdBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRTtFQUFFLE9BQU8sRUFBRSxTQUFRLE1BQUc7R0FBQyxJQUFFLEVBQUUsUUFBUSxVQUFTLENBQUM7RUFBQyxDQUFDLEdBQUU7Q0FBQyxFQUFFLEVBQUUsSUFBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUFDO0FBQUMsSUFBTSxJQUFFLEtBQUc7QUFBRyxJQUFJLG9CQUFFLElBQUksSUFBRTtBQUFFLElBQUEsb0JBQUUsSUFBSSxJQUFFO0FBQUUsSUFBQSxJQUFFO0FBQUUsSUFBTSxLQUFFLE1BQUc7Q0FBQyxJQUFHLEVBQUUsSUFBSSxDQUFDLEdBQUUsT0FBTyxFQUFFLElBQUksQ0FBQztDQUFFLE9BQUssRUFBRSxJQUFJLENBQUMsSUFBRztDQUFJLE1BQU0sSUFBRTtDQUFJLEtBQTBDLElBQUUsS0FBRyxLQUFHLElBQUUsR0FBRyxNQUFNLEVBQUUsSUFBRyxHQUFHLEdBQUc7Q0FBRSxPQUFPLEVBQUUsSUFBSSxHQUFFLENBQUMsR0FBRSxFQUFFLElBQUksR0FBRSxDQUFDLEdBQUU7QUFBQztBQUFFLElBQUEsS0FBRSxNQUFHLEVBQUUsSUFBSSxDQUFDO0FBQUUsSUFBQSxLQUFHLEdBQUUsTUFBSTtDQUFDLElBQUUsSUFBRSxHQUFFLEVBQUUsSUFBSSxHQUFFLENBQUMsR0FBRSxFQUFFLElBQUksR0FBRSxDQUFDO0FBQUM7QUFBRSxJQUFBLElBQUU7QUFBcUIsSUFBQSxvQkFBRSxJQUFJLElBQUU7QUFBRSxJQUFBLEtBQUcsR0FBRSxNQUFJO0NBQXdDO0VBQUMsTUFBTSxJQUFFLGlCQUFpQixJQUFJLElBQUUsb0JBQW9CLEVBQUUsS0FBRyxHQUFHLCtVQUE4VSxJQUFFLFFBQVE7RUFBTSxJQUFHO0dBQUMsSUFBSSxJQUFFLENBQUM7R0FBRSxRQUFRLFNBQU8sR0FBRSxHQUFHLE1BQUk7SUFBQyxFQUFFLEtBQUssQ0FBQyxLQUFHLElBQUUsQ0FBQyxHQUFFLEVBQUUsT0FBTyxDQUFDLEtBQUcsRUFBRSxHQUFFLEdBQUcsQ0FBQztHQUFDLEdBQUUsY0FBWSxPQUFBLGFBQVMsWUFBQSxhQUFZLFNBQVMsSUFBSSxHQUFFLEtBQUcsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFJLFFBQVEsS0FBSyxDQUFDLEdBQUUsRUFBRSxJQUFJLENBQUM7RUFBRSxTQUFPLEdBQUU7R0FBQyxFQUFFLEtBQUssRUFBRSxPQUFPLEtBQUcsRUFBRSxPQUFPLENBQUM7RUFBQyxVQUFRO0dBQUMsUUFBUSxRQUFNO0VBQUM7Q0FBQztBQUFDO0FBQUUsSUFBQSxJQUFFLE9BQU8sT0FBTyxDQUFDLENBQUM7QUFBRSxJQUFBLElBQUUsT0FBTyxPQUFPLENBQUMsQ0FBQztBQUFFLFNBQVMsRUFBRSxHQUFFLEdBQUUsSUFBRSxHQUFFO0NBQUMsT0FBTyxFQUFFLFVBQVEsRUFBRSxTQUFPLEVBQUUsU0FBTyxLQUFHLEVBQUU7QUFBSztBQUFDLElBQU0sSUFBRTtBQUF3QyxJQUFBLElBQUU7QUFBVyxTQUFTLEVBQUUsR0FBRTtDQUFDLE9BQU8sRUFBRSxRQUFRLEdBQUUsR0FBRyxDQUFDLENBQUMsUUFBUSxHQUFFLEVBQUU7QUFBQztBQUFDLElBQU0sSUFBRTtBQUFXLElBQUEsS0FBRSxNQUFHLE9BQU8sYUFBYSxLQUFHLElBQUUsS0FBRyxLQUFHLEdBQUc7QUFBRSxTQUFTLEVBQUUsR0FBRTtDQUFDLElBQUksR0FBRSxJQUFFO0NBQUcsS0FBSSxJQUFFLEtBQUssSUFBSSxDQUFDLEdBQUUsSUFBRSxJQUFHLElBQUUsSUFBRSxLQUFHLEdBQUUsSUFBRSxFQUFFLElBQUUsRUFBRSxJQUFFO0NBQUUsUUFBTyxFQUFFLElBQUUsRUFBRSxJQUFFLEVBQUEsQ0FBRyxRQUFRLEdBQUUsT0FBTztBQUFDO0FBQUMsSUFBTSxJQUFFO0FBQUssSUFBQSxLQUFHLEdBQUUsTUFBSTtDQUFDLElBQUksSUFBRSxFQUFFO0NBQU8sT0FBSyxJQUFHLElBQUUsS0FBRyxJQUFFLEVBQUUsV0FBVyxFQUFFLENBQUM7Q0FBRSxPQUFPO0FBQUM7QUFBRSxJQUFBLEtBQUUsTUFBRyxFQUFFLEdBQUUsQ0FBQztBQUFFLFNBQVMsRUFBRSxHQUFFO0NBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxNQUFJLENBQUM7QUFBQztBQUFDLFNBQVMsRUFBRSxHQUFFO0NBQUMsT0FBMkMsWUFBVSxPQUFPLEtBQUcsS0FBRyxFQUFFLGVBQWEsRUFBRSxRQUFNO0FBQVc7QUFBQyxTQUFTLEVBQUUsR0FBRTtDQUFDLE9BQU0sWUFBVSxPQUFPLEtBQXlDLEVBQUUsT0FBTyxDQUFDLE1BQUksRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLFlBQVk7QUFBRTtBQUFDLFNBQVMsRUFBRSxHQUFFO0NBQUMsT0FBTyxFQUFFLENBQUMsSUFBRSxVQUFVLE1BQUksVUFBVSxFQUFFLENBQUMsRUFBRTtBQUFFO0FBQUMsSUFBTSxJQUFFLE9BQU8sSUFBSSxZQUFZO0FBQUUsSUFBQSxJQUFFLE9BQU8sSUFBSSxtQkFBbUI7QUFBRSxJQUFBLElBQUU7Q0FBQyxhQUFZLENBQUM7Q0FBRSxjQUFhLENBQUM7Q0FBRSxhQUFZLENBQUM7Q0FBRSwwQkFBeUIsQ0FBQztDQUFFLDBCQUF5QixDQUFDO0NBQUUsV0FBVSxDQUFDO0NBQUUsTUFBSyxDQUFDO0FBQUM7QUFBRSxJQUFBLElBQUU7Q0FBQyxNQUFLLENBQUM7Q0FBRSxRQUFPLENBQUM7Q0FBRSxXQUFVLENBQUM7Q0FBRSxRQUFPLENBQUM7Q0FBRSxRQUFPLENBQUM7Q0FBRSxXQUFVLENBQUM7Q0FBRSxPQUFNLENBQUM7QUFBQztBQUFFLElBQUEsSUFBRTtDQUFDLFVBQVMsQ0FBQztDQUFFLFNBQVEsQ0FBQztDQUFFLGNBQWEsQ0FBQztDQUFFLGFBQVksQ0FBQztDQUFFLFdBQVUsQ0FBQztDQUFFLE1BQUssQ0FBQztBQUFDO0FBQUUsSUFBQSxJQUFFO0VBQUUsSUFBRztFQUFDLFVBQVMsQ0FBQztFQUFFLFFBQU8sQ0FBQztFQUFFLGNBQWEsQ0FBQztFQUFFLGFBQVksQ0FBQztFQUFFLFdBQVUsQ0FBQztDQUFDO0VBQUcsSUFBRztBQUFDO0FBQUUsU0FBUyxFQUFFLEdBQUU7Q0FBQyxRQUFPLFdBQVMsSUFBRSxNQUFJLEVBQUUsS0FBSyxjQUFZLElBQUUsSUFBRSxjQUFhLElBQUUsRUFBRSxFQUFFLFlBQVU7S0FBTTtBQUFDO0FBQUMsSUFBTSxJQUFFLE9BQU87QUFBZSxJQUFBLElBQUUsT0FBTztBQUFvQixJQUFBLEtBQUcsT0FBTztBQUFzQixJQUFBLEtBQUcsT0FBTztBQUF5QixJQUFBLEtBQUcsT0FBTztBQUFlLElBQUEsS0FBRyxPQUFPO0FBQVUsU0FBUyxHQUFHLEdBQUUsR0FBRSxHQUFFO0NBQUMsSUFBRyxZQUFVLE9BQU8sR0FBRTtFQUFDLE1BQU0sSUFBRSxHQUFHLENBQUM7RUFBRSxLQUFHLE1BQUksTUFBSSxHQUFHLEdBQUUsR0FBRSxDQUFDO0VBQUUsTUFBTSxJQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQyxHQUFFLElBQUUsRUFBRSxDQUFDLEdBQUUsSUFBRSxFQUFFLENBQUM7RUFBRSxLQUFJLElBQUksSUFBRSxHQUFFLElBQUUsRUFBRSxRQUFPLEVBQUUsR0FBRTtHQUFDLE1BQU0sSUFBRSxFQUFFO0dBQUcsSUFBRyxFQUFFLEtBQUssS0FBRyxLQUFHLEVBQUUsTUFBSSxLQUFHLEtBQUssS0FBRyxLQUFHLEtBQUssSUFBRztJQUFDLE1BQU0sSUFBRSxHQUFHLEdBQUUsQ0FBQztJQUFFLElBQUc7S0FBQyxFQUFFLEdBQUUsR0FBRSxDQUFDO0lBQUMsU0FBTyxHQUFFLENBQUM7R0FBQztFQUFDO0NBQUM7Q0FBQyxPQUFPO0FBQUM7QUFBQyxTQUFTLEdBQUcsR0FBRTtDQUFDLE9BQU0sY0FBWSxPQUFPO0FBQUM7QUFBQyxJQUFNLEtBQUcsT0FBTyxJQUFJLG1CQUFtQjtBQUFFLFNBQVMsR0FBRyxHQUFFO0NBQUMsT0FBTyxRQUFNLE1BQUksWUFBVSxPQUFPLEtBQUcsY0FBWSxPQUFPLE1BQUksRUFBRSxhQUFXLE1BQUksdUJBQXNCO0FBQUM7QUFBQyxTQUFTLEdBQUcsR0FBRSxHQUFFO0NBQUMsT0FBTyxLQUFHLElBQUUsSUFBRSxNQUFJLElBQUUsS0FBRyxLQUFHO0FBQUU7QUFBQyxTQUFTLEdBQUcsR0FBRSxHQUFFO0NBQUMsT0FBTyxFQUFFLEtBQUssS0FBRyxFQUFFO0FBQUM7QUFBQyxTQUFTLEdBQUcsR0FBRTtDQUFDLE9BQU8sU0FBTyxLQUFHLFlBQVUsT0FBTyxLQUFHLEVBQUUsWUFBWSxTQUFPLE9BQU8sUUFBTSxFQUFFLFdBQVUsS0FBRyxFQUFFO0FBQVM7QUFBQyxTQUFTLEdBQUcsR0FBRSxHQUFFLElBQUUsQ0FBQyxHQUFFO0NBQUMsSUFBRyxDQUFDLEtBQUcsQ0FBQyxHQUFHLENBQUMsS0FBRyxDQUFDLE1BQU0sUUFBUSxDQUFDLEdBQUUsT0FBTztDQUFFLElBQUcsTUFBTSxRQUFRLENBQUMsR0FBRSxLQUFJLElBQUksSUFBRSxHQUFFLElBQUUsRUFBRSxRQUFPLEtBQUksRUFBRSxLQUFHLEdBQUcsRUFBRSxJQUFHLEVBQUUsRUFBRTtNQUFPLElBQUcsR0FBRyxDQUFDLEdBQUUsS0FBSSxNQUFNLEtBQUssR0FBRSxFQUFFLEtBQUcsR0FBRyxFQUFFLElBQUcsRUFBRSxFQUFFO0NBQUUsT0FBTztBQUFDO0FBQUMsU0FBUyxHQUFHLEdBQUUsR0FBRTtDQUFDLE9BQU8sZUFBZSxHQUFFLFlBQVcsRUFBQyxPQUFNLEVBQUMsQ0FBQztBQUFDO0FBQUMsSUFBTSxLQUFHLE1BQUs7Q0FBQyxZQUFZLEdBQUU7RUFBQyxLQUFLLDZCQUFXLElBQUksWUFBWSxHQUFHLEdBQUUsS0FBSyxTQUFPLEtBQUksS0FBSyxNQUFJLEdBQUUsS0FBSyxVQUFRLEdBQUUsS0FBSyxVQUFRO0NBQUM7Q0FBQyxhQUFhLEdBQUU7RUFBQyxJQUFHLE1BQUksS0FBSyxTQUFRLE9BQU8sS0FBSztFQUFRLElBQUksSUFBRSxLQUFLO0VBQVEsSUFBRyxJQUFFLEtBQUssU0FBUSxLQUFJLElBQUksSUFBRSxLQUFLLFNBQVEsSUFBRSxHQUFFLEtBQUksS0FBRyxLQUFLLFdBQVc7T0FBUSxLQUFJLElBQUksSUFBRSxLQUFLLFVBQVEsR0FBRSxLQUFHLEdBQUUsS0FBSSxLQUFHLEtBQUssV0FBVztFQUFHLE9BQU8sS0FBSyxVQUFRLEdBQUUsS0FBSyxVQUFRLEdBQUU7Q0FBQztDQUFDLFlBQVksR0FBRSxHQUFFO0VBQUMsSUFBRyxLQUFHLEtBQUssV0FBVyxRQUFPO0dBQUMsTUFBTSxJQUFFLEtBQUssWUFBVyxJQUFFLEVBQUU7R0FBTyxJQUFJLElBQUU7R0FBRSxPQUFLLEtBQUcsSUFBRyxJQUFHLE1BQUksR0FBRSxJQUFFLEdBQUUsTUFBTSxFQUFFLElBQUcsR0FBRyxHQUFHO0dBQUUsS0FBSyxhQUFXLElBQUksWUFBWSxDQUFDLEdBQUUsS0FBSyxXQUFXLElBQUksQ0FBQyxHQUFFLEtBQUssU0FBTztHQUFFLEtBQUksSUFBSSxJQUFFLEdBQUUsSUFBRSxHQUFFLEtBQUksS0FBSyxXQUFXLEtBQUc7RUFBQztFQUFDLElBQUksSUFBRSxLQUFLLGFBQWEsSUFBRSxDQUFDLEdBQUUsSUFBRTtFQUFFLEtBQUksSUFBSSxJQUFFLEdBQUUsSUFBRSxFQUFFLFFBQU8sSUFBRSxHQUFFLEtBQUksS0FBSyxJQUFJLFdBQVcsR0FBRSxFQUFFLEVBQUUsTUFBSSxLQUFLLFdBQVcsRUFBRSxJQUFHLEtBQUk7RUFBSyxJQUFFLEtBQUcsS0FBSyxVQUFRLE1BQUksS0FBSyxXQUFTO0NBQUU7Q0FBQyxXQUFXLEdBQUU7RUFBQyxJQUFHLElBQUUsS0FBSyxRQUFPO0dBQUMsTUFBTSxJQUFFLEtBQUssV0FBVyxJQUFHLElBQUUsS0FBSyxhQUFhLENBQUMsR0FBRSxJQUFFLElBQUU7R0FBRSxLQUFLLFdBQVcsS0FBRztHQUFFLEtBQUksSUFBSSxJQUFFLEdBQUUsSUFBRSxHQUFFLEtBQUksS0FBSyxJQUFJLFdBQVcsQ0FBQztHQUFFLElBQUUsS0FBRyxLQUFLLFVBQVEsTUFBSSxLQUFLLFdBQVM7RUFBRTtDQUFDO0NBQUMsU0FBUyxHQUFFO0VBQUMsSUFBSSxJQUFFO0VBQUcsSUFBRyxLQUFHLEtBQUssVUFBUSxNQUFJLEtBQUssV0FBVyxJQUFHLE9BQU87RUFBRSxNQUFNLElBQUUsS0FBSyxXQUFXLElBQUcsSUFBRSxLQUFLLGFBQWEsQ0FBQyxHQUFFLElBQUUsSUFBRTtFQUFFLEtBQUksSUFBSSxJQUFFLEdBQUUsSUFBRSxHQUFFLEtBQUksS0FBRyxLQUFLLElBQUksUUFBUSxDQUFDLElBQUU7RUFBRSxPQUFPO0NBQUM7QUFBQztBQUFFLElBQUEsS0FBRyxTQUFTLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRTtBQUFJLElBQUEsS0FBRyxJQUFJLE9BQU8sSUFBSSxFQUFFLDZDQUE2QztBQUFFLElBQUEsTUFBRyxNQUFHLGVBQWEsT0FBTyxjQUFZLGFBQWEsY0FBWSxVQUFTLEtBQUcsT0FBSyxFQUFFO0FBQVMsSUFBQSxNQUFHLE1BQUc7Q0FBQyxJQUFHLENBQUMsR0FBRSxPQUFPO0NBQVMsSUFBRyxHQUFHLENBQUMsR0FBRSxPQUFPO0NBQUUsSUFBRyxpQkFBZ0IsR0FBRTtFQUFDLE1BQU0sSUFBRSxFQUFFLFlBQVk7RUFBRSxJQUFHLEdBQUcsQ0FBQyxHQUFFLE9BQU87Q0FBQztDQUFDLE9BQU87QUFBUTtBQUFFLElBQUEsTUFBSSxHQUFFLEdBQUUsTUFBSTtDQUFDLE1BQU0sSUFBRSxFQUFFLE1BQU0sR0FBRztDQUFFLElBQUk7Q0FBRSxLQUFJLElBQUksSUFBRSxHQUFFLElBQUUsRUFBRSxRQUFPLElBQUUsR0FBRSxLQUFJLENBQUMsSUFBRSxFQUFFLE9BQUssRUFBRSxhQUFhLEdBQUUsQ0FBQztBQUFDO0FBQUUsSUFBQSxNQUFJLEdBQUUsTUFBSTtDQUFDLElBQUk7Q0FBRSxNQUFNLEtBQUcsVUFBUSxJQUFFLEVBQUUsZ0JBQWMsS0FBSyxNQUFJLElBQUUsSUFBRSxHQUFBLENBQUksTUFBTSxDQUFDLEdBQUUsSUFBRSxDQUFDO0NBQUUsS0FBSSxJQUFJLElBQUUsR0FBRSxJQUFFLEVBQUUsUUFBTyxJQUFFLEdBQUUsS0FBSTtFQUFDLE1BQU0sSUFBRSxFQUFFLEVBQUUsQ0FBQyxLQUFLO0VBQUUsSUFBRyxDQUFDLEdBQUU7RUFBUyxNQUFNLElBQUUsRUFBRSxNQUFNLEVBQUU7RUFBRSxJQUFHLEdBQUU7R0FBQyxNQUFNLElBQUUsSUFBRSxTQUFTLEVBQUUsSUFBRyxFQUFFLEdBQUUsSUFBRSxFQUFFO0dBQUcsTUFBSSxNQUFJLEVBQUUsR0FBRSxDQUFDLEdBQUUsR0FBRyxHQUFFLEdBQUUsRUFBRSxFQUFFLEdBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQyxZQUFZLEdBQUUsQ0FBQyxJQUFHLEVBQUUsU0FBTztFQUFDLE9BQU0sRUFBRSxLQUFLLENBQUM7Q0FBQztBQUFDO0FBQUUsSUFBQSxNQUFHLE1BQUc7Q0FBQyxNQUFNLElBQUUsR0FBRyxFQUFFLFFBQVEsTUFBTSxDQUFDLENBQUMsaUJBQWlCLEVBQUU7Q0FBRSxLQUFJLElBQUksSUFBRSxHQUFFLElBQUUsRUFBRSxRQUFPLElBQUUsR0FBRSxLQUFJO0VBQUMsTUFBTSxJQUFFLEVBQUU7RUFBRyxLQUFHLEVBQUUsYUFBYSxDQUFDLE1BQUksTUFBSSxHQUFHLEdBQUUsQ0FBQyxHQUFFLEVBQUUsY0FBWSxFQUFFLFdBQVcsWUFBWSxDQUFDO0NBQUU7QUFBQztBQUFFLElBQUksS0FBRyxDQUFDO0FBQUUsU0FBUyxLQUFJO0NBQUMsSUFBRyxDQUFDLE1BQUksSUFBRyxPQUFPO0NBQUcsSUFBRyxlQUFhLE9BQU8sVUFBUztFQUFDLE1BQU0sSUFBRSxTQUFTLEtBQUssY0FBYyw4QkFBNEI7RUFBRSxJQUFHLEdBQUUsT0FBTyxLQUFHLEVBQUUsU0FBTyxFQUFFLGFBQWEsU0FBUyxLQUFHLEtBQUs7RUFBRSxNQUFNLElBQUUsU0FBUyxLQUFLLGNBQWMseUJBQXVCO0VBQUUsSUFBRyxHQUFFLE9BQU8sS0FBRyxFQUFFLGFBQWEsU0FBUyxLQUFHLEtBQUs7Q0FBQztDQUFDLE9BQU8sS0FBRyxlQUFhLE9BQU8sb0JBQWtCLG9CQUFrQixLQUFLO0FBQUM7QUFBQyxJQUFNLE1BQUksR0FBRSxNQUFJO0NBQUMsTUFBTSxJQUFFLFNBQVMsTUFBSyxJQUFFLEtBQUcsR0FBRSxJQUFFLFNBQVMsY0FBYyxPQUFPLEdBQUUsTUFBRyxNQUFHO0VBQUMsTUFBTSxJQUFFLE1BQU0sS0FBSyxFQUFFLGlCQUFpQixTQUFTLEVBQUUsRUFBRSxDQUFDO0VBQUUsT0FBTyxFQUFFLEVBQUUsU0FBTztDQUFFLEVBQUEsQ0FBRyxDQUFDLEdBQUUsSUFBRSxLQUFLLE1BQUksSUFBRSxFQUFFLGNBQVk7Q0FBSyxFQUFFLGFBQWEsR0FBRSxDQUFDLEdBQUUsRUFBRSxhQUFhLEdBQUUsQ0FBQztDQUFFLE1BQU0sSUFBRSxLQUFHLEdBQUc7Q0FBRSxPQUFPLEtBQUcsRUFBRSxhQUFhLFNBQVEsQ0FBQyxHQUFFLEVBQUUsYUFBYSxHQUFFLENBQUMsR0FBRTtBQUFDO0FBQUUsSUFBQSxLQUFHLE1BQUs7Q0FBQyxZQUFZLEdBQUUsR0FBRTtFQUFDLEtBQUssVUFBUSxHQUFHLEdBQUUsQ0FBQyxHQUFFLEtBQUssUUFBUSxZQUFZLFNBQVMsZUFBZSxFQUFFLENBQUMsR0FBRSxLQUFLLFVBQU8sTUFBRztHQUFDLElBQUk7R0FBRSxJQUFHLEVBQUUsT0FBTSxPQUFPLEVBQUU7R0FBTSxNQUFNLElBQUUsVUFBUSxJQUFFLEVBQUUsWUFBWSxDQUFDLENBQUMsZ0JBQWMsS0FBSyxNQUFJLElBQUUsSUFBRSxTQUFTO0dBQVksS0FBSSxJQUFJLElBQUUsR0FBRSxJQUFFLEVBQUUsUUFBTyxJQUFFLEdBQUUsS0FBSTtJQUFDLE1BQU0sSUFBRSxFQUFFO0lBQUcsSUFBRyxFQUFFLGNBQVksR0FBRSxPQUFPO0dBQUM7R0FBQyxNQUFNLEVBQUUsRUFBRTtFQUFDLEVBQUEsQ0FBRyxLQUFLLE9BQU8sR0FBRSxLQUFLLFNBQU87Q0FBQztDQUFDLFdBQVcsR0FBRSxHQUFFO0VBQUMsSUFBRztHQUFDLE9BQU8sS0FBSyxNQUFNLFdBQVcsR0FBRSxDQUFDLEdBQUUsS0FBSyxVQUFTLENBQUM7RUFBQyxTQUFPLEdBQUU7R0FBQyxPQUFNLENBQUM7RUFBQztDQUFDO0NBQUMsV0FBVyxHQUFFO0VBQUMsS0FBSyxNQUFNLFdBQVcsQ0FBQyxHQUFFLEtBQUs7Q0FBUTtDQUFDLFFBQVEsR0FBRTtFQUFDLE1BQU0sSUFBRSxLQUFLLE1BQU0sU0FBUztFQUFHLE9BQU8sS0FBRyxFQUFFLFVBQVEsRUFBRSxVQUFRO0NBQUU7QUFBQztBQUFFLElBQUEsS0FBRyxNQUFLO0NBQUMsWUFBWSxHQUFFLEdBQUU7RUFBQyxLQUFLLFVBQVEsR0FBRyxHQUFFLENBQUMsR0FBRSxLQUFLLFFBQU0sS0FBSyxRQUFRLFlBQVcsS0FBSyxTQUFPO0NBQUM7Q0FBQyxXQUFXLEdBQUUsR0FBRTtFQUFDLElBQUcsS0FBRyxLQUFLLFVBQVEsS0FBRyxHQUFFO0dBQUMsTUFBTSxJQUFFLFNBQVMsZUFBZSxDQUFDO0dBQUUsT0FBTyxLQUFLLFFBQVEsYUFBYSxHQUFFLEtBQUssTUFBTSxNQUFJLElBQUksR0FBRSxLQUFLLFVBQVMsQ0FBQztFQUFDO0VBQUMsT0FBTSxDQUFDO0NBQUM7Q0FBQyxXQUFXLEdBQUU7RUFBQyxLQUFLLFFBQVEsWUFBWSxLQUFLLE1BQU0sRUFBRSxHQUFFLEtBQUs7Q0FBUTtDQUFDLFFBQVEsR0FBRTtFQUFDLE9BQU8sSUFBRSxLQUFLLFNBQU8sS0FBSyxNQUFNLEVBQUUsQ0FBQyxjQUFZO0NBQUU7QUFBQztBQUFFLElBQUksS0FBRztBQUFFLElBQU0sS0FBRztDQUFDLFVBQVMsQ0FBQztDQUFFLG1CQUFrQixDQUFDO0FBQUM7QUFBRSxJQUFNLEtBQU4sTUFBTSxHQUFFO0NBQUMsT0FBTyxXQUFXLEdBQUU7RUFBQyxPQUFPLEVBQUUsQ0FBQztDQUFDO0NBQUMsWUFBWSxJQUFFLEdBQUUsSUFBRSxDQUFDLEdBQUUsR0FBRTtFQUFDLEtBQUssVUFBUSxPQUFPLE9BQU8sT0FBTyxPQUFPLENBQUMsR0FBRSxFQUFFLEdBQUUsQ0FBQyxHQUFFLEtBQUssS0FBRyxHQUFFLEtBQUssOEJBQVksSUFBSSxJQUFFLEdBQUUsS0FBSyxRQUFNLElBQUksSUFBSSxDQUFDLEdBQUUsS0FBSyxTQUFPLENBQUMsQ0FBQyxFQUFFLFVBQVMsQ0FBQyxLQUFLLFVBQVEsS0FBRyxPQUFLLEtBQUcsQ0FBQyxHQUFFLEdBQUcsSUFBSSxJQUFHLEdBQUcsY0FBVSxNQUFHO0dBQUMsTUFBTSxJQUFFLEVBQUUsT0FBTyxHQUFFLEVBQUMsUUFBTyxNQUFHO0dBQUUsSUFBSSxJQUFFO0dBQUcsS0FBSSxJQUFJLElBQUUsR0FBRSxJQUFFLEdBQUUsS0FBSTtJQUFDLE1BQU0sSUFBRSxFQUFFLENBQUM7SUFBRSxJQUFHLEtBQUssTUFBSSxHQUFFO0lBQVMsTUFBTSxJQUFFLEVBQUUsTUFBTSxJQUFJLENBQUM7SUFBRSxJQUFHLEtBQUssTUFBSSxLQUFHLENBQUMsRUFBRSxNQUFLO0lBQVMsTUFBTSxJQUFFLEVBQUUsU0FBUyxDQUFDO0lBQUUsSUFBRyxNQUFJLEVBQUUsUUFBTztJQUFTLE1BQU0sSUFBRSxJQUFFLE9BQUssSUFBRSxXQUFRLElBQUU7SUFBSyxJQUFJLElBQUU7SUFBRyxLQUFJLE1BQU0sS0FBSyxHQUFFLEVBQUUsU0FBTyxNQUFJLEtBQUcsSUFBRTtJQUFLLEtBQUcsSUFBRSxJQUFFLGdCQUFhLElBQUU7R0FBTTtHQUFDLE9BQU87RUFBQyxFQUFBLENBQUcsSUFBSSxDQUFDO0NBQUM7Q0FBQyxZQUFXO0VBQUMsQ0FBQyxLQUFLLFVBQVEsS0FBRyxHQUFHLElBQUk7Q0FBQztDQUFDLHVCQUF1QixHQUFFLElBQUUsQ0FBQyxHQUFFO0VBQUMsTUFBTSxJQUFFLElBQUksR0FBRyxPQUFPLE9BQU8sT0FBTyxPQUFPLENBQUMsR0FBRSxLQUFLLE9BQU8sR0FBRSxDQUFDLEdBQUUsS0FBSyxJQUFHLEtBQUcsS0FBSyxTQUFPLEtBQUssQ0FBQztFQUFFLE9BQU8sRUFBRSxjQUFZLElBQUksSUFBSSxLQUFLLFdBQVcsR0FBRSxDQUFDLEtBQUssVUFBUSxLQUFHLEVBQUUsV0FBUyxLQUFLLFFBQVEsVUFBUSxHQUFHLEtBQUssUUFBUSxNQUFNLE1BQUksR0FBRyxFQUFFLE1BQU0sS0FBRyxHQUFHLENBQUMsR0FBRTtDQUFDO0NBQUMsbUJBQW1CLEdBQUU7RUFBQyxPQUFPLEtBQUssR0FBRyxNQUFJLEtBQUssR0FBRyxNQUFJLEtBQUc7Q0FBQztDQUFDLFNBQVE7RUFBQyxPQUFPLEtBQUssUUFBTSxLQUFLLE9BQUssTUFBSSxFQUFDLG1CQUFrQixHQUFFLFFBQU8sR0FBRSxPQUFNLFFBQUssSUFBRSxJQUFJLEdBQUcsR0FBRSxDQUFDLElBQUUsSUFBSSxHQUFHLEdBQUUsQ0FBQyxFQUFBLENBQUcsS0FBSyxPQUFPLEdBQUUsSUFBSSxHQUFHLENBQUM7TUFBUTtDQUFDO0NBQUMsYUFBYSxHQUFFLEdBQUU7RUFBQyxJQUFJLEdBQUU7RUFBRSxPQUFPLFVBQVEsSUFBRSxVQUFRLElBQUUsS0FBSyxNQUFNLElBQUksQ0FBQyxNQUFJLEtBQUssTUFBSSxJQUFFLEtBQUssSUFBRSxFQUFFLElBQUksQ0FBQyxNQUFJLEtBQUssTUFBSSxLQUFHO0NBQUM7Q0FBQyxhQUFhLEdBQUUsR0FBRTtFQUFDLEVBQUUsQ0FBQyxHQUFFLEVBQUUsV0FBVyxDQUFDLEtBQUcsS0FBSyxZQUFZLElBQUksQ0FBQztFQUFFLE1BQU0sSUFBRSxLQUFLLE1BQU0sSUFBSSxDQUFDO0VBQUUsSUFBRSxFQUFFLElBQUksQ0FBQyxJQUFFLEtBQUssTUFBTSxJQUFJLG1CQUFFLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0NBQUM7Q0FBQyxZQUFZLEdBQUUsR0FBRSxHQUFFO0VBQUMsS0FBSyxhQUFhLEdBQUUsQ0FBQyxHQUFFLEtBQUssT0FBTyxDQUFDLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRSxDQUFDO0NBQUM7Q0FBQyxXQUFXLEdBQUU7RUFBQyxLQUFLLE1BQU0sSUFBSSxDQUFDLEtBQUcsS0FBSyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTTtDQUFDO0NBQUMsV0FBVyxHQUFFO0VBQUMsS0FBSyxPQUFPLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLEdBQUUsS0FBSyxXQUFXLENBQUM7Q0FBQztDQUFDLFdBQVU7RUFBQyxLQUFLLE1BQUksS0FBSztDQUFDO0FBQUM7QUFBQyxJQUFNLHFCQUFHLElBQUksUUFBTTtBQUFFLElBQUEsS0FBRztDQUFDLHlCQUF3QjtDQUFFLGFBQVk7Q0FBRSxtQkFBa0I7Q0FBRSxrQkFBaUI7Q0FBRSxrQkFBaUI7Q0FBRSxhQUFZO0NBQUUsU0FBUTtDQUFFLE1BQUs7Q0FBRSxVQUFTO0NBQUUsWUFBVztDQUFFLFNBQVE7Q0FBRSxZQUFXO0NBQUUsYUFBWTtDQUFFLGNBQWE7Q0FBRSxZQUFXO0NBQUUsZUFBYztDQUFFLGdCQUFlO0NBQUUsaUJBQWdCO0NBQUUsWUFBVztDQUFFLFlBQVc7Q0FBRSxTQUFRO0NBQUUsT0FBTTtDQUFFLFNBQVE7Q0FBRSxPQUFNO0NBQUUsU0FBUTtDQUFFLFFBQU87Q0FBRSxRQUFPO0NBQUUsTUFBSztDQUFFLGlCQUFnQjtDQUFFLGFBQVk7Q0FBRSxjQUFhO0NBQUUsYUFBWTtDQUFFLGlCQUFnQjtDQUFFLGtCQUFpQjtDQUFFLGtCQUFpQjtDQUFFLGVBQWM7Q0FBRSxhQUFZO0FBQUM7QUFBRSxTQUFTLEdBQUcsR0FBRSxHQUFFO0NBQUMsT0FBTyxRQUFNLEtBQUcsYUFBVyxPQUFPLEtBQUcsT0FBSyxJQUFFLEtBQUcsWUFBVSxPQUFPLEtBQUcsTUFBSSxLQUFHLEtBQUssTUFBSSxFQUFFLFdBQVcsSUFBSSxJQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFFLElBQUU7QUFBSTtBQUFDLElBQU0sS0FBRztBQUFHLFNBQVMsR0FBRyxHQUFFO0NBQUMsSUFBRyxPQUFLLEVBQUUsV0FBVyxDQUFDLEtBQUcsT0FBSyxFQUFFLFdBQVcsQ0FBQyxHQUFFLE9BQU87Q0FBRSxJQUFJLElBQUU7Q0FBRyxLQUFJLElBQUksSUFBRSxHQUFFLElBQUUsRUFBRSxRQUFPLEtBQUk7RUFBQyxNQUFNLElBQUUsRUFBRSxXQUFXLENBQUM7RUFBRSxLQUFHLEtBQUcsTUFBSSxLQUFHLEtBQUcsTUFBSSxPQUFPLGFBQWEsSUFBRSxFQUFFLElBQUUsRUFBRTtDQUFFO0NBQUMsT0FBTyxFQUFFLFdBQVcsS0FBSyxJQUFFLE1BQUksSUFBRTtBQUFDO0FBQUMsSUFBTSxLQUFHLE9BQU8sSUFBSSxjQUFjO0FBQUUsU0FBUyxHQUFHLEdBQUU7Q0FBQyxPQUFNLFlBQVUsT0FBTyxLQUFHLFNBQU8sS0FBRyxNQUFNO0FBQUM7QUFBQyxTQUFTLEdBQUcsR0FBRTtDQUFDLE9BQU8sR0FBRyxDQUFDLEtBQUcsRUFBRSxFQUFFLGFBQVcsRUFBRSxVQUFVO0FBQWlCO0FBQUMsSUFBTSxNQUFHLE1BQUcsUUFBTSxLQUFHLENBQUMsTUFBSSxLQUFHLE9BQUs7QUFBRSxJQUFBLEtBQUcsT0FBTyxJQUFJLHdCQUF3QjtBQUFFLFNBQVMsR0FBRyxHQUFFO0NBQUMsT0FBTyxFQUFFLGFBQVc7QUFBRTtBQUFDLFNBQVMsR0FBRyxHQUFFO0NBQUMsTUFBTSxJQUFFLEVBQUUsTUFBSyxLQUFHLEtBQUcsRUFBRSxTQUFTLEdBQUcsSUFBRSxFQUFFLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSSxJQUFFLE1BQUksRUFBRSxRQUFNO0NBQVUsUUFBUSxLQUFLLHFDQUFxQyxFQUFFLGdQQUFnUDtBQUFDO0FBQUMsU0FBUyxHQUFHLEdBQUUsR0FBRTtDQUFDLEtBQUksTUFBTSxLQUFLLEdBQUU7RUFBQyxNQUFNLElBQUUsRUFBRTtFQUFHLEVBQUUsZUFBZSxDQUFDLEtBQUcsQ0FBQyxHQUFHLENBQUMsTUFBSSxNQUFNLFFBQVEsQ0FBQyxLQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUcsR0FBRyxDQUFDLElBQUUsRUFBRSxLQUFLLEdBQUcsQ0FBQyxJQUFFLEtBQUksR0FBRSxHQUFHLElBQUUsR0FBRyxDQUFDLEtBQUcsRUFBRSxLQUFLLElBQUUsSUFBSSxHQUFFLEdBQUcsR0FBRSxDQUFDLEdBQUUsRUFBRSxLQUFLLEdBQUcsS0FBRyxFQUFFLEtBQUssR0FBRyxDQUFDLElBQUUsT0FBSyxHQUFHLEdBQUUsQ0FBQyxJQUFFLEdBQUc7Q0FBRTtBQUFDO0FBQUMsU0FBUyxHQUFHLEdBQUUsR0FBRSxHQUFFLEdBQUUsSUFBRSxDQUFDLEdBQUU7Q0FBQyxJQUFHLEdBQUcsQ0FBQyxHQUFFLE9BQU87Q0FBRSxNQUFNLElBQUUsT0FBTztDQUFFLElBQUcsYUFBVyxHQUFFLE9BQU8sRUFBRSxLQUFLLENBQUMsR0FBRTtDQUFFLElBQUcsZUFBYSxHQUFFO0VBQUMsSUFBRyxHQUFHLENBQUMsR0FBRSxPQUEyQyxHQUFHLENBQUMsR0FBRTtFQUFFLElBQUcsR0FBRyxDQUFDLEtBQUcsR0FBRTtHQUFDLE1BQU0sSUFBRSxFQUFFLENBQUM7R0FBRSxPQUEyQyxZQUFVLE9BQU8sS0FBRyxNQUFNLFFBQVEsQ0FBQyxLQUFHLEdBQUcsQ0FBQyxLQUFHLEdBQUcsQ0FBQyxLQUFHLFNBQU8sS0FBRyxRQUFRLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFBRSw2S0FBNkssR0FBRSxHQUFHLEdBQUUsR0FBRSxHQUFFLEdBQUUsQ0FBQztFQUFDO0VBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxHQUFFO0NBQUM7Q0FBQyxJQUFHLE1BQU0sUUFBUSxDQUFDLEdBQUU7RUFBQyxLQUFJLElBQUksSUFBRSxHQUFFLElBQUUsRUFBRSxRQUFPLEtBQUksR0FBRyxFQUFFLElBQUcsR0FBRSxHQUFFLEdBQUUsQ0FBQztFQUFFLE9BQU87Q0FBQztDQUFDLE9BQU8sR0FBRyxDQUFDLEtBQUcsRUFBRSxLQUFLLElBQUksRUFBRSxtQkFBbUIsR0FBRSxLQUFHLEdBQUcsQ0FBQyxLQUFHLEtBQUcsRUFBRSxPQUFPLEdBQUUsQ0FBQyxHQUFFLEVBQUUsS0FBSyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEtBQUcsRUFBRSxLQUFLLENBQUMsR0FBRSxLQUFHLEdBQUcsQ0FBQyxLQUF3QyxHQUFHLENBQUMsR0FBRSxLQUFHLEdBQUcsQ0FBQyxJQUFFLEVBQUUsYUFBVyxPQUFPLFVBQVUsWUFBVSxFQUFFLEtBQUssRUFBRSxTQUFTLENBQUMsR0FBRSxNQUFJLEdBQUcsR0FBRSxDQUFDLEdBQUUsTUFBSSxFQUFFLEtBQUssRUFBRSxTQUFTLENBQUMsR0FBRTtBQUFFO0FBQUMsSUFBTSxLQUFHLEVBQUUsQ0FBQztBQUFFLElBQU0sS0FBTixNQUFRO0NBQUMsWUFBWSxHQUFFLEdBQUUsR0FBRTtFQUFDLEtBQUssUUFBTSxHQUFFLEtBQUssY0FBWSxHQUFFLEtBQUssV0FBUyxFQUFFLElBQUcsQ0FBQyxHQUFFLEtBQUssWUFBVSxHQUFFLEdBQUcsV0FBVyxDQUFDO0NBQUM7Q0FBQyx3QkFBd0IsR0FBRSxHQUFFLEdBQUU7RUFBQyxJQUFJLElBQUUsS0FBSyxZQUFVLEtBQUssVUFBVSx3QkFBd0IsR0FBRSxHQUFFLENBQUMsSUFBRTtFQUFHO0dBQUMsSUFBSSxJQUFFO0dBQUcsS0FBSSxJQUFJLElBQUUsR0FBRSxJQUFFLEtBQUssTUFBTSxRQUFPLEtBQUk7SUFBQyxNQUFNLElBQUUsS0FBSyxNQUFNO0lBQUcsSUFBRyxZQUFVLE9BQU8sR0FBRSxLQUFHO1NBQU8sSUFBRyxHQUFFLElBQUcsR0FBRyxDQUFDLEdBQUU7S0FBQyxNQUFNLElBQUUsRUFBRSxDQUFDO0tBQUUsWUFBVSxPQUFPLElBQUUsS0FBRyxJQUFFLFFBQU0sS0FBRyxDQUFDLE1BQUksTUFBeUMsWUFBVSxPQUFPLEtBQUcsTUFBTSxRQUFRLENBQUMsS0FBRyxHQUFHLENBQUMsS0FBRyxHQUFHLENBQUMsS0FBRyxRQUFRLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFBRSw2S0FBNkssR0FBRSxLQUFHLEdBQUcsR0FBRyxHQUFFLEdBQUUsR0FBRSxDQUFDLENBQUM7SUFBRSxPQUFNLEtBQUcsR0FBRyxHQUFHLEdBQUUsR0FBRSxHQUFFLENBQUMsQ0FBQztHQUFDO0dBQUMsSUFBRyxHQUFFO0lBQUMsS0FBSyxxQkFBbUIsS0FBSyxtQ0FBaUIsSUFBSSxJQUFFO0lBQUcsTUFBTSxJQUFFLEVBQUUsT0FBSyxFQUFFLE9BQUssSUFBRTtJQUFFLElBQUksSUFBRSxLQUFLLGlCQUFpQixJQUFJLENBQUM7SUFBRSxJQUFHLENBQUMsR0FBRTtLQUFDLElBQUcsSUFBRSxFQUFFLEVBQUUsRUFBRSxLQUFLLFVBQVMsRUFBRSxJQUFJLEdBQUUsQ0FBQyxNQUFJLENBQUMsR0FBRSxLQUFLLGlCQUFpQixRQUFNLEtBQUk7TUFBQyxNQUFNLElBQUUsS0FBSyxpQkFBaUIsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7TUFBTSxLQUFLLE1BQUksS0FBRyxLQUFLLGlCQUFpQixPQUFPLENBQUM7S0FBQztLQUFDLEtBQUssaUJBQWlCLElBQUksR0FBRSxDQUFDO0lBQUM7SUFBQyxJQUFHLENBQUMsRUFBRSxhQUFhLEtBQUssYUFBWSxDQUFDLEdBQUU7S0FBQyxNQUFNLElBQUUsRUFBRSxHQUFFLE1BQUksR0FBRSxLQUFLLEdBQUUsS0FBSyxXQUFXO0tBQUUsRUFBRSxZQUFZLEtBQUssYUFBWSxHQUFFLENBQUM7SUFBQztJQUFDLElBQUUsR0FBRyxHQUFFLENBQUM7R0FBQztFQUFDO0VBQUMsT0FBTztDQUFDO0FBQUM7QUFBQyxJQUFNLEtBQUc7QUFBSyxTQUFTLEdBQUcsR0FBRSxHQUFFO0NBQUMsSUFBSSxJQUFFO0NBQUUsT0FBSyxFQUFFLEtBQUcsS0FBRyxPQUFLLEVBQUUsV0FBVyxDQUFDLElBQUc7Q0FBSSxPQUFNLEVBQUUsSUFBRSxDQUFDO0FBQUU7QUFBQyxTQUFTLEdBQUcsR0FBRTtDQUFDLE1BQU0sSUFBRSxFQUFFO0NBQU8sSUFBSSxJQUFFLElBQUcsSUFBRSxHQUFFLElBQUUsR0FBRSxJQUFFLEdBQUUsSUFBRSxDQUFDLEdBQUUsSUFBRSxDQUFDO0NBQUUsS0FBSSxJQUFJLElBQUUsR0FBRSxJQUFFLEdBQUUsS0FBSTtFQUFDLE1BQU0sSUFBRSxFQUFFLFdBQVcsQ0FBQztFQUFFLElBQUcsTUFBSSxLQUFHLEtBQUcsTUFBSSxNQUFJLE9BQUssRUFBRSxXQUFXLElBQUUsQ0FBQyxHQUFFLElBQUcsR0FBRSxPQUFLLEtBQUcsRUFBRSxXQUFXLElBQUUsQ0FBQyxNQUFJLE9BQUssSUFBRSxDQUFDLEdBQUU7T0FBVSxJQUFHLE9BQUssS0FBRyxPQUFLLEtBQUcsR0FBRyxHQUFFLENBQUMsR0FBTTtPQUFBLE1BQUksR0FBRSxJQUFHLFFBQU0sR0FBRTtRQUFTLElBQUcsUUFBTSxHQUFFO0lBQUMsSUFBRyxLQUFJLElBQUUsR0FBRTtLQUFDLElBQUUsQ0FBQztLQUFFLElBQUksSUFBRSxJQUFFO0tBQUUsT0FBSyxJQUFFLElBQUc7TUFBQyxNQUFNLElBQUUsRUFBRSxXQUFXLENBQUM7TUFBRSxJQUFHLE9BQUssS0FBRyxPQUFLLEdBQUU7TUFBTTtLQUFHO0tBQUMsSUFBRSxLQUFHLE9BQUssRUFBRSxXQUFXLENBQUMsS0FBRyxLQUFJLElBQUUsR0FBRSxJQUFFLElBQUUsR0FBRSxJQUFFO0tBQUU7SUFBUTtJQUFDLE1BQUksTUFBSSxLQUFHLEVBQUUsVUFBVSxHQUFFLElBQUUsQ0FBQyxHQUFFLElBQUUsSUFBRTtHQUFFLE9BQU0sT0FBSyxLQUFHLE1BQUksTUFBSSxLQUFHLEVBQUUsVUFBVSxHQUFFLElBQUUsQ0FBQyxHQUFFLElBQUUsSUFBRTtFQUFBLE9BQVEsTUFBSSxJQUFFLElBQUUsSUFBRSxNQUFJLE1BQUksSUFBRTtPQUFRLElBQUUsQ0FBQyxHQUFFO0NBQUc7Q0FBQyxPQUFPLEtBQUcsTUFBSSxLQUFHLE1BQUksS0FBRyxJQUFFLEtBQUcsTUFBSSxLQUFHLE1BQUksTUFBSSxLQUFHLEVBQUUsVUFBVSxDQUFDLElBQUcsS0FBRztBQUFDO0FBQUMsU0FBUyxHQUFHLEdBQUUsR0FBRTtDQUFDLE1BQU0sSUFBRSxJQUFFLEtBQUksSUFBRSxNQUFJO0NBQUUsS0FBSSxJQUFJLElBQUUsR0FBRSxJQUFFLEVBQUUsUUFBTyxLQUFJO0VBQUMsTUFBTSxJQUFFLEVBQUU7RUFBRyxJQUFHLFdBQVMsRUFBRSxNQUFLO0dBQUMsRUFBRSxTQUFPLElBQUUsRUFBRSxNQUFBLENBQU8sV0FBVyxLQUFJLENBQUM7R0FBRSxNQUFNLElBQUUsRUFBRSxPQUFNLElBQUUsQ0FBQztHQUFFLEtBQUksSUFBSSxJQUFFLEdBQUUsSUFBRSxFQUFFLFFBQU8sS0FBSSxFQUFFLEtBQUcsSUFBRSxFQUFFO0dBQUcsRUFBRSxRQUFNO0VBQUM7RUFBQyxNQUFNLFFBQVEsRUFBRSxRQUFRLEtBQUcsaUJBQWUsRUFBRSxRQUFNLEdBQUcsRUFBRSxVQUFTLENBQUM7Q0FBQztDQUFDLE9BQU87QUFBQztBQUFDLFNBQVMsR0FBRyxFQUFDLFNBQVEsSUFBRSxHQUFFLFNBQVEsSUFBRSxNQUFHLEdBQUU7Q0FBQyxJQUFJLEdBQUUsR0FBRTtDQUFFLE1BQU0sS0FBRyxHQUFFLEdBQUUsTUFBSSxFQUFFLFdBQVcsQ0FBQyxLQUFHLEVBQUUsU0FBUyxDQUFDLEtBQUcsRUFBRSxXQUFXLEdBQUUsRUFBRSxDQUFDLENBQUMsU0FBTyxJQUFFLElBQUksTUFBSSxHQUFFLElBQUUsRUFBRSxNQUFNO0NBQUUsRUFBRSxNQUFLLE1BQUc7RUFBQyxFQUFFLFNBQU8sVUFBVyxFQUFFLE1BQU0sU0FBUyxHQUFHLE1BQUksTUFBSSxJQUFFLElBQUksT0FBTyxLQUFLLEVBQUUsTUFBSyxHQUFHLElBQUcsRUFBRSxNQUFNLEtBQUcsRUFBRSxNQUFNLEVBQUUsQ0FBQyxRQUFRLElBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFFLENBQUM7Q0FBRSxDQUFDLEdBQUUsRUFBRSxVQUFRLEVBQUUsS0FBS0EsUUFBVSxHQUFFLEVBQUUsS0FBS0MsU0FBVztDQUFFLElBQUksSUFBRSxDQUFDO0NBQUUsTUFBTSxJQUFFQyxXQUFhLEVBQUUsT0FBT0MsV0FBWSxNQUFHLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUUsS0FBRyxHQUFFLElBQUUsSUFBRyxJQUFFLElBQUcsSUFBRSxRQUFNO0VBQUMsSUFBRSxHQUFFLElBQUUsR0FBRSxJQUFFLEtBQUs7RUFBRSxNQUFNLElBQUUsU0FBUyxHQUFFO0dBQUMsTUFBTSxJQUFFLE9BQUssRUFBRSxRQUFRLElBQUksR0FBRSxJQUFFLE9BQUssRUFBRSxRQUFRLEdBQUc7R0FBRSxJQUFHLENBQUMsS0FBRyxDQUFDLEdBQUUsT0FBTztHQUFFLElBQUcsQ0FBQyxHQUFFLE9BQU8sR0FBRyxDQUFDO0dBQUUsTUFBTSxJQUFFLEVBQUU7R0FBTyxJQUFJLElBQUUsSUFBRyxJQUFFLEdBQUUsSUFBRSxHQUFFLElBQUUsR0FBRSxJQUFFLEdBQUUsSUFBRSxHQUFFLElBQUUsQ0FBQztHQUFFLE9BQUssSUFBRSxJQUFHO0lBQUMsTUFBTSxJQUFFLEVBQUUsV0FBVyxDQUFDO0lBQUUsSUFBRyxPQUFLLEtBQUcsT0FBSyxLQUFHLEdBQUcsR0FBRSxDQUFDLEdBQUUsSUFBRyxNQUFJLEdBQUUsSUFBRyxNQUFJLE1BQUksSUFBRSxJQUFFLEtBQUcsT0FBSyxFQUFFLFdBQVcsSUFBRSxDQUFDLEdBQUU7S0FBQyxLQUFJLEtBQUcsR0FBRSxJQUFFLElBQUUsTUFBSSxPQUFLLEVBQUUsV0FBVyxDQUFDLEtBQUcsRUFBRSxXQUFXLElBQUUsQ0FBQyxNQUFJLE1BQUs7S0FBSSxLQUFHO0lBQUMsT0FBTSxJQUFHLE9BQUssR0FBRSxJQUFHLE9BQUssR0FBRSxJQUFHLElBQUUsR0FBRTtTQUFTLElBQUcsT0FBSyxLQUFHLElBQUUsSUFBRSxLQUFHLEVBQUUsV0FBVyxJQUFFLENBQUMsTUFBSSxJQUFHLEtBQUcsRUFBRSxVQUFVLEdBQUUsQ0FBQyxHQUFFLEtBQUcsR0FBRSxJQUFFLEdBQUUsSUFBRSxDQUFDO1NBQU8sSUFBRyxNQUFJLE1BQUksSUFBRSxJQUFFLEtBQUcsRUFBRSxXQUFXLElBQUUsQ0FBQyxNQUFJLElBQUc7S0FBQyxLQUFJLEtBQUcsRUFBRSxVQUFVLEdBQUUsQ0FBQyxHQUFFLElBQUUsS0FBRyxPQUFLLEVBQUUsV0FBVyxDQUFDLElBQUc7S0FBSSxJQUFFLEdBQUUsSUFBRSxDQUFDO0lBQUMsT0FBTSxRQUFNLElBQUUsTUFBSSxRQUFNLEtBQUcsS0FBSTtTQUFTLElBQUUsS0FBRyxLQUFJO1NBQVMsS0FBSTtTQUFTO1NBQVMsTUFBSSxJQUFFLElBQUUsSUFBRSxNQUFJLE1BQUksSUFBRSxJQUFHO0dBQUc7R0FBQyxPQUFPLEtBQUcsSUFBRSxNQUFJLEtBQUcsRUFBRSxVQUFVLENBQUMsSUFBRyxNQUFJLElBQUUsSUFBRSxHQUFHLENBQUMsS0FBRyxNQUFJLElBQUUsSUFBRSxHQUFHLENBQUM7RUFBQyxFQUFFLENBQUM7RUFBRSxJQUFJLElBQUVDLFFBQVUsS0FBRyxJQUFFLElBQUUsTUFBSSxJQUFFLFFBQU0sSUFBRSxPQUFLLENBQUM7RUFBRSxPQUFPLEVBQUUsY0FBWSxJQUFFLEdBQUcsR0FBRSxFQUFFLFNBQVMsSUFBRyxJQUFFLENBQUMsR0FBRUMsVUFBWSxHQUFFLENBQUMsR0FBRTtDQUFDLEdBQUUsSUFBRTtDQUFFLElBQUksSUFBRTtDQUFFLEtBQUksSUFBSSxJQUFFLEdBQUUsSUFBRSxFQUFFLFFBQU8sS0FBSSxFQUFFLEVBQUUsQ0FBQyxRQUFNLEVBQUUsRUFBRSxHQUFFLElBQUUsRUFBRSxHQUFFLEVBQUUsRUFBRSxDQUFDLElBQUk7Q0FBRSxPQUFPLFFBQU0sS0FBUyxFQUFFLGNBQWEsSUFBRSxFQUFFLEdBQUUsRUFBRSxTQUFTLElBQUksUUFBTSxLQUFTLEVBQUUsV0FBVSxJQUFFLEVBQUUsR0FBRSxHQUFHLElBQUcsRUFBRSxPQUFLLE1BQUksSUFBRSxFQUFFLFNBQVMsSUFBRSxJQUFHO0FBQUM7QUFBQyxJQUFNLEtBQUcsSUFBSSxHQUFDO0FBQUUsSUFBQSxLQUFHLEdBQUc7QUFBRSxJQUFBLEtBQUEsYUFBSyxjQUFjO0NBQUMsbUJBQWtCLEtBQUs7Q0FBRSxZQUFXO0NBQUcsUUFBTztDQUFHLGVBQWMsS0FBSztBQUFDLENBQUM7QUFBRSxJQUFBLEtBQUcsR0FBRztBQUFTLFNBQVMsS0FBSTtDQUFDLE9BQUEsYUFBUyxXQUFXLEVBQUU7QUFBQztBQUFDLFNBQVMsR0FBRyxHQUFFO0NBQUMsSUFBSTtDQUFFLE1BQU0sSUFBRSxHQUFHLEdBQUUsRUFBQyxZQUFXLE1BQUcsR0FBRSxJQUFBLGFBQUksY0FBWTtFQUFDLElBQUksSUFBRTtFQUFFLE9BQU8sRUFBRSxRQUFNLElBQUUsRUFBRSxRQUFNLEVBQUUsU0FBTyxJQUFFLEVBQUUsdUJBQXVCLEtBQUssTUFBSSxFQUFFLFFBQU07R0FBQyxRQUFPLEVBQUU7R0FBTyxPQUFNLEVBQUU7RUFBSyxJQUFFLEVBQUMsUUFBTyxFQUFFLE9BQU0sR0FBRSxDQUFDLENBQUMsSUFBRSxLQUFLLE1BQUksRUFBRSxVQUFRLElBQUUsRUFBRSx1QkFBdUIsRUFBQyxPQUFNLEVBQUUsTUFBSyxDQUFDLElBQUcsRUFBRSwwQkFBd0IsSUFBRSxFQUFFLHVCQUF1QixFQUFDLG1CQUFrQixDQUFDLEVBQUMsQ0FBQyxJQUFHO0NBQUMsR0FBRTtFQUFDLEVBQUU7RUFBc0IsRUFBRTtFQUFNLEVBQUU7RUFBTSxFQUFFO0VBQU87Q0FBQyxDQUFDLEdBQUUsSUFBQSxhQUFJLGNBQVk7RUFBQyxJQUFJO0VBQUUsT0FBTyxLQUFLLE1BQUksRUFBRSxpQkFBZSxLQUFLLE1BQUksRUFBRSxhQUFXLEtBQUssTUFBSSxFQUFFLHVCQUFxQixFQUFFLFNBQU8sR0FBRztHQUFDLFNBQVE7SUFBQyxXQUFVLEVBQUU7SUFBVSxRQUFPLEVBQUU7R0FBb0I7R0FBRSxTQUFRLFVBQVEsSUFBRSxFQUFFLGtCQUFnQixLQUFLLE1BQUksSUFBRSxJQUFFLEVBQUU7RUFBYSxDQUFDO0NBQUMsR0FBRTtFQUFDLEVBQUU7RUFBcUIsRUFBRTtFQUFVLEVBQUU7RUFBYyxFQUFFO0VBQU8sRUFBRTtDQUFhLENBQUMsR0FBRSxJQUFFLHVCQUFzQixJQUFFLEVBQUUsb0JBQWtCLEVBQUUsbUJBQWtCLElBQUUsVUFBUSxJQUFFLEVBQUUsa0JBQWdCLEtBQUssTUFBSSxJQUFFLElBQUUsRUFBRSxlQUFjLElBQUEsYUFBSSxlQUFhO0VBQUMsbUJBQWtCO0VBQUUsWUFBVztFQUFFLFFBQU87RUFBRSxlQUFjO0NBQUMsSUFBRztFQUFDO0VBQUU7RUFBRTtFQUFFO0NBQUMsQ0FBQztDQUFFLE9BQUEsYUFBUyxjQUFjLEdBQUcsVUFBUyxFQUFDLE9BQU0sRUFBQyxHQUFFLEVBQUUsUUFBUTtBQUFDO0FBQUMsSUFBTSxLQUFBLGFBQUssY0FBYyxLQUFLLENBQUM7QUFBRSxJQUFBLEtBQUcsR0FBRztBQUFTLFNBQVMsS0FBSTtDQUFDLE1BQU0sSUFBQSxhQUFJLFdBQVcsRUFBRTtDQUFFLElBQUcsQ0FBQyxHQUFFLE1BQU0sRUFBRSxFQUFFO0NBQUUsT0FBTztBQUFDO0FBQUMsU0FBUyxHQUFHLEdBQUU7Q0FBQyxNQUFNLElBQUEsYUFBSSxXQUFXLEVBQUUsR0FBRSxJQUFBLGFBQUksY0FBWSxTQUFTLEdBQUUsR0FBRTtFQUFDLElBQUcsQ0FBQyxHQUFFLE1BQU0sRUFBRSxFQUFFO0VBQUUsSUFBRyxHQUFHLENBQUMsR0FBRTtHQUFDLE1BQU0sSUFBRSxFQUFFLENBQUM7R0FBRSxJQUF5QyxTQUFPLEtBQUcsTUFBTSxRQUFRLENBQUMsS0FBRyxZQUFVLE9BQU8sR0FBRyxNQUFNLEVBQUUsQ0FBQztHQUFFLE9BQU87RUFBQztFQUFDLElBQUcsTUFBTSxRQUFRLENBQUMsS0FBRyxZQUFVLE9BQU8sR0FBRSxNQUFNLEVBQUUsQ0FBQztFQUFFLE9BQU8sSUFBRSxPQUFPLE9BQU8sT0FBTyxPQUFPLENBQUMsR0FBRSxDQUFDLEdBQUUsQ0FBQyxJQUFFO0NBQUMsRUFBRSxFQUFFLE9BQU0sQ0FBQyxHQUFFLENBQUMsRUFBRSxPQUFNLENBQUMsQ0FBQztDQUFFLE9BQU8sRUFBRSxXQUFBLGFBQVcsY0FBYyxHQUFHLFVBQVMsRUFBQyxPQUFNLEVBQUMsR0FBRSxFQUFFLFFBQVEsSUFBRTtBQUFJO0FBQUMsSUFBTSxLQUFHLE9BQU8sVUFBVTtBQUFlLElBQUEsS0FBRyxDQUFDO0FBQUUsU0FBUyxHQUFHLEdBQUUsR0FBRTtDQUFDLE1BQU0sSUFBRSxZQUFVLE9BQU8sSUFBRSxPQUFLLEVBQUUsQ0FBQztDQUFFLEdBQUcsTUFBSSxHQUFHLE1BQUksS0FBRztDQUFFLE1BQU0sSUFBRSxJQUFFLE1BQUksRUFBRSxJQUFFLElBQUUsR0FBRyxFQUFFO0NBQUUsT0FBTyxJQUFFLElBQUUsTUFBSSxJQUFFO0FBQUM7QUFBQyxJQUFJO0FBQUcsU0FBUyxHQUFHLEdBQUUsR0FBRSxHQUFFO0NBQUMsTUFBTSxJQUFFLEdBQUcsQ0FBQyxHQUFFLElBQUUsR0FBRSxJQUFFLENBQUMsRUFBRSxDQUFDLEdBQUUsRUFBQyxPQUFNLElBQUUsR0FBRSxhQUFZLElBQUUsR0FBRyxFQUFFLGFBQVksRUFBRSxpQkFBaUIsR0FBRSxhQUFZLElBQUUsRUFBRSxDQUFDLE1BQUcsR0FBRSxJQUFFLEVBQUUsZUFBYSxFQUFFLGNBQVksRUFBRSxFQUFFLFdBQVcsSUFBRSxNQUFJLEVBQUUsY0FBWSxFQUFFLGVBQWEsR0FBRSxJQUFFLEtBQUcsRUFBRSxRQUFNLEVBQUUsTUFBTSxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxJQUFFO0NBQUUsSUFBRyxFQUFDLG1CQUFrQixNQUFHO0NBQUUsSUFBRyxLQUFHLEVBQUUsbUJBQWtCO0VBQUMsTUFBTSxJQUFFLEVBQUU7RUFBa0IsSUFBRyxFQUFFLG1CQUFrQjtHQUFDLE1BQU0sSUFBRSxFQUFFO0dBQWtCLEtBQUcsR0FBRSxNQUFJLEVBQUUsR0FBRSxDQUFDLEtBQUcsRUFBRSxHQUFFLENBQUM7RUFBQyxPQUFNLElBQUU7Q0FBQztDQUFDLE1BQU0sSUFBRSxJQUFJLEdBQUcsR0FBRSxHQUFFLElBQUUsRUFBRSxpQkFBZSxLQUFLLENBQUM7Q0FBRSxTQUFTLEVBQUUsR0FBRSxHQUFFO0VBQUMsT0FBTyxTQUFTLEdBQUUsR0FBRSxHQUFFO0dBQUMsTUFBSyxFQUFDLE9BQU0sR0FBRSxnQkFBZSxHQUFFLGNBQWEsR0FBRSxvQkFBbUIsR0FBRSxtQkFBa0IsR0FBRSxRQUFPLE1BQUcsR0FBRSxJQUFBLGFBQUksV0FBVyxFQUFFLEdBQUUsSUFBRSxHQUFHLEdBQUUsSUFBRSxFQUFFLHFCQUFtQixFQUFFO0dBQWtCLGFBQXVDLGlCQUFBLGFBQWlCLGNBQWMsQ0FBQztHQUFFLE1BQU0sSUFBRSxFQUFFLEdBQUUsR0FBRSxDQUFDLEtBQUc7R0FBRSxJQUFJLEdBQUU7R0FBRTtJQUFDLE1BQU0sSUFBQSxhQUFJLE9BQU8sSUFBSSxHQUFFLElBQUUsRUFBRTtJQUFRLElBQUcsU0FBTyxLQUFHLEVBQUUsT0FBSyxLQUFHLEVBQUUsT0FBSyxFQUFFLGNBQVksRUFBRSxPQUFLLEVBQUUsVUFBUSxFQUFFLE9BQUssS0FBRyxTQUFTLEdBQUUsR0FBRSxHQUFFO0tBQUMsTUFBTSxJQUFFLEdBQUUsSUFBRTtLQUFFLElBQUksSUFBRTtLQUFFLEtBQUksTUFBTSxLQUFLLEdBQUUsSUFBRyxHQUFHLEtBQUssR0FBRSxDQUFDLE1BQUksS0FBSSxFQUFFLE9BQUssRUFBRSxLQUFJLE9BQU0sQ0FBQztLQUFFLE9BQU8sTUFBSTtJQUFDLEVBQUUsRUFBRSxJQUFHLEdBQUUsRUFBRSxFQUFFLEdBQUUsSUFBRSxFQUFFLElBQUcsSUFBRSxFQUFFO1NBQU87S0FBQyxJQUFFLFNBQVMsR0FBRSxHQUFFLEdBQUU7TUFBQyxNQUFNLElBQUUsT0FBTyxPQUFPLE9BQU8sT0FBTyxDQUFDLEdBQUUsQ0FBQyxHQUFFO09BQUMsV0FBVSxLQUFLO09BQUUsT0FBTTtNQUFDLENBQUMsR0FBRSxJQUFFLEVBQUUsU0FBTztNQUFFLEtBQUksSUFBSSxJQUFFLEdBQUUsSUFBRSxFQUFFLFFBQU8sS0FBSTtPQUFDLE1BQU0sSUFBRSxFQUFFLElBQUcsSUFBRSxHQUFHLENBQUMsSUFBRSxFQUFFLElBQUUsT0FBTyxPQUFPLENBQUMsR0FBRSxDQUFDLElBQUUsQ0FBQyxJQUFFO09BQUUsS0FBSSxNQUFNLEtBQUssR0FBRSxnQkFBYyxJQUFFLEVBQUUsWUFBVSxHQUFHLEVBQUUsV0FBVSxFQUFFLEVBQUUsSUFBRSxZQUFVLElBQUUsRUFBRSxRQUFNLE9BQU8sT0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFFLEVBQUUsS0FBSyxHQUFFLEVBQUUsRUFBRSxJQUFFLEtBQUssS0FBRyxLQUFLLE1BQUksRUFBRSxPQUFLLEVBQUUsS0FBRyxFQUFFO01BQUc7TUFBQyxPQUFNLGVBQWMsS0FBRyxZQUFVLE9BQU8sRUFBRSxjQUFZLEVBQUUsWUFBVSxHQUFHLEVBQUUsV0FBVSxFQUFFLFNBQVMsSUFBRztLQUFDLEVBQUUsR0FBRSxHQUFFLENBQUMsR0FBRSxJQUFFLEVBQUUsd0JBQXdCLEdBQUUsRUFBRSxZQUFXLEVBQUUsTUFBTTtLQUFFLElBQUksSUFBRTtLQUFFLEtBQUksTUFBTSxLQUFLLEdBQUUsR0FBRyxLQUFLLEdBQUUsQ0FBQyxLQUFHO0tBQUksRUFBRSxVQUFRO01BQUM7TUFBRTtNQUFFLEVBQUU7TUFBVyxFQUFFO01BQU87TUFBRTtNQUFFO01BQUU7S0FBQztJQUFDO0dBQUM7R0FBQyxhQUF1QyxpQkFBQSxhQUFpQixjQUFjLENBQUMsR0FBdUMsRUFBRSxzQkFBb0IsRUFBRSxtQkFBbUIsQ0FBQztHQUFFLE1BQU0sSUFBRSxFQUFFLE1BQUksR0FBRSxJQUFFLFNBQVMsR0FBRSxHQUFFLEdBQUUsR0FBRTtJQUFDLE1BQU0sSUFBRSxDQUFDO0lBQUUsS0FBSSxNQUFNLEtBQUssR0FBRSxLQUFLLE1BQUksRUFBRSxNQUFJLFFBQU0sRUFBRSxNQUFJLFNBQU8sS0FBRyxZQUFVLEtBQUcsRUFBRSxVQUFRLE1BQUksa0JBQWdCLElBQUUsRUFBRSxLQUFHLEVBQUUsY0FBWSxLQUFHLENBQUMsRUFBRSxHQUFFLENBQUMsTUFBSSxFQUFFLEtBQUcsRUFBRSxJQUFHLEtBQXlDQyxZQUFFLENBQUMsTUFBSSxPQUFLLHFCQUFHLElBQUksSUFBRSxHQUFBLENBQUksSUFBSSxDQUFDLEtBQUcsQ0FBQyxFQUFFLENBQUMsS0FBRyxFQUFFLFNBQVMsR0FBRyxNQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUUsUUFBUSxLQUFLLHFEQUFxRCxFQUFFLDJWQUEyVjtJQUFLLE9BQU87R0FBQyxFQUFFLEdBQUUsR0FBRSxHQUFFLENBQUM7R0FBRSxJQUFJLElBQUUsR0FBRyxHQUFFLENBQUM7R0FBRSxPQUFPLE1BQUksS0FBRyxNQUFJLElBQUcsRUFBRSxjQUFZLEtBQUcsTUFBSSxFQUFFLFlBQVcsRUFBRSxFQUFFLENBQUMsS0FBRyxFQUFFLFNBQVMsR0FBRyxJQUFFLFVBQVEsZUFBYSxHQUFFLE1BQUksRUFBRSxNQUFJLEtBQUEsR0FBR0MsYUFBQUEsY0FBQUEsQ0FBRSxHQUFFLENBQUM7RUFBQyxFQUFFLEdBQUUsR0FBRSxDQUFDO0NBQUM7Q0FBQyxFQUFFLGNBQVk7Q0FBRSxJQUFJLElBQUEsYUFBSSxXQUFXLENBQUM7Q0FBRSxPQUFPLEVBQUUsUUFBTSxHQUFFLEVBQUUsaUJBQWUsR0FBRSxFQUFFLGNBQVksR0FBRSxFQUFFLG9CQUFrQixHQUFFLEVBQUUscUJBQW1CLElBQUUsR0FBRyxFQUFFLG9CQUFtQixFQUFFLGlCQUFpQixJQUFFLElBQUcsRUFBRSxvQkFBa0IsR0FBRSxFQUFFLFNBQU8sSUFBRSxFQUFFLFNBQU8sR0FBRSxPQUFPLGVBQWUsR0FBRSxnQkFBZTtFQUFDLE1BQUs7R0FBQyxPQUFPLEtBQUs7RUFBbUI7RUFBRSxJQUFJLEdBQUU7R0FBQyxLQUFLLHNCQUFvQixJQUFFLFNBQVMsR0FBRSxHQUFHLEdBQUU7SUFBQyxLQUFJLE1BQU0sS0FBSyxHQUFFLEdBQUcsR0FBRSxHQUFFLENBQUMsQ0FBQztJQUFFLE9BQU87R0FBQyxFQUFFLENBQUMsR0FBRSxFQUFFLGNBQWEsQ0FBQyxJQUFFO0VBQUM7Q0FBQyxDQUFDLEdBQXdDLEVBQUUsR0FBRSxDQUFDLEdBQUUsRUFBRSx1QkFBcUIsR0FBRSxNQUFJO0VBQUMsSUFBSSxJQUFFLENBQUMsR0FBRSxJQUFFLENBQUM7RUFBRSxRQUFPLE1BQUc7R0FBQyxDQUFDLE1BQUksRUFBRSxLQUFHLENBQUMsR0FBRSxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsVUFBUSxTQUFPLFFBQVEsS0FBSyxpREFBaUQsSUFBSSxJQUFFLG9CQUFvQixFQUFFLEtBQUcsR0FBRyxpUUFBaVEsR0FBRSxJQUFFLENBQUMsR0FBRSxJQUFFLENBQUM7RUFBRTtDQUFDLEVBQUEsQ0FBRyxHQUFFLENBQUMsR0FBRyxHQUFHLFNBQU0sSUFBSSxFQUFFLG1CQUFtQixHQUFFLEtBQUcsR0FBRyxHQUFFLEdBQUU7RUFBQyxPQUFNLENBQUM7RUFBRSxnQkFBZSxDQUFDO0VBQUUsYUFBWSxDQUFDO0VBQUUsb0JBQW1CLENBQUM7RUFBRSxtQkFBa0IsQ0FBQztFQUFFLG1CQUFrQixDQUFDO0VBQUUsUUFBTyxDQUFDO0NBQUMsQ0FBQyxHQUFFO0FBQUM7QUFBQyxJQUFJLHFCQUFHLElBQUksSUFBSTtDQUFDO0NBQUk7Q0FBTztDQUFVO0NBQU87Q0FBVTtDQUFRO0NBQVE7Q0FBSTtDQUFNO0NBQU07Q0FBYTtDQUFPO0NBQVM7Q0FBSztDQUFTO0NBQVU7Q0FBTztDQUFPO0NBQU07Q0FBVztDQUFPO0NBQVc7Q0FBSztDQUFNO0NBQVU7Q0FBTTtDQUFTO0NBQU07Q0FBSztDQUFLO0NBQUs7Q0FBUTtDQUFXO0NBQWE7Q0FBUztDQUFTO0NBQU87Q0FBSztDQUFLO0NBQUs7Q0FBSztDQUFLO0NBQUs7Q0FBUztDQUFTO0NBQUs7Q0FBTztDQUFJO0NBQVM7Q0FBTTtDQUFRO0NBQU07Q0FBTTtDQUFRO0NBQVM7Q0FBSztDQUFPO0NBQU07Q0FBTztDQUFPO0NBQVE7Q0FBTTtDQUFTO0NBQUs7Q0FBVztDQUFTO0NBQVM7Q0FBSTtDQUFVO0NBQU07Q0FBVztDQUFJO0NBQUs7Q0FBSztDQUFPO0NBQUk7Q0FBTztDQUFTO0NBQVU7Q0FBUztDQUFPO0NBQVE7Q0FBTztDQUFTO0NBQU07Q0FBVTtDQUFNO0NBQVE7Q0FBUTtDQUFLO0NBQVc7Q0FBVztDQUFRO0NBQUs7Q0FBUTtDQUFPO0NBQUs7Q0FBSTtDQUFLO0NBQU07Q0FBUTtDQUFNO0NBQVM7Q0FBVztDQUFPO0NBQVU7Q0FBVTtDQUFnQjtDQUFzQjtDQUFjO0NBQW1CO0NBQW9CO0NBQW9CO0NBQWlCO0NBQWU7Q0FBVTtDQUFVO0NBQVU7Q0FBVTtDQUFVO0NBQWlCO0NBQVU7Q0FBVTtDQUFjO0NBQWU7Q0FBVztDQUFlO0NBQXFCO0NBQWM7Q0FBUztDQUFlO0NBQVM7Q0FBZ0I7Q0FBSTtDQUFRO0NBQU87Q0FBaUI7Q0FBUztDQUFPO0NBQU87Q0FBVTtDQUFVO0NBQVc7Q0FBaUI7Q0FBTztDQUFPO0NBQU07Q0FBUztDQUFTO0NBQU87Q0FBVztDQUFRO0FBQUssQ0FBQztBQUFFLFNBQVMsR0FBRyxHQUFFLEdBQUU7Q0FBQyxNQUFNLElBQUUsQ0FBQyxFQUFFLEVBQUU7Q0FBRSxLQUFJLElBQUksSUFBRSxHQUFFLElBQUUsRUFBRSxRQUFPLElBQUUsR0FBRSxLQUFHLEdBQUUsRUFBRSxLQUFLLEVBQUUsSUFBRyxFQUFFLElBQUUsRUFBRTtDQUFFLE9BQU87QUFBQztBQUFDLElBQU0sTUFBRyxPQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUU7QUFBRyxTQUFTLEdBQUcsR0FBRSxHQUFHLEdBQUU7Q0FBQyxJQUFHLEdBQUcsQ0FBQyxLQUFHLEdBQUcsQ0FBQyxHQUFFLE9BQU8sR0FBRyxHQUFHLEdBQUcsR0FBRSxDQUFDLEdBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0NBQUUsTUFBTSxJQUFFO0NBQUUsT0FBTyxNQUFJLEVBQUUsVUFBUSxNQUFJLEVBQUUsVUFBUSxZQUFVLE9BQU8sRUFBRSxLQUFHLEdBQUcsQ0FBQyxJQUFFLEdBQUcsR0FBRyxHQUFHLEdBQUUsQ0FBQyxDQUFDLENBQUM7QUFBQztBQUFDLFNBQVMsR0FBRyxHQUFFLEdBQUUsSUFBRSxHQUFFO0NBQUMsSUFBRyxDQUFDLEdBQUUsTUFBTSxFQUFFLEdBQUUsQ0FBQztDQUFFLE1BQU0sS0FBRyxHQUFFLEdBQUcsTUFBSSxFQUFFLEdBQUUsR0FBRSxHQUFHLEdBQUUsR0FBRyxDQUFDLENBQUM7Q0FBRSxPQUFPLEVBQUUsU0FBTSxNQUFHLEdBQUcsR0FBRSxHQUFFLE9BQU8sT0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFFLENBQUMsR0FBRSxFQUFDLE9BQU0sTUFBTSxVQUFVLE9BQU8sRUFBRSxPQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxFQUFDLENBQUMsQ0FBQyxHQUFFLEVBQUUsY0FBVyxNQUFHLEdBQUcsR0FBRSxHQUFFLE9BQU8sT0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFFLENBQUMsR0FBRSxDQUFDLENBQUMsR0FBRTtBQUFDO0FBQUMsSUFBTSxNQUFHLE1BQUcsR0FBRyxJQUFHLENBQUM7QUFBRSxJQUFBLEtBQUc7QUFBRyxHQUFHLFNBQVEsTUFBRztDQUFDLEdBQUcsS0FBRyxHQUFHLENBQUM7QUFBQyxDQUFDO0FBQUUsSUFBTSxLQUFOLE1BQVE7Q0FBQyxZQUFZLEdBQUUsR0FBRTtFQUFDLEtBQUssZ0NBQWMsSUFBSSxJQUFFLEdBQUUsS0FBSyxRQUFNLEdBQUUsS0FBSyxjQUFZLEdBQUUsS0FBSyxXQUFTLFNBQVMsR0FBRTtHQUFDLEtBQUksSUFBSSxJQUFFLEdBQUUsSUFBRSxFQUFFLFFBQU8sS0FBRyxHQUFFO0lBQUMsTUFBTSxJQUFFLEVBQUU7SUFBRyxJQUFHLEdBQUcsQ0FBQyxLQUFHLENBQUMsR0FBRyxDQUFDLEdBQUUsT0FBTSxDQUFDO0dBQUM7R0FBQyxPQUFNLENBQUM7RUFBQyxFQUFFLENBQUMsR0FBRSxHQUFHLFdBQVcsS0FBSyxXQUFXO0NBQUM7Q0FBQyxhQUFhLEdBQUUsR0FBRTtFQUFDLEtBQUssY0FBYyxPQUFPLENBQUMsR0FBRSxLQUFLLGFBQWEsQ0FBQztDQUFDO0NBQUMsYUFBYSxHQUFFLEdBQUUsR0FBRSxHQUFFO0VBQUMsTUFBTSxJQUFFLEtBQUs7RUFBWSxJQUFHLEtBQUssVUFBUztHQUFDLElBQUcsRUFBRSxhQUFhLEdBQUUsSUFBRSxDQUFDLEdBQUUsS0FBSyxjQUFjLElBQUksQ0FBQyxLQUFHLEtBQUssYUFBYSxHQUFFLEdBQUUsR0FBRSxDQUFDO1FBQU07SUFBQyxNQUFNLElBQUUsS0FBSyxhQUFhLEdBQUUsR0FBRSxHQUFFLENBQUM7SUFBRSxFQUFFLFlBQVksR0FBRSxFQUFFLE1BQUssRUFBRSxLQUFLO0dBQUM7R0FBQztFQUFNO0VBQUMsTUFBTSxJQUFFLEtBQUssY0FBYyxJQUFJLENBQUM7RUFBRSxJQUFHLEtBQUssYUFBYSxHQUFFLEdBQUUsR0FBRSxDQUFDLEdBQUUsQ0FBQyxFQUFFLFVBQVEsR0FBRTtHQUFDLE1BQU0sSUFBRSxFQUFFLE9BQU0sSUFBRSxLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUMsQ0FBQztHQUFNLElBQUcsRUFBRSxXQUFTLEVBQUUsUUFBTztJQUFDLElBQUksSUFBRSxDQUFDO0lBQUUsS0FBSSxJQUFJLElBQUUsR0FBRSxJQUFFLEVBQUUsUUFBTyxLQUFJLElBQUcsRUFBRSxPQUFLLEVBQUUsSUFBRztLQUFDLElBQUUsQ0FBQztLQUFFO0lBQUs7SUFBQyxJQUFHLEdBQUU7R0FBTTtFQUFDO0VBQUMsS0FBSyxhQUFhLENBQUM7Q0FBQztDQUFDLGFBQWEsR0FBRSxHQUFFLEdBQUUsR0FBRTtFQUFDLE1BQU0sSUFBRSxHQUFHLEdBQUcsS0FBSyxPQUFNLEdBQUUsR0FBRSxDQUFDLENBQUMsR0FBRSxJQUFFO0dBQUMsTUFBSyxLQUFLLGNBQVk7R0FBRSxPQUFNLEVBQUUsR0FBRSxFQUFFO0VBQUM7RUFBRSxPQUFPLEtBQUssY0FBYyxJQUFJLEdBQUUsQ0FBQyxHQUFFO0NBQUM7Q0FBQyxhQUFhLEdBQUU7RUFBQyxNQUFNLElBQUUsS0FBSztFQUFZLEVBQUUsV0FBVyxDQUFDO0VBQUUsS0FBSSxNQUFNLEtBQUssS0FBSyxjQUFjLE9BQU8sR0FBRSxFQUFFLFlBQVksR0FBRSxFQUFFLE1BQUssRUFBRSxLQUFLO0NBQUM7QUFBQztBQUFDLFNBQVMsR0FBRyxHQUFFLEdBQUcsR0FBRTtDQUFDLE1BQU0sSUFBRSxHQUFHLEdBQUUsR0FBRyxDQUFDLEdBQUUsSUFBRSxhQUFhLEVBQUUsS0FBSyxVQUFVLENBQUMsQ0FBQyxLQUFJLElBQUUsSUFBSSxHQUFHLEdBQUUsQ0FBQztDQUFFLEVBQXVDLENBQUM7Q0FBRSxNQUFNLEtBQUUsTUFBRztFQUFDLE1BQU0sSUFBRSxHQUFHLEdBQUUsSUFBQSxhQUFJLFdBQVcsRUFBRTtFQUFFLElBQUk7RUFBRTtHQUFDLE1BQU0sSUFBQSxhQUFJLE9BQU8sSUFBSTtHQUFFLFNBQU8sRUFBRSxZQUFVLEVBQUUsVUFBUSxFQUFFLFdBQVcsbUJBQW1CLENBQUMsSUFBRyxJQUFFLEVBQUU7RUFBTztFQUFDLGFBQXVDLFNBQVMsTUFBTSxFQUFFLFFBQVEsS0FBRyxRQUFRLEtBQUssOEJBQThCLEVBQUUsa0VBQWtFLEdBQXVDLEVBQUUsTUFBSyxNQUFHLFlBQVUsT0FBTyxLQUFHLE9BQUssRUFBRSxRQUFRLFNBQVMsQ0FBQyxLQUFHLFFBQVEsS0FBSyw4VUFBOFUsR0FBRSxFQUFFLFdBQVcsVUFBUSxFQUFFLEdBQUUsR0FBRSxFQUFFLFlBQVcsR0FBRSxFQUFFLE1BQU07RUFBRTtHQUFDLE1BQU0sSUFBRSxFQUFFLFdBQVM7SUFBQztJQUFFLEVBQUU7SUFBVztHQUFDLElBQUU7SUFBQztJQUFFO0lBQUUsRUFBRTtJQUFXO0lBQUUsRUFBRTtJQUFPO0dBQUMsR0FBRSxJQUFBLGFBQUksT0FBTyxDQUFDO0dBQUUsYUFBRSxzQkFBb0I7SUFBQyxFQUFFLFdBQVcsV0FBUyxFQUFFLFlBQVUsTUFBSSxFQUFFLFdBQVcsV0FBVyxDQUFDLEdBQUUsRUFBRSxVQUFRLElBQUcsRUFBRSxHQUFFLEdBQUUsRUFBRSxZQUFXLEdBQUUsRUFBRSxNQUFNO0dBQUUsR0FBRSxDQUFDLEdBQUEsYUFBSSw0QkFBd0I7SUFBQyxFQUFFLFdBQVcsVUFBUSxFQUFFLGFBQWEsR0FBRSxFQUFFLFVBQVU7R0FBQyxHQUFFO0lBQUM7SUFBRSxFQUFFO0lBQVc7R0FBQyxDQUFDO0VBQUM7RUFBQyxPQUFPLEVBQUUsV0FBVyxVQUFRLEVBQUUsY0FBYyxPQUFPLENBQUMsR0FBRTtDQUFJO0NBQUUsU0FBUyxFQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRTtFQUFDLElBQUcsRUFBRSxVQUFTLEVBQUUsYUFBYSxHQUFFLEdBQUUsR0FBRSxDQUFDO09BQU07R0FBQyxNQUFNLElBQUUsT0FBTyxPQUFPLE9BQU8sT0FBTyxDQUFDLEdBQUUsQ0FBQyxHQUFFLEVBQUMsT0FBTSxFQUFFLEdBQUUsR0FBRSxFQUFFLFlBQVksRUFBQyxDQUFDO0dBQUUsRUFBRSxhQUFhLEdBQUUsR0FBRSxHQUFFLENBQUM7RUFBQztDQUFDO0NBQUMsT0FBQSxhQUFTLEtBQUssQ0FBQztBQUFDO0FBQUMsU0FBUyxHQUFHLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRTtDQUFDLEtBQUksTUFBTSxLQUFLLEdBQUU7RUFBQyxNQUFNLElBQUUsRUFBRSxJQUFHLElBQUUsSUFBRSxJQUFFLE1BQUksSUFBRTtFQUFFLElBQUcsWUFBVSxPQUFPLEtBQUcsU0FBTyxHQUFFO0dBQUMsTUFBTSxJQUFFLENBQUM7R0FBRSxHQUFHLEdBQUUsR0FBRSxHQUFFLEdBQUUsQ0FBQyxHQUFFLEVBQUUsS0FBRztFQUFDLE9BQU0sRUFBRSxLQUFHLEVBQUUsR0FBRSxHQUFFLENBQUM7Q0FBQztBQUFDO0FBQUMsU0FBUyxHQUFHLEdBQUUsR0FBRSxHQUFFLEdBQUU7Q0FBQyxJQUFJLElBQUU7Q0FBRyxLQUFJLE1BQU0sS0FBSyxHQUFFO0VBQUMsTUFBTSxJQUFFLEVBQUUsSUFBRyxJQUFFLEVBQUUsSUFBRyxJQUFFLElBQUUsSUFBRSxNQUFJLElBQUU7RUFBRSxZQUFVLE9BQU8sS0FBRyxTQUFPLElBQUUsWUFBVSxPQUFPLEtBQUcsU0FBTyxNQUFJLEtBQUcsR0FBRyxHQUFFLEdBQUUsR0FBRSxDQUFDLEtBQUcsS0FBSyxNQUFJLEtBQUcsY0FBWSxPQUFPLE1BQUksS0FBRyxPQUFLLElBQUUsSUFBRSxNQUFJLElBQUU7Q0FBSTtDQUFDLE9BQU87QUFBQztBQUFDLFNBQVMsR0FBRyxHQUFFLEdBQUU7Q0FBQyxJQUFJLEdBQUU7Q0FBRSxNQUFNLEtBQUcsVUFBUSxJQUFFLFFBQU0sSUFBRSxLQUFLLElBQUUsRUFBRSxXQUFTLEtBQUssTUFBSSxJQUFFLElBQUUsUUFBTSxLQUFJLElBQUUsVUFBUSxJQUFFLFFBQU0sSUFBRSxLQUFLLElBQUUsRUFBRSxhQUFXLEtBQUssTUFBSSxJQUFFLElBQUUsU0FBUSxJQUFFLFNBQVMsR0FBRSxHQUFFO0VBQUMsTUFBTSxJQUFFLENBQUM7RUFBRSxPQUFPLEdBQUcsR0FBRSxHQUFFLElBQUUsTUFBRyxPQUFLLElBQUUsQ0FBQyxHQUFFO0NBQUMsRUFBRSxHQUFFLENBQUMsR0FBRSxJQUFFLFNBQVMsR0FBRSxHQUFFO0VBQUMsTUFBTSxJQUFFLENBQUM7RUFBRSxPQUFPLEdBQUcsR0FBRSxHQUFFLElBQUcsR0FBRSxNQUFJO0dBQXdDO0lBQUMsTUFBTSxJQUFFLE9BQU8sQ0FBQztJQUFFLElBQUksSUFBRTtJQUFFLEtBQUksSUFBSSxJQUFFLEdBQUUsSUFBRSxFQUFFLFdBQVMsT0FBSyxFQUFFLFdBQVcsQ0FBQyxJQUFFLE1BQUksT0FBSyxFQUFFLFdBQVcsQ0FBQyxLQUFHLEtBQUksRUFBRSxJQUFFLEtBQUk7SUFBSyxNQUFJLEtBQUcsUUFBUSxLQUFLLHVCQUF1QixFQUFFLFFBQVEsRUFBRSxtRUFBbUU7R0FBQztHQUFDLE9BQU0sV0FBUyxJQUFFLElBQUUsT0FBSyxJQUFFO0VBQUcsQ0FBQyxHQUFFO0NBQUMsRUFBRSxHQUFFLENBQUMsR0FBRSxJQUFFLEVBQUU7TUFDM2g5QixFQUFFO1NBQ0EsTUFBRyxHQUFHLEdBQUUsRUFBRSxPQUFNLENBQUMsRUFBRTs7O0NBRXZCLE9BQU8sT0FBTyxPQUFPLEdBQUU7RUFBQyxhQUFZO0VBQUUsS0FBSTtFQUFFLE1BQUs7RUFBRSxRQUFRLEdBQUU7R0FBQyxJQUFHLENBQUMsR0FBRSxNQUFNLElBQUksTUFBTSxzQ0FBc0M7R0FBRSxNQUFNLElBQUUsUUFBTSxJQUFFLElBQUUsU0FBUztHQUFnQixPQUFPLFNBQVMsR0FBRSxHQUFFLEdBQUU7SUFBQyxNQUFNLElBQUUsQ0FBQztJQUFFLE9BQU8sR0FBRyxHQUFFLEdBQUUsSUFBRyxHQUFFLE1BQUksRUFBRSxpQkFBaUIsT0FBSyxJQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBRyxDQUFDLEdBQUU7R0FBQyxFQUFFLEdBQUUsR0FBRSxpQkFBaUIsQ0FBQyxDQUFDO0VBQUM7Q0FBQyxDQUFDO0FBQUM7QUFBQyxJQUFJO0FBQUcsSUFBTSxLQUFOLE1BQVE7Q0FBQyxZQUFZLEdBQUUsR0FBRTtFQUFDLEtBQUssTUFBSSxDQUFDLEdBQUUsS0FBSyxVQUFRLEdBQUUsSUFBRSxPQUFLO0dBQUMsTUFBTSxJQUFFLEtBQUssUUFBUSxDQUFDO0dBQUUsSUFBRyxDQUFDLEVBQUUsYUFBYSxLQUFLLElBQUcsQ0FBQyxHQUFFO0lBQUMsTUFBTSxJQUFFLEVBQUUsS0FBSyxPQUFNLEdBQUUsWUFBWTtJQUFFLEVBQUUsWUFBWSxLQUFLLElBQUcsR0FBRSxDQUFDO0dBQUM7RUFBQyxHQUFFLEtBQUssT0FBSyxHQUFFLEtBQUssS0FBRyxJQUFFLEdBQUUsS0FBSyxRQUFNLEdBQUUsRUFBRSxLQUFLLEVBQUUsR0FBRSxHQUFHLFlBQVM7R0FBQyxNQUFNLEVBQUUsSUFBRyxPQUFPLEtBQUssSUFBSSxDQUFDO0VBQUMsQ0FBQztDQUFDO0NBQUMsUUFBUSxJQUFFLElBQUc7RUFBQyxPQUFPLEVBQUUsT0FBSyxLQUFLLE9BQUssRUFBRSxDQUFDLEVBQUUsU0FBTyxDQUFDLElBQUUsS0FBSztDQUFJO0FBQUM7QUFBQyxTQUFTLEdBQUcsR0FBRSxHQUFHLEdBQUU7Q0FBQyxlQUFrRCxPQUFPLGFBQVcsa0JBQWdCLFVBQVUsV0FBUyxRQUFRLEtBQUssaUhBQWlIO0NBQUUsTUFBTSxJQUFFLEdBQUcsR0FBRyxHQUFFLEdBQUcsQ0FBQyxDQUFDO0NBQVMsT0FBTyxJQUFJLEdBQWhCLEVBQUUsQ0FBaUIsR0FBRSxDQUFDO0FBQUM7QUFBQyxTQUFTLEdBQUcsR0FBRTtDQUFDLE1BQU0sSUFBQSxhQUFJLFlBQVksR0FBRSxNQUFJO0VBQUMsTUFBTSxJQUFFLEVBQUUsR0FBQSxhQUFJLFdBQVcsRUFBRSxHQUFFLEVBQUUsWUFBWTtFQUFFLE9BQTJDLEtBQUssTUFBSSxLQUFHLFFBQVEsS0FBSyx5SEFBeUgsRUFBRSxDQUFDLEVBQUUsRUFBRSxHQUFBLGFBQUksY0FBYyxHQUFFLE9BQU8sT0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFFLENBQUMsR0FBRTtHQUFDLE9BQU07R0FBRSxLQUFJO0VBQUMsQ0FBQyxDQUFDO0NBQUMsQ0FBQztDQUFFLE9BQU8sRUFBRSxjQUFZLGFBQWEsRUFBRSxDQUFDLEVBQUUsSUFBRyxHQUFHLEdBQUUsQ0FBQztBQUFDO0FBQUMsS0FBRztBQUFHLElBQU0sS0FBTixNQUFRO0NBQUMsWUFBWSxFQUFDLE9BQU0sTUFBRyxDQUFDLEdBQUU7RUFBQyxLQUFLLHNCQUFrQjtHQUFDLE1BQU0sSUFBRSxLQUFLLFNBQVMsU0FBUztHQUFFLElBQUcsQ0FBQyxHQUFFLE9BQU07R0FBRyxNQUFNLElBQUUsS0FBSyxTQUFTLFFBQVEsU0FBTyxHQUFHO0dBQUUsT0FBTSxVQUFVLEdBQUc7SUFBQyxLQUFHLFVBQVUsRUFBRTtJQUFHLEdBQUcsRUFBRTtJQUFTLEdBQUcsRUFBRSxJQUFJLEVBQUU7R0FBRSxDQUFDLENBQUMsT0FBTyxPQUFPLEdBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRTtFQUFTLEdBQUUsS0FBSyxxQkFBaUI7R0FBQyxJQUFHLEtBQUssUUFBTyxNQUFNLEVBQUUsQ0FBQztHQUFFLE9BQU8sS0FBSyxjQUFjO0VBQUMsR0FBRSxLQUFLLHdCQUFvQjtHQUFDLElBQUcsS0FBSyxRQUFPLE1BQU0sRUFBRSxDQUFDO0dBQUUsTUFBTSxJQUFFLEtBQUssU0FBUyxTQUFTO0dBQUUsSUFBRyxDQUFDLEdBQUUsT0FBTSxDQUFDO0dBQUUsTUFBTSxJQUFFO0tBQUUsSUFBRztLQUFJLElBQUc7SUFBRSx5QkFBd0IsRUFBQyxRQUFPLEVBQUM7R0FBQyxHQUFFLElBQUUsS0FBSyxTQUFTLFFBQVEsU0FBTyxHQUFHO0dBQUUsT0FBTyxNQUFJLEVBQUUsUUFBTSxJQUFHLENBQUEsYUFBRyxjQUFjLFNBQVEsT0FBTyxPQUFPLENBQUMsR0FBRSxHQUFFLEVBQUMsS0FBSSxTQUFRLENBQUMsQ0FBQyxDQUFDO0VBQUMsR0FBRSxLQUFLLGFBQVM7R0FBQyxLQUFLLFNBQU8sQ0FBQztFQUFDLEdBQUUsS0FBSyxXQUFTLElBQUksR0FBRztHQUFDLFVBQVMsQ0FBQztHQUFFLE9BQU07RUFBQyxDQUFDLEdBQUUsS0FBSyxTQUFPLENBQUM7Q0FBQztDQUFDLGNBQWMsR0FBRTtFQUFDLElBQUcsS0FBSyxRQUFPLE1BQU0sRUFBRSxDQUFDO0VBQUUsT0FBQSxhQUFTLGNBQWMsSUFBRyxFQUFDLE9BQU0sS0FBSyxTQUFRLEdBQUUsQ0FBQztDQUFDO0NBQUMseUJBQXlCLEdBQUU7RUFBQyxNQUFNLEVBQUUsQ0FBQztDQUFDO0FBQUM7QUFBQyxJQUFNLEtBQUc7Q0FBQyxZQUFXO0NBQUcsV0FBVTtBQUFFO0FBQXVDLGVBQWEsT0FBTyxhQUFXLGtCQUFnQixVQUFVLFdBQVMsUUFBUSxLQUFLLGtOQUFrTjtBQUFFLElBQU0sS0FBRyxRQUFRLEVBQUU7QUFBd0UsZUFBYSxPQUFPLFdBQVMsT0FBTyxRQUFNLE9BQU8sTUFBSSxJQUFHLE1BQUksT0FBTyxPQUFLLFFBQVEsS0FBSyxvWkFBb1osR0FBRSxPQUFPLE9BQUs7QUFBRyxJQUFNLEtBQUc7QUFBcUcsSUFBQSxLQUFHLGNBQWMsRUFBRTtBQUFJLElBQUEsS0FBRyxTQUFTLEVBQUU7QUFBRyxTQUFTLEdBQUcsR0FBRTtDQUFDLE9BQU0sT0FBSyxFQUFFLFFBQVEsUUFBUSxJQUFFLEtBQUcsR0FBRyxZQUFVLEdBQUUsRUFBRSxRQUFRLEtBQUksR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxNQUFJLElBQUUsbUJBQW1CLEdBQUcsS0FBRyxJQUFFLHdCQUF3QixHQUFHLEtBQUcsSUFBRSxtQkFBbUIsR0FBRyx3QkFBd0IsR0FBRyxLQUFHLElBQUUsT0FBSyxFQUFFLFFBQVEsTUFBTSxJQUFFLElBQUUsY0FBYyxFQUFFLE1BQU0sR0FBRyxLQUFHLE9BQUssRUFBRSxRQUFRLE1BQU0sSUFBRSxJQUFFLG1CQUFtQixFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUU7QUFBQyxTQUFTLEdBQUcsR0FBRSxHQUFFO0NBQUMsSUFBRyxPQUFLLEVBQUUsUUFBUSxHQUFHLEdBQUU7Q0FBTyxJQUFJLElBQUUsR0FBRSxJQUFFO0NBQUUsS0FBSSxJQUFJLElBQUUsR0FBRSxJQUFFLEVBQUUsUUFBTyxLQUFJO0VBQUMsTUFBTSxJQUFFLEVBQUUsV0FBVyxDQUFDO0VBQUUsSUFBRyxPQUFLLEdBQUU7T0FBUyxJQUFHLE9BQUssR0FBRTtPQUFTLElBQUcsT0FBSyxHQUFFO09BQVMsSUFBRyxPQUFLLEdBQUU7T0FBUyxJQUFHLE9BQUssS0FBRyxNQUFJLEtBQUcsTUFBSSxLQUFHLENBQUMsR0FBRyxHQUFFLENBQUMsR0FBRTtHQUFDLE1BQU0sSUFBRSxFQUFFLFVBQVUsR0FBRSxDQUFDLEdBQUUsSUFBRSxFQUFFLFVBQVUsSUFBRSxDQUFDO0dBQUUsRUFBRSxLQUFLLElBQUUsTUFBSSxLQUFHLE1BQUksQ0FBQyxHQUFFLEVBQUUsS0FBSyxJQUFFLE1BQUksS0FBRyxNQUFJLEtBQUcsTUFBSSxDQUFDO0VBQUM7Q0FBQztBQUFDO0FBQUMsU0FBUyxHQUFHLEdBQUU7Q0FBQyxJQUFHLEVBQUUsU0FBQSxRQUFTO0VBQUMsTUFBTSxJQUFFLEVBQUUsT0FBTSxJQUFFLENBQUM7RUFBRSxLQUFJLElBQUksSUFBRSxHQUFFLElBQUUsRUFBRSxRQUFPLEtBQUk7R0FBQyxNQUFNLElBQUUsR0FBRyxFQUFFLEVBQUU7R0FBRSxFQUFFLEtBQUssQ0FBQyxHQUFFLEdBQUcsR0FBRSxDQUFDO0VBQUM7RUFBQyxFQUFFLFFBQU07Q0FBQztBQUFDIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1LDYsNyw4LDldfQ==