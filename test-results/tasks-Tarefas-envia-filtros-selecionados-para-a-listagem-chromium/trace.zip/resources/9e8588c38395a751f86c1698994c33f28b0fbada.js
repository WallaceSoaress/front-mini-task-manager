import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/tasks/TaskCard.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=df6b4f96";
import { dueDateState, formatDate, formatDateTime, priorityLabels, priorityTone } from "/src/components/tasks/labels.ts";
import { CardMeta, CardTitle, Chip, TaskCardButton } from "/src/components/tasks/styles.ts";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskCard.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=df6b4f96";
export function TaskCard(t0) {
	const $ = _c(44);
	if ($[0] !== "22014746074fd053e0212d436dbd03a706bdcd7a4c1f91d67a20e1173416a7c9") {
		for (let $i = 0; $i < 44; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "22014746074fd053e0212d436dbd03a706bdcd7a4c1f91d67a20e1173416a7c9";
	}
	const { task, onOpen, onDragStart, onDragEnd } = t0;
	const dueTone = dueDateState(task.dueDate);
	let t1;
	if ($[1] !== onOpen || $[2] !== task) {
		t1 = () => onOpen(task);
		$[1] = onOpen;
		$[2] = task;
		$[3] = t1;
	} else {
		t1 = $[3];
	}
	let t2;
	if ($[4] !== onDragStart || $[5] !== task) {
		t2 = (event) => {
			event.dataTransfer.effectAllowed = "move";
			event.dataTransfer.setData("text/plain", task.id);
			onDragStart?.(task);
		};
		$[4] = onDragStart;
		$[5] = task;
		$[6] = t2;
	} else {
		t2 = $[6];
	}
	let t3;
	if ($[7] !== task.title) {
		t3 = /* @__PURE__ */ _jsxDEV(CardTitle, { children: task.title }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 10
		}, this);
		$[7] = task.title;
		$[8] = t3;
	} else {
		t3 = $[8];
	}
	let t4;
	if ($[9] !== task.team.name) {
		t4 = /* @__PURE__ */ _jsxDEV(Chip, { children: task.team.name }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 58,
			columnNumber: 10
		}, this);
		$[9] = task.team.name;
		$[10] = t4;
	} else {
		t4 = $[10];
	}
	const t5 = priorityTone[task.priority];
	const t6 = priorityLabels[task.priority];
	let t7;
	if ($[11] !== t5 || $[12] !== t6) {
		t7 = /* @__PURE__ */ _jsxDEV(Chip, {
			$tone: t5,
			children: t6
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 68,
			columnNumber: 10
		}, this);
		$[11] = t5;
		$[12] = t6;
		$[13] = t7;
	} else {
		t7 = $[13];
	}
	const t8 = dueTone === "danger" ? "danger" : dueTone === "warning" ? "warning" : "default";
	let t9;
	if ($[14] !== task.dueDate) {
		t9 = formatDate(task.dueDate);
		$[14] = task.dueDate;
		$[15] = t9;
	} else {
		t9 = $[15];
	}
	let t10;
	if ($[16] !== t8 || $[17] !== t9) {
		t10 = /* @__PURE__ */ _jsxDEV(Chip, {
			$tone: t8,
			children: t9
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 86,
			columnNumber: 11
		}, this);
		$[16] = t8;
		$[17] = t9;
		$[18] = t10;
	} else {
		t10 = $[18];
	}
	let t11;
	if ($[19] !== t10 || $[20] !== t4 || $[21] !== t7) {
		t11 = /* @__PURE__ */ _jsxDEV(CardMeta, { children: [
			t4,
			t7,
			t10
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 95,
			columnNumber: 11
		}, this);
		$[19] = t10;
		$[20] = t4;
		$[21] = t7;
		$[22] = t11;
	} else {
		t11 = $[22];
	}
	let t12;
	if ($[23] !== task.id) {
		t12 = task.id.slice(0, 8);
		$[23] = task.id;
		$[24] = t12;
	} else {
		t12 = $[24];
	}
	let t13;
	if ($[25] !== t12) {
		t13 = /* @__PURE__ */ _jsxDEV("span", { children: ["#", t12] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 113,
			columnNumber: 11
		}, this);
		$[25] = t12;
		$[26] = t13;
	} else {
		t13 = $[26];
	}
	const t14 = task.responsible?.name ?? "Sem responsavel";
	let t15;
	if ($[27] !== t14) {
		t15 = /* @__PURE__ */ _jsxDEV("span", { children: t14 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 122,
			columnNumber: 11
		}, this);
		$[27] = t14;
		$[28] = t15;
	} else {
		t15 = $[28];
	}
	let t16;
	if ($[29] !== t13 || $[30] !== t15) {
		t16 = /* @__PURE__ */ _jsxDEV(CardMeta, { children: [t13, t15] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 130,
			columnNumber: 11
		}, this);
		$[29] = t13;
		$[30] = t15;
		$[31] = t16;
	} else {
		t16 = $[31];
	}
	let t17;
	if ($[32] !== task.createdAt) {
		t17 = formatDateTime(task.createdAt);
		$[32] = task.createdAt;
		$[33] = t17;
	} else {
		t17 = $[33];
	}
	let t18;
	if ($[34] !== t17) {
		t18 = /* @__PURE__ */ _jsxDEV(CardMeta, { children: /* @__PURE__ */ _jsxDEV("span", { children: ["Criado em ", t17] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 147,
			columnNumber: 21
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 147,
			columnNumber: 11
		}, this);
		$[34] = t17;
		$[35] = t18;
	} else {
		t18 = $[35];
	}
	let t19;
	if ($[36] !== onDragEnd || $[37] !== t1 || $[38] !== t11 || $[39] !== t16 || $[40] !== t18 || $[41] !== t2 || $[42] !== t3) {
		t19 = /* @__PURE__ */ _jsxDEV(TaskCardButton, {
			type: "button",
			draggable: true,
			onClick: t1,
			onDragEnd,
			onDragStart: t2,
			children: [
				t3,
				t11,
				t16,
				t18
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 155,
			columnNumber: 11
		}, this);
		$[36] = onDragEnd;
		$[37] = t1;
		$[38] = t11;
		$[39] = t16;
		$[40] = t18;
		$[41] = t2;
		$[42] = t3;
		$[43] = t19;
	} else {
		t19 = $[43];
	}
	return t19;
}
_c2 = TaskCard;
var _c2;
$RefreshReg$(_c2, "TaskCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/tasks/TaskCard.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskCard.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUNBLFNBQVNBLGNBQWNDLFlBQVlDLGdCQUFnQkMsZ0JBQWdCQyxvQkFBb0I7QUFDdkYsU0FBU0MsVUFBVUMsV0FBV0MsTUFBTUMsc0JBQXNCOzs7QUFTMUQsT0FBTyxTQUFBQyxTQUFBQyxJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsSUFBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQWtCLFFBQUFLLE1BQUFDLFFBQUFDLGFBQUFDLGNBQUFUO0NBQ3ZCLE1BQUFVLFVBQWdCcEIsYUFBYWdCLEtBQUlLLE9BQVE7Q0FBRSxJQUFBQztDQUFBLElBQUFYLEVBQUEsT0FBQU0sVUFBQU4sRUFBQSxPQUFBSyxNQUFBO0VBTTlCTSxXQUFNTCxPQUFPRCxJQUFJO0VBQUNMLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFXO0NBQUE7RUFBQUEsS0FBQVgsRUFBQTtDQUFBO0NBQUEsSUFBQVk7Q0FBQSxJQUFBWixFQUFBLE9BQUFPLGVBQUFQLEVBQUEsT0FBQUssTUFBQTtFQUVkTyxNQUFBQyxVQUFBO0dBQ1hBLE1BQUtDLGFBQWFDLGdCQUFpQjtHQUNuQ0YsTUFBS0MsYUFBYUUsUUFBUyxjQUFjWCxLQUFJWSxFQUFHO0dBQ2hEVixjQUFjRixJQUFJO0VBQUM7RUFDcEJMLEVBQUEsS0FBQU87RUFBQVAsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFZO0NBQUE7RUFBQUEsS0FBQVosRUFBQTtDQUFBO0NBQUEsSUFBQWtCO0NBQUEsSUFBQWxCLEVBQUEsT0FBQUssS0FBQWMsT0FBQTtFQUVERCxLQUFBLHdCQUFDLFdBQUQsWUFBWWIsS0FBSWMsTUFBTjs7Ozs7RUFBeUJuQixFQUFBLEtBQUFLLEtBQUFjO0VBQUFuQixFQUFBLEtBQUFrQjtDQUFBO0VBQUFBLEtBQUFsQixFQUFBO0NBQUE7Q0FBQSxJQUFBb0I7Q0FBQSxJQUFBcEIsRUFBQSxPQUFBSyxLQUFBZ0IsS0FBQUMsTUFBQTtFQUdqQ0YsS0FBQSx3QkFBQyxNQUFELFlBQU9mLEtBQUlnQixLQUFLQyxLQUFYOzs7OztFQUF3QnRCLEVBQUEsS0FBQUssS0FBQWdCLEtBQUFDO0VBQUF0QixFQUFBLE1BQUFvQjtDQUFBO0VBQUFBLEtBQUFwQixFQUFBO0NBQUE7Q0FDaEIsTUFBQXVCLEtBQUE5QixhQUFhWSxLQUFJbUI7Q0FBYSxNQUFBQyxLQUFBakMsZUFBZWEsS0FBSW1CO0NBQVUsSUFBQUU7Q0FBQSxJQUFBMUIsRUFBQSxRQUFBdUIsTUFBQXZCLEVBQUEsUUFBQXlCLElBQUE7RUFBeEVDLEtBQUEsd0JBQUMsTUFBRDtHQUFhLE9BQUFIO2FBQThCRTtFQUF0Qzs7Ozs7RUFBMkV6QixFQUFBLE1BQUF1QjtFQUFBdkIsRUFBQSxNQUFBeUI7RUFBQXpCLEVBQUEsTUFBQTBCO0NBQUE7RUFBQUEsS0FBQTFCLEVBQUE7Q0FBQTtDQUNuRSxNQUFBMkIsS0FBQWxCLFlBQVksV0FBWixXQUFrQ0EsWUFBWSxZQUFaO0NBQTZDLElBQUFtQjtDQUFBLElBQUE1QixFQUFBLFFBQUFLLEtBQUFLLFNBQUE7RUFDekZrQixLQUFBdEMsV0FBV2UsS0FBSUssT0FBUTtFQUFDVixFQUFBLE1BQUFLLEtBQUFLO0VBQUFWLEVBQUEsTUFBQTRCO0NBQUE7RUFBQUEsS0FBQTVCLEVBQUE7Q0FBQTtDQUFBLElBQUE2QjtDQUFBLElBQUE3QixFQUFBLFFBQUEyQixNQUFBM0IsRUFBQSxRQUFBNEIsSUFBQTtFQUQzQkMsTUFBQSx3QkFBQyxNQUFEO0dBQWEsT0FBQUY7YUFDVkM7RUFERTs7Ozs7RUFFRTVCLEVBQUEsTUFBQTJCO0VBQUEzQixFQUFBLE1BQUE0QjtFQUFBNUIsRUFBQSxNQUFBNkI7Q0FBQTtFQUFBQSxNQUFBN0IsRUFBQTtDQUFBO0NBQUEsSUFBQThCO0NBQUEsSUFBQTlCLEVBQUEsUUFBQTZCLE9BQUE3QixFQUFBLFFBQUFvQixNQUFBcEIsRUFBQSxRQUFBMEIsSUFBQTtFQUxUSSxNQUFBLHdCQUFDLFVBQUQ7R0FDRVY7R0FDQU07R0FDQUc7RUFITzs7Ozs7RUFNRTdCLEVBQUEsTUFBQTZCO0VBQUE3QixFQUFBLE1BQUFvQjtFQUFBcEIsRUFBQSxNQUFBMEI7RUFBQTFCLEVBQUEsTUFBQThCO0NBQUE7RUFBQUEsTUFBQTlCLEVBQUE7Q0FBQTtDQUFBLElBQUErQjtDQUFBLElBQUEvQixFQUFBLFFBQUFLLEtBQUFZLElBQUE7RUFHRGMsTUFBQTFCLEtBQUlZLEdBQUdlLE1BQU8sR0FBRyxDQUFDO0VBQUNoQyxFQUFBLE1BQUFLLEtBQUFZO0VBQUFqQixFQUFBLE1BQUErQjtDQUFBO0VBQUFBLE1BQUEvQixFQUFBO0NBQUE7Q0FBQSxJQUFBaUM7Q0FBQSxJQUFBakMsRUFBQSxRQUFBK0IsS0FBQTtFQUEzQkUsTUFBQSw2Q0FBTSxLQUFFRixHQUEyQjs7Ozs7RUFBQS9CLEVBQUEsTUFBQStCO0VBQUEvQixFQUFBLE1BQUFpQztDQUFBO0VBQUFBLE1BQUFqQyxFQUFBO0NBQUE7Q0FDNUIsTUFBQWtDLE1BQUE3QixLQUFJOEIsYUFBa0JiLFFBQXRCO0NBQTJDLElBQUFjO0NBQUEsSUFBQXBDLEVBQUEsUUFBQWtDLEtBQUE7RUFBbERFLE1BQUEsNENBQU9GLElBQW1EOzs7OztFQUFBbEMsRUFBQSxNQUFBa0M7RUFBQWxDLEVBQUEsTUFBQW9DO0NBQUE7RUFBQUEsTUFBQXBDLEVBQUE7Q0FBQTtDQUFBLElBQUFxQztDQUFBLElBQUFyQyxFQUFBLFFBQUFpQyxPQUFBakMsRUFBQSxRQUFBb0MsS0FBQTtFQUY1REMsTUFBQSx3QkFBQyxVQUFELGFBQ0VKLEtBQ0FHLEdBRk87Ozs7O0VBR0VwQyxFQUFBLE1BQUFpQztFQUFBakMsRUFBQSxNQUFBb0M7RUFBQXBDLEVBQUEsTUFBQXFDO0NBQUE7RUFBQUEsTUFBQXJDLEVBQUE7Q0FBQTtDQUFBLElBQUFzQztDQUFBLElBQUF0QyxFQUFBLFFBQUFLLEtBQUFrQyxXQUFBO0VBR1FELE1BQUEvQyxlQUFlYyxLQUFJa0MsU0FBVTtFQUFDdkMsRUFBQSxNQUFBSyxLQUFBa0M7RUFBQXZDLEVBQUEsTUFBQXNDO0NBQUE7RUFBQUEsTUFBQXRDLEVBQUE7Q0FBQTtDQUFBLElBQUF3QztDQUFBLElBQUF4QyxFQUFBLFFBQUFzQyxLQUFBO0VBRGpERSxNQUFBLHdCQUFDLFVBQUQsWUFDRSw2Q0FBTSxjQUFXRixHQUFzQzs7OztXQURoRDs7Ozs7RUFFRXRDLEVBQUEsTUFBQXNDO0VBQUF0QyxFQUFBLE1BQUF3QztDQUFBO0VBQUFBLE1BQUF4QyxFQUFBO0NBQUE7Q0FBQSxJQUFBeUM7Q0FBQSxJQUFBekMsRUFBQSxRQUFBUSxhQUFBUixFQUFBLFFBQUFXLE1BQUFYLEVBQUEsUUFBQThCLE9BQUE5QixFQUFBLFFBQUFxQyxPQUFBckMsRUFBQSxRQUFBd0MsT0FBQXhDLEVBQUEsUUFBQVksTUFBQVosRUFBQSxRQUFBa0IsSUFBQTtFQTVCYnVCLE1BQUEsd0JBQUMsZ0JBQUQ7R0FDTztHQUNMO0dBQ1MsU0FBQTlCO0dBQ0VIO0dBQ0UsYUFBQUk7YUFMZjtJQVdFTTtJQUVBWTtJQVFBTztJQUtBRztHQTFCYTs7Ozs7O0VBNkJFeEMsRUFBQSxNQUFBUTtFQUFBUixFQUFBLE1BQUFXO0VBQUFYLEVBQUEsTUFBQThCO0VBQUE5QixFQUFBLE1BQUFxQztFQUFBckMsRUFBQSxNQUFBd0M7RUFBQXhDLEVBQUEsTUFBQVk7RUFBQVosRUFBQSxNQUFBa0I7RUFBQWxCLEVBQUEsTUFBQXlDO0NBQUE7RUFBQUEsTUFBQXpDLEVBQUE7Q0FBQTtDQUFBLE9BN0JqQnlDO0FBNkJpQiIsIm5hbWVzIjpbImR1ZURhdGVTdGF0ZSIsImZvcm1hdERhdGUiLCJmb3JtYXREYXRlVGltZSIsInByaW9yaXR5TGFiZWxzIiwicHJpb3JpdHlUb25lIiwiQ2FyZE1ldGEiLCJDYXJkVGl0bGUiLCJDaGlwIiwiVGFza0NhcmRCdXR0b24iLCJUYXNrQ2FyZCIsInQwIiwiJCIsIl9jIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJ0YXNrIiwib25PcGVuIiwib25EcmFnU3RhcnQiLCJvbkRyYWdFbmQiLCJkdWVUb25lIiwiZHVlRGF0ZSIsInQxIiwidDIiLCJldmVudCIsImRhdGFUcmFuc2ZlciIsImVmZmVjdEFsbG93ZWQiLCJzZXREYXRhIiwiaWQiLCJ0MyIsInRpdGxlIiwidDQiLCJ0ZWFtIiwibmFtZSIsInQ1IiwicHJpb3JpdHkiLCJ0NiIsInQ3IiwidDgiLCJ0OSIsInQxMCIsInQxMSIsInQxMiIsInNsaWNlIiwidDEzIiwidDE0IiwicmVzcG9uc2libGUiLCJ0MTUiLCJ0MTYiLCJ0MTciLCJjcmVhdGVkQXQiLCJ0MTgiLCJ0MTkiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVGFza0NhcmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgVGFzayB9IGZyb20gXCIuLi8uLi9pbnRlcmZhY2VzL3Rhc2tzL3Rhc2tcIjtcbmltcG9ydCB7IGR1ZURhdGVTdGF0ZSwgZm9ybWF0RGF0ZSwgZm9ybWF0RGF0ZVRpbWUsIHByaW9yaXR5TGFiZWxzLCBwcmlvcml0eVRvbmUgfSBmcm9tIFwiLi9sYWJlbHNcIjtcbmltcG9ydCB7IENhcmRNZXRhLCBDYXJkVGl0bGUsIENoaXAsIFRhc2tDYXJkQnV0dG9uIH0gZnJvbSBcIi4vc3R5bGVzXCI7XG5cbnR5cGUgVGFza0NhcmRQcm9wcyA9IHtcbiAgdGFzazogVGFzaztcbiAgb25PcGVuOiAodGFzazogVGFzaykgPT4gdm9pZDtcbiAgb25EcmFnU3RhcnQ/OiAodGFzazogVGFzaykgPT4gdm9pZDtcbiAgb25EcmFnRW5kPzogKCkgPT4gdm9pZDtcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBUYXNrQ2FyZCh7IHRhc2ssIG9uT3Blbiwgb25EcmFnU3RhcnQsIG9uRHJhZ0VuZCB9OiBUYXNrQ2FyZFByb3BzKSB7XG4gIGNvbnN0IGR1ZVRvbmUgPSBkdWVEYXRlU3RhdGUodGFzay5kdWVEYXRlKTtcblxuICByZXR1cm4gKFxuICAgIDxUYXNrQ2FyZEJ1dHRvblxuICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICBkcmFnZ2FibGVcbiAgICAgIG9uQ2xpY2s9eygpID0+IG9uT3Blbih0YXNrKX1cbiAgICAgIG9uRHJhZ0VuZD17b25EcmFnRW5kfVxuICAgICAgb25EcmFnU3RhcnQ9eyhldmVudCkgPT4ge1xuICAgICAgICBldmVudC5kYXRhVHJhbnNmZXIuZWZmZWN0QWxsb3dlZCA9IFwibW92ZVwiO1xuICAgICAgICBldmVudC5kYXRhVHJhbnNmZXIuc2V0RGF0YShcInRleHQvcGxhaW5cIiwgdGFzay5pZCk7XG4gICAgICAgIG9uRHJhZ1N0YXJ0Py4odGFzayk7XG4gICAgICB9fVxuICAgID5cbiAgICAgIDxDYXJkVGl0bGU+e3Rhc2sudGl0bGV9PC9DYXJkVGl0bGU+XG5cbiAgICAgIDxDYXJkTWV0YT5cbiAgICAgICAgPENoaXA+e3Rhc2sudGVhbS5uYW1lfTwvQ2hpcD5cbiAgICAgICAgPENoaXAgJHRvbmU9e3ByaW9yaXR5VG9uZVt0YXNrLnByaW9yaXR5XX0+e3ByaW9yaXR5TGFiZWxzW3Rhc2sucHJpb3JpdHldfTwvQ2hpcD5cbiAgICAgICAgPENoaXAgJHRvbmU9e2R1ZVRvbmUgPT09IFwiZGFuZ2VyXCIgPyBcImRhbmdlclwiIDogZHVlVG9uZSA9PT0gXCJ3YXJuaW5nXCIgPyBcIndhcm5pbmdcIiA6IFwiZGVmYXVsdFwifT5cbiAgICAgICAgICB7Zm9ybWF0RGF0ZSh0YXNrLmR1ZURhdGUpfVxuICAgICAgICA8L0NoaXA+XG4gICAgICA8L0NhcmRNZXRhPlxuXG4gICAgICA8Q2FyZE1ldGE+XG4gICAgICAgIDxzcGFuPiN7dGFzay5pZC5zbGljZSgwLCA4KX08L3NwYW4+XG4gICAgICAgIDxzcGFuPnt0YXNrLnJlc3BvbnNpYmxlPy5uYW1lID8/IFwiU2VtIHJlc3BvbnNhdmVsXCJ9PC9zcGFuPlxuICAgICAgPC9DYXJkTWV0YT5cblxuICAgICAgPENhcmRNZXRhPlxuICAgICAgICA8c3Bhbj5DcmlhZG8gZW0ge2Zvcm1hdERhdGVUaW1lKHRhc2suY3JlYXRlZEF0KX08L3NwYW4+XG4gICAgICA8L0NhcmRNZXRhPlxuICAgIDwvVGFza0NhcmRCdXR0b24+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3dhbGxhL0Rlc2t0b3AvUHJvamV0b3MtcGVzc29haXMvcHJvdmEtdGVjbmljYS9mcm9udC1taW5pLXRhc2stbWFuYWdlci9zcmMvY29tcG9uZW50cy90YXNrcy9UYXNrQ2FyZC50c3gifQ==