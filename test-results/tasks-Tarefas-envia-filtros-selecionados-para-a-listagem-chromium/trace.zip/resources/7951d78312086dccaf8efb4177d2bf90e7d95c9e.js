import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/publicRoutes.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=df6b4f96";
import { Route, Routes } from "/node_modules/.vite/deps/react-router.js?v=01185dd1";
import Login from "/src/pages/public/Login/index.tsx";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/publicRoutes.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=df6b4f96";
export function PublicRoutes() {
	const $ = _c(3);
	if ($[0] !== "ad4efb32b9b7e57ac9540c429401129b8b137c06ba0dd18ea83cf6099cd344d8") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "ad4efb32b9b7e57ac9540c429401129b8b137c06ba0dd18ea83cf6099cd344d8";
	}
	let t0;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ _jsxDEV(Route, {
			path: "/",
			element: /* @__PURE__ */ _jsxDEV(Login, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 35
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 10
		}, this);
		$[1] = t0;
	} else {
		t0 = $[1];
	}
	let t1;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = /* @__PURE__ */ _jsxDEV(Routes, { children: [t0, /* @__PURE__ */ _jsxDEV(Route, {
			path: "/login",
			element: /* @__PURE__ */ _jsxDEV(Login, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 52
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 22
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 10
		}, this);
		$[2] = t1;
	} else {
		t1 = $[2];
	}
	return t1;
}
_c2 = PublicRoutes;
var _c2;
$RefreshReg$(_c2, "PublicRoutes");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/publicRoutes.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/publicRoutes.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/publicRoutes.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/publicRoutes.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLE9BQU9DLGNBQWM7QUFDOUIsT0FBT0MsV0FBVzs7O0FBRWxCLE9BQU8sU0FBQUMsZUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFLO0NBQUEsSUFBQUwsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBR0RDLEtBQUEsd0JBQUMsT0FBRDtHQUFZO0dBQWEsaUNBQUMsT0FBRCxDQUFNOzs7OztFQUFHOzs7OztFQUFJTCxFQUFBLEtBQUFLO0NBQUE7RUFBQUEsS0FBQUwsRUFBQTtDQUFBO0NBQUEsSUFBQU07Q0FBQSxJQUFBTixFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFEeENFLEtBQUEsd0JBQUMsUUFBRCxhQUNFRCxJQUNBLHdCQUFDLE9BQUQ7R0FBWTtHQUFrQixpQ0FBQyxPQUFELENBQU07Ozs7O0VBQUc7Ozs7VUFGbEM7Ozs7O0VBR0VMLEVBQUEsS0FBQU07Q0FBQTtFQUFBQSxLQUFBTixFQUFBO0NBQUE7Q0FBQSxPQUhUTTtBQUdTIiwibmFtZXMiOlsiUm91dGUiLCJSb3V0ZXMiLCJMb2dpbiIsIlB1YmxpY1JvdXRlcyIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwidDAiLCJ0MSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJwdWJsaWNSb3V0ZXMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFJvdXRlLCBSb3V0ZXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyXCI7XG5pbXBvcnQgTG9naW4gZnJvbSBcIi4uL3BhZ2VzL3B1YmxpYy9Mb2dpblwiO1xuXG5leHBvcnQgZnVuY3Rpb24gUHVibGljUm91dGVzKCkge1xuICByZXR1cm4gKFxuICAgIDxSb3V0ZXM+XG4gICAgICA8Um91dGUgcGF0aD1cIi9cIiBlbGVtZW50PXs8TG9naW4gLz59IC8+XG4gICAgICA8Um91dGUgcGF0aD1cIi9sb2dpblwiIGVsZW1lbnQ9ezxMb2dpbiAvPn0gLz5cbiAgICA8L1JvdXRlcz5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvd2FsbGEvRGVza3RvcC9Qcm9qZXRvcy1wZXNzb2Fpcy9wcm92YS10ZWNuaWNhL2Zyb250LW1pbmktdGFzay1tYW5hZ2VyL3NyYy9yb3V0ZXMvcHVibGljUm91dGVzLnRzeCJ9