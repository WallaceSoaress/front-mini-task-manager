import styled from "/node_modules/.vite/deps/styled-components.js?v=b967f2da";
export const TeamsGrid = styled.section`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: 12px;
`;
export const TeamCard = styled.article`
  display: grid;
  gap: 14px;
  border: 1px solid #d9dce1;
  border-radius: 8px;
  padding: 16px;
  color: ${({ theme }) => theme.colors.text_black};
  background: ${({ theme }) => theme.colors.white};
  box-shadow: 0 1px 2px rgba(9, 30, 66, 0.12);

  h2 {
    margin: 0;
    font-size: 18px;
  }

  p {
    margin: 0;
    color: ${({ theme }) => theme.colors.dark};
    font-size: 14px;
  }
`;
export const TeamCardHeader = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;

  @media (max-width: 480px) {
    align-items: stretch;
    flex-direction: column;
  }
`;
export const TeamActions = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  flex-wrap: wrap;
`;
export const MemberList = styled.ul`
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin: 0;
  padding: 0;
  list-style: none;
`;
export const MemberBadge = styled.li`
  max-width: 100%;
  border: 1px solid ${({ theme }) => theme.colors.border};
  border-radius: 6px;
  padding: 5px 8px;
  overflow: hidden;
  color: ${({ theme }) => theme.colors.text_black};
  background: ${({ theme }) => theme.colors.lighter};
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 13px;
  font-weight: 700;
`;
export const HelperText = styled.span`
  color: ${({ theme }) => theme.colors.dark};
  font-size: 13px;
  font-weight: 500;
`;
export const SuccessMessage = styled.p`
  margin: 0;
  border: 1px solid ${({ theme }) => theme.colors.success};
  border-radius: 8px;
  padding: 12px 14px;
  color: ${({ theme }) => theme.colors.completed};
  background: ${({ theme }) => theme.colors.success_light};
  font-weight: 700;
`;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsT0FBT0EsWUFBWTtBQUVuQixPQUFPLE1BQU1DLFlBQVlELE9BQU9FLE9BQU87Ozs7O0FBTXZDLE9BQU8sTUFBTUMsV0FBV0gsT0FBT0ksT0FBTzs7Ozs7O1lBTTFCLEVBQUVDLFlBQVlBLE1BQU1DLE9BQU9DLFdBQVU7aUJBQ2hDLEVBQUVGLFlBQVlBLE1BQU1DLE9BQU9FLE1BQUs7Ozs7Ozs7Ozs7Y0FVbkMsRUFBRUgsWUFBWUEsTUFBTUMsT0FBT0csS0FBSTs7OztBQUs3QyxPQUFPLE1BQU1DLGlCQUFpQlYsT0FBT1csR0FBRzs7Ozs7Ozs7Ozs7QUFZeEMsT0FBTyxNQUFNQyxjQUFjWixPQUFPVyxHQUFHOzs7Ozs7QUFPckMsT0FBTyxNQUFNRSxhQUFhYixPQUFPYyxFQUFFOzs7Ozs7OztBQVNuQyxPQUFPLE1BQU1DLGNBQWNmLE9BQU9nQixFQUFFOzt1QkFFYixFQUFFWCxZQUFZQSxNQUFNQyxPQUFPVyxPQUFNOzs7O1lBSTVDLEVBQUVaLFlBQVlBLE1BQU1DLE9BQU9DLFdBQVU7aUJBQ2hDLEVBQUVGLFlBQVlBLE1BQU1DLE9BQU9ZLFFBQU87Ozs7OztBQU9uRCxPQUFPLE1BQU1DLGFBQWFuQixPQUFPb0IsSUFBSTtZQUN6QixFQUFFZixZQUFZQSxNQUFNQyxPQUFPRyxLQUFJOzs7O0FBSzNDLE9BQU8sTUFBTVksaUJBQWlCckIsT0FBT3NCLENBQUM7O3VCQUVmLEVBQUVqQixZQUFZQSxNQUFNQyxPQUFPaUIsUUFBTzs7O1lBRzdDLEVBQUVsQixZQUFZQSxNQUFNQyxPQUFPa0IsVUFBUztpQkFDL0IsRUFBRW5CLFlBQVlBLE1BQU1DLE9BQU9tQixjQUFhIiwibmFtZXMiOlsic3R5bGVkIiwiVGVhbXNHcmlkIiwic2VjdGlvbiIsIlRlYW1DYXJkIiwiYXJ0aWNsZSIsInRoZW1lIiwiY29sb3JzIiwidGV4dF9ibGFjayIsIndoaXRlIiwiZGFyayIsIlRlYW1DYXJkSGVhZGVyIiwiZGl2IiwiVGVhbUFjdGlvbnMiLCJNZW1iZXJMaXN0IiwidWwiLCJNZW1iZXJCYWRnZSIsImxpIiwiYm9yZGVyIiwibGlnaHRlciIsIkhlbHBlclRleHQiLCJzcGFuIiwiU3VjY2Vzc01lc3NhZ2UiLCJwIiwic3VjY2VzcyIsImNvbXBsZXRlZCIsInN1Y2Nlc3NfbGlnaHQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsic3R5bGVzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XG5cbmV4cG9ydCBjb25zdCBUZWFtc0dyaWQgPSBzdHlsZWQuc2VjdGlvbmBcbiAgZGlzcGxheTogZ3JpZDtcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiByZXBlYXQoYXV0by1maXQsIG1pbm1heCgyNjBweCwgMWZyKSk7XG4gIGdhcDogMTJweDtcbmA7XG5cbmV4cG9ydCBjb25zdCBUZWFtQ2FyZCA9IHN0eWxlZC5hcnRpY2xlYFxuICBkaXNwbGF5OiBncmlkO1xuICBnYXA6IDE0cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNkOWRjZTE7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgcGFkZGluZzogMTZweDtcbiAgY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLnRleHRfYmxhY2t9O1xuICBiYWNrZ3JvdW5kOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy53aGl0ZX07XG4gIGJveC1zaGFkb3c6IDAgMXB4IDJweCByZ2JhKDksIDMwLCA2NiwgMC4xMik7XG5cbiAgaDIge1xuICAgIG1hcmdpbjogMDtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gIH1cblxuICBwIHtcbiAgICBtYXJnaW46IDA7XG4gICAgY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLmRhcmt9O1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IFRlYW1DYXJkSGVhZGVyID0gc3R5bGVkLmRpdmBcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgZ2FwOiAxMnB4O1xuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA0ODBweCkge1xuICAgIGFsaWduLWl0ZW1zOiBzdHJldGNoO1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBUZWFtQWN0aW9ucyA9IHN0eWxlZC5kaXZgXG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gIGdhcDogOHB4O1xuICBmbGV4LXdyYXA6IHdyYXA7XG5gO1xuXG5leHBvcnQgY29uc3QgTWVtYmVyTGlzdCA9IHN0eWxlZC51bGBcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC13cmFwOiB3cmFwO1xuICBnYXA6IDhweDtcbiAgbWFyZ2luOiAwO1xuICBwYWRkaW5nOiAwO1xuICBsaXN0LXN0eWxlOiBub25lO1xuYDtcblxuZXhwb3J0IGNvbnN0IE1lbWJlckJhZGdlID0gc3R5bGVkLmxpYFxuICBtYXgtd2lkdGg6IDEwMCU7XG4gIGJvcmRlcjogMXB4IHNvbGlkICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLmJvcmRlcn07XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgcGFkZGluZzogNXB4IDhweDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLnRleHRfYmxhY2t9O1xuICBiYWNrZ3JvdW5kOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy5saWdodGVyfTtcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbmA7XG5cbmV4cG9ydCBjb25zdCBIZWxwZXJUZXh0ID0gc3R5bGVkLnNwYW5gXG4gIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy5kYXJrfTtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBmb250LXdlaWdodDogNTAwO1xuYDtcblxuZXhwb3J0IGNvbnN0IFN1Y2Nlc3NNZXNzYWdlID0gc3R5bGVkLnBgXG4gIG1hcmdpbjogMDtcbiAgYm9yZGVyOiAxcHggc29saWQgJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMuc3VjY2Vzc307XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgcGFkZGluZzogMTJweCAxNHB4O1xuICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMuY29tcGxldGVkfTtcbiAgYmFja2dyb3VuZDogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMuc3VjY2Vzc19saWdodH07XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG5gO1xuIl0sImZpbGUiOiJDOi9Vc2Vycy93YWxsYS9EZXNrdG9wL1Byb2pldG9zLXBlc3NvYWlzL3Byb3ZhLXRlY25pY2EvZnJvbnQtbWluaS10YXNrLW1hbmFnZXIvc3JjL2NvbXBvbmVudHMvdGVhbXMvc3R5bGVzLnRzIn0=