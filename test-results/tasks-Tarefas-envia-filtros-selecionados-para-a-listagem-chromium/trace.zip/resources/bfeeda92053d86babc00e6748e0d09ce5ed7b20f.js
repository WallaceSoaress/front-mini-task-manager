import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=df6b4f96";
import { QueryClient, QueryClientProvider } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=0247f062";
import { ThemeProvider } from "/node_modules/.vite/deps/styled-components.js?v=b967f2da";
import packageJson from "/package.json?import";
import { AuthProvider } from "/src/hooks/auth.tsx";
import { AppRoutes } from "/src/routes/index.tsx";
import "/src/styles/global-styles.css";
import themeDefault from "/src/styles/themeDefault.ts";
import { VersionBadge } from "/src/styles/styles.ts";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/App.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=df6b4f96";
const queryClient = new QueryClient();
function App() {
	const $ = _c(2);
	if ($[0] !== "627cdc48eb0c056d750909777cf5c77ae987cf09beba3b150b811267d0de9192") {
		for (let $i = 0; $i < 2; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "627cdc48eb0c056d750909777cf5c77ae987cf09beba3b150b811267d0de9192";
	}
	let t0;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ _jsxDEV(ThemeProvider, {
			theme: themeDefault,
			children: /* @__PURE__ */ _jsxDEV(QueryClientProvider, {
				client: queryClient,
				children: /* @__PURE__ */ _jsxDEV(AuthProvider, { children: [/* @__PURE__ */ _jsxDEV(AppRoutes, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 102
				}, this), /* @__PURE__ */ _jsxDEV(VersionBadge, { children: ["Mini Task Manager - v", packageJson.version] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 115
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 88
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 46
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 10
		}, this);
		$[1] = t0;
	} else {
		t0 = $[1];
	}
	return t0;
}
_c2 = App;
export default App;
var _c2;
$RefreshReg$(_c2, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLGFBQWFDLDJCQUEyQjtBQUNqRCxTQUFTQyxxQkFBcUI7QUFDOUIsT0FBT0MsaUJBQWlCO0FBQ3hCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxpQkFBaUI7QUFDMUIsT0FBTztBQUNQLE9BQU9DLGtCQUFrQjtBQUN6QixTQUFTQyxvQkFBb0I7OztBQUU3QixNQUFNQyxjQUFjLElBQUlSLFlBQVk7QUFFcEMsU0FBQVMsTUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFLO0NBQUEsSUFBQUwsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBRUlDLEtBQUEsd0JBQUMsZUFBRDtHQUFzQlQ7YUFDcEIsd0JBQUMscUJBQUQ7SUFBNkJFO2NBQzNCLHdCQUFDLGNBQUQsYUFDRSx3QkFBQyxXQUFELENBQVU7Ozs7Y0FDVix3QkFBQyxjQUFELGFBQWMseUJBQXNCTCxZQUFXYSxPQUFsQzs7OztZQUZGOzs7OztHQURLOzs7OztFQURSOzs7OztFQU9FTixFQUFBLEtBQUFLO0NBQUE7RUFBQUEsS0FBQUwsRUFBQTtDQUFBO0NBQUEsT0FQaEJLO0FBT2dCOztBQUlwQixlQUFlTiIsIm5hbWVzIjpbIlF1ZXJ5Q2xpZW50IiwiUXVlcnlDbGllbnRQcm92aWRlciIsIlRoZW1lUHJvdmlkZXIiLCJwYWNrYWdlSnNvbiIsIkF1dGhQcm92aWRlciIsIkFwcFJvdXRlcyIsInRoZW1lRGVmYXVsdCIsIlZlcnNpb25CYWRnZSIsInF1ZXJ5Q2xpZW50IiwiQXBwIiwiJCIsIl9jIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJ0MCIsInZlcnNpb24iXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBRdWVyeUNsaWVudCwgUXVlcnlDbGllbnRQcm92aWRlciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcbmltcG9ydCB7IFRoZW1lUHJvdmlkZXIgfSBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcbmltcG9ydCBwYWNrYWdlSnNvbiBmcm9tIFwiLi4vcGFja2FnZS5qc29uXCI7XG5pbXBvcnQgeyBBdXRoUHJvdmlkZXIgfSBmcm9tIFwiLi9ob29rcy9hdXRoXCI7XG5pbXBvcnQgeyBBcHBSb3V0ZXMgfSBmcm9tIFwiLi9yb3V0ZXNcIjtcbmltcG9ydCBcIi4vc3R5bGVzL2dsb2JhbC1zdHlsZXMuY3NzXCI7XG5pbXBvcnQgdGhlbWVEZWZhdWx0IGZyb20gXCIuL3N0eWxlcy90aGVtZURlZmF1bHRcIjtcbmltcG9ydCB7IFZlcnNpb25CYWRnZSB9IGZyb20gXCIuL3N0eWxlcy9zdHlsZXNcIjtcblxuY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKTtcblxuZnVuY3Rpb24gQXBwKCkge1xuICByZXR1cm4gKFxuICAgIDxUaGVtZVByb3ZpZGVyIHRoZW1lPXt0aGVtZURlZmF1bHR9PlxuICAgICAgPFF1ZXJ5Q2xpZW50UHJvdmlkZXIgY2xpZW50PXtxdWVyeUNsaWVudH0+XG4gICAgICAgIDxBdXRoUHJvdmlkZXI+XG4gICAgICAgICAgPEFwcFJvdXRlcyAvPlxuICAgICAgICAgIDxWZXJzaW9uQmFkZ2U+TWluaSBUYXNrIE1hbmFnZXIgLSB2e3BhY2thZ2VKc29uLnZlcnNpb259PC9WZXJzaW9uQmFkZ2U+XG4gICAgICAgIDwvQXV0aFByb3ZpZGVyPlxuICAgICAgPC9RdWVyeUNsaWVudFByb3ZpZGVyPlxuICAgIDwvVGhlbWVQcm92aWRlcj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwO1xuIl0sImZpbGUiOiJDOi9Vc2Vycy93YWxsYS9EZXNrdG9wL1Byb2pldG9zLXBlc3NvYWlzL3Byb3ZhLXRlY25pY2EvZnJvbnQtbWluaS10YXNrLW1hbmFnZXIvc3JjL0FwcC50c3gifQ==