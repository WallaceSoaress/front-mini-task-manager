import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/index.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=df6b4f96";
import { BrowserRouter, Navigate, Route, Routes } from "/node_modules/.vite/deps/react-router.js?v=01185dd1";
import { useAuth } from "/src/hooks/auth.tsx";
import { PrivateRoutes } from "/src/routes/adminRoutes/privateRoutes.tsx";
import { PublicRoutes } from "/src/routes/publicRoutes.tsx";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/index.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=df6b4f96";
var _s = $RefreshSig$();
export function AppRoutes() {
	_s();
	const $ = _c(3);
	if ($[0] !== "1169d6e3d74cd2c95bf0b01aabffaf51edaae67786db1d549c4c8480ab56a93e") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "1169d6e3d74cd2c95bf0b01aabffaf51edaae67786db1d549c4c8480ab56a93e";
	}
	const { isAuthorized, isLoadingAuth } = useAuth();
	if (isLoadingAuth) {
		return null;
	}
	let t0;
	if ($[1] !== isAuthorized) {
		t0 = /* @__PURE__ */ _jsxDEV(BrowserRouter, { children: /* @__PURE__ */ _jsxDEV(Routes, { children: isAuthorized ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Route, {
			path: "/*",
			element: /* @__PURE__ */ _jsxDEV(PrivateRoutes, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 77
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 51
		}, this), /* @__PURE__ */ _jsxDEV(Route, {
			path: "/login",
			element: /* @__PURE__ */ _jsxDEV(Navigate, {
				to: "/",
				replace: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 128
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 98
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 49
		}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Route, {
			path: "/login",
			element: /* @__PURE__ */ _jsxDEV(PublicRoutes, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 204
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 174
		}, this), /* @__PURE__ */ _jsxDEV(Route, {
			path: "*",
			element: /* @__PURE__ */ _jsxDEV(Navigate, {
				to: "/login",
				replace: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 249
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 224
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 172
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 25
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 10
		}, this);
		$[1] = isAuthorized;
		$[2] = t0;
	} else {
		t0 = $[2];
	}
	return t0;
}
_s(AppRoutes, "DSN5e0XMcNYL/PibHl/V4Q6E6Sw=", false, function() {
	return [useAuth];
});
_c2 = AppRoutes;
var _c2;
$RefreshReg$(_c2, "AppRoutes");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLGVBQWVDLFVBQVVDLE9BQU9DLGNBQWM7QUFDdkQsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0Msb0JBQW9COzs7O0FBRTdCLE9BQU8sU0FBQUMsWUFBQTs7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FDTCxRQUFBSyxjQUFBQyxrQkFBd0NWLFFBQVE7Q0FFaEQsSUFBSVUsZUFBYTtFQUFBLE9BQ1I7Q0FBSTtDQUNaLElBQUFDO0NBQUEsSUFBQVAsRUFBQSxPQUFBSyxjQUFBO0VBR0NFLEtBQUEsd0JBQUMsZUFBRCxZQUNFLHdCQUFDLFFBQUQsWUFDR0YsZUFBQSxnREFFRyx3QkFBQyxPQUFEO0dBQVk7R0FBYyxpQ0FBQyxlQUFELENBQWM7Ozs7O0VBQUc7Ozs7WUFDM0Msd0JBQUMsT0FBRDtHQUFZO0dBQWtCLGlDQUFDLFVBQUQ7SUFBYTtJQUFJO0dBQU87Ozs7O0VBQUc7Ozs7VUFBSTs7OzthQUhoRSxnREFPRyx3QkFBQyxPQUFEO0dBQVk7R0FBa0IsaUNBQUMsY0FBRCxDQUFhOzs7OztFQUFHOzs7O1lBQzlDLHdCQUFDLE9BQUQ7R0FBWTtHQUFhLGlDQUFDLFVBQUQ7SUFBYTtJQUFTO0dBQU87Ozs7O0VBQUc7Ozs7VUFBSTs7OztXQVQ1RDs7OztXQURLOzs7OztFQWNFTCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU87Q0FBQTtFQUFBQSxLQUFBUCxFQUFBO0NBQUE7Q0FBQSxPQWRoQk87QUFjZ0IiLCJuYW1lcyI6WyJCcm93c2VyUm91dGVyIiwiTmF2aWdhdGUiLCJSb3V0ZSIsIlJvdXRlcyIsInVzZUF1dGgiLCJQcml2YXRlUm91dGVzIiwiUHVibGljUm91dGVzIiwiQXBwUm91dGVzIiwiJCIsIl9jIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJpc0F1dGhvcml6ZWQiLCJpc0xvYWRpbmdBdXRoIiwidDAiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJyb3dzZXJSb3V0ZXIsIE5hdmlnYXRlLCBSb3V0ZSwgUm91dGVzIH0gZnJvbSBcInJlYWN0LXJvdXRlclwiO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCIuLi9ob29rcy9hdXRoXCI7XG5pbXBvcnQgeyBQcml2YXRlUm91dGVzIH0gZnJvbSBcIi4vYWRtaW5Sb3V0ZXMvcHJpdmF0ZVJvdXRlc1wiO1xuaW1wb3J0IHsgUHVibGljUm91dGVzIH0gZnJvbSBcIi4vcHVibGljUm91dGVzXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBBcHBSb3V0ZXMoKSB7XG4gIGNvbnN0IHsgaXNBdXRob3JpemVkLCBpc0xvYWRpbmdBdXRoIH0gPSB1c2VBdXRoKCk7XG5cbiAgaWYgKGlzTG9hZGluZ0F1dGgpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPEJyb3dzZXJSb3V0ZXI+XG4gICAgICA8Um91dGVzPlxuICAgICAgICB7aXNBdXRob3JpemVkID8gKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIi8qXCIgZWxlbWVudD17PFByaXZhdGVSb3V0ZXMgLz59IC8+XG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9sb2dpblwiIGVsZW1lbnQ9ezxOYXZpZ2F0ZSB0bz1cIi9cIiByZXBsYWNlIC8+fSAvPlxuICAgICAgICAgIDwvPlxuICAgICAgICApIDogKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9sb2dpblwiIGVsZW1lbnQ9ezxQdWJsaWNSb3V0ZXMgLz59IC8+XG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIipcIiBlbGVtZW50PXs8TmF2aWdhdGUgdG89XCIvbG9naW5cIiByZXBsYWNlIC8+fSAvPlxuICAgICAgICAgIDwvPlxuICAgICAgICApfVxuICAgICAgPC9Sb3V0ZXM+XG4gICAgPC9Ccm93c2VyUm91dGVyPlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy93YWxsYS9EZXNrdG9wL1Byb2pldG9zLXBlc3NvYWlzL3Byb3ZhLXRlY25pY2EvZnJvbnQtbWluaS10YXNrLW1hbmFnZXIvc3JjL3JvdXRlcy9pbmRleC50c3gifQ==