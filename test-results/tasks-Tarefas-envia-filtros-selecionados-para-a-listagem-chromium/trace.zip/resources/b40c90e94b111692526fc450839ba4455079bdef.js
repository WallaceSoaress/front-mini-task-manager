import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/tasks/TaskDetailsModal.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=df6b4f96";
import { formatDate, formatDateTime, priorityLabels, statusLabels } from "/src/components/tasks/labels.ts";
import { Button, DetailGrid, ModalActions, ModalBackdrop, ModalBody, ModalHeader, ModalPanel } from "/src/components/tasks/styles.ts";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskDetailsModal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=df6b4f96";
export function TaskDetailsModal(t0) {
	const $ = _c(73);
	if ($[0] !== "eae5a5afa361c77eb772e4757ef46fa67beb4f751108bef2143c04039cc99a36") {
		for (let $i = 0; $i < 73; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "eae5a5afa361c77eb772e4757ef46fa67beb4f751108bef2143c04039cc99a36";
	}
	const { task, onClose, onEdit, onDelete } = t0;
	let t1;
	if ($[1] !== task.title) {
		t1 = /* @__PURE__ */ _jsxDEV("h2", {
			id: "task-details-title",
			children: task.title
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 10
		}, this);
		$[1] = task.title;
		$[2] = t1;
	} else {
		t1 = $[2];
	}
	let t2;
	if ($[3] !== task.id) {
		t2 = task.id.slice(0, 8);
		$[3] = task.id;
		$[4] = t2;
	} else {
		t2 = $[4];
	}
	let t3;
	if ($[5] !== t2) {
		t3 = /* @__PURE__ */ _jsxDEV("p", { children: ["#", t2] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 43,
			columnNumber: 10
		}, this);
		$[5] = t2;
		$[6] = t3;
	} else {
		t3 = $[6];
	}
	let t4;
	if ($[7] !== t1 || $[8] !== t3) {
		t4 = /* @__PURE__ */ _jsxDEV("div", { children: [t1, t3] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 51,
			columnNumber: 10
		}, this);
		$[7] = t1;
		$[8] = t3;
		$[9] = t4;
	} else {
		t4 = $[9];
	}
	let t5;
	if ($[10] !== onClose) {
		t5 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			$variant: "ghost",
			onClick: onClose,
			children: "Fechar"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 60,
			columnNumber: 10
		}, this);
		$[10] = onClose;
		$[11] = t5;
	} else {
		t5 = $[11];
	}
	let t6;
	if ($[12] !== t4 || $[13] !== t5) {
		t6 = /* @__PURE__ */ _jsxDEV(ModalHeader, { children: [t4, t5] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 68,
			columnNumber: 10
		}, this);
		$[12] = t4;
		$[13] = t5;
		$[14] = t6;
	} else {
		t6 = $[14];
	}
	let t7;
	if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
		t7 = /* @__PURE__ */ _jsxDEV("dt", { children: "Status" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 77,
			columnNumber: 10
		}, this);
		$[15] = t7;
	} else {
		t7 = $[15];
	}
	const t8 = statusLabels[task.status];
	let t9;
	if ($[16] !== t8) {
		t9 = /* @__PURE__ */ _jsxDEV("div", { children: [t7, /* @__PURE__ */ _jsxDEV("dd", { children: t8 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 85,
			columnNumber: 19
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 85,
			columnNumber: 10
		}, this);
		$[16] = t8;
		$[17] = t9;
	} else {
		t9 = $[17];
	}
	let t10;
	if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
		t10 = /* @__PURE__ */ _jsxDEV("dt", { children: "Prioridade" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 93,
			columnNumber: 11
		}, this);
		$[18] = t10;
	} else {
		t10 = $[18];
	}
	const t11 = priorityLabels[task.priority];
	let t12;
	if ($[19] !== t11) {
		t12 = /* @__PURE__ */ _jsxDEV("div", { children: [t10, /* @__PURE__ */ _jsxDEV("dd", { children: t11 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 101,
			columnNumber: 21
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 101,
			columnNumber: 11
		}, this);
		$[19] = t11;
		$[20] = t12;
	} else {
		t12 = $[20];
	}
	let t13;
	if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
		t13 = /* @__PURE__ */ _jsxDEV("dt", { children: "Responsavel" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 109,
			columnNumber: 11
		}, this);
		$[21] = t13;
	} else {
		t13 = $[21];
	}
	const t14 = task.responsible?.name ?? "Nao atribuido";
	let t15;
	if ($[22] !== t14) {
		t15 = /* @__PURE__ */ _jsxDEV("div", { children: [t13, /* @__PURE__ */ _jsxDEV("dd", { children: t14 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 117,
			columnNumber: 21
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 117,
			columnNumber: 11
		}, this);
		$[22] = t14;
		$[23] = t15;
	} else {
		t15 = $[23];
	}
	let t16;
	if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
		t16 = /* @__PURE__ */ _jsxDEV("dt", { children: "Time" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 125,
			columnNumber: 11
		}, this);
		$[24] = t16;
	} else {
		t16 = $[24];
	}
	let t17;
	if ($[25] !== task.team.name) {
		t17 = /* @__PURE__ */ _jsxDEV("div", { children: [t16, /* @__PURE__ */ _jsxDEV("dd", { children: task.team.name }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 132,
			columnNumber: 21
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 132,
			columnNumber: 11
		}, this);
		$[25] = task.team.name;
		$[26] = t17;
	} else {
		t17 = $[26];
	}
	let t18;
	if ($[27] === Symbol.for("react.memo_cache_sentinel")) {
		t18 = /* @__PURE__ */ _jsxDEV("dt", { children: "Criador" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 140,
			columnNumber: 11
		}, this);
		$[27] = t18;
	} else {
		t18 = $[27];
	}
	let t19;
	if ($[28] !== task.createdBy.name) {
		t19 = /* @__PURE__ */ _jsxDEV("div", { children: [t18, /* @__PURE__ */ _jsxDEV("dd", { children: task.createdBy.name }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 147,
			columnNumber: 21
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 147,
			columnNumber: 11
		}, this);
		$[28] = task.createdBy.name;
		$[29] = t19;
	} else {
		t19 = $[29];
	}
	let t20;
	if ($[30] === Symbol.for("react.memo_cache_sentinel")) {
		t20 = /* @__PURE__ */ _jsxDEV("dt", { children: "Prazo" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 155,
			columnNumber: 11
		}, this);
		$[30] = t20;
	} else {
		t20 = $[30];
	}
	let t21;
	if ($[31] !== task.dueDate) {
		t21 = formatDate(task.dueDate);
		$[31] = task.dueDate;
		$[32] = t21;
	} else {
		t21 = $[32];
	}
	let t22;
	if ($[33] !== t21) {
		t22 = /* @__PURE__ */ _jsxDEV("div", { children: [t20, /* @__PURE__ */ _jsxDEV("dd", { children: t21 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 170,
			columnNumber: 21
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 170,
			columnNumber: 11
		}, this);
		$[33] = t21;
		$[34] = t22;
	} else {
		t22 = $[34];
	}
	let t23;
	if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
		t23 = /* @__PURE__ */ _jsxDEV("dt", { children: "Criacao" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 178,
			columnNumber: 11
		}, this);
		$[35] = t23;
	} else {
		t23 = $[35];
	}
	let t24;
	if ($[36] !== task.createdAt) {
		t24 = formatDateTime(task.createdAt);
		$[36] = task.createdAt;
		$[37] = t24;
	} else {
		t24 = $[37];
	}
	let t25;
	if ($[38] !== t24) {
		t25 = /* @__PURE__ */ _jsxDEV("div", { children: [t23, /* @__PURE__ */ _jsxDEV("dd", { children: t24 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 193,
			columnNumber: 21
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 193,
			columnNumber: 11
		}, this);
		$[38] = t24;
		$[39] = t25;
	} else {
		t25 = $[39];
	}
	let t26;
	if ($[40] === Symbol.for("react.memo_cache_sentinel")) {
		t26 = /* @__PURE__ */ _jsxDEV("dt", { children: "Ultima atualizacao" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 201,
			columnNumber: 11
		}, this);
		$[40] = t26;
	} else {
		t26 = $[40];
	}
	let t27;
	if ($[41] !== task.updatedAt) {
		t27 = formatDateTime(task.updatedAt);
		$[41] = task.updatedAt;
		$[42] = t27;
	} else {
		t27 = $[42];
	}
	let t28;
	if ($[43] !== t27) {
		t28 = /* @__PURE__ */ _jsxDEV("div", { children: [t26, /* @__PURE__ */ _jsxDEV("dd", { children: t27 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 216,
			columnNumber: 21
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 216,
			columnNumber: 11
		}, this);
		$[43] = t27;
		$[44] = t28;
	} else {
		t28 = $[44];
	}
	let t29;
	if ($[45] === Symbol.for("react.memo_cache_sentinel")) {
		t29 = /* @__PURE__ */ _jsxDEV("dt", { children: "Descricao" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 224,
			columnNumber: 11
		}, this);
		$[45] = t29;
	} else {
		t29 = $[45];
	}
	const t30 = task.description || "Sem descricao.";
	let t31;
	if ($[46] !== t30) {
		t31 = /* @__PURE__ */ _jsxDEV("div", { children: [t29, /* @__PURE__ */ _jsxDEV("dd", { children: t30 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 232,
			columnNumber: 21
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 232,
			columnNumber: 11
		}, this);
		$[46] = t30;
		$[47] = t31;
	} else {
		t31 = $[47];
	}
	let t32;
	if ($[48] !== t12 || $[49] !== t15 || $[50] !== t17 || $[51] !== t19 || $[52] !== t22 || $[53] !== t25 || $[54] !== t28 || $[55] !== t31 || $[56] !== t9) {
		t32 = /* @__PURE__ */ _jsxDEV(DetailGrid, { children: [
			t9,
			t12,
			t15,
			t17,
			t19,
			t22,
			t25,
			t28,
			t31
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 240,
			columnNumber: 11
		}, this);
		$[48] = t12;
		$[49] = t15;
		$[50] = t17;
		$[51] = t19;
		$[52] = t22;
		$[53] = t25;
		$[54] = t28;
		$[55] = t31;
		$[56] = t9;
		$[57] = t32;
	} else {
		t32 = $[57];
	}
	let t33;
	if ($[58] !== onEdit || $[59] !== task) {
		t33 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			$variant: "ghost",
			onClick: () => onEdit(task),
			children: "Editar"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 256,
			columnNumber: 11
		}, this);
		$[58] = onEdit;
		$[59] = task;
		$[60] = t33;
	} else {
		t33 = $[60];
	}
	let t34;
	if ($[61] !== onDelete || $[62] !== task) {
		t34 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			$variant: "danger",
			onClick: () => onDelete(task),
			children: "Excluir"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 265,
			columnNumber: 11
		}, this);
		$[61] = onDelete;
		$[62] = task;
		$[63] = t34;
	} else {
		t34 = $[63];
	}
	let t35;
	if ($[64] !== t33 || $[65] !== t34) {
		t35 = /* @__PURE__ */ _jsxDEV(ModalActions, { children: [t33, t34] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 274,
			columnNumber: 11
		}, this);
		$[64] = t33;
		$[65] = t34;
		$[66] = t35;
	} else {
		t35 = $[66];
	}
	let t36;
	if ($[67] !== t32 || $[68] !== t35) {
		t36 = /* @__PURE__ */ _jsxDEV(ModalBody, { children: [t32, t35] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 283,
			columnNumber: 11
		}, this);
		$[67] = t32;
		$[68] = t35;
		$[69] = t36;
	} else {
		t36 = $[69];
	}
	let t37;
	if ($[70] !== t36 || $[71] !== t6) {
		t37 = /* @__PURE__ */ _jsxDEV(ModalBackdrop, {
			role: "presentation",
			children: /* @__PURE__ */ _jsxDEV(ModalPanel, {
				role: "dialog",
				"aria-modal": "true",
				"aria-labelledby": "task-details-title",
				children: [t6, t36]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 292,
				columnNumber: 46
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 292,
			columnNumber: 11
		}, this);
		$[70] = t36;
		$[71] = t6;
		$[72] = t37;
	} else {
		t37 = $[72];
	}
	return t37;
}
_c2 = TaskDetailsModal;
var _c2;
$RefreshReg$(_c2, "TaskDetailsModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/tasks/TaskDetailsModal.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskDetailsModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskDetailsModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskDetailsModal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUNBLFNBQVNBLFlBQVlDLGdCQUFnQkMsZ0JBQWdCQyxvQkFBb0I7QUFDekUsU0FBU0MsUUFBUUMsWUFBWUMsY0FBY0MsZUFBZUMsV0FBV0MsYUFBYUMsa0JBQWtCOzs7QUFTcEcsT0FBTyxTQUFBQyxpQkFBQUMsSUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLElBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUEwQixRQUFBSyxNQUFBQyxTQUFBQyxRQUFBQyxhQUFBVDtDQUEwRCxJQUFBVTtDQUFBLElBQUFULEVBQUEsT0FBQUssS0FBQUssT0FBQTtFQU0vRUQsS0FBQTtHQUFPO2FBQXNCSixLQUFJSztFQUFZOzs7OztFQUFBVixFQUFBLEtBQUFLLEtBQUFLO0VBQUFWLEVBQUEsS0FBQVM7Q0FBQTtFQUFBQSxLQUFBVCxFQUFBO0NBQUE7Q0FBQSxJQUFBVztDQUFBLElBQUFYLEVBQUEsT0FBQUssS0FBQU8sSUFBQTtFQUN4Q0QsS0FBQU4sS0FBSU8sR0FBR0MsTUFBTyxHQUFHLENBQUM7RUFBQ2IsRUFBQSxLQUFBSyxLQUFBTztFQUFBWixFQUFBLEtBQUFXO0NBQUE7RUFBQUEsS0FBQVgsRUFBQTtDQUFBO0NBQUEsSUFBQWM7Q0FBQSxJQUFBZCxFQUFBLE9BQUFXLElBQUE7RUFBeEJHLEtBQUEsMENBQUcsS0FBRUgsRUFBd0I7Ozs7O0VBQUFYLEVBQUEsS0FBQVc7RUFBQVgsRUFBQSxLQUFBYztDQUFBO0VBQUFBLEtBQUFkLEVBQUE7Q0FBQTtDQUFBLElBQUFlO0NBQUEsSUFBQWYsRUFBQSxPQUFBUyxNQUFBVCxFQUFBLE9BQUFjLElBQUE7RUFGL0JDLEtBQUEsNENBQ0VOLElBQ0FLLEVBQ0k7Ozs7O0VBQUFkLEVBQUEsS0FBQVM7RUFBQVQsRUFBQSxLQUFBYztFQUFBZCxFQUFBLEtBQUFlO0NBQUE7RUFBQUEsS0FBQWYsRUFBQTtDQUFBO0NBQUEsSUFBQWdCO0NBQUEsSUFBQWhCLEVBQUEsUUFBQU0sU0FBQTtFQUNOVSxLQUFBLHdCQUFDLFFBQUQ7R0FBYTtHQUFrQjtHQUFpQlY7YUFBUztFQUFsRDs7Ozs7RUFFRU4sRUFBQSxNQUFBTTtFQUFBTixFQUFBLE1BQUFnQjtDQUFBO0VBQUFBLEtBQUFoQixFQUFBO0NBQUE7Q0FBQSxJQUFBaUI7Q0FBQSxJQUFBakIsRUFBQSxRQUFBZSxNQUFBZixFQUFBLFFBQUFnQixJQUFBO0VBUFhDLEtBQUEsd0JBQUMsYUFBRCxhQUNFRixJQUlBQyxFQUxVOzs7OztFQVFFaEIsRUFBQSxNQUFBZTtFQUFBZixFQUFBLE1BQUFnQjtFQUFBaEIsRUFBQSxNQUFBaUI7Q0FBQTtFQUFBQSxLQUFBakIsRUFBQTtDQUFBO0NBQUEsSUFBQWtCO0NBQUEsSUFBQWxCLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQUtSYyxLQUFBLDBDQUFJLFNBQVc7Ozs7O0VBQUFsQixFQUFBLE1BQUFrQjtDQUFBO0VBQUFBLEtBQUFsQixFQUFBO0NBQUE7Q0FDVixNQUFBbUIsS0FBQTdCLGFBQWFlLEtBQUllO0NBQVEsSUFBQUM7Q0FBQSxJQUFBckIsRUFBQSxRQUFBbUIsSUFBQTtFQUZoQ0UsS0FBQSw0Q0FDRUgsSUFDQSwwQ0FBS0MsR0FBK0I7Ozs7VUFDaEM7Ozs7O0VBQUFuQixFQUFBLE1BQUFtQjtFQUFBbkIsRUFBQSxNQUFBcUI7Q0FBQTtFQUFBQSxLQUFBckIsRUFBQTtDQUFBO0NBQUEsSUFBQXNCO0NBQUEsSUFBQXRCLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQUVKa0IsTUFBQSwwQ0FBSSxhQUFlOzs7OztFQUFBdEIsRUFBQSxNQUFBc0I7Q0FBQTtFQUFBQSxNQUFBdEIsRUFBQTtDQUFBO0NBQ2QsTUFBQXVCLE1BQUFsQyxlQUFlZ0IsS0FBSW1CO0NBQVUsSUFBQUM7Q0FBQSxJQUFBekIsRUFBQSxRQUFBdUIsS0FBQTtFQUZwQ0UsTUFBQSw0Q0FDRUgsS0FDQSwwQ0FBS0MsSUFBbUM7Ozs7VUFDcEM7Ozs7O0VBQUF2QixFQUFBLE1BQUF1QjtFQUFBdkIsRUFBQSxNQUFBeUI7Q0FBQTtFQUFBQSxNQUFBekIsRUFBQTtDQUFBO0NBQUEsSUFBQTBCO0NBQUEsSUFBQTFCLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQUVKc0IsTUFBQSwwQ0FBSSxjQUFnQjs7Ozs7RUFBQTFCLEVBQUEsTUFBQTBCO0NBQUE7RUFBQUEsTUFBQTFCLEVBQUE7Q0FBQTtDQUNmLE1BQUEyQixNQUFBdEIsS0FBSXVCLGFBQWtCQyxRQUF0QjtDQUF5QyxJQUFBQztDQUFBLElBQUE5QixFQUFBLFFBQUEyQixLQUFBO0VBRmhERyxNQUFBLDRDQUNFSixLQUNBLDBDQUFLQyxJQUErQzs7OztVQUNoRDs7Ozs7RUFBQTNCLEVBQUEsTUFBQTJCO0VBQUEzQixFQUFBLE1BQUE4QjtDQUFBO0VBQUFBLE1BQUE5QixFQUFBO0NBQUE7Q0FBQSxJQUFBK0I7Q0FBQSxJQUFBL0IsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBRUoyQixNQUFBLDBDQUFJLE9BQVM7Ozs7O0VBQUEvQixFQUFBLE1BQUErQjtDQUFBO0VBQUFBLE1BQUEvQixFQUFBO0NBQUE7Q0FBQSxJQUFBZ0M7Q0FBQSxJQUFBaEMsRUFBQSxRQUFBSyxLQUFBNEIsS0FBQUosTUFBQTtFQURmRyxNQUFBLDRDQUNFRCxLQUNBLDBDQUFLMUIsS0FBSTRCLEtBQUtKLEtBQVc7Ozs7VUFDckI7Ozs7O0VBQUE3QixFQUFBLE1BQUFLLEtBQUE0QixLQUFBSjtFQUFBN0IsRUFBQSxNQUFBZ0M7Q0FBQTtFQUFBQSxNQUFBaEMsRUFBQTtDQUFBO0NBQUEsSUFBQWtDO0NBQUEsSUFBQWxDLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQUVKOEIsTUFBQSwwQ0FBSSxVQUFZOzs7OztFQUFBbEMsRUFBQSxNQUFBa0M7Q0FBQTtFQUFBQSxNQUFBbEMsRUFBQTtDQUFBO0NBQUEsSUFBQW1DO0NBQUEsSUFBQW5DLEVBQUEsUUFBQUssS0FBQStCLFVBQUFQLE1BQUE7RUFEbEJNLE1BQUEsNENBQ0VELEtBQ0EsMENBQUs3QixLQUFJK0IsVUFBVVAsS0FBVzs7OztVQUMxQjs7Ozs7RUFBQTdCLEVBQUEsTUFBQUssS0FBQStCLFVBQUFQO0VBQUE3QixFQUFBLE1BQUFtQztDQUFBO0VBQUFBLE1BQUFuQyxFQUFBO0NBQUE7Q0FBQSxJQUFBcUM7Q0FBQSxJQUFBckMsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBRUppQyxNQUFBLDBDQUFJLFFBQVU7Ozs7O0VBQUFyQyxFQUFBLE1BQUFxQztDQUFBO0VBQUFBLE1BQUFyQyxFQUFBO0NBQUE7Q0FBQSxJQUFBc0M7Q0FBQSxJQUFBdEMsRUFBQSxRQUFBSyxLQUFBa0MsU0FBQTtFQUNURCxNQUFBbkQsV0FBV2tCLEtBQUlrQyxPQUFRO0VBQUN2QyxFQUFBLE1BQUFLLEtBQUFrQztFQUFBdkMsRUFBQSxNQUFBc0M7Q0FBQTtFQUFBQSxNQUFBdEMsRUFBQTtDQUFBO0NBQUEsSUFBQXdDO0NBQUEsSUFBQXhDLEVBQUEsUUFBQXNDLEtBQUE7RUFGL0JFLE1BQUEsNENBQ0VILEtBQ0EsMENBQUtDLElBQThCOzs7O1VBQy9COzs7OztFQUFBdEMsRUFBQSxNQUFBc0M7RUFBQXRDLEVBQUEsTUFBQXdDO0NBQUE7RUFBQUEsTUFBQXhDLEVBQUE7Q0FBQTtDQUFBLElBQUF5QztDQUFBLElBQUF6QyxFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFFSnFDLE1BQUEsMENBQUksVUFBWTs7Ozs7RUFBQXpDLEVBQUEsTUFBQXlDO0NBQUE7RUFBQUEsTUFBQXpDLEVBQUE7Q0FBQTtDQUFBLElBQUEwQztDQUFBLElBQUExQyxFQUFBLFFBQUFLLEtBQUFzQyxXQUFBO0VBQ1hELE1BQUF0RCxlQUFlaUIsS0FBSXNDLFNBQVU7RUFBQzNDLEVBQUEsTUFBQUssS0FBQXNDO0VBQUEzQyxFQUFBLE1BQUEwQztDQUFBO0VBQUFBLE1BQUExQyxFQUFBO0NBQUE7Q0FBQSxJQUFBNEM7Q0FBQSxJQUFBNUMsRUFBQSxRQUFBMEMsS0FBQTtFQUZyQ0UsTUFBQSw0Q0FDRUgsS0FDQSwwQ0FBS0MsSUFBb0M7Ozs7VUFDckM7Ozs7O0VBQUExQyxFQUFBLE1BQUEwQztFQUFBMUMsRUFBQSxNQUFBNEM7Q0FBQTtFQUFBQSxNQUFBNUMsRUFBQTtDQUFBO0NBQUEsSUFBQTZDO0NBQUEsSUFBQTdDLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQUVKeUMsTUFBQSwwQ0FBSSxxQkFBdUI7Ozs7O0VBQUE3QyxFQUFBLE1BQUE2QztDQUFBO0VBQUFBLE1BQUE3QyxFQUFBO0NBQUE7Q0FBQSxJQUFBOEM7Q0FBQSxJQUFBOUMsRUFBQSxRQUFBSyxLQUFBMEMsV0FBQTtFQUN0QkQsTUFBQTFELGVBQWVpQixLQUFJMEMsU0FBVTtFQUFDL0MsRUFBQSxNQUFBSyxLQUFBMEM7RUFBQS9DLEVBQUEsTUFBQThDO0NBQUE7RUFBQUEsTUFBQTlDLEVBQUE7Q0FBQTtDQUFBLElBQUFnRDtDQUFBLElBQUFoRCxFQUFBLFFBQUE4QyxLQUFBO0VBRnJDRSxNQUFBLDRDQUNFSCxLQUNBLDBDQUFLQyxJQUFvQzs7OztVQUNyQzs7Ozs7RUFBQTlDLEVBQUEsTUFBQThDO0VBQUE5QyxFQUFBLE1BQUFnRDtDQUFBO0VBQUFBLE1BQUFoRCxFQUFBO0NBQUE7Q0FBQSxJQUFBaUQ7Q0FBQSxJQUFBakQsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBRUo2QyxNQUFBLDBDQUFJLFlBQWM7Ozs7O0VBQUFqRCxFQUFBLE1BQUFpRDtDQUFBO0VBQUFBLE1BQUFqRCxFQUFBO0NBQUE7Q0FDYixNQUFBa0QsTUFBQTdDLEtBQUk4QyxlQUFKO0NBQW9DLElBQUFDO0NBQUEsSUFBQXBELEVBQUEsUUFBQWtELEtBQUE7RUFGM0NFLE1BQUEsNENBQ0VILEtBQ0EsMENBQUtDLElBQTBDOzs7O1VBQzNDOzs7OztFQUFBbEQsRUFBQSxNQUFBa0Q7RUFBQWxELEVBQUEsTUFBQW9EO0NBQUE7RUFBQUEsTUFBQXBELEVBQUE7Q0FBQTtDQUFBLElBQUFxRDtDQUFBLElBQUFyRCxFQUFBLFFBQUF5QixPQUFBekIsRUFBQSxRQUFBOEIsT0FBQTlCLEVBQUEsUUFBQWdDLE9BQUFoQyxFQUFBLFFBQUFtQyxPQUFBbkMsRUFBQSxRQUFBd0MsT0FBQXhDLEVBQUEsUUFBQTRDLE9BQUE1QyxFQUFBLFFBQUFnRCxPQUFBaEQsRUFBQSxRQUFBb0QsT0FBQXBELEVBQUEsUUFBQXFCLElBQUE7RUFwQ1JnQyxNQUFBLHdCQUFDLFlBQUQ7R0FDRWhDO0dBSUFJO0dBSUFLO0dBSUFFO0dBSUFHO0dBSUFLO0dBSUFJO0dBSUFJO0dBSUFJO0VBakNTOzs7OztFQXFDRXBELEVBQUEsTUFBQXlCO0VBQUF6QixFQUFBLE1BQUE4QjtFQUFBOUIsRUFBQSxNQUFBZ0M7RUFBQWhDLEVBQUEsTUFBQW1DO0VBQUFuQyxFQUFBLE1BQUF3QztFQUFBeEMsRUFBQSxNQUFBNEM7RUFBQTVDLEVBQUEsTUFBQWdEO0VBQUFoRCxFQUFBLE1BQUFvRDtFQUFBcEQsRUFBQSxNQUFBcUI7RUFBQXJCLEVBQUEsTUFBQXFEO0NBQUE7RUFBQUEsTUFBQXJELEVBQUE7Q0FBQTtDQUFBLElBQUFzRDtDQUFBLElBQUF0RCxFQUFBLFFBQUFPLFVBQUFQLEVBQUEsUUFBQUssTUFBQTtFQUdYaUQsTUFBQSx3QkFBQyxRQUFEO0dBQWE7R0FBa0I7R0FBaUIsZUFBTS9DLE9BQU9GLElBQUk7YUFBRztFQUE3RDs7Ozs7RUFFRUwsRUFBQSxNQUFBTztFQUFBUCxFQUFBLE1BQUFLO0VBQUFMLEVBQUEsTUFBQXNEO0NBQUE7RUFBQUEsTUFBQXRELEVBQUE7Q0FBQTtDQUFBLElBQUF1RDtDQUFBLElBQUF2RCxFQUFBLFFBQUFRLFlBQUFSLEVBQUEsUUFBQUssTUFBQTtFQUNUa0QsTUFBQSx3QkFBQyxRQUFEO0dBQWE7R0FBa0I7R0FBa0IsZUFBTS9DLFNBQVNILElBQUk7YUFBRztFQUFoRTs7Ozs7RUFFRUwsRUFBQSxNQUFBUTtFQUFBUixFQUFBLE1BQUFLO0VBQUFMLEVBQUEsTUFBQXVEO0NBQUE7RUFBQUEsTUFBQXZELEVBQUE7Q0FBQTtDQUFBLElBQUF3RDtDQUFBLElBQUF4RCxFQUFBLFFBQUFzRCxPQUFBdEQsRUFBQSxRQUFBdUQsS0FBQTtFQU5YQyxNQUFBLHdCQUFDLGNBQUQsYUFDRUYsS0FHQUMsR0FKVzs7Ozs7RUFPRXZELEVBQUEsTUFBQXNEO0VBQUF0RCxFQUFBLE1BQUF1RDtFQUFBdkQsRUFBQSxNQUFBd0Q7Q0FBQTtFQUFBQSxNQUFBeEQsRUFBQTtDQUFBO0NBQUEsSUFBQXlEO0NBQUEsSUFBQXpELEVBQUEsUUFBQXFELE9BQUFyRCxFQUFBLFFBQUF3RCxLQUFBO0VBL0NqQkMsTUFBQSx3QkFBQyxXQUFELGFBQ0VKLEtBdUNBRyxHQXhDUTs7Ozs7RUFnREV4RCxFQUFBLE1BQUFxRDtFQUFBckQsRUFBQSxNQUFBd0Q7RUFBQXhELEVBQUEsTUFBQXlEO0NBQUE7RUFBQUEsTUFBQXpELEVBQUE7Q0FBQTtDQUFBLElBQUEwRDtDQUFBLElBQUExRCxFQUFBLFFBQUF5RCxPQUFBekQsRUFBQSxRQUFBaUIsSUFBQTtFQTVEaEJ5QyxNQUFBLHdCQUFDLGVBQUQ7R0FBb0I7YUFDbEIsd0JBQUMsWUFBRDtJQUFpQjtJQUFvQjtJQUF1QjtjQUE1RCxDQUNFekMsSUFVQXdDLEdBWFM7Ozs7OztFQURDOzs7OztFQThERXpELEVBQUEsTUFBQXlEO0VBQUF6RCxFQUFBLE1BQUFpQjtFQUFBakIsRUFBQSxNQUFBMEQ7Q0FBQTtFQUFBQSxNQUFBMUQsRUFBQTtDQUFBO0NBQUEsT0E5RGhCMEQ7QUE4RGdCIiwibmFtZXMiOlsiZm9ybWF0RGF0ZSIsImZvcm1hdERhdGVUaW1lIiwicHJpb3JpdHlMYWJlbHMiLCJzdGF0dXNMYWJlbHMiLCJCdXR0b24iLCJEZXRhaWxHcmlkIiwiTW9kYWxBY3Rpb25zIiwiTW9kYWxCYWNrZHJvcCIsIk1vZGFsQm9keSIsIk1vZGFsSGVhZGVyIiwiTW9kYWxQYW5lbCIsIlRhc2tEZXRhaWxzTW9kYWwiLCJ0MCIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwidGFzayIsIm9uQ2xvc2UiLCJvbkVkaXQiLCJvbkRlbGV0ZSIsInQxIiwidGl0bGUiLCJ0MiIsImlkIiwic2xpY2UiLCJ0MyIsInQ0IiwidDUiLCJ0NiIsInQ3IiwidDgiLCJzdGF0dXMiLCJ0OSIsInQxMCIsInQxMSIsInByaW9yaXR5IiwidDEyIiwidDEzIiwidDE0IiwicmVzcG9uc2libGUiLCJuYW1lIiwidDE1IiwidDE2IiwidDE3IiwidGVhbSIsInQxOCIsInQxOSIsImNyZWF0ZWRCeSIsInQyMCIsInQyMSIsImR1ZURhdGUiLCJ0MjIiLCJ0MjMiLCJ0MjQiLCJjcmVhdGVkQXQiLCJ0MjUiLCJ0MjYiLCJ0MjciLCJ1cGRhdGVkQXQiLCJ0MjgiLCJ0MjkiLCJ0MzAiLCJkZXNjcmlwdGlvbiIsInQzMSIsInQzMiIsInQzMyIsInQzNCIsInQzNSIsInQzNiIsInQzNyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUYXNrRGV0YWlsc01vZGFsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFRhc2sgfSBmcm9tIFwiLi4vLi4vaW50ZXJmYWNlcy90YXNrcy90YXNrXCI7XG5pbXBvcnQgeyBmb3JtYXREYXRlLCBmb3JtYXREYXRlVGltZSwgcHJpb3JpdHlMYWJlbHMsIHN0YXR1c0xhYmVscyB9IGZyb20gXCIuL2xhYmVsc1wiO1xuaW1wb3J0IHsgQnV0dG9uLCBEZXRhaWxHcmlkLCBNb2RhbEFjdGlvbnMsIE1vZGFsQmFja2Ryb3AsIE1vZGFsQm9keSwgTW9kYWxIZWFkZXIsIE1vZGFsUGFuZWwgfSBmcm9tIFwiLi9zdHlsZXNcIjtcblxudHlwZSBUYXNrRGV0YWlsc01vZGFsUHJvcHMgPSB7XG4gIHRhc2s6IFRhc2s7XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG4gIG9uRWRpdDogKHRhc2s6IFRhc2spID0+IHZvaWQ7XG4gIG9uRGVsZXRlOiAodGFzazogVGFzaykgPT4gdm9pZDtcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBUYXNrRGV0YWlsc01vZGFsKHsgdGFzaywgb25DbG9zZSwgb25FZGl0LCBvbkRlbGV0ZSB9OiBUYXNrRGV0YWlsc01vZGFsUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8TW9kYWxCYWNrZHJvcCByb2xlPVwicHJlc2VudGF0aW9uXCI+XG4gICAgICA8TW9kYWxQYW5lbCByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIiBhcmlhLWxhYmVsbGVkYnk9XCJ0YXNrLWRldGFpbHMtdGl0bGVcIj5cbiAgICAgICAgPE1vZGFsSGVhZGVyPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDIgaWQ9XCJ0YXNrLWRldGFpbHMtdGl0bGVcIj57dGFzay50aXRsZX08L2gyPlxuICAgICAgICAgICAgPHA+I3t0YXNrLmlkLnNsaWNlKDAsIDgpfTwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJidXR0b25cIiAkdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17b25DbG9zZX0+XG4gICAgICAgICAgICBGZWNoYXJcbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9Nb2RhbEhlYWRlcj5cblxuICAgICAgICA8TW9kYWxCb2R5PlxuICAgICAgICAgIDxEZXRhaWxHcmlkPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGR0PlN0YXR1czwvZHQ+XG4gICAgICAgICAgICAgIDxkZD57c3RhdHVzTGFiZWxzW3Rhc2suc3RhdHVzXX08L2RkPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8ZHQ+UHJpb3JpZGFkZTwvZHQ+XG4gICAgICAgICAgICAgIDxkZD57cHJpb3JpdHlMYWJlbHNbdGFzay5wcmlvcml0eV19PC9kZD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGR0PlJlc3BvbnNhdmVsPC9kdD5cbiAgICAgICAgICAgICAgPGRkPnt0YXNrLnJlc3BvbnNpYmxlPy5uYW1lID8/IFwiTmFvIGF0cmlidWlkb1wifTwvZGQ+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxkdD5UaW1lPC9kdD5cbiAgICAgICAgICAgICAgPGRkPnt0YXNrLnRlYW0ubmFtZX08L2RkPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8ZHQ+Q3JpYWRvcjwvZHQ+XG4gICAgICAgICAgICAgIDxkZD57dGFzay5jcmVhdGVkQnkubmFtZX08L2RkPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8ZHQ+UHJhem88L2R0PlxuICAgICAgICAgICAgICA8ZGQ+e2Zvcm1hdERhdGUodGFzay5kdWVEYXRlKX08L2RkPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8ZHQ+Q3JpYWNhbzwvZHQ+XG4gICAgICAgICAgICAgIDxkZD57Zm9ybWF0RGF0ZVRpbWUodGFzay5jcmVhdGVkQXQpfTwvZGQ+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxkdD5VbHRpbWEgYXR1YWxpemFjYW88L2R0PlxuICAgICAgICAgICAgICA8ZGQ+e2Zvcm1hdERhdGVUaW1lKHRhc2sudXBkYXRlZEF0KX08L2RkPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8ZHQ+RGVzY3JpY2FvPC9kdD5cbiAgICAgICAgICAgICAgPGRkPnt0YXNrLmRlc2NyaXB0aW9uIHx8IFwiU2VtIGRlc2NyaWNhby5cIn08L2RkPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9EZXRhaWxHcmlkPlxuXG4gICAgICAgICAgPE1vZGFsQWN0aW9ucz5cbiAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiICR2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXsoKSA9PiBvbkVkaXQodGFzayl9PlxuICAgICAgICAgICAgICBFZGl0YXJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgJHZhcmlhbnQ9XCJkYW5nZXJcIiBvbkNsaWNrPXsoKSA9PiBvbkRlbGV0ZSh0YXNrKX0+XG4gICAgICAgICAgICAgIEV4Y2x1aXJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvTW9kYWxBY3Rpb25zPlxuICAgICAgICA8L01vZGFsQm9keT5cbiAgICAgIDwvTW9kYWxQYW5lbD5cbiAgICA8L01vZGFsQmFja2Ryb3A+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3dhbGxhL0Rlc2t0b3AvUHJvamV0b3MtcGVzc29haXMvcHJvdmEtdGVjbmljYS9mcm9udC1taW5pLXRhc2stbWFuYWdlci9zcmMvY29tcG9uZW50cy90YXNrcy9UYXNrRGV0YWlsc01vZGFsLnRzeCJ9