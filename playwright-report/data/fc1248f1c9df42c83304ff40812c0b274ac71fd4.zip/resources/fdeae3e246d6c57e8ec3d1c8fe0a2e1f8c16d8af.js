import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/tasks/ConfirmDialog.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=2ae0ea78";
import { Button, FieldError, ModalActions, ModalBackdrop, ModalBody, ModalHeader, ModalPanel } from "/src/components/tasks/styles.ts";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/ConfirmDialog.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2ae0ea78";
export function ConfirmDialog(t0) {
	const $ = _c(30);
	if ($[0] !== "6d65de2f9d034c9255435169169a033f2ec02d309d4881da46566c5729b6f92f") {
		for (let $i = 0; $i < 30; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "6d65de2f9d034c9255435169169a033f2ec02d309d4881da46566c5729b6f92f";
	}
	const { title, message, confirmLabel, errorMessage, isLoading, onCancel, onConfirm } = t0;
	let t1;
	if ($[1] !== title) {
		t1 = /* @__PURE__ */ _jsxDEV("h2", {
			id: "confirm-title",
			children: title
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 31,
			columnNumber: 10
		}, this);
		$[1] = title;
		$[2] = t1;
	} else {
		t1 = $[2];
	}
	let t2;
	if ($[3] !== isLoading || $[4] !== onCancel) {
		t2 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			$variant: "ghost",
			onClick: onCancel,
			disabled: isLoading,
			children: "Fechar"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 10
		}, this);
		$[3] = isLoading;
		$[4] = onCancel;
		$[5] = t2;
	} else {
		t2 = $[5];
	}
	let t3;
	if ($[6] !== t1 || $[7] !== t2) {
		t3 = /* @__PURE__ */ _jsxDEV(ModalHeader, { children: [t1, t2] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 10
		}, this);
		$[6] = t1;
		$[7] = t2;
		$[8] = t3;
	} else {
		t3 = $[8];
	}
	let t4;
	if ($[9] !== message) {
		t4 = /* @__PURE__ */ _jsxDEV("p", { children: message }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 57,
			columnNumber: 10
		}, this);
		$[9] = message;
		$[10] = t4;
	} else {
		t4 = $[10];
	}
	let t5;
	if ($[11] !== errorMessage) {
		t5 = errorMessage ? /* @__PURE__ */ _jsxDEV(FieldError, {
			role: "alert",
			children: errorMessage
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 65,
			columnNumber: 25
		}, this) : null;
		$[11] = errorMessage;
		$[12] = t5;
	} else {
		t5 = $[12];
	}
	let t6;
	if ($[13] !== isLoading || $[14] !== onCancel) {
		t6 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			$variant: "ghost",
			onClick: onCancel,
			disabled: isLoading,
			children: "Cancelar"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 73,
			columnNumber: 10
		}, this);
		$[13] = isLoading;
		$[14] = onCancel;
		$[15] = t6;
	} else {
		t6 = $[15];
	}
	const t7 = isLoading ? "Excluindo..." : confirmLabel;
	let t8;
	if ($[16] !== isLoading || $[17] !== onConfirm || $[18] !== t7) {
		t8 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			$variant: "danger",
			onClick: onConfirm,
			disabled: isLoading,
			children: t7
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 83,
			columnNumber: 10
		}, this);
		$[16] = isLoading;
		$[17] = onConfirm;
		$[18] = t7;
		$[19] = t8;
	} else {
		t8 = $[19];
	}
	let t9;
	if ($[20] !== t6 || $[21] !== t8) {
		t9 = /* @__PURE__ */ _jsxDEV(ModalActions, { children: [t6, t8] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 93,
			columnNumber: 10
		}, this);
		$[20] = t6;
		$[21] = t8;
		$[22] = t9;
	} else {
		t9 = $[22];
	}
	let t10;
	if ($[23] !== t4 || $[24] !== t5 || $[25] !== t9) {
		t10 = /* @__PURE__ */ _jsxDEV(ModalBody, { children: [
			t4,
			t5,
			t9
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 102,
			columnNumber: 11
		}, this);
		$[23] = t4;
		$[24] = t5;
		$[25] = t9;
		$[26] = t10;
	} else {
		t10 = $[26];
	}
	let t11;
	if ($[27] !== t10 || $[28] !== t3) {
		t11 = /* @__PURE__ */ _jsxDEV(ModalBackdrop, {
			role: "presentation",
			children: /* @__PURE__ */ _jsxDEV(ModalPanel, {
				role: "dialog",
				"aria-modal": "true",
				"aria-labelledby": "confirm-title",
				children: [t3, t10]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 112,
				columnNumber: 46
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 112,
			columnNumber: 11
		}, this);
		$[27] = t10;
		$[28] = t3;
		$[29] = t11;
	} else {
		t11 = $[29];
	}
	return t11;
}
_c2 = ConfirmDialog;
var _c2;
$RefreshReg$(_c2, "ConfirmDialog");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/tasks/ConfirmDialog.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/ConfirmDialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/ConfirmDialog.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/ConfirmDialog.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLFFBQVFDLFlBQVlDLGNBQWNDLGVBQWVDLFdBQVdDLGFBQWFDLGtCQUFrQjs7O0FBWXBHLE9BQU8sU0FBQUMsY0FBQUMsSUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLElBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUF1QixRQUFBSyxPQUFBQyxTQUFBQyxjQUFBQyxjQUFBQyxXQUFBQyxVQUFBQyxjQUFBWjtDQUFrRyxJQUFBYTtDQUFBLElBQUFaLEVBQUEsT0FBQUssT0FBQTtFQUt0SE8sS0FBQTtHQUFPO2FBQWlCUDtFQUFXOzs7OztFQUFBTCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQVk7Q0FBQTtFQUFBQSxLQUFBWixFQUFBO0NBQUE7Q0FBQSxJQUFBYTtDQUFBLElBQUFiLEVBQUEsT0FBQVMsYUFBQVQsRUFBQSxPQUFBVSxVQUFBO0VBQ25DRyxLQUFBLHdCQUFDLFFBQUQ7R0FBYTtHQUFrQjtHQUFpQkg7R0FBb0JEO2FBQVc7RUFBeEU7Ozs7O0VBRUVULEVBQUEsS0FBQVM7RUFBQVQsRUFBQSxLQUFBVTtFQUFBVixFQUFBLEtBQUFhO0NBQUE7RUFBQUEsS0FBQWIsRUFBQTtDQUFBO0NBQUEsSUFBQWM7Q0FBQSxJQUFBZCxFQUFBLE9BQUFZLE1BQUFaLEVBQUEsT0FBQWEsSUFBQTtFQUpYQyxLQUFBLHdCQUFDLGFBQUQsYUFDRUYsSUFDQUMsRUFGVTs7Ozs7RUFLRWIsRUFBQSxLQUFBWTtFQUFBWixFQUFBLEtBQUFhO0VBQUFiLEVBQUEsS0FBQWM7Q0FBQTtFQUFBQSxLQUFBZCxFQUFBO0NBQUE7Q0FBQSxJQUFBZTtDQUFBLElBQUFmLEVBQUEsT0FBQU0sU0FBQTtFQUVaUyxLQUFBLHlDQUFJVCxRQUFZOzs7OztFQUFBTixFQUFBLEtBQUFNO0VBQUFOLEVBQUEsTUFBQWU7Q0FBQTtFQUFBQSxLQUFBZixFQUFBO0NBQUE7Q0FBQSxJQUFBZ0I7Q0FBQSxJQUFBaEIsRUFBQSxRQUFBUSxjQUFBO0VBQ2ZRLEtBQUFSLGVBQWUsd0JBQUMsWUFBRDtHQUFpQjthQUFTQTtFQUFmOzs7O2FBQTFCO0VBQTBFUixFQUFBLE1BQUFRO0VBQUFSLEVBQUEsTUFBQWdCO0NBQUE7RUFBQUEsS0FBQWhCLEVBQUE7Q0FBQTtDQUFBLElBQUFpQjtDQUFBLElBQUFqQixFQUFBLFFBQUFTLGFBQUFULEVBQUEsUUFBQVUsVUFBQTtFQUV6RU8sS0FBQSx3QkFBQyxRQUFEO0dBQWE7R0FBa0I7R0FBaUJQO0dBQW9CRDthQUFXO0VBQXhFOzs7OztFQUVFVCxFQUFBLE1BQUFTO0VBQUFULEVBQUEsTUFBQVU7RUFBQVYsRUFBQSxNQUFBaUI7Q0FBQTtFQUFBQSxLQUFBakIsRUFBQTtDQUFBO0NBRU4sTUFBQWtCLEtBQUFULFlBQUEsaUJBQUFGO0NBQXlDLElBQUFZO0NBQUEsSUFBQW5CLEVBQUEsUUFBQVMsYUFBQVQsRUFBQSxRQUFBVyxhQUFBWCxFQUFBLFFBQUFrQixJQUFBO0VBRDVDQyxLQUFBLHdCQUFDLFFBQUQ7R0FBYTtHQUFrQjtHQUFrQlI7R0FBcUJGO2FBQ25FUztFQURJOzs7OztFQUVFbEIsRUFBQSxNQUFBUztFQUFBVCxFQUFBLE1BQUFXO0VBQUFYLEVBQUEsTUFBQWtCO0VBQUFsQixFQUFBLE1BQUFtQjtDQUFBO0VBQUFBLEtBQUFuQixFQUFBO0NBQUE7Q0FBQSxJQUFBb0I7Q0FBQSxJQUFBcEIsRUFBQSxRQUFBaUIsTUFBQWpCLEVBQUEsUUFBQW1CLElBQUE7RUFOWEMsS0FBQSx3QkFBQyxjQUFELGFBQ0VILElBR0FFLEVBSlc7Ozs7O0VBT0VuQixFQUFBLE1BQUFpQjtFQUFBakIsRUFBQSxNQUFBbUI7RUFBQW5CLEVBQUEsTUFBQW9CO0NBQUE7RUFBQUEsS0FBQXBCLEVBQUE7Q0FBQTtDQUFBLElBQUFxQjtDQUFBLElBQUFyQixFQUFBLFFBQUFlLE1BQUFmLEVBQUEsUUFBQWdCLE1BQUFoQixFQUFBLFFBQUFvQixJQUFBO0VBVmpCQyxNQUFBLHdCQUFDLFdBQUQ7R0FDRU47R0FDQ0M7R0FDREk7RUFIUTs7Ozs7RUFXRXBCLEVBQUEsTUFBQWU7RUFBQWYsRUFBQSxNQUFBZ0I7RUFBQWhCLEVBQUEsTUFBQW9CO0VBQUFwQixFQUFBLE1BQUFxQjtDQUFBO0VBQUFBLE1BQUFyQixFQUFBO0NBQUE7Q0FBQSxJQUFBc0I7Q0FBQSxJQUFBdEIsRUFBQSxRQUFBcUIsT0FBQXJCLEVBQUEsUUFBQWMsSUFBQTtFQW5CaEJRLE1BQUEsd0JBQUMsZUFBRDtHQUFvQjthQUNsQix3QkFBQyxZQUFEO0lBQWlCO0lBQW9CO0lBQXVCO2NBQTVELENBQ0VSLElBTUFPLEdBUFM7Ozs7OztFQURDOzs7OztFQXFCRXJCLEVBQUEsTUFBQXFCO0VBQUFyQixFQUFBLE1BQUFjO0VBQUFkLEVBQUEsTUFBQXNCO0NBQUE7RUFBQUEsTUFBQXRCLEVBQUE7Q0FBQTtDQUFBLE9BckJoQnNCO0FBcUJnQiIsIm5hbWVzIjpbIkJ1dHRvbiIsIkZpZWxkRXJyb3IiLCJNb2RhbEFjdGlvbnMiLCJNb2RhbEJhY2tkcm9wIiwiTW9kYWxCb2R5IiwiTW9kYWxIZWFkZXIiLCJNb2RhbFBhbmVsIiwiQ29uZmlybURpYWxvZyIsInQwIiwiJCIsIl9jIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJ0aXRsZSIsIm1lc3NhZ2UiLCJjb25maXJtTGFiZWwiLCJlcnJvck1lc3NhZ2UiLCJpc0xvYWRpbmciLCJvbkNhbmNlbCIsIm9uQ29uZmlybSIsInQxIiwidDIiLCJ0MyIsInQ0IiwidDUiLCJ0NiIsInQ3IiwidDgiLCJ0OSIsInQxMCIsInQxMSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDb25maXJtRGlhbG9nLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCdXR0b24sIEZpZWxkRXJyb3IsIE1vZGFsQWN0aW9ucywgTW9kYWxCYWNrZHJvcCwgTW9kYWxCb2R5LCBNb2RhbEhlYWRlciwgTW9kYWxQYW5lbCB9IGZyb20gXCIuL3N0eWxlc1wiO1xuXG50eXBlIENvbmZpcm1EaWFsb2dQcm9wcyA9IHtcbiAgdGl0bGU6IHN0cmluZztcbiAgbWVzc2FnZTogc3RyaW5nO1xuICBjb25maXJtTGFiZWw6IHN0cmluZztcbiAgZXJyb3JNZXNzYWdlPzogc3RyaW5nO1xuICBpc0xvYWRpbmc/OiBib29sZWFuO1xuICBvbkNhbmNlbDogKCkgPT4gdm9pZDtcbiAgb25Db25maXJtOiAoKSA9PiB2b2lkO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIENvbmZpcm1EaWFsb2coeyB0aXRsZSwgbWVzc2FnZSwgY29uZmlybUxhYmVsLCBlcnJvck1lc3NhZ2UsIGlzTG9hZGluZywgb25DYW5jZWwsIG9uQ29uZmlybSB9OiBDb25maXJtRGlhbG9nUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8TW9kYWxCYWNrZHJvcCByb2xlPVwicHJlc2VudGF0aW9uXCI+XG4gICAgICA8TW9kYWxQYW5lbCByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIiBhcmlhLWxhYmVsbGVkYnk9XCJjb25maXJtLXRpdGxlXCI+XG4gICAgICAgIDxNb2RhbEhlYWRlcj5cbiAgICAgICAgICA8aDIgaWQ9XCJjb25maXJtLXRpdGxlXCI+e3RpdGxlfTwvaDI+XG4gICAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgJHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9e29uQ2FuY2VsfSBkaXNhYmxlZD17aXNMb2FkaW5nfT5cbiAgICAgICAgICAgIEZlY2hhclxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L01vZGFsSGVhZGVyPlxuICAgICAgICA8TW9kYWxCb2R5PlxuICAgICAgICAgIDxwPnttZXNzYWdlfTwvcD5cbiAgICAgICAgICB7ZXJyb3JNZXNzYWdlID8gPEZpZWxkRXJyb3Igcm9sZT1cImFsZXJ0XCI+e2Vycm9yTWVzc2FnZX08L0ZpZWxkRXJyb3I+IDogbnVsbH1cbiAgICAgICAgICA8TW9kYWxBY3Rpb25zPlxuICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgJHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9e29uQ2FuY2VsfSBkaXNhYmxlZD17aXNMb2FkaW5nfT5cbiAgICAgICAgICAgICAgQ2FuY2VsYXJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgJHZhcmlhbnQ9XCJkYW5nZXJcIiBvbkNsaWNrPXtvbkNvbmZpcm19IGRpc2FibGVkPXtpc0xvYWRpbmd9PlxuICAgICAgICAgICAgICB7aXNMb2FkaW5nID8gXCJFeGNsdWluZG8uLi5cIiA6IGNvbmZpcm1MYWJlbH1cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvTW9kYWxBY3Rpb25zPlxuICAgICAgICA8L01vZGFsQm9keT5cbiAgICAgIDwvTW9kYWxQYW5lbD5cbiAgICA8L01vZGFsQmFja2Ryb3A+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3dhbGxhL0Rlc2t0b3AvUHJvamV0b3MtcGVzc29haXMvcHJvdmEtdGVjbmljYS9mcm9udC1taW5pLXRhc2stbWFuYWdlci9zcmMvY29tcG9uZW50cy90YXNrcy9Db25maXJtRGlhbG9nLnRzeCJ9