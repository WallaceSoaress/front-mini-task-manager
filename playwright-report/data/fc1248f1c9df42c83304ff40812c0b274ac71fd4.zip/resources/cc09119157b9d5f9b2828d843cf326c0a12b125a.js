import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/teams/TeamList.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];const _c = __vite__cjsImport0_react_compilerRuntime["c"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=2ae0ea78";
import { Button } from "/src/components/tasks/styles.ts";
import { MemberBadge, MemberList, TeamActions, TeamCard, TeamCardHeader, TeamsGrid } from "/src/components/teams/styles.ts";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/teams/TeamList.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2ae0ea78";
export function TeamList(t0) {
	const $ = _c(8);
	if ($[0] !== "844ec28d806f6252701bb6e355870e6b55345cbeebf01d48d6f23e80351d1200") {
		for (let $i = 0; $i < 8; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "844ec28d806f6252701bb6e355870e6b55345cbeebf01d48d6f23e80351d1200";
	}
	const { teams, onDeleteTeam } = t0;
	let t1;
	if ($[1] !== onDeleteTeam || $[2] !== teams) {
		let t2;
		if ($[4] !== onDeleteTeam) {
			t2 = (team) => /* @__PURE__ */ _jsxDEV(TeamCard, { children: [/* @__PURE__ */ _jsxDEV(TeamCardHeader, { children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", { children: team.name }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 65
			}, this), /* @__PURE__ */ _jsxDEV("p", { children: [
				team.members.length,
				" ",
				team.members.length === 1 ? "membro" : "membros"
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 85
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 60
			}, this), /* @__PURE__ */ _jsxDEV(TeamActions, { children: /* @__PURE__ */ _jsxDEV(Button, {
				type: "button",
				$variant: "danger",
				onClick: () => onDeleteTeam(team),
				children: "Excluir"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 183
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 170
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 44
			}, this), team.members.length ? /* @__PURE__ */ _jsxDEV(MemberList, {
				"aria-label": `Membros do time ${team.name}`,
				children: team.members.map(_temp)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 328
			}, this) : /* @__PURE__ */ _jsxDEV("p", { children: "Nenhum membro vinculado." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 425
			}, this)] }, team.id, true, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 20
			}, this);
			$[4] = onDeleteTeam;
			$[5] = t2;
		} else {
			t2 = $[5];
		}
		t1 = teams.map(t2);
		$[1] = onDeleteTeam;
		$[2] = teams;
		$[3] = t1;
	} else {
		t1 = $[3];
	}
	let t2;
	if ($[6] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV(TeamsGrid, { children: t1 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 10
		}, this);
		$[6] = t1;
		$[7] = t2;
	} else {
		t2 = $[7];
	}
	return t2;
}
_c2 = TeamList;
function _temp(member) {
	return /* @__PURE__ */ _jsxDEV(MemberBadge, {
		title: member.email,
		children: member.name
	}, member.id, false, {
		fileName: _jsxFileName,
		lineNumber: 49,
		columnNumber: 10
	}, this);
}
var _c2;
$RefreshReg$(_c2, "TeamList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/teams/TeamList.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/teams/TeamList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/teams/TeamList.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/teams/TeamList.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUNBLFNBQVNBLGNBQWM7QUFDdkIsU0FBU0MsYUFBYUMsWUFBWUMsYUFBYUMsVUFBVUMsZ0JBQWdCQyxpQkFBaUI7OztBQU8xRixPQUFPLFNBQUFDLFNBQUFDLElBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBa0IsUUFBQUssT0FBQUMsaUJBQUFQO0NBQXNDLElBQUFRO0NBQUEsSUFBQVAsRUFBQSxPQUFBTSxnQkFBQU4sRUFBQSxPQUFBSyxPQUFBO0VBQUEsSUFBQUc7RUFBQSxJQUFBUixFQUFBLE9BQUFNLGNBQUE7R0FHOUNFLE1BQUFDLFNBQ1Qsd0JBQUMsVUFBRCxhQUNFLHdCQUFDLGdCQUFELGFBQ0UsNENBQ0UsMENBQUtBLEtBQUlDLEtBQVc7Ozs7YUFDcEI7SUFDR0QsS0FBSUUsUUFBUUM7SUFBUTtJQUFFSCxLQUFJRSxRQUFRQyxXQUFZLElBQXhCO0dBQ3JCOzs7O1dBQ0E7Ozs7YUFFTix3QkFBQyxhQUFELFlBQ0Usd0JBQUMsUUFBRDtJQUFhO0lBQWtCO0lBQWtCLGVBQU1OLGFBQWFHLElBQUk7Y0FBRztHQUFwRTs7OztZQURHOzs7O1dBUkM7Ozs7YUFlZEEsS0FBSUUsUUFBUUMsU0FDWCx3QkFBQyxZQUFEO0lBQXdCLGlDQUFtQkgsS0FBSUM7Y0FDNUNELEtBQUlFLFFBQVFFLElBQUtDLEtBSWpCO0dBTFE7Ozs7Y0FRWCx5Q0FBRywyQkFBNEI7Ozs7V0F6QjFCLEtBQU1MLEtBQUlNOzs7O1VBQVY7R0E0QlZmLEVBQUEsS0FBQU07R0FBQU4sRUFBQSxLQUFBUTtFQUFBO0dBQUFBLEtBQUFSLEVBQUE7RUFBQTtFQTdCQU8sS0FBQUYsTUFBS1EsSUFBS0wsRUE2QlY7RUFBQ1IsRUFBQSxLQUFBTTtFQUFBTixFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU87Q0FBQTtFQUFBQSxLQUFBUCxFQUFBO0NBQUE7Q0FBQSxJQUFBUTtDQUFBLElBQUFSLEVBQUEsT0FBQU8sSUFBQTtFQTlCSkMsS0FBQSx3QkFBQyxXQUFELFlBQ0dELEdBRE87Ozs7O0VBK0JFUCxFQUFBLEtBQUFPO0VBQUFQLEVBQUEsS0FBQVE7Q0FBQTtFQUFBQSxLQUFBUixFQUFBO0NBQUE7Q0FBQSxPQS9CWlE7QUErQlk7O0FBakNULFNBQUFNLE1BQUFFLFFBQUE7Q0FBQSxPQXVCUyx3QkFBQyxhQUFEO0VBQW9DLE9BQUFBLE9BQU1DO1lBQ3ZDRCxPQUFNTjtDQURHLEdBQU1NLE9BQU1EOzs7O1FBQVo7QUFFRSIsIm5hbWVzIjpbIkJ1dHRvbiIsIk1lbWJlckJhZGdlIiwiTWVtYmVyTGlzdCIsIlRlYW1BY3Rpb25zIiwiVGVhbUNhcmQiLCJUZWFtQ2FyZEhlYWRlciIsIlRlYW1zR3JpZCIsIlRlYW1MaXN0IiwidDAiLCIkIiwiX2MiLCIkaSIsIlN5bWJvbCIsImZvciIsInRlYW1zIiwib25EZWxldGVUZWFtIiwidDEiLCJ0MiIsInRlYW0iLCJuYW1lIiwibWVtYmVycyIsImxlbmd0aCIsIm1hcCIsIl90ZW1wIiwiaWQiLCJtZW1iZXIiLCJlbWFpbCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUZWFtTGlzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBUZWFtIH0gZnJvbSBcIi4uLy4uL2ludGVyZmFjZXMvdGFza3MvdGVhbVwiO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIi4uL3Rhc2tzL3N0eWxlc1wiO1xuaW1wb3J0IHsgTWVtYmVyQmFkZ2UsIE1lbWJlckxpc3QsIFRlYW1BY3Rpb25zLCBUZWFtQ2FyZCwgVGVhbUNhcmRIZWFkZXIsIFRlYW1zR3JpZCB9IGZyb20gXCIuL3N0eWxlc1wiO1xuXG50eXBlIFRlYW1MaXN0UHJvcHMgPSB7XG4gIHRlYW1zOiBUZWFtW107XG4gIG9uRGVsZXRlVGVhbTogKHRlYW06IFRlYW0pID0+IHZvaWQ7XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gVGVhbUxpc3QoeyB0ZWFtcywgb25EZWxldGVUZWFtIH06IFRlYW1MaXN0UHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8VGVhbXNHcmlkPlxuICAgICAge3RlYW1zLm1hcCgodGVhbSkgPT4gKFxuICAgICAgICA8VGVhbUNhcmQga2V5PXt0ZWFtLmlkfT5cbiAgICAgICAgICA8VGVhbUNhcmRIZWFkZXI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDI+e3RlYW0ubmFtZX08L2gyPlxuICAgICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgICB7dGVhbS5tZW1iZXJzLmxlbmd0aH0ge3RlYW0ubWVtYmVycy5sZW5ndGggPT09IDEgPyBcIm1lbWJyb1wiIDogXCJtZW1icm9zXCJ9XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8VGVhbUFjdGlvbnM+XG4gICAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiICR2YXJpYW50PVwiZGFuZ2VyXCIgb25DbGljaz17KCkgPT4gb25EZWxldGVUZWFtKHRlYW0pfT5cbiAgICAgICAgICAgICAgICBFeGNsdWlyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPC9UZWFtQWN0aW9ucz5cbiAgICAgICAgICA8L1RlYW1DYXJkSGVhZGVyPlxuXG4gICAgICAgICAge3RlYW0ubWVtYmVycy5sZW5ndGggPyAoXG4gICAgICAgICAgICA8TWVtYmVyTGlzdCBhcmlhLWxhYmVsPXtgTWVtYnJvcyBkbyB0aW1lICR7dGVhbS5uYW1lfWB9PlxuICAgICAgICAgICAgICB7dGVhbS5tZW1iZXJzLm1hcCgobWVtYmVyKSA9PiAoXG4gICAgICAgICAgICAgICAgPE1lbWJlckJhZGdlIGtleT17bWVtYmVyLmlkfSB0aXRsZT17bWVtYmVyLmVtYWlsfT5cbiAgICAgICAgICAgICAgICAgIHttZW1iZXIubmFtZX1cbiAgICAgICAgICAgICAgICA8L01lbWJlckJhZGdlPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvTWVtYmVyTGlzdD5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPHA+TmVuaHVtIG1lbWJybyB2aW5jdWxhZG8uPC9wPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvVGVhbUNhcmQ+XG4gICAgICApKX1cbiAgICA8L1RlYW1zR3JpZD5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvd2FsbGEvRGVza3RvcC9Qcm9qZXRvcy1wZXNzb2Fpcy9wcm92YS10ZWNuaWNhL2Zyb250LW1pbmktdGFzay1tYW5hZ2VyL3NyYy9jb21wb25lbnRzL3RlYW1zL1RlYW1MaXN0LnRzeCJ9