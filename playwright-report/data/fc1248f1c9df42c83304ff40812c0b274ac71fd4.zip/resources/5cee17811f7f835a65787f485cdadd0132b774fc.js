import { n as __toESM, t as __commonJSMin } from "/node_modules/.vite/deps/rolldown-runtime-BPOCksWG.js?v=f59827d3";
//#region node_modules/property-expr/index.js
/**
* Based on Kendo UI Core expression code <https://github.com/telerik/kendo-ui-core#license-information>
*/
var require_property_expr = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function Cache(maxSize) {
		this._maxSize = maxSize;
		this.clear();
	}
	Cache.prototype.clear = function() {
		this._size = 0;
		this._values = Object.create(null);
	};
	Cache.prototype.get = function(key) {
		return this._values[key];
	};
	Cache.prototype.set = function(key, value) {
		this._size >= this._maxSize && this.clear();
		if (!(key in this._values)) this._size++;
		return this._values[key] = value;
	};
	var SPLIT_REGEX = /[^.^\]^[]+|(?=\[\]|\.\.)/g;
	var DIGIT_REGEX = /^\d+$/;
	var LEAD_DIGIT_REGEX = /^\d/;
	var SPEC_CHAR_REGEX = /[~`!#$%\^&*+=\-\[\]\\';,/{}|\\":<>\?]/g;
	var CLEAN_QUOTES_REGEX = /^\s*(['"]?)(.*?)(\1)\s*$/;
	var MAX_CACHE_SIZE = 512;
	var pathCache = new Cache(MAX_CACHE_SIZE);
	var setCache = new Cache(MAX_CACHE_SIZE);
	var getCache = new Cache(MAX_CACHE_SIZE);
	module.exports = {
		Cache,
		split,
		normalizePath,
		setter: function(path) {
			var parts = normalizePath(path);
			return setCache.get(path) || setCache.set(path, function setter(obj, value) {
				var index = 0;
				var len = parts.length;
				var data = obj;
				while (index < len - 1) {
					var part = parts[index];
					if (part === "__proto__" || part === "constructor" || part === "prototype") return obj;
					data = data[parts[index++]];
				}
				data[parts[index]] = value;
			});
		},
		getter: function(path, safe) {
			var parts = normalizePath(path);
			return getCache.get(path) || getCache.set(path, function getter(data) {
				var index = 0, len = parts.length;
				while (index < len) if (data != null || !safe) data = data[parts[index++]];
				else return;
				return data;
			});
		},
		join: function(segments) {
			return segments.reduce(function(path, part) {
				return path + (isQuoted(part) || DIGIT_REGEX.test(part) ? "[" + part + "]" : (path ? "." : "") + part);
			}, "");
		},
		forEach: function(path, cb, thisArg) {
			forEach(Array.isArray(path) ? path : split(path), cb, thisArg);
		}
	};
	function normalizePath(path) {
		return pathCache.get(path) || pathCache.set(path, split(path).map(function(part) {
			return part.replace(CLEAN_QUOTES_REGEX, "$2");
		}));
	}
	function split(path) {
		return path.match(SPLIT_REGEX) || [""];
	}
	function forEach(parts, iter, thisArg) {
		var len = parts.length, part, idx, isArray, isBracket;
		for (idx = 0; idx < len; idx++) {
			part = parts[idx];
			if (part) {
				if (shouldBeQuoted(part)) part = "\"" + part + "\"";
				isBracket = isQuoted(part);
				isArray = !isBracket && /^\d+$/.test(part);
				iter.call(thisArg, part, isBracket, isArray, idx, parts);
			}
		}
	}
	function isQuoted(str) {
		return typeof str === "string" && str && ["'", "\""].indexOf(str.charAt(0)) !== -1;
	}
	function hasLeadingNumber(part) {
		return part.match(LEAD_DIGIT_REGEX) && !part.match(DIGIT_REGEX);
	}
	function hasSpecialChars(part) {
		return SPEC_CHAR_REGEX.test(part);
	}
	function shouldBeQuoted(part) {
		return !isQuoted(part) && (hasLeadingNumber(part) || hasSpecialChars(part));
	}
}));
//#endregion
//#region node_modules/tiny-case/index.js
var require_tiny_case = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var reWords = /[A-Z\xc0-\xd6\xd8-\xde]?[a-z\xdf-\xf6\xf8-\xff]+(?:['’](?:d|ll|m|re|s|t|ve))?(?=[\xac\xb1\xd7\xf7\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\xbf\u2000-\u206f \t\x0b\f\xa0\ufeff\n\r\u2028\u2029\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000]|[A-Z\xc0-\xd6\xd8-\xde]|$)|(?:[A-Z\xc0-\xd6\xd8-\xde]|[^\ud800-\udfff\xac\xb1\xd7\xf7\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\xbf\u2000-\u206f \t\x0b\f\xa0\ufeff\n\r\u2028\u2029\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\d+\u2700-\u27bfa-z\xdf-\xf6\xf8-\xffA-Z\xc0-\xd6\xd8-\xde])+(?:['’](?:D|LL|M|RE|S|T|VE))?(?=[\xac\xb1\xd7\xf7\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\xbf\u2000-\u206f \t\x0b\f\xa0\ufeff\n\r\u2028\u2029\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000]|[A-Z\xc0-\xd6\xd8-\xde](?:[a-z\xdf-\xf6\xf8-\xff]|[^\ud800-\udfff\xac\xb1\xd7\xf7\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\xbf\u2000-\u206f \t\x0b\f\xa0\ufeff\n\r\u2028\u2029\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\d+\u2700-\u27bfa-z\xdf-\xf6\xf8-\xffA-Z\xc0-\xd6\xd8-\xde])|$)|[A-Z\xc0-\xd6\xd8-\xde]?(?:[a-z\xdf-\xf6\xf8-\xff]|[^\ud800-\udfff\xac\xb1\xd7\xf7\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\xbf\u2000-\u206f \t\x0b\f\xa0\ufeff\n\r\u2028\u2029\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\d+\u2700-\u27bfa-z\xdf-\xf6\xf8-\xffA-Z\xc0-\xd6\xd8-\xde])+(?:['’](?:d|ll|m|re|s|t|ve))?|[A-Z\xc0-\xd6\xd8-\xde]+(?:['’](?:D|LL|M|RE|S|T|VE))?|\d*(?:1ST|2ND|3RD|(?![123])\dTH)(?=\b|[a-z_])|\d*(?:1st|2nd|3rd|(?![123])\dth)(?=\b|[A-Z_])|\d+|(?:[\u2700-\u27bf]|(?:\ud83c[\udde6-\uddff]){2}|[\ud800-\udbff][\udc00-\udfff])[\ufe0e\ufe0f]?(?:[\u0300-\u036f\ufe20-\ufe2f\u20d0-\u20ff]|\ud83c[\udffb-\udfff])?(?:\u200d(?:[^\ud800-\udfff]|(?:\ud83c[\udde6-\uddff]){2}|[\ud800-\udbff][\udc00-\udfff])[\ufe0e\ufe0f]?(?:[\u0300-\u036f\ufe20-\ufe2f\u20d0-\u20ff]|\ud83c[\udffb-\udfff])?)*/g;
	var words = (str) => str.match(reWords) || [];
	var upperFirst = (str) => str[0].toUpperCase() + str.slice(1);
	var join = (str, d) => words(str).join(d).toLowerCase();
	var camelCase = (str) => words(str).reduce((acc, next) => `${acc}${!acc ? next.toLowerCase() : next[0].toUpperCase() + next.slice(1).toLowerCase()}`, "");
	var pascalCase = (str) => upperFirst(camelCase(str));
	var snakeCase = (str) => join(str, "_");
	var kebabCase = (str) => join(str, "-");
	var sentenceCase = (str) => upperFirst(join(str, " "));
	var titleCase = (str) => words(str).map(upperFirst).join(" ");
	module.exports = {
		words,
		upperFirst,
		camelCase,
		pascalCase,
		snakeCase,
		kebabCase,
		sentenceCase,
		titleCase
	};
}));
//#endregion
//#region node_modules/toposort/index.js
var require_toposort = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Topological sorting function
	*
	* @param {Array} edges
	* @returns {Array}
	*/
	module.exports = function(edges) {
		return toposort(uniqueNodes(edges), edges);
	};
	module.exports.array = toposort;
	function toposort(nodes, edges) {
		var cursor = nodes.length, sorted = new Array(cursor), visited = {}, i = cursor, outgoingEdges = makeOutgoingEdges(edges), nodesHash = makeNodesHash(nodes);
		edges.forEach(function(edge) {
			if (!nodesHash.has(edge[0]) || !nodesHash.has(edge[1])) throw new Error("Unknown node. There is an unknown node in the supplied edges.");
		});
		while (i--) if (!visited[i]) visit(nodes[i], i, /* @__PURE__ */ new Set());
		return sorted;
		function visit(node, i, predecessors) {
			if (predecessors.has(node)) {
				var nodeRep;
				try {
					nodeRep = ", node was:" + JSON.stringify(node);
				} catch (e) {
					nodeRep = "";
				}
				throw new Error("Cyclic dependency" + nodeRep);
			}
			if (!nodesHash.has(node)) throw new Error("Found unknown node. Make sure to provided all involved nodes. Unknown node: " + JSON.stringify(node));
			if (visited[i]) return;
			visited[i] = true;
			var outgoing = outgoingEdges.get(node) || /* @__PURE__ */ new Set();
			outgoing = Array.from(outgoing);
			if (i = outgoing.length) {
				predecessors.add(node);
				do {
					var child = outgoing[--i];
					visit(child, nodesHash.get(child), predecessors);
				} while (i);
				predecessors.delete(node);
			}
			sorted[--cursor] = node;
		}
	}
	function uniqueNodes(arr) {
		var res = /* @__PURE__ */ new Set();
		for (var i = 0, len = arr.length; i < len; i++) {
			var edge = arr[i];
			res.add(edge[0]);
			res.add(edge[1]);
		}
		return Array.from(res);
	}
	function makeOutgoingEdges(arr) {
		var edges = /* @__PURE__ */ new Map();
		for (var i = 0, len = arr.length; i < len; i++) {
			var edge = arr[i];
			if (!edges.has(edge[0])) edges.set(edge[0], /* @__PURE__ */ new Set());
			if (!edges.has(edge[1])) edges.set(edge[1], /* @__PURE__ */ new Set());
			edges.get(edge[0]).add(edge[1]);
		}
		return edges;
	}
	function makeNodesHash(arr) {
		var res = /* @__PURE__ */ new Map();
		for (var i = 0, len = arr.length; i < len; i++) res.set(arr[i], i);
		return res;
	}
}));
//#endregion
//#region node_modules/yup/index.esm.js
var import_property_expr = require_property_expr();
var import_tiny_case = require_tiny_case();
var import_toposort = /* @__PURE__ */ __toESM(require_toposort());
var toString = Object.prototype.toString;
var errorToString = Error.prototype.toString;
var regExpToString = RegExp.prototype.toString;
var symbolToString = typeof Symbol !== "undefined" ? Symbol.prototype.toString : () => "";
var SYMBOL_REGEXP = /^Symbol\((.*)\)(.*)$/;
function printNumber(val) {
	if (val != +val) return "NaN";
	return val === 0 && 1 / val < 0 ? "-0" : "" + val;
}
function printSimpleValue(val, quoteStrings = false) {
	if (val == null || val === true || val === false) return "" + val;
	const typeOf = typeof val;
	if (typeOf === "number") return printNumber(val);
	if (typeOf === "string") return quoteStrings ? `"${val}"` : val;
	if (typeOf === "function") return "[Function " + (val.name || "anonymous") + "]";
	if (typeOf === "symbol") return symbolToString.call(val).replace(SYMBOL_REGEXP, "Symbol($1)");
	const tag = toString.call(val).slice(8, -1);
	if (tag === "Date") return isNaN(val.getTime()) ? "" + val : val.toISOString(val);
	if (tag === "Error" || val instanceof Error) return "[" + errorToString.call(val) + "]";
	if (tag === "RegExp") return regExpToString.call(val);
	return null;
}
function printValue(value, quoteStrings) {
	let result = printSimpleValue(value, quoteStrings);
	if (result !== null) return result;
	return JSON.stringify(value, function(key, value) {
		let result = printSimpleValue(this[key], quoteStrings);
		if (result !== null) return result;
		return value;
	}, 2);
}
function toArray(value) {
	return value == null ? [] : [].concat(value);
}
var _Symbol$toStringTag;
var _Symbol$hasInstance;
var _Symbol$toStringTag2;
var strReg = /\$\{\s*(\w+)\s*\}/g;
_Symbol$toStringTag = Symbol.toStringTag;
var ValidationErrorNoStack = class {
	constructor(errorOrErrors, value, field, type) {
		this.name = void 0;
		this.message = void 0;
		this.value = void 0;
		this.path = void 0;
		this.type = void 0;
		this.params = void 0;
		this.errors = void 0;
		this.inner = void 0;
		this[_Symbol$toStringTag] = "Error";
		this.name = "ValidationError";
		this.value = value;
		this.path = field;
		this.type = type;
		this.errors = [];
		this.inner = [];
		toArray(errorOrErrors).forEach((err) => {
			if (ValidationError.isError(err)) {
				this.errors.push(...err.errors);
				const innerErrors = err.inner.length ? err.inner : [err];
				this.inner.push(...innerErrors);
			} else this.errors.push(err);
		});
		this.message = this.errors.length > 1 ? `${this.errors.length} errors occurred` : this.errors[0];
	}
};
_Symbol$hasInstance = Symbol.hasInstance;
_Symbol$toStringTag2 = Symbol.toStringTag;
var ValidationError = class ValidationError extends Error {
	static formatError(message, params) {
		const path = params.label || params.path || "this";
		params = Object.assign({}, params, {
			path,
			originalPath: params.path
		});
		if (typeof message === "string") return message.replace(strReg, (_, key) => printValue(params[key]));
		if (typeof message === "function") return message(params);
		return message;
	}
	static isError(err) {
		return err && err.name === "ValidationError";
	}
	constructor(errorOrErrors, value, field, type, disableStack) {
		const errorNoStack = new ValidationErrorNoStack(errorOrErrors, value, field, type);
		if (disableStack) return errorNoStack;
		super();
		this.value = void 0;
		this.path = void 0;
		this.type = void 0;
		this.params = void 0;
		this.errors = [];
		this.inner = [];
		this[_Symbol$toStringTag2] = "Error";
		this.name = errorNoStack.name;
		this.message = errorNoStack.message;
		this.type = errorNoStack.type;
		this.value = errorNoStack.value;
		this.path = errorNoStack.path;
		this.errors = errorNoStack.errors;
		this.inner = errorNoStack.inner;
		if (Error.captureStackTrace) Error.captureStackTrace(this, ValidationError);
	}
	static [_Symbol$hasInstance](inst) {
		return ValidationErrorNoStack[Symbol.hasInstance](inst) || super[Symbol.hasInstance](inst);
	}
};
var mixed = {
	default: "${path} is invalid",
	required: "${path} is a required field",
	defined: "${path} must be defined",
	notNull: "${path} cannot be null",
	oneOf: "${path} must be one of the following values: ${values}",
	notOneOf: "${path} must not be one of the following values: ${values}",
	notType: ({ path, type, value, originalValue }) => {
		const castMsg = originalValue != null && originalValue !== value ? ` (cast from the value \`${printValue(originalValue, true)}\`).` : ".";
		return type !== "mixed" ? `${path} must be a \`${type}\` type, but the final value was: \`${printValue(value, true)}\`` + castMsg : `${path} must match the configured type. The validated value was: \`${printValue(value, true)}\`` + castMsg;
	}
};
var string = {
	length: "${path} must be exactly ${length} characters",
	min: "${path} must be at least ${min} characters",
	max: "${path} must be at most ${max} characters",
	matches: "${path} must match the following: \"${regex}\"",
	email: "${path} must be a valid email",
	url: "${path} must be a valid URL",
	uuid: "${path} must be a valid UUID",
	datetime: "${path} must be a valid ISO date-time",
	datetime_precision: "${path} must be a valid ISO date-time with a sub-second precision of exactly ${precision} digits",
	datetime_offset: "${path} must be a valid ISO date-time with UTC \"Z\" timezone",
	trim: "${path} must be a trimmed string",
	lowercase: "${path} must be a lowercase string",
	uppercase: "${path} must be a upper case string"
};
var number = {
	min: "${path} must be greater than or equal to ${min}",
	max: "${path} must be less than or equal to ${max}",
	lessThan: "${path} must be less than ${less}",
	moreThan: "${path} must be greater than ${more}",
	positive: "${path} must be a positive number",
	negative: "${path} must be a negative number",
	integer: "${path} must be an integer"
};
var date = {
	min: "${path} field must be later than ${min}",
	max: "${path} field must be at earlier than ${max}"
};
var boolean = { isValue: "${path} field must be ${value}" };
var object = {
	noUnknown: "${path} field has unspecified keys: ${unknown}",
	exact: "${path} object contains unknown properties: ${properties}"
};
var array = {
	min: "${path} field must have at least ${min} items",
	max: "${path} field must have less than or equal to ${max} items",
	length: "${path} must have ${length} items"
};
var tuple = { notType: (params) => {
	const { path, value, spec } = params;
	const typeLen = spec.types.length;
	if (Array.isArray(value)) {
		if (value.length < typeLen) return `${path} tuple value has too few items, expected a length of ${typeLen} but got ${value.length} for value: \`${printValue(value, true)}\``;
		if (value.length > typeLen) return `${path} tuple value has too many items, expected a length of ${typeLen} but got ${value.length} for value: \`${printValue(value, true)}\``;
	}
	return ValidationError.formatError(mixed.notType, params);
} };
var locale = Object.assign(Object.create(null), {
	mixed,
	string,
	number,
	date,
	object,
	array,
	boolean,
	tuple
});
var isSchema = (obj) => obj && obj.__isYupSchema__;
var Condition = class Condition {
	static fromOptions(refs, config) {
		if (!config.then && !config.otherwise) throw new TypeError("either `then:` or `otherwise:` is required for `when()` conditions");
		let { is, then, otherwise } = config;
		let check = typeof is === "function" ? is : (...values) => values.every((value) => value === is);
		return new Condition(refs, (values, schema) => {
			var _branch;
			let branch = check(...values) ? then : otherwise;
			return (_branch = branch == null ? void 0 : branch(schema)) != null ? _branch : schema;
		});
	}
	constructor(refs, builder) {
		this.fn = void 0;
		this.refs = refs;
		this.refs = refs;
		this.fn = builder;
	}
	resolve(base, options) {
		let values = this.refs.map((ref) => ref.getValue(options == null ? void 0 : options.value, options == null ? void 0 : options.parent, options == null ? void 0 : options.context));
		let schema = this.fn(values, base, options);
		if (schema === void 0 || schema === base) return base;
		if (!isSchema(schema)) throw new TypeError("conditions must return a schema object");
		return schema.resolve(options);
	}
};
var prefixes = {
	context: "$",
	value: "."
};
function create$9(key, options) {
	return new Reference(key, options);
}
var Reference = class {
	constructor(key, options = {}) {
		this.key = void 0;
		this.isContext = void 0;
		this.isValue = void 0;
		this.isSibling = void 0;
		this.path = void 0;
		this.getter = void 0;
		this.map = void 0;
		if (typeof key !== "string") throw new TypeError("ref must be a string, got: " + key);
		this.key = key.trim();
		if (key === "") throw new TypeError("ref must be a non-empty string");
		this.isContext = this.key[0] === prefixes.context;
		this.isValue = this.key[0] === prefixes.value;
		this.isSibling = !this.isContext && !this.isValue;
		let prefix = this.isContext ? prefixes.context : this.isValue ? prefixes.value : "";
		this.path = this.key.slice(prefix.length);
		this.getter = this.path && (0, import_property_expr.getter)(this.path, true);
		this.map = options.map;
	}
	getValue(value, parent, context) {
		let result = this.isContext ? context : this.isValue ? value : parent;
		if (this.getter) result = this.getter(result || {});
		if (this.map) result = this.map(result);
		return result;
	}
	/**
	*
	* @param {*} value
	* @param {Object} options
	* @param {Object=} options.context
	* @param {Object=} options.parent
	*/
	cast(value, options) {
		return this.getValue(value, options == null ? void 0 : options.parent, options == null ? void 0 : options.context);
	}
	resolve() {
		return this;
	}
	describe() {
		return {
			type: "ref",
			key: this.key
		};
	}
	toString() {
		return `Ref(${this.key})`;
	}
	static isRef(value) {
		return value && value.__isYupRef;
	}
};
Reference.prototype.__isYupRef = true;
var isAbsent = (value) => value == null;
function createValidation(config) {
	function validate({ value, path = "", options, originalValue, schema }, panic, next) {
		const { name, test, params, message, skipAbsent } = config;
		let { parent, context, abortEarly = schema.spec.abortEarly, disableStackTrace = schema.spec.disableStackTrace } = options;
		const resolveOptions = {
			value,
			parent,
			context
		};
		function createError(overrides = {}) {
			const nextParams = resolveParams(Object.assign({
				value,
				originalValue,
				label: schema.spec.label,
				path: overrides.path || path,
				spec: schema.spec,
				disableStackTrace: overrides.disableStackTrace || disableStackTrace
			}, params, overrides.params), resolveOptions);
			const error = new ValidationError(ValidationError.formatError(overrides.message || message, nextParams), value, nextParams.path, overrides.type || name, nextParams.disableStackTrace);
			error.params = nextParams;
			return error;
		}
		const invalid = abortEarly ? panic : next;
		let ctx = {
			path,
			parent,
			type: name,
			from: options.from,
			createError,
			resolve(item) {
				return resolveMaybeRef(item, resolveOptions);
			},
			options,
			originalValue,
			schema
		};
		const handleResult = (validOrError) => {
			if (ValidationError.isError(validOrError)) invalid(validOrError);
			else if (!validOrError) invalid(createError());
			else next(null);
		};
		const handleError = (err) => {
			if (ValidationError.isError(err)) invalid(err);
			else panic(err);
		};
		if (skipAbsent && isAbsent(value)) return handleResult(true);
		let result;
		try {
			var _result;
			result = test.call(ctx, value, ctx);
			if (typeof ((_result = result) == null ? void 0 : _result.then) === "function") {
				if (options.sync) throw new Error(`Validation test of type: "${ctx.type}" returned a Promise during a synchronous validate. This test will finish after the validate call has returned`);
				return Promise.resolve(result).then(handleResult, handleError);
			}
		} catch (err) {
			handleError(err);
			return;
		}
		handleResult(result);
	}
	validate.OPTIONS = config;
	return validate;
}
function resolveParams(params, options) {
	if (!params) return params;
	for (const key of Object.keys(params)) params[key] = resolveMaybeRef(params[key], options);
	return params;
}
function resolveMaybeRef(item, options) {
	return Reference.isRef(item) ? item.getValue(options.value, options.parent, options.context) : item;
}
function getIn(schema, path, value, context = value) {
	let parent, lastPart, lastPartDebug;
	if (!path) return {
		parent,
		parentPath: path,
		schema
	};
	(0, import_property_expr.forEach)(path, (_part, isBracket, isArray) => {
		let part = isBracket ? _part.slice(1, _part.length - 1) : _part;
		schema = schema.resolve({
			context,
			parent,
			value
		});
		let isTuple = schema.type === "tuple";
		let idx = isArray ? parseInt(part, 10) : 0;
		if (schema.innerType || isTuple) {
			if (isTuple && !isArray) throw new Error(`Yup.reach cannot implicitly index into a tuple type. the path part "${lastPartDebug}" must contain an index to the tuple element, e.g. "${lastPartDebug}[0]"`);
			if (value && idx >= value.length) throw new Error(`Yup.reach cannot resolve an array item at index: ${_part}, in the path: ${path}. because there is no value at that index. `);
			parent = value;
			value = value && value[idx];
			schema = isTuple ? schema.spec.types[idx] : schema.innerType;
		}
		if (!isArray) {
			if (!schema.fields || !schema.fields[part]) throw new Error(`The schema does not contain the path: ${path}. (failed at: ${lastPartDebug} which is a type: "${schema.type}")`);
			parent = value;
			value = value && value[part];
			schema = schema.fields[part];
		}
		lastPart = part;
		lastPartDebug = isBracket ? "[" + _part + "]" : "." + _part;
	});
	return {
		schema,
		parent,
		parentPath: lastPart
	};
}
function reach(obj, path, value, context) {
	return getIn(obj, path, value, context).schema;
}
var ReferenceSet = class ReferenceSet extends Set {
	describe() {
		const description = [];
		for (const item of this.values()) description.push(Reference.isRef(item) ? item.describe() : item);
		return description;
	}
	resolveAll(resolve) {
		let result = [];
		for (const item of this.values()) result.push(resolve(item));
		return result;
	}
	clone() {
		return new ReferenceSet(this.values());
	}
	merge(newItems, removeItems) {
		const next = this.clone();
		newItems.forEach((value) => next.add(value));
		removeItems.forEach((value) => next.delete(value));
		return next;
	}
};
function clone(src, seen = /* @__PURE__ */ new Map()) {
	if (isSchema(src) || !src || typeof src !== "object") return src;
	if (seen.has(src)) return seen.get(src);
	let copy;
	if (src instanceof Date) {
		copy = new Date(src.getTime());
		seen.set(src, copy);
	} else if (src instanceof RegExp) {
		copy = new RegExp(src);
		seen.set(src, copy);
	} else if (Array.isArray(src)) {
		copy = new Array(src.length);
		seen.set(src, copy);
		for (let i = 0; i < src.length; i++) copy[i] = clone(src[i], seen);
	} else if (src instanceof Map) {
		copy = /* @__PURE__ */ new Map();
		seen.set(src, copy);
		for (const [k, v] of src.entries()) copy.set(k, clone(v, seen));
	} else if (src instanceof Set) {
		copy = /* @__PURE__ */ new Set();
		seen.set(src, copy);
		for (const v of src) copy.add(clone(v, seen));
	} else if (src instanceof Object) {
		copy = {};
		seen.set(src, copy);
		for (const [k, v] of Object.entries(src)) copy[k] = clone(v, seen);
	} else throw Error(`Unable to clone ${src}`);
	return copy;
}
/**
* Copied from @standard-schema/spec to avoid having a dependency on it.
* https://github.com/standard-schema/standard-schema/blob/main/packages/spec/src/index.ts
*/
function createStandardPath(path) {
	if (!(path != null && path.length)) return;
	const segments = [];
	let currentSegment = "";
	let inBrackets = false;
	let inQuotes = false;
	for (let i = 0; i < path.length; i++) {
		const char = path[i];
		if (char === "[" && !inQuotes) {
			if (currentSegment) {
				segments.push(...currentSegment.split(".").filter(Boolean));
				currentSegment = "";
			}
			inBrackets = true;
			continue;
		}
		if (char === "]" && !inQuotes) {
			if (currentSegment) {
				if (/^\d+$/.test(currentSegment)) segments.push(currentSegment);
				else segments.push(currentSegment.replace(/^"|"$/g, ""));
				currentSegment = "";
			}
			inBrackets = false;
			continue;
		}
		if (char === "\"") {
			inQuotes = !inQuotes;
			continue;
		}
		if (char === "." && !inBrackets && !inQuotes) {
			if (currentSegment) {
				segments.push(currentSegment);
				currentSegment = "";
			}
			continue;
		}
		currentSegment += char;
	}
	if (currentSegment) segments.push(...currentSegment.split(".").filter(Boolean));
	return segments;
}
function createStandardIssues(error, parentPath) {
	const path = parentPath ? `${parentPath}.${error.path}` : error.path;
	return error.errors.map((err) => ({
		message: err,
		path: createStandardPath(path)
	}));
}
function issuesFromValidationError(error, parentPath) {
	var _error$inner;
	if (!((_error$inner = error.inner) != null && _error$inner.length) && error.errors.length) return createStandardIssues(error, parentPath);
	const path = parentPath ? `${parentPath}.${error.path}` : error.path;
	return error.inner.flatMap((err) => issuesFromValidationError(err, path));
}
var Schema = class {
	constructor(options) {
		this.type = void 0;
		this.deps = [];
		this.tests = void 0;
		this.transforms = void 0;
		this.conditions = [];
		this._mutate = void 0;
		this.internalTests = {};
		this._whitelist = new ReferenceSet();
		this._blacklist = new ReferenceSet();
		this.exclusiveTests = Object.create(null);
		this._typeCheck = void 0;
		this.spec = void 0;
		this.tests = [];
		this.transforms = [];
		this.withMutation(() => {
			this.typeError(mixed.notType);
		});
		this.type = options.type;
		this._typeCheck = options.check;
		this.spec = Object.assign({
			strip: false,
			strict: false,
			abortEarly: true,
			recursive: true,
			disableStackTrace: false,
			nullable: false,
			optional: true,
			coerce: true
		}, options == null ? void 0 : options.spec);
		this.withMutation((s) => {
			s.nonNullable();
		});
	}
	get _type() {
		return this.type;
	}
	clone(spec) {
		if (this._mutate) {
			if (spec) Object.assign(this.spec, spec);
			return this;
		}
		const next = Object.create(Object.getPrototypeOf(this));
		next.type = this.type;
		next._typeCheck = this._typeCheck;
		next._whitelist = this._whitelist.clone();
		next._blacklist = this._blacklist.clone();
		next.internalTests = Object.assign({}, this.internalTests);
		next.exclusiveTests = Object.assign({}, this.exclusiveTests);
		next.deps = [...this.deps];
		next.conditions = [...this.conditions];
		next.tests = [...this.tests];
		next.transforms = [...this.transforms];
		next.spec = clone(Object.assign({}, this.spec, spec));
		return next;
	}
	label(label) {
		let next = this.clone();
		next.spec.label = label;
		return next;
	}
	meta(...args) {
		if (args.length === 0) return this.spec.meta;
		let next = this.clone();
		next.spec.meta = Object.assign(next.spec.meta || {}, args[0]);
		return next;
	}
	withMutation(fn) {
		let before = this._mutate;
		this._mutate = true;
		let result = fn(this);
		this._mutate = before;
		return result;
	}
	concat(schema) {
		if (!schema || schema === this) return this;
		if (schema.type !== this.type && this.type !== "mixed") throw new TypeError(`You cannot \`concat()\` schema's of different types: ${this.type} and ${schema.type}`);
		let base = this;
		let combined = schema.clone();
		combined.spec = Object.assign({}, base.spec, combined.spec);
		combined.internalTests = Object.assign({}, base.internalTests, combined.internalTests);
		combined._whitelist = base._whitelist.merge(schema._whitelist, schema._blacklist);
		combined._blacklist = base._blacklist.merge(schema._blacklist, schema._whitelist);
		combined.tests = base.tests;
		combined.exclusiveTests = base.exclusiveTests;
		combined.withMutation((next) => {
			schema.tests.forEach((fn) => {
				next.test(fn.OPTIONS);
			});
		});
		combined.transforms = [...base.transforms, ...combined.transforms];
		return combined;
	}
	isType(v) {
		if (v == null) {
			if (this.spec.nullable && v === null) return true;
			if (this.spec.optional && v === void 0) return true;
			return false;
		}
		return this._typeCheck(v);
	}
	resolve(options) {
		let schema = this;
		if (schema.conditions.length) {
			let conditions = schema.conditions;
			schema = schema.clone();
			schema.conditions = [];
			schema = conditions.reduce((prevSchema, condition) => condition.resolve(prevSchema, options), schema);
			schema = schema.resolve(options);
		}
		return schema;
	}
	resolveOptions(options) {
		var _options$strict, _options$abortEarly, _options$recursive, _options$disableStack;
		return Object.assign({}, options, {
			from: options.from || [],
			strict: (_options$strict = options.strict) != null ? _options$strict : this.spec.strict,
			abortEarly: (_options$abortEarly = options.abortEarly) != null ? _options$abortEarly : this.spec.abortEarly,
			recursive: (_options$recursive = options.recursive) != null ? _options$recursive : this.spec.recursive,
			disableStackTrace: (_options$disableStack = options.disableStackTrace) != null ? _options$disableStack : this.spec.disableStackTrace
		});
	}
	/**
	* Run the configured transform pipeline over an input value.
	*/
	cast(value, options = {}) {
		let resolvedSchema = this.resolve(Object.assign({}, options, { value }));
		let allowOptionality = options.assert === "ignore-optionality";
		let result = resolvedSchema._cast(value, options);
		if (options.assert !== false && !resolvedSchema.isType(result)) {
			if (allowOptionality && isAbsent(result)) return result;
			let formattedValue = printValue(value);
			let formattedResult = printValue(result);
			throw new TypeError(`The value of ${options.path || "field"} could not be cast to a value that satisfies the schema type: "${resolvedSchema.type}". \n\nattempted value: ${formattedValue} \n` + (formattedResult !== formattedValue ? `result of cast: ${formattedResult}` : ""));
		}
		return result;
	}
	_cast(rawValue, options) {
		let value = rawValue === void 0 ? rawValue : this.transforms.reduce((prevValue, fn) => fn.call(this, prevValue, rawValue, this, options), rawValue);
		if (value === void 0) value = this.getDefault(options);
		return value;
	}
	_validate(_value, options = {}, panic, next) {
		let { path, originalValue = _value, strict = this.spec.strict } = options;
		let value = _value;
		if (!strict) value = this._cast(value, Object.assign({ assert: false }, options));
		let initialTests = [];
		for (let test of Object.values(this.internalTests)) if (test) initialTests.push(test);
		this.runTests({
			path,
			value,
			originalValue,
			options,
			tests: initialTests
		}, panic, (initialErrors) => {
			if (initialErrors.length) return next(initialErrors, value);
			this.runTests({
				path,
				value,
				originalValue,
				options,
				tests: this.tests
			}, panic, next);
		});
	}
	/**
	* Executes a set of validations, either schema, produced Tests or a nested
	* schema validate result.
	*/
	runTests(runOptions, panic, next) {
		let fired = false;
		let { tests, value, originalValue, path, options } = runOptions;
		let panicOnce = (arg) => {
			if (fired) return;
			fired = true;
			panic(arg, value);
		};
		let nextOnce = (arg) => {
			if (fired) return;
			fired = true;
			next(arg, value);
		};
		let count = tests.length;
		let nestedErrors = [];
		if (!count) return nextOnce([]);
		let args = {
			value,
			originalValue,
			path,
			options,
			schema: this
		};
		for (let i = 0; i < tests.length; i++) {
			const test = tests[i];
			test(args, panicOnce, function finishTestRun(err) {
				if (err) Array.isArray(err) ? nestedErrors.push(...err) : nestedErrors.push(err);
				if (--count <= 0) nextOnce(nestedErrors);
			});
		}
	}
	asNestedTest({ key, index, parent, parentPath, originalParent, options }) {
		const k = key != null ? key : index;
		if (k == null) throw TypeError("Must include `key` or `index` for nested validations");
		const isIndex = typeof k === "number";
		let value = parent[k];
		const testOptions = Object.assign({}, options, {
			strict: true,
			parent,
			value,
			originalValue: originalParent[k],
			key: void 0,
			[isIndex ? "index" : "key"]: k,
			path: isIndex || k.includes(".") ? `${parentPath || ""}[${isIndex ? k : `"${k}"`}]` : (parentPath ? `${parentPath}.` : "") + key
		});
		return (_, panic, next) => this.resolve(testOptions)._validate(value, testOptions, panic, next);
	}
	validate(value, options) {
		var _options$disableStack2;
		let schema = this.resolve(Object.assign({}, options, { value }));
		let disableStackTrace = (_options$disableStack2 = options == null ? void 0 : options.disableStackTrace) != null ? _options$disableStack2 : schema.spec.disableStackTrace;
		return new Promise((resolve, reject) => schema._validate(value, options, (error, parsed) => {
			if (ValidationError.isError(error)) error.value = parsed;
			reject(error);
		}, (errors, validated) => {
			if (errors.length) reject(new ValidationError(errors, validated, void 0, void 0, disableStackTrace));
			else resolve(validated);
		}));
	}
	validateSync(value, options) {
		var _options$disableStack3;
		let schema = this.resolve(Object.assign({}, options, { value }));
		let result;
		let disableStackTrace = (_options$disableStack3 = options == null ? void 0 : options.disableStackTrace) != null ? _options$disableStack3 : schema.spec.disableStackTrace;
		schema._validate(value, Object.assign({}, options, { sync: true }), (error, parsed) => {
			if (ValidationError.isError(error)) error.value = parsed;
			throw error;
		}, (errors, validated) => {
			if (errors.length) throw new ValidationError(errors, value, void 0, void 0, disableStackTrace);
			result = validated;
		});
		return result;
	}
	isValid(value, options) {
		return this.validate(value, options).then(() => true, (err) => {
			if (ValidationError.isError(err)) return false;
			throw err;
		});
	}
	isValidSync(value, options) {
		try {
			this.validateSync(value, options);
			return true;
		} catch (err) {
			if (ValidationError.isError(err)) return false;
			throw err;
		}
	}
	_getDefault(options) {
		let defaultValue = this.spec.default;
		if (defaultValue == null) return defaultValue;
		return typeof defaultValue === "function" ? defaultValue.call(this, options) : clone(defaultValue);
	}
	getDefault(options) {
		return this.resolve(options || {})._getDefault(options);
	}
	default(def) {
		if (arguments.length === 0) return this._getDefault();
		return this.clone({ default: def });
	}
	strict(isStrict = true) {
		return this.clone({ strict: isStrict });
	}
	nullability(nullable, message) {
		const next = this.clone({ nullable });
		next.internalTests.nullable = createValidation({
			message,
			name: "nullable",
			test(value) {
				return value === null ? this.schema.spec.nullable : true;
			}
		});
		return next;
	}
	optionality(optional, message) {
		const next = this.clone({ optional });
		next.internalTests.optionality = createValidation({
			message,
			name: "optionality",
			test(value) {
				return value === void 0 ? this.schema.spec.optional : true;
			}
		});
		return next;
	}
	optional() {
		return this.optionality(true);
	}
	defined(message = mixed.defined) {
		return this.optionality(false, message);
	}
	nullable() {
		return this.nullability(true);
	}
	nonNullable(message = mixed.notNull) {
		return this.nullability(false, message);
	}
	required(message = mixed.required) {
		return this.clone().withMutation((next) => next.nonNullable(message).defined(message));
	}
	notRequired() {
		return this.clone().withMutation((next) => next.nullable().optional());
	}
	transform(fn) {
		let next = this.clone();
		next.transforms.push(fn);
		return next;
	}
	/**
	* Adds a test function to the schema's queue of tests.
	* tests can be exclusive or non-exclusive.
	*
	* - exclusive tests, will replace any existing tests of the same name.
	* - non-exclusive: can be stacked
	*
	* If a non-exclusive test is added to a schema with an exclusive test of the same name
	* the exclusive test is removed and further tests of the same name will be stacked.
	*
	* If an exclusive test is added to a schema with non-exclusive tests of the same name
	* the previous tests are removed and further tests of the same name will replace each other.
	*/
	test(...args) {
		let opts;
		if (args.length === 1) {
			if (typeof args[0] === "function") opts = { test: args[0] };
			else opts = args[0];
		} else if (args.length === 2) opts = {
			name: args[0],
			test: args[1]
		};
		else opts = {
			name: args[0],
			message: args[1],
			test: args[2]
		};
		if (opts.message === void 0) opts.message = mixed.default;
		if (typeof opts.test !== "function") throw new TypeError("`test` is a required parameters");
		let next = this.clone();
		let validate = createValidation(opts);
		let isExclusive = opts.exclusive || opts.name && next.exclusiveTests[opts.name] === true;
		if (opts.exclusive) {
			if (!opts.name) throw new TypeError("Exclusive tests must provide a unique `name` identifying the test");
		}
		if (opts.name) next.exclusiveTests[opts.name] = !!opts.exclusive;
		next.tests = next.tests.filter((fn) => {
			if (fn.OPTIONS.name === opts.name) {
				if (isExclusive) return false;
				if (fn.OPTIONS.test === validate.OPTIONS.test) return false;
			}
			return true;
		});
		next.tests.push(validate);
		return next;
	}
	when(keys, options) {
		if (!Array.isArray(keys) && typeof keys !== "string") {
			options = keys;
			keys = ".";
		}
		let next = this.clone();
		let deps = toArray(keys).map((key) => new Reference(key));
		deps.forEach((dep) => {
			if (dep.isSibling) next.deps.push(dep.key);
		});
		next.conditions.push(typeof options === "function" ? new Condition(deps, options) : Condition.fromOptions(deps, options));
		return next;
	}
	typeError(message) {
		let next = this.clone();
		next.internalTests.typeError = createValidation({
			message,
			name: "typeError",
			skipAbsent: true,
			test(value) {
				if (!this.schema._typeCheck(value)) return this.createError({ params: { type: this.schema.type } });
				return true;
			}
		});
		return next;
	}
	oneOf(enums, message = mixed.oneOf) {
		let next = this.clone();
		enums.forEach((val) => {
			next._whitelist.add(val);
			next._blacklist.delete(val);
		});
		next.internalTests.whiteList = createValidation({
			message,
			name: "oneOf",
			skipAbsent: true,
			test(value) {
				let valids = this.schema._whitelist;
				let resolved = valids.resolveAll(this.resolve);
				return resolved.includes(value) ? true : this.createError({ params: {
					values: Array.from(valids).join(", "),
					resolved
				} });
			}
		});
		return next;
	}
	notOneOf(enums, message = mixed.notOneOf) {
		let next = this.clone();
		enums.forEach((val) => {
			next._blacklist.add(val);
			next._whitelist.delete(val);
		});
		next.internalTests.blacklist = createValidation({
			message,
			name: "notOneOf",
			test(value) {
				let invalids = this.schema._blacklist;
				let resolved = invalids.resolveAll(this.resolve);
				if (resolved.includes(value)) return this.createError({ params: {
					values: Array.from(invalids).join(", "),
					resolved
				} });
				return true;
			}
		});
		return next;
	}
	strip(strip = true) {
		let next = this.clone();
		next.spec.strip = strip;
		return next;
	}
	/**
	* Return a serialized description of the schema including validations, flags, types etc.
	*
	* @param options Provide any needed context for resolving runtime schema alterations (lazy, when conditions, etc).
	*/
	describe(options) {
		const next = (options ? this.resolve(options) : this).clone();
		const { label, meta, optional, nullable } = next.spec;
		return {
			meta,
			label,
			optional,
			nullable,
			default: next.getDefault(options),
			type: next.type,
			oneOf: next._whitelist.describe(),
			notOneOf: next._blacklist.describe(),
			tests: next.tests.filter((n, idx, list) => list.findIndex((c) => c.OPTIONS.name === n.OPTIONS.name) === idx).map((fn) => {
				const params = fn.OPTIONS.params && options ? resolveParams(Object.assign({}, fn.OPTIONS.params), options) : fn.OPTIONS.params;
				return {
					name: fn.OPTIONS.name,
					params
				};
			})
		};
	}
	get ["~standard"]() {
		const schema = this;
		return {
			version: 1,
			vendor: "yup",
			async validate(value) {
				try {
					return { value: await schema.validate(value, { abortEarly: false }) };
				} catch (err) {
					if (err instanceof ValidationError) return { issues: issuesFromValidationError(err) };
					throw err;
				}
			}
		};
	}
};
Schema.prototype.__isYupSchema__ = true;
for (const method of ["validate", "validateSync"]) Schema.prototype[`${method}At`] = function(path, value, options = {}) {
	const { parent, parentPath, schema } = getIn(this, path, value, options.context);
	return schema[method](parent && parent[parentPath], Object.assign({}, options, {
		parent,
		path
	}));
};
for (const alias of ["equals", "is"]) Schema.prototype[alias] = Schema.prototype.oneOf;
for (const alias of ["not", "nope"]) Schema.prototype[alias] = Schema.prototype.notOneOf;
var returnsTrue = () => true;
function create$8(spec) {
	return new MixedSchema(spec);
}
var MixedSchema = class extends Schema {
	constructor(spec) {
		super(typeof spec === "function" ? {
			type: "mixed",
			check: spec
		} : Object.assign({
			type: "mixed",
			check: returnsTrue
		}, spec));
	}
};
create$8.prototype = MixedSchema.prototype;
function create$7() {
	return new BooleanSchema();
}
var BooleanSchema = class extends Schema {
	constructor() {
		super({
			type: "boolean",
			check(v) {
				if (v instanceof Boolean) v = v.valueOf();
				return typeof v === "boolean";
			}
		});
		this.withMutation(() => {
			this.transform((value, _raw) => {
				if (this.spec.coerce && !this.isType(value)) {
					if (/^(true|1)$/i.test(String(value))) return true;
					if (/^(false|0)$/i.test(String(value))) return false;
				}
				return value;
			});
		});
	}
	isTrue(message = boolean.isValue) {
		return this.test({
			message,
			name: "is-value",
			exclusive: true,
			params: { value: "true" },
			test(value) {
				return isAbsent(value) || value === true;
			}
		});
	}
	isFalse(message = boolean.isValue) {
		return this.test({
			message,
			name: "is-value",
			exclusive: true,
			params: { value: "false" },
			test(value) {
				return isAbsent(value) || value === false;
			}
		});
	}
	default(def) {
		return super.default(def);
	}
	defined(msg) {
		return super.defined(msg);
	}
	optional() {
		return super.optional();
	}
	required(msg) {
		return super.required(msg);
	}
	notRequired() {
		return super.notRequired();
	}
	nullable() {
		return super.nullable();
	}
	nonNullable(msg) {
		return super.nonNullable(msg);
	}
	strip(v) {
		return super.strip(v);
	}
};
create$7.prototype = BooleanSchema.prototype;
/**
* This file is a modified version of the file from the following repository:
* Date.parse with progressive enhancement for ISO 8601 <https://github.com/csnover/js-iso8601>
* NON-CONFORMANT EDITION.
* © 2011 Colin Snover <http://zetafleet.com>
* Released under MIT license.
*/
var isoReg = /^(\d{4}|[+-]\d{6})(?:-?(\d{2})(?:-?(\d{2}))?)?(?:[ T]?(\d{2}):?(\d{2})(?::?(\d{2})(?:[,.](\d{1,}))?)?(?:(Z)|([+-])(\d{2})(?::?(\d{2}))?)?)?$/;
function parseIsoDate(date) {
	const struct = parseDateStruct(date);
	if (!struct) return Date.parse ? Date.parse(date) : NaN;
	if (struct.z === void 0 && struct.plusMinus === void 0) return new Date(struct.year, struct.month, struct.day, struct.hour, struct.minute, struct.second, struct.millisecond).valueOf();
	let totalMinutesOffset = 0;
	if (struct.z !== "Z" && struct.plusMinus !== void 0) {
		totalMinutesOffset = struct.hourOffset * 60 + struct.minuteOffset;
		if (struct.plusMinus === "+") totalMinutesOffset = 0 - totalMinutesOffset;
	}
	return Date.UTC(struct.year, struct.month, struct.day, struct.hour, struct.minute + totalMinutesOffset, struct.second, struct.millisecond);
}
function parseDateStruct(date) {
	var _regexResult$7$length, _regexResult$;
	const regexResult = isoReg.exec(date);
	if (!regexResult) return null;
	return {
		year: toNumber(regexResult[1]),
		month: toNumber(regexResult[2], 1) - 1,
		day: toNumber(regexResult[3], 1),
		hour: toNumber(regexResult[4]),
		minute: toNumber(regexResult[5]),
		second: toNumber(regexResult[6]),
		millisecond: regexResult[7] ? toNumber(regexResult[7].substring(0, 3)) : 0,
		precision: (_regexResult$7$length = (_regexResult$ = regexResult[7]) == null ? void 0 : _regexResult$.length) != null ? _regexResult$7$length : void 0,
		z: regexResult[8] || void 0,
		plusMinus: regexResult[9] || void 0,
		hourOffset: toNumber(regexResult[10]),
		minuteOffset: toNumber(regexResult[11])
	};
}
function toNumber(str, defaultValue = 0) {
	return Number(str) || defaultValue;
}
var rEmail = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
var rUrl = /^((https?|ftp):)?\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i;
var rUUID = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;
var rIsoDateTime = new RegExp(`^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d+)?(([+-]\\d{2}(:?\\d{2})?)|Z)$`);
var isTrimmed = (value) => isAbsent(value) || value === value.trim();
var objStringTag = {}.toString();
function create$6() {
	return new StringSchema();
}
var StringSchema = class extends Schema {
	constructor() {
		super({
			type: "string",
			check(value) {
				if (value instanceof String) value = value.valueOf();
				return typeof value === "string";
			}
		});
		this.withMutation(() => {
			this.transform((value, _raw) => {
				if (!this.spec.coerce || this.isType(value)) return value;
				if (Array.isArray(value)) return value;
				const strValue = value != null && value.toString ? value.toString() : value;
				if (strValue === objStringTag) return value;
				return strValue;
			});
		});
	}
	required(message) {
		return super.required(message).withMutation((schema) => schema.test({
			message: message || mixed.required,
			name: "required",
			skipAbsent: true,
			test: (value) => !!value.length
		}));
	}
	notRequired() {
		return super.notRequired().withMutation((schema) => {
			schema.tests = schema.tests.filter((t) => t.OPTIONS.name !== "required");
			return schema;
		});
	}
	length(length, message = string.length) {
		return this.test({
			message,
			name: "length",
			exclusive: true,
			params: { length },
			skipAbsent: true,
			test(value) {
				return value.length === this.resolve(length);
			}
		});
	}
	min(min, message = string.min) {
		return this.test({
			message,
			name: "min",
			exclusive: true,
			params: { min },
			skipAbsent: true,
			test(value) {
				return value.length >= this.resolve(min);
			}
		});
	}
	max(max, message = string.max) {
		return this.test({
			name: "max",
			exclusive: true,
			message,
			params: { max },
			skipAbsent: true,
			test(value) {
				return value.length <= this.resolve(max);
			}
		});
	}
	matches(regex, options) {
		let excludeEmptyString = false;
		let message;
		let name;
		if (options) {
			if (typeof options === "object") ({excludeEmptyString = false, message, name} = options);
			else message = options;
		}
		return this.test({
			name: name || "matches",
			message: message || string.matches,
			params: { regex },
			skipAbsent: true,
			test: (value) => value === "" && excludeEmptyString || value.search(regex) !== -1
		});
	}
	email(message = string.email) {
		return this.matches(rEmail, {
			name: "email",
			message,
			excludeEmptyString: true
		});
	}
	url(message = string.url) {
		return this.matches(rUrl, {
			name: "url",
			message,
			excludeEmptyString: true
		});
	}
	uuid(message = string.uuid) {
		return this.matches(rUUID, {
			name: "uuid",
			message,
			excludeEmptyString: false
		});
	}
	datetime(options) {
		let message = "";
		let allowOffset;
		let precision;
		if (options) {
			if (typeof options === "object") ({message = "", allowOffset = false, precision = void 0} = options);
			else message = options;
		}
		return this.matches(rIsoDateTime, {
			name: "datetime",
			message: message || string.datetime,
			excludeEmptyString: true
		}).test({
			name: "datetime_offset",
			message: message || string.datetime_offset,
			params: { allowOffset },
			skipAbsent: true,
			test: (value) => {
				if (!value || allowOffset) return true;
				const struct = parseDateStruct(value);
				if (!struct) return false;
				return !!struct.z;
			}
		}).test({
			name: "datetime_precision",
			message: message || string.datetime_precision,
			params: { precision },
			skipAbsent: true,
			test: (value) => {
				if (!value || precision == void 0) return true;
				const struct = parseDateStruct(value);
				if (!struct) return false;
				return struct.precision === precision;
			}
		});
	}
	ensure() {
		return this.default("").transform((val) => val === null ? "" : val);
	}
	trim(message = string.trim) {
		return this.transform((val) => val != null ? val.trim() : val).test({
			message,
			name: "trim",
			test: isTrimmed
		});
	}
	lowercase(message = string.lowercase) {
		return this.transform((value) => !isAbsent(value) ? value.toLowerCase() : value).test({
			message,
			name: "string_case",
			exclusive: true,
			skipAbsent: true,
			test: (value) => isAbsent(value) || value === value.toLowerCase()
		});
	}
	uppercase(message = string.uppercase) {
		return this.transform((value) => !isAbsent(value) ? value.toUpperCase() : value).test({
			message,
			name: "string_case",
			exclusive: true,
			skipAbsent: true,
			test: (value) => isAbsent(value) || value === value.toUpperCase()
		});
	}
};
create$6.prototype = StringSchema.prototype;
var isNaN$1 = (value) => value != +value;
function create$5() {
	return new NumberSchema();
}
var NumberSchema = class extends Schema {
	constructor() {
		super({
			type: "number",
			check(value) {
				if (value instanceof Number) value = value.valueOf();
				return typeof value === "number" && !isNaN$1(value);
			}
		});
		this.withMutation(() => {
			this.transform((value, _raw) => {
				if (!this.spec.coerce) return value;
				let parsed = value;
				if (typeof parsed === "string") {
					parsed = parsed.replace(/\s/g, "");
					if (parsed === "") return NaN;
					parsed = +parsed;
				}
				if (this.isType(parsed) || parsed === null) return parsed;
				return parseFloat(parsed);
			});
		});
	}
	min(min, message = number.min) {
		return this.test({
			message,
			name: "min",
			exclusive: true,
			params: { min },
			skipAbsent: true,
			test(value) {
				return value >= this.resolve(min);
			}
		});
	}
	max(max, message = number.max) {
		return this.test({
			message,
			name: "max",
			exclusive: true,
			params: { max },
			skipAbsent: true,
			test(value) {
				return value <= this.resolve(max);
			}
		});
	}
	lessThan(less, message = number.lessThan) {
		return this.test({
			message,
			name: "max",
			exclusive: true,
			params: { less },
			skipAbsent: true,
			test(value) {
				return value < this.resolve(less);
			}
		});
	}
	moreThan(more, message = number.moreThan) {
		return this.test({
			message,
			name: "min",
			exclusive: true,
			params: { more },
			skipAbsent: true,
			test(value) {
				return value > this.resolve(more);
			}
		});
	}
	positive(msg = number.positive) {
		return this.moreThan(0, msg);
	}
	negative(msg = number.negative) {
		return this.lessThan(0, msg);
	}
	integer(message = number.integer) {
		return this.test({
			name: "integer",
			message,
			skipAbsent: true,
			test: (val) => Number.isInteger(val)
		});
	}
	truncate() {
		return this.transform((value) => !isAbsent(value) ? value | 0 : value);
	}
	round(method) {
		var _method;
		let avail = [
			"ceil",
			"floor",
			"round",
			"trunc"
		];
		method = ((_method = method) == null ? void 0 : _method.toLowerCase()) || "round";
		if (method === "trunc") return this.truncate();
		if (avail.indexOf(method.toLowerCase()) === -1) throw new TypeError("Only valid options for round() are: " + avail.join(", "));
		return this.transform((value) => !isAbsent(value) ? Math[method](value) : value);
	}
};
create$5.prototype = NumberSchema.prototype;
var invalidDate = /* @__PURE__ */ new Date("");
var isDate = (obj) => Object.prototype.toString.call(obj) === "[object Date]";
function create$4() {
	return new DateSchema();
}
var DateSchema = class DateSchema extends Schema {
	constructor() {
		super({
			type: "date",
			check(v) {
				return isDate(v) && !isNaN(v.getTime());
			}
		});
		this.withMutation(() => {
			this.transform((value, _raw) => {
				if (!this.spec.coerce || this.isType(value) || value === null) return value;
				value = parseIsoDate(value);
				return !isNaN(value) ? new Date(value) : DateSchema.INVALID_DATE;
			});
		});
	}
	prepareParam(ref, name) {
		let param;
		if (!Reference.isRef(ref)) {
			let cast = this.cast(ref);
			if (!this._typeCheck(cast)) throw new TypeError(`\`${name}\` must be a Date or a value that can be \`cast()\` to a Date`);
			param = cast;
		} else param = ref;
		return param;
	}
	min(min, message = date.min) {
		let limit = this.prepareParam(min, "min");
		return this.test({
			message,
			name: "min",
			exclusive: true,
			params: { min },
			skipAbsent: true,
			test(value) {
				return value >= this.resolve(limit);
			}
		});
	}
	max(max, message = date.max) {
		let limit = this.prepareParam(max, "max");
		return this.test({
			message,
			name: "max",
			exclusive: true,
			params: { max },
			skipAbsent: true,
			test(value) {
				return value <= this.resolve(limit);
			}
		});
	}
};
DateSchema.INVALID_DATE = invalidDate;
create$4.prototype = DateSchema.prototype;
create$4.INVALID_DATE = invalidDate;
function sortFields(fields, excludedEdges = []) {
	let edges = [];
	let nodes = /* @__PURE__ */ new Set();
	let excludes = new Set(excludedEdges.map(([a, b]) => `${a}-${b}`));
	function addNode(depPath, key) {
		let node = (0, import_property_expr.split)(depPath)[0];
		nodes.add(node);
		if (!excludes.has(`${key}-${node}`)) edges.push([key, node]);
	}
	for (const key of Object.keys(fields)) {
		let value = fields[key];
		nodes.add(key);
		if (Reference.isRef(value) && value.isSibling) addNode(value.path, key);
		else if (isSchema(value) && "deps" in value) value.deps.forEach((path) => addNode(path, key));
	}
	return import_toposort.default.array(Array.from(nodes), edges).reverse();
}
function findIndex(arr, err) {
	let idx = Infinity;
	arr.some((key, ii) => {
		var _err$path;
		if ((_err$path = err.path) != null && _err$path.includes(key)) {
			idx = ii;
			return true;
		}
	});
	return idx;
}
function sortByKeyOrder(keys) {
	return (a, b) => {
		return findIndex(keys, a) - findIndex(keys, b);
	};
}
var parseJson = (value, _, schema) => {
	if (typeof value !== "string") return value;
	let parsed = value;
	try {
		parsed = JSON.parse(value);
	} catch (err) {}
	return schema.isType(parsed) ? parsed : value;
};
function deepPartial(schema) {
	if ("fields" in schema) {
		const partial = {};
		for (const [key, fieldSchema] of Object.entries(schema.fields)) partial[key] = deepPartial(fieldSchema);
		return schema.setFields(partial);
	}
	if (schema.type === "array") {
		const nextArray = schema.optional();
		if (nextArray.innerType) nextArray.innerType = deepPartial(nextArray.innerType);
		return nextArray;
	}
	if (schema.type === "tuple") return schema.optional().clone({ types: schema.spec.types.map(deepPartial) });
	if ("optional" in schema) return schema.optional();
	return schema;
}
var deepHas = (obj, p) => {
	const path = [...(0, import_property_expr.normalizePath)(p)];
	if (path.length === 1) return path[0] in obj;
	let last = path.pop();
	let parent = (0, import_property_expr.getter)((0, import_property_expr.join)(path), true)(obj);
	return !!(parent && last in parent);
};
var isObject = (obj) => Object.prototype.toString.call(obj) === "[object Object]";
function unknown(ctx, value) {
	let known = Object.keys(ctx.fields);
	return Object.keys(value).filter((key) => known.indexOf(key) === -1);
}
var defaultSort = sortByKeyOrder([]);
function create$3(spec) {
	return new ObjectSchema(spec);
}
var ObjectSchema = class extends Schema {
	constructor(spec) {
		super({
			type: "object",
			check(value) {
				return isObject(value) || typeof value === "function";
			}
		});
		this.fields = Object.create(null);
		this._sortErrors = defaultSort;
		this._nodes = [];
		this._excludedEdges = [];
		this.withMutation(() => {
			if (spec) this.shape(spec);
		});
	}
	_cast(_value, options = {}) {
		var _options$stripUnknown;
		let value = super._cast(_value, options);
		if (value === void 0) return this.getDefault(options);
		if (!this._typeCheck(value)) return value;
		let fields = this.fields;
		let strip = (_options$stripUnknown = options.stripUnknown) != null ? _options$stripUnknown : this.spec.noUnknown;
		let props = [].concat(this._nodes, Object.keys(value).filter((v) => !this._nodes.includes(v)));
		let intermediateValue = {};
		let innerOptions = Object.assign({}, options, {
			parent: intermediateValue,
			__validating: options.__validating || false
		});
		let isChanged = false;
		for (const prop of props) {
			let field = fields[prop];
			let exists = prop in value;
			let inputValue = value[prop];
			if (field) {
				let fieldValue;
				innerOptions.path = (options.path ? `${options.path}.` : "") + prop;
				field = field.resolve({
					value: inputValue,
					context: options.context,
					parent: intermediateValue
				});
				let fieldSpec = field instanceof Schema ? field.spec : void 0;
				let strict = fieldSpec == null ? void 0 : fieldSpec.strict;
				if (fieldSpec != null && fieldSpec.strip) {
					isChanged = isChanged || prop in value;
					continue;
				}
				fieldValue = !options.__validating || !strict ? field.cast(inputValue, innerOptions) : inputValue;
				if (fieldValue !== void 0) intermediateValue[prop] = fieldValue;
			} else if (exists && !strip) intermediateValue[prop] = inputValue;
			if (exists !== prop in intermediateValue || intermediateValue[prop] !== inputValue) isChanged = true;
		}
		return isChanged ? intermediateValue : value;
	}
	_validate(_value, options = {}, panic, next) {
		let { from = [], originalValue = _value, recursive = this.spec.recursive } = options;
		options.from = [{
			schema: this,
			value: originalValue
		}, ...from];
		options.__validating = true;
		options.originalValue = originalValue;
		super._validate(_value, options, panic, (objectErrors, value) => {
			if (!recursive || !isObject(value)) {
				next(objectErrors, value);
				return;
			}
			originalValue = originalValue || value;
			let tests = [];
			for (let key of this._nodes) {
				let field = this.fields[key];
				if (!field || Reference.isRef(field)) continue;
				tests.push(field.asNestedTest({
					options,
					key,
					parent: value,
					parentPath: options.path,
					originalParent: originalValue
				}));
			}
			this.runTests({
				tests,
				value,
				originalValue,
				options
			}, panic, (fieldErrors) => {
				next(fieldErrors.sort(this._sortErrors).concat(objectErrors), value);
			});
		});
	}
	clone(spec) {
		const next = super.clone(spec);
		next.fields = Object.assign({}, this.fields);
		next._nodes = this._nodes;
		next._excludedEdges = this._excludedEdges;
		next._sortErrors = this._sortErrors;
		return next;
	}
	concat(schema) {
		let next = super.concat(schema);
		let nextFields = next.fields;
		for (let [field, schemaOrRef] of Object.entries(this.fields)) {
			const target = nextFields[field];
			nextFields[field] = target === void 0 ? schemaOrRef : target;
		}
		return next.withMutation((s) => s.setFields(nextFields, [...this._excludedEdges, ...schema._excludedEdges]));
	}
	_getDefault(options) {
		if ("default" in this.spec) return super._getDefault(options);
		if (!this._nodes.length) return;
		let dft = {};
		this._nodes.forEach((key) => {
			var _innerOptions;
			const field = this.fields[key];
			let innerOptions = options;
			if ((_innerOptions = innerOptions) != null && _innerOptions.value) innerOptions = Object.assign({}, innerOptions, {
				parent: innerOptions.value,
				value: innerOptions.value[key]
			});
			dft[key] = field && "getDefault" in field ? field.getDefault(innerOptions) : void 0;
		});
		return dft;
	}
	setFields(shape, excludedEdges) {
		let next = this.clone();
		next.fields = shape;
		next._nodes = sortFields(shape, excludedEdges);
		next._sortErrors = sortByKeyOrder(Object.keys(shape));
		if (excludedEdges) next._excludedEdges = excludedEdges;
		return next;
	}
	shape(additions, excludes = []) {
		return this.clone().withMutation((next) => {
			let edges = next._excludedEdges;
			if (excludes.length) {
				if (!Array.isArray(excludes[0])) excludes = [excludes];
				edges = [...next._excludedEdges, ...excludes];
			}
			return next.setFields(Object.assign(next.fields, additions), edges);
		});
	}
	partial() {
		const partial = {};
		for (const [key, schema] of Object.entries(this.fields)) partial[key] = "optional" in schema && schema.optional instanceof Function ? schema.optional() : schema;
		return this.setFields(partial);
	}
	deepPartial() {
		return deepPartial(this);
	}
	pick(keys) {
		const picked = {};
		for (const key of keys) if (this.fields[key]) picked[key] = this.fields[key];
		return this.setFields(picked, this._excludedEdges.filter(([a, b]) => keys.includes(a) && keys.includes(b)));
	}
	omit(keys) {
		const remaining = [];
		for (const key of Object.keys(this.fields)) {
			if (keys.includes(key)) continue;
			remaining.push(key);
		}
		return this.pick(remaining);
	}
	from(from, to, alias) {
		let fromGetter = (0, import_property_expr.getter)(from, true);
		return this.transform((obj) => {
			if (!obj) return obj;
			let newObj = obj;
			if (deepHas(obj, from)) {
				newObj = Object.assign({}, obj);
				if (!alias) delete newObj[from];
				newObj[to] = fromGetter(obj);
			}
			return newObj;
		});
	}
	/** Parse an input JSON string to an object */
	json() {
		return this.transform(parseJson);
	}
	/**
	* Similar to `noUnknown` but only validates that an object is the right shape without stripping the unknown keys
	*/
	exact(message) {
		return this.test({
			name: "exact",
			exclusive: true,
			message: message || object.exact,
			test(value) {
				if (value == null) return true;
				const unknownKeys = unknown(this.schema, value);
				return unknownKeys.length === 0 || this.createError({ params: { properties: unknownKeys.join(", ") } });
			}
		});
	}
	stripUnknown() {
		return this.clone({ noUnknown: true });
	}
	noUnknown(noAllow = true, message = object.noUnknown) {
		if (typeof noAllow !== "boolean") {
			message = noAllow;
			noAllow = true;
		}
		let next = this.test({
			name: "noUnknown",
			exclusive: true,
			message,
			test(value) {
				if (value == null) return true;
				const unknownKeys = unknown(this.schema, value);
				return !noAllow || unknownKeys.length === 0 || this.createError({ params: { unknown: unknownKeys.join(", ") } });
			}
		});
		next.spec.noUnknown = noAllow;
		return next;
	}
	unknown(allow = true, message = object.noUnknown) {
		return this.noUnknown(!allow, message);
	}
	transformKeys(fn) {
		return this.transform((obj) => {
			if (!obj) return obj;
			const result = {};
			for (const key of Object.keys(obj)) result[fn(key)] = obj[key];
			return result;
		});
	}
	camelCase() {
		return this.transformKeys(import_tiny_case.camelCase);
	}
	snakeCase() {
		return this.transformKeys(import_tiny_case.snakeCase);
	}
	constantCase() {
		return this.transformKeys((key) => (0, import_tiny_case.snakeCase)(key).toUpperCase());
	}
	describe(options) {
		const next = (options ? this.resolve(options) : this).clone();
		const base = super.describe(options);
		base.fields = {};
		for (const [key, value] of Object.entries(next.fields)) {
			var _innerOptions2;
			let innerOptions = options;
			if ((_innerOptions2 = innerOptions) != null && _innerOptions2.value) innerOptions = Object.assign({}, innerOptions, {
				parent: innerOptions.value,
				value: innerOptions.value[key]
			});
			base.fields[key] = value.describe(innerOptions);
		}
		return base;
	}
};
create$3.prototype = ObjectSchema.prototype;
function create$2(type) {
	return new ArraySchema(type);
}
var ArraySchema = class extends Schema {
	constructor(type) {
		super({
			type: "array",
			spec: { types: type },
			check(v) {
				return Array.isArray(v);
			}
		});
		this.innerType = void 0;
		this.innerType = type;
	}
	_cast(_value, _opts) {
		const value = super._cast(_value, _opts);
		if (!this._typeCheck(value) || !this.innerType) return value;
		let isChanged = false;
		const castArray = value.map((v, idx) => {
			const castElement = this.innerType.cast(v, Object.assign({}, _opts, {
				path: `${_opts.path || ""}[${idx}]`,
				parent: value,
				originalValue: v,
				value: v,
				index: idx
			}));
			if (castElement !== v) isChanged = true;
			return castElement;
		});
		return isChanged ? castArray : value;
	}
	_validate(_value, options = {}, panic, next) {
		var _options$recursive;
		let innerType = this.innerType;
		let recursive = (_options$recursive = options.recursive) != null ? _options$recursive : this.spec.recursive;
		options.originalValue != null && options.originalValue;
		super._validate(_value, options, panic, (arrayErrors, value) => {
			var _options$originalValu2;
			if (!recursive || !innerType || !this._typeCheck(value)) {
				next(arrayErrors, value);
				return;
			}
			let tests = new Array(value.length);
			for (let index = 0; index < value.length; index++) {
				var _options$originalValu;
				tests[index] = innerType.asNestedTest({
					options,
					index,
					parent: value,
					parentPath: options.path,
					originalParent: (_options$originalValu = options.originalValue) != null ? _options$originalValu : _value
				});
			}
			this.runTests({
				value,
				tests,
				originalValue: (_options$originalValu2 = options.originalValue) != null ? _options$originalValu2 : _value,
				options
			}, panic, (innerTypeErrors) => next(innerTypeErrors.concat(arrayErrors), value));
		});
	}
	clone(spec) {
		const next = super.clone(spec);
		next.innerType = this.innerType;
		return next;
	}
	/** Parse an input JSON string to an object */
	json() {
		return this.transform(parseJson);
	}
	concat(schema) {
		let next = super.concat(schema);
		next.innerType = this.innerType;
		if (schema.innerType) next.innerType = next.innerType ? next.innerType.concat(schema.innerType) : schema.innerType;
		return next;
	}
	of(schema) {
		let next = this.clone();
		if (!isSchema(schema)) throw new TypeError("`array.of()` sub-schema must be a valid yup schema not: " + printValue(schema));
		next.innerType = schema;
		next.spec = Object.assign({}, next.spec, { types: schema });
		return next;
	}
	length(length, message = array.length) {
		return this.test({
			message,
			name: "length",
			exclusive: true,
			params: { length },
			skipAbsent: true,
			test(value) {
				return value.length === this.resolve(length);
			}
		});
	}
	min(min, message) {
		message = message || array.min;
		return this.test({
			message,
			name: "min",
			exclusive: true,
			params: { min },
			skipAbsent: true,
			test(value) {
				return value.length >= this.resolve(min);
			}
		});
	}
	max(max, message) {
		message = message || array.max;
		return this.test({
			message,
			name: "max",
			exclusive: true,
			params: { max },
			skipAbsent: true,
			test(value) {
				return value.length <= this.resolve(max);
			}
		});
	}
	ensure() {
		return this.default(() => []).transform((val, original) => {
			if (this._typeCheck(val)) return val;
			return original == null ? [] : [].concat(original);
		});
	}
	compact(rejector) {
		let reject = !rejector ? (v) => !!v : (v, i, a) => !rejector(v, i, a);
		return this.transform((values) => values != null ? values.filter(reject) : values);
	}
	describe(options) {
		const next = (options ? this.resolve(options) : this).clone();
		const base = super.describe(options);
		if (next.innerType) {
			var _innerOptions;
			let innerOptions = options;
			if ((_innerOptions = innerOptions) != null && _innerOptions.value) innerOptions = Object.assign({}, innerOptions, {
				parent: innerOptions.value,
				value: innerOptions.value[0]
			});
			base.innerType = next.innerType.describe(innerOptions);
		}
		return base;
	}
};
create$2.prototype = ArraySchema.prototype;
function create$1(schemas) {
	return new TupleSchema(schemas);
}
var TupleSchema = class extends Schema {
	constructor(schemas) {
		super({
			type: "tuple",
			spec: { types: schemas },
			check(v) {
				const types = this.spec.types;
				return Array.isArray(v) && v.length === types.length;
			}
		});
		this.withMutation(() => {
			this.typeError(tuple.notType);
		});
	}
	_cast(inputValue, options) {
		const { types } = this.spec;
		const value = super._cast(inputValue, options);
		if (!this._typeCheck(value)) return value;
		let isChanged = false;
		const castArray = types.map((type, idx) => {
			const castElement = type.cast(value[idx], Object.assign({}, options, {
				path: `${options.path || ""}[${idx}]`,
				parent: value,
				originalValue: value[idx],
				value: value[idx],
				index: idx
			}));
			if (castElement !== value[idx]) isChanged = true;
			return castElement;
		});
		return isChanged ? castArray : value;
	}
	_validate(_value, options = {}, panic, next) {
		let itemTypes = this.spec.types;
		super._validate(_value, options, panic, (tupleErrors, value) => {
			var _options$originalValu2;
			if (!this._typeCheck(value)) {
				next(tupleErrors, value);
				return;
			}
			let tests = [];
			for (let [index, itemSchema] of itemTypes.entries()) {
				var _options$originalValu;
				tests[index] = itemSchema.asNestedTest({
					options,
					index,
					parent: value,
					parentPath: options.path,
					originalParent: (_options$originalValu = options.originalValue) != null ? _options$originalValu : _value
				});
			}
			this.runTests({
				value,
				tests,
				originalValue: (_options$originalValu2 = options.originalValue) != null ? _options$originalValu2 : _value,
				options
			}, panic, (innerTypeErrors) => next(innerTypeErrors.concat(tupleErrors), value));
		});
	}
	describe(options) {
		const next = (options ? this.resolve(options) : this).clone();
		const base = super.describe(options);
		base.innerType = next.spec.types.map((schema, index) => {
			var _innerOptions;
			let innerOptions = options;
			if ((_innerOptions = innerOptions) != null && _innerOptions.value) innerOptions = Object.assign({}, innerOptions, {
				parent: innerOptions.value,
				value: innerOptions.value[index]
			});
			return schema.describe(innerOptions);
		});
		return base;
	}
};
create$1.prototype = TupleSchema.prototype;
function create(builder) {
	return new Lazy(builder);
}
function catchValidationError(fn) {
	try {
		return fn();
	} catch (err) {
		if (ValidationError.isError(err)) return Promise.reject(err);
		throw err;
	}
}
var Lazy = class Lazy {
	constructor(builder) {
		this.type = "lazy";
		this.__isYupSchema__ = true;
		this.spec = void 0;
		this._resolve = (value, options = {}) => {
			let schema = this.builder(value, options);
			if (!isSchema(schema)) throw new TypeError("lazy() functions must return a valid schema");
			if (this.spec.optional) schema = schema.optional();
			return schema.resolve(options);
		};
		this.builder = builder;
		this.spec = {
			meta: void 0,
			optional: false
		};
	}
	clone(spec) {
		const next = new Lazy(this.builder);
		next.spec = Object.assign({}, this.spec, spec);
		return next;
	}
	optionality(optional) {
		return this.clone({ optional });
	}
	optional() {
		return this.optionality(true);
	}
	resolve(options) {
		return this._resolve(options.value, options);
	}
	cast(value, options) {
		return this._resolve(value, options).cast(value, options);
	}
	asNestedTest(config) {
		let { key, index, parent, options } = config;
		let value = parent[index != null ? index : key];
		return this._resolve(value, Object.assign({}, options, {
			value,
			parent
		})).asNestedTest(config);
	}
	validate(value, options) {
		return catchValidationError(() => this._resolve(value, options).validate(value, options));
	}
	validateSync(value, options) {
		return this._resolve(value, options).validateSync(value, options);
	}
	validateAt(path, value, options) {
		return catchValidationError(() => this._resolve(value, options).validateAt(path, value, options));
	}
	validateSyncAt(path, value, options) {
		return this._resolve(value, options).validateSyncAt(path, value, options);
	}
	isValid(value, options) {
		try {
			return this._resolve(value, options).isValid(value, options);
		} catch (err) {
			if (ValidationError.isError(err)) return Promise.resolve(false);
			throw err;
		}
	}
	isValidSync(value, options) {
		return this._resolve(value, options).isValidSync(value, options);
	}
	describe(options) {
		return options ? this.resolve(options).describe(options) : {
			type: "lazy",
			meta: this.spec.meta,
			label: void 0
		};
	}
	meta(...args) {
		if (args.length === 0) return this.spec.meta;
		let next = this.clone();
		next.spec.meta = Object.assign(next.spec.meta || {}, args[0]);
		return next;
	}
	get ["~standard"]() {
		const schema = this;
		return {
			version: 1,
			vendor: "yup",
			async validate(value) {
				try {
					return { value: await schema.validate(value, { abortEarly: false }) };
				} catch (err) {
					if (ValidationError.isError(err)) return { issues: issuesFromValidationError(err) };
					throw err;
				}
			}
		};
	}
};
function setLocale(custom) {
	Object.keys(custom).forEach((type) => {
		Object.keys(custom[type]).forEach((method) => {
			locale[type][method] = custom[type][method];
		});
	});
}
function addMethod(schemaType, name, fn) {
	if (!schemaType || !isSchema(schemaType.prototype)) throw new TypeError("You must provide a yup schema constructor function");
	if (typeof name !== "string") throw new TypeError("A Method name must be provided");
	if (typeof fn !== "function") throw new TypeError("Method function must be provided");
	schemaType.prototype[name] = fn;
}
//#endregion
export { ArraySchema, BooleanSchema, DateSchema, Lazy as LazySchema, MixedSchema, NumberSchema, ObjectSchema, Schema, StringSchema, TupleSchema, ValidationError, addMethod, create$2 as array, create$7 as bool, create$7 as boolean, create$4 as date, locale as defaultLocale, getIn, isSchema, create as lazy, create$8 as mixed, create$5 as number, create$3 as object, printValue, reach, create$9 as ref, setLocale, create$6 as string, create$1 as tuple };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoieXVwLmpzIiwibmFtZXMiOlsiZ2V0dGVyIiwic3BsaXQiLCJ0b3Bvc29ydCIsIm5vcm1hbGl6ZVBhdGgiLCJqb2luIiwiY2FtZWxDYXNlIiwic25ha2VDYXNlIl0sInNvdXJjZXMiOlsiLi4vLi4vcHJvcGVydHktZXhwci9pbmRleC5qcyIsIi4uLy4uL3RpbnktY2FzZS9pbmRleC5qcyIsIi4uLy4uL3RvcG9zb3J0L2luZGV4LmpzIiwiLi4vLi4veXVwL2luZGV4LmVzbS5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEJhc2VkIG9uIEtlbmRvIFVJIENvcmUgZXhwcmVzc2lvbiBjb2RlIDxodHRwczovL2dpdGh1Yi5jb20vdGVsZXJpay9rZW5kby11aS1jb3JlI2xpY2Vuc2UtaW5mb3JtYXRpb24+XG4gKi9cbid1c2Ugc3RyaWN0J1xuXG5mdW5jdGlvbiBDYWNoZShtYXhTaXplKSB7XG4gIHRoaXMuX21heFNpemUgPSBtYXhTaXplXG4gIHRoaXMuY2xlYXIoKVxufVxuQ2FjaGUucHJvdG90eXBlLmNsZWFyID0gZnVuY3Rpb24gKCkge1xuICB0aGlzLl9zaXplID0gMFxuICB0aGlzLl92YWx1ZXMgPSBPYmplY3QuY3JlYXRlKG51bGwpXG59XG5DYWNoZS5wcm90b3R5cGUuZ2V0ID0gZnVuY3Rpb24gKGtleSkge1xuICByZXR1cm4gdGhpcy5fdmFsdWVzW2tleV1cbn1cbkNhY2hlLnByb3RvdHlwZS5zZXQgPSBmdW5jdGlvbiAoa2V5LCB2YWx1ZSkge1xuICB0aGlzLl9zaXplID49IHRoaXMuX21heFNpemUgJiYgdGhpcy5jbGVhcigpXG4gIGlmICghKGtleSBpbiB0aGlzLl92YWx1ZXMpKSB0aGlzLl9zaXplKytcblxuICByZXR1cm4gKHRoaXMuX3ZhbHVlc1trZXldID0gdmFsdWUpXG59XG5cbnZhciBTUExJVF9SRUdFWCA9IC9bXi5eXFxdXltdK3woPz1cXFtcXF18XFwuXFwuKS9nLFxuICBESUdJVF9SRUdFWCA9IC9eXFxkKyQvLFxuICBMRUFEX0RJR0lUX1JFR0VYID0gL15cXGQvLFxuICBTUEVDX0NIQVJfUkVHRVggPSAvW35gISMkJVxcXiYqKz1cXC1cXFtcXF1cXFxcJzssL3t9fFxcXFxcIjo8PlxcP10vZyxcbiAgQ0xFQU5fUVVPVEVTX1JFR0VYID0gL15cXHMqKFsnXCJdPykoLio/KShcXDEpXFxzKiQvLFxuICBNQVhfQ0FDSEVfU0laRSA9IDUxMlxuXG52YXIgcGF0aENhY2hlID0gbmV3IENhY2hlKE1BWF9DQUNIRV9TSVpFKSxcbiAgc2V0Q2FjaGUgPSBuZXcgQ2FjaGUoTUFYX0NBQ0hFX1NJWkUpLFxuICBnZXRDYWNoZSA9IG5ldyBDYWNoZShNQVhfQ0FDSEVfU0laRSlcblxudmFyIGNvbmZpZ1xuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgQ2FjaGU6IENhY2hlLFxuXG4gIHNwbGl0OiBzcGxpdCxcblxuICBub3JtYWxpemVQYXRoOiBub3JtYWxpemVQYXRoLFxuXG4gIHNldHRlcjogZnVuY3Rpb24gKHBhdGgpIHtcbiAgICB2YXIgcGFydHMgPSBub3JtYWxpemVQYXRoKHBhdGgpXG5cbiAgICByZXR1cm4gKFxuICAgICAgc2V0Q2FjaGUuZ2V0KHBhdGgpIHx8XG4gICAgICBzZXRDYWNoZS5zZXQocGF0aCwgZnVuY3Rpb24gc2V0dGVyKG9iaiwgdmFsdWUpIHtcbiAgICAgICAgdmFyIGluZGV4ID0gMFxuICAgICAgICB2YXIgbGVuID0gcGFydHMubGVuZ3RoXG4gICAgICAgIHZhciBkYXRhID0gb2JqXG5cbiAgICAgICAgd2hpbGUgKGluZGV4IDwgbGVuIC0gMSkge1xuICAgICAgICAgIHZhciBwYXJ0ID0gcGFydHNbaW5kZXhdXG4gICAgICAgICAgaWYgKFxuICAgICAgICAgICAgcGFydCA9PT0gJ19fcHJvdG9fXycgfHxcbiAgICAgICAgICAgIHBhcnQgPT09ICdjb25zdHJ1Y3RvcicgfHxcbiAgICAgICAgICAgIHBhcnQgPT09ICdwcm90b3R5cGUnXG4gICAgICAgICAgKSB7XG4gICAgICAgICAgICByZXR1cm4gb2JqXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgZGF0YSA9IGRhdGFbcGFydHNbaW5kZXgrK11dXG4gICAgICAgIH1cbiAgICAgICAgZGF0YVtwYXJ0c1tpbmRleF1dID0gdmFsdWVcbiAgICAgIH0pXG4gICAgKVxuICB9LFxuXG4gIGdldHRlcjogZnVuY3Rpb24gKHBhdGgsIHNhZmUpIHtcbiAgICB2YXIgcGFydHMgPSBub3JtYWxpemVQYXRoKHBhdGgpXG4gICAgcmV0dXJuIChcbiAgICAgIGdldENhY2hlLmdldChwYXRoKSB8fFxuICAgICAgZ2V0Q2FjaGUuc2V0KHBhdGgsIGZ1bmN0aW9uIGdldHRlcihkYXRhKSB7XG4gICAgICAgIHZhciBpbmRleCA9IDAsXG4gICAgICAgICAgbGVuID0gcGFydHMubGVuZ3RoXG4gICAgICAgIHdoaWxlIChpbmRleCA8IGxlbikge1xuICAgICAgICAgIGlmIChkYXRhICE9IG51bGwgfHwgIXNhZmUpIGRhdGEgPSBkYXRhW3BhcnRzW2luZGV4KytdXVxuICAgICAgICAgIGVsc2UgcmV0dXJuXG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGRhdGFcbiAgICAgIH0pXG4gICAgKVxuICB9LFxuXG4gIGpvaW46IGZ1bmN0aW9uIChzZWdtZW50cykge1xuICAgIHJldHVybiBzZWdtZW50cy5yZWR1Y2UoZnVuY3Rpb24gKHBhdGgsIHBhcnQpIHtcbiAgICAgIHJldHVybiAoXG4gICAgICAgIHBhdGggK1xuICAgICAgICAoaXNRdW90ZWQocGFydCkgfHwgRElHSVRfUkVHRVgudGVzdChwYXJ0KVxuICAgICAgICAgID8gJ1snICsgcGFydCArICddJ1xuICAgICAgICAgIDogKHBhdGggPyAnLicgOiAnJykgKyBwYXJ0KVxuICAgICAgKVxuICAgIH0sICcnKVxuICB9LFxuXG4gIGZvckVhY2g6IGZ1bmN0aW9uIChwYXRoLCBjYiwgdGhpc0FyZykge1xuICAgIGZvckVhY2goQXJyYXkuaXNBcnJheShwYXRoKSA/IHBhdGggOiBzcGxpdChwYXRoKSwgY2IsIHRoaXNBcmcpXG4gIH0sXG59XG5cbmZ1bmN0aW9uIG5vcm1hbGl6ZVBhdGgocGF0aCkge1xuICByZXR1cm4gKFxuICAgIHBhdGhDYWNoZS5nZXQocGF0aCkgfHxcbiAgICBwYXRoQ2FjaGUuc2V0KFxuICAgICAgcGF0aCxcbiAgICAgIHNwbGl0KHBhdGgpLm1hcChmdW5jdGlvbiAocGFydCkge1xuICAgICAgICByZXR1cm4gcGFydC5yZXBsYWNlKENMRUFOX1FVT1RFU19SRUdFWCwgJyQyJylcbiAgICAgIH0pXG4gICAgKVxuICApXG59XG5cbmZ1bmN0aW9uIHNwbGl0KHBhdGgpIHtcbiAgcmV0dXJuIHBhdGgubWF0Y2goU1BMSVRfUkVHRVgpIHx8IFsnJ11cbn1cblxuZnVuY3Rpb24gZm9yRWFjaChwYXJ0cywgaXRlciwgdGhpc0FyZykge1xuICB2YXIgbGVuID0gcGFydHMubGVuZ3RoLFxuICAgIHBhcnQsXG4gICAgaWR4LFxuICAgIGlzQXJyYXksXG4gICAgaXNCcmFja2V0XG5cbiAgZm9yIChpZHggPSAwOyBpZHggPCBsZW47IGlkeCsrKSB7XG4gICAgcGFydCA9IHBhcnRzW2lkeF1cblxuICAgIGlmIChwYXJ0KSB7XG4gICAgICBpZiAoc2hvdWxkQmVRdW90ZWQocGFydCkpIHtcbiAgICAgICAgcGFydCA9ICdcIicgKyBwYXJ0ICsgJ1wiJ1xuICAgICAgfVxuXG4gICAgICBpc0JyYWNrZXQgPSBpc1F1b3RlZChwYXJ0KVxuICAgICAgaXNBcnJheSA9ICFpc0JyYWNrZXQgJiYgL15cXGQrJC8udGVzdChwYXJ0KVxuXG4gICAgICBpdGVyLmNhbGwodGhpc0FyZywgcGFydCwgaXNCcmFja2V0LCBpc0FycmF5LCBpZHgsIHBhcnRzKVxuICAgIH1cbiAgfVxufVxuXG5mdW5jdGlvbiBpc1F1b3RlZChzdHIpIHtcbiAgcmV0dXJuIChcbiAgICB0eXBlb2Ygc3RyID09PSAnc3RyaW5nJyAmJiBzdHIgJiYgW1wiJ1wiLCAnXCInXS5pbmRleE9mKHN0ci5jaGFyQXQoMCkpICE9PSAtMVxuICApXG59XG5cbmZ1bmN0aW9uIGhhc0xlYWRpbmdOdW1iZXIocGFydCkge1xuICByZXR1cm4gcGFydC5tYXRjaChMRUFEX0RJR0lUX1JFR0VYKSAmJiAhcGFydC5tYXRjaChESUdJVF9SRUdFWClcbn1cblxuZnVuY3Rpb24gaGFzU3BlY2lhbENoYXJzKHBhcnQpIHtcbiAgcmV0dXJuIFNQRUNfQ0hBUl9SRUdFWC50ZXN0KHBhcnQpXG59XG5cbmZ1bmN0aW9uIHNob3VsZEJlUXVvdGVkKHBhcnQpIHtcbiAgcmV0dXJuICFpc1F1b3RlZChwYXJ0KSAmJiAoaGFzTGVhZGluZ051bWJlcihwYXJ0KSB8fCBoYXNTcGVjaWFsQ2hhcnMocGFydCkpXG59XG4iLCJjb25zdCByZVdvcmRzID0gL1tBLVpcXHhjMC1cXHhkNlxceGQ4LVxceGRlXT9bYS16XFx4ZGYtXFx4ZjZcXHhmOC1cXHhmZl0rKD86WyfigJldKD86ZHxsbHxtfHJlfHN8dHx2ZSkpPyg/PVtcXHhhY1xceGIxXFx4ZDdcXHhmN1xceDAwLVxceDJmXFx4M2EtXFx4NDBcXHg1Yi1cXHg2MFxceDdiLVxceGJmXFx1MjAwMC1cXHUyMDZmIFxcdFxceDBiXFxmXFx4YTBcXHVmZWZmXFxuXFxyXFx1MjAyOFxcdTIwMjlcXHUxNjgwXFx1MTgwZVxcdTIwMDBcXHUyMDAxXFx1MjAwMlxcdTIwMDNcXHUyMDA0XFx1MjAwNVxcdTIwMDZcXHUyMDA3XFx1MjAwOFxcdTIwMDlcXHUyMDBhXFx1MjAyZlxcdTIwNWZcXHUzMDAwXXxbQS1aXFx4YzAtXFx4ZDZcXHhkOC1cXHhkZV18JCl8KD86W0EtWlxceGMwLVxceGQ2XFx4ZDgtXFx4ZGVdfFteXFx1ZDgwMC1cXHVkZmZmXFx4YWNcXHhiMVxceGQ3XFx4ZjdcXHgwMC1cXHgyZlxceDNhLVxceDQwXFx4NWItXFx4NjBcXHg3Yi1cXHhiZlxcdTIwMDAtXFx1MjA2ZiBcXHRcXHgwYlxcZlxceGEwXFx1ZmVmZlxcblxcclxcdTIwMjhcXHUyMDI5XFx1MTY4MFxcdTE4MGVcXHUyMDAwXFx1MjAwMVxcdTIwMDJcXHUyMDAzXFx1MjAwNFxcdTIwMDVcXHUyMDA2XFx1MjAwN1xcdTIwMDhcXHUyMDA5XFx1MjAwYVxcdTIwMmZcXHUyMDVmXFx1MzAwMFxcZCtcXHUyNzAwLVxcdTI3YmZhLXpcXHhkZi1cXHhmNlxceGY4LVxceGZmQS1aXFx4YzAtXFx4ZDZcXHhkOC1cXHhkZV0pKyg/Olsn4oCZXSg/OkR8TEx8TXxSRXxTfFR8VkUpKT8oPz1bXFx4YWNcXHhiMVxceGQ3XFx4ZjdcXHgwMC1cXHgyZlxceDNhLVxceDQwXFx4NWItXFx4NjBcXHg3Yi1cXHhiZlxcdTIwMDAtXFx1MjA2ZiBcXHRcXHgwYlxcZlxceGEwXFx1ZmVmZlxcblxcclxcdTIwMjhcXHUyMDI5XFx1MTY4MFxcdTE4MGVcXHUyMDAwXFx1MjAwMVxcdTIwMDJcXHUyMDAzXFx1MjAwNFxcdTIwMDVcXHUyMDA2XFx1MjAwN1xcdTIwMDhcXHUyMDA5XFx1MjAwYVxcdTIwMmZcXHUyMDVmXFx1MzAwMF18W0EtWlxceGMwLVxceGQ2XFx4ZDgtXFx4ZGVdKD86W2EtelxceGRmLVxceGY2XFx4ZjgtXFx4ZmZdfFteXFx1ZDgwMC1cXHVkZmZmXFx4YWNcXHhiMVxceGQ3XFx4ZjdcXHgwMC1cXHgyZlxceDNhLVxceDQwXFx4NWItXFx4NjBcXHg3Yi1cXHhiZlxcdTIwMDAtXFx1MjA2ZiBcXHRcXHgwYlxcZlxceGEwXFx1ZmVmZlxcblxcclxcdTIwMjhcXHUyMDI5XFx1MTY4MFxcdTE4MGVcXHUyMDAwXFx1MjAwMVxcdTIwMDJcXHUyMDAzXFx1MjAwNFxcdTIwMDVcXHUyMDA2XFx1MjAwN1xcdTIwMDhcXHUyMDA5XFx1MjAwYVxcdTIwMmZcXHUyMDVmXFx1MzAwMFxcZCtcXHUyNzAwLVxcdTI3YmZhLXpcXHhkZi1cXHhmNlxceGY4LVxceGZmQS1aXFx4YzAtXFx4ZDZcXHhkOC1cXHhkZV0pfCQpfFtBLVpcXHhjMC1cXHhkNlxceGQ4LVxceGRlXT8oPzpbYS16XFx4ZGYtXFx4ZjZcXHhmOC1cXHhmZl18W15cXHVkODAwLVxcdWRmZmZcXHhhY1xceGIxXFx4ZDdcXHhmN1xceDAwLVxceDJmXFx4M2EtXFx4NDBcXHg1Yi1cXHg2MFxceDdiLVxceGJmXFx1MjAwMC1cXHUyMDZmIFxcdFxceDBiXFxmXFx4YTBcXHVmZWZmXFxuXFxyXFx1MjAyOFxcdTIwMjlcXHUxNjgwXFx1MTgwZVxcdTIwMDBcXHUyMDAxXFx1MjAwMlxcdTIwMDNcXHUyMDA0XFx1MjAwNVxcdTIwMDZcXHUyMDA3XFx1MjAwOFxcdTIwMDlcXHUyMDBhXFx1MjAyZlxcdTIwNWZcXHUzMDAwXFxkK1xcdTI3MDAtXFx1MjdiZmEtelxceGRmLVxceGY2XFx4ZjgtXFx4ZmZBLVpcXHhjMC1cXHhkNlxceGQ4LVxceGRlXSkrKD86WyfigJldKD86ZHxsbHxtfHJlfHN8dHx2ZSkpP3xbQS1aXFx4YzAtXFx4ZDZcXHhkOC1cXHhkZV0rKD86WyfigJldKD86RHxMTHxNfFJFfFN8VHxWRSkpP3xcXGQqKD86MVNUfDJORHwzUkR8KD8hWzEyM10pXFxkVEgpKD89XFxifFthLXpfXSl8XFxkKig/OjFzdHwybmR8M3JkfCg/IVsxMjNdKVxcZHRoKSg/PVxcYnxbQS1aX10pfFxcZCt8KD86W1xcdTI3MDAtXFx1MjdiZl18KD86XFx1ZDgzY1tcXHVkZGU2LVxcdWRkZmZdKXsyfXxbXFx1ZDgwMC1cXHVkYmZmXVtcXHVkYzAwLVxcdWRmZmZdKVtcXHVmZTBlXFx1ZmUwZl0/KD86W1xcdTAzMDAtXFx1MDM2ZlxcdWZlMjAtXFx1ZmUyZlxcdTIwZDAtXFx1MjBmZl18XFx1ZDgzY1tcXHVkZmZiLVxcdWRmZmZdKT8oPzpcXHUyMDBkKD86W15cXHVkODAwLVxcdWRmZmZdfCg/OlxcdWQ4M2NbXFx1ZGRlNi1cXHVkZGZmXSl7Mn18W1xcdWQ4MDAtXFx1ZGJmZl1bXFx1ZGMwMC1cXHVkZmZmXSlbXFx1ZmUwZVxcdWZlMGZdPyg/OltcXHUwMzAwLVxcdTAzNmZcXHVmZTIwLVxcdWZlMmZcXHUyMGQwLVxcdTIwZmZdfFxcdWQ4M2NbXFx1ZGZmYi1cXHVkZmZmXSk/KSovZ1xuXG5jb25zdCB3b3JkcyA9IChzdHIpID0+IHN0ci5tYXRjaChyZVdvcmRzKSB8fCBbXVxuXG5jb25zdCB1cHBlckZpcnN0ID0gKHN0cikgPT4gc3RyWzBdLnRvVXBwZXJDYXNlKCkgKyBzdHIuc2xpY2UoMSlcblxuY29uc3Qgam9pbiA9IChzdHIsIGQpID0+IHdvcmRzKHN0cikuam9pbihkKS50b0xvd2VyQ2FzZSgpXG5cbmNvbnN0IGNhbWVsQ2FzZSA9IChzdHIpID0+XG4gIHdvcmRzKHN0cikucmVkdWNlKFxuICAgIChhY2MsIG5leHQpID0+XG4gICAgICBgJHthY2N9JHtcbiAgICAgICAgIWFjY1xuICAgICAgICAgID8gbmV4dC50b0xvd2VyQ2FzZSgpXG4gICAgICAgICAgOiBuZXh0WzBdLnRvVXBwZXJDYXNlKCkgKyBuZXh0LnNsaWNlKDEpLnRvTG93ZXJDYXNlKClcbiAgICAgIH1gLFxuICAgICcnLFxuICApXG5cbmNvbnN0IHBhc2NhbENhc2UgPSAoc3RyKSA9PiB1cHBlckZpcnN0KGNhbWVsQ2FzZShzdHIpKVxuXG5jb25zdCBzbmFrZUNhc2UgPSAoc3RyKSA9PiBqb2luKHN0ciwgJ18nKVxuXG5jb25zdCBrZWJhYkNhc2UgPSAoc3RyKSA9PiBqb2luKHN0ciwgJy0nKVxuXG5jb25zdCBzZW50ZW5jZUNhc2UgPSAoc3RyKSA9PiB1cHBlckZpcnN0KGpvaW4oc3RyLCAnICcpKVxuXG5jb25zdCB0aXRsZUNhc2UgPSAoc3RyKSA9PiB3b3JkcyhzdHIpLm1hcCh1cHBlckZpcnN0KS5qb2luKCcgJylcblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gIHdvcmRzLFxuICB1cHBlckZpcnN0LFxuICBjYW1lbENhc2UsXG4gIHBhc2NhbENhc2UsXG4gIHNuYWtlQ2FzZSxcbiAga2ViYWJDYXNlLFxuICBzZW50ZW5jZUNhc2UsXG4gIHRpdGxlQ2FzZSxcbn1cbiIsIlxuLyoqXG4gKiBUb3BvbG9naWNhbCBzb3J0aW5nIGZ1bmN0aW9uXG4gKlxuICogQHBhcmFtIHtBcnJheX0gZWRnZXNcbiAqIEByZXR1cm5zIHtBcnJheX1cbiAqL1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uKGVkZ2VzKSB7XG4gIHJldHVybiB0b3Bvc29ydCh1bmlxdWVOb2RlcyhlZGdlcyksIGVkZ2VzKVxufVxuXG5tb2R1bGUuZXhwb3J0cy5hcnJheSA9IHRvcG9zb3J0XG5cbmZ1bmN0aW9uIHRvcG9zb3J0KG5vZGVzLCBlZGdlcykge1xuICB2YXIgY3Vyc29yID0gbm9kZXMubGVuZ3RoXG4gICAgLCBzb3J0ZWQgPSBuZXcgQXJyYXkoY3Vyc29yKVxuICAgICwgdmlzaXRlZCA9IHt9XG4gICAgLCBpID0gY3Vyc29yXG4gICAgLy8gQmV0dGVyIGRhdGEgc3RydWN0dXJlcyBtYWtlIGFsZ29yaXRobSBtdWNoIGZhc3Rlci5cbiAgICAsIG91dGdvaW5nRWRnZXMgPSBtYWtlT3V0Z29pbmdFZGdlcyhlZGdlcylcbiAgICAsIG5vZGVzSGFzaCA9IG1ha2VOb2Rlc0hhc2gobm9kZXMpXG5cbiAgLy8gY2hlY2sgZm9yIHVua25vd24gbm9kZXNcbiAgZWRnZXMuZm9yRWFjaChmdW5jdGlvbihlZGdlKSB7XG4gICAgaWYgKCFub2Rlc0hhc2guaGFzKGVkZ2VbMF0pIHx8ICFub2Rlc0hhc2guaGFzKGVkZ2VbMV0pKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ1Vua25vd24gbm9kZS4gVGhlcmUgaXMgYW4gdW5rbm93biBub2RlIGluIHRoZSBzdXBwbGllZCBlZGdlcy4nKVxuICAgIH1cbiAgfSlcblxuICB3aGlsZSAoaS0tKSB7XG4gICAgaWYgKCF2aXNpdGVkW2ldKSB2aXNpdChub2Rlc1tpXSwgaSwgbmV3IFNldCgpKVxuICB9XG5cbiAgcmV0dXJuIHNvcnRlZFxuXG4gIGZ1bmN0aW9uIHZpc2l0KG5vZGUsIGksIHByZWRlY2Vzc29ycykge1xuICAgIGlmKHByZWRlY2Vzc29ycy5oYXMobm9kZSkpIHtcbiAgICAgIHZhciBub2RlUmVwXG4gICAgICB0cnkge1xuICAgICAgICBub2RlUmVwID0gXCIsIG5vZGUgd2FzOlwiICsgSlNPTi5zdHJpbmdpZnkobm9kZSlcbiAgICAgIH0gY2F0Y2goZSkge1xuICAgICAgICBub2RlUmVwID0gXCJcIlxuICAgICAgfVxuICAgICAgdGhyb3cgbmV3IEVycm9yKCdDeWNsaWMgZGVwZW5kZW5jeScgKyBub2RlUmVwKVxuICAgIH1cblxuICAgIGlmICghbm9kZXNIYXNoLmhhcyhub2RlKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdGb3VuZCB1bmtub3duIG5vZGUuIE1ha2Ugc3VyZSB0byBwcm92aWRlZCBhbGwgaW52b2x2ZWQgbm9kZXMuIFVua25vd24gbm9kZTogJytKU09OLnN0cmluZ2lmeShub2RlKSlcbiAgICB9XG5cbiAgICBpZiAodmlzaXRlZFtpXSkgcmV0dXJuO1xuICAgIHZpc2l0ZWRbaV0gPSB0cnVlXG5cbiAgICB2YXIgb3V0Z29pbmcgPSBvdXRnb2luZ0VkZ2VzLmdldChub2RlKSB8fCBuZXcgU2V0KClcbiAgICBvdXRnb2luZyA9IEFycmF5LmZyb20ob3V0Z29pbmcpXG5cbiAgICBpZiAoaSA9IG91dGdvaW5nLmxlbmd0aCkge1xuICAgICAgcHJlZGVjZXNzb3JzLmFkZChub2RlKVxuICAgICAgZG8ge1xuICAgICAgICB2YXIgY2hpbGQgPSBvdXRnb2luZ1stLWldXG4gICAgICAgIHZpc2l0KGNoaWxkLCBub2Rlc0hhc2guZ2V0KGNoaWxkKSwgcHJlZGVjZXNzb3JzKVxuICAgICAgfSB3aGlsZSAoaSlcbiAgICAgIHByZWRlY2Vzc29ycy5kZWxldGUobm9kZSlcbiAgICB9XG5cbiAgICBzb3J0ZWRbLS1jdXJzb3JdID0gbm9kZVxuICB9XG59XG5cbmZ1bmN0aW9uIHVuaXF1ZU5vZGVzKGFycil7XG4gIHZhciByZXMgPSBuZXcgU2V0KClcbiAgZm9yICh2YXIgaSA9IDAsIGxlbiA9IGFyci5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgIHZhciBlZGdlID0gYXJyW2ldXG4gICAgcmVzLmFkZChlZGdlWzBdKVxuICAgIHJlcy5hZGQoZWRnZVsxXSlcbiAgfVxuICByZXR1cm4gQXJyYXkuZnJvbShyZXMpXG59XG5cbmZ1bmN0aW9uIG1ha2VPdXRnb2luZ0VkZ2VzKGFycil7XG4gIHZhciBlZGdlcyA9IG5ldyBNYXAoKVxuICBmb3IgKHZhciBpID0gMCwgbGVuID0gYXJyLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgdmFyIGVkZ2UgPSBhcnJbaV1cbiAgICBpZiAoIWVkZ2VzLmhhcyhlZGdlWzBdKSkgZWRnZXMuc2V0KGVkZ2VbMF0sIG5ldyBTZXQoKSlcbiAgICBpZiAoIWVkZ2VzLmhhcyhlZGdlWzFdKSkgZWRnZXMuc2V0KGVkZ2VbMV0sIG5ldyBTZXQoKSlcbiAgICBlZGdlcy5nZXQoZWRnZVswXSkuYWRkKGVkZ2VbMV0pXG4gIH1cbiAgcmV0dXJuIGVkZ2VzXG59XG5cbmZ1bmN0aW9uIG1ha2VOb2Rlc0hhc2goYXJyKXtcbiAgdmFyIHJlcyA9IG5ldyBNYXAoKVxuICBmb3IgKHZhciBpID0gMCwgbGVuID0gYXJyLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgcmVzLnNldChhcnJbaV0sIGkpXG4gIH1cbiAgcmV0dXJuIHJlc1xufVxuIiwiaW1wb3J0IHsgZ2V0dGVyLCBmb3JFYWNoLCBzcGxpdCwgbm9ybWFsaXplUGF0aCwgam9pbiB9IGZyb20gJ3Byb3BlcnR5LWV4cHInO1xuaW1wb3J0IHsgY2FtZWxDYXNlLCBzbmFrZUNhc2UgfSBmcm9tICd0aW55LWNhc2UnO1xuaW1wb3J0IHRvcG9zb3J0IGZyb20gJ3RvcG9zb3J0JztcblxuY29uc3QgdG9TdHJpbmcgPSBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nO1xuY29uc3QgZXJyb3JUb1N0cmluZyA9IEVycm9yLnByb3RvdHlwZS50b1N0cmluZztcbmNvbnN0IHJlZ0V4cFRvU3RyaW5nID0gUmVnRXhwLnByb3RvdHlwZS50b1N0cmluZztcbmNvbnN0IHN5bWJvbFRvU3RyaW5nID0gdHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgPyBTeW1ib2wucHJvdG90eXBlLnRvU3RyaW5nIDogKCkgPT4gJyc7XG5jb25zdCBTWU1CT0xfUkVHRVhQID0gL15TeW1ib2xcXCgoLiopXFwpKC4qKSQvO1xuZnVuY3Rpb24gcHJpbnROdW1iZXIodmFsKSB7XG4gIGlmICh2YWwgIT0gK3ZhbCkgcmV0dXJuICdOYU4nO1xuICBjb25zdCBpc05lZ2F0aXZlWmVybyA9IHZhbCA9PT0gMCAmJiAxIC8gdmFsIDwgMDtcbiAgcmV0dXJuIGlzTmVnYXRpdmVaZXJvID8gJy0wJyA6ICcnICsgdmFsO1xufVxuZnVuY3Rpb24gcHJpbnRTaW1wbGVWYWx1ZSh2YWwsIHF1b3RlU3RyaW5ncyA9IGZhbHNlKSB7XG4gIGlmICh2YWwgPT0gbnVsbCB8fCB2YWwgPT09IHRydWUgfHwgdmFsID09PSBmYWxzZSkgcmV0dXJuICcnICsgdmFsO1xuICBjb25zdCB0eXBlT2YgPSB0eXBlb2YgdmFsO1xuICBpZiAodHlwZU9mID09PSAnbnVtYmVyJykgcmV0dXJuIHByaW50TnVtYmVyKHZhbCk7XG4gIGlmICh0eXBlT2YgPT09ICdzdHJpbmcnKSByZXR1cm4gcXVvdGVTdHJpbmdzID8gYFwiJHt2YWx9XCJgIDogdmFsO1xuICBpZiAodHlwZU9mID09PSAnZnVuY3Rpb24nKSByZXR1cm4gJ1tGdW5jdGlvbiAnICsgKHZhbC5uYW1lIHx8ICdhbm9ueW1vdXMnKSArICddJztcbiAgaWYgKHR5cGVPZiA9PT0gJ3N5bWJvbCcpIHJldHVybiBzeW1ib2xUb1N0cmluZy5jYWxsKHZhbCkucmVwbGFjZShTWU1CT0xfUkVHRVhQLCAnU3ltYm9sKCQxKScpO1xuICBjb25zdCB0YWcgPSB0b1N0cmluZy5jYWxsKHZhbCkuc2xpY2UoOCwgLTEpO1xuICBpZiAodGFnID09PSAnRGF0ZScpIHJldHVybiBpc05hTih2YWwuZ2V0VGltZSgpKSA/ICcnICsgdmFsIDogdmFsLnRvSVNPU3RyaW5nKHZhbCk7XG4gIGlmICh0YWcgPT09ICdFcnJvcicgfHwgdmFsIGluc3RhbmNlb2YgRXJyb3IpIHJldHVybiAnWycgKyBlcnJvclRvU3RyaW5nLmNhbGwodmFsKSArICddJztcbiAgaWYgKHRhZyA9PT0gJ1JlZ0V4cCcpIHJldHVybiByZWdFeHBUb1N0cmluZy5jYWxsKHZhbCk7XG4gIHJldHVybiBudWxsO1xufVxuZnVuY3Rpb24gcHJpbnRWYWx1ZSh2YWx1ZSwgcXVvdGVTdHJpbmdzKSB7XG4gIGxldCByZXN1bHQgPSBwcmludFNpbXBsZVZhbHVlKHZhbHVlLCBxdW90ZVN0cmluZ3MpO1xuICBpZiAocmVzdWx0ICE9PSBudWxsKSByZXR1cm4gcmVzdWx0O1xuICByZXR1cm4gSlNPTi5zdHJpbmdpZnkodmFsdWUsIGZ1bmN0aW9uIChrZXksIHZhbHVlKSB7XG4gICAgbGV0IHJlc3VsdCA9IHByaW50U2ltcGxlVmFsdWUodGhpc1trZXldLCBxdW90ZVN0cmluZ3MpO1xuICAgIGlmIChyZXN1bHQgIT09IG51bGwpIHJldHVybiByZXN1bHQ7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9LCAyKTtcbn1cblxuZnVuY3Rpb24gdG9BcnJheSh2YWx1ZSkge1xuICByZXR1cm4gdmFsdWUgPT0gbnVsbCA/IFtdIDogW10uY29uY2F0KHZhbHVlKTtcbn1cblxubGV0IF9TeW1ib2wkdG9TdHJpbmdUYWcsIF9TeW1ib2wkaGFzSW5zdGFuY2UsIF9TeW1ib2wkdG9TdHJpbmdUYWcyO1xubGV0IHN0clJlZyA9IC9cXCRcXHtcXHMqKFxcdyspXFxzKlxcfS9nO1xuX1N5bWJvbCR0b1N0cmluZ1RhZyA9IFN5bWJvbC50b1N0cmluZ1RhZztcbmNsYXNzIFZhbGlkYXRpb25FcnJvck5vU3RhY2sge1xuICBjb25zdHJ1Y3RvcihlcnJvck9yRXJyb3JzLCB2YWx1ZSwgZmllbGQsIHR5cGUpIHtcbiAgICB0aGlzLm5hbWUgPSB2b2lkIDA7XG4gICAgdGhpcy5tZXNzYWdlID0gdm9pZCAwO1xuICAgIHRoaXMudmFsdWUgPSB2b2lkIDA7XG4gICAgdGhpcy5wYXRoID0gdm9pZCAwO1xuICAgIHRoaXMudHlwZSA9IHZvaWQgMDtcbiAgICB0aGlzLnBhcmFtcyA9IHZvaWQgMDtcbiAgICB0aGlzLmVycm9ycyA9IHZvaWQgMDtcbiAgICB0aGlzLmlubmVyID0gdm9pZCAwO1xuICAgIHRoaXNbX1N5bWJvbCR0b1N0cmluZ1RhZ10gPSAnRXJyb3InO1xuICAgIHRoaXMubmFtZSA9ICdWYWxpZGF0aW9uRXJyb3InO1xuICAgIHRoaXMudmFsdWUgPSB2YWx1ZTtcbiAgICB0aGlzLnBhdGggPSBmaWVsZDtcbiAgICB0aGlzLnR5cGUgPSB0eXBlO1xuICAgIHRoaXMuZXJyb3JzID0gW107XG4gICAgdGhpcy5pbm5lciA9IFtdO1xuICAgIHRvQXJyYXkoZXJyb3JPckVycm9ycykuZm9yRWFjaChlcnIgPT4ge1xuICAgICAgaWYgKFZhbGlkYXRpb25FcnJvci5pc0Vycm9yKGVycikpIHtcbiAgICAgICAgdGhpcy5lcnJvcnMucHVzaCguLi5lcnIuZXJyb3JzKTtcbiAgICAgICAgY29uc3QgaW5uZXJFcnJvcnMgPSBlcnIuaW5uZXIubGVuZ3RoID8gZXJyLmlubmVyIDogW2Vycl07XG4gICAgICAgIHRoaXMuaW5uZXIucHVzaCguLi5pbm5lckVycm9ycyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLmVycm9ycy5wdXNoKGVycik7XG4gICAgICB9XG4gICAgfSk7XG4gICAgdGhpcy5tZXNzYWdlID0gdGhpcy5lcnJvcnMubGVuZ3RoID4gMSA/IGAke3RoaXMuZXJyb3JzLmxlbmd0aH0gZXJyb3JzIG9jY3VycmVkYCA6IHRoaXMuZXJyb3JzWzBdO1xuICB9XG59XG5fU3ltYm9sJGhhc0luc3RhbmNlID0gU3ltYm9sLmhhc0luc3RhbmNlO1xuX1N5bWJvbCR0b1N0cmluZ1RhZzIgPSBTeW1ib2wudG9TdHJpbmdUYWc7XG5jbGFzcyBWYWxpZGF0aW9uRXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIHN0YXRpYyBmb3JtYXRFcnJvcihtZXNzYWdlLCBwYXJhbXMpIHtcbiAgICAvLyBBdHRlbXB0IHRvIG1ha2UgdGhlIHBhdGggbW9yZSBmcmllbmRseSBmb3IgZXJyb3IgbWVzc2FnZSBpbnRlcnBvbGF0aW9uLlxuICAgIGNvbnN0IHBhdGggPSBwYXJhbXMubGFiZWwgfHwgcGFyYW1zLnBhdGggfHwgJ3RoaXMnO1xuICAgIC8vIFN0b3JlIHRoZSBvcmlnaW5hbCBwYXRoIHVuZGVyIGBvcmlnaW5hbFBhdGhgIHNvIGl0IGlzbid0IGxvc3QgdG8gY3VzdG9tXG4gICAgLy8gbWVzc2FnZSBmdW5jdGlvbnM7IGUuZy4sIG9uZXMgcHJvdmlkZWQgaW4gYHNldExvY2FsZSgpYCBjYWxscy5cbiAgICBwYXJhbXMgPSBPYmplY3QuYXNzaWduKHt9LCBwYXJhbXMsIHtcbiAgICAgIHBhdGgsXG4gICAgICBvcmlnaW5hbFBhdGg6IHBhcmFtcy5wYXRoXG4gICAgfSk7XG4gICAgaWYgKHR5cGVvZiBtZXNzYWdlID09PSAnc3RyaW5nJykgcmV0dXJuIG1lc3NhZ2UucmVwbGFjZShzdHJSZWcsIChfLCBrZXkpID0+IHByaW50VmFsdWUocGFyYW1zW2tleV0pKTtcbiAgICBpZiAodHlwZW9mIG1lc3NhZ2UgPT09ICdmdW5jdGlvbicpIHJldHVybiBtZXNzYWdlKHBhcmFtcyk7XG4gICAgcmV0dXJuIG1lc3NhZ2U7XG4gIH1cbiAgc3RhdGljIGlzRXJyb3IoZXJyKSB7XG4gICAgcmV0dXJuIGVyciAmJiBlcnIubmFtZSA9PT0gJ1ZhbGlkYXRpb25FcnJvcic7XG4gIH1cbiAgY29uc3RydWN0b3IoZXJyb3JPckVycm9ycywgdmFsdWUsIGZpZWxkLCB0eXBlLCBkaXNhYmxlU3RhY2spIHtcbiAgICBjb25zdCBlcnJvck5vU3RhY2sgPSBuZXcgVmFsaWRhdGlvbkVycm9yTm9TdGFjayhlcnJvck9yRXJyb3JzLCB2YWx1ZSwgZmllbGQsIHR5cGUpO1xuICAgIGlmIChkaXNhYmxlU3RhY2spIHtcbiAgICAgIHJldHVybiBlcnJvck5vU3RhY2s7XG4gICAgfVxuICAgIHN1cGVyKCk7XG4gICAgdGhpcy52YWx1ZSA9IHZvaWQgMDtcbiAgICB0aGlzLnBhdGggPSB2b2lkIDA7XG4gICAgdGhpcy50eXBlID0gdm9pZCAwO1xuICAgIHRoaXMucGFyYW1zID0gdm9pZCAwO1xuICAgIHRoaXMuZXJyb3JzID0gW107XG4gICAgdGhpcy5pbm5lciA9IFtdO1xuICAgIHRoaXNbX1N5bWJvbCR0b1N0cmluZ1RhZzJdID0gJ0Vycm9yJztcbiAgICB0aGlzLm5hbWUgPSBlcnJvck5vU3RhY2submFtZTtcbiAgICB0aGlzLm1lc3NhZ2UgPSBlcnJvck5vU3RhY2subWVzc2FnZTtcbiAgICB0aGlzLnR5cGUgPSBlcnJvck5vU3RhY2sudHlwZTtcbiAgICB0aGlzLnZhbHVlID0gZXJyb3JOb1N0YWNrLnZhbHVlO1xuICAgIHRoaXMucGF0aCA9IGVycm9yTm9TdGFjay5wYXRoO1xuICAgIHRoaXMuZXJyb3JzID0gZXJyb3JOb1N0YWNrLmVycm9ycztcbiAgICB0aGlzLmlubmVyID0gZXJyb3JOb1N0YWNrLmlubmVyO1xuICAgIGlmIChFcnJvci5jYXB0dXJlU3RhY2tUcmFjZSkge1xuICAgICAgRXJyb3IuY2FwdHVyZVN0YWNrVHJhY2UodGhpcywgVmFsaWRhdGlvbkVycm9yKTtcbiAgICB9XG4gIH1cbiAgc3RhdGljIFtfU3ltYm9sJGhhc0luc3RhbmNlXShpbnN0KSB7XG4gICAgcmV0dXJuIFZhbGlkYXRpb25FcnJvck5vU3RhY2tbU3ltYm9sLmhhc0luc3RhbmNlXShpbnN0KSB8fCBzdXBlcltTeW1ib2wuaGFzSW5zdGFuY2VdKGluc3QpO1xuICB9XG59XG5cbmxldCBtaXhlZCA9IHtcbiAgZGVmYXVsdDogJyR7cGF0aH0gaXMgaW52YWxpZCcsXG4gIHJlcXVpcmVkOiAnJHtwYXRofSBpcyBhIHJlcXVpcmVkIGZpZWxkJyxcbiAgZGVmaW5lZDogJyR7cGF0aH0gbXVzdCBiZSBkZWZpbmVkJyxcbiAgbm90TnVsbDogJyR7cGF0aH0gY2Fubm90IGJlIG51bGwnLFxuICBvbmVPZjogJyR7cGF0aH0gbXVzdCBiZSBvbmUgb2YgdGhlIGZvbGxvd2luZyB2YWx1ZXM6ICR7dmFsdWVzfScsXG4gIG5vdE9uZU9mOiAnJHtwYXRofSBtdXN0IG5vdCBiZSBvbmUgb2YgdGhlIGZvbGxvd2luZyB2YWx1ZXM6ICR7dmFsdWVzfScsXG4gIG5vdFR5cGU6ICh7XG4gICAgcGF0aCxcbiAgICB0eXBlLFxuICAgIHZhbHVlLFxuICAgIG9yaWdpbmFsVmFsdWVcbiAgfSkgPT4ge1xuICAgIGNvbnN0IGNhc3RNc2cgPSBvcmlnaW5hbFZhbHVlICE9IG51bGwgJiYgb3JpZ2luYWxWYWx1ZSAhPT0gdmFsdWUgPyBgIChjYXN0IGZyb20gdGhlIHZhbHVlIFxcYCR7cHJpbnRWYWx1ZShvcmlnaW5hbFZhbHVlLCB0cnVlKX1cXGApLmAgOiAnLic7XG4gICAgcmV0dXJuIHR5cGUgIT09ICdtaXhlZCcgPyBgJHtwYXRofSBtdXN0IGJlIGEgXFxgJHt0eXBlfVxcYCB0eXBlLCBgICsgYGJ1dCB0aGUgZmluYWwgdmFsdWUgd2FzOiBcXGAke3ByaW50VmFsdWUodmFsdWUsIHRydWUpfVxcYGAgKyBjYXN0TXNnIDogYCR7cGF0aH0gbXVzdCBtYXRjaCB0aGUgY29uZmlndXJlZCB0eXBlLiBgICsgYFRoZSB2YWxpZGF0ZWQgdmFsdWUgd2FzOiBcXGAke3ByaW50VmFsdWUodmFsdWUsIHRydWUpfVxcYGAgKyBjYXN0TXNnO1xuICB9XG59O1xubGV0IHN0cmluZyA9IHtcbiAgbGVuZ3RoOiAnJHtwYXRofSBtdXN0IGJlIGV4YWN0bHkgJHtsZW5ndGh9IGNoYXJhY3RlcnMnLFxuICBtaW46ICcke3BhdGh9IG11c3QgYmUgYXQgbGVhc3QgJHttaW59IGNoYXJhY3RlcnMnLFxuICBtYXg6ICcke3BhdGh9IG11c3QgYmUgYXQgbW9zdCAke21heH0gY2hhcmFjdGVycycsXG4gIG1hdGNoZXM6ICcke3BhdGh9IG11c3QgbWF0Y2ggdGhlIGZvbGxvd2luZzogXCIke3JlZ2V4fVwiJyxcbiAgZW1haWw6ICcke3BhdGh9IG11c3QgYmUgYSB2YWxpZCBlbWFpbCcsXG4gIHVybDogJyR7cGF0aH0gbXVzdCBiZSBhIHZhbGlkIFVSTCcsXG4gIHV1aWQ6ICcke3BhdGh9IG11c3QgYmUgYSB2YWxpZCBVVUlEJyxcbiAgZGF0ZXRpbWU6ICcke3BhdGh9IG11c3QgYmUgYSB2YWxpZCBJU08gZGF0ZS10aW1lJyxcbiAgZGF0ZXRpbWVfcHJlY2lzaW9uOiAnJHtwYXRofSBtdXN0IGJlIGEgdmFsaWQgSVNPIGRhdGUtdGltZSB3aXRoIGEgc3ViLXNlY29uZCBwcmVjaXNpb24gb2YgZXhhY3RseSAke3ByZWNpc2lvbn0gZGlnaXRzJyxcbiAgZGF0ZXRpbWVfb2Zmc2V0OiAnJHtwYXRofSBtdXN0IGJlIGEgdmFsaWQgSVNPIGRhdGUtdGltZSB3aXRoIFVUQyBcIlpcIiB0aW1lem9uZScsXG4gIHRyaW06ICcke3BhdGh9IG11c3QgYmUgYSB0cmltbWVkIHN0cmluZycsXG4gIGxvd2VyY2FzZTogJyR7cGF0aH0gbXVzdCBiZSBhIGxvd2VyY2FzZSBzdHJpbmcnLFxuICB1cHBlcmNhc2U6ICcke3BhdGh9IG11c3QgYmUgYSB1cHBlciBjYXNlIHN0cmluZydcbn07XG5sZXQgbnVtYmVyID0ge1xuICBtaW46ICcke3BhdGh9IG11c3QgYmUgZ3JlYXRlciB0aGFuIG9yIGVxdWFsIHRvICR7bWlufScsXG4gIG1heDogJyR7cGF0aH0gbXVzdCBiZSBsZXNzIHRoYW4gb3IgZXF1YWwgdG8gJHttYXh9JyxcbiAgbGVzc1RoYW46ICcke3BhdGh9IG11c3QgYmUgbGVzcyB0aGFuICR7bGVzc30nLFxuICBtb3JlVGhhbjogJyR7cGF0aH0gbXVzdCBiZSBncmVhdGVyIHRoYW4gJHttb3JlfScsXG4gIHBvc2l0aXZlOiAnJHtwYXRofSBtdXN0IGJlIGEgcG9zaXRpdmUgbnVtYmVyJyxcbiAgbmVnYXRpdmU6ICcke3BhdGh9IG11c3QgYmUgYSBuZWdhdGl2ZSBudW1iZXInLFxuICBpbnRlZ2VyOiAnJHtwYXRofSBtdXN0IGJlIGFuIGludGVnZXInXG59O1xubGV0IGRhdGUgPSB7XG4gIG1pbjogJyR7cGF0aH0gZmllbGQgbXVzdCBiZSBsYXRlciB0aGFuICR7bWlufScsXG4gIG1heDogJyR7cGF0aH0gZmllbGQgbXVzdCBiZSBhdCBlYXJsaWVyIHRoYW4gJHttYXh9J1xufTtcbmxldCBib29sZWFuID0ge1xuICBpc1ZhbHVlOiAnJHtwYXRofSBmaWVsZCBtdXN0IGJlICR7dmFsdWV9J1xufTtcbmxldCBvYmplY3QgPSB7XG4gIG5vVW5rbm93bjogJyR7cGF0aH0gZmllbGQgaGFzIHVuc3BlY2lmaWVkIGtleXM6ICR7dW5rbm93bn0nLFxuICBleGFjdDogJyR7cGF0aH0gb2JqZWN0IGNvbnRhaW5zIHVua25vd24gcHJvcGVydGllczogJHtwcm9wZXJ0aWVzfSdcbn07XG5sZXQgYXJyYXkgPSB7XG4gIG1pbjogJyR7cGF0aH0gZmllbGQgbXVzdCBoYXZlIGF0IGxlYXN0ICR7bWlufSBpdGVtcycsXG4gIG1heDogJyR7cGF0aH0gZmllbGQgbXVzdCBoYXZlIGxlc3MgdGhhbiBvciBlcXVhbCB0byAke21heH0gaXRlbXMnLFxuICBsZW5ndGg6ICcke3BhdGh9IG11c3QgaGF2ZSAke2xlbmd0aH0gaXRlbXMnXG59O1xubGV0IHR1cGxlID0ge1xuICBub3RUeXBlOiBwYXJhbXMgPT4ge1xuICAgIGNvbnN0IHtcbiAgICAgIHBhdGgsXG4gICAgICB2YWx1ZSxcbiAgICAgIHNwZWNcbiAgICB9ID0gcGFyYW1zO1xuICAgIGNvbnN0IHR5cGVMZW4gPSBzcGVjLnR5cGVzLmxlbmd0aDtcbiAgICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgIGlmICh2YWx1ZS5sZW5ndGggPCB0eXBlTGVuKSByZXR1cm4gYCR7cGF0aH0gdHVwbGUgdmFsdWUgaGFzIHRvbyBmZXcgaXRlbXMsIGV4cGVjdGVkIGEgbGVuZ3RoIG9mICR7dHlwZUxlbn0gYnV0IGdvdCAke3ZhbHVlLmxlbmd0aH0gZm9yIHZhbHVlOiBcXGAke3ByaW50VmFsdWUodmFsdWUsIHRydWUpfVxcYGA7XG4gICAgICBpZiAodmFsdWUubGVuZ3RoID4gdHlwZUxlbikgcmV0dXJuIGAke3BhdGh9IHR1cGxlIHZhbHVlIGhhcyB0b28gbWFueSBpdGVtcywgZXhwZWN0ZWQgYSBsZW5ndGggb2YgJHt0eXBlTGVufSBidXQgZ290ICR7dmFsdWUubGVuZ3RofSBmb3IgdmFsdWU6IFxcYCR7cHJpbnRWYWx1ZSh2YWx1ZSwgdHJ1ZSl9XFxgYDtcbiAgICB9XG4gICAgcmV0dXJuIFZhbGlkYXRpb25FcnJvci5mb3JtYXRFcnJvcihtaXhlZC5ub3RUeXBlLCBwYXJhbXMpO1xuICB9XG59O1xudmFyIGxvY2FsZSA9IE9iamVjdC5hc3NpZ24oT2JqZWN0LmNyZWF0ZShudWxsKSwge1xuICBtaXhlZCxcbiAgc3RyaW5nLFxuICBudW1iZXIsXG4gIGRhdGUsXG4gIG9iamVjdCxcbiAgYXJyYXksXG4gIGJvb2xlYW4sXG4gIHR1cGxlXG59KTtcblxuY29uc3QgaXNTY2hlbWEgPSBvYmogPT4gb2JqICYmIG9iai5fX2lzWXVwU2NoZW1hX187XG5cbmNsYXNzIENvbmRpdGlvbiB7XG4gIHN0YXRpYyBmcm9tT3B0aW9ucyhyZWZzLCBjb25maWcpIHtcbiAgICBpZiAoIWNvbmZpZy50aGVuICYmICFjb25maWcub3RoZXJ3aXNlKSB0aHJvdyBuZXcgVHlwZUVycm9yKCdlaXRoZXIgYHRoZW46YCBvciBgb3RoZXJ3aXNlOmAgaXMgcmVxdWlyZWQgZm9yIGB3aGVuKClgIGNvbmRpdGlvbnMnKTtcbiAgICBsZXQge1xuICAgICAgaXMsXG4gICAgICB0aGVuLFxuICAgICAgb3RoZXJ3aXNlXG4gICAgfSA9IGNvbmZpZztcbiAgICBsZXQgY2hlY2sgPSB0eXBlb2YgaXMgPT09ICdmdW5jdGlvbicgPyBpcyA6ICguLi52YWx1ZXMpID0+IHZhbHVlcy5ldmVyeSh2YWx1ZSA9PiB2YWx1ZSA9PT0gaXMpO1xuICAgIHJldHVybiBuZXcgQ29uZGl0aW9uKHJlZnMsICh2YWx1ZXMsIHNjaGVtYSkgPT4ge1xuICAgICAgdmFyIF9icmFuY2g7XG4gICAgICBsZXQgYnJhbmNoID0gY2hlY2soLi4udmFsdWVzKSA/IHRoZW4gOiBvdGhlcndpc2U7XG4gICAgICByZXR1cm4gKF9icmFuY2ggPSBicmFuY2ggPT0gbnVsbCA/IHZvaWQgMCA6IGJyYW5jaChzY2hlbWEpKSAhPSBudWxsID8gX2JyYW5jaCA6IHNjaGVtYTtcbiAgICB9KTtcbiAgfVxuICBjb25zdHJ1Y3RvcihyZWZzLCBidWlsZGVyKSB7XG4gICAgdGhpcy5mbiA9IHZvaWQgMDtcbiAgICB0aGlzLnJlZnMgPSByZWZzO1xuICAgIHRoaXMucmVmcyA9IHJlZnM7XG4gICAgdGhpcy5mbiA9IGJ1aWxkZXI7XG4gIH1cbiAgcmVzb2x2ZShiYXNlLCBvcHRpb25zKSB7XG4gICAgbGV0IHZhbHVlcyA9IHRoaXMucmVmcy5tYXAocmVmID0+XG4gICAgLy8gVE9ETzogPyBvcGVyYXRvciBoZXJlP1xuICAgIHJlZi5nZXRWYWx1ZShvcHRpb25zID09IG51bGwgPyB2b2lkIDAgOiBvcHRpb25zLnZhbHVlLCBvcHRpb25zID09IG51bGwgPyB2b2lkIDAgOiBvcHRpb25zLnBhcmVudCwgb3B0aW9ucyA9PSBudWxsID8gdm9pZCAwIDogb3B0aW9ucy5jb250ZXh0KSk7XG4gICAgbGV0IHNjaGVtYSA9IHRoaXMuZm4odmFsdWVzLCBiYXNlLCBvcHRpb25zKTtcbiAgICBpZiAoc2NoZW1hID09PSB1bmRlZmluZWQgfHxcbiAgICAvLyBAdHMtaWdub3JlIHRoaXMgY2FuIGJlIGJhc2VcbiAgICBzY2hlbWEgPT09IGJhc2UpIHtcbiAgICAgIHJldHVybiBiYXNlO1xuICAgIH1cbiAgICBpZiAoIWlzU2NoZW1hKHNjaGVtYSkpIHRocm93IG5ldyBUeXBlRXJyb3IoJ2NvbmRpdGlvbnMgbXVzdCByZXR1cm4gYSBzY2hlbWEgb2JqZWN0Jyk7XG4gICAgcmV0dXJuIHNjaGVtYS5yZXNvbHZlKG9wdGlvbnMpO1xuICB9XG59XG5cbmNvbnN0IHByZWZpeGVzID0ge1xuICBjb250ZXh0OiAnJCcsXG4gIHZhbHVlOiAnLidcbn07XG5mdW5jdGlvbiBjcmVhdGUkOShrZXksIG9wdGlvbnMpIHtcbiAgcmV0dXJuIG5ldyBSZWZlcmVuY2Uoa2V5LCBvcHRpb25zKTtcbn1cbmNsYXNzIFJlZmVyZW5jZSB7XG4gIGNvbnN0cnVjdG9yKGtleSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgdGhpcy5rZXkgPSB2b2lkIDA7XG4gICAgdGhpcy5pc0NvbnRleHQgPSB2b2lkIDA7XG4gICAgdGhpcy5pc1ZhbHVlID0gdm9pZCAwO1xuICAgIHRoaXMuaXNTaWJsaW5nID0gdm9pZCAwO1xuICAgIHRoaXMucGF0aCA9IHZvaWQgMDtcbiAgICB0aGlzLmdldHRlciA9IHZvaWQgMDtcbiAgICB0aGlzLm1hcCA9IHZvaWQgMDtcbiAgICBpZiAodHlwZW9mIGtleSAhPT0gJ3N0cmluZycpIHRocm93IG5ldyBUeXBlRXJyb3IoJ3JlZiBtdXN0IGJlIGEgc3RyaW5nLCBnb3Q6ICcgKyBrZXkpO1xuICAgIHRoaXMua2V5ID0ga2V5LnRyaW0oKTtcbiAgICBpZiAoa2V5ID09PSAnJykgdGhyb3cgbmV3IFR5cGVFcnJvcigncmVmIG11c3QgYmUgYSBub24tZW1wdHkgc3RyaW5nJyk7XG4gICAgdGhpcy5pc0NvbnRleHQgPSB0aGlzLmtleVswXSA9PT0gcHJlZml4ZXMuY29udGV4dDtcbiAgICB0aGlzLmlzVmFsdWUgPSB0aGlzLmtleVswXSA9PT0gcHJlZml4ZXMudmFsdWU7XG4gICAgdGhpcy5pc1NpYmxpbmcgPSAhdGhpcy5pc0NvbnRleHQgJiYgIXRoaXMuaXNWYWx1ZTtcbiAgICBsZXQgcHJlZml4ID0gdGhpcy5pc0NvbnRleHQgPyBwcmVmaXhlcy5jb250ZXh0IDogdGhpcy5pc1ZhbHVlID8gcHJlZml4ZXMudmFsdWUgOiAnJztcbiAgICB0aGlzLnBhdGggPSB0aGlzLmtleS5zbGljZShwcmVmaXgubGVuZ3RoKTtcbiAgICB0aGlzLmdldHRlciA9IHRoaXMucGF0aCAmJiBnZXR0ZXIodGhpcy5wYXRoLCB0cnVlKTtcbiAgICB0aGlzLm1hcCA9IG9wdGlvbnMubWFwO1xuICB9XG4gIGdldFZhbHVlKHZhbHVlLCBwYXJlbnQsIGNvbnRleHQpIHtcbiAgICBsZXQgcmVzdWx0ID0gdGhpcy5pc0NvbnRleHQgPyBjb250ZXh0IDogdGhpcy5pc1ZhbHVlID8gdmFsdWUgOiBwYXJlbnQ7XG4gICAgaWYgKHRoaXMuZ2V0dGVyKSByZXN1bHQgPSB0aGlzLmdldHRlcihyZXN1bHQgfHwge30pO1xuICAgIGlmICh0aGlzLm1hcCkgcmVzdWx0ID0gdGhpcy5tYXAocmVzdWx0KTtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqIEBwYXJhbSB7Kn0gdmFsdWVcbiAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnNcbiAgICogQHBhcmFtIHtPYmplY3Q9fSBvcHRpb25zLmNvbnRleHRcbiAgICogQHBhcmFtIHtPYmplY3Q9fSBvcHRpb25zLnBhcmVudFxuICAgKi9cbiAgY2FzdCh2YWx1ZSwgb3B0aW9ucykge1xuICAgIHJldHVybiB0aGlzLmdldFZhbHVlKHZhbHVlLCBvcHRpb25zID09IG51bGwgPyB2b2lkIDAgOiBvcHRpb25zLnBhcmVudCwgb3B0aW9ucyA9PSBudWxsID8gdm9pZCAwIDogb3B0aW9ucy5jb250ZXh0KTtcbiAgfVxuICByZXNvbHZlKCkge1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIGRlc2NyaWJlKCkge1xuICAgIHJldHVybiB7XG4gICAgICB0eXBlOiAncmVmJyxcbiAgICAgIGtleTogdGhpcy5rZXlcbiAgICB9O1xuICB9XG4gIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiBgUmVmKCR7dGhpcy5rZXl9KWA7XG4gIH1cbiAgc3RhdGljIGlzUmVmKHZhbHVlKSB7XG4gICAgcmV0dXJuIHZhbHVlICYmIHZhbHVlLl9faXNZdXBSZWY7XG4gIH1cbn1cblxuLy8gQHRzLWlnbm9yZVxuUmVmZXJlbmNlLnByb3RvdHlwZS5fX2lzWXVwUmVmID0gdHJ1ZTtcblxuY29uc3QgaXNBYnNlbnQgPSB2YWx1ZSA9PiB2YWx1ZSA9PSBudWxsO1xuXG5mdW5jdGlvbiBjcmVhdGVWYWxpZGF0aW9uKGNvbmZpZykge1xuICBmdW5jdGlvbiB2YWxpZGF0ZSh7XG4gICAgdmFsdWUsXG4gICAgcGF0aCA9ICcnLFxuICAgIG9wdGlvbnMsXG4gICAgb3JpZ2luYWxWYWx1ZSxcbiAgICBzY2hlbWFcbiAgfSwgcGFuaWMsIG5leHQpIHtcbiAgICBjb25zdCB7XG4gICAgICBuYW1lLFxuICAgICAgdGVzdCxcbiAgICAgIHBhcmFtcyxcbiAgICAgIG1lc3NhZ2UsXG4gICAgICBza2lwQWJzZW50XG4gICAgfSA9IGNvbmZpZztcbiAgICBsZXQge1xuICAgICAgcGFyZW50LFxuICAgICAgY29udGV4dCxcbiAgICAgIGFib3J0RWFybHkgPSBzY2hlbWEuc3BlYy5hYm9ydEVhcmx5LFxuICAgICAgZGlzYWJsZVN0YWNrVHJhY2UgPSBzY2hlbWEuc3BlYy5kaXNhYmxlU3RhY2tUcmFjZVxuICAgIH0gPSBvcHRpb25zO1xuICAgIGNvbnN0IHJlc29sdmVPcHRpb25zID0ge1xuICAgICAgdmFsdWUsXG4gICAgICBwYXJlbnQsXG4gICAgICBjb250ZXh0XG4gICAgfTtcbiAgICBmdW5jdGlvbiBjcmVhdGVFcnJvcihvdmVycmlkZXMgPSB7fSkge1xuICAgICAgY29uc3QgbmV4dFBhcmFtcyA9IHJlc29sdmVQYXJhbXMoT2JqZWN0LmFzc2lnbih7XG4gICAgICAgIHZhbHVlLFxuICAgICAgICBvcmlnaW5hbFZhbHVlLFxuICAgICAgICBsYWJlbDogc2NoZW1hLnNwZWMubGFiZWwsXG4gICAgICAgIHBhdGg6IG92ZXJyaWRlcy5wYXRoIHx8IHBhdGgsXG4gICAgICAgIHNwZWM6IHNjaGVtYS5zcGVjLFxuICAgICAgICBkaXNhYmxlU3RhY2tUcmFjZTogb3ZlcnJpZGVzLmRpc2FibGVTdGFja1RyYWNlIHx8IGRpc2FibGVTdGFja1RyYWNlXG4gICAgICB9LCBwYXJhbXMsIG92ZXJyaWRlcy5wYXJhbXMpLCByZXNvbHZlT3B0aW9ucyk7XG4gICAgICBjb25zdCBlcnJvciA9IG5ldyBWYWxpZGF0aW9uRXJyb3IoVmFsaWRhdGlvbkVycm9yLmZvcm1hdEVycm9yKG92ZXJyaWRlcy5tZXNzYWdlIHx8IG1lc3NhZ2UsIG5leHRQYXJhbXMpLCB2YWx1ZSwgbmV4dFBhcmFtcy5wYXRoLCBvdmVycmlkZXMudHlwZSB8fCBuYW1lLCBuZXh0UGFyYW1zLmRpc2FibGVTdGFja1RyYWNlKTtcbiAgICAgIGVycm9yLnBhcmFtcyA9IG5leHRQYXJhbXM7XG4gICAgICByZXR1cm4gZXJyb3I7XG4gICAgfVxuICAgIGNvbnN0IGludmFsaWQgPSBhYm9ydEVhcmx5ID8gcGFuaWMgOiBuZXh0O1xuICAgIGxldCBjdHggPSB7XG4gICAgICBwYXRoLFxuICAgICAgcGFyZW50LFxuICAgICAgdHlwZTogbmFtZSxcbiAgICAgIGZyb206IG9wdGlvbnMuZnJvbSxcbiAgICAgIGNyZWF0ZUVycm9yLFxuICAgICAgcmVzb2x2ZShpdGVtKSB7XG4gICAgICAgIHJldHVybiByZXNvbHZlTWF5YmVSZWYoaXRlbSwgcmVzb2x2ZU9wdGlvbnMpO1xuICAgICAgfSxcbiAgICAgIG9wdGlvbnMsXG4gICAgICBvcmlnaW5hbFZhbHVlLFxuICAgICAgc2NoZW1hXG4gICAgfTtcbiAgICBjb25zdCBoYW5kbGVSZXN1bHQgPSB2YWxpZE9yRXJyb3IgPT4ge1xuICAgICAgaWYgKFZhbGlkYXRpb25FcnJvci5pc0Vycm9yKHZhbGlkT3JFcnJvcikpIGludmFsaWQodmFsaWRPckVycm9yKTtlbHNlIGlmICghdmFsaWRPckVycm9yKSBpbnZhbGlkKGNyZWF0ZUVycm9yKCkpO2Vsc2UgbmV4dChudWxsKTtcbiAgICB9O1xuICAgIGNvbnN0IGhhbmRsZUVycm9yID0gZXJyID0+IHtcbiAgICAgIGlmIChWYWxpZGF0aW9uRXJyb3IuaXNFcnJvcihlcnIpKSBpbnZhbGlkKGVycik7ZWxzZSBwYW5pYyhlcnIpO1xuICAgIH07XG4gICAgY29uc3Qgc2hvdWxkU2tpcCA9IHNraXBBYnNlbnQgJiYgaXNBYnNlbnQodmFsdWUpO1xuICAgIGlmIChzaG91bGRTa2lwKSB7XG4gICAgICByZXR1cm4gaGFuZGxlUmVzdWx0KHRydWUpO1xuICAgIH1cbiAgICBsZXQgcmVzdWx0O1xuICAgIHRyeSB7XG4gICAgICB2YXIgX3Jlc3VsdDtcbiAgICAgIHJlc3VsdCA9IHRlc3QuY2FsbChjdHgsIHZhbHVlLCBjdHgpO1xuICAgICAgaWYgKHR5cGVvZiAoKF9yZXN1bHQgPSByZXN1bHQpID09IG51bGwgPyB2b2lkIDAgOiBfcmVzdWx0LnRoZW4pID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIGlmIChvcHRpb25zLnN5bmMpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFZhbGlkYXRpb24gdGVzdCBvZiB0eXBlOiBcIiR7Y3R4LnR5cGV9XCIgcmV0dXJuZWQgYSBQcm9taXNlIGR1cmluZyBhIHN5bmNocm9ub3VzIHZhbGlkYXRlLiBgICsgYFRoaXMgdGVzdCB3aWxsIGZpbmlzaCBhZnRlciB0aGUgdmFsaWRhdGUgY2FsbCBoYXMgcmV0dXJuZWRgKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHJlc3VsdCkudGhlbihoYW5kbGVSZXN1bHQsIGhhbmRsZUVycm9yKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGhhbmRsZUVycm9yKGVycik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGhhbmRsZVJlc3VsdChyZXN1bHQpO1xuICB9XG4gIHZhbGlkYXRlLk9QVElPTlMgPSBjb25maWc7XG4gIHJldHVybiB2YWxpZGF0ZTtcbn1cblxuLy8gV2FybmluZzogbXV0YXRlcyB0aGUgaW5wdXRcbmZ1bmN0aW9uIHJlc29sdmVQYXJhbXMocGFyYW1zLCBvcHRpb25zKSB7XG4gIGlmICghcGFyYW1zKSByZXR1cm4gcGFyYW1zO1xuICBmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhwYXJhbXMpKSB7XG4gICAgcGFyYW1zW2tleV0gPSByZXNvbHZlTWF5YmVSZWYocGFyYW1zW2tleV0sIG9wdGlvbnMpO1xuICB9XG4gIHJldHVybiBwYXJhbXM7XG59XG5mdW5jdGlvbiByZXNvbHZlTWF5YmVSZWYoaXRlbSwgb3B0aW9ucykge1xuICByZXR1cm4gUmVmZXJlbmNlLmlzUmVmKGl0ZW0pID8gaXRlbS5nZXRWYWx1ZShvcHRpb25zLnZhbHVlLCBvcHRpb25zLnBhcmVudCwgb3B0aW9ucy5jb250ZXh0KSA6IGl0ZW07XG59XG5cbmZ1bmN0aW9uIGdldEluKHNjaGVtYSwgcGF0aCwgdmFsdWUsIGNvbnRleHQgPSB2YWx1ZSkge1xuICBsZXQgcGFyZW50LCBsYXN0UGFydCwgbGFzdFBhcnREZWJ1ZztcblxuICAvLyByb290IHBhdGg6ICcnXG4gIGlmICghcGF0aCkgcmV0dXJuIHtcbiAgICBwYXJlbnQsXG4gICAgcGFyZW50UGF0aDogcGF0aCxcbiAgICBzY2hlbWFcbiAgfTtcbiAgZm9yRWFjaChwYXRoLCAoX3BhcnQsIGlzQnJhY2tldCwgaXNBcnJheSkgPT4ge1xuICAgIGxldCBwYXJ0ID0gaXNCcmFja2V0ID8gX3BhcnQuc2xpY2UoMSwgX3BhcnQubGVuZ3RoIC0gMSkgOiBfcGFydDtcbiAgICBzY2hlbWEgPSBzY2hlbWEucmVzb2x2ZSh7XG4gICAgICBjb250ZXh0LFxuICAgICAgcGFyZW50LFxuICAgICAgdmFsdWVcbiAgICB9KTtcbiAgICBsZXQgaXNUdXBsZSA9IHNjaGVtYS50eXBlID09PSAndHVwbGUnO1xuICAgIGxldCBpZHggPSBpc0FycmF5ID8gcGFyc2VJbnQocGFydCwgMTApIDogMDtcbiAgICBpZiAoc2NoZW1hLmlubmVyVHlwZSB8fCBpc1R1cGxlKSB7XG4gICAgICBpZiAoaXNUdXBsZSAmJiAhaXNBcnJheSkgdGhyb3cgbmV3IEVycm9yKGBZdXAucmVhY2ggY2Fubm90IGltcGxpY2l0bHkgaW5kZXggaW50byBhIHR1cGxlIHR5cGUuIHRoZSBwYXRoIHBhcnQgXCIke2xhc3RQYXJ0RGVidWd9XCIgbXVzdCBjb250YWluIGFuIGluZGV4IHRvIHRoZSB0dXBsZSBlbGVtZW50LCBlLmcuIFwiJHtsYXN0UGFydERlYnVnfVswXVwiYCk7XG4gICAgICBpZiAodmFsdWUgJiYgaWR4ID49IHZhbHVlLmxlbmd0aCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFl1cC5yZWFjaCBjYW5ub3QgcmVzb2x2ZSBhbiBhcnJheSBpdGVtIGF0IGluZGV4OiAke19wYXJ0fSwgaW4gdGhlIHBhdGg6ICR7cGF0aH0uIGAgKyBgYmVjYXVzZSB0aGVyZSBpcyBubyB2YWx1ZSBhdCB0aGF0IGluZGV4LiBgKTtcbiAgICAgIH1cbiAgICAgIHBhcmVudCA9IHZhbHVlO1xuICAgICAgdmFsdWUgPSB2YWx1ZSAmJiB2YWx1ZVtpZHhdO1xuICAgICAgc2NoZW1hID0gaXNUdXBsZSA/IHNjaGVtYS5zcGVjLnR5cGVzW2lkeF0gOiBzY2hlbWEuaW5uZXJUeXBlO1xuICAgIH1cblxuICAgIC8vIHNvbWV0aW1lcyB0aGUgYXJyYXkgaW5kZXggcGFydCBvZiBhIHBhdGggZG9lc24ndCBleGlzdDogXCJuZXN0ZWQuYXJyLmNoaWxkXCJcbiAgICAvLyBpbiB0aGVzZSBjYXNlcyB0aGUgY3VycmVudCBwYXJ0IGlzIHRoZSBuZXh0IHNjaGVtYSBhbmQgc2hvdWxkIGJlIHByb2Nlc3NlZFxuICAgIC8vIGluIHRoaXMgaXRlcmF0aW9uLiBGb3IgY2FzZXMgd2hlcmUgdGhlIGluZGV4IHNpZ25hdHVyZSBpcyBpbmNsdWRlZCB0aGlzXG4gICAgLy8gY2hlY2sgd2lsbCBmYWlsIGFuZCB3ZSdsbCBoYW5kbGUgdGhlIGBjaGlsZGAgcGFydCBvbiB0aGUgbmV4dCBpdGVyYXRpb24gbGlrZSBub3JtYWxcbiAgICBpZiAoIWlzQXJyYXkpIHtcbiAgICAgIGlmICghc2NoZW1hLmZpZWxkcyB8fCAhc2NoZW1hLmZpZWxkc1twYXJ0XSkgdGhyb3cgbmV3IEVycm9yKGBUaGUgc2NoZW1hIGRvZXMgbm90IGNvbnRhaW4gdGhlIHBhdGg6ICR7cGF0aH0uIGAgKyBgKGZhaWxlZCBhdDogJHtsYXN0UGFydERlYnVnfSB3aGljaCBpcyBhIHR5cGU6IFwiJHtzY2hlbWEudHlwZX1cIilgKTtcbiAgICAgIHBhcmVudCA9IHZhbHVlO1xuICAgICAgdmFsdWUgPSB2YWx1ZSAmJiB2YWx1ZVtwYXJ0XTtcbiAgICAgIHNjaGVtYSA9IHNjaGVtYS5maWVsZHNbcGFydF07XG4gICAgfVxuICAgIGxhc3RQYXJ0ID0gcGFydDtcbiAgICBsYXN0UGFydERlYnVnID0gaXNCcmFja2V0ID8gJ1snICsgX3BhcnQgKyAnXScgOiAnLicgKyBfcGFydDtcbiAgfSk7XG4gIHJldHVybiB7XG4gICAgc2NoZW1hLFxuICAgIHBhcmVudCxcbiAgICBwYXJlbnRQYXRoOiBsYXN0UGFydFxuICB9O1xufVxuZnVuY3Rpb24gcmVhY2gob2JqLCBwYXRoLCB2YWx1ZSwgY29udGV4dCkge1xuICByZXR1cm4gZ2V0SW4ob2JqLCBwYXRoLCB2YWx1ZSwgY29udGV4dCkuc2NoZW1hO1xufVxuXG5jbGFzcyBSZWZlcmVuY2VTZXQgZXh0ZW5kcyBTZXQge1xuICBkZXNjcmliZSgpIHtcbiAgICBjb25zdCBkZXNjcmlwdGlvbiA9IFtdO1xuICAgIGZvciAoY29uc3QgaXRlbSBvZiB0aGlzLnZhbHVlcygpKSB7XG4gICAgICBkZXNjcmlwdGlvbi5wdXNoKFJlZmVyZW5jZS5pc1JlZihpdGVtKSA/IGl0ZW0uZGVzY3JpYmUoKSA6IGl0ZW0pO1xuICAgIH1cbiAgICByZXR1cm4gZGVzY3JpcHRpb247XG4gIH1cbiAgcmVzb2x2ZUFsbChyZXNvbHZlKSB7XG4gICAgbGV0IHJlc3VsdCA9IFtdO1xuICAgIGZvciAoY29uc3QgaXRlbSBvZiB0aGlzLnZhbHVlcygpKSB7XG4gICAgICByZXN1bHQucHVzaChyZXNvbHZlKGl0ZW0pKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuICBjbG9uZSgpIHtcbiAgICByZXR1cm4gbmV3IFJlZmVyZW5jZVNldCh0aGlzLnZhbHVlcygpKTtcbiAgfVxuICBtZXJnZShuZXdJdGVtcywgcmVtb3ZlSXRlbXMpIHtcbiAgICBjb25zdCBuZXh0ID0gdGhpcy5jbG9uZSgpO1xuICAgIG5ld0l0ZW1zLmZvckVhY2godmFsdWUgPT4gbmV4dC5hZGQodmFsdWUpKTtcbiAgICByZW1vdmVJdGVtcy5mb3JFYWNoKHZhbHVlID0+IG5leHQuZGVsZXRlKHZhbHVlKSk7XG4gICAgcmV0dXJuIG5leHQ7XG4gIH1cbn1cblxuLy8gdHdlYWtlZCBmcm9tIGh0dHBzOi8vZ2l0aHViLmNvbS9LZWxpbjIwMjUvbmFub2Nsb25lL2Jsb2IvMGFiZWI3NjM1YmRhOWI2OGVmMjI3NzA5M2Y3NmRiZTNiZjM5NDhlMS9zcmMvaW5kZXguanNcbmZ1bmN0aW9uIGNsb25lKHNyYywgc2VlbiA9IG5ldyBNYXAoKSkge1xuICBpZiAoaXNTY2hlbWEoc3JjKSB8fCAhc3JjIHx8IHR5cGVvZiBzcmMgIT09ICdvYmplY3QnKSByZXR1cm4gc3JjO1xuICBpZiAoc2Vlbi5oYXMoc3JjKSkgcmV0dXJuIHNlZW4uZ2V0KHNyYyk7XG4gIGxldCBjb3B5O1xuICBpZiAoc3JjIGluc3RhbmNlb2YgRGF0ZSkge1xuICAgIC8vIERhdGVcbiAgICBjb3B5ID0gbmV3IERhdGUoc3JjLmdldFRpbWUoKSk7XG4gICAgc2Vlbi5zZXQoc3JjLCBjb3B5KTtcbiAgfSBlbHNlIGlmIChzcmMgaW5zdGFuY2VvZiBSZWdFeHApIHtcbiAgICAvLyBSZWdFeHBcbiAgICBjb3B5ID0gbmV3IFJlZ0V4cChzcmMpO1xuICAgIHNlZW4uc2V0KHNyYywgY29weSk7XG4gIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShzcmMpKSB7XG4gICAgLy8gQXJyYXlcbiAgICBjb3B5ID0gbmV3IEFycmF5KHNyYy5sZW5ndGgpO1xuICAgIHNlZW4uc2V0KHNyYywgY29weSk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzcmMubGVuZ3RoOyBpKyspIGNvcHlbaV0gPSBjbG9uZShzcmNbaV0sIHNlZW4pO1xuICB9IGVsc2UgaWYgKHNyYyBpbnN0YW5jZW9mIE1hcCkge1xuICAgIC8vIE1hcFxuICAgIGNvcHkgPSBuZXcgTWFwKCk7XG4gICAgc2Vlbi5zZXQoc3JjLCBjb3B5KTtcbiAgICBmb3IgKGNvbnN0IFtrLCB2XSBvZiBzcmMuZW50cmllcygpKSBjb3B5LnNldChrLCBjbG9uZSh2LCBzZWVuKSk7XG4gIH0gZWxzZSBpZiAoc3JjIGluc3RhbmNlb2YgU2V0KSB7XG4gICAgLy8gU2V0XG4gICAgY29weSA9IG5ldyBTZXQoKTtcbiAgICBzZWVuLnNldChzcmMsIGNvcHkpO1xuICAgIGZvciAoY29uc3QgdiBvZiBzcmMpIGNvcHkuYWRkKGNsb25lKHYsIHNlZW4pKTtcbiAgfSBlbHNlIGlmIChzcmMgaW5zdGFuY2VvZiBPYmplY3QpIHtcbiAgICAvLyBPYmplY3RcbiAgICBjb3B5ID0ge307XG4gICAgc2Vlbi5zZXQoc3JjLCBjb3B5KTtcbiAgICBmb3IgKGNvbnN0IFtrLCB2XSBvZiBPYmplY3QuZW50cmllcyhzcmMpKSBjb3B5W2tdID0gY2xvbmUodiwgc2Vlbik7XG4gIH0gZWxzZSB7XG4gICAgdGhyb3cgRXJyb3IoYFVuYWJsZSB0byBjbG9uZSAke3NyY31gKTtcbiAgfVxuICByZXR1cm4gY29weTtcbn1cblxuLyoqXG4gKiBDb3BpZWQgZnJvbSBAc3RhbmRhcmQtc2NoZW1hL3NwZWMgdG8gYXZvaWQgaGF2aW5nIGEgZGVwZW5kZW5jeSBvbiBpdC5cbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9zdGFuZGFyZC1zY2hlbWEvc3RhbmRhcmQtc2NoZW1hL2Jsb2IvbWFpbi9wYWNrYWdlcy9zcGVjL3NyYy9pbmRleC50c1xuICovXG5cbmZ1bmN0aW9uIGNyZWF0ZVN0YW5kYXJkUGF0aChwYXRoKSB7XG4gIGlmICghKHBhdGggIT0gbnVsbCAmJiBwYXRoLmxlbmd0aCkpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG5cbiAgLy8gQXJyYXkgdG8gc3RvcmUgdGhlIGZpbmFsIHBhdGggc2VnbWVudHNcbiAgY29uc3Qgc2VnbWVudHMgPSBbXTtcbiAgLy8gQnVmZmVyIGZvciBidWlsZGluZyB0aGUgY3VycmVudCBzZWdtZW50XG4gIGxldCBjdXJyZW50U2VnbWVudCA9ICcnO1xuICAvLyBUcmFjayBpZiB3ZSdyZSBpbnNpZGUgc3F1YXJlIGJyYWNrZXRzIChhcnJheS9wcm9wZXJ0eSBhY2Nlc3MpXG4gIGxldCBpbkJyYWNrZXRzID0gZmFsc2U7XG4gIC8vIFRyYWNrIGlmIHdlJ3JlIGluc2lkZSBxdW90ZXMgKGZvciBwcm9wZXJ0eSBuYW1lcyB3aXRoIHNwZWNpYWwgY2hhcnMpXG4gIGxldCBpblF1b3RlcyA9IGZhbHNlO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IHBhdGgubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBjaGFyID0gcGF0aFtpXTtcbiAgICBpZiAoY2hhciA9PT0gJ1snICYmICFpblF1b3Rlcykge1xuICAgICAgLy8gV2hlbiBlbnRlcmluZyBicmFja2V0cywgcHVzaCBhbnkgYWNjdW11bGF0ZWQgc2VnbWVudCBhZnRlciBzcGxpdHRpbmcgb24gZG90c1xuICAgICAgaWYgKGN1cnJlbnRTZWdtZW50KSB7XG4gICAgICAgIHNlZ21lbnRzLnB1c2goLi4uY3VycmVudFNlZ21lbnQuc3BsaXQoJy4nKS5maWx0ZXIoQm9vbGVhbikpO1xuICAgICAgICBjdXJyZW50U2VnbWVudCA9ICcnO1xuICAgICAgfVxuICAgICAgaW5CcmFja2V0cyA9IHRydWU7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKGNoYXIgPT09ICddJyAmJiAhaW5RdW90ZXMpIHtcbiAgICAgIGlmIChjdXJyZW50U2VnbWVudCkge1xuICAgICAgICAvLyBIYW5kbGUgbnVtZXJpYyBpbmRpY2VzIChlLmcuIGFyclswXSlcbiAgICAgICAgaWYgKC9eXFxkKyQvLnRlc3QoY3VycmVudFNlZ21lbnQpKSB7XG4gICAgICAgICAgc2VnbWVudHMucHVzaChjdXJyZW50U2VnbWVudCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgLy8gSGFuZGxlIHF1b3RlZCBwcm9wZXJ0eSBuYW1lcyAoZS5nLiBvYmpbXCJmb28uYmFyXCJdKVxuICAgICAgICAgIHNlZ21lbnRzLnB1c2goY3VycmVudFNlZ21lbnQucmVwbGFjZSgvXlwifFwiJC9nLCAnJykpO1xuICAgICAgICB9XG4gICAgICAgIGN1cnJlbnRTZWdtZW50ID0gJyc7XG4gICAgICB9XG4gICAgICBpbkJyYWNrZXRzID0gZmFsc2U7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKGNoYXIgPT09ICdcIicpIHtcbiAgICAgIC8vIFRvZ2dsZSBxdW90ZSBzdGF0ZSBmb3IgaGFuZGxpbmcgcXVvdGVkIHByb3BlcnR5IG5hbWVzXG4gICAgICBpblF1b3RlcyA9ICFpblF1b3RlcztcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoY2hhciA9PT0gJy4nICYmICFpbkJyYWNrZXRzICYmICFpblF1b3Rlcykge1xuICAgICAgLy8gT24gZG90cyBvdXRzaWRlIGJyYWNrZXRzL3F1b3RlcywgcHVzaCBjdXJyZW50IHNlZ21lbnRcbiAgICAgIGlmIChjdXJyZW50U2VnbWVudCkge1xuICAgICAgICBzZWdtZW50cy5wdXNoKGN1cnJlbnRTZWdtZW50KTtcbiAgICAgICAgY3VycmVudFNlZ21lbnQgPSAnJztcbiAgICAgIH1cbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjdXJyZW50U2VnbWVudCArPSBjaGFyO1xuICB9XG5cbiAgLy8gUHVzaCBhbnkgcmVtYWluaW5nIHNlZ21lbnQgYWZ0ZXIgc3BsaXR0aW5nIG9uIGRvdHNcbiAgaWYgKGN1cnJlbnRTZWdtZW50KSB7XG4gICAgc2VnbWVudHMucHVzaCguLi5jdXJyZW50U2VnbWVudC5zcGxpdCgnLicpLmZpbHRlcihCb29sZWFuKSk7XG4gIH1cbiAgcmV0dXJuIHNlZ21lbnRzO1xufVxuZnVuY3Rpb24gY3JlYXRlU3RhbmRhcmRJc3N1ZXMoZXJyb3IsIHBhcmVudFBhdGgpIHtcbiAgY29uc3QgcGF0aCA9IHBhcmVudFBhdGggPyBgJHtwYXJlbnRQYXRofS4ke2Vycm9yLnBhdGh9YCA6IGVycm9yLnBhdGg7XG4gIHJldHVybiBlcnJvci5lcnJvcnMubWFwKGVyciA9PiAoe1xuICAgIG1lc3NhZ2U6IGVycixcbiAgICBwYXRoOiBjcmVhdGVTdGFuZGFyZFBhdGgocGF0aClcbiAgfSkpO1xufVxuZnVuY3Rpb24gaXNzdWVzRnJvbVZhbGlkYXRpb25FcnJvcihlcnJvciwgcGFyZW50UGF0aCkge1xuICB2YXIgX2Vycm9yJGlubmVyO1xuICBpZiAoISgoX2Vycm9yJGlubmVyID0gZXJyb3IuaW5uZXIpICE9IG51bGwgJiYgX2Vycm9yJGlubmVyLmxlbmd0aCkgJiYgZXJyb3IuZXJyb3JzLmxlbmd0aCkge1xuICAgIHJldHVybiBjcmVhdGVTdGFuZGFyZElzc3VlcyhlcnJvciwgcGFyZW50UGF0aCk7XG4gIH1cbiAgY29uc3QgcGF0aCA9IHBhcmVudFBhdGggPyBgJHtwYXJlbnRQYXRofS4ke2Vycm9yLnBhdGh9YCA6IGVycm9yLnBhdGg7XG4gIHJldHVybiBlcnJvci5pbm5lci5mbGF0TWFwKGVyciA9PiBpc3N1ZXNGcm9tVmFsaWRhdGlvbkVycm9yKGVyciwgcGF0aCkpO1xufVxuXG4vLyBJZiBgQ3VzdG9tU2NoZW1hTWV0YWAgaXNuJ3QgZXh0ZW5kZWQgd2l0aCBhbnkga2V5cywgd2UnbGwgZmFsbCBiYWNrIHRvIGFcbi8vIGxvb3NlIFJlY29yZCBkZWZpbml0aW9uIGFsbG93aW5nIGZyZWUgZm9ybSB1c2FnZS5cbmNsYXNzIFNjaGVtYSB7XG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICB0aGlzLnR5cGUgPSB2b2lkIDA7XG4gICAgdGhpcy5kZXBzID0gW107XG4gICAgdGhpcy50ZXN0cyA9IHZvaWQgMDtcbiAgICB0aGlzLnRyYW5zZm9ybXMgPSB2b2lkIDA7XG4gICAgdGhpcy5jb25kaXRpb25zID0gW107XG4gICAgdGhpcy5fbXV0YXRlID0gdm9pZCAwO1xuICAgIHRoaXMuaW50ZXJuYWxUZXN0cyA9IHt9O1xuICAgIHRoaXMuX3doaXRlbGlzdCA9IG5ldyBSZWZlcmVuY2VTZXQoKTtcbiAgICB0aGlzLl9ibGFja2xpc3QgPSBuZXcgUmVmZXJlbmNlU2V0KCk7XG4gICAgdGhpcy5leGNsdXNpdmVUZXN0cyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgdGhpcy5fdHlwZUNoZWNrID0gdm9pZCAwO1xuICAgIHRoaXMuc3BlYyA9IHZvaWQgMDtcbiAgICB0aGlzLnRlc3RzID0gW107XG4gICAgdGhpcy50cmFuc2Zvcm1zID0gW107XG4gICAgdGhpcy53aXRoTXV0YXRpb24oKCkgPT4ge1xuICAgICAgdGhpcy50eXBlRXJyb3IobWl4ZWQubm90VHlwZSk7XG4gICAgfSk7XG4gICAgdGhpcy50eXBlID0gb3B0aW9ucy50eXBlO1xuICAgIHRoaXMuX3R5cGVDaGVjayA9IG9wdGlvbnMuY2hlY2s7XG4gICAgdGhpcy5zcGVjID0gT2JqZWN0LmFzc2lnbih7XG4gICAgICBzdHJpcDogZmFsc2UsXG4gICAgICBzdHJpY3Q6IGZhbHNlLFxuICAgICAgYWJvcnRFYXJseTogdHJ1ZSxcbiAgICAgIHJlY3Vyc2l2ZTogdHJ1ZSxcbiAgICAgIGRpc2FibGVTdGFja1RyYWNlOiBmYWxzZSxcbiAgICAgIG51bGxhYmxlOiBmYWxzZSxcbiAgICAgIG9wdGlvbmFsOiB0cnVlLFxuICAgICAgY29lcmNlOiB0cnVlXG4gICAgfSwgb3B0aW9ucyA9PSBudWxsID8gdm9pZCAwIDogb3B0aW9ucy5zcGVjKTtcbiAgICB0aGlzLndpdGhNdXRhdGlvbihzID0+IHtcbiAgICAgIHMubm9uTnVsbGFibGUoKTtcbiAgICB9KTtcbiAgfVxuXG4gIC8vIFRPRE86IHJlbW92ZVxuICBnZXQgX3R5cGUoKSB7XG4gICAgcmV0dXJuIHRoaXMudHlwZTtcbiAgfVxuICBjbG9uZShzcGVjKSB7XG4gICAgaWYgKHRoaXMuX211dGF0ZSkge1xuICAgICAgaWYgKHNwZWMpIE9iamVjdC5hc3NpZ24odGhpcy5zcGVjLCBzcGVjKTtcbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIC8vIGlmIHRoZSBuZXN0ZWQgdmFsdWUgaXMgYSBzY2hlbWEgd2UgY2FuIHNraXAgY2xvbmluZywgc2luY2VcbiAgICAvLyB0aGV5IGFyZSBhbHJlYWR5IGltbXV0YWJsZVxuICAgIGNvbnN0IG5leHQgPSBPYmplY3QuY3JlYXRlKE9iamVjdC5nZXRQcm90b3R5cGVPZih0aGlzKSk7XG5cbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yIHRoaXMgaXMgcmVhZG9ubHlcbiAgICBuZXh0LnR5cGUgPSB0aGlzLnR5cGU7XG4gICAgbmV4dC5fdHlwZUNoZWNrID0gdGhpcy5fdHlwZUNoZWNrO1xuICAgIG5leHQuX3doaXRlbGlzdCA9IHRoaXMuX3doaXRlbGlzdC5jbG9uZSgpO1xuICAgIG5leHQuX2JsYWNrbGlzdCA9IHRoaXMuX2JsYWNrbGlzdC5jbG9uZSgpO1xuICAgIG5leHQuaW50ZXJuYWxUZXN0cyA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMuaW50ZXJuYWxUZXN0cyk7XG4gICAgbmV4dC5leGNsdXNpdmVUZXN0cyA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMuZXhjbHVzaXZlVGVzdHMpO1xuXG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciB0aGlzIGlzIHJlYWRvbmx5XG4gICAgbmV4dC5kZXBzID0gWy4uLnRoaXMuZGVwc107XG4gICAgbmV4dC5jb25kaXRpb25zID0gWy4uLnRoaXMuY29uZGl0aW9uc107XG4gICAgbmV4dC50ZXN0cyA9IFsuLi50aGlzLnRlc3RzXTtcbiAgICBuZXh0LnRyYW5zZm9ybXMgPSBbLi4udGhpcy50cmFuc2Zvcm1zXTtcbiAgICBuZXh0LnNwZWMgPSBjbG9uZShPYmplY3QuYXNzaWduKHt9LCB0aGlzLnNwZWMsIHNwZWMpKTtcbiAgICByZXR1cm4gbmV4dDtcbiAgfVxuICBsYWJlbChsYWJlbCkge1xuICAgIGxldCBuZXh0ID0gdGhpcy5jbG9uZSgpO1xuICAgIG5leHQuc3BlYy5sYWJlbCA9IGxhYmVsO1xuICAgIHJldHVybiBuZXh0O1xuICB9XG4gIG1ldGEoLi4uYXJncykge1xuICAgIGlmIChhcmdzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHRoaXMuc3BlYy5tZXRhO1xuICAgIGxldCBuZXh0ID0gdGhpcy5jbG9uZSgpO1xuICAgIG5leHQuc3BlYy5tZXRhID0gT2JqZWN0LmFzc2lnbihuZXh0LnNwZWMubWV0YSB8fCB7fSwgYXJnc1swXSk7XG4gICAgcmV0dXJuIG5leHQ7XG4gIH1cbiAgd2l0aE11dGF0aW9uKGZuKSB7XG4gICAgbGV0IGJlZm9yZSA9IHRoaXMuX211dGF0ZTtcbiAgICB0aGlzLl9tdXRhdGUgPSB0cnVlO1xuICAgIGxldCByZXN1bHQgPSBmbih0aGlzKTtcbiAgICB0aGlzLl9tdXRhdGUgPSBiZWZvcmU7XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuICBjb25jYXQoc2NoZW1hKSB7XG4gICAgaWYgKCFzY2hlbWEgfHwgc2NoZW1hID09PSB0aGlzKSByZXR1cm4gdGhpcztcbiAgICBpZiAoc2NoZW1hLnR5cGUgIT09IHRoaXMudHlwZSAmJiB0aGlzLnR5cGUgIT09ICdtaXhlZCcpIHRocm93IG5ldyBUeXBlRXJyb3IoYFlvdSBjYW5ub3QgXFxgY29uY2F0KClcXGAgc2NoZW1hJ3Mgb2YgZGlmZmVyZW50IHR5cGVzOiAke3RoaXMudHlwZX0gYW5kICR7c2NoZW1hLnR5cGV9YCk7XG4gICAgbGV0IGJhc2UgPSB0aGlzO1xuICAgIGxldCBjb21iaW5lZCA9IHNjaGVtYS5jbG9uZSgpO1xuICAgIGNvbnN0IG1lcmdlZFNwZWMgPSBPYmplY3QuYXNzaWduKHt9LCBiYXNlLnNwZWMsIGNvbWJpbmVkLnNwZWMpO1xuICAgIGNvbWJpbmVkLnNwZWMgPSBtZXJnZWRTcGVjO1xuICAgIGNvbWJpbmVkLmludGVybmFsVGVzdHMgPSBPYmplY3QuYXNzaWduKHt9LCBiYXNlLmludGVybmFsVGVzdHMsIGNvbWJpbmVkLmludGVybmFsVGVzdHMpO1xuXG4gICAgLy8gbWFudWFsbHkgbWVyZ2UgdGhlIGJsYWNrbGlzdC93aGl0ZWxpc3QgKHRoZSBvdGhlciBgc2NoZW1hYCB0YWtlc1xuICAgIC8vIHByZWNlZGVuY2UgaW4gY2FzZSBvZiBjb25mbGljdHMpXG4gICAgY29tYmluZWQuX3doaXRlbGlzdCA9IGJhc2UuX3doaXRlbGlzdC5tZXJnZShzY2hlbWEuX3doaXRlbGlzdCwgc2NoZW1hLl9ibGFja2xpc3QpO1xuICAgIGNvbWJpbmVkLl9ibGFja2xpc3QgPSBiYXNlLl9ibGFja2xpc3QubWVyZ2Uoc2NoZW1hLl9ibGFja2xpc3QsIHNjaGVtYS5fd2hpdGVsaXN0KTtcblxuICAgIC8vIHN0YXJ0IHdpdGggdGhlIGN1cnJlbnQgdGVzdHNcbiAgICBjb21iaW5lZC50ZXN0cyA9IGJhc2UudGVzdHM7XG4gICAgY29tYmluZWQuZXhjbHVzaXZlVGVzdHMgPSBiYXNlLmV4Y2x1c2l2ZVRlc3RzO1xuXG4gICAgLy8gbWFudWFsbHkgYWRkIHRoZSBuZXcgdGVzdHMgdG8gZW5zdXJlXG4gICAgLy8gdGhlIGRlZHVwaW5nIGxvZ2ljIGlzIGNvbnNpc3RlbnRcbiAgICBjb21iaW5lZC53aXRoTXV0YXRpb24obmV4dCA9PiB7XG4gICAgICBzY2hlbWEudGVzdHMuZm9yRWFjaChmbiA9PiB7XG4gICAgICAgIG5leHQudGVzdChmbi5PUFRJT05TKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIGNvbWJpbmVkLnRyYW5zZm9ybXMgPSBbLi4uYmFzZS50cmFuc2Zvcm1zLCAuLi5jb21iaW5lZC50cmFuc2Zvcm1zXTtcbiAgICByZXR1cm4gY29tYmluZWQ7XG4gIH1cbiAgaXNUeXBlKHYpIHtcbiAgICBpZiAodiA9PSBudWxsKSB7XG4gICAgICBpZiAodGhpcy5zcGVjLm51bGxhYmxlICYmIHYgPT09IG51bGwpIHJldHVybiB0cnVlO1xuICAgICAgaWYgKHRoaXMuc3BlYy5vcHRpb25hbCAmJiB2ID09PSB1bmRlZmluZWQpIHJldHVybiB0cnVlO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fdHlwZUNoZWNrKHYpO1xuICB9XG4gIHJlc29sdmUob3B0aW9ucykge1xuICAgIGxldCBzY2hlbWEgPSB0aGlzO1xuICAgIGlmIChzY2hlbWEuY29uZGl0aW9ucy5sZW5ndGgpIHtcbiAgICAgIGxldCBjb25kaXRpb25zID0gc2NoZW1hLmNvbmRpdGlvbnM7XG4gICAgICBzY2hlbWEgPSBzY2hlbWEuY2xvbmUoKTtcbiAgICAgIHNjaGVtYS5jb25kaXRpb25zID0gW107XG4gICAgICBzY2hlbWEgPSBjb25kaXRpb25zLnJlZHVjZSgocHJldlNjaGVtYSwgY29uZGl0aW9uKSA9PiBjb25kaXRpb24ucmVzb2x2ZShwcmV2U2NoZW1hLCBvcHRpb25zKSwgc2NoZW1hKTtcbiAgICAgIHNjaGVtYSA9IHNjaGVtYS5yZXNvbHZlKG9wdGlvbnMpO1xuICAgIH1cbiAgICByZXR1cm4gc2NoZW1hO1xuICB9XG4gIHJlc29sdmVPcHRpb25zKG9wdGlvbnMpIHtcbiAgICB2YXIgX29wdGlvbnMkc3RyaWN0LCBfb3B0aW9ucyRhYm9ydEVhcmx5LCBfb3B0aW9ucyRyZWN1cnNpdmUsIF9vcHRpb25zJGRpc2FibGVTdGFjaztcbiAgICByZXR1cm4gT2JqZWN0LmFzc2lnbih7fSwgb3B0aW9ucywge1xuICAgICAgZnJvbTogb3B0aW9ucy5mcm9tIHx8IFtdLFxuICAgICAgc3RyaWN0OiAoX29wdGlvbnMkc3RyaWN0ID0gb3B0aW9ucy5zdHJpY3QpICE9IG51bGwgPyBfb3B0aW9ucyRzdHJpY3QgOiB0aGlzLnNwZWMuc3RyaWN0LFxuICAgICAgYWJvcnRFYXJseTogKF9vcHRpb25zJGFib3J0RWFybHkgPSBvcHRpb25zLmFib3J0RWFybHkpICE9IG51bGwgPyBfb3B0aW9ucyRhYm9ydEVhcmx5IDogdGhpcy5zcGVjLmFib3J0RWFybHksXG4gICAgICByZWN1cnNpdmU6IChfb3B0aW9ucyRyZWN1cnNpdmUgPSBvcHRpb25zLnJlY3Vyc2l2ZSkgIT0gbnVsbCA/IF9vcHRpb25zJHJlY3Vyc2l2ZSA6IHRoaXMuc3BlYy5yZWN1cnNpdmUsXG4gICAgICBkaXNhYmxlU3RhY2tUcmFjZTogKF9vcHRpb25zJGRpc2FibGVTdGFjayA9IG9wdGlvbnMuZGlzYWJsZVN0YWNrVHJhY2UpICE9IG51bGwgPyBfb3B0aW9ucyRkaXNhYmxlU3RhY2sgOiB0aGlzLnNwZWMuZGlzYWJsZVN0YWNrVHJhY2VcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSdW4gdGhlIGNvbmZpZ3VyZWQgdHJhbnNmb3JtIHBpcGVsaW5lIG92ZXIgYW4gaW5wdXQgdmFsdWUuXG4gICAqL1xuXG4gIGNhc3QodmFsdWUsIG9wdGlvbnMgPSB7fSkge1xuICAgIGxldCByZXNvbHZlZFNjaGVtYSA9IHRoaXMucmVzb2x2ZShPYmplY3QuYXNzaWduKHt9LCBvcHRpb25zLCB7XG4gICAgICB2YWx1ZVxuICAgICAgLy8gcGFyZW50OiBvcHRpb25zLnBhcmVudCxcbiAgICAgIC8vIGNvbnRleHQ6IG9wdGlvbnMuY29udGV4dCxcbiAgICB9KSk7XG5cbiAgICBsZXQgYWxsb3dPcHRpb25hbGl0eSA9IG9wdGlvbnMuYXNzZXJ0ID09PSAnaWdub3JlLW9wdGlvbmFsaXR5JztcbiAgICBsZXQgcmVzdWx0ID0gcmVzb2x2ZWRTY2hlbWEuX2Nhc3QodmFsdWUsIG9wdGlvbnMpO1xuICAgIGlmIChvcHRpb25zLmFzc2VydCAhPT0gZmFsc2UgJiYgIXJlc29sdmVkU2NoZW1hLmlzVHlwZShyZXN1bHQpKSB7XG4gICAgICBpZiAoYWxsb3dPcHRpb25hbGl0eSAmJiBpc0Fic2VudChyZXN1bHQpKSB7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICB9XG4gICAgICBsZXQgZm9ybWF0dGVkVmFsdWUgPSBwcmludFZhbHVlKHZhbHVlKTtcbiAgICAgIGxldCBmb3JtYXR0ZWRSZXN1bHQgPSBwcmludFZhbHVlKHJlc3VsdCk7XG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBUaGUgdmFsdWUgb2YgJHtvcHRpb25zLnBhdGggfHwgJ2ZpZWxkJ30gY291bGQgbm90IGJlIGNhc3QgdG8gYSB2YWx1ZSBgICsgYHRoYXQgc2F0aXNmaWVzIHRoZSBzY2hlbWEgdHlwZTogXCIke3Jlc29sdmVkU2NoZW1hLnR5cGV9XCIuIFxcblxcbmAgKyBgYXR0ZW1wdGVkIHZhbHVlOiAke2Zvcm1hdHRlZFZhbHVlfSBcXG5gICsgKGZvcm1hdHRlZFJlc3VsdCAhPT0gZm9ybWF0dGVkVmFsdWUgPyBgcmVzdWx0IG9mIGNhc3Q6ICR7Zm9ybWF0dGVkUmVzdWx0fWAgOiAnJykpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG4gIF9jYXN0KHJhd1ZhbHVlLCBvcHRpb25zKSB7XG4gICAgbGV0IHZhbHVlID0gcmF3VmFsdWUgPT09IHVuZGVmaW5lZCA/IHJhd1ZhbHVlIDogdGhpcy50cmFuc2Zvcm1zLnJlZHVjZSgocHJldlZhbHVlLCBmbikgPT4gZm4uY2FsbCh0aGlzLCBwcmV2VmFsdWUsIHJhd1ZhbHVlLCB0aGlzLCBvcHRpb25zKSwgcmF3VmFsdWUpO1xuICAgIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICB2YWx1ZSA9IHRoaXMuZ2V0RGVmYXVsdChvcHRpb25zKTtcbiAgICB9XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG4gIF92YWxpZGF0ZShfdmFsdWUsIG9wdGlvbnMgPSB7fSwgcGFuaWMsIG5leHQpIHtcbiAgICBsZXQge1xuICAgICAgcGF0aCxcbiAgICAgIG9yaWdpbmFsVmFsdWUgPSBfdmFsdWUsXG4gICAgICBzdHJpY3QgPSB0aGlzLnNwZWMuc3RyaWN0XG4gICAgfSA9IG9wdGlvbnM7XG4gICAgbGV0IHZhbHVlID0gX3ZhbHVlO1xuICAgIGlmICghc3RyaWN0KSB7XG4gICAgICB2YWx1ZSA9IHRoaXMuX2Nhc3QodmFsdWUsIE9iamVjdC5hc3NpZ24oe1xuICAgICAgICBhc3NlcnQ6IGZhbHNlXG4gICAgICB9LCBvcHRpb25zKSk7XG4gICAgfVxuICAgIGxldCBpbml0aWFsVGVzdHMgPSBbXTtcbiAgICBmb3IgKGxldCB0ZXN0IG9mIE9iamVjdC52YWx1ZXModGhpcy5pbnRlcm5hbFRlc3RzKSkge1xuICAgICAgaWYgKHRlc3QpIGluaXRpYWxUZXN0cy5wdXNoKHRlc3QpO1xuICAgIH1cbiAgICB0aGlzLnJ1blRlc3RzKHtcbiAgICAgIHBhdGgsXG4gICAgICB2YWx1ZSxcbiAgICAgIG9yaWdpbmFsVmFsdWUsXG4gICAgICBvcHRpb25zLFxuICAgICAgdGVzdHM6IGluaXRpYWxUZXN0c1xuICAgIH0sIHBhbmljLCBpbml0aWFsRXJyb3JzID0+IHtcbiAgICAgIC8vIGV2ZW4gaWYgd2UgYXJlbid0IGVuZGluZyBlYXJseSB3ZSBjYW4ndCBwcm9jZWVkIGZ1cnRoZXIgaWYgdGhlIHR5cGVzIGFyZW4ndCBjb3JyZWN0XG4gICAgICBpZiAoaW5pdGlhbEVycm9ycy5sZW5ndGgpIHtcbiAgICAgICAgcmV0dXJuIG5leHQoaW5pdGlhbEVycm9ycywgdmFsdWUpO1xuICAgICAgfVxuICAgICAgdGhpcy5ydW5UZXN0cyh7XG4gICAgICAgIHBhdGgsXG4gICAgICAgIHZhbHVlLFxuICAgICAgICBvcmlnaW5hbFZhbHVlLFxuICAgICAgICBvcHRpb25zLFxuICAgICAgICB0ZXN0czogdGhpcy50ZXN0c1xuICAgICAgfSwgcGFuaWMsIG5leHQpO1xuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIEV4ZWN1dGVzIGEgc2V0IG9mIHZhbGlkYXRpb25zLCBlaXRoZXIgc2NoZW1hLCBwcm9kdWNlZCBUZXN0cyBvciBhIG5lc3RlZFxuICAgKiBzY2hlbWEgdmFsaWRhdGUgcmVzdWx0LlxuICAgKi9cbiAgcnVuVGVzdHMocnVuT3B0aW9ucywgcGFuaWMsIG5leHQpIHtcbiAgICBsZXQgZmlyZWQgPSBmYWxzZTtcbiAgICBsZXQge1xuICAgICAgdGVzdHMsXG4gICAgICB2YWx1ZSxcbiAgICAgIG9yaWdpbmFsVmFsdWUsXG4gICAgICBwYXRoLFxuICAgICAgb3B0aW9uc1xuICAgIH0gPSBydW5PcHRpb25zO1xuICAgIGxldCBwYW5pY09uY2UgPSBhcmcgPT4ge1xuICAgICAgaWYgKGZpcmVkKSByZXR1cm47XG4gICAgICBmaXJlZCA9IHRydWU7XG4gICAgICBwYW5pYyhhcmcsIHZhbHVlKTtcbiAgICB9O1xuICAgIGxldCBuZXh0T25jZSA9IGFyZyA9PiB7XG4gICAgICBpZiAoZmlyZWQpIHJldHVybjtcbiAgICAgIGZpcmVkID0gdHJ1ZTtcbiAgICAgIG5leHQoYXJnLCB2YWx1ZSk7XG4gICAgfTtcbiAgICBsZXQgY291bnQgPSB0ZXN0cy5sZW5ndGg7XG4gICAgbGV0IG5lc3RlZEVycm9ycyA9IFtdO1xuICAgIGlmICghY291bnQpIHJldHVybiBuZXh0T25jZShbXSk7XG4gICAgbGV0IGFyZ3MgPSB7XG4gICAgICB2YWx1ZSxcbiAgICAgIG9yaWdpbmFsVmFsdWUsXG4gICAgICBwYXRoLFxuICAgICAgb3B0aW9ucyxcbiAgICAgIHNjaGVtYTogdGhpc1xuICAgIH07XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0ZXN0cy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgdGVzdCA9IHRlc3RzW2ldO1xuICAgICAgdGVzdChhcmdzLCBwYW5pY09uY2UsIGZ1bmN0aW9uIGZpbmlzaFRlc3RSdW4oZXJyKSB7XG4gICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICBBcnJheS5pc0FycmF5KGVycikgPyBuZXN0ZWRFcnJvcnMucHVzaCguLi5lcnIpIDogbmVzdGVkRXJyb3JzLnB1c2goZXJyKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoLS1jb3VudCA8PSAwKSB7XG4gICAgICAgICAgbmV4dE9uY2UobmVzdGVkRXJyb3JzKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIGFzTmVzdGVkVGVzdCh7XG4gICAga2V5LFxuICAgIGluZGV4LFxuICAgIHBhcmVudCxcbiAgICBwYXJlbnRQYXRoLFxuICAgIG9yaWdpbmFsUGFyZW50LFxuICAgIG9wdGlvbnNcbiAgfSkge1xuICAgIGNvbnN0IGsgPSBrZXkgIT0gbnVsbCA/IGtleSA6IGluZGV4O1xuICAgIGlmIChrID09IG51bGwpIHtcbiAgICAgIHRocm93IFR5cGVFcnJvcignTXVzdCBpbmNsdWRlIGBrZXlgIG9yIGBpbmRleGAgZm9yIG5lc3RlZCB2YWxpZGF0aW9ucycpO1xuICAgIH1cbiAgICBjb25zdCBpc0luZGV4ID0gdHlwZW9mIGsgPT09ICdudW1iZXInO1xuICAgIGxldCB2YWx1ZSA9IHBhcmVudFtrXTtcbiAgICBjb25zdCB0ZXN0T3B0aW9ucyA9IE9iamVjdC5hc3NpZ24oe30sIG9wdGlvbnMsIHtcbiAgICAgIC8vIE5lc3RlZCB2YWxpZGF0aW9ucyBmaWVsZHMgYXJlIGFsd2F5cyBzdHJpY3Q6XG4gICAgICAvLyAgICAxLiBwYXJlbnQgaXNuJ3Qgc3RyaWN0IHNvIHRoZSBjYXN0aW5nIHdpbGwgYWxzbyBoYXZlIGNhc3QgaW5uZXIgdmFsdWVzXG4gICAgICAvLyAgICAyLiBwYXJlbnQgaXMgc3RyaWN0IGluIHdoaWNoIGNhc2UgdGhlIG5lc3RlZCB2YWx1ZXMgd2VyZW4ndCBjYXN0IGVpdGhlclxuICAgICAgc3RyaWN0OiB0cnVlLFxuICAgICAgcGFyZW50LFxuICAgICAgdmFsdWUsXG4gICAgICBvcmlnaW5hbFZhbHVlOiBvcmlnaW5hbFBhcmVudFtrXSxcbiAgICAgIC8vIEZJWE1FOiB0ZXN0cyBkZXBlbmQgb24gYGluZGV4YCBiZWluZyBwYXNzZWQgYXJvdW5kIGRlZXBseSxcbiAgICAgIC8vICAgd2Ugc2hvdWxkIG5vdCBsZXQgdGhlIG9wdGlvbnMua2V5L2luZGV4IGJsZWVkIHRocm91Z2hcbiAgICAgIGtleTogdW5kZWZpbmVkLFxuICAgICAgLy8gaW5kZXg6IHVuZGVmaW5lZCxcbiAgICAgIFtpc0luZGV4ID8gJ2luZGV4JyA6ICdrZXknXTogayxcbiAgICAgIHBhdGg6IGlzSW5kZXggfHwgay5pbmNsdWRlcygnLicpID8gYCR7cGFyZW50UGF0aCB8fCAnJ31bJHtpc0luZGV4ID8gayA6IGBcIiR7a31cImB9XWAgOiAocGFyZW50UGF0aCA/IGAke3BhcmVudFBhdGh9LmAgOiAnJykgKyBrZXlcbiAgICB9KTtcbiAgICByZXR1cm4gKF8sIHBhbmljLCBuZXh0KSA9PiB0aGlzLnJlc29sdmUodGVzdE9wdGlvbnMpLl92YWxpZGF0ZSh2YWx1ZSwgdGVzdE9wdGlvbnMsIHBhbmljLCBuZXh0KTtcbiAgfVxuICB2YWxpZGF0ZSh2YWx1ZSwgb3B0aW9ucykge1xuICAgIHZhciBfb3B0aW9ucyRkaXNhYmxlU3RhY2syO1xuICAgIGxldCBzY2hlbWEgPSB0aGlzLnJlc29sdmUoT2JqZWN0LmFzc2lnbih7fSwgb3B0aW9ucywge1xuICAgICAgdmFsdWVcbiAgICB9KSk7XG4gICAgbGV0IGRpc2FibGVTdGFja1RyYWNlID0gKF9vcHRpb25zJGRpc2FibGVTdGFjazIgPSBvcHRpb25zID09IG51bGwgPyB2b2lkIDAgOiBvcHRpb25zLmRpc2FibGVTdGFja1RyYWNlKSAhPSBudWxsID8gX29wdGlvbnMkZGlzYWJsZVN0YWNrMiA6IHNjaGVtYS5zcGVjLmRpc2FibGVTdGFja1RyYWNlO1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiBzY2hlbWEuX3ZhbGlkYXRlKHZhbHVlLCBvcHRpb25zLCAoZXJyb3IsIHBhcnNlZCkgPT4ge1xuICAgICAgaWYgKFZhbGlkYXRpb25FcnJvci5pc0Vycm9yKGVycm9yKSkgZXJyb3IudmFsdWUgPSBwYXJzZWQ7XG4gICAgICByZWplY3QoZXJyb3IpO1xuICAgIH0sIChlcnJvcnMsIHZhbGlkYXRlZCkgPT4ge1xuICAgICAgaWYgKGVycm9ycy5sZW5ndGgpIHJlamVjdChuZXcgVmFsaWRhdGlvbkVycm9yKGVycm9ycywgdmFsaWRhdGVkLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgZGlzYWJsZVN0YWNrVHJhY2UpKTtlbHNlIHJlc29sdmUodmFsaWRhdGVkKTtcbiAgICB9KSk7XG4gIH1cbiAgdmFsaWRhdGVTeW5jKHZhbHVlLCBvcHRpb25zKSB7XG4gICAgdmFyIF9vcHRpb25zJGRpc2FibGVTdGFjazM7XG4gICAgbGV0IHNjaGVtYSA9IHRoaXMucmVzb2x2ZShPYmplY3QuYXNzaWduKHt9LCBvcHRpb25zLCB7XG4gICAgICB2YWx1ZVxuICAgIH0pKTtcbiAgICBsZXQgcmVzdWx0O1xuICAgIGxldCBkaXNhYmxlU3RhY2tUcmFjZSA9IChfb3B0aW9ucyRkaXNhYmxlU3RhY2szID0gb3B0aW9ucyA9PSBudWxsID8gdm9pZCAwIDogb3B0aW9ucy5kaXNhYmxlU3RhY2tUcmFjZSkgIT0gbnVsbCA/IF9vcHRpb25zJGRpc2FibGVTdGFjazMgOiBzY2hlbWEuc3BlYy5kaXNhYmxlU3RhY2tUcmFjZTtcbiAgICBzY2hlbWEuX3ZhbGlkYXRlKHZhbHVlLCBPYmplY3QuYXNzaWduKHt9LCBvcHRpb25zLCB7XG4gICAgICBzeW5jOiB0cnVlXG4gICAgfSksIChlcnJvciwgcGFyc2VkKSA9PiB7XG4gICAgICBpZiAoVmFsaWRhdGlvbkVycm9yLmlzRXJyb3IoZXJyb3IpKSBlcnJvci52YWx1ZSA9IHBhcnNlZDtcbiAgICAgIHRocm93IGVycm9yO1xuICAgIH0sIChlcnJvcnMsIHZhbGlkYXRlZCkgPT4ge1xuICAgICAgaWYgKGVycm9ycy5sZW5ndGgpIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoZXJyb3JzLCB2YWx1ZSwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIGRpc2FibGVTdGFja1RyYWNlKTtcbiAgICAgIHJlc3VsdCA9IHZhbGlkYXRlZDtcbiAgICB9KTtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG4gIGlzVmFsaWQodmFsdWUsIG9wdGlvbnMpIHtcbiAgICByZXR1cm4gdGhpcy52YWxpZGF0ZSh2YWx1ZSwgb3B0aW9ucykudGhlbigoKSA9PiB0cnVlLCBlcnIgPT4ge1xuICAgICAgaWYgKFZhbGlkYXRpb25FcnJvci5pc0Vycm9yKGVycikpIHJldHVybiBmYWxzZTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9KTtcbiAgfVxuICBpc1ZhbGlkU3luYyh2YWx1ZSwgb3B0aW9ucykge1xuICAgIHRyeSB7XG4gICAgICB0aGlzLnZhbGlkYXRlU3luYyh2YWx1ZSwgb3B0aW9ucyk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChWYWxpZGF0aW9uRXJyb3IuaXNFcnJvcihlcnIpKSByZXR1cm4gZmFsc2U7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9XG4gIF9nZXREZWZhdWx0KG9wdGlvbnMpIHtcbiAgICBsZXQgZGVmYXVsdFZhbHVlID0gdGhpcy5zcGVjLmRlZmF1bHQ7XG4gICAgaWYgKGRlZmF1bHRWYWx1ZSA9PSBudWxsKSB7XG4gICAgICByZXR1cm4gZGVmYXVsdFZhbHVlO1xuICAgIH1cbiAgICByZXR1cm4gdHlwZW9mIGRlZmF1bHRWYWx1ZSA9PT0gJ2Z1bmN0aW9uJyA/IGRlZmF1bHRWYWx1ZS5jYWxsKHRoaXMsIG9wdGlvbnMpIDogY2xvbmUoZGVmYXVsdFZhbHVlKTtcbiAgfVxuICBnZXREZWZhdWx0KG9wdGlvbnNcbiAgLy8gSWYgc2NoZW1hIGlzIGRlZmF1bHRlZCB3ZSBrbm93IGl0J3MgYXQgbGVhc3Qgbm90IHVuZGVmaW5lZFxuICApIHtcbiAgICBsZXQgc2NoZW1hID0gdGhpcy5yZXNvbHZlKG9wdGlvbnMgfHwge30pO1xuICAgIHJldHVybiBzY2hlbWEuX2dldERlZmF1bHQob3B0aW9ucyk7XG4gIH1cbiAgZGVmYXVsdChkZWYpIHtcbiAgICBpZiAoYXJndW1lbnRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuIHRoaXMuX2dldERlZmF1bHQoKTtcbiAgICB9XG4gICAgbGV0IG5leHQgPSB0aGlzLmNsb25lKHtcbiAgICAgIGRlZmF1bHQ6IGRlZlxuICAgIH0pO1xuICAgIHJldHVybiBuZXh0O1xuICB9XG4gIHN0cmljdChpc1N0cmljdCA9IHRydWUpIHtcbiAgICByZXR1cm4gdGhpcy5jbG9uZSh7XG4gICAgICBzdHJpY3Q6IGlzU3RyaWN0XG4gICAgfSk7XG4gIH1cbiAgbnVsbGFiaWxpdHkobnVsbGFibGUsIG1lc3NhZ2UpIHtcbiAgICBjb25zdCBuZXh0ID0gdGhpcy5jbG9uZSh7XG4gICAgICBudWxsYWJsZVxuICAgIH0pO1xuICAgIG5leHQuaW50ZXJuYWxUZXN0cy5udWxsYWJsZSA9IGNyZWF0ZVZhbGlkYXRpb24oe1xuICAgICAgbWVzc2FnZSxcbiAgICAgIG5hbWU6ICdudWxsYWJsZScsXG4gICAgICB0ZXN0KHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZSA9PT0gbnVsbCA/IHRoaXMuc2NoZW1hLnNwZWMubnVsbGFibGUgOiB0cnVlO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBuZXh0O1xuICB9XG4gIG9wdGlvbmFsaXR5KG9wdGlvbmFsLCBtZXNzYWdlKSB7XG4gICAgY29uc3QgbmV4dCA9IHRoaXMuY2xvbmUoe1xuICAgICAgb3B0aW9uYWxcbiAgICB9KTtcbiAgICBuZXh0LmludGVybmFsVGVzdHMub3B0aW9uYWxpdHkgPSBjcmVhdGVWYWxpZGF0aW9uKHtcbiAgICAgIG1lc3NhZ2UsXG4gICAgICBuYW1lOiAnb3B0aW9uYWxpdHknLFxuICAgICAgdGVzdCh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUgPT09IHVuZGVmaW5lZCA/IHRoaXMuc2NoZW1hLnNwZWMub3B0aW9uYWwgOiB0cnVlO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBuZXh0O1xuICB9XG4gIG9wdGlvbmFsKCkge1xuICAgIHJldHVybiB0aGlzLm9wdGlvbmFsaXR5KHRydWUpO1xuICB9XG4gIGRlZmluZWQobWVzc2FnZSA9IG1peGVkLmRlZmluZWQpIHtcbiAgICByZXR1cm4gdGhpcy5vcHRpb25hbGl0eShmYWxzZSwgbWVzc2FnZSk7XG4gIH1cbiAgbnVsbGFibGUoKSB7XG4gICAgcmV0dXJuIHRoaXMubnVsbGFiaWxpdHkodHJ1ZSk7XG4gIH1cbiAgbm9uTnVsbGFibGUobWVzc2FnZSA9IG1peGVkLm5vdE51bGwpIHtcbiAgICByZXR1cm4gdGhpcy5udWxsYWJpbGl0eShmYWxzZSwgbWVzc2FnZSk7XG4gIH1cbiAgcmVxdWlyZWQobWVzc2FnZSA9IG1peGVkLnJlcXVpcmVkKSB7XG4gICAgcmV0dXJuIHRoaXMuY2xvbmUoKS53aXRoTXV0YXRpb24obmV4dCA9PiBuZXh0Lm5vbk51bGxhYmxlKG1lc3NhZ2UpLmRlZmluZWQobWVzc2FnZSkpO1xuICB9XG4gIG5vdFJlcXVpcmVkKCkge1xuICAgIHJldHVybiB0aGlzLmNsb25lKCkud2l0aE11dGF0aW9uKG5leHQgPT4gbmV4dC5udWxsYWJsZSgpLm9wdGlvbmFsKCkpO1xuICB9XG4gIHRyYW5zZm9ybShmbikge1xuICAgIGxldCBuZXh0ID0gdGhpcy5jbG9uZSgpO1xuICAgIG5leHQudHJhbnNmb3Jtcy5wdXNoKGZuKTtcbiAgICByZXR1cm4gbmV4dDtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIGEgdGVzdCBmdW5jdGlvbiB0byB0aGUgc2NoZW1hJ3MgcXVldWUgb2YgdGVzdHMuXG4gICAqIHRlc3RzIGNhbiBiZSBleGNsdXNpdmUgb3Igbm9uLWV4Y2x1c2l2ZS5cbiAgICpcbiAgICogLSBleGNsdXNpdmUgdGVzdHMsIHdpbGwgcmVwbGFjZSBhbnkgZXhpc3RpbmcgdGVzdHMgb2YgdGhlIHNhbWUgbmFtZS5cbiAgICogLSBub24tZXhjbHVzaXZlOiBjYW4gYmUgc3RhY2tlZFxuICAgKlxuICAgKiBJZiBhIG5vbi1leGNsdXNpdmUgdGVzdCBpcyBhZGRlZCB0byBhIHNjaGVtYSB3aXRoIGFuIGV4Y2x1c2l2ZSB0ZXN0IG9mIHRoZSBzYW1lIG5hbWVcbiAgICogdGhlIGV4Y2x1c2l2ZSB0ZXN0IGlzIHJlbW92ZWQgYW5kIGZ1cnRoZXIgdGVzdHMgb2YgdGhlIHNhbWUgbmFtZSB3aWxsIGJlIHN0YWNrZWQuXG4gICAqXG4gICAqIElmIGFuIGV4Y2x1c2l2ZSB0ZXN0IGlzIGFkZGVkIHRvIGEgc2NoZW1hIHdpdGggbm9uLWV4Y2x1c2l2ZSB0ZXN0cyBvZiB0aGUgc2FtZSBuYW1lXG4gICAqIHRoZSBwcmV2aW91cyB0ZXN0cyBhcmUgcmVtb3ZlZCBhbmQgZnVydGhlciB0ZXN0cyBvZiB0aGUgc2FtZSBuYW1lIHdpbGwgcmVwbGFjZSBlYWNoIG90aGVyLlxuICAgKi9cblxuICB0ZXN0KC4uLmFyZ3MpIHtcbiAgICBsZXQgb3B0cztcbiAgICBpZiAoYXJncy5sZW5ndGggPT09IDEpIHtcbiAgICAgIGlmICh0eXBlb2YgYXJnc1swXSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBvcHRzID0ge1xuICAgICAgICAgIHRlc3Q6IGFyZ3NbMF1cbiAgICAgICAgfTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG9wdHMgPSBhcmdzWzBdO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoYXJncy5sZW5ndGggPT09IDIpIHtcbiAgICAgIG9wdHMgPSB7XG4gICAgICAgIG5hbWU6IGFyZ3NbMF0sXG4gICAgICAgIHRlc3Q6IGFyZ3NbMV1cbiAgICAgIH07XG4gICAgfSBlbHNlIHtcbiAgICAgIG9wdHMgPSB7XG4gICAgICAgIG5hbWU6IGFyZ3NbMF0sXG4gICAgICAgIG1lc3NhZ2U6IGFyZ3NbMV0sXG4gICAgICAgIHRlc3Q6IGFyZ3NbMl1cbiAgICAgIH07XG4gICAgfVxuICAgIGlmIChvcHRzLm1lc3NhZ2UgPT09IHVuZGVmaW5lZCkgb3B0cy5tZXNzYWdlID0gbWl4ZWQuZGVmYXVsdDtcbiAgICBpZiAodHlwZW9mIG9wdHMudGVzdCAhPT0gJ2Z1bmN0aW9uJykgdGhyb3cgbmV3IFR5cGVFcnJvcignYHRlc3RgIGlzIGEgcmVxdWlyZWQgcGFyYW1ldGVycycpO1xuICAgIGxldCBuZXh0ID0gdGhpcy5jbG9uZSgpO1xuICAgIGxldCB2YWxpZGF0ZSA9IGNyZWF0ZVZhbGlkYXRpb24ob3B0cyk7XG4gICAgbGV0IGlzRXhjbHVzaXZlID0gb3B0cy5leGNsdXNpdmUgfHwgb3B0cy5uYW1lICYmIG5leHQuZXhjbHVzaXZlVGVzdHNbb3B0cy5uYW1lXSA9PT0gdHJ1ZTtcbiAgICBpZiAob3B0cy5leGNsdXNpdmUpIHtcbiAgICAgIGlmICghb3B0cy5uYW1lKSB0aHJvdyBuZXcgVHlwZUVycm9yKCdFeGNsdXNpdmUgdGVzdHMgbXVzdCBwcm92aWRlIGEgdW5pcXVlIGBuYW1lYCBpZGVudGlmeWluZyB0aGUgdGVzdCcpO1xuICAgIH1cbiAgICBpZiAob3B0cy5uYW1lKSBuZXh0LmV4Y2x1c2l2ZVRlc3RzW29wdHMubmFtZV0gPSAhIW9wdHMuZXhjbHVzaXZlO1xuICAgIG5leHQudGVzdHMgPSBuZXh0LnRlc3RzLmZpbHRlcihmbiA9PiB7XG4gICAgICBpZiAoZm4uT1BUSU9OUy5uYW1lID09PSBvcHRzLm5hbWUpIHtcbiAgICAgICAgaWYgKGlzRXhjbHVzaXZlKSByZXR1cm4gZmFsc2U7XG4gICAgICAgIGlmIChmbi5PUFRJT05TLnRlc3QgPT09IHZhbGlkYXRlLk9QVElPTlMudGVzdCkgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSk7XG4gICAgbmV4dC50ZXN0cy5wdXNoKHZhbGlkYXRlKTtcbiAgICByZXR1cm4gbmV4dDtcbiAgfVxuICB3aGVuKGtleXMsIG9wdGlvbnMpIHtcbiAgICBpZiAoIUFycmF5LmlzQXJyYXkoa2V5cykgJiYgdHlwZW9mIGtleXMgIT09ICdzdHJpbmcnKSB7XG4gICAgICBvcHRpb25zID0ga2V5cztcbiAgICAgIGtleXMgPSAnLic7XG4gICAgfVxuICAgIGxldCBuZXh0ID0gdGhpcy5jbG9uZSgpO1xuICAgIGxldCBkZXBzID0gdG9BcnJheShrZXlzKS5tYXAoa2V5ID0+IG5ldyBSZWZlcmVuY2Uoa2V5KSk7XG4gICAgZGVwcy5mb3JFYWNoKGRlcCA9PiB7XG4gICAgICAvLyBAdHMtaWdub3JlIHJlYWRvbmx5IGFycmF5XG4gICAgICBpZiAoZGVwLmlzU2libGluZykgbmV4dC5kZXBzLnB1c2goZGVwLmtleSk7XG4gICAgfSk7XG4gICAgbmV4dC5jb25kaXRpb25zLnB1c2godHlwZW9mIG9wdGlvbnMgPT09ICdmdW5jdGlvbicgPyBuZXcgQ29uZGl0aW9uKGRlcHMsIG9wdGlvbnMpIDogQ29uZGl0aW9uLmZyb21PcHRpb25zKGRlcHMsIG9wdGlvbnMpKTtcbiAgICByZXR1cm4gbmV4dDtcbiAgfVxuICB0eXBlRXJyb3IobWVzc2FnZSkge1xuICAgIGxldCBuZXh0ID0gdGhpcy5jbG9uZSgpO1xuICAgIG5leHQuaW50ZXJuYWxUZXN0cy50eXBlRXJyb3IgPSBjcmVhdGVWYWxpZGF0aW9uKHtcbiAgICAgIG1lc3NhZ2UsXG4gICAgICBuYW1lOiAndHlwZUVycm9yJyxcbiAgICAgIHNraXBBYnNlbnQ6IHRydWUsXG4gICAgICB0ZXN0KHZhbHVlKSB7XG4gICAgICAgIGlmICghdGhpcy5zY2hlbWEuX3R5cGVDaGVjayh2YWx1ZSkpIHJldHVybiB0aGlzLmNyZWF0ZUVycm9yKHtcbiAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgIHR5cGU6IHRoaXMuc2NoZW1hLnR5cGVcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gbmV4dDtcbiAgfVxuICBvbmVPZihlbnVtcywgbWVzc2FnZSA9IG1peGVkLm9uZU9mKSB7XG4gICAgbGV0IG5leHQgPSB0aGlzLmNsb25lKCk7XG4gICAgZW51bXMuZm9yRWFjaCh2YWwgPT4ge1xuICAgICAgbmV4dC5fd2hpdGVsaXN0LmFkZCh2YWwpO1xuICAgICAgbmV4dC5fYmxhY2tsaXN0LmRlbGV0ZSh2YWwpO1xuICAgIH0pO1xuICAgIG5leHQuaW50ZXJuYWxUZXN0cy53aGl0ZUxpc3QgPSBjcmVhdGVWYWxpZGF0aW9uKHtcbiAgICAgIG1lc3NhZ2UsXG4gICAgICBuYW1lOiAnb25lT2YnLFxuICAgICAgc2tpcEFic2VudDogdHJ1ZSxcbiAgICAgIHRlc3QodmFsdWUpIHtcbiAgICAgICAgbGV0IHZhbGlkcyA9IHRoaXMuc2NoZW1hLl93aGl0ZWxpc3Q7XG4gICAgICAgIGxldCByZXNvbHZlZCA9IHZhbGlkcy5yZXNvbHZlQWxsKHRoaXMucmVzb2x2ZSk7XG4gICAgICAgIHJldHVybiByZXNvbHZlZC5pbmNsdWRlcyh2YWx1ZSkgPyB0cnVlIDogdGhpcy5jcmVhdGVFcnJvcih7XG4gICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICB2YWx1ZXM6IEFycmF5LmZyb20odmFsaWRzKS5qb2luKCcsICcpLFxuICAgICAgICAgICAgcmVzb2x2ZWRcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBuZXh0O1xuICB9XG4gIG5vdE9uZU9mKGVudW1zLCBtZXNzYWdlID0gbWl4ZWQubm90T25lT2YpIHtcbiAgICBsZXQgbmV4dCA9IHRoaXMuY2xvbmUoKTtcbiAgICBlbnVtcy5mb3JFYWNoKHZhbCA9PiB7XG4gICAgICBuZXh0Ll9ibGFja2xpc3QuYWRkKHZhbCk7XG4gICAgICBuZXh0Ll93aGl0ZWxpc3QuZGVsZXRlKHZhbCk7XG4gICAgfSk7XG4gICAgbmV4dC5pbnRlcm5hbFRlc3RzLmJsYWNrbGlzdCA9IGNyZWF0ZVZhbGlkYXRpb24oe1xuICAgICAgbWVzc2FnZSxcbiAgICAgIG5hbWU6ICdub3RPbmVPZicsXG4gICAgICB0ZXN0KHZhbHVlKSB7XG4gICAgICAgIGxldCBpbnZhbGlkcyA9IHRoaXMuc2NoZW1hLl9ibGFja2xpc3Q7XG4gICAgICAgIGxldCByZXNvbHZlZCA9IGludmFsaWRzLnJlc29sdmVBbGwodGhpcy5yZXNvbHZlKTtcbiAgICAgICAgaWYgKHJlc29sdmVkLmluY2x1ZGVzKHZhbHVlKSkgcmV0dXJuIHRoaXMuY3JlYXRlRXJyb3Ioe1xuICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgdmFsdWVzOiBBcnJheS5mcm9tKGludmFsaWRzKS5qb2luKCcsICcpLFxuICAgICAgICAgICAgcmVzb2x2ZWRcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gbmV4dDtcbiAgfVxuICBzdHJpcChzdHJpcCA9IHRydWUpIHtcbiAgICBsZXQgbmV4dCA9IHRoaXMuY2xvbmUoKTtcbiAgICBuZXh0LnNwZWMuc3RyaXAgPSBzdHJpcDtcbiAgICByZXR1cm4gbmV4dDtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gYSBzZXJpYWxpemVkIGRlc2NyaXB0aW9uIG9mIHRoZSBzY2hlbWEgaW5jbHVkaW5nIHZhbGlkYXRpb25zLCBmbGFncywgdHlwZXMgZXRjLlxuICAgKlxuICAgKiBAcGFyYW0gb3B0aW9ucyBQcm92aWRlIGFueSBuZWVkZWQgY29udGV4dCBmb3IgcmVzb2x2aW5nIHJ1bnRpbWUgc2NoZW1hIGFsdGVyYXRpb25zIChsYXp5LCB3aGVuIGNvbmRpdGlvbnMsIGV0YykuXG4gICAqL1xuICBkZXNjcmliZShvcHRpb25zKSB7XG4gICAgY29uc3QgbmV4dCA9IChvcHRpb25zID8gdGhpcy5yZXNvbHZlKG9wdGlvbnMpIDogdGhpcykuY2xvbmUoKTtcbiAgICBjb25zdCB7XG4gICAgICBsYWJlbCxcbiAgICAgIG1ldGEsXG4gICAgICBvcHRpb25hbCxcbiAgICAgIG51bGxhYmxlXG4gICAgfSA9IG5leHQuc3BlYztcbiAgICBjb25zdCBkZXNjcmlwdGlvbiA9IHtcbiAgICAgIG1ldGEsXG4gICAgICBsYWJlbCxcbiAgICAgIG9wdGlvbmFsLFxuICAgICAgbnVsbGFibGUsXG4gICAgICBkZWZhdWx0OiBuZXh0LmdldERlZmF1bHQob3B0aW9ucyksXG4gICAgICB0eXBlOiBuZXh0LnR5cGUsXG4gICAgICBvbmVPZjogbmV4dC5fd2hpdGVsaXN0LmRlc2NyaWJlKCksXG4gICAgICBub3RPbmVPZjogbmV4dC5fYmxhY2tsaXN0LmRlc2NyaWJlKCksXG4gICAgICB0ZXN0czogbmV4dC50ZXN0cy5maWx0ZXIoKG4sIGlkeCwgbGlzdCkgPT4gbGlzdC5maW5kSW5kZXgoYyA9PiBjLk9QVElPTlMubmFtZSA9PT0gbi5PUFRJT05TLm5hbWUpID09PSBpZHgpLm1hcChmbiA9PiB7XG4gICAgICAgIGNvbnN0IHBhcmFtcyA9IGZuLk9QVElPTlMucGFyYW1zICYmIG9wdGlvbnMgPyByZXNvbHZlUGFyYW1zKE9iamVjdC5hc3NpZ24oe30sIGZuLk9QVElPTlMucGFyYW1zKSwgb3B0aW9ucykgOiBmbi5PUFRJT05TLnBhcmFtcztcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBuYW1lOiBmbi5PUFRJT05TLm5hbWUsXG4gICAgICAgICAgcGFyYW1zXG4gICAgICAgIH07XG4gICAgICB9KVxuICAgIH07XG4gICAgcmV0dXJuIGRlc2NyaXB0aW9uO1xuICB9XG4gIGdldCBbJ35zdGFuZGFyZCddKCkge1xuICAgIGNvbnN0IHNjaGVtYSA9IHRoaXM7XG4gICAgY29uc3Qgc3RhbmRhcmQgPSB7XG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAgdmVuZG9yOiAneXVwJyxcbiAgICAgIGFzeW5jIHZhbGlkYXRlKHZhbHVlKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgc2NoZW1hLnZhbGlkYXRlKHZhbHVlLCB7XG4gICAgICAgICAgICBhYm9ydEVhcmx5OiBmYWxzZVxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB2YWx1ZTogcmVzdWx0XG4gICAgICAgICAgfTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIFZhbGlkYXRpb25FcnJvcikge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgaXNzdWVzOiBpc3N1ZXNGcm9tVmFsaWRhdGlvbkVycm9yKGVycilcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfVxuICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gICAgcmV0dXJuIHN0YW5kYXJkO1xuICB9XG59XG4vLyBAdHMtZXhwZWN0LWVycm9yXG5TY2hlbWEucHJvdG90eXBlLl9faXNZdXBTY2hlbWFfXyA9IHRydWU7XG5mb3IgKGNvbnN0IG1ldGhvZCBvZiBbJ3ZhbGlkYXRlJywgJ3ZhbGlkYXRlU3luYyddKSBTY2hlbWEucHJvdG90eXBlW2Ake21ldGhvZH1BdGBdID0gZnVuY3Rpb24gKHBhdGgsIHZhbHVlLCBvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIHBhcmVudCxcbiAgICBwYXJlbnRQYXRoLFxuICAgIHNjaGVtYVxuICB9ID0gZ2V0SW4odGhpcywgcGF0aCwgdmFsdWUsIG9wdGlvbnMuY29udGV4dCk7XG4gIHJldHVybiBzY2hlbWFbbWV0aG9kXShwYXJlbnQgJiYgcGFyZW50W3BhcmVudFBhdGhdLCBPYmplY3QuYXNzaWduKHt9LCBvcHRpb25zLCB7XG4gICAgcGFyZW50LFxuICAgIHBhdGhcbiAgfSkpO1xufTtcbmZvciAoY29uc3QgYWxpYXMgb2YgWydlcXVhbHMnLCAnaXMnXSkgU2NoZW1hLnByb3RvdHlwZVthbGlhc10gPSBTY2hlbWEucHJvdG90eXBlLm9uZU9mO1xuZm9yIChjb25zdCBhbGlhcyBvZiBbJ25vdCcsICdub3BlJ10pIFNjaGVtYS5wcm90b3R5cGVbYWxpYXNdID0gU2NoZW1hLnByb3RvdHlwZS5ub3RPbmVPZjtcblxuY29uc3QgcmV0dXJuc1RydWUgPSAoKSA9PiB0cnVlO1xuZnVuY3Rpb24gY3JlYXRlJDgoc3BlYykge1xuICByZXR1cm4gbmV3IE1peGVkU2NoZW1hKHNwZWMpO1xufVxuY2xhc3MgTWl4ZWRTY2hlbWEgZXh0ZW5kcyBTY2hlbWEge1xuICBjb25zdHJ1Y3RvcihzcGVjKSB7XG4gICAgc3VwZXIodHlwZW9mIHNwZWMgPT09ICdmdW5jdGlvbicgPyB7XG4gICAgICB0eXBlOiAnbWl4ZWQnLFxuICAgICAgY2hlY2s6IHNwZWNcbiAgICB9IDogT2JqZWN0LmFzc2lnbih7XG4gICAgICB0eXBlOiAnbWl4ZWQnLFxuICAgICAgY2hlY2s6IHJldHVybnNUcnVlXG4gICAgfSwgc3BlYykpO1xuICB9XG59XG5jcmVhdGUkOC5wcm90b3R5cGUgPSBNaXhlZFNjaGVtYS5wcm90b3R5cGU7XG5cbmZ1bmN0aW9uIGNyZWF0ZSQ3KCkge1xuICByZXR1cm4gbmV3IEJvb2xlYW5TY2hlbWEoKTtcbn1cbmNsYXNzIEJvb2xlYW5TY2hlbWEgZXh0ZW5kcyBTY2hlbWEge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcih7XG4gICAgICB0eXBlOiAnYm9vbGVhbicsXG4gICAgICBjaGVjayh2KSB7XG4gICAgICAgIGlmICh2IGluc3RhbmNlb2YgQm9vbGVhbikgdiA9IHYudmFsdWVPZigpO1xuICAgICAgICByZXR1cm4gdHlwZW9mIHYgPT09ICdib29sZWFuJztcbiAgICAgIH1cbiAgICB9KTtcbiAgICB0aGlzLndpdGhNdXRhdGlvbigoKSA9PiB7XG4gICAgICB0aGlzLnRyYW5zZm9ybSgodmFsdWUsIF9yYXcpID0+IHtcbiAgICAgICAgaWYgKHRoaXMuc3BlYy5jb2VyY2UgJiYgIXRoaXMuaXNUeXBlKHZhbHVlKSkge1xuICAgICAgICAgIGlmICgvXih0cnVlfDEpJC9pLnRlc3QoU3RyaW5nKHZhbHVlKSkpIHJldHVybiB0cnVlO1xuICAgICAgICAgIGlmICgvXihmYWxzZXwwKSQvaS50ZXN0KFN0cmluZyh2YWx1ZSkpKSByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbiAgaXNUcnVlKG1lc3NhZ2UgPSBib29sZWFuLmlzVmFsdWUpIHtcbiAgICByZXR1cm4gdGhpcy50ZXN0KHtcbiAgICAgIG1lc3NhZ2UsXG4gICAgICBuYW1lOiAnaXMtdmFsdWUnLFxuICAgICAgZXhjbHVzaXZlOiB0cnVlLFxuICAgICAgcGFyYW1zOiB7XG4gICAgICAgIHZhbHVlOiAndHJ1ZSdcbiAgICAgIH0sXG4gICAgICB0ZXN0KHZhbHVlKSB7XG4gICAgICAgIHJldHVybiBpc0Fic2VudCh2YWx1ZSkgfHwgdmFsdWUgPT09IHRydWU7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgaXNGYWxzZShtZXNzYWdlID0gYm9vbGVhbi5pc1ZhbHVlKSB7XG4gICAgcmV0dXJuIHRoaXMudGVzdCh7XG4gICAgICBtZXNzYWdlLFxuICAgICAgbmFtZTogJ2lzLXZhbHVlJyxcbiAgICAgIGV4Y2x1c2l2ZTogdHJ1ZSxcbiAgICAgIHBhcmFtczoge1xuICAgICAgICB2YWx1ZTogJ2ZhbHNlJ1xuICAgICAgfSxcbiAgICAgIHRlc3QodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIGlzQWJzZW50KHZhbHVlKSB8fCB2YWx1ZSA9PT0gZmFsc2U7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgZGVmYXVsdChkZWYpIHtcbiAgICByZXR1cm4gc3VwZXIuZGVmYXVsdChkZWYpO1xuICB9XG4gIGRlZmluZWQobXNnKSB7XG4gICAgcmV0dXJuIHN1cGVyLmRlZmluZWQobXNnKTtcbiAgfVxuICBvcHRpb25hbCgpIHtcbiAgICByZXR1cm4gc3VwZXIub3B0aW9uYWwoKTtcbiAgfVxuICByZXF1aXJlZChtc2cpIHtcbiAgICByZXR1cm4gc3VwZXIucmVxdWlyZWQobXNnKTtcbiAgfVxuICBub3RSZXF1aXJlZCgpIHtcbiAgICByZXR1cm4gc3VwZXIubm90UmVxdWlyZWQoKTtcbiAgfVxuICBudWxsYWJsZSgpIHtcbiAgICByZXR1cm4gc3VwZXIubnVsbGFibGUoKTtcbiAgfVxuICBub25OdWxsYWJsZShtc2cpIHtcbiAgICByZXR1cm4gc3VwZXIubm9uTnVsbGFibGUobXNnKTtcbiAgfVxuICBzdHJpcCh2KSB7XG4gICAgcmV0dXJuIHN1cGVyLnN0cmlwKHYpO1xuICB9XG59XG5jcmVhdGUkNy5wcm90b3R5cGUgPSBCb29sZWFuU2NoZW1hLnByb3RvdHlwZTtcblxuLyoqXG4gKiBUaGlzIGZpbGUgaXMgYSBtb2RpZmllZCB2ZXJzaW9uIG9mIHRoZSBmaWxlIGZyb20gdGhlIGZvbGxvd2luZyByZXBvc2l0b3J5OlxuICogRGF0ZS5wYXJzZSB3aXRoIHByb2dyZXNzaXZlIGVuaGFuY2VtZW50IGZvciBJU08gODYwMSA8aHR0cHM6Ly9naXRodWIuY29tL2Nzbm92ZXIvanMtaXNvODYwMT5cbiAqIE5PTi1DT05GT1JNQU5UIEVESVRJT04uXG4gKiDCqSAyMDExIENvbGluIFNub3ZlciA8aHR0cDovL3pldGFmbGVldC5jb20+XG4gKiBSZWxlYXNlZCB1bmRlciBNSVQgbGljZW5zZS5cbiAqL1xuXG4vLyBwcmV0dGllci1pZ25vcmVcbi8vICAgICAgICAgICAgICAgIDEgWVlZWSAgICAgICAgICAgICAgICAyIE1NICAgICAgICAzIEREICAgICAgICAgICAgICA0IEhIICAgICA1IG1tICAgICAgICA2IHNzICAgICAgICAgICA3IG1zZWMgICAgICAgICA4IFogOSDCsSAgIDEwIHR6SEggICAgMTEgdHptbVxuY29uc3QgaXNvUmVnID0gL14oXFxkezR9fFsrLV1cXGR7Nn0pKD86LT8oXFxkezJ9KSg/Oi0/KFxcZHsyfSkpPyk/KD86WyBUXT8oXFxkezJ9KTo/KFxcZHsyfSkoPzo6PyhcXGR7Mn0pKD86WywuXShcXGR7MSx9KSk/KT8oPzooWil8KFsrLV0pKFxcZHsyfSkoPzo6PyhcXGR7Mn0pKT8pPyk/JC87XG5mdW5jdGlvbiBwYXJzZUlzb0RhdGUoZGF0ZSkge1xuICBjb25zdCBzdHJ1Y3QgPSBwYXJzZURhdGVTdHJ1Y3QoZGF0ZSk7XG4gIGlmICghc3RydWN0KSByZXR1cm4gRGF0ZS5wYXJzZSA/IERhdGUucGFyc2UoZGF0ZSkgOiBOdW1iZXIuTmFOO1xuXG4gIC8vIHRpbWVzdGFtcHMgd2l0aG91dCB0aW1lem9uZSBpZGVudGlmaWVycyBzaG91bGQgYmUgY29uc2lkZXJlZCBsb2NhbCB0aW1lXG4gIGlmIChzdHJ1Y3QueiA9PT0gdW5kZWZpbmVkICYmIHN0cnVjdC5wbHVzTWludXMgPT09IHVuZGVmaW5lZCkge1xuICAgIHJldHVybiBuZXcgRGF0ZShzdHJ1Y3QueWVhciwgc3RydWN0Lm1vbnRoLCBzdHJ1Y3QuZGF5LCBzdHJ1Y3QuaG91ciwgc3RydWN0Lm1pbnV0ZSwgc3RydWN0LnNlY29uZCwgc3RydWN0Lm1pbGxpc2Vjb25kKS52YWx1ZU9mKCk7XG4gIH1cbiAgbGV0IHRvdGFsTWludXRlc09mZnNldCA9IDA7XG4gIGlmIChzdHJ1Y3QueiAhPT0gJ1onICYmIHN0cnVjdC5wbHVzTWludXMgIT09IHVuZGVmaW5lZCkge1xuICAgIHRvdGFsTWludXRlc09mZnNldCA9IHN0cnVjdC5ob3VyT2Zmc2V0ICogNjAgKyBzdHJ1Y3QubWludXRlT2Zmc2V0O1xuICAgIGlmIChzdHJ1Y3QucGx1c01pbnVzID09PSAnKycpIHRvdGFsTWludXRlc09mZnNldCA9IDAgLSB0b3RhbE1pbnV0ZXNPZmZzZXQ7XG4gIH1cbiAgcmV0dXJuIERhdGUuVVRDKHN0cnVjdC55ZWFyLCBzdHJ1Y3QubW9udGgsIHN0cnVjdC5kYXksIHN0cnVjdC5ob3VyLCBzdHJ1Y3QubWludXRlICsgdG90YWxNaW51dGVzT2Zmc2V0LCBzdHJ1Y3Quc2Vjb25kLCBzdHJ1Y3QubWlsbGlzZWNvbmQpO1xufVxuZnVuY3Rpb24gcGFyc2VEYXRlU3RydWN0KGRhdGUpIHtcbiAgdmFyIF9yZWdleFJlc3VsdCQ3JGxlbmd0aCwgX3JlZ2V4UmVzdWx0JDtcbiAgY29uc3QgcmVnZXhSZXN1bHQgPSBpc29SZWcuZXhlYyhkYXRlKTtcbiAgaWYgKCFyZWdleFJlc3VsdCkgcmV0dXJuIG51bGw7XG5cbiAgLy8gdXNlIG9mIHRvTnVtYmVyKCkgYXZvaWRzIE5hTiB0aW1lc3RhbXBzIGNhdXNlZCBieSDigJx1bmRlZmluZWTigJ1cbiAgLy8gdmFsdWVzIGJlaW5nIHBhc3NlZCB0byBEYXRlIGNvbnN0cnVjdG9yXG4gIHJldHVybiB7XG4gICAgeWVhcjogdG9OdW1iZXIocmVnZXhSZXN1bHRbMV0pLFxuICAgIG1vbnRoOiB0b051bWJlcihyZWdleFJlc3VsdFsyXSwgMSkgLSAxLFxuICAgIGRheTogdG9OdW1iZXIocmVnZXhSZXN1bHRbM10sIDEpLFxuICAgIGhvdXI6IHRvTnVtYmVyKHJlZ2V4UmVzdWx0WzRdKSxcbiAgICBtaW51dGU6IHRvTnVtYmVyKHJlZ2V4UmVzdWx0WzVdKSxcbiAgICBzZWNvbmQ6IHRvTnVtYmVyKHJlZ2V4UmVzdWx0WzZdKSxcbiAgICBtaWxsaXNlY29uZDogcmVnZXhSZXN1bHRbN10gP1xuICAgIC8vIGFsbG93IGFyYml0cmFyeSBzdWItc2Vjb25kIHByZWNpc2lvbiBiZXlvbmQgbWlsbGlzZWNvbmRzXG4gICAgdG9OdW1iZXIocmVnZXhSZXN1bHRbN10uc3Vic3RyaW5nKDAsIDMpKSA6IDAsXG4gICAgcHJlY2lzaW9uOiAoX3JlZ2V4UmVzdWx0JDckbGVuZ3RoID0gKF9yZWdleFJlc3VsdCQgPSByZWdleFJlc3VsdFs3XSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9yZWdleFJlc3VsdCQubGVuZ3RoKSAhPSBudWxsID8gX3JlZ2V4UmVzdWx0JDckbGVuZ3RoIDogdW5kZWZpbmVkLFxuICAgIHo6IHJlZ2V4UmVzdWx0WzhdIHx8IHVuZGVmaW5lZCxcbiAgICBwbHVzTWludXM6IHJlZ2V4UmVzdWx0WzldIHx8IHVuZGVmaW5lZCxcbiAgICBob3VyT2Zmc2V0OiB0b051bWJlcihyZWdleFJlc3VsdFsxMF0pLFxuICAgIG1pbnV0ZU9mZnNldDogdG9OdW1iZXIocmVnZXhSZXN1bHRbMTFdKVxuICB9O1xufVxuZnVuY3Rpb24gdG9OdW1iZXIoc3RyLCBkZWZhdWx0VmFsdWUgPSAwKSB7XG4gIHJldHVybiBOdW1iZXIoc3RyKSB8fCBkZWZhdWx0VmFsdWU7XG59XG5cbi8vIFRha2VuIGZyb20gSFRNTCBzcGVjOiBodHRwczovL2h0bWwuc3BlYy53aGF0d2cub3JnL211bHRpcGFnZS9pbnB1dC5odG1sI3ZhbGlkLWUtbWFpbC1hZGRyZXNzXG5sZXQgckVtYWlsID1cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZVxuL15bYS16QS1aMC05LiEjJCUmJyorXFwvPT9eX2B7fH1+LV0rQFthLXpBLVowLTldKD86W2EtekEtWjAtOS1dezAsNjF9W2EtekEtWjAtOV0pPyg/OlxcLlthLXpBLVowLTldKD86W2EtekEtWjAtOS1dezAsNjF9W2EtekEtWjAtOV0pPykqJC87XG5sZXQgclVybCA9XG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmVcbi9eKChodHRwcz98ZnRwKTopP1xcL1xcLygoKChbYS16XXxcXGR8LXxcXC58X3x+fFtcXHUwMEEwLVxcdUQ3RkZcXHVGOTAwLVxcdUZEQ0ZcXHVGREYwLVxcdUZGRUZdKXwoJVtcXGRhLWZdezJ9KXxbIVxcJCYnXFwoXFwpXFwqXFwrLDs9XXw6KSpAKT8oKChcXGR8WzEtOV1cXGR8MVxcZFxcZHwyWzAtNF1cXGR8MjVbMC01XSlcXC4oXFxkfFsxLTldXFxkfDFcXGRcXGR8MlswLTRdXFxkfDI1WzAtNV0pXFwuKFxcZHxbMS05XVxcZHwxXFxkXFxkfDJbMC00XVxcZHwyNVswLTVdKVxcLihcXGR8WzEtOV1cXGR8MVxcZFxcZHwyWzAtNF1cXGR8MjVbMC01XSkpfCgoKFthLXpdfFxcZHxbXFx1MDBBMC1cXHVEN0ZGXFx1RjkwMC1cXHVGRENGXFx1RkRGMC1cXHVGRkVGXSl8KChbYS16XXxcXGR8W1xcdTAwQTAtXFx1RDdGRlxcdUY5MDAtXFx1RkRDRlxcdUZERjAtXFx1RkZFRl0pKFthLXpdfFxcZHwtfFxcLnxffH58W1xcdTAwQTAtXFx1RDdGRlxcdUY5MDAtXFx1RkRDRlxcdUZERjAtXFx1RkZFRl0pKihbYS16XXxcXGR8W1xcdTAwQTAtXFx1RDdGRlxcdUY5MDAtXFx1RkRDRlxcdUZERjAtXFx1RkZFRl0pKSlcXC4pKygoW2Etel18W1xcdTAwQTAtXFx1RDdGRlxcdUY5MDAtXFx1RkRDRlxcdUZERjAtXFx1RkZFRl0pfCgoW2Etel18W1xcdTAwQTAtXFx1RDdGRlxcdUY5MDAtXFx1RkRDRlxcdUZERjAtXFx1RkZFRl0pKFthLXpdfFxcZHwtfFxcLnxffH58W1xcdTAwQTAtXFx1RDdGRlxcdUY5MDAtXFx1RkRDRlxcdUZERjAtXFx1RkZFRl0pKihbYS16XXxbXFx1MDBBMC1cXHVEN0ZGXFx1RjkwMC1cXHVGRENGXFx1RkRGMC1cXHVGRkVGXSkpKVxcLj8pKDpcXGQqKT8pKFxcLygoKFthLXpdfFxcZHwtfFxcLnxffH58W1xcdTAwQTAtXFx1RDdGRlxcdUY5MDAtXFx1RkRDRlxcdUZERjAtXFx1RkZFRl0pfCglW1xcZGEtZl17Mn0pfFshXFwkJidcXChcXClcXCpcXCssOz1dfDp8QCkrKFxcLygoW2Etel18XFxkfC18XFwufF98fnxbXFx1MDBBMC1cXHVEN0ZGXFx1RjkwMC1cXHVGRENGXFx1RkRGMC1cXHVGRkVGXSl8KCVbXFxkYS1mXXsyfSl8WyFcXCQmJ1xcKFxcKVxcKlxcKyw7PV18OnxAKSopKik/KT8oXFw/KCgoW2Etel18XFxkfC18XFwufF98fnxbXFx1MDBBMC1cXHVEN0ZGXFx1RjkwMC1cXHVGRENGXFx1RkRGMC1cXHVGRkVGXSl8KCVbXFxkYS1mXXsyfSl8WyFcXCQmJ1xcKFxcKVxcKlxcKyw7PV18OnxAKXxbXFx1RTAwMC1cXHVGOEZGXXxcXC98XFw/KSopPyhcXCMoKChbYS16XXxcXGR8LXxcXC58X3x+fFtcXHUwMEEwLVxcdUQ3RkZcXHVGOTAwLVxcdUZEQ0ZcXHVGREYwLVxcdUZGRUZdKXwoJVtcXGRhLWZdezJ9KXxbIVxcJCYnXFwoXFwpXFwqXFwrLDs9XXw6fEApfFxcL3xcXD8pKik/JC9pO1xuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmVcbmxldCByVVVJRCA9IC9eKD86WzAtOWEtZl17OH0tWzAtOWEtZl17NH0tWzEtNV1bMC05YS1mXXszfS1bODlhYl1bMC05YS1mXXszfS1bMC05YS1mXXsxMn18MDAwMDAwMDAtMDAwMC0wMDAwLTAwMDAtMDAwMDAwMDAwMDAwKSQvaTtcbmxldCB5ZWFyTW9udGhEYXkgPSAnXlxcXFxkezR9LVxcXFxkezJ9LVxcXFxkezJ9JztcbmxldCBob3VyTWludXRlU2Vjb25kID0gJ1xcXFxkezJ9OlxcXFxkezJ9OlxcXFxkezJ9JztcbmxldCB6T3JPZmZzZXQgPSAnKChbKy1dXFxcXGR7Mn0oOj9cXFxcZHsyfSk/KXxaKSc7XG5sZXQgcklzb0RhdGVUaW1lID0gbmV3IFJlZ0V4cChgJHt5ZWFyTW9udGhEYXl9VCR7aG91ck1pbnV0ZVNlY29uZH0oXFxcXC5cXFxcZCspPyR7ek9yT2Zmc2V0fSRgKTtcbmxldCBpc1RyaW1tZWQgPSB2YWx1ZSA9PiBpc0Fic2VudCh2YWx1ZSkgfHwgdmFsdWUgPT09IHZhbHVlLnRyaW0oKTtcbmxldCBvYmpTdHJpbmdUYWcgPSB7fS50b1N0cmluZygpO1xuZnVuY3Rpb24gY3JlYXRlJDYoKSB7XG4gIHJldHVybiBuZXcgU3RyaW5nU2NoZW1hKCk7XG59XG5jbGFzcyBTdHJpbmdTY2hlbWEgZXh0ZW5kcyBTY2hlbWEge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcih7XG4gICAgICB0eXBlOiAnc3RyaW5nJyxcbiAgICAgIGNoZWNrKHZhbHVlKSB7XG4gICAgICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIFN0cmluZykgdmFsdWUgPSB2YWx1ZS52YWx1ZU9mKCk7XG4gICAgICAgIHJldHVybiB0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHRoaXMud2l0aE11dGF0aW9uKCgpID0+IHtcbiAgICAgIHRoaXMudHJhbnNmb3JtKCh2YWx1ZSwgX3JhdykgPT4ge1xuICAgICAgICBpZiAoIXRoaXMuc3BlYy5jb2VyY2UgfHwgdGhpcy5pc1R5cGUodmFsdWUpKSByZXR1cm4gdmFsdWU7XG5cbiAgICAgICAgLy8gZG9uJ3QgZXZlciBjb252ZXJ0IGFycmF5c1xuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHJldHVybiB2YWx1ZTtcbiAgICAgICAgY29uc3Qgc3RyVmFsdWUgPSB2YWx1ZSAhPSBudWxsICYmIHZhbHVlLnRvU3RyaW5nID8gdmFsdWUudG9TdHJpbmcoKSA6IHZhbHVlO1xuXG4gICAgICAgIC8vIG5vIG9uZSB3YW50cyBwbGFpbiBvYmplY3RzIGNvbnZlcnRlZCB0byBbT2JqZWN0IG9iamVjdF1cbiAgICAgICAgaWYgKHN0clZhbHVlID09PSBvYmpTdHJpbmdUYWcpIHJldHVybiB2YWx1ZTtcbiAgICAgICAgcmV0dXJuIHN0clZhbHVlO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbiAgcmVxdWlyZWQobWVzc2FnZSkge1xuICAgIHJldHVybiBzdXBlci5yZXF1aXJlZChtZXNzYWdlKS53aXRoTXV0YXRpb24oc2NoZW1hID0+IHNjaGVtYS50ZXN0KHtcbiAgICAgIG1lc3NhZ2U6IG1lc3NhZ2UgfHwgbWl4ZWQucmVxdWlyZWQsXG4gICAgICBuYW1lOiAncmVxdWlyZWQnLFxuICAgICAgc2tpcEFic2VudDogdHJ1ZSxcbiAgICAgIHRlc3Q6IHZhbHVlID0+ICEhdmFsdWUubGVuZ3RoXG4gICAgfSkpO1xuICB9XG4gIG5vdFJlcXVpcmVkKCkge1xuICAgIHJldHVybiBzdXBlci5ub3RSZXF1aXJlZCgpLndpdGhNdXRhdGlvbihzY2hlbWEgPT4ge1xuICAgICAgc2NoZW1hLnRlc3RzID0gc2NoZW1hLnRlc3RzLmZpbHRlcih0ID0+IHQuT1BUSU9OUy5uYW1lICE9PSAncmVxdWlyZWQnKTtcbiAgICAgIHJldHVybiBzY2hlbWE7XG4gICAgfSk7XG4gIH1cbiAgbGVuZ3RoKGxlbmd0aCwgbWVzc2FnZSA9IHN0cmluZy5sZW5ndGgpIHtcbiAgICByZXR1cm4gdGhpcy50ZXN0KHtcbiAgICAgIG1lc3NhZ2UsXG4gICAgICBuYW1lOiAnbGVuZ3RoJyxcbiAgICAgIGV4Y2x1c2l2ZTogdHJ1ZSxcbiAgICAgIHBhcmFtczoge1xuICAgICAgICBsZW5ndGhcbiAgICAgIH0sXG4gICAgICBza2lwQWJzZW50OiB0cnVlLFxuICAgICAgdGVzdCh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUubGVuZ3RoID09PSB0aGlzLnJlc29sdmUobGVuZ3RoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICBtaW4obWluLCBtZXNzYWdlID0gc3RyaW5nLm1pbikge1xuICAgIHJldHVybiB0aGlzLnRlc3Qoe1xuICAgICAgbWVzc2FnZSxcbiAgICAgIG5hbWU6ICdtaW4nLFxuICAgICAgZXhjbHVzaXZlOiB0cnVlLFxuICAgICAgcGFyYW1zOiB7XG4gICAgICAgIG1pblxuICAgICAgfSxcbiAgICAgIHNraXBBYnNlbnQ6IHRydWUsXG4gICAgICB0ZXN0KHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZS5sZW5ndGggPj0gdGhpcy5yZXNvbHZlKG1pbik7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgbWF4KG1heCwgbWVzc2FnZSA9IHN0cmluZy5tYXgpIHtcbiAgICByZXR1cm4gdGhpcy50ZXN0KHtcbiAgICAgIG5hbWU6ICdtYXgnLFxuICAgICAgZXhjbHVzaXZlOiB0cnVlLFxuICAgICAgbWVzc2FnZSxcbiAgICAgIHBhcmFtczoge1xuICAgICAgICBtYXhcbiAgICAgIH0sXG4gICAgICBza2lwQWJzZW50OiB0cnVlLFxuICAgICAgdGVzdCh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUubGVuZ3RoIDw9IHRoaXMucmVzb2x2ZShtYXgpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIG1hdGNoZXMocmVnZXgsIG9wdGlvbnMpIHtcbiAgICBsZXQgZXhjbHVkZUVtcHR5U3RyaW5nID0gZmFsc2U7XG4gICAgbGV0IG1lc3NhZ2U7XG4gICAgbGV0IG5hbWU7XG4gICAgaWYgKG9wdGlvbnMpIHtcbiAgICAgIGlmICh0eXBlb2Ygb3B0aW9ucyA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgKHtcbiAgICAgICAgICBleGNsdWRlRW1wdHlTdHJpbmcgPSBmYWxzZSxcbiAgICAgICAgICBtZXNzYWdlLFxuICAgICAgICAgIG5hbWVcbiAgICAgICAgfSA9IG9wdGlvbnMpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbWVzc2FnZSA9IG9wdGlvbnM7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnRlc3Qoe1xuICAgICAgbmFtZTogbmFtZSB8fCAnbWF0Y2hlcycsXG4gICAgICBtZXNzYWdlOiBtZXNzYWdlIHx8IHN0cmluZy5tYXRjaGVzLFxuICAgICAgcGFyYW1zOiB7XG4gICAgICAgIHJlZ2V4XG4gICAgICB9LFxuICAgICAgc2tpcEFic2VudDogdHJ1ZSxcbiAgICAgIHRlc3Q6IHZhbHVlID0+IHZhbHVlID09PSAnJyAmJiBleGNsdWRlRW1wdHlTdHJpbmcgfHwgdmFsdWUuc2VhcmNoKHJlZ2V4KSAhPT0gLTFcbiAgICB9KTtcbiAgfVxuICBlbWFpbChtZXNzYWdlID0gc3RyaW5nLmVtYWlsKSB7XG4gICAgcmV0dXJuIHRoaXMubWF0Y2hlcyhyRW1haWwsIHtcbiAgICAgIG5hbWU6ICdlbWFpbCcsXG4gICAgICBtZXNzYWdlLFxuICAgICAgZXhjbHVkZUVtcHR5U3RyaW5nOiB0cnVlXG4gICAgfSk7XG4gIH1cbiAgdXJsKG1lc3NhZ2UgPSBzdHJpbmcudXJsKSB7XG4gICAgcmV0dXJuIHRoaXMubWF0Y2hlcyhyVXJsLCB7XG4gICAgICBuYW1lOiAndXJsJyxcbiAgICAgIG1lc3NhZ2UsXG4gICAgICBleGNsdWRlRW1wdHlTdHJpbmc6IHRydWVcbiAgICB9KTtcbiAgfVxuICB1dWlkKG1lc3NhZ2UgPSBzdHJpbmcudXVpZCkge1xuICAgIHJldHVybiB0aGlzLm1hdGNoZXMoclVVSUQsIHtcbiAgICAgIG5hbWU6ICd1dWlkJyxcbiAgICAgIG1lc3NhZ2UsXG4gICAgICBleGNsdWRlRW1wdHlTdHJpbmc6IGZhbHNlXG4gICAgfSk7XG4gIH1cbiAgZGF0ZXRpbWUob3B0aW9ucykge1xuICAgIGxldCBtZXNzYWdlID0gJyc7XG4gICAgbGV0IGFsbG93T2Zmc2V0O1xuICAgIGxldCBwcmVjaXNpb247XG4gICAgaWYgKG9wdGlvbnMpIHtcbiAgICAgIGlmICh0eXBlb2Ygb3B0aW9ucyA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgKHtcbiAgICAgICAgICBtZXNzYWdlID0gJycsXG4gICAgICAgICAgYWxsb3dPZmZzZXQgPSBmYWxzZSxcbiAgICAgICAgICBwcmVjaXNpb24gPSB1bmRlZmluZWRcbiAgICAgICAgfSA9IG9wdGlvbnMpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbWVzc2FnZSA9IG9wdGlvbnM7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0aGlzLm1hdGNoZXMocklzb0RhdGVUaW1lLCB7XG4gICAgICBuYW1lOiAnZGF0ZXRpbWUnLFxuICAgICAgbWVzc2FnZTogbWVzc2FnZSB8fCBzdHJpbmcuZGF0ZXRpbWUsXG4gICAgICBleGNsdWRlRW1wdHlTdHJpbmc6IHRydWVcbiAgICB9KS50ZXN0KHtcbiAgICAgIG5hbWU6ICdkYXRldGltZV9vZmZzZXQnLFxuICAgICAgbWVzc2FnZTogbWVzc2FnZSB8fCBzdHJpbmcuZGF0ZXRpbWVfb2Zmc2V0LFxuICAgICAgcGFyYW1zOiB7XG4gICAgICAgIGFsbG93T2Zmc2V0XG4gICAgICB9LFxuICAgICAgc2tpcEFic2VudDogdHJ1ZSxcbiAgICAgIHRlc3Q6IHZhbHVlID0+IHtcbiAgICAgICAgaWYgKCF2YWx1ZSB8fCBhbGxvd09mZnNldCkgcmV0dXJuIHRydWU7XG4gICAgICAgIGNvbnN0IHN0cnVjdCA9IHBhcnNlRGF0ZVN0cnVjdCh2YWx1ZSk7XG4gICAgICAgIGlmICghc3RydWN0KSByZXR1cm4gZmFsc2U7XG4gICAgICAgIHJldHVybiAhIXN0cnVjdC56O1xuICAgICAgfVxuICAgIH0pLnRlc3Qoe1xuICAgICAgbmFtZTogJ2RhdGV0aW1lX3ByZWNpc2lvbicsXG4gICAgICBtZXNzYWdlOiBtZXNzYWdlIHx8IHN0cmluZy5kYXRldGltZV9wcmVjaXNpb24sXG4gICAgICBwYXJhbXM6IHtcbiAgICAgICAgcHJlY2lzaW9uXG4gICAgICB9LFxuICAgICAgc2tpcEFic2VudDogdHJ1ZSxcbiAgICAgIHRlc3Q6IHZhbHVlID0+IHtcbiAgICAgICAgaWYgKCF2YWx1ZSB8fCBwcmVjaXNpb24gPT0gdW5kZWZpbmVkKSByZXR1cm4gdHJ1ZTtcbiAgICAgICAgY29uc3Qgc3RydWN0ID0gcGFyc2VEYXRlU3RydWN0KHZhbHVlKTtcbiAgICAgICAgaWYgKCFzdHJ1Y3QpIHJldHVybiBmYWxzZTtcbiAgICAgICAgcmV0dXJuIHN0cnVjdC5wcmVjaXNpb24gPT09IHByZWNpc2lvbjtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIC8vLS0gdHJhbnNmb3JtcyAtLVxuICBlbnN1cmUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZGVmYXVsdCgnJykudHJhbnNmb3JtKHZhbCA9PiB2YWwgPT09IG51bGwgPyAnJyA6IHZhbCk7XG4gIH1cbiAgdHJpbShtZXNzYWdlID0gc3RyaW5nLnRyaW0pIHtcbiAgICByZXR1cm4gdGhpcy50cmFuc2Zvcm0odmFsID0+IHZhbCAhPSBudWxsID8gdmFsLnRyaW0oKSA6IHZhbCkudGVzdCh7XG4gICAgICBtZXNzYWdlLFxuICAgICAgbmFtZTogJ3RyaW0nLFxuICAgICAgdGVzdDogaXNUcmltbWVkXG4gICAgfSk7XG4gIH1cbiAgbG93ZXJjYXNlKG1lc3NhZ2UgPSBzdHJpbmcubG93ZXJjYXNlKSB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNmb3JtKHZhbHVlID0+ICFpc0Fic2VudCh2YWx1ZSkgPyB2YWx1ZS50b0xvd2VyQ2FzZSgpIDogdmFsdWUpLnRlc3Qoe1xuICAgICAgbWVzc2FnZSxcbiAgICAgIG5hbWU6ICdzdHJpbmdfY2FzZScsXG4gICAgICBleGNsdXNpdmU6IHRydWUsXG4gICAgICBza2lwQWJzZW50OiB0cnVlLFxuICAgICAgdGVzdDogdmFsdWUgPT4gaXNBYnNlbnQodmFsdWUpIHx8IHZhbHVlID09PSB2YWx1ZS50b0xvd2VyQ2FzZSgpXG4gICAgfSk7XG4gIH1cbiAgdXBwZXJjYXNlKG1lc3NhZ2UgPSBzdHJpbmcudXBwZXJjYXNlKSB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNmb3JtKHZhbHVlID0+ICFpc0Fic2VudCh2YWx1ZSkgPyB2YWx1ZS50b1VwcGVyQ2FzZSgpIDogdmFsdWUpLnRlc3Qoe1xuICAgICAgbWVzc2FnZSxcbiAgICAgIG5hbWU6ICdzdHJpbmdfY2FzZScsXG4gICAgICBleGNsdXNpdmU6IHRydWUsXG4gICAgICBza2lwQWJzZW50OiB0cnVlLFxuICAgICAgdGVzdDogdmFsdWUgPT4gaXNBYnNlbnQodmFsdWUpIHx8IHZhbHVlID09PSB2YWx1ZS50b1VwcGVyQ2FzZSgpXG4gICAgfSk7XG4gIH1cbn1cbmNyZWF0ZSQ2LnByb3RvdHlwZSA9IFN0cmluZ1NjaGVtYS5wcm90b3R5cGU7XG5cbi8vXG4vLyBTdHJpbmcgSW50ZXJmYWNlc1xuLy9cblxubGV0IGlzTmFOJDEgPSB2YWx1ZSA9PiB2YWx1ZSAhPSArdmFsdWU7XG5mdW5jdGlvbiBjcmVhdGUkNSgpIHtcbiAgcmV0dXJuIG5ldyBOdW1iZXJTY2hlbWEoKTtcbn1cbmNsYXNzIE51bWJlclNjaGVtYSBleHRlbmRzIFNjaGVtYSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKHtcbiAgICAgIHR5cGU6ICdudW1iZXInLFxuICAgICAgY2hlY2sodmFsdWUpIHtcbiAgICAgICAgaWYgKHZhbHVlIGluc3RhbmNlb2YgTnVtYmVyKSB2YWx1ZSA9IHZhbHVlLnZhbHVlT2YoKTtcbiAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicgJiYgIWlzTmFOJDEodmFsdWUpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHRoaXMud2l0aE11dGF0aW9uKCgpID0+IHtcbiAgICAgIHRoaXMudHJhbnNmb3JtKCh2YWx1ZSwgX3JhdykgPT4ge1xuICAgICAgICBpZiAoIXRoaXMuc3BlYy5jb2VyY2UpIHJldHVybiB2YWx1ZTtcbiAgICAgICAgbGV0IHBhcnNlZCA9IHZhbHVlO1xuICAgICAgICBpZiAodHlwZW9mIHBhcnNlZCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICBwYXJzZWQgPSBwYXJzZWQucmVwbGFjZSgvXFxzL2csICcnKTtcbiAgICAgICAgICBpZiAocGFyc2VkID09PSAnJykgcmV0dXJuIE5hTjtcbiAgICAgICAgICAvLyBkb24ndCB1c2UgcGFyc2VGbG9hdCB0byBhdm9pZCBwb3NpdGl2ZXMgb24gYWxwaGEtbnVtZXJpYyBzdHJpbmdzXG4gICAgICAgICAgcGFyc2VkID0gK3BhcnNlZDtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIG51bGwgLT4gTmFOIGlzbid0IHVzZWZ1bDsgdHJlYXQgYWxsIG51bGxzIGFzIG51bGwgYW5kIGxldCBpdCBmYWlsIG9uXG4gICAgICAgIC8vIG51bGxhYmlsaXR5IGNoZWNrIHZzIFR5cGVFcnJvcnNcbiAgICAgICAgaWYgKHRoaXMuaXNUeXBlKHBhcnNlZCkgfHwgcGFyc2VkID09PSBudWxsKSByZXR1cm4gcGFyc2VkO1xuICAgICAgICByZXR1cm4gcGFyc2VGbG9hdChwYXJzZWQpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbiAgbWluKG1pbiwgbWVzc2FnZSA9IG51bWJlci5taW4pIHtcbiAgICByZXR1cm4gdGhpcy50ZXN0KHtcbiAgICAgIG1lc3NhZ2UsXG4gICAgICBuYW1lOiAnbWluJyxcbiAgICAgIGV4Y2x1c2l2ZTogdHJ1ZSxcbiAgICAgIHBhcmFtczoge1xuICAgICAgICBtaW5cbiAgICAgIH0sXG4gICAgICBza2lwQWJzZW50OiB0cnVlLFxuICAgICAgdGVzdCh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUgPj0gdGhpcy5yZXNvbHZlKG1pbik7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgbWF4KG1heCwgbWVzc2FnZSA9IG51bWJlci5tYXgpIHtcbiAgICByZXR1cm4gdGhpcy50ZXN0KHtcbiAgICAgIG1lc3NhZ2UsXG4gICAgICBuYW1lOiAnbWF4JyxcbiAgICAgIGV4Y2x1c2l2ZTogdHJ1ZSxcbiAgICAgIHBhcmFtczoge1xuICAgICAgICBtYXhcbiAgICAgIH0sXG4gICAgICBza2lwQWJzZW50OiB0cnVlLFxuICAgICAgdGVzdCh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUgPD0gdGhpcy5yZXNvbHZlKG1heCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgbGVzc1RoYW4obGVzcywgbWVzc2FnZSA9IG51bWJlci5sZXNzVGhhbikge1xuICAgIHJldHVybiB0aGlzLnRlc3Qoe1xuICAgICAgbWVzc2FnZSxcbiAgICAgIG5hbWU6ICdtYXgnLFxuICAgICAgZXhjbHVzaXZlOiB0cnVlLFxuICAgICAgcGFyYW1zOiB7XG4gICAgICAgIGxlc3NcbiAgICAgIH0sXG4gICAgICBza2lwQWJzZW50OiB0cnVlLFxuICAgICAgdGVzdCh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUgPCB0aGlzLnJlc29sdmUobGVzcyk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgbW9yZVRoYW4obW9yZSwgbWVzc2FnZSA9IG51bWJlci5tb3JlVGhhbikge1xuICAgIHJldHVybiB0aGlzLnRlc3Qoe1xuICAgICAgbWVzc2FnZSxcbiAgICAgIG5hbWU6ICdtaW4nLFxuICAgICAgZXhjbHVzaXZlOiB0cnVlLFxuICAgICAgcGFyYW1zOiB7XG4gICAgICAgIG1vcmVcbiAgICAgIH0sXG4gICAgICBza2lwQWJzZW50OiB0cnVlLFxuICAgICAgdGVzdCh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUgPiB0aGlzLnJlc29sdmUobW9yZSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgcG9zaXRpdmUobXNnID0gbnVtYmVyLnBvc2l0aXZlKSB7XG4gICAgcmV0dXJuIHRoaXMubW9yZVRoYW4oMCwgbXNnKTtcbiAgfVxuICBuZWdhdGl2ZShtc2cgPSBudW1iZXIubmVnYXRpdmUpIHtcbiAgICByZXR1cm4gdGhpcy5sZXNzVGhhbigwLCBtc2cpO1xuICB9XG4gIGludGVnZXIobWVzc2FnZSA9IG51bWJlci5pbnRlZ2VyKSB7XG4gICAgcmV0dXJuIHRoaXMudGVzdCh7XG4gICAgICBuYW1lOiAnaW50ZWdlcicsXG4gICAgICBtZXNzYWdlLFxuICAgICAgc2tpcEFic2VudDogdHJ1ZSxcbiAgICAgIHRlc3Q6IHZhbCA9PiBOdW1iZXIuaXNJbnRlZ2VyKHZhbClcbiAgICB9KTtcbiAgfVxuICB0cnVuY2F0ZSgpIHtcbiAgICByZXR1cm4gdGhpcy50cmFuc2Zvcm0odmFsdWUgPT4gIWlzQWJzZW50KHZhbHVlKSA/IHZhbHVlIHwgMCA6IHZhbHVlKTtcbiAgfVxuICByb3VuZChtZXRob2QpIHtcbiAgICB2YXIgX21ldGhvZDtcbiAgICBsZXQgYXZhaWwgPSBbJ2NlaWwnLCAnZmxvb3InLCAncm91bmQnLCAndHJ1bmMnXTtcbiAgICBtZXRob2QgPSAoKF9tZXRob2QgPSBtZXRob2QpID09IG51bGwgPyB2b2lkIDAgOiBfbWV0aG9kLnRvTG93ZXJDYXNlKCkpIHx8ICdyb3VuZCc7XG5cbiAgICAvLyB0aGlzIGV4aXN0cyBmb3Igc3ltZW10cnkgd2l0aCB0aGUgbmV3IE1hdGgudHJ1bmNcbiAgICBpZiAobWV0aG9kID09PSAndHJ1bmMnKSByZXR1cm4gdGhpcy50cnVuY2F0ZSgpO1xuICAgIGlmIChhdmFpbC5pbmRleE9mKG1ldGhvZC50b0xvd2VyQ2FzZSgpKSA9PT0gLTEpIHRocm93IG5ldyBUeXBlRXJyb3IoJ09ubHkgdmFsaWQgb3B0aW9ucyBmb3Igcm91bmQoKSBhcmU6ICcgKyBhdmFpbC5qb2luKCcsICcpKTtcbiAgICByZXR1cm4gdGhpcy50cmFuc2Zvcm0odmFsdWUgPT4gIWlzQWJzZW50KHZhbHVlKSA/IE1hdGhbbWV0aG9kXSh2YWx1ZSkgOiB2YWx1ZSk7XG4gIH1cbn1cbmNyZWF0ZSQ1LnByb3RvdHlwZSA9IE51bWJlclNjaGVtYS5wcm90b3R5cGU7XG5cbi8vXG4vLyBOdW1iZXIgSW50ZXJmYWNlc1xuLy9cblxubGV0IGludmFsaWREYXRlID0gbmV3IERhdGUoJycpO1xubGV0IGlzRGF0ZSA9IG9iaiA9PiBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwob2JqKSA9PT0gJ1tvYmplY3QgRGF0ZV0nO1xuZnVuY3Rpb24gY3JlYXRlJDQoKSB7XG4gIHJldHVybiBuZXcgRGF0ZVNjaGVtYSgpO1xufVxuY2xhc3MgRGF0ZVNjaGVtYSBleHRlbmRzIFNjaGVtYSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKHtcbiAgICAgIHR5cGU6ICdkYXRlJyxcbiAgICAgIGNoZWNrKHYpIHtcbiAgICAgICAgcmV0dXJuIGlzRGF0ZSh2KSAmJiAhaXNOYU4odi5nZXRUaW1lKCkpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHRoaXMud2l0aE11dGF0aW9uKCgpID0+IHtcbiAgICAgIHRoaXMudHJhbnNmb3JtKCh2YWx1ZSwgX3JhdykgPT4ge1xuICAgICAgICAvLyBudWxsIC0+IEludmFsaWREYXRlIGlzbid0IHVzZWZ1bDsgdHJlYXQgYWxsIG51bGxzIGFzIG51bGwgYW5kIGxldCBpdCBmYWlsIG9uXG4gICAgICAgIC8vIG51bGxhYmlsaXR5IGNoZWNrIHZzIFR5cGVFcnJvcnNcbiAgICAgICAgaWYgKCF0aGlzLnNwZWMuY29lcmNlIHx8IHRoaXMuaXNUeXBlKHZhbHVlKSB8fCB2YWx1ZSA9PT0gbnVsbCkgcmV0dXJuIHZhbHVlO1xuICAgICAgICB2YWx1ZSA9IHBhcnNlSXNvRGF0ZSh2YWx1ZSk7XG5cbiAgICAgICAgLy8gMCBpcyBhIHZhbGlkIHRpbWVzdGFtcCBlcXVpdmFsZW50IHRvIDE5NzAtMDEtMDFUMDA6MDA6MDBaKHVuaXggZXBvY2gpIG9yIGJlZm9yZS5cbiAgICAgICAgcmV0dXJuICFpc05hTih2YWx1ZSkgPyBuZXcgRGF0ZSh2YWx1ZSkgOiBEYXRlU2NoZW1hLklOVkFMSURfREFURTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG4gIHByZXBhcmVQYXJhbShyZWYsIG5hbWUpIHtcbiAgICBsZXQgcGFyYW07XG4gICAgaWYgKCFSZWZlcmVuY2UuaXNSZWYocmVmKSkge1xuICAgICAgbGV0IGNhc3QgPSB0aGlzLmNhc3QocmVmKTtcbiAgICAgIGlmICghdGhpcy5fdHlwZUNoZWNrKGNhc3QpKSB0aHJvdyBuZXcgVHlwZUVycm9yKGBcXGAke25hbWV9XFxgIG11c3QgYmUgYSBEYXRlIG9yIGEgdmFsdWUgdGhhdCBjYW4gYmUgXFxgY2FzdCgpXFxgIHRvIGEgRGF0ZWApO1xuICAgICAgcGFyYW0gPSBjYXN0O1xuICAgIH0gZWxzZSB7XG4gICAgICBwYXJhbSA9IHJlZjtcbiAgICB9XG4gICAgcmV0dXJuIHBhcmFtO1xuICB9XG4gIG1pbihtaW4sIG1lc3NhZ2UgPSBkYXRlLm1pbikge1xuICAgIGxldCBsaW1pdCA9IHRoaXMucHJlcGFyZVBhcmFtKG1pbiwgJ21pbicpO1xuICAgIHJldHVybiB0aGlzLnRlc3Qoe1xuICAgICAgbWVzc2FnZSxcbiAgICAgIG5hbWU6ICdtaW4nLFxuICAgICAgZXhjbHVzaXZlOiB0cnVlLFxuICAgICAgcGFyYW1zOiB7XG4gICAgICAgIG1pblxuICAgICAgfSxcbiAgICAgIHNraXBBYnNlbnQ6IHRydWUsXG4gICAgICB0ZXN0KHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZSA+PSB0aGlzLnJlc29sdmUobGltaXQpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIG1heChtYXgsIG1lc3NhZ2UgPSBkYXRlLm1heCkge1xuICAgIGxldCBsaW1pdCA9IHRoaXMucHJlcGFyZVBhcmFtKG1heCwgJ21heCcpO1xuICAgIHJldHVybiB0aGlzLnRlc3Qoe1xuICAgICAgbWVzc2FnZSxcbiAgICAgIG5hbWU6ICdtYXgnLFxuICAgICAgZXhjbHVzaXZlOiB0cnVlLFxuICAgICAgcGFyYW1zOiB7XG4gICAgICAgIG1heFxuICAgICAgfSxcbiAgICAgIHNraXBBYnNlbnQ6IHRydWUsXG4gICAgICB0ZXN0KHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZSA8PSB0aGlzLnJlc29sdmUobGltaXQpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG59XG5EYXRlU2NoZW1hLklOVkFMSURfREFURSA9IGludmFsaWREYXRlO1xuY3JlYXRlJDQucHJvdG90eXBlID0gRGF0ZVNjaGVtYS5wcm90b3R5cGU7XG5jcmVhdGUkNC5JTlZBTElEX0RBVEUgPSBpbnZhbGlkRGF0ZTtcblxuLy8gQHRzLWV4cGVjdC1lcnJvclxuZnVuY3Rpb24gc29ydEZpZWxkcyhmaWVsZHMsIGV4Y2x1ZGVkRWRnZXMgPSBbXSkge1xuICBsZXQgZWRnZXMgPSBbXTtcbiAgbGV0IG5vZGVzID0gbmV3IFNldCgpO1xuICBsZXQgZXhjbHVkZXMgPSBuZXcgU2V0KGV4Y2x1ZGVkRWRnZXMubWFwKChbYSwgYl0pID0+IGAke2F9LSR7Yn1gKSk7XG4gIGZ1bmN0aW9uIGFkZE5vZGUoZGVwUGF0aCwga2V5KSB7XG4gICAgbGV0IG5vZGUgPSBzcGxpdChkZXBQYXRoKVswXTtcbiAgICBub2Rlcy5hZGQobm9kZSk7XG4gICAgaWYgKCFleGNsdWRlcy5oYXMoYCR7a2V5fS0ke25vZGV9YCkpIGVkZ2VzLnB1c2goW2tleSwgbm9kZV0pO1xuICB9XG4gIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKGZpZWxkcykpIHtcbiAgICBsZXQgdmFsdWUgPSBmaWVsZHNba2V5XTtcbiAgICBub2Rlcy5hZGQoa2V5KTtcbiAgICBpZiAoUmVmZXJlbmNlLmlzUmVmKHZhbHVlKSAmJiB2YWx1ZS5pc1NpYmxpbmcpIGFkZE5vZGUodmFsdWUucGF0aCwga2V5KTtlbHNlIGlmIChpc1NjaGVtYSh2YWx1ZSkgJiYgJ2RlcHMnIGluIHZhbHVlKSB2YWx1ZS5kZXBzLmZvckVhY2gocGF0aCA9PiBhZGROb2RlKHBhdGgsIGtleSkpO1xuICB9XG4gIHJldHVybiB0b3Bvc29ydC5hcnJheShBcnJheS5mcm9tKG5vZGVzKSwgZWRnZXMpLnJldmVyc2UoKTtcbn1cblxuZnVuY3Rpb24gZmluZEluZGV4KGFyciwgZXJyKSB7XG4gIGxldCBpZHggPSBJbmZpbml0eTtcbiAgYXJyLnNvbWUoKGtleSwgaWkpID0+IHtcbiAgICB2YXIgX2VyciRwYXRoO1xuICAgIGlmICgoX2VyciRwYXRoID0gZXJyLnBhdGgpICE9IG51bGwgJiYgX2VyciRwYXRoLmluY2x1ZGVzKGtleSkpIHtcbiAgICAgIGlkeCA9IGlpO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIGlkeDtcbn1cbmZ1bmN0aW9uIHNvcnRCeUtleU9yZGVyKGtleXMpIHtcbiAgcmV0dXJuIChhLCBiKSA9PiB7XG4gICAgcmV0dXJuIGZpbmRJbmRleChrZXlzLCBhKSAtIGZpbmRJbmRleChrZXlzLCBiKTtcbiAgfTtcbn1cblxuY29uc3QgcGFyc2VKc29uID0gKHZhbHVlLCBfLCBzY2hlbWEpID0+IHtcbiAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cbiAgbGV0IHBhcnNlZCA9IHZhbHVlO1xuICB0cnkge1xuICAgIHBhcnNlZCA9IEpTT04ucGFyc2UodmFsdWUpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICAvKiAqL1xuICB9XG4gIHJldHVybiBzY2hlbWEuaXNUeXBlKHBhcnNlZCkgPyBwYXJzZWQgOiB2YWx1ZTtcbn07XG5cbi8vIEB0cy1pZ25vcmVcbmZ1bmN0aW9uIGRlZXBQYXJ0aWFsKHNjaGVtYSkge1xuICBpZiAoJ2ZpZWxkcycgaW4gc2NoZW1hKSB7XG4gICAgY29uc3QgcGFydGlhbCA9IHt9O1xuICAgIGZvciAoY29uc3QgW2tleSwgZmllbGRTY2hlbWFdIG9mIE9iamVjdC5lbnRyaWVzKHNjaGVtYS5maWVsZHMpKSB7XG4gICAgICBwYXJ0aWFsW2tleV0gPSBkZWVwUGFydGlhbChmaWVsZFNjaGVtYSk7XG4gICAgfVxuICAgIHJldHVybiBzY2hlbWEuc2V0RmllbGRzKHBhcnRpYWwpO1xuICB9XG4gIGlmIChzY2hlbWEudHlwZSA9PT0gJ2FycmF5Jykge1xuICAgIGNvbnN0IG5leHRBcnJheSA9IHNjaGVtYS5vcHRpb25hbCgpO1xuICAgIGlmIChuZXh0QXJyYXkuaW5uZXJUeXBlKSBuZXh0QXJyYXkuaW5uZXJUeXBlID0gZGVlcFBhcnRpYWwobmV4dEFycmF5LmlubmVyVHlwZSk7XG4gICAgcmV0dXJuIG5leHRBcnJheTtcbiAgfVxuICBpZiAoc2NoZW1hLnR5cGUgPT09ICd0dXBsZScpIHtcbiAgICByZXR1cm4gc2NoZW1hLm9wdGlvbmFsKCkuY2xvbmUoe1xuICAgICAgdHlwZXM6IHNjaGVtYS5zcGVjLnR5cGVzLm1hcChkZWVwUGFydGlhbClcbiAgICB9KTtcbiAgfVxuICBpZiAoJ29wdGlvbmFsJyBpbiBzY2hlbWEpIHtcbiAgICByZXR1cm4gc2NoZW1hLm9wdGlvbmFsKCk7XG4gIH1cbiAgcmV0dXJuIHNjaGVtYTtcbn1cbmNvbnN0IGRlZXBIYXMgPSAob2JqLCBwKSA9PiB7XG4gIGNvbnN0IHBhdGggPSBbLi4ubm9ybWFsaXplUGF0aChwKV07XG4gIGlmIChwYXRoLmxlbmd0aCA9PT0gMSkgcmV0dXJuIHBhdGhbMF0gaW4gb2JqO1xuICBsZXQgbGFzdCA9IHBhdGgucG9wKCk7XG4gIGxldCBwYXJlbnQgPSBnZXR0ZXIoam9pbihwYXRoKSwgdHJ1ZSkob2JqKTtcbiAgcmV0dXJuICEhKHBhcmVudCAmJiBsYXN0IGluIHBhcmVudCk7XG59O1xubGV0IGlzT2JqZWN0ID0gb2JqID0+IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvYmopID09PSAnW29iamVjdCBPYmplY3RdJztcbmZ1bmN0aW9uIHVua25vd24oY3R4LCB2YWx1ZSkge1xuICBsZXQga25vd24gPSBPYmplY3Qua2V5cyhjdHguZmllbGRzKTtcbiAgcmV0dXJuIE9iamVjdC5rZXlzKHZhbHVlKS5maWx0ZXIoa2V5ID0+IGtub3duLmluZGV4T2Yoa2V5KSA9PT0gLTEpO1xufVxuY29uc3QgZGVmYXVsdFNvcnQgPSBzb3J0QnlLZXlPcmRlcihbXSk7XG5mdW5jdGlvbiBjcmVhdGUkMyhzcGVjKSB7XG4gIHJldHVybiBuZXcgT2JqZWN0U2NoZW1hKHNwZWMpO1xufVxuY2xhc3MgT2JqZWN0U2NoZW1hIGV4dGVuZHMgU2NoZW1hIHtcbiAgY29uc3RydWN0b3Ioc3BlYykge1xuICAgIHN1cGVyKHtcbiAgICAgIHR5cGU6ICdvYmplY3QnLFxuICAgICAgY2hlY2sodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIGlzT2JqZWN0KHZhbHVlKSB8fCB0eXBlb2YgdmFsdWUgPT09ICdmdW5jdGlvbic7XG4gICAgICB9XG4gICAgfSk7XG4gICAgdGhpcy5maWVsZHMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgIHRoaXMuX3NvcnRFcnJvcnMgPSBkZWZhdWx0U29ydDtcbiAgICB0aGlzLl9ub2RlcyA9IFtdO1xuICAgIHRoaXMuX2V4Y2x1ZGVkRWRnZXMgPSBbXTtcbiAgICB0aGlzLndpdGhNdXRhdGlvbigoKSA9PiB7XG4gICAgICBpZiAoc3BlYykge1xuICAgICAgICB0aGlzLnNoYXBlKHNwZWMpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIF9jYXN0KF92YWx1ZSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgdmFyIF9vcHRpb25zJHN0cmlwVW5rbm93bjtcbiAgICBsZXQgdmFsdWUgPSBzdXBlci5fY2FzdChfdmFsdWUsIG9wdGlvbnMpO1xuXG4gICAgLy9zaG91bGQgaWdub3JlIG51bGxzIGhlcmVcbiAgICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkgcmV0dXJuIHRoaXMuZ2V0RGVmYXVsdChvcHRpb25zKTtcbiAgICBpZiAoIXRoaXMuX3R5cGVDaGVjayh2YWx1ZSkpIHJldHVybiB2YWx1ZTtcbiAgICBsZXQgZmllbGRzID0gdGhpcy5maWVsZHM7XG4gICAgbGV0IHN0cmlwID0gKF9vcHRpb25zJHN0cmlwVW5rbm93biA9IG9wdGlvbnMuc3RyaXBVbmtub3duKSAhPSBudWxsID8gX29wdGlvbnMkc3RyaXBVbmtub3duIDogdGhpcy5zcGVjLm5vVW5rbm93bjtcbiAgICBsZXQgcHJvcHMgPSBbXS5jb25jYXQodGhpcy5fbm9kZXMsIE9iamVjdC5rZXlzKHZhbHVlKS5maWx0ZXIodiA9PiAhdGhpcy5fbm9kZXMuaW5jbHVkZXModikpKTtcbiAgICBsZXQgaW50ZXJtZWRpYXRlVmFsdWUgPSB7fTsgLy8gaXMgZmlsbGVkIGR1cmluZyB0aGUgdHJhbnNmb3JtIGJlbG93XG4gICAgbGV0IGlubmVyT3B0aW9ucyA9IE9iamVjdC5hc3NpZ24oe30sIG9wdGlvbnMsIHtcbiAgICAgIHBhcmVudDogaW50ZXJtZWRpYXRlVmFsdWUsXG4gICAgICBfX3ZhbGlkYXRpbmc6IG9wdGlvbnMuX192YWxpZGF0aW5nIHx8IGZhbHNlXG4gICAgfSk7XG4gICAgbGV0IGlzQ2hhbmdlZCA9IGZhbHNlO1xuICAgIGZvciAoY29uc3QgcHJvcCBvZiBwcm9wcykge1xuICAgICAgbGV0IGZpZWxkID0gZmllbGRzW3Byb3BdO1xuICAgICAgbGV0IGV4aXN0cyA9IChwcm9wIGluIHZhbHVlKTtcbiAgICAgIGxldCBpbnB1dFZhbHVlID0gdmFsdWVbcHJvcF07XG4gICAgICBpZiAoZmllbGQpIHtcbiAgICAgICAgbGV0IGZpZWxkVmFsdWU7XG5cbiAgICAgICAgLy8gc2FmZSB0byBtdXRhdGUgc2luY2UgdGhpcyBpcyBmaXJlZCBpbiBzZXF1ZW5jZVxuICAgICAgICBpbm5lck9wdGlvbnMucGF0aCA9IChvcHRpb25zLnBhdGggPyBgJHtvcHRpb25zLnBhdGh9LmAgOiAnJykgKyBwcm9wO1xuICAgICAgICBmaWVsZCA9IGZpZWxkLnJlc29sdmUoe1xuICAgICAgICAgIHZhbHVlOiBpbnB1dFZhbHVlLFxuICAgICAgICAgIGNvbnRleHQ6IG9wdGlvbnMuY29udGV4dCxcbiAgICAgICAgICBwYXJlbnQ6IGludGVybWVkaWF0ZVZhbHVlXG4gICAgICAgIH0pO1xuICAgICAgICBsZXQgZmllbGRTcGVjID0gZmllbGQgaW5zdGFuY2VvZiBTY2hlbWEgPyBmaWVsZC5zcGVjIDogdW5kZWZpbmVkO1xuICAgICAgICBsZXQgc3RyaWN0ID0gZmllbGRTcGVjID09IG51bGwgPyB2b2lkIDAgOiBmaWVsZFNwZWMuc3RyaWN0O1xuICAgICAgICBpZiAoZmllbGRTcGVjICE9IG51bGwgJiYgZmllbGRTcGVjLnN0cmlwKSB7XG4gICAgICAgICAgaXNDaGFuZ2VkID0gaXNDaGFuZ2VkIHx8IHByb3AgaW4gdmFsdWU7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgZmllbGRWYWx1ZSA9ICFvcHRpb25zLl9fdmFsaWRhdGluZyB8fCAhc3RyaWN0ID8gZmllbGQuY2FzdChpbnB1dFZhbHVlLCBpbm5lck9wdGlvbnMpIDogaW5wdXRWYWx1ZTtcbiAgICAgICAgaWYgKGZpZWxkVmFsdWUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgIGludGVybWVkaWF0ZVZhbHVlW3Byb3BdID0gZmllbGRWYWx1ZTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChleGlzdHMgJiYgIXN0cmlwKSB7XG4gICAgICAgIGludGVybWVkaWF0ZVZhbHVlW3Byb3BdID0gaW5wdXRWYWx1ZTtcbiAgICAgIH1cbiAgICAgIGlmIChleGlzdHMgIT09IHByb3AgaW4gaW50ZXJtZWRpYXRlVmFsdWUgfHwgaW50ZXJtZWRpYXRlVmFsdWVbcHJvcF0gIT09IGlucHV0VmFsdWUpIHtcbiAgICAgICAgaXNDaGFuZ2VkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGlzQ2hhbmdlZCA/IGludGVybWVkaWF0ZVZhbHVlIDogdmFsdWU7XG4gIH1cbiAgX3ZhbGlkYXRlKF92YWx1ZSwgb3B0aW9ucyA9IHt9LCBwYW5pYywgbmV4dCkge1xuICAgIGxldCB7XG4gICAgICBmcm9tID0gW10sXG4gICAgICBvcmlnaW5hbFZhbHVlID0gX3ZhbHVlLFxuICAgICAgcmVjdXJzaXZlID0gdGhpcy5zcGVjLnJlY3Vyc2l2ZVxuICAgIH0gPSBvcHRpb25zO1xuICAgIG9wdGlvbnMuZnJvbSA9IFt7XG4gICAgICBzY2hlbWE6IHRoaXMsXG4gICAgICB2YWx1ZTogb3JpZ2luYWxWYWx1ZVxuICAgIH0sIC4uLmZyb21dO1xuICAgIC8vIHRoaXMgZmxhZyBpcyBuZWVkZWQgZm9yIGhhbmRsaW5nIGBzdHJpY3RgIGNvcnJlY3RseSBpbiB0aGUgY29udGV4dCBvZlxuICAgIC8vIHZhbGlkYXRpb24gdnMganVzdCBjYXN0aW5nLiBlLmcgc3RyaWN0KCkgb24gYSBmaWVsZCBpcyBvbmx5IHVzZWQgd2hlbiB2YWxpZGF0aW5nXG4gICAgb3B0aW9ucy5fX3ZhbGlkYXRpbmcgPSB0cnVlO1xuICAgIG9wdGlvbnMub3JpZ2luYWxWYWx1ZSA9IG9yaWdpbmFsVmFsdWU7XG4gICAgc3VwZXIuX3ZhbGlkYXRlKF92YWx1ZSwgb3B0aW9ucywgcGFuaWMsIChvYmplY3RFcnJvcnMsIHZhbHVlKSA9PiB7XG4gICAgICBpZiAoIXJlY3Vyc2l2ZSB8fCAhaXNPYmplY3QodmFsdWUpKSB7XG4gICAgICAgIG5leHQob2JqZWN0RXJyb3JzLCB2YWx1ZSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIG9yaWdpbmFsVmFsdWUgPSBvcmlnaW5hbFZhbHVlIHx8IHZhbHVlO1xuICAgICAgbGV0IHRlc3RzID0gW107XG4gICAgICBmb3IgKGxldCBrZXkgb2YgdGhpcy5fbm9kZXMpIHtcbiAgICAgICAgbGV0IGZpZWxkID0gdGhpcy5maWVsZHNba2V5XTtcbiAgICAgICAgaWYgKCFmaWVsZCB8fCBSZWZlcmVuY2UuaXNSZWYoZmllbGQpKSB7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgdGVzdHMucHVzaChmaWVsZC5hc05lc3RlZFRlc3Qoe1xuICAgICAgICAgIG9wdGlvbnMsXG4gICAgICAgICAga2V5LFxuICAgICAgICAgIHBhcmVudDogdmFsdWUsXG4gICAgICAgICAgcGFyZW50UGF0aDogb3B0aW9ucy5wYXRoLFxuICAgICAgICAgIG9yaWdpbmFsUGFyZW50OiBvcmlnaW5hbFZhbHVlXG4gICAgICAgIH0pKTtcbiAgICAgIH1cbiAgICAgIHRoaXMucnVuVGVzdHMoe1xuICAgICAgICB0ZXN0cyxcbiAgICAgICAgdmFsdWUsXG4gICAgICAgIG9yaWdpbmFsVmFsdWUsXG4gICAgICAgIG9wdGlvbnNcbiAgICAgIH0sIHBhbmljLCBmaWVsZEVycm9ycyA9PiB7XG4gICAgICAgIG5leHQoZmllbGRFcnJvcnMuc29ydCh0aGlzLl9zb3J0RXJyb3JzKS5jb25jYXQob2JqZWN0RXJyb3JzKSwgdmFsdWUpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbiAgY2xvbmUoc3BlYykge1xuICAgIGNvbnN0IG5leHQgPSBzdXBlci5jbG9uZShzcGVjKTtcbiAgICBuZXh0LmZpZWxkcyA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMuZmllbGRzKTtcbiAgICBuZXh0Ll9ub2RlcyA9IHRoaXMuX25vZGVzO1xuICAgIG5leHQuX2V4Y2x1ZGVkRWRnZXMgPSB0aGlzLl9leGNsdWRlZEVkZ2VzO1xuICAgIG5leHQuX3NvcnRFcnJvcnMgPSB0aGlzLl9zb3J0RXJyb3JzO1xuICAgIHJldHVybiBuZXh0O1xuICB9XG4gIGNvbmNhdChzY2hlbWEpIHtcbiAgICBsZXQgbmV4dCA9IHN1cGVyLmNvbmNhdChzY2hlbWEpO1xuICAgIGxldCBuZXh0RmllbGRzID0gbmV4dC5maWVsZHM7XG4gICAgZm9yIChsZXQgW2ZpZWxkLCBzY2hlbWFPclJlZl0gb2YgT2JqZWN0LmVudHJpZXModGhpcy5maWVsZHMpKSB7XG4gICAgICBjb25zdCB0YXJnZXQgPSBuZXh0RmllbGRzW2ZpZWxkXTtcbiAgICAgIG5leHRGaWVsZHNbZmllbGRdID0gdGFyZ2V0ID09PSB1bmRlZmluZWQgPyBzY2hlbWFPclJlZiA6IHRhcmdldDtcbiAgICB9XG4gICAgcmV0dXJuIG5leHQud2l0aE11dGF0aW9uKHMgPT5cbiAgICAvLyBYWFg6IGV4Y2x1ZGVzIGhlcmUgaXMgd3JvbmdcbiAgICBzLnNldEZpZWxkcyhuZXh0RmllbGRzLCBbLi4udGhpcy5fZXhjbHVkZWRFZGdlcywgLi4uc2NoZW1hLl9leGNsdWRlZEVkZ2VzXSkpO1xuICB9XG4gIF9nZXREZWZhdWx0KG9wdGlvbnMpIHtcbiAgICBpZiAoJ2RlZmF1bHQnIGluIHRoaXMuc3BlYykge1xuICAgICAgcmV0dXJuIHN1cGVyLl9nZXREZWZhdWx0KG9wdGlvbnMpO1xuICAgIH1cblxuICAgIC8vIGlmIHRoZXJlIGlzIG5vIGRlZmF1bHQgc2V0IGludmVudCBvbmVcbiAgICBpZiAoIXRoaXMuX25vZGVzLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgbGV0IGRmdCA9IHt9O1xuICAgIHRoaXMuX25vZGVzLmZvckVhY2goa2V5ID0+IHtcbiAgICAgIHZhciBfaW5uZXJPcHRpb25zO1xuICAgICAgY29uc3QgZmllbGQgPSB0aGlzLmZpZWxkc1trZXldO1xuICAgICAgbGV0IGlubmVyT3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgICBpZiAoKF9pbm5lck9wdGlvbnMgPSBpbm5lck9wdGlvbnMpICE9IG51bGwgJiYgX2lubmVyT3B0aW9ucy52YWx1ZSkge1xuICAgICAgICBpbm5lck9wdGlvbnMgPSBPYmplY3QuYXNzaWduKHt9LCBpbm5lck9wdGlvbnMsIHtcbiAgICAgICAgICBwYXJlbnQ6IGlubmVyT3B0aW9ucy52YWx1ZSxcbiAgICAgICAgICB2YWx1ZTogaW5uZXJPcHRpb25zLnZhbHVlW2tleV1cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBkZnRba2V5XSA9IGZpZWxkICYmICdnZXREZWZhdWx0JyBpbiBmaWVsZCA/IGZpZWxkLmdldERlZmF1bHQoaW5uZXJPcHRpb25zKSA6IHVuZGVmaW5lZDtcbiAgICB9KTtcbiAgICByZXR1cm4gZGZ0O1xuICB9XG4gIHNldEZpZWxkcyhzaGFwZSwgZXhjbHVkZWRFZGdlcykge1xuICAgIGxldCBuZXh0ID0gdGhpcy5jbG9uZSgpO1xuICAgIG5leHQuZmllbGRzID0gc2hhcGU7XG4gICAgbmV4dC5fbm9kZXMgPSBzb3J0RmllbGRzKHNoYXBlLCBleGNsdWRlZEVkZ2VzKTtcbiAgICBuZXh0Ll9zb3J0RXJyb3JzID0gc29ydEJ5S2V5T3JkZXIoT2JqZWN0LmtleXMoc2hhcGUpKTtcbiAgICAvLyBYWFg6IHRoaXMgY2FycmllcyBvdmVyIGVkZ2VzIHdoaWNoIG1heSBub3QgYmUgd2hhdCB5b3Ugd2FudFxuICAgIGlmIChleGNsdWRlZEVkZ2VzKSBuZXh0Ll9leGNsdWRlZEVkZ2VzID0gZXhjbHVkZWRFZGdlcztcbiAgICByZXR1cm4gbmV4dDtcbiAgfVxuICBzaGFwZShhZGRpdGlvbnMsIGV4Y2x1ZGVzID0gW10pIHtcbiAgICByZXR1cm4gdGhpcy5jbG9uZSgpLndpdGhNdXRhdGlvbihuZXh0ID0+IHtcbiAgICAgIGxldCBlZGdlcyA9IG5leHQuX2V4Y2x1ZGVkRWRnZXM7XG4gICAgICBpZiAoZXhjbHVkZXMubGVuZ3RoKSB7XG4gICAgICAgIGlmICghQXJyYXkuaXNBcnJheShleGNsdWRlc1swXSkpIGV4Y2x1ZGVzID0gW2V4Y2x1ZGVzXTtcbiAgICAgICAgZWRnZXMgPSBbLi4ubmV4dC5fZXhjbHVkZWRFZGdlcywgLi4uZXhjbHVkZXNdO1xuICAgICAgfVxuXG4gICAgICAvLyBYWFg6IGV4Y2x1ZGVzIGhlcmUgaXMgd3JvbmdcbiAgICAgIHJldHVybiBuZXh0LnNldEZpZWxkcyhPYmplY3QuYXNzaWduKG5leHQuZmllbGRzLCBhZGRpdGlvbnMpLCBlZGdlcyk7XG4gICAgfSk7XG4gIH1cbiAgcGFydGlhbCgpIHtcbiAgICBjb25zdCBwYXJ0aWFsID0ge307XG4gICAgZm9yIChjb25zdCBba2V5LCBzY2hlbWFdIG9mIE9iamVjdC5lbnRyaWVzKHRoaXMuZmllbGRzKSkge1xuICAgICAgcGFydGlhbFtrZXldID0gJ29wdGlvbmFsJyBpbiBzY2hlbWEgJiYgc2NoZW1hLm9wdGlvbmFsIGluc3RhbmNlb2YgRnVuY3Rpb24gPyBzY2hlbWEub3B0aW9uYWwoKSA6IHNjaGVtYTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuc2V0RmllbGRzKHBhcnRpYWwpO1xuICB9XG4gIGRlZXBQYXJ0aWFsKCkge1xuICAgIGNvbnN0IG5leHQgPSBkZWVwUGFydGlhbCh0aGlzKTtcbiAgICByZXR1cm4gbmV4dDtcbiAgfVxuICBwaWNrKGtleXMpIHtcbiAgICBjb25zdCBwaWNrZWQgPSB7fTtcbiAgICBmb3IgKGNvbnN0IGtleSBvZiBrZXlzKSB7XG4gICAgICBpZiAodGhpcy5maWVsZHNba2V5XSkgcGlja2VkW2tleV0gPSB0aGlzLmZpZWxkc1trZXldO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5zZXRGaWVsZHMocGlja2VkLCB0aGlzLl9leGNsdWRlZEVkZ2VzLmZpbHRlcigoW2EsIGJdKSA9PiBrZXlzLmluY2x1ZGVzKGEpICYmIGtleXMuaW5jbHVkZXMoYikpKTtcbiAgfVxuICBvbWl0KGtleXMpIHtcbiAgICBjb25zdCByZW1haW5pbmcgPSBbXTtcbiAgICBmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyh0aGlzLmZpZWxkcykpIHtcbiAgICAgIGlmIChrZXlzLmluY2x1ZGVzKGtleSkpIGNvbnRpbnVlO1xuICAgICAgcmVtYWluaW5nLnB1c2goa2V5KTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMucGljayhyZW1haW5pbmcpO1xuICB9XG4gIGZyb20oZnJvbSwgdG8sIGFsaWFzKSB7XG4gICAgbGV0IGZyb21HZXR0ZXIgPSBnZXR0ZXIoZnJvbSwgdHJ1ZSk7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNmb3JtKG9iaiA9PiB7XG4gICAgICBpZiAoIW9iaikgcmV0dXJuIG9iajtcbiAgICAgIGxldCBuZXdPYmogPSBvYmo7XG4gICAgICBpZiAoZGVlcEhhcyhvYmosIGZyb20pKSB7XG4gICAgICAgIG5ld09iaiA9IE9iamVjdC5hc3NpZ24oe30sIG9iaik7XG4gICAgICAgIGlmICghYWxpYXMpIGRlbGV0ZSBuZXdPYmpbZnJvbV07XG4gICAgICAgIG5ld09ialt0b10gPSBmcm9tR2V0dGVyKG9iaik7XG4gICAgICB9XG4gICAgICByZXR1cm4gbmV3T2JqO1xuICAgIH0pO1xuICB9XG5cbiAgLyoqIFBhcnNlIGFuIGlucHV0IEpTT04gc3RyaW5nIHRvIGFuIG9iamVjdCAqL1xuICBqc29uKCkge1xuICAgIHJldHVybiB0aGlzLnRyYW5zZm9ybShwYXJzZUpzb24pO1xuICB9XG5cbiAgLyoqXG4gICAqIFNpbWlsYXIgdG8gYG5vVW5rbm93bmAgYnV0IG9ubHkgdmFsaWRhdGVzIHRoYXQgYW4gb2JqZWN0IGlzIHRoZSByaWdodCBzaGFwZSB3aXRob3V0IHN0cmlwcGluZyB0aGUgdW5rbm93biBrZXlzXG4gICAqL1xuICBleGFjdChtZXNzYWdlKSB7XG4gICAgcmV0dXJuIHRoaXMudGVzdCh7XG4gICAgICBuYW1lOiAnZXhhY3QnLFxuICAgICAgZXhjbHVzaXZlOiB0cnVlLFxuICAgICAgbWVzc2FnZTogbWVzc2FnZSB8fCBvYmplY3QuZXhhY3QsXG4gICAgICB0ZXN0KHZhbHVlKSB7XG4gICAgICAgIGlmICh2YWx1ZSA9PSBudWxsKSByZXR1cm4gdHJ1ZTtcbiAgICAgICAgY29uc3QgdW5rbm93bktleXMgPSB1bmtub3duKHRoaXMuc2NoZW1hLCB2YWx1ZSk7XG4gICAgICAgIHJldHVybiB1bmtub3duS2V5cy5sZW5ndGggPT09IDAgfHwgdGhpcy5jcmVhdGVFcnJvcih7XG4gICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICBwcm9wZXJ0aWVzOiB1bmtub3duS2V5cy5qb2luKCcsICcpXG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICBzdHJpcFVua25vd24oKSB7XG4gICAgcmV0dXJuIHRoaXMuY2xvbmUoe1xuICAgICAgbm9Vbmtub3duOiB0cnVlXG4gICAgfSk7XG4gIH1cbiAgbm9Vbmtub3duKG5vQWxsb3cgPSB0cnVlLCBtZXNzYWdlID0gb2JqZWN0Lm5vVW5rbm93bikge1xuICAgIGlmICh0eXBlb2Ygbm9BbGxvdyAhPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICBtZXNzYWdlID0gbm9BbGxvdztcbiAgICAgIG5vQWxsb3cgPSB0cnVlO1xuICAgIH1cbiAgICBsZXQgbmV4dCA9IHRoaXMudGVzdCh7XG4gICAgICBuYW1lOiAnbm9Vbmtub3duJyxcbiAgICAgIGV4Y2x1c2l2ZTogdHJ1ZSxcbiAgICAgIG1lc3NhZ2U6IG1lc3NhZ2UsXG4gICAgICB0ZXN0KHZhbHVlKSB7XG4gICAgICAgIGlmICh2YWx1ZSA9PSBudWxsKSByZXR1cm4gdHJ1ZTtcbiAgICAgICAgY29uc3QgdW5rbm93bktleXMgPSB1bmtub3duKHRoaXMuc2NoZW1hLCB2YWx1ZSk7XG4gICAgICAgIHJldHVybiAhbm9BbGxvdyB8fCB1bmtub3duS2V5cy5sZW5ndGggPT09IDAgfHwgdGhpcy5jcmVhdGVFcnJvcih7XG4gICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICB1bmtub3duOiB1bmtub3duS2V5cy5qb2luKCcsICcpXG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBuZXh0LnNwZWMubm9Vbmtub3duID0gbm9BbGxvdztcbiAgICByZXR1cm4gbmV4dDtcbiAgfVxuICB1bmtub3duKGFsbG93ID0gdHJ1ZSwgbWVzc2FnZSA9IG9iamVjdC5ub1Vua25vd24pIHtcbiAgICByZXR1cm4gdGhpcy5ub1Vua25vd24oIWFsbG93LCBtZXNzYWdlKTtcbiAgfVxuICB0cmFuc2Zvcm1LZXlzKGZuKSB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNmb3JtKG9iaiA9PiB7XG4gICAgICBpZiAoIW9iaikgcmV0dXJuIG9iajtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IHt9O1xuICAgICAgZm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMob2JqKSkgcmVzdWx0W2ZuKGtleSldID0gb2JqW2tleV07XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH0pO1xuICB9XG4gIGNhbWVsQ2FzZSgpIHtcbiAgICByZXR1cm4gdGhpcy50cmFuc2Zvcm1LZXlzKGNhbWVsQ2FzZSk7XG4gIH1cbiAgc25ha2VDYXNlKCkge1xuICAgIHJldHVybiB0aGlzLnRyYW5zZm9ybUtleXMoc25ha2VDYXNlKTtcbiAgfVxuICBjb25zdGFudENhc2UoKSB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNmb3JtS2V5cyhrZXkgPT4gc25ha2VDYXNlKGtleSkudG9VcHBlckNhc2UoKSk7XG4gIH1cbiAgZGVzY3JpYmUob3B0aW9ucykge1xuICAgIGNvbnN0IG5leHQgPSAob3B0aW9ucyA/IHRoaXMucmVzb2x2ZShvcHRpb25zKSA6IHRoaXMpLmNsb25lKCk7XG4gICAgY29uc3QgYmFzZSA9IHN1cGVyLmRlc2NyaWJlKG9wdGlvbnMpO1xuICAgIGJhc2UuZmllbGRzID0ge307XG4gICAgZm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXMobmV4dC5maWVsZHMpKSB7XG4gICAgICB2YXIgX2lubmVyT3B0aW9uczI7XG4gICAgICBsZXQgaW5uZXJPcHRpb25zID0gb3B0aW9ucztcbiAgICAgIGlmICgoX2lubmVyT3B0aW9uczIgPSBpbm5lck9wdGlvbnMpICE9IG51bGwgJiYgX2lubmVyT3B0aW9uczIudmFsdWUpIHtcbiAgICAgICAgaW5uZXJPcHRpb25zID0gT2JqZWN0LmFzc2lnbih7fSwgaW5uZXJPcHRpb25zLCB7XG4gICAgICAgICAgcGFyZW50OiBpbm5lck9wdGlvbnMudmFsdWUsXG4gICAgICAgICAgdmFsdWU6IGlubmVyT3B0aW9ucy52YWx1ZVtrZXldXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgYmFzZS5maWVsZHNba2V5XSA9IHZhbHVlLmRlc2NyaWJlKGlubmVyT3B0aW9ucyk7XG4gICAgfVxuICAgIHJldHVybiBiYXNlO1xuICB9XG59XG5jcmVhdGUkMy5wcm90b3R5cGUgPSBPYmplY3RTY2hlbWEucHJvdG90eXBlO1xuXG5mdW5jdGlvbiBjcmVhdGUkMih0eXBlKSB7XG4gIHJldHVybiBuZXcgQXJyYXlTY2hlbWEodHlwZSk7XG59XG5jbGFzcyBBcnJheVNjaGVtYSBleHRlbmRzIFNjaGVtYSB7XG4gIGNvbnN0cnVjdG9yKHR5cGUpIHtcbiAgICBzdXBlcih7XG4gICAgICB0eXBlOiAnYXJyYXknLFxuICAgICAgc3BlYzoge1xuICAgICAgICB0eXBlczogdHlwZVxuICAgICAgfSxcbiAgICAgIGNoZWNrKHYpIHtcbiAgICAgICAgcmV0dXJuIEFycmF5LmlzQXJyYXkodik7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICAvLyBgdW5kZWZpbmVkYCBzcGVjaWZpY2FsbHkgbWVhbnMgdW5pbml0aWFsaXplZCwgYXMgb3Bwb3NlZCB0byBcIm5vIHN1YnR5cGVcIlxuICAgIHRoaXMuaW5uZXJUeXBlID0gdm9pZCAwO1xuICAgIHRoaXMuaW5uZXJUeXBlID0gdHlwZTtcbiAgfVxuICBfY2FzdChfdmFsdWUsIF9vcHRzKSB7XG4gICAgY29uc3QgdmFsdWUgPSBzdXBlci5fY2FzdChfdmFsdWUsIF9vcHRzKTtcblxuICAgIC8vIHNob3VsZCBpZ25vcmUgbnVsbHMgaGVyZVxuICAgIGlmICghdGhpcy5fdHlwZUNoZWNrKHZhbHVlKSB8fCAhdGhpcy5pbm5lclR5cGUpIHtcbiAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9XG4gICAgbGV0IGlzQ2hhbmdlZCA9IGZhbHNlO1xuICAgIGNvbnN0IGNhc3RBcnJheSA9IHZhbHVlLm1hcCgodiwgaWR4KSA9PiB7XG4gICAgICBjb25zdCBjYXN0RWxlbWVudCA9IHRoaXMuaW5uZXJUeXBlLmNhc3QodiwgT2JqZWN0LmFzc2lnbih7fSwgX29wdHMsIHtcbiAgICAgICAgcGF0aDogYCR7X29wdHMucGF0aCB8fCAnJ31bJHtpZHh9XWAsXG4gICAgICAgIHBhcmVudDogdmFsdWUsXG4gICAgICAgIG9yaWdpbmFsVmFsdWU6IHYsXG4gICAgICAgIHZhbHVlOiB2LFxuICAgICAgICBpbmRleDogaWR4XG4gICAgICB9KSk7XG4gICAgICBpZiAoY2FzdEVsZW1lbnQgIT09IHYpIHtcbiAgICAgICAgaXNDaGFuZ2VkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBjYXN0RWxlbWVudDtcbiAgICB9KTtcbiAgICByZXR1cm4gaXNDaGFuZ2VkID8gY2FzdEFycmF5IDogdmFsdWU7XG4gIH1cbiAgX3ZhbGlkYXRlKF92YWx1ZSwgb3B0aW9ucyA9IHt9LCBwYW5pYywgbmV4dCkge1xuICAgIHZhciBfb3B0aW9ucyRyZWN1cnNpdmU7XG4gICAgLy8gbGV0IHN5bmMgPSBvcHRpb25zLnN5bmM7XG4gICAgLy8gbGV0IHBhdGggPSBvcHRpb25zLnBhdGg7XG4gICAgbGV0IGlubmVyVHlwZSA9IHRoaXMuaW5uZXJUeXBlO1xuICAgIC8vIGxldCBlbmRFYXJseSA9IG9wdGlvbnMuYWJvcnRFYXJseSA/PyB0aGlzLnNwZWMuYWJvcnRFYXJseTtcbiAgICBsZXQgcmVjdXJzaXZlID0gKF9vcHRpb25zJHJlY3Vyc2l2ZSA9IG9wdGlvbnMucmVjdXJzaXZlKSAhPSBudWxsID8gX29wdGlvbnMkcmVjdXJzaXZlIDogdGhpcy5zcGVjLnJlY3Vyc2l2ZTtcbiAgICBvcHRpb25zLm9yaWdpbmFsVmFsdWUgIT0gbnVsbCA/IG9wdGlvbnMub3JpZ2luYWxWYWx1ZSA6IF92YWx1ZTtcbiAgICBzdXBlci5fdmFsaWRhdGUoX3ZhbHVlLCBvcHRpb25zLCBwYW5pYywgKGFycmF5RXJyb3JzLCB2YWx1ZSkgPT4ge1xuICAgICAgdmFyIF9vcHRpb25zJG9yaWdpbmFsVmFsdTI7XG4gICAgICBpZiAoIXJlY3Vyc2l2ZSB8fCAhaW5uZXJUeXBlIHx8ICF0aGlzLl90eXBlQ2hlY2sodmFsdWUpKSB7XG4gICAgICAgIG5leHQoYXJyYXlFcnJvcnMsIHZhbHVlKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyAjOTUwIEVuc3VyZSB0aGF0IHNwYXJzZSBhcnJheSBlbXB0eSBzbG90cyBhcmUgdmFsaWRhdGVkXG4gICAgICBsZXQgdGVzdHMgPSBuZXcgQXJyYXkodmFsdWUubGVuZ3RoKTtcbiAgICAgIGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCB2YWx1ZS5sZW5ndGg7IGluZGV4KyspIHtcbiAgICAgICAgdmFyIF9vcHRpb25zJG9yaWdpbmFsVmFsdTtcbiAgICAgICAgdGVzdHNbaW5kZXhdID0gaW5uZXJUeXBlLmFzTmVzdGVkVGVzdCh7XG4gICAgICAgICAgb3B0aW9ucyxcbiAgICAgICAgICBpbmRleCxcbiAgICAgICAgICBwYXJlbnQ6IHZhbHVlLFxuICAgICAgICAgIHBhcmVudFBhdGg6IG9wdGlvbnMucGF0aCxcbiAgICAgICAgICBvcmlnaW5hbFBhcmVudDogKF9vcHRpb25zJG9yaWdpbmFsVmFsdSA9IG9wdGlvbnMub3JpZ2luYWxWYWx1ZSkgIT0gbnVsbCA/IF9vcHRpb25zJG9yaWdpbmFsVmFsdSA6IF92YWx1ZVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIHRoaXMucnVuVGVzdHMoe1xuICAgICAgICB2YWx1ZSxcbiAgICAgICAgdGVzdHMsXG4gICAgICAgIG9yaWdpbmFsVmFsdWU6IChfb3B0aW9ucyRvcmlnaW5hbFZhbHUyID0gb3B0aW9ucy5vcmlnaW5hbFZhbHVlKSAhPSBudWxsID8gX29wdGlvbnMkb3JpZ2luYWxWYWx1MiA6IF92YWx1ZSxcbiAgICAgICAgb3B0aW9uc1xuICAgICAgfSwgcGFuaWMsIGlubmVyVHlwZUVycm9ycyA9PiBuZXh0KGlubmVyVHlwZUVycm9ycy5jb25jYXQoYXJyYXlFcnJvcnMpLCB2YWx1ZSkpO1xuICAgIH0pO1xuICB9XG4gIGNsb25lKHNwZWMpIHtcbiAgICBjb25zdCBuZXh0ID0gc3VwZXIuY2xvbmUoc3BlYyk7XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciByZWFkb25seVxuICAgIG5leHQuaW5uZXJUeXBlID0gdGhpcy5pbm5lclR5cGU7XG4gICAgcmV0dXJuIG5leHQ7XG4gIH1cblxuICAvKiogUGFyc2UgYW4gaW5wdXQgSlNPTiBzdHJpbmcgdG8gYW4gb2JqZWN0ICovXG4gIGpzb24oKSB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNmb3JtKHBhcnNlSnNvbik7XG4gIH1cbiAgY29uY2F0KHNjaGVtYSkge1xuICAgIGxldCBuZXh0ID0gc3VwZXIuY29uY2F0KHNjaGVtYSk7XG5cbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yIHJlYWRvbmx5XG4gICAgbmV4dC5pbm5lclR5cGUgPSB0aGlzLmlubmVyVHlwZTtcbiAgICBpZiAoc2NoZW1hLmlubmVyVHlwZSlcbiAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgcmVhZG9ubHlcbiAgICAgIG5leHQuaW5uZXJUeXBlID0gbmV4dC5pbm5lclR5cGUgP1xuICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvciBMYXp5IGRvZXNuJ3QgaGF2ZSBjb25jYXQgYW5kIHdpbGwgYnJlYWtcbiAgICAgIG5leHQuaW5uZXJUeXBlLmNvbmNhdChzY2hlbWEuaW5uZXJUeXBlKSA6IHNjaGVtYS5pbm5lclR5cGU7XG4gICAgcmV0dXJuIG5leHQ7XG4gIH1cbiAgb2Yoc2NoZW1hKSB7XG4gICAgLy8gRklYTUU6IHRoaXMgc2hvdWxkIHJldHVybiBhIG5ldyBpbnN0YW5jZSBvZiBhcnJheSB3aXRob3V0IHRoZSBkZWZhdWx0IHRvIGJlXG4gICAgbGV0IG5leHQgPSB0aGlzLmNsb25lKCk7XG4gICAgaWYgKCFpc1NjaGVtYShzY2hlbWEpKSB0aHJvdyBuZXcgVHlwZUVycm9yKCdgYXJyYXkub2YoKWAgc3ViLXNjaGVtYSBtdXN0IGJlIGEgdmFsaWQgeXVwIHNjaGVtYSBub3Q6ICcgKyBwcmludFZhbHVlKHNjaGVtYSkpO1xuXG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciByZWFkb25seVxuICAgIG5leHQuaW5uZXJUeXBlID0gc2NoZW1hO1xuICAgIG5leHQuc3BlYyA9IE9iamVjdC5hc3NpZ24oe30sIG5leHQuc3BlYywge1xuICAgICAgdHlwZXM6IHNjaGVtYVxuICAgIH0pO1xuICAgIHJldHVybiBuZXh0O1xuICB9XG4gIGxlbmd0aChsZW5ndGgsIG1lc3NhZ2UgPSBhcnJheS5sZW5ndGgpIHtcbiAgICByZXR1cm4gdGhpcy50ZXN0KHtcbiAgICAgIG1lc3NhZ2UsXG4gICAgICBuYW1lOiAnbGVuZ3RoJyxcbiAgICAgIGV4Y2x1c2l2ZTogdHJ1ZSxcbiAgICAgIHBhcmFtczoge1xuICAgICAgICBsZW5ndGhcbiAgICAgIH0sXG4gICAgICBza2lwQWJzZW50OiB0cnVlLFxuICAgICAgdGVzdCh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUubGVuZ3RoID09PSB0aGlzLnJlc29sdmUobGVuZ3RoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICBtaW4obWluLCBtZXNzYWdlKSB7XG4gICAgbWVzc2FnZSA9IG1lc3NhZ2UgfHwgYXJyYXkubWluO1xuICAgIHJldHVybiB0aGlzLnRlc3Qoe1xuICAgICAgbWVzc2FnZSxcbiAgICAgIG5hbWU6ICdtaW4nLFxuICAgICAgZXhjbHVzaXZlOiB0cnVlLFxuICAgICAgcGFyYW1zOiB7XG4gICAgICAgIG1pblxuICAgICAgfSxcbiAgICAgIHNraXBBYnNlbnQ6IHRydWUsXG4gICAgICAvLyBGSVhNRSh0cyk6IEFycmF5PHR5cGVvZiBUPlxuICAgICAgdGVzdCh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUubGVuZ3RoID49IHRoaXMucmVzb2x2ZShtaW4pO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIG1heChtYXgsIG1lc3NhZ2UpIHtcbiAgICBtZXNzYWdlID0gbWVzc2FnZSB8fCBhcnJheS5tYXg7XG4gICAgcmV0dXJuIHRoaXMudGVzdCh7XG4gICAgICBtZXNzYWdlLFxuICAgICAgbmFtZTogJ21heCcsXG4gICAgICBleGNsdXNpdmU6IHRydWUsXG4gICAgICBwYXJhbXM6IHtcbiAgICAgICAgbWF4XG4gICAgICB9LFxuICAgICAgc2tpcEFic2VudDogdHJ1ZSxcbiAgICAgIHRlc3QodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlLmxlbmd0aCA8PSB0aGlzLnJlc29sdmUobWF4KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICBlbnN1cmUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZGVmYXVsdCgoKSA9PiBbXSkudHJhbnNmb3JtKCh2YWwsIG9yaWdpbmFsKSA9PiB7XG4gICAgICAvLyBXZSBkb24ndCB3YW50IHRvIHJldHVybiBgbnVsbGAgZm9yIG51bGxhYmxlIHNjaGVtYVxuICAgICAgaWYgKHRoaXMuX3R5cGVDaGVjayh2YWwpKSByZXR1cm4gdmFsO1xuICAgICAgcmV0dXJuIG9yaWdpbmFsID09IG51bGwgPyBbXSA6IFtdLmNvbmNhdChvcmlnaW5hbCk7XG4gICAgfSk7XG4gIH1cbiAgY29tcGFjdChyZWplY3Rvcikge1xuICAgIGxldCByZWplY3QgPSAhcmVqZWN0b3IgPyB2ID0+ICEhdiA6ICh2LCBpLCBhKSA9PiAhcmVqZWN0b3IodiwgaSwgYSk7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNmb3JtKHZhbHVlcyA9PiB2YWx1ZXMgIT0gbnVsbCA/IHZhbHVlcy5maWx0ZXIocmVqZWN0KSA6IHZhbHVlcyk7XG4gIH1cbiAgZGVzY3JpYmUob3B0aW9ucykge1xuICAgIGNvbnN0IG5leHQgPSAob3B0aW9ucyA/IHRoaXMucmVzb2x2ZShvcHRpb25zKSA6IHRoaXMpLmNsb25lKCk7XG4gICAgY29uc3QgYmFzZSA9IHN1cGVyLmRlc2NyaWJlKG9wdGlvbnMpO1xuICAgIGlmIChuZXh0LmlubmVyVHlwZSkge1xuICAgICAgdmFyIF9pbm5lck9wdGlvbnM7XG4gICAgICBsZXQgaW5uZXJPcHRpb25zID0gb3B0aW9ucztcbiAgICAgIGlmICgoX2lubmVyT3B0aW9ucyA9IGlubmVyT3B0aW9ucykgIT0gbnVsbCAmJiBfaW5uZXJPcHRpb25zLnZhbHVlKSB7XG4gICAgICAgIGlubmVyT3B0aW9ucyA9IE9iamVjdC5hc3NpZ24oe30sIGlubmVyT3B0aW9ucywge1xuICAgICAgICAgIHBhcmVudDogaW5uZXJPcHRpb25zLnZhbHVlLFxuICAgICAgICAgIHZhbHVlOiBpbm5lck9wdGlvbnMudmFsdWVbMF1cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBiYXNlLmlubmVyVHlwZSA9IG5leHQuaW5uZXJUeXBlLmRlc2NyaWJlKGlubmVyT3B0aW9ucyk7XG4gICAgfVxuICAgIHJldHVybiBiYXNlO1xuICB9XG59XG5jcmVhdGUkMi5wcm90b3R5cGUgPSBBcnJheVNjaGVtYS5wcm90b3R5cGU7XG5cbi8vIEB0cy1pZ25vcmVcbmZ1bmN0aW9uIGNyZWF0ZSQxKHNjaGVtYXMpIHtcbiAgcmV0dXJuIG5ldyBUdXBsZVNjaGVtYShzY2hlbWFzKTtcbn1cbmNsYXNzIFR1cGxlU2NoZW1hIGV4dGVuZHMgU2NoZW1hIHtcbiAgY29uc3RydWN0b3Ioc2NoZW1hcykge1xuICAgIHN1cGVyKHtcbiAgICAgIHR5cGU6ICd0dXBsZScsXG4gICAgICBzcGVjOiB7XG4gICAgICAgIHR5cGVzOiBzY2hlbWFzXG4gICAgICB9LFxuICAgICAgY2hlY2sodikge1xuICAgICAgICBjb25zdCB0eXBlcyA9IHRoaXMuc3BlYy50eXBlcztcbiAgICAgICAgcmV0dXJuIEFycmF5LmlzQXJyYXkodikgJiYgdi5sZW5ndGggPT09IHR5cGVzLmxlbmd0aDtcbiAgICAgIH1cbiAgICB9KTtcbiAgICB0aGlzLndpdGhNdXRhdGlvbigoKSA9PiB7XG4gICAgICB0aGlzLnR5cGVFcnJvcih0dXBsZS5ub3RUeXBlKTtcbiAgICB9KTtcbiAgfVxuICBfY2FzdChpbnB1dFZhbHVlLCBvcHRpb25zKSB7XG4gICAgY29uc3Qge1xuICAgICAgdHlwZXNcbiAgICB9ID0gdGhpcy5zcGVjO1xuICAgIGNvbnN0IHZhbHVlID0gc3VwZXIuX2Nhc3QoaW5wdXRWYWx1ZSwgb3B0aW9ucyk7XG4gICAgaWYgKCF0aGlzLl90eXBlQ2hlY2sodmFsdWUpKSB7XG4gICAgICByZXR1cm4gdmFsdWU7XG4gICAgfVxuICAgIGxldCBpc0NoYW5nZWQgPSBmYWxzZTtcbiAgICBjb25zdCBjYXN0QXJyYXkgPSB0eXBlcy5tYXAoKHR5cGUsIGlkeCkgPT4ge1xuICAgICAgY29uc3QgY2FzdEVsZW1lbnQgPSB0eXBlLmNhc3QodmFsdWVbaWR4XSwgT2JqZWN0LmFzc2lnbih7fSwgb3B0aW9ucywge1xuICAgICAgICBwYXRoOiBgJHtvcHRpb25zLnBhdGggfHwgJyd9WyR7aWR4fV1gLFxuICAgICAgICBwYXJlbnQ6IHZhbHVlLFxuICAgICAgICBvcmlnaW5hbFZhbHVlOiB2YWx1ZVtpZHhdLFxuICAgICAgICB2YWx1ZTogdmFsdWVbaWR4XSxcbiAgICAgICAgaW5kZXg6IGlkeFxuICAgICAgfSkpO1xuICAgICAgaWYgKGNhc3RFbGVtZW50ICE9PSB2YWx1ZVtpZHhdKSBpc0NoYW5nZWQgPSB0cnVlO1xuICAgICAgcmV0dXJuIGNhc3RFbGVtZW50O1xuICAgIH0pO1xuICAgIHJldHVybiBpc0NoYW5nZWQgPyBjYXN0QXJyYXkgOiB2YWx1ZTtcbiAgfVxuICBfdmFsaWRhdGUoX3ZhbHVlLCBvcHRpb25zID0ge30sIHBhbmljLCBuZXh0KSB7XG4gICAgbGV0IGl0ZW1UeXBlcyA9IHRoaXMuc3BlYy50eXBlcztcbiAgICBzdXBlci5fdmFsaWRhdGUoX3ZhbHVlLCBvcHRpb25zLCBwYW5pYywgKHR1cGxlRXJyb3JzLCB2YWx1ZSkgPT4ge1xuICAgICAgdmFyIF9vcHRpb25zJG9yaWdpbmFsVmFsdTI7XG4gICAgICAvLyBpbnRlbnRpb25hbGx5IG5vdCByZXNwZWN0aW5nIHJlY3Vyc2l2ZVxuICAgICAgaWYgKCF0aGlzLl90eXBlQ2hlY2sodmFsdWUpKSB7XG4gICAgICAgIG5leHQodHVwbGVFcnJvcnMsIHZhbHVlKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgbGV0IHRlc3RzID0gW107XG4gICAgICBmb3IgKGxldCBbaW5kZXgsIGl0ZW1TY2hlbWFdIG9mIGl0ZW1UeXBlcy5lbnRyaWVzKCkpIHtcbiAgICAgICAgdmFyIF9vcHRpb25zJG9yaWdpbmFsVmFsdTtcbiAgICAgICAgdGVzdHNbaW5kZXhdID0gaXRlbVNjaGVtYS5hc05lc3RlZFRlc3Qoe1xuICAgICAgICAgIG9wdGlvbnMsXG4gICAgICAgICAgaW5kZXgsXG4gICAgICAgICAgcGFyZW50OiB2YWx1ZSxcbiAgICAgICAgICBwYXJlbnRQYXRoOiBvcHRpb25zLnBhdGgsXG4gICAgICAgICAgb3JpZ2luYWxQYXJlbnQ6IChfb3B0aW9ucyRvcmlnaW5hbFZhbHUgPSBvcHRpb25zLm9yaWdpbmFsVmFsdWUpICE9IG51bGwgPyBfb3B0aW9ucyRvcmlnaW5hbFZhbHUgOiBfdmFsdWVcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICB0aGlzLnJ1blRlc3RzKHtcbiAgICAgICAgdmFsdWUsXG4gICAgICAgIHRlc3RzLFxuICAgICAgICBvcmlnaW5hbFZhbHVlOiAoX29wdGlvbnMkb3JpZ2luYWxWYWx1MiA9IG9wdGlvbnMub3JpZ2luYWxWYWx1ZSkgIT0gbnVsbCA/IF9vcHRpb25zJG9yaWdpbmFsVmFsdTIgOiBfdmFsdWUsXG4gICAgICAgIG9wdGlvbnNcbiAgICAgIH0sIHBhbmljLCBpbm5lclR5cGVFcnJvcnMgPT4gbmV4dChpbm5lclR5cGVFcnJvcnMuY29uY2F0KHR1cGxlRXJyb3JzKSwgdmFsdWUpKTtcbiAgICB9KTtcbiAgfVxuICBkZXNjcmliZShvcHRpb25zKSB7XG4gICAgY29uc3QgbmV4dCA9IChvcHRpb25zID8gdGhpcy5yZXNvbHZlKG9wdGlvbnMpIDogdGhpcykuY2xvbmUoKTtcbiAgICBjb25zdCBiYXNlID0gc3VwZXIuZGVzY3JpYmUob3B0aW9ucyk7XG4gICAgYmFzZS5pbm5lclR5cGUgPSBuZXh0LnNwZWMudHlwZXMubWFwKChzY2hlbWEsIGluZGV4KSA9PiB7XG4gICAgICB2YXIgX2lubmVyT3B0aW9ucztcbiAgICAgIGxldCBpbm5lck9wdGlvbnMgPSBvcHRpb25zO1xuICAgICAgaWYgKChfaW5uZXJPcHRpb25zID0gaW5uZXJPcHRpb25zKSAhPSBudWxsICYmIF9pbm5lck9wdGlvbnMudmFsdWUpIHtcbiAgICAgICAgaW5uZXJPcHRpb25zID0gT2JqZWN0LmFzc2lnbih7fSwgaW5uZXJPcHRpb25zLCB7XG4gICAgICAgICAgcGFyZW50OiBpbm5lck9wdGlvbnMudmFsdWUsXG4gICAgICAgICAgdmFsdWU6IGlubmVyT3B0aW9ucy52YWx1ZVtpbmRleF1cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gc2NoZW1hLmRlc2NyaWJlKGlubmVyT3B0aW9ucyk7XG4gICAgfSk7XG4gICAgcmV0dXJuIGJhc2U7XG4gIH1cbn1cbmNyZWF0ZSQxLnByb3RvdHlwZSA9IFR1cGxlU2NoZW1hLnByb3RvdHlwZTtcblxuZnVuY3Rpb24gY3JlYXRlKGJ1aWxkZXIpIHtcbiAgcmV0dXJuIG5ldyBMYXp5KGJ1aWxkZXIpO1xufVxuZnVuY3Rpb24gY2F0Y2hWYWxpZGF0aW9uRXJyb3IoZm4pIHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gZm4oKTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgaWYgKFZhbGlkYXRpb25FcnJvci5pc0Vycm9yKGVycikpIHJldHVybiBQcm9taXNlLnJlamVjdChlcnIpO1xuICAgIHRocm93IGVycjtcbiAgfVxufVxuY2xhc3MgTGF6eSB7XG4gIGNvbnN0cnVjdG9yKGJ1aWxkZXIpIHtcbiAgICB0aGlzLnR5cGUgPSAnbGF6eSc7XG4gICAgdGhpcy5fX2lzWXVwU2NoZW1hX18gPSB0cnVlO1xuICAgIHRoaXMuc3BlYyA9IHZvaWQgMDtcbiAgICB0aGlzLl9yZXNvbHZlID0gKHZhbHVlLCBvcHRpb25zID0ge30pID0+IHtcbiAgICAgIGxldCBzY2hlbWEgPSB0aGlzLmJ1aWxkZXIodmFsdWUsIG9wdGlvbnMpO1xuICAgICAgaWYgKCFpc1NjaGVtYShzY2hlbWEpKSB0aHJvdyBuZXcgVHlwZUVycm9yKCdsYXp5KCkgZnVuY3Rpb25zIG11c3QgcmV0dXJuIGEgdmFsaWQgc2NoZW1hJyk7XG4gICAgICBpZiAodGhpcy5zcGVjLm9wdGlvbmFsKSBzY2hlbWEgPSBzY2hlbWEub3B0aW9uYWwoKTtcbiAgICAgIHJldHVybiBzY2hlbWEucmVzb2x2ZShvcHRpb25zKTtcbiAgICB9O1xuICAgIHRoaXMuYnVpbGRlciA9IGJ1aWxkZXI7XG4gICAgdGhpcy5zcGVjID0ge1xuICAgICAgbWV0YTogdW5kZWZpbmVkLFxuICAgICAgb3B0aW9uYWw6IGZhbHNlXG4gICAgfTtcbiAgfVxuICBjbG9uZShzcGVjKSB7XG4gICAgY29uc3QgbmV4dCA9IG5ldyBMYXp5KHRoaXMuYnVpbGRlcik7XG4gICAgbmV4dC5zcGVjID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5zcGVjLCBzcGVjKTtcbiAgICByZXR1cm4gbmV4dDtcbiAgfVxuICBvcHRpb25hbGl0eShvcHRpb25hbCkge1xuICAgIGNvbnN0IG5leHQgPSB0aGlzLmNsb25lKHtcbiAgICAgIG9wdGlvbmFsXG4gICAgfSk7XG4gICAgcmV0dXJuIG5leHQ7XG4gIH1cbiAgb3B0aW9uYWwoKSB7XG4gICAgcmV0dXJuIHRoaXMub3B0aW9uYWxpdHkodHJ1ZSk7XG4gIH1cbiAgcmVzb2x2ZShvcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMuX3Jlc29sdmUob3B0aW9ucy52YWx1ZSwgb3B0aW9ucyk7XG4gIH1cbiAgY2FzdCh2YWx1ZSwgb3B0aW9ucykge1xuICAgIHJldHVybiB0aGlzLl9yZXNvbHZlKHZhbHVlLCBvcHRpb25zKS5jYXN0KHZhbHVlLCBvcHRpb25zKTtcbiAgfVxuICBhc05lc3RlZFRlc3QoY29uZmlnKSB7XG4gICAgbGV0IHtcbiAgICAgIGtleSxcbiAgICAgIGluZGV4LFxuICAgICAgcGFyZW50LFxuICAgICAgb3B0aW9uc1xuICAgIH0gPSBjb25maWc7XG4gICAgbGV0IHZhbHVlID0gcGFyZW50W2luZGV4ICE9IG51bGwgPyBpbmRleCA6IGtleV07XG4gICAgcmV0dXJuIHRoaXMuX3Jlc29sdmUodmFsdWUsIE9iamVjdC5hc3NpZ24oe30sIG9wdGlvbnMsIHtcbiAgICAgIHZhbHVlLFxuICAgICAgcGFyZW50XG4gICAgfSkpLmFzTmVzdGVkVGVzdChjb25maWcpO1xuICB9XG4gIHZhbGlkYXRlKHZhbHVlLCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIGNhdGNoVmFsaWRhdGlvbkVycm9yKCgpID0+IHRoaXMuX3Jlc29sdmUodmFsdWUsIG9wdGlvbnMpLnZhbGlkYXRlKHZhbHVlLCBvcHRpb25zKSk7XG4gIH1cbiAgdmFsaWRhdGVTeW5jKHZhbHVlLCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMuX3Jlc29sdmUodmFsdWUsIG9wdGlvbnMpLnZhbGlkYXRlU3luYyh2YWx1ZSwgb3B0aW9ucyk7XG4gIH1cbiAgdmFsaWRhdGVBdChwYXRoLCB2YWx1ZSwgb3B0aW9ucykge1xuICAgIHJldHVybiBjYXRjaFZhbGlkYXRpb25FcnJvcigoKSA9PiB0aGlzLl9yZXNvbHZlKHZhbHVlLCBvcHRpb25zKS52YWxpZGF0ZUF0KHBhdGgsIHZhbHVlLCBvcHRpb25zKSk7XG4gIH1cbiAgdmFsaWRhdGVTeW5jQXQocGF0aCwgdmFsdWUsIG9wdGlvbnMpIHtcbiAgICByZXR1cm4gdGhpcy5fcmVzb2x2ZSh2YWx1ZSwgb3B0aW9ucykudmFsaWRhdGVTeW5jQXQocGF0aCwgdmFsdWUsIG9wdGlvbnMpO1xuICB9XG4gIGlzVmFsaWQodmFsdWUsIG9wdGlvbnMpIHtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIHRoaXMuX3Jlc29sdmUodmFsdWUsIG9wdGlvbnMpLmlzVmFsaWQodmFsdWUsIG9wdGlvbnMpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKFZhbGlkYXRpb25FcnJvci5pc0Vycm9yKGVycikpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShmYWxzZSk7XG4gICAgICB9XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9XG4gIGlzVmFsaWRTeW5jKHZhbHVlLCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMuX3Jlc29sdmUodmFsdWUsIG9wdGlvbnMpLmlzVmFsaWRTeW5jKHZhbHVlLCBvcHRpb25zKTtcbiAgfVxuICBkZXNjcmliZShvcHRpb25zKSB7XG4gICAgcmV0dXJuIG9wdGlvbnMgPyB0aGlzLnJlc29sdmUob3B0aW9ucykuZGVzY3JpYmUob3B0aW9ucykgOiB7XG4gICAgICB0eXBlOiAnbGF6eScsXG4gICAgICBtZXRhOiB0aGlzLnNwZWMubWV0YSxcbiAgICAgIGxhYmVsOiB1bmRlZmluZWRcbiAgICB9O1xuICB9XG4gIG1ldGEoLi4uYXJncykge1xuICAgIGlmIChhcmdzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHRoaXMuc3BlYy5tZXRhO1xuICAgIGxldCBuZXh0ID0gdGhpcy5jbG9uZSgpO1xuICAgIG5leHQuc3BlYy5tZXRhID0gT2JqZWN0LmFzc2lnbihuZXh0LnNwZWMubWV0YSB8fCB7fSwgYXJnc1swXSk7XG4gICAgcmV0dXJuIG5leHQ7XG4gIH1cbiAgZ2V0IFsnfnN0YW5kYXJkJ10oKSB7XG4gICAgY29uc3Qgc2NoZW1hID0gdGhpcztcbiAgICBjb25zdCBzdGFuZGFyZCA9IHtcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICB2ZW5kb3I6ICd5dXAnLFxuICAgICAgYXN5bmMgdmFsaWRhdGUodmFsdWUpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBzY2hlbWEudmFsaWRhdGUodmFsdWUsIHtcbiAgICAgICAgICAgIGFib3J0RWFybHk6IGZhbHNlXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHZhbHVlOiByZXN1bHRcbiAgICAgICAgICB9O1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICBpZiAoVmFsaWRhdGlvbkVycm9yLmlzRXJyb3IoZXJyKSkge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgaXNzdWVzOiBpc3N1ZXNGcm9tVmFsaWRhdGlvbkVycm9yKGVycilcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfVxuICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gICAgcmV0dXJuIHN0YW5kYXJkO1xuICB9XG59XG5cbmZ1bmN0aW9uIHNldExvY2FsZShjdXN0b20pIHtcbiAgT2JqZWN0LmtleXMoY3VzdG9tKS5mb3JFYWNoKHR5cGUgPT4ge1xuICAgIC8vIEB0cy1pZ25vcmVcbiAgICBPYmplY3Qua2V5cyhjdXN0b21bdHlwZV0pLmZvckVhY2gobWV0aG9kID0+IHtcbiAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgIGxvY2FsZVt0eXBlXVttZXRob2RdID0gY3VzdG9tW3R5cGVdW21ldGhvZF07XG4gICAgfSk7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiBhZGRNZXRob2Qoc2NoZW1hVHlwZSwgbmFtZSwgZm4pIHtcbiAgaWYgKCFzY2hlbWFUeXBlIHx8ICFpc1NjaGVtYShzY2hlbWFUeXBlLnByb3RvdHlwZSkpIHRocm93IG5ldyBUeXBlRXJyb3IoJ1lvdSBtdXN0IHByb3ZpZGUgYSB5dXAgc2NoZW1hIGNvbnN0cnVjdG9yIGZ1bmN0aW9uJyk7XG4gIGlmICh0eXBlb2YgbmFtZSAhPT0gJ3N0cmluZycpIHRocm93IG5ldyBUeXBlRXJyb3IoJ0EgTWV0aG9kIG5hbWUgbXVzdCBiZSBwcm92aWRlZCcpO1xuICBpZiAodHlwZW9mIGZuICE9PSAnZnVuY3Rpb24nKSB0aHJvdyBuZXcgVHlwZUVycm9yKCdNZXRob2QgZnVuY3Rpb24gbXVzdCBiZSBwcm92aWRlZCcpO1xuICBzY2hlbWFUeXBlLnByb3RvdHlwZVtuYW1lXSA9IGZuO1xufVxuXG5leHBvcnQgeyBBcnJheVNjaGVtYSwgQm9vbGVhblNjaGVtYSwgRGF0ZVNjaGVtYSwgTGF6eSBhcyBMYXp5U2NoZW1hLCBNaXhlZFNjaGVtYSwgTnVtYmVyU2NoZW1hLCBPYmplY3RTY2hlbWEsIFNjaGVtYSwgU3RyaW5nU2NoZW1hLCBUdXBsZVNjaGVtYSwgVmFsaWRhdGlvbkVycm9yLCBhZGRNZXRob2QsIGNyZWF0ZSQyIGFzIGFycmF5LCBjcmVhdGUkNyBhcyBib29sLCBjcmVhdGUkNyBhcyBib29sZWFuLCBjcmVhdGUkNCBhcyBkYXRlLCBsb2NhbGUgYXMgZGVmYXVsdExvY2FsZSwgZ2V0SW4sIGlzU2NoZW1hLCBjcmVhdGUgYXMgbGF6eSwgY3JlYXRlJDggYXMgbWl4ZWQsIGNyZWF0ZSQ1IGFzIG51bWJlciwgY3JlYXRlJDMgYXMgb2JqZWN0LCBwcmludFZhbHVlLCByZWFjaCwgY3JlYXRlJDkgYXMgcmVmLCBzZXRMb2NhbGUsIGNyZWF0ZSQ2IGFzIHN0cmluZywgY3JlYXRlJDEgYXMgdHVwbGUgfTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0NBS0EsU0FBUyxNQUFNLFNBQVM7RUFDdEIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssTUFBTTtDQUNiO0NBQ0EsTUFBTSxVQUFVLFFBQVEsV0FBWTtFQUNsQyxLQUFLLFFBQVE7RUFDYixLQUFLLFVBQVUsT0FBTyxPQUFPLElBQUk7Q0FDbkM7Q0FDQSxNQUFNLFVBQVUsTUFBTSxTQUFVLEtBQUs7RUFDbkMsT0FBTyxLQUFLLFFBQVE7Q0FDdEI7Q0FDQSxNQUFNLFVBQVUsTUFBTSxTQUFVLEtBQUssT0FBTztFQUMxQyxLQUFLLFNBQVMsS0FBSyxZQUFZLEtBQUssTUFBTTtFQUMxQyxJQUFJLEVBQUUsT0FBTyxLQUFLLFVBQVUsS0FBSztFQUVqQyxPQUFRLEtBQUssUUFBUSxPQUFPO0NBQzlCO0NBRUEsSUFBSSxjQUFjO0NBQ2hCLElBQUEsY0FBYztDQUNkLElBQUEsbUJBQW1CO0NBQ25CLElBQUEsa0JBQWtCO0NBQ2xCLElBQUEscUJBQXFCO0NBQ3JCLElBQUEsaUJBQWlCO0NBRW5CLElBQUksWUFBWSxJQUFJLE1BQU0sY0FBYztDQUN0QyxJQUFBLFdBQVcsSUFBSSxNQUFNLGNBQWM7Q0FDbkMsSUFBQSxXQUFXLElBQUksTUFBTSxjQUFjO0NBSXJDLE9BQU8sVUFBVTtFQUNSO0VBRUE7RUFFUTtFQUVmLFFBQVEsU0FBVSxNQUFNO0dBQ3RCLElBQUksUUFBUSxjQUFjLElBQUk7R0FFOUIsT0FDRSxTQUFTLElBQUksSUFBSSxLQUNqQixTQUFTLElBQUksTUFBTSxTQUFTLE9BQU8sS0FBSyxPQUFPO0lBQzdDLElBQUksUUFBUTtJQUNaLElBQUksTUFBTSxNQUFNO0lBQ2hCLElBQUksT0FBTztJQUVYLE9BQU8sUUFBUSxNQUFNLEdBQUc7S0FDdEIsSUFBSSxPQUFPLE1BQU07S0FDakIsSUFDRSxTQUFTLGVBQ1QsU0FBUyxpQkFDVCxTQUFTLGFBRVQsT0FBTztLQUdULE9BQU8sS0FBSyxNQUFNO0lBQ3BCO0lBQ0EsS0FBSyxNQUFNLFVBQVU7R0FDdkIsQ0FBQztFQUVMO0VBRUEsUUFBUSxTQUFVLE1BQU0sTUFBTTtHQUM1QixJQUFJLFFBQVEsY0FBYyxJQUFJO0dBQzlCLE9BQ0UsU0FBUyxJQUFJLElBQUksS0FDakIsU0FBUyxJQUFJLE1BQU0sU0FBUyxPQUFPLE1BQU07SUFDdkMsSUFBSSxRQUFRLEdBQ1YsTUFBTSxNQUFNO0lBQ2QsT0FBTyxRQUFRLEtBQ2IsSUFBSSxRQUFRLFFBQVEsQ0FBQyxNQUFNLE9BQU8sS0FBSyxNQUFNO1NBQ3hDO0lBRVAsT0FBTztHQUNULENBQUM7RUFFTDtFQUVBLE1BQU0sU0FBVSxVQUFVO0dBQ3hCLE9BQU8sU0FBUyxPQUFPLFNBQVUsTUFBTSxNQUFNO0lBQzNDLE9BQ0UsUUFDQyxTQUFTLElBQUksS0FBSyxZQUFZLEtBQUssSUFBSSxJQUNwQyxNQUFNLE9BQU8sT0FDWixPQUFPLE1BQU0sTUFBTTtHQUU1QixHQUFHLEVBQUU7RUFDUDtFQUVBLFNBQVMsU0FBVSxNQUFNLElBQUksU0FBUztHQUNwQyxRQUFRLE1BQU0sUUFBUSxJQUFJLElBQUksT0FBTyxNQUFNLElBQUksR0FBRyxJQUFJLE9BQU87RUFDL0Q7Q0FDRjtDQUVBLFNBQVMsY0FBYyxNQUFNO0VBQzNCLE9BQ0UsVUFBVSxJQUFJLElBQUksS0FDbEIsVUFBVSxJQUNSLE1BQ0EsTUFBTSxJQUFJLENBQUMsQ0FBQyxJQUFJLFNBQVUsTUFBTTtHQUM5QixPQUFPLEtBQUssUUFBUSxvQkFBb0IsSUFBSTtFQUM5QyxDQUFDLENBQ0g7Q0FFSjtDQUVBLFNBQVMsTUFBTSxNQUFNO0VBQ25CLE9BQU8sS0FBSyxNQUFNLFdBQVcsS0FBSyxDQUFDLEVBQUU7Q0FDdkM7Q0FFQSxTQUFTLFFBQVEsT0FBTyxNQUFNLFNBQVM7RUFDckMsSUFBSSxNQUFNLE1BQU0sUUFDZCxNQUNBLEtBQ0EsU0FDQTtFQUVGLEtBQUssTUFBTSxHQUFHLE1BQU0sS0FBSyxPQUFPO0dBQzlCLE9BQU8sTUFBTTtHQUViLElBQUksTUFBTTtJQUNSLElBQUksZUFBZSxJQUFJLEdBQ3JCLE9BQU8sT0FBTSxPQUFPO0lBR3RCLFlBQVksU0FBUyxJQUFJO0lBQ3pCLFVBQVUsQ0FBQyxhQUFhLFFBQVEsS0FBSyxJQUFJO0lBRXpDLEtBQUssS0FBSyxTQUFTLE1BQU0sV0FBVyxTQUFTLEtBQUssS0FBSztHQUN6RDtFQUNGO0NBQ0Y7Q0FFQSxTQUFTLFNBQVMsS0FBSztFQUNyQixPQUNFLE9BQU8sUUFBUSxZQUFZLE9BQU8sQ0FBQyxLQUFLLElBQUcsQ0FBQyxDQUFDLFFBQVEsSUFBSSxPQUFPLENBQUMsQ0FBQyxNQUFNO0NBRTVFO0NBRUEsU0FBUyxpQkFBaUIsTUFBTTtFQUM5QixPQUFPLEtBQUssTUFBTSxnQkFBZ0IsS0FBSyxDQUFDLEtBQUssTUFBTSxXQUFXO0NBQ2hFO0NBRUEsU0FBUyxnQkFBZ0IsTUFBTTtFQUM3QixPQUFPLGdCQUFnQixLQUFLLElBQUk7Q0FDbEM7Q0FFQSxTQUFTLGVBQWUsTUFBTTtFQUM1QixPQUFPLENBQUMsU0FBUyxJQUFJLE1BQU0saUJBQWlCLElBQUksS0FBSyxnQkFBZ0IsSUFBSTtDQUMzRTs7Ozs7Q0M3SkEsSUFBTSxVQUFVO0NBRWhCLElBQU0sU0FBUyxRQUFRLElBQUksTUFBTSxPQUFPLEtBQUssQ0FBQztDQUU5QyxJQUFNLGNBQWMsUUFBUSxJQUFJLEVBQUUsQ0FBQyxZQUFZLElBQUksSUFBSSxNQUFNLENBQUM7Q0FFOUQsSUFBTSxRQUFRLEtBQUssTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsWUFBWTtDQUV4RCxJQUFNLGFBQWEsUUFDakIsTUFBTSxHQUFHLENBQUMsQ0FBQyxRQUNSLEtBQUssU0FDSixHQUFHLE1BQ0QsQ0FBQyxNQUNHLEtBQUssWUFBWSxJQUNqQixLQUFLLEVBQUUsQ0FBQyxZQUFZLElBQUksS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLFlBQVksS0FFMUQsRUFDRjtDQUVGLElBQU0sY0FBYyxRQUFRLFdBQVcsVUFBVSxHQUFHLENBQUM7Q0FFckQsSUFBTSxhQUFhLFFBQVEsS0FBSyxLQUFLLEdBQUc7Q0FFeEMsSUFBTSxhQUFhLFFBQVEsS0FBSyxLQUFLLEdBQUc7Q0FFeEMsSUFBTSxnQkFBZ0IsUUFBUSxXQUFXLEtBQUssS0FBSyxHQUFHLENBQUM7Q0FFdkQsSUFBTSxhQUFhLFFBQVEsTUFBTSxHQUFHLENBQUMsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxDQUFDLEtBQUssR0FBRztDQUU5RCxPQUFPLFVBQVU7RUFDZjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7Ozs7Ozs7Ozs7O0NDOUJBLE9BQU8sVUFBVSxTQUFTLE9BQU87RUFDL0IsT0FBTyxTQUFTLFlBQVksS0FBSyxHQUFHLEtBQUs7Q0FDM0M7Q0FFQSxPQUFPLFFBQVEsUUFBUTtDQUV2QixTQUFTLFNBQVMsT0FBTyxPQUFPO0VBQzlCLElBQUksU0FBUyxNQUFNLFFBQ2YsU0FBUyxJQUFJLE1BQU0sTUFBTSxHQUN6QixVQUFVLENBQUMsR0FDWCxJQUFJLFFBRUosZ0JBQWdCLGtCQUFrQixLQUFLLEdBQ3ZDLFlBQVksY0FBYyxLQUFLO0VBR25DLE1BQU0sUUFBUSxTQUFTLE1BQU07R0FDM0IsSUFBSSxDQUFDLFVBQVUsSUFBSSxLQUFLLEVBQUUsS0FBSyxDQUFDLFVBQVUsSUFBSSxLQUFLLEVBQUUsR0FDbkQsTUFBTSxJQUFJLE1BQU0sK0RBQStEO0VBRW5GLENBQUM7RUFFRCxPQUFPLEtBQ0wsSUFBSSxDQUFDLFFBQVEsSUFBSSxNQUFNLE1BQU0sSUFBSSxtQkFBRyxJQUFJLElBQUksQ0FBQztFQUcvQyxPQUFPO0VBRVAsU0FBUyxNQUFNLE1BQU0sR0FBRyxjQUFjO0dBQ3BDLElBQUcsYUFBYSxJQUFJLElBQUksR0FBRztJQUN6QixJQUFJO0lBQ0osSUFBSTtLQUNGLFVBQVUsZ0JBQWdCLEtBQUssVUFBVSxJQUFJO0lBQy9DLFNBQVEsR0FBRztLQUNULFVBQVU7SUFDWjtJQUNBLE1BQU0sSUFBSSxNQUFNLHNCQUFzQixPQUFPO0dBQy9DO0dBRUEsSUFBSSxDQUFDLFVBQVUsSUFBSSxJQUFJLEdBQ3JCLE1BQU0sSUFBSSxNQUFNLGlGQUErRSxLQUFLLFVBQVUsSUFBSSxDQUFDO0dBR3JILElBQUksUUFBUSxJQUFJO0dBQ2hCLFFBQVEsS0FBSztHQUViLElBQUksV0FBVyxjQUFjLElBQUksSUFBSSxxQkFBSyxJQUFJLElBQUk7R0FDbEQsV0FBVyxNQUFNLEtBQUssUUFBUTtHQUU5QixJQUFJLElBQUksU0FBUyxRQUFRO0lBQ3ZCLGFBQWEsSUFBSSxJQUFJO0lBQ3JCLEdBQUc7S0FDRCxJQUFJLFFBQVEsU0FBUyxFQUFFO0tBQ3ZCLE1BQU0sT0FBTyxVQUFVLElBQUksS0FBSyxHQUFHLFlBQVk7SUFDakQsU0FBUztJQUNULGFBQWEsT0FBTyxJQUFJO0dBQzFCO0dBRUEsT0FBTyxFQUFFLFVBQVU7RUFDckI7Q0FDRjtDQUVBLFNBQVMsWUFBWSxLQUFJO0VBQ3ZCLElBQUksc0JBQU0sSUFBSSxJQUFJO0VBQ2xCLEtBQUssSUFBSSxJQUFJLEdBQUcsTUFBTSxJQUFJLFFBQVEsSUFBSSxLQUFLLEtBQUs7R0FDOUMsSUFBSSxPQUFPLElBQUk7R0FDZixJQUFJLElBQUksS0FBSyxFQUFFO0dBQ2YsSUFBSSxJQUFJLEtBQUssRUFBRTtFQUNqQjtFQUNBLE9BQU8sTUFBTSxLQUFLLEdBQUc7Q0FDdkI7Q0FFQSxTQUFTLGtCQUFrQixLQUFJO0VBQzdCLElBQUksd0JBQVEsSUFBSSxJQUFJO0VBQ3BCLEtBQUssSUFBSSxJQUFJLEdBQUcsTUFBTSxJQUFJLFFBQVEsSUFBSSxLQUFLLEtBQUs7R0FDOUMsSUFBSSxPQUFPLElBQUk7R0FDZixJQUFJLENBQUMsTUFBTSxJQUFJLEtBQUssRUFBRSxHQUFHLE1BQU0sSUFBSSxLQUFLLG9CQUFJLElBQUksSUFBSSxDQUFDO0dBQ3JELElBQUksQ0FBQyxNQUFNLElBQUksS0FBSyxFQUFFLEdBQUcsTUFBTSxJQUFJLEtBQUssb0JBQUksSUFBSSxJQUFJLENBQUM7R0FDckQsTUFBTSxJQUFJLEtBQUssRUFBRSxDQUFDLENBQUMsSUFBSSxLQUFLLEVBQUU7RUFDaEM7RUFDQSxPQUFPO0NBQ1Q7Q0FFQSxTQUFTLGNBQWMsS0FBSTtFQUN6QixJQUFJLHNCQUFNLElBQUksSUFBSTtFQUNsQixLQUFLLElBQUksSUFBSSxHQUFHLE1BQU0sSUFBSSxRQUFRLElBQUksS0FBSyxLQUN6QyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUM7RUFFbkIsT0FBTztDQUNUOzs7Ozs7O0FDN0ZBLElBQU0sV0FBVyxPQUFPLFVBQVU7QUFDbEMsSUFBTSxnQkFBZ0IsTUFBTSxVQUFVO0FBQ3RDLElBQU0saUJBQWlCLE9BQU8sVUFBVTtBQUN4QyxJQUFNLGlCQUFpQixPQUFPLFdBQVcsY0FBYyxPQUFPLFVBQVUsaUJBQWlCO0FBQ3pGLElBQU0sZ0JBQWdCO0FBQ3RCLFNBQVMsWUFBWSxLQUFLO0NBQ3hCLElBQUksT0FBTyxDQUFDLEtBQUssT0FBTztDQUV4QixPQUR1QixRQUFRLEtBQUssSUFBSSxNQUFNLElBQ3RCLE9BQU8sS0FBSztBQUN0QztBQUNBLFNBQVMsaUJBQWlCLEtBQUssZUFBZSxPQUFPO0NBQ25ELElBQUksT0FBTyxRQUFRLFFBQVEsUUFBUSxRQUFRLE9BQU8sT0FBTyxLQUFLO0NBQzlELE1BQU0sU0FBUyxPQUFPO0NBQ3RCLElBQUksV0FBVyxVQUFVLE9BQU8sWUFBWSxHQUFHO0NBQy9DLElBQUksV0FBVyxVQUFVLE9BQU8sZUFBZSxJQUFJLElBQUksS0FBSztDQUM1RCxJQUFJLFdBQVcsWUFBWSxPQUFPLGdCQUFnQixJQUFJLFFBQVEsZUFBZTtDQUM3RSxJQUFJLFdBQVcsVUFBVSxPQUFPLGVBQWUsS0FBSyxHQUFHLENBQUMsQ0FBQyxRQUFRLGVBQWUsWUFBWTtDQUM1RixNQUFNLE1BQU0sU0FBUyxLQUFLLEdBQUcsQ0FBQyxDQUFDLE1BQU0sR0FBRyxFQUFFO0NBQzFDLElBQUksUUFBUSxRQUFRLE9BQU8sTUFBTSxJQUFJLFFBQVEsQ0FBQyxJQUFJLEtBQUssTUFBTSxJQUFJLFlBQVksR0FBRztDQUNoRixJQUFJLFFBQVEsV0FBVyxlQUFlLE9BQU8sT0FBTyxNQUFNLGNBQWMsS0FBSyxHQUFHLElBQUk7Q0FDcEYsSUFBSSxRQUFRLFVBQVUsT0FBTyxlQUFlLEtBQUssR0FBRztDQUNwRCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLFdBQVcsT0FBTyxjQUFjO0NBQ3ZDLElBQUksU0FBUyxpQkFBaUIsT0FBTyxZQUFZO0NBQ2pELElBQUksV0FBVyxNQUFNLE9BQU87Q0FDNUIsT0FBTyxLQUFLLFVBQVUsT0FBTyxTQUFVLEtBQUssT0FBTztFQUNqRCxJQUFJLFNBQVMsaUJBQWlCLEtBQUssTUFBTSxZQUFZO0VBQ3JELElBQUksV0FBVyxNQUFNLE9BQU87RUFDNUIsT0FBTztDQUNULEdBQUcsQ0FBQztBQUNOO0FBRUEsU0FBUyxRQUFRLE9BQU87Q0FDdEIsT0FBTyxTQUFTLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sS0FBSztBQUM3QztBQUVBLElBQUk7QUFBcUIsSUFBQTtBQUFxQixJQUFBO0FBQzlDLElBQUksU0FBUztBQUNiLHNCQUFzQixPQUFPO0FBQzdCLElBQU0seUJBQU4sTUFBNkI7Q0FDM0IsWUFBWSxlQUFlLE9BQU8sT0FBTyxNQUFNO0VBQzdDLEtBQUssT0FBTyxLQUFLO0VBQ2pCLEtBQUssVUFBVSxLQUFLO0VBQ3BCLEtBQUssUUFBUSxLQUFLO0VBQ2xCLEtBQUssT0FBTyxLQUFLO0VBQ2pCLEtBQUssT0FBTyxLQUFLO0VBQ2pCLEtBQUssU0FBUyxLQUFLO0VBQ25CLEtBQUssU0FBUyxLQUFLO0VBQ25CLEtBQUssUUFBUSxLQUFLO0VBQ2xCLEtBQUssdUJBQXVCO0VBQzVCLEtBQUssT0FBTztFQUNaLEtBQUssUUFBUTtFQUNiLEtBQUssT0FBTztFQUNaLEtBQUssT0FBTztFQUNaLEtBQUssU0FBUyxDQUFDO0VBQ2YsS0FBSyxRQUFRLENBQUM7RUFDZCxRQUFRLGFBQWEsQ0FBQyxDQUFDLFNBQVEsUUFBTztHQUNwQyxJQUFJLGdCQUFnQixRQUFRLEdBQUcsR0FBRztJQUNoQyxLQUFLLE9BQU8sS0FBSyxHQUFHLElBQUksTUFBTTtJQUM5QixNQUFNLGNBQWMsSUFBSSxNQUFNLFNBQVMsSUFBSSxRQUFRLENBQUMsR0FBRztJQUN2RCxLQUFLLE1BQU0sS0FBSyxHQUFHLFdBQVc7R0FDaEMsT0FDRSxLQUFLLE9BQU8sS0FBSyxHQUFHO0VBRXhCLENBQUM7RUFDRCxLQUFLLFVBQVUsS0FBSyxPQUFPLFNBQVMsSUFBSSxHQUFHLEtBQUssT0FBTyxPQUFPLG9CQUFvQixLQUFLLE9BQU87Q0FDaEc7QUFDRjtBQUNBLHNCQUFzQixPQUFPO0FBQzdCLHVCQUF1QixPQUFPO0FBQzlCLElBQU0sa0JBQU4sTUFBTSx3QkFBd0IsTUFBTTtDQUNsQyxPQUFPLFlBQVksU0FBUyxRQUFRO0VBRWxDLE1BQU0sT0FBTyxPQUFPLFNBQVMsT0FBTyxRQUFRO0VBRzVDLFNBQVMsT0FBTyxPQUFPLENBQUMsR0FBRyxRQUFRO0dBQ2pDO0dBQ0EsY0FBYyxPQUFPO0VBQ3ZCLENBQUM7RUFDRCxJQUFJLE9BQU8sWUFBWSxVQUFVLE9BQU8sUUFBUSxRQUFRLFNBQVMsR0FBRyxRQUFRLFdBQVcsT0FBTyxJQUFJLENBQUM7RUFDbkcsSUFBSSxPQUFPLFlBQVksWUFBWSxPQUFPLFFBQVEsTUFBTTtFQUN4RCxPQUFPO0NBQ1Q7Q0FDQSxPQUFPLFFBQVEsS0FBSztFQUNsQixPQUFPLE9BQU8sSUFBSSxTQUFTO0NBQzdCO0NBQ0EsWUFBWSxlQUFlLE9BQU8sT0FBTyxNQUFNLGNBQWM7RUFDM0QsTUFBTSxlQUFlLElBQUksdUJBQXVCLGVBQWUsT0FBTyxPQUFPLElBQUk7RUFDakYsSUFBSSxjQUNGLE9BQU87RUFFVCxNQUFNO0VBQ04sS0FBSyxRQUFRLEtBQUs7RUFDbEIsS0FBSyxPQUFPLEtBQUs7RUFDakIsS0FBSyxPQUFPLEtBQUs7RUFDakIsS0FBSyxTQUFTLEtBQUs7RUFDbkIsS0FBSyxTQUFTLENBQUM7RUFDZixLQUFLLFFBQVEsQ0FBQztFQUNkLEtBQUssd0JBQXdCO0VBQzdCLEtBQUssT0FBTyxhQUFhO0VBQ3pCLEtBQUssVUFBVSxhQUFhO0VBQzVCLEtBQUssT0FBTyxhQUFhO0VBQ3pCLEtBQUssUUFBUSxhQUFhO0VBQzFCLEtBQUssT0FBTyxhQUFhO0VBQ3pCLEtBQUssU0FBUyxhQUFhO0VBQzNCLEtBQUssUUFBUSxhQUFhO0VBQzFCLElBQUksTUFBTSxtQkFDUixNQUFNLGtCQUFrQixNQUFNLGVBQWU7Q0FFakQ7Q0FDQSxRQUFRLHFCQUFxQixNQUFNO0VBQ2pDLE9BQU8sdUJBQXVCLE9BQU8sWUFBWSxDQUFDLElBQUksS0FBSyxNQUFNLE9BQU8sWUFBWSxDQUFDLElBQUk7Q0FDM0Y7QUFDRjtBQUVBLElBQUksUUFBUTtDQUNWLFNBQVM7Q0FDVCxVQUFVO0NBQ1YsU0FBUztDQUNULFNBQVM7Q0FDVCxPQUFPO0NBQ1AsVUFBVTtDQUNWLFVBQVUsRUFDUixNQUNBLE1BQ0EsT0FDQSxvQkFDSTtFQUNKLE1BQU0sVUFBVSxpQkFBaUIsUUFBUSxrQkFBa0IsUUFBUSwyQkFBMkIsV0FBVyxlQUFlLElBQUksRUFBRSxRQUFRO0VBQ3RJLE9BQU8sU0FBUyxVQUFVLEdBQUcsS0FBSyxlQUFlLEtBQUssc0NBQTJDLFdBQVcsT0FBTyxJQUFJLEVBQUUsTUFBTSxVQUFVLEdBQUcsS0FBSyw4REFBbUUsV0FBVyxPQUFPLElBQUksRUFBRSxNQUFNO0NBQ3BQO0FBQ0Y7QUFDQSxJQUFJLFNBQVM7Q0FDWCxRQUFRO0NBQ1IsS0FBSztDQUNMLEtBQUs7Q0FDTCxTQUFTO0NBQ1QsT0FBTztDQUNQLEtBQUs7Q0FDTCxNQUFNO0NBQ04sVUFBVTtDQUNWLG9CQUFvQjtDQUNwQixpQkFBaUI7Q0FDakIsTUFBTTtDQUNOLFdBQVc7Q0FDWCxXQUFXO0FBQ2I7QUFDQSxJQUFJLFNBQVM7Q0FDWCxLQUFLO0NBQ0wsS0FBSztDQUNMLFVBQVU7Q0FDVixVQUFVO0NBQ1YsVUFBVTtDQUNWLFVBQVU7Q0FDVixTQUFTO0FBQ1g7QUFDQSxJQUFJLE9BQU87Q0FDVCxLQUFLO0NBQ0wsS0FBSztBQUNQO0FBQ0EsSUFBSSxVQUFVLEVBQ1osU0FBUyxpQ0FDWDtBQUNBLElBQUksU0FBUztDQUNYLFdBQVc7Q0FDWCxPQUFPO0FBQ1Q7QUFDQSxJQUFJLFFBQVE7Q0FDVixLQUFLO0NBQ0wsS0FBSztDQUNMLFFBQVE7QUFDVjtBQUNBLElBQUksUUFBUSxFQUNWLFVBQVMsV0FBVTtDQUNqQixNQUFNLEVBQ0osTUFDQSxPQUNBLFNBQ0U7Q0FDSixNQUFNLFVBQVUsS0FBSyxNQUFNO0NBQzNCLElBQUksTUFBTSxRQUFRLEtBQUssR0FBRztFQUN4QixJQUFJLE1BQU0sU0FBUyxTQUFTLE9BQU8sR0FBRyxLQUFLLHVEQUF1RCxRQUFRLFdBQVcsTUFBTSxPQUFPLGdCQUFnQixXQUFXLE9BQU8sSUFBSSxFQUFFO0VBQzFLLElBQUksTUFBTSxTQUFTLFNBQVMsT0FBTyxHQUFHLEtBQUssd0RBQXdELFFBQVEsV0FBVyxNQUFNLE9BQU8sZ0JBQWdCLFdBQVcsT0FBTyxJQUFJLEVBQUU7Q0FDN0s7Q0FDQSxPQUFPLGdCQUFnQixZQUFZLE1BQU0sU0FBUyxNQUFNO0FBQzFELEVBQ0Y7QUFDQSxJQUFJLFNBQVMsT0FBTyxPQUFPLE9BQU8sT0FBTyxJQUFJLEdBQUc7Q0FDOUM7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNGLENBQUM7QUFFRCxJQUFNLFlBQVcsUUFBTyxPQUFPLElBQUk7QUFFbkMsSUFBTSxZQUFOLE1BQU0sVUFBVTtDQUNkLE9BQU8sWUFBWSxNQUFNLFFBQVE7RUFDL0IsSUFBSSxDQUFDLE9BQU8sUUFBUSxDQUFDLE9BQU8sV0FBVyxNQUFNLElBQUksVUFBVSxvRUFBb0U7RUFDL0gsSUFBSSxFQUNGLElBQ0EsTUFDQSxjQUNFO0VBQ0osSUFBSSxRQUFRLE9BQU8sT0FBTyxhQUFhLE1BQU0sR0FBRyxXQUFXLE9BQU8sT0FBTSxVQUFTLFVBQVUsRUFBRTtFQUM3RixPQUFPLElBQUksVUFBVSxPQUFPLFFBQVEsV0FBVztHQUM3QyxJQUFJO0dBQ0osSUFBSSxTQUFTLE1BQU0sR0FBRyxNQUFNLElBQUksT0FBTztHQUN2QyxRQUFRLFVBQVUsVUFBVSxPQUFPLEtBQUssSUFBSSxPQUFPLE1BQU0sTUFBTSxPQUFPLFVBQVU7RUFDbEYsQ0FBQztDQUNIO0NBQ0EsWUFBWSxNQUFNLFNBQVM7RUFDekIsS0FBSyxLQUFLLEtBQUs7RUFDZixLQUFLLE9BQU87RUFDWixLQUFLLE9BQU87RUFDWixLQUFLLEtBQUs7Q0FDWjtDQUNBLFFBQVEsTUFBTSxTQUFTO0VBQ3JCLElBQUksU0FBUyxLQUFLLEtBQUssS0FBSSxRQUUzQixJQUFJLFNBQVMsV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLE9BQU8sV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLFFBQVEsV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLE9BQU8sQ0FBQztFQUM3SSxJQUFJLFNBQVMsS0FBSyxHQUFHLFFBQVEsTUFBTSxPQUFPO0VBQzFDLElBQUksV0FBVyxLQUFBLEtBRWYsV0FBVyxNQUNULE9BQU87RUFFVCxJQUFJLENBQUMsU0FBUyxNQUFNLEdBQUcsTUFBTSxJQUFJLFVBQVUsd0NBQXdDO0VBQ25GLE9BQU8sT0FBTyxRQUFRLE9BQU87Q0FDL0I7QUFDRjtBQUVBLElBQU0sV0FBVztDQUNmLFNBQVM7Q0FDVCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLFNBQVMsS0FBSyxTQUFTO0NBQzlCLE9BQU8sSUFBSSxVQUFVLEtBQUssT0FBTztBQUNuQztBQUNBLElBQU0sWUFBTixNQUFnQjtDQUNkLFlBQVksS0FBSyxVQUFVLENBQUMsR0FBRztFQUM3QixLQUFLLE1BQU0sS0FBSztFQUNoQixLQUFLLFlBQVksS0FBSztFQUN0QixLQUFLLFVBQVUsS0FBSztFQUNwQixLQUFLLFlBQVksS0FBSztFQUN0QixLQUFLLE9BQU8sS0FBSztFQUNqQixLQUFLLFNBQVMsS0FBSztFQUNuQixLQUFLLE1BQU0sS0FBSztFQUNoQixJQUFJLE9BQU8sUUFBUSxVQUFVLE1BQU0sSUFBSSxVQUFVLGdDQUFnQyxHQUFHO0VBQ3BGLEtBQUssTUFBTSxJQUFJLEtBQUs7RUFDcEIsSUFBSSxRQUFRLElBQUksTUFBTSxJQUFJLFVBQVUsZ0NBQWdDO0VBQ3BFLEtBQUssWUFBWSxLQUFLLElBQUksT0FBTyxTQUFTO0VBQzFDLEtBQUssVUFBVSxLQUFLLElBQUksT0FBTyxTQUFTO0VBQ3hDLEtBQUssWUFBWSxDQUFDLEtBQUssYUFBYSxDQUFDLEtBQUs7RUFDMUMsSUFBSSxTQUFTLEtBQUssWUFBWSxTQUFTLFVBQVUsS0FBSyxVQUFVLFNBQVMsUUFBUTtFQUNqRixLQUFLLE9BQU8sS0FBSyxJQUFJLE1BQU0sT0FBTyxNQUFNO0VBQ3hDLEtBQUssU0FBUyxLQUFLLFNBQUEsR0FBUUEscUJBQUFBLE9BQUFBLENBQU8sS0FBSyxNQUFNLElBQUk7RUFDakQsS0FBSyxNQUFNLFFBQVE7Q0FDckI7Q0FDQSxTQUFTLE9BQU8sUUFBUSxTQUFTO0VBQy9CLElBQUksU0FBUyxLQUFLLFlBQVksVUFBVSxLQUFLLFVBQVUsUUFBUTtFQUMvRCxJQUFJLEtBQUssUUFBUSxTQUFTLEtBQUssT0FBTyxVQUFVLENBQUMsQ0FBQztFQUNsRCxJQUFJLEtBQUssS0FBSyxTQUFTLEtBQUssSUFBSSxNQUFNO0VBQ3RDLE9BQU87Q0FDVDs7Ozs7Ozs7Q0FTQSxLQUFLLE9BQU8sU0FBUztFQUNuQixPQUFPLEtBQUssU0FBUyxPQUFPLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSxRQUFRLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSxPQUFPO0NBQ25IO0NBQ0EsVUFBVTtFQUNSLE9BQU87Q0FDVDtDQUNBLFdBQVc7RUFDVCxPQUFPO0dBQ0wsTUFBTTtHQUNOLEtBQUssS0FBSztFQUNaO0NBQ0Y7Q0FDQSxXQUFXO0VBQ1QsT0FBTyxPQUFPLEtBQUssSUFBSTtDQUN6QjtDQUNBLE9BQU8sTUFBTSxPQUFPO0VBQ2xCLE9BQU8sU0FBUyxNQUFNO0NBQ3hCO0FBQ0Y7QUFHQSxVQUFVLFVBQVUsYUFBYTtBQUVqQyxJQUFNLFlBQVcsVUFBUyxTQUFTO0FBRW5DLFNBQVMsaUJBQWlCLFFBQVE7Q0FDaEMsU0FBUyxTQUFTLEVBQ2hCLE9BQ0EsT0FBTyxJQUNQLFNBQ0EsZUFDQSxVQUNDLE9BQU8sTUFBTTtFQUNkLE1BQU0sRUFDSixNQUNBLE1BQ0EsUUFDQSxTQUNBLGVBQ0U7RUFDSixJQUFJLEVBQ0YsUUFDQSxTQUNBLGFBQWEsT0FBTyxLQUFLLFlBQ3pCLG9CQUFvQixPQUFPLEtBQUssc0JBQzlCO0VBQ0osTUFBTSxpQkFBaUI7R0FDckI7R0FDQTtHQUNBO0VBQ0Y7RUFDQSxTQUFTLFlBQVksWUFBWSxDQUFDLEdBQUc7R0FDbkMsTUFBTSxhQUFhLGNBQWMsT0FBTyxPQUFPO0lBQzdDO0lBQ0E7SUFDQSxPQUFPLE9BQU8sS0FBSztJQUNuQixNQUFNLFVBQVUsUUFBUTtJQUN4QixNQUFNLE9BQU87SUFDYixtQkFBbUIsVUFBVSxxQkFBcUI7R0FDcEQsR0FBRyxRQUFRLFVBQVUsTUFBTSxHQUFHLGNBQWM7R0FDNUMsTUFBTSxRQUFRLElBQUksZ0JBQWdCLGdCQUFnQixZQUFZLFVBQVUsV0FBVyxTQUFTLFVBQVUsR0FBRyxPQUFPLFdBQVcsTUFBTSxVQUFVLFFBQVEsTUFBTSxXQUFXLGlCQUFpQjtHQUNyTCxNQUFNLFNBQVM7R0FDZixPQUFPO0VBQ1Q7RUFDQSxNQUFNLFVBQVUsYUFBYSxRQUFRO0VBQ3JDLElBQUksTUFBTTtHQUNSO0dBQ0E7R0FDQSxNQUFNO0dBQ04sTUFBTSxRQUFRO0dBQ2Q7R0FDQSxRQUFRLE1BQU07SUFDWixPQUFPLGdCQUFnQixNQUFNLGNBQWM7R0FDN0M7R0FDQTtHQUNBO0dBQ0E7RUFDRjtFQUNBLE1BQU0sZ0JBQWUsaUJBQWdCO0dBQ25DLElBQUksZ0JBQWdCLFFBQVEsWUFBWSxHQUFHLFFBQVEsWUFBWTtRQUFPLElBQUksQ0FBQyxjQUFjLFFBQVEsWUFBWSxDQUFDO1FBQU8sS0FBSyxJQUFJO0VBQ2hJO0VBQ0EsTUFBTSxlQUFjLFFBQU87R0FDekIsSUFBSSxnQkFBZ0IsUUFBUSxHQUFHLEdBQUcsUUFBUSxHQUFHO1FBQU8sTUFBTSxHQUFHO0VBQy9EO0VBRUEsSUFEbUIsY0FBYyxTQUFTLEtBQUssR0FFN0MsT0FBTyxhQUFhLElBQUk7RUFFMUIsSUFBSTtFQUNKLElBQUk7R0FDRixJQUFJO0dBQ0osU0FBUyxLQUFLLEtBQUssS0FBSyxPQUFPLEdBQUc7R0FDbEMsSUFBSSxTQUFTLFVBQVUsV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLFVBQVUsWUFBWTtJQUM5RSxJQUFJLFFBQVEsTUFDVixNQUFNLElBQUksTUFBTSw2QkFBNkIsSUFBSSxLQUFLLCtHQUFvSDtJQUU1SyxPQUFPLFFBQVEsUUFBUSxNQUFNLENBQUMsQ0FBQyxLQUFLLGNBQWMsV0FBVztHQUMvRDtFQUNGLFNBQVMsS0FBSztHQUNaLFlBQVksR0FBRztHQUNmO0VBQ0Y7RUFDQSxhQUFhLE1BQU07Q0FDckI7Q0FDQSxTQUFTLFVBQVU7Q0FDbkIsT0FBTztBQUNUO0FBR0EsU0FBUyxjQUFjLFFBQVEsU0FBUztDQUN0QyxJQUFJLENBQUMsUUFBUSxPQUFPO0NBQ3BCLEtBQUssTUFBTSxPQUFPLE9BQU8sS0FBSyxNQUFNLEdBQ2xDLE9BQU8sT0FBTyxnQkFBZ0IsT0FBTyxNQUFNLE9BQU87Q0FFcEQsT0FBTztBQUNUO0FBQ0EsU0FBUyxnQkFBZ0IsTUFBTSxTQUFTO0NBQ3RDLE9BQU8sVUFBVSxNQUFNLElBQUksSUFBSSxLQUFLLFNBQVMsUUFBUSxPQUFPLFFBQVEsUUFBUSxRQUFRLE9BQU8sSUFBSTtBQUNqRztBQUVBLFNBQVMsTUFBTSxRQUFRLE1BQU0sT0FBTyxVQUFVLE9BQU87Q0FDbkQsSUFBSSxRQUFRLFVBQVU7Q0FHdEIsSUFBSSxDQUFDLE1BQU0sT0FBTztFQUNoQjtFQUNBLFlBQVk7RUFDWjtDQUNGO0NBQ0EsQ0FBQSxHQUFBLHFCQUFBLFFBQUEsQ0FBUSxPQUFPLE9BQU8sV0FBVyxZQUFZO0VBQzNDLElBQUksT0FBTyxZQUFZLE1BQU0sTUFBTSxHQUFHLE1BQU0sU0FBUyxDQUFDLElBQUk7RUFDMUQsU0FBUyxPQUFPLFFBQVE7R0FDdEI7R0FDQTtHQUNBO0VBQ0YsQ0FBQztFQUNELElBQUksVUFBVSxPQUFPLFNBQVM7RUFDOUIsSUFBSSxNQUFNLFVBQVUsU0FBUyxNQUFNLEVBQUUsSUFBSTtFQUN6QyxJQUFJLE9BQU8sYUFBYSxTQUFTO0dBQy9CLElBQUksV0FBVyxDQUFDLFNBQVMsTUFBTSxJQUFJLE1BQU0sdUVBQXVFLGNBQWMsc0RBQXNELGNBQWMsS0FBSztHQUN2TSxJQUFJLFNBQVMsT0FBTyxNQUFNLFFBQ3hCLE1BQU0sSUFBSSxNQUFNLG9EQUFvRCxNQUFNLGlCQUFpQixLQUFLLDRDQUFpRDtHQUVuSixTQUFTO0dBQ1QsUUFBUSxTQUFTLE1BQU07R0FDdkIsU0FBUyxVQUFVLE9BQU8sS0FBSyxNQUFNLE9BQU8sT0FBTztFQUNyRDtFQU1BLElBQUksQ0FBQyxTQUFTO0dBQ1osSUFBSSxDQUFDLE9BQU8sVUFBVSxDQUFDLE9BQU8sT0FBTyxPQUFPLE1BQU0sSUFBSSxNQUFNLHlDQUF5QyxLQUFLLGdCQUFxQixjQUFjLHFCQUFxQixPQUFPLEtBQUssR0FBRztHQUNqTCxTQUFTO0dBQ1QsUUFBUSxTQUFTLE1BQU07R0FDdkIsU0FBUyxPQUFPLE9BQU87RUFDekI7RUFDQSxXQUFXO0VBQ1gsZ0JBQWdCLFlBQVksTUFBTSxRQUFRLE1BQU0sTUFBTTtDQUN4RCxDQUFDO0NBQ0QsT0FBTztFQUNMO0VBQ0E7RUFDQSxZQUFZO0NBQ2Q7QUFDRjtBQUNBLFNBQVMsTUFBTSxLQUFLLE1BQU0sT0FBTyxTQUFTO0NBQ3hDLE9BQU8sTUFBTSxLQUFLLE1BQU0sT0FBTyxPQUFPLENBQUMsQ0FBQztBQUMxQztBQUVBLElBQU0sZUFBTixNQUFNLHFCQUFxQixJQUFJO0NBQzdCLFdBQVc7RUFDVCxNQUFNLGNBQWMsQ0FBQztFQUNyQixLQUFLLE1BQU0sUUFBUSxLQUFLLE9BQU8sR0FDN0IsWUFBWSxLQUFLLFVBQVUsTUFBTSxJQUFJLElBQUksS0FBSyxTQUFTLElBQUksSUFBSTtFQUVqRSxPQUFPO0NBQ1Q7Q0FDQSxXQUFXLFNBQVM7RUFDbEIsSUFBSSxTQUFTLENBQUM7RUFDZCxLQUFLLE1BQU0sUUFBUSxLQUFLLE9BQU8sR0FDN0IsT0FBTyxLQUFLLFFBQVEsSUFBSSxDQUFDO0VBRTNCLE9BQU87Q0FDVDtDQUNBLFFBQVE7RUFDTixPQUFPLElBQUksYUFBYSxLQUFLLE9BQU8sQ0FBQztDQUN2QztDQUNBLE1BQU0sVUFBVSxhQUFhO0VBQzNCLE1BQU0sT0FBTyxLQUFLLE1BQU07RUFDeEIsU0FBUyxTQUFRLFVBQVMsS0FBSyxJQUFJLEtBQUssQ0FBQztFQUN6QyxZQUFZLFNBQVEsVUFBUyxLQUFLLE9BQU8sS0FBSyxDQUFDO0VBQy9DLE9BQU87Q0FDVDtBQUNGO0FBR0EsU0FBUyxNQUFNLEtBQUssdUJBQU8sSUFBSSxJQUFJLEdBQUc7Q0FDcEMsSUFBSSxTQUFTLEdBQUcsS0FBSyxDQUFDLE9BQU8sT0FBTyxRQUFRLFVBQVUsT0FBTztDQUM3RCxJQUFJLEtBQUssSUFBSSxHQUFHLEdBQUcsT0FBTyxLQUFLLElBQUksR0FBRztDQUN0QyxJQUFJO0NBQ0osSUFBSSxlQUFlLE1BQU07RUFFdkIsT0FBTyxJQUFJLEtBQUssSUFBSSxRQUFRLENBQUM7RUFDN0IsS0FBSyxJQUFJLEtBQUssSUFBSTtDQUNwQixPQUFPLElBQUksZUFBZSxRQUFRO0VBRWhDLE9BQU8sSUFBSSxPQUFPLEdBQUc7RUFDckIsS0FBSyxJQUFJLEtBQUssSUFBSTtDQUNwQixPQUFPLElBQUksTUFBTSxRQUFRLEdBQUcsR0FBRztFQUU3QixPQUFPLElBQUksTUFBTSxJQUFJLE1BQU07RUFDM0IsS0FBSyxJQUFJLEtBQUssSUFBSTtFQUNsQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQUssS0FBSyxLQUFLLE1BQU0sSUFBSSxJQUFJLElBQUk7Q0FDbkUsT0FBTyxJQUFJLGVBQWUsS0FBSztFQUU3Qix1QkFBTyxJQUFJLElBQUk7RUFDZixLQUFLLElBQUksS0FBSyxJQUFJO0VBQ2xCLEtBQUssTUFBTSxDQUFDLEdBQUcsTUFBTSxJQUFJLFFBQVEsR0FBRyxLQUFLLElBQUksR0FBRyxNQUFNLEdBQUcsSUFBSSxDQUFDO0NBQ2hFLE9BQU8sSUFBSSxlQUFlLEtBQUs7RUFFN0IsdUJBQU8sSUFBSSxJQUFJO0VBQ2YsS0FBSyxJQUFJLEtBQUssSUFBSTtFQUNsQixLQUFLLE1BQU0sS0FBSyxLQUFLLEtBQUssSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDO0NBQzlDLE9BQU8sSUFBSSxlQUFlLFFBQVE7RUFFaEMsT0FBTyxDQUFDO0VBQ1IsS0FBSyxJQUFJLEtBQUssSUFBSTtFQUNsQixLQUFLLE1BQU0sQ0FBQyxHQUFHLE1BQU0sT0FBTyxRQUFRLEdBQUcsR0FBRyxLQUFLLEtBQUssTUFBTSxHQUFHLElBQUk7Q0FDbkUsT0FDRSxNQUFNLE1BQU0sbUJBQW1CLEtBQUs7Q0FFdEMsT0FBTztBQUNUOzs7OztBQU9BLFNBQVMsbUJBQW1CLE1BQU07Q0FDaEMsSUFBSSxFQUFFLFFBQVEsUUFBUSxLQUFLLFNBQ3pCO0NBSUYsTUFBTSxXQUFXLENBQUM7Q0FFbEIsSUFBSSxpQkFBaUI7Q0FFckIsSUFBSSxhQUFhO0NBRWpCLElBQUksV0FBVztDQUNmLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsS0FBSztFQUNwQyxNQUFNLE9BQU8sS0FBSztFQUNsQixJQUFJLFNBQVMsT0FBTyxDQUFDLFVBQVU7R0FFN0IsSUFBSSxnQkFBZ0I7SUFDbEIsU0FBUyxLQUFLLEdBQUcsZUFBZSxNQUFNLEdBQUcsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDO0lBQzFELGlCQUFpQjtHQUNuQjtHQUNBLGFBQWE7R0FDYjtFQUNGO0VBQ0EsSUFBSSxTQUFTLE9BQU8sQ0FBQyxVQUFVO0dBQzdCLElBQUksZ0JBQWdCO0lBRWxCLElBQUksUUFBUSxLQUFLLGNBQWMsR0FDN0IsU0FBUyxLQUFLLGNBQWM7U0FHNUIsU0FBUyxLQUFLLGVBQWUsUUFBUSxVQUFVLEVBQUUsQ0FBQztJQUVwRCxpQkFBaUI7R0FDbkI7R0FDQSxhQUFhO0dBQ2I7RUFDRjtFQUNBLElBQUksU0FBUyxNQUFLO0dBRWhCLFdBQVcsQ0FBQztHQUNaO0VBQ0Y7RUFDQSxJQUFJLFNBQVMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxVQUFVO0dBRTVDLElBQUksZ0JBQWdCO0lBQ2xCLFNBQVMsS0FBSyxjQUFjO0lBQzVCLGlCQUFpQjtHQUNuQjtHQUNBO0VBQ0Y7RUFDQSxrQkFBa0I7Q0FDcEI7Q0FHQSxJQUFJLGdCQUNGLFNBQVMsS0FBSyxHQUFHLGVBQWUsTUFBTSxHQUFHLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQztDQUU1RCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLHFCQUFxQixPQUFPLFlBQVk7Q0FDL0MsTUFBTSxPQUFPLGFBQWEsR0FBRyxXQUFXLEdBQUcsTUFBTSxTQUFTLE1BQU07Q0FDaEUsT0FBTyxNQUFNLE9BQU8sS0FBSSxTQUFRO0VBQzlCLFNBQVM7RUFDVCxNQUFNLG1CQUFtQixJQUFJO0NBQy9CLEVBQUU7QUFDSjtBQUNBLFNBQVMsMEJBQTBCLE9BQU8sWUFBWTtDQUNwRCxJQUFJO0NBQ0osSUFBSSxHQUFHLGVBQWUsTUFBTSxVQUFVLFFBQVEsYUFBYSxXQUFXLE1BQU0sT0FBTyxRQUNqRixPQUFPLHFCQUFxQixPQUFPLFVBQVU7Q0FFL0MsTUFBTSxPQUFPLGFBQWEsR0FBRyxXQUFXLEdBQUcsTUFBTSxTQUFTLE1BQU07Q0FDaEUsT0FBTyxNQUFNLE1BQU0sU0FBUSxRQUFPLDBCQUEwQixLQUFLLElBQUksQ0FBQztBQUN4RTtBQUlBLElBQU0sU0FBTixNQUFhO0NBQ1gsWUFBWSxTQUFTO0VBQ25CLEtBQUssT0FBTyxLQUFLO0VBQ2pCLEtBQUssT0FBTyxDQUFDO0VBQ2IsS0FBSyxRQUFRLEtBQUs7RUFDbEIsS0FBSyxhQUFhLEtBQUs7RUFDdkIsS0FBSyxhQUFhLENBQUM7RUFDbkIsS0FBSyxVQUFVLEtBQUs7RUFDcEIsS0FBSyxnQkFBZ0IsQ0FBQztFQUN0QixLQUFLLGFBQWEsSUFBSSxhQUFhO0VBQ25DLEtBQUssYUFBYSxJQUFJLGFBQWE7RUFDbkMsS0FBSyxpQkFBaUIsT0FBTyxPQUFPLElBQUk7RUFDeEMsS0FBSyxhQUFhLEtBQUs7RUFDdkIsS0FBSyxPQUFPLEtBQUs7RUFDakIsS0FBSyxRQUFRLENBQUM7RUFDZCxLQUFLLGFBQWEsQ0FBQztFQUNuQixLQUFLLG1CQUFtQjtHQUN0QixLQUFLLFVBQVUsTUFBTSxPQUFPO0VBQzlCLENBQUM7RUFDRCxLQUFLLE9BQU8sUUFBUTtFQUNwQixLQUFLLGFBQWEsUUFBUTtFQUMxQixLQUFLLE9BQU8sT0FBTyxPQUFPO0dBQ3hCLE9BQU87R0FDUCxRQUFRO0dBQ1IsWUFBWTtHQUNaLFdBQVc7R0FDWCxtQkFBbUI7R0FDbkIsVUFBVTtHQUNWLFVBQVU7R0FDVixRQUFRO0VBQ1YsR0FBRyxXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVEsSUFBSTtFQUMxQyxLQUFLLGNBQWEsTUFBSztHQUNyQixFQUFFLFlBQVk7RUFDaEIsQ0FBQztDQUNIO0NBR0EsSUFBSSxRQUFRO0VBQ1YsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxNQUFNLE1BQU07RUFDVixJQUFJLEtBQUssU0FBUztHQUNoQixJQUFJLE1BQU0sT0FBTyxPQUFPLEtBQUssTUFBTSxJQUFJO0dBQ3ZDLE9BQU87RUFDVDtFQUlBLE1BQU0sT0FBTyxPQUFPLE9BQU8sT0FBTyxlQUFlLElBQUksQ0FBQztFQUd0RCxLQUFLLE9BQU8sS0FBSztFQUNqQixLQUFLLGFBQWEsS0FBSztFQUN2QixLQUFLLGFBQWEsS0FBSyxXQUFXLE1BQU07RUFDeEMsS0FBSyxhQUFhLEtBQUssV0FBVyxNQUFNO0VBQ3hDLEtBQUssZ0JBQWdCLE9BQU8sT0FBTyxDQUFDLEdBQUcsS0FBSyxhQUFhO0VBQ3pELEtBQUssaUJBQWlCLE9BQU8sT0FBTyxDQUFDLEdBQUcsS0FBSyxjQUFjO0VBRzNELEtBQUssT0FBTyxDQUFDLEdBQUcsS0FBSyxJQUFJO0VBQ3pCLEtBQUssYUFBYSxDQUFDLEdBQUcsS0FBSyxVQUFVO0VBQ3JDLEtBQUssUUFBUSxDQUFDLEdBQUcsS0FBSyxLQUFLO0VBQzNCLEtBQUssYUFBYSxDQUFDLEdBQUcsS0FBSyxVQUFVO0VBQ3JDLEtBQUssT0FBTyxNQUFNLE9BQU8sT0FBTyxDQUFDLEdBQUcsS0FBSyxNQUFNLElBQUksQ0FBQztFQUNwRCxPQUFPO0NBQ1Q7Q0FDQSxNQUFNLE9BQU87RUFDWCxJQUFJLE9BQU8sS0FBSyxNQUFNO0VBQ3RCLEtBQUssS0FBSyxRQUFRO0VBQ2xCLE9BQU87Q0FDVDtDQUNBLEtBQUssR0FBRyxNQUFNO0VBQ1osSUFBSSxLQUFLLFdBQVcsR0FBRyxPQUFPLEtBQUssS0FBSztFQUN4QyxJQUFJLE9BQU8sS0FBSyxNQUFNO0VBQ3RCLEtBQUssS0FBSyxPQUFPLE9BQU8sT0FBTyxLQUFLLEtBQUssUUFBUSxDQUFDLEdBQUcsS0FBSyxFQUFFO0VBQzVELE9BQU87Q0FDVDtDQUNBLGFBQWEsSUFBSTtFQUNmLElBQUksU0FBUyxLQUFLO0VBQ2xCLEtBQUssVUFBVTtFQUNmLElBQUksU0FBUyxHQUFHLElBQUk7RUFDcEIsS0FBSyxVQUFVO0VBQ2YsT0FBTztDQUNUO0NBQ0EsT0FBTyxRQUFRO0VBQ2IsSUFBSSxDQUFDLFVBQVUsV0FBVyxNQUFNLE9BQU87RUFDdkMsSUFBSSxPQUFPLFNBQVMsS0FBSyxRQUFRLEtBQUssU0FBUyxTQUFTLE1BQU0sSUFBSSxVQUFVLHdEQUF3RCxLQUFLLEtBQUssT0FBTyxPQUFPLE1BQU07RUFDbEssSUFBSSxPQUFPO0VBQ1gsSUFBSSxXQUFXLE9BQU8sTUFBTTtFQUU1QixTQUFTLE9BRFUsT0FBTyxPQUFPLENBQUMsR0FBRyxLQUFLLE1BQU0sU0FBUyxJQUNoQztFQUN6QixTQUFTLGdCQUFnQixPQUFPLE9BQU8sQ0FBQyxHQUFHLEtBQUssZUFBZSxTQUFTLGFBQWE7RUFJckYsU0FBUyxhQUFhLEtBQUssV0FBVyxNQUFNLE9BQU8sWUFBWSxPQUFPLFVBQVU7RUFDaEYsU0FBUyxhQUFhLEtBQUssV0FBVyxNQUFNLE9BQU8sWUFBWSxPQUFPLFVBQVU7RUFHaEYsU0FBUyxRQUFRLEtBQUs7RUFDdEIsU0FBUyxpQkFBaUIsS0FBSztFQUkvQixTQUFTLGNBQWEsU0FBUTtHQUM1QixPQUFPLE1BQU0sU0FBUSxPQUFNO0lBQ3pCLEtBQUssS0FBSyxHQUFHLE9BQU87R0FDdEIsQ0FBQztFQUNILENBQUM7RUFDRCxTQUFTLGFBQWEsQ0FBQyxHQUFHLEtBQUssWUFBWSxHQUFHLFNBQVMsVUFBVTtFQUNqRSxPQUFPO0NBQ1Q7Q0FDQSxPQUFPLEdBQUc7RUFDUixJQUFJLEtBQUssTUFBTTtHQUNiLElBQUksS0FBSyxLQUFLLFlBQVksTUFBTSxNQUFNLE9BQU87R0FDN0MsSUFBSSxLQUFLLEtBQUssWUFBWSxNQUFNLEtBQUEsR0FBVyxPQUFPO0dBQ2xELE9BQU87RUFDVDtFQUNBLE9BQU8sS0FBSyxXQUFXLENBQUM7Q0FDMUI7Q0FDQSxRQUFRLFNBQVM7RUFDZixJQUFJLFNBQVM7RUFDYixJQUFJLE9BQU8sV0FBVyxRQUFRO0dBQzVCLElBQUksYUFBYSxPQUFPO0dBQ3hCLFNBQVMsT0FBTyxNQUFNO0dBQ3RCLE9BQU8sYUFBYSxDQUFDO0dBQ3JCLFNBQVMsV0FBVyxRQUFRLFlBQVksY0FBYyxVQUFVLFFBQVEsWUFBWSxPQUFPLEdBQUcsTUFBTTtHQUNwRyxTQUFTLE9BQU8sUUFBUSxPQUFPO0VBQ2pDO0VBQ0EsT0FBTztDQUNUO0NBQ0EsZUFBZSxTQUFTO0VBQ3RCLElBQUksaUJBQWlCLHFCQUFxQixvQkFBb0I7RUFDOUQsT0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFHLFNBQVM7R0FDaEMsTUFBTSxRQUFRLFFBQVEsQ0FBQztHQUN2QixTQUFTLGtCQUFrQixRQUFRLFdBQVcsT0FBTyxrQkFBa0IsS0FBSyxLQUFLO0dBQ2pGLGFBQWEsc0JBQXNCLFFBQVEsZUFBZSxPQUFPLHNCQUFzQixLQUFLLEtBQUs7R0FDakcsWUFBWSxxQkFBcUIsUUFBUSxjQUFjLE9BQU8scUJBQXFCLEtBQUssS0FBSztHQUM3RixvQkFBb0Isd0JBQXdCLFFBQVEsc0JBQXNCLE9BQU8sd0JBQXdCLEtBQUssS0FBSztFQUNySCxDQUFDO0NBQ0g7Ozs7Q0FNQSxLQUFLLE9BQU8sVUFBVSxDQUFDLEdBQUc7RUFDeEIsSUFBSSxpQkFBaUIsS0FBSyxRQUFRLE9BQU8sT0FBTyxDQUFDLEdBQUcsU0FBUyxFQUMzRCxNQUdGLENBQUMsQ0FBQztFQUVGLElBQUksbUJBQW1CLFFBQVEsV0FBVztFQUMxQyxJQUFJLFNBQVMsZUFBZSxNQUFNLE9BQU8sT0FBTztFQUNoRCxJQUFJLFFBQVEsV0FBVyxTQUFTLENBQUMsZUFBZSxPQUFPLE1BQU0sR0FBRztHQUM5RCxJQUFJLG9CQUFvQixTQUFTLE1BQU0sR0FDckMsT0FBTztHQUVULElBQUksaUJBQWlCLFdBQVcsS0FBSztHQUNyQyxJQUFJLGtCQUFrQixXQUFXLE1BQU07R0FDdkMsTUFBTSxJQUFJLFVBQVUsZ0JBQWdCLFFBQVEsUUFBUSxRQUFRLGlFQUFzRSxlQUFlLEtBQUssMEJBQStCLGVBQWUsUUFBUSxvQkFBb0IsaUJBQWlCLG1CQUFtQixvQkFBb0IsR0FBRztFQUM3UjtFQUNBLE9BQU87Q0FDVDtDQUNBLE1BQU0sVUFBVSxTQUFTO0VBQ3ZCLElBQUksUUFBUSxhQUFhLEtBQUEsSUFBWSxXQUFXLEtBQUssV0FBVyxRQUFRLFdBQVcsT0FBTyxHQUFHLEtBQUssTUFBTSxXQUFXLFVBQVUsTUFBTSxPQUFPLEdBQUcsUUFBUTtFQUNySixJQUFJLFVBQVUsS0FBQSxHQUNaLFFBQVEsS0FBSyxXQUFXLE9BQU87RUFFakMsT0FBTztDQUNUO0NBQ0EsVUFBVSxRQUFRLFVBQVUsQ0FBQyxHQUFHLE9BQU8sTUFBTTtFQUMzQyxJQUFJLEVBQ0YsTUFDQSxnQkFBZ0IsUUFDaEIsU0FBUyxLQUFLLEtBQUssV0FDakI7RUFDSixJQUFJLFFBQVE7RUFDWixJQUFJLENBQUMsUUFDSCxRQUFRLEtBQUssTUFBTSxPQUFPLE9BQU8sT0FBTyxFQUN0QyxRQUFRLE1BQ1YsR0FBRyxPQUFPLENBQUM7RUFFYixJQUFJLGVBQWUsQ0FBQztFQUNwQixLQUFLLElBQUksUUFBUSxPQUFPLE9BQU8sS0FBSyxhQUFhLEdBQy9DLElBQUksTUFBTSxhQUFhLEtBQUssSUFBSTtFQUVsQyxLQUFLLFNBQVM7R0FDWjtHQUNBO0dBQ0E7R0FDQTtHQUNBLE9BQU87RUFDVCxHQUFHLFFBQU8sa0JBQWlCO0dBRXpCLElBQUksY0FBYyxRQUNoQixPQUFPLEtBQUssZUFBZSxLQUFLO0dBRWxDLEtBQUssU0FBUztJQUNaO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsT0FBTyxLQUFLO0dBQ2QsR0FBRyxPQUFPLElBQUk7RUFDaEIsQ0FBQztDQUNIOzs7OztDQU1BLFNBQVMsWUFBWSxPQUFPLE1BQU07RUFDaEMsSUFBSSxRQUFRO0VBQ1osSUFBSSxFQUNGLE9BQ0EsT0FDQSxlQUNBLE1BQ0EsWUFDRTtFQUNKLElBQUksYUFBWSxRQUFPO0dBQ3JCLElBQUksT0FBTztHQUNYLFFBQVE7R0FDUixNQUFNLEtBQUssS0FBSztFQUNsQjtFQUNBLElBQUksWUFBVyxRQUFPO0dBQ3BCLElBQUksT0FBTztHQUNYLFFBQVE7R0FDUixLQUFLLEtBQUssS0FBSztFQUNqQjtFQUNBLElBQUksUUFBUSxNQUFNO0VBQ2xCLElBQUksZUFBZSxDQUFDO0VBQ3BCLElBQUksQ0FBQyxPQUFPLE9BQU8sU0FBUyxDQUFDLENBQUM7RUFDOUIsSUFBSSxPQUFPO0dBQ1Q7R0FDQTtHQUNBO0dBQ0E7R0FDQSxRQUFRO0VBQ1Y7RUFDQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUs7R0FDckMsTUFBTSxPQUFPLE1BQU07R0FDbkIsS0FBSyxNQUFNLFdBQVcsU0FBUyxjQUFjLEtBQUs7SUFDaEQsSUFBSSxLQUNGLE1BQU0sUUFBUSxHQUFHLElBQUksYUFBYSxLQUFLLEdBQUcsR0FBRyxJQUFJLGFBQWEsS0FBSyxHQUFHO0lBRXhFLElBQUksRUFBRSxTQUFTLEdBQ2IsU0FBUyxZQUFZO0dBRXpCLENBQUM7RUFDSDtDQUNGO0NBQ0EsYUFBYSxFQUNYLEtBQ0EsT0FDQSxRQUNBLFlBQ0EsZ0JBQ0EsV0FDQztFQUNELE1BQU0sSUFBSSxPQUFPLE9BQU8sTUFBTTtFQUM5QixJQUFJLEtBQUssTUFDUCxNQUFNLFVBQVUsc0RBQXNEO0VBRXhFLE1BQU0sVUFBVSxPQUFPLE1BQU07RUFDN0IsSUFBSSxRQUFRLE9BQU87RUFDbkIsTUFBTSxjQUFjLE9BQU8sT0FBTyxDQUFDLEdBQUcsU0FBUztHQUk3QyxRQUFRO0dBQ1I7R0FDQTtHQUNBLGVBQWUsZUFBZTtHQUc5QixLQUFLLEtBQUE7SUFFSixVQUFVLFVBQVUsUUFBUTtHQUM3QixNQUFNLFdBQVcsRUFBRSxTQUFTLEdBQUcsSUFBSSxHQUFHLGNBQWMsR0FBRyxHQUFHLFVBQVUsSUFBSSxJQUFJLEVBQUUsR0FBRyxNQUFNLGFBQWEsR0FBRyxXQUFXLEtBQUssTUFBTTtFQUMvSCxDQUFDO0VBQ0QsUUFBUSxHQUFHLE9BQU8sU0FBUyxLQUFLLFFBQVEsV0FBVyxDQUFDLENBQUMsVUFBVSxPQUFPLGFBQWEsT0FBTyxJQUFJO0NBQ2hHO0NBQ0EsU0FBUyxPQUFPLFNBQVM7RUFDdkIsSUFBSTtFQUNKLElBQUksU0FBUyxLQUFLLFFBQVEsT0FBTyxPQUFPLENBQUMsR0FBRyxTQUFTLEVBQ25ELE1BQ0YsQ0FBQyxDQUFDO0VBQ0YsSUFBSSxxQkFBcUIseUJBQXlCLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSxzQkFBc0IsT0FBTyx5QkFBeUIsT0FBTyxLQUFLO0VBQ3ZKLE9BQU8sSUFBSSxTQUFTLFNBQVMsV0FBVyxPQUFPLFVBQVUsT0FBTyxVQUFVLE9BQU8sV0FBVztHQUMxRixJQUFJLGdCQUFnQixRQUFRLEtBQUssR0FBRyxNQUFNLFFBQVE7R0FDbEQsT0FBTyxLQUFLO0VBQ2QsSUFBSSxRQUFRLGNBQWM7R0FDeEIsSUFBSSxPQUFPLFFBQVEsT0FBTyxJQUFJLGdCQUFnQixRQUFRLFdBQVcsS0FBQSxHQUFXLEtBQUEsR0FBVyxpQkFBaUIsQ0FBQztRQUFPLFFBQVEsU0FBUztFQUNuSSxDQUFDLENBQUM7Q0FDSjtDQUNBLGFBQWEsT0FBTyxTQUFTO0VBQzNCLElBQUk7RUFDSixJQUFJLFNBQVMsS0FBSyxRQUFRLE9BQU8sT0FBTyxDQUFDLEdBQUcsU0FBUyxFQUNuRCxNQUNGLENBQUMsQ0FBQztFQUNGLElBQUk7RUFDSixJQUFJLHFCQUFxQix5QkFBeUIsV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLHNCQUFzQixPQUFPLHlCQUF5QixPQUFPLEtBQUs7RUFDdkosT0FBTyxVQUFVLE9BQU8sT0FBTyxPQUFPLENBQUMsR0FBRyxTQUFTLEVBQ2pELE1BQU0sS0FDUixDQUFDLElBQUksT0FBTyxXQUFXO0dBQ3JCLElBQUksZ0JBQWdCLFFBQVEsS0FBSyxHQUFHLE1BQU0sUUFBUTtHQUNsRCxNQUFNO0VBQ1IsSUFBSSxRQUFRLGNBQWM7R0FDeEIsSUFBSSxPQUFPLFFBQVEsTUFBTSxJQUFJLGdCQUFnQixRQUFRLE9BQU8sS0FBQSxHQUFXLEtBQUEsR0FBVyxpQkFBaUI7R0FDbkcsU0FBUztFQUNYLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSxRQUFRLE9BQU8sU0FBUztFQUN0QixPQUFPLEtBQUssU0FBUyxPQUFPLE9BQU8sQ0FBQyxDQUFDLFdBQVcsT0FBTSxRQUFPO0dBQzNELElBQUksZ0JBQWdCLFFBQVEsR0FBRyxHQUFHLE9BQU87R0FDekMsTUFBTTtFQUNSLENBQUM7Q0FDSDtDQUNBLFlBQVksT0FBTyxTQUFTO0VBQzFCLElBQUk7R0FDRixLQUFLLGFBQWEsT0FBTyxPQUFPO0dBQ2hDLE9BQU87RUFDVCxTQUFTLEtBQUs7R0FDWixJQUFJLGdCQUFnQixRQUFRLEdBQUcsR0FBRyxPQUFPO0dBQ3pDLE1BQU07RUFDUjtDQUNGO0NBQ0EsWUFBWSxTQUFTO0VBQ25CLElBQUksZUFBZSxLQUFLLEtBQUs7RUFDN0IsSUFBSSxnQkFBZ0IsTUFDbEIsT0FBTztFQUVULE9BQU8sT0FBTyxpQkFBaUIsYUFBYSxhQUFhLEtBQUssTUFBTSxPQUFPLElBQUksTUFBTSxZQUFZO0NBQ25HO0NBQ0EsV0FBVyxTQUVUO0VBRUEsT0FEYSxLQUFLLFFBQVEsV0FBVyxDQUFDLENBQzFCLENBQUMsQ0FBQyxZQUFZLE9BQU87Q0FDbkM7Q0FDQSxRQUFRLEtBQUs7RUFDWCxJQUFJLFVBQVUsV0FBVyxHQUN2QixPQUFPLEtBQUssWUFBWTtFQUsxQixPQUhXLEtBQUssTUFBTSxFQUNwQixTQUFTLElBQ1gsQ0FDVTtDQUNaO0NBQ0EsT0FBTyxXQUFXLE1BQU07RUFDdEIsT0FBTyxLQUFLLE1BQU0sRUFDaEIsUUFBUSxTQUNWLENBQUM7Q0FDSDtDQUNBLFlBQVksVUFBVSxTQUFTO0VBQzdCLE1BQU0sT0FBTyxLQUFLLE1BQU0sRUFDdEIsU0FDRixDQUFDO0VBQ0QsS0FBSyxjQUFjLFdBQVcsaUJBQWlCO0dBQzdDO0dBQ0EsTUFBTTtHQUNOLEtBQUssT0FBTztJQUNWLE9BQU8sVUFBVSxPQUFPLEtBQUssT0FBTyxLQUFLLFdBQVc7R0FDdEQ7RUFDRixDQUFDO0VBQ0QsT0FBTztDQUNUO0NBQ0EsWUFBWSxVQUFVLFNBQVM7RUFDN0IsTUFBTSxPQUFPLEtBQUssTUFBTSxFQUN0QixTQUNGLENBQUM7RUFDRCxLQUFLLGNBQWMsY0FBYyxpQkFBaUI7R0FDaEQ7R0FDQSxNQUFNO0dBQ04sS0FBSyxPQUFPO0lBQ1YsT0FBTyxVQUFVLEtBQUEsSUFBWSxLQUFLLE9BQU8sS0FBSyxXQUFXO0dBQzNEO0VBQ0YsQ0FBQztFQUNELE9BQU87Q0FDVDtDQUNBLFdBQVc7RUFDVCxPQUFPLEtBQUssWUFBWSxJQUFJO0NBQzlCO0NBQ0EsUUFBUSxVQUFVLE1BQU0sU0FBUztFQUMvQixPQUFPLEtBQUssWUFBWSxPQUFPLE9BQU87Q0FDeEM7Q0FDQSxXQUFXO0VBQ1QsT0FBTyxLQUFLLFlBQVksSUFBSTtDQUM5QjtDQUNBLFlBQVksVUFBVSxNQUFNLFNBQVM7RUFDbkMsT0FBTyxLQUFLLFlBQVksT0FBTyxPQUFPO0NBQ3hDO0NBQ0EsU0FBUyxVQUFVLE1BQU0sVUFBVTtFQUNqQyxPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsY0FBYSxTQUFRLEtBQUssWUFBWSxPQUFPLENBQUMsQ0FBQyxRQUFRLE9BQU8sQ0FBQztDQUNyRjtDQUNBLGNBQWM7RUFDWixPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsY0FBYSxTQUFRLEtBQUssU0FBUyxDQUFDLENBQUMsU0FBUyxDQUFDO0NBQ3JFO0NBQ0EsVUFBVSxJQUFJO0VBQ1osSUFBSSxPQUFPLEtBQUssTUFBTTtFQUN0QixLQUFLLFdBQVcsS0FBSyxFQUFFO0VBQ3ZCLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Q0FnQkEsS0FBSyxHQUFHLE1BQU07RUFDWixJQUFJO0VBQ0osSUFBSSxLQUFLLFdBQVcsR0FBRztHQUNyQixJQUFJLE9BQU8sS0FBSyxPQUFPLFlBQ3JCLE9BQU8sRUFDTCxNQUFNLEtBQUssR0FDYjtRQUVBLE9BQU8sS0FBSztFQUVoQixPQUFPLElBQUksS0FBSyxXQUFXLEdBQ3pCLE9BQU87R0FDTCxNQUFNLEtBQUs7R0FDWCxNQUFNLEtBQUs7RUFDYjtPQUVBLE9BQU87R0FDTCxNQUFNLEtBQUs7R0FDWCxTQUFTLEtBQUs7R0FDZCxNQUFNLEtBQUs7RUFDYjtFQUVGLElBQUksS0FBSyxZQUFZLEtBQUEsR0FBVyxLQUFLLFVBQVUsTUFBTTtFQUNyRCxJQUFJLE9BQU8sS0FBSyxTQUFTLFlBQVksTUFBTSxJQUFJLFVBQVUsaUNBQWlDO0VBQzFGLElBQUksT0FBTyxLQUFLLE1BQU07RUFDdEIsSUFBSSxXQUFXLGlCQUFpQixJQUFJO0VBQ3BDLElBQUksY0FBYyxLQUFLLGFBQWEsS0FBSyxRQUFRLEtBQUssZUFBZSxLQUFLLFVBQVU7RUFDcEYsSUFBSSxLQUFLLFdBQ0g7T0FBQSxDQUFDLEtBQUssTUFBTSxNQUFNLElBQUksVUFBVSxtRUFBbUU7RUFBQTtFQUV6RyxJQUFJLEtBQUssTUFBTSxLQUFLLGVBQWUsS0FBSyxRQUFRLENBQUMsQ0FBQyxLQUFLO0VBQ3ZELEtBQUssUUFBUSxLQUFLLE1BQU0sUUFBTyxPQUFNO0dBQ25DLElBQUksR0FBRyxRQUFRLFNBQVMsS0FBSyxNQUFNO0lBQ2pDLElBQUksYUFBYSxPQUFPO0lBQ3hCLElBQUksR0FBRyxRQUFRLFNBQVMsU0FBUyxRQUFRLE1BQU0sT0FBTztHQUN4RDtHQUNBLE9BQU87RUFDVCxDQUFDO0VBQ0QsS0FBSyxNQUFNLEtBQUssUUFBUTtFQUN4QixPQUFPO0NBQ1Q7Q0FDQSxLQUFLLE1BQU0sU0FBUztFQUNsQixJQUFJLENBQUMsTUFBTSxRQUFRLElBQUksS0FBSyxPQUFPLFNBQVMsVUFBVTtHQUNwRCxVQUFVO0dBQ1YsT0FBTztFQUNUO0VBQ0EsSUFBSSxPQUFPLEtBQUssTUFBTTtFQUN0QixJQUFJLE9BQU8sUUFBUSxJQUFJLENBQUMsQ0FBQyxLQUFJLFFBQU8sSUFBSSxVQUFVLEdBQUcsQ0FBQztFQUN0RCxLQUFLLFNBQVEsUUFBTztHQUVsQixJQUFJLElBQUksV0FBVyxLQUFLLEtBQUssS0FBSyxJQUFJLEdBQUc7RUFDM0MsQ0FBQztFQUNELEtBQUssV0FBVyxLQUFLLE9BQU8sWUFBWSxhQUFhLElBQUksVUFBVSxNQUFNLE9BQU8sSUFBSSxVQUFVLFlBQVksTUFBTSxPQUFPLENBQUM7RUFDeEgsT0FBTztDQUNUO0NBQ0EsVUFBVSxTQUFTO0VBQ2pCLElBQUksT0FBTyxLQUFLLE1BQU07RUFDdEIsS0FBSyxjQUFjLFlBQVksaUJBQWlCO0dBQzlDO0dBQ0EsTUFBTTtHQUNOLFlBQVk7R0FDWixLQUFLLE9BQU87SUFDVixJQUFJLENBQUMsS0FBSyxPQUFPLFdBQVcsS0FBSyxHQUFHLE9BQU8sS0FBSyxZQUFZLEVBQzFELFFBQVEsRUFDTixNQUFNLEtBQUssT0FBTyxLQUNwQixFQUNGLENBQUM7SUFDRCxPQUFPO0dBQ1Q7RUFDRixDQUFDO0VBQ0QsT0FBTztDQUNUO0NBQ0EsTUFBTSxPQUFPLFVBQVUsTUFBTSxPQUFPO0VBQ2xDLElBQUksT0FBTyxLQUFLLE1BQU07RUFDdEIsTUFBTSxTQUFRLFFBQU87R0FDbkIsS0FBSyxXQUFXLElBQUksR0FBRztHQUN2QixLQUFLLFdBQVcsT0FBTyxHQUFHO0VBQzVCLENBQUM7RUFDRCxLQUFLLGNBQWMsWUFBWSxpQkFBaUI7R0FDOUM7R0FDQSxNQUFNO0dBQ04sWUFBWTtHQUNaLEtBQUssT0FBTztJQUNWLElBQUksU0FBUyxLQUFLLE9BQU87SUFDekIsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87SUFDN0MsT0FBTyxTQUFTLFNBQVMsS0FBSyxJQUFJLE9BQU8sS0FBSyxZQUFZLEVBQ3hELFFBQVE7S0FDTixRQUFRLE1BQU0sS0FBSyxNQUFNLENBQUMsQ0FBQyxLQUFLLElBQUk7S0FDcEM7SUFDRixFQUNGLENBQUM7R0FDSDtFQUNGLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSxTQUFTLE9BQU8sVUFBVSxNQUFNLFVBQVU7RUFDeEMsSUFBSSxPQUFPLEtBQUssTUFBTTtFQUN0QixNQUFNLFNBQVEsUUFBTztHQUNuQixLQUFLLFdBQVcsSUFBSSxHQUFHO0dBQ3ZCLEtBQUssV0FBVyxPQUFPLEdBQUc7RUFDNUIsQ0FBQztFQUNELEtBQUssY0FBYyxZQUFZLGlCQUFpQjtHQUM5QztHQUNBLE1BQU07R0FDTixLQUFLLE9BQU87SUFDVixJQUFJLFdBQVcsS0FBSyxPQUFPO0lBQzNCLElBQUksV0FBVyxTQUFTLFdBQVcsS0FBSyxPQUFPO0lBQy9DLElBQUksU0FBUyxTQUFTLEtBQUssR0FBRyxPQUFPLEtBQUssWUFBWSxFQUNwRCxRQUFRO0tBQ04sUUFBUSxNQUFNLEtBQUssUUFBUSxDQUFDLENBQUMsS0FBSyxJQUFJO0tBQ3RDO0lBQ0YsRUFDRixDQUFDO0lBQ0QsT0FBTztHQUNUO0VBQ0YsQ0FBQztFQUNELE9BQU87Q0FDVDtDQUNBLE1BQU0sUUFBUSxNQUFNO0VBQ2xCLElBQUksT0FBTyxLQUFLLE1BQU07RUFDdEIsS0FBSyxLQUFLLFFBQVE7RUFDbEIsT0FBTztDQUNUOzs7Ozs7Q0FPQSxTQUFTLFNBQVM7RUFDaEIsTUFBTSxRQUFRLFVBQVUsS0FBSyxRQUFRLE9BQU8sSUFBSSxLQUFBLENBQU0sTUFBTTtFQUM1RCxNQUFNLEVBQ0osT0FDQSxNQUNBLFVBQ0EsYUFDRSxLQUFLO0VBa0JULE9BQU87R0FoQkw7R0FDQTtHQUNBO0dBQ0E7R0FDQSxTQUFTLEtBQUssV0FBVyxPQUFPO0dBQ2hDLE1BQU0sS0FBSztHQUNYLE9BQU8sS0FBSyxXQUFXLFNBQVM7R0FDaEMsVUFBVSxLQUFLLFdBQVcsU0FBUztHQUNuQyxPQUFPLEtBQUssTUFBTSxRQUFRLEdBQUcsS0FBSyxTQUFTLEtBQUssV0FBVSxNQUFLLEVBQUUsUUFBUSxTQUFTLEVBQUUsUUFBUSxJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSSxPQUFNO0lBQ25ILE1BQU0sU0FBUyxHQUFHLFFBQVEsVUFBVSxVQUFVLGNBQWMsT0FBTyxPQUFPLENBQUMsR0FBRyxHQUFHLFFBQVEsTUFBTSxHQUFHLE9BQU8sSUFBSSxHQUFHLFFBQVE7SUFDeEgsT0FBTztLQUNMLE1BQU0sR0FBRyxRQUFRO0tBQ2pCO0lBQ0Y7R0FDRixDQUFDO0VBRWM7Q0FDbkI7Q0FDQSxLQUFLLGVBQWU7RUFDbEIsTUFBTSxTQUFTO0VBc0JmLE9BQU87R0FwQkwsU0FBUztHQUNULFFBQVE7R0FDUixNQUFNLFNBQVMsT0FBTztJQUNwQixJQUFJO0tBSUYsT0FBTyxFQUNMLE9BQU8sTUFKWSxPQUFPLFNBQVMsT0FBTyxFQUMxQyxZQUFZLE1BQ2QsQ0FBQyxFQUdEO0lBQ0YsU0FBUyxLQUFLO0tBQ1osSUFBSSxlQUFlLGlCQUNqQixPQUFPLEVBQ0wsUUFBUSwwQkFBMEIsR0FBRyxFQUN2QztLQUVGLE1BQU07SUFDUjtHQUNGO0VBRVk7Q0FDaEI7QUFDRjtBQUVBLE9BQU8sVUFBVSxrQkFBa0I7QUFDbkMsS0FBSyxNQUFNLFVBQVUsQ0FBQyxZQUFZLGNBQWMsR0FBRyxPQUFPLFVBQVUsR0FBRyxPQUFPLE9BQU8sU0FBVSxNQUFNLE9BQU8sVUFBVSxDQUFDLEdBQUc7Q0FDeEgsTUFBTSxFQUNKLFFBQ0EsWUFDQSxXQUNFLE1BQU0sTUFBTSxNQUFNLE9BQU8sUUFBUSxPQUFPO0NBQzVDLE9BQU8sT0FBTyxPQUFPLENBQUMsVUFBVSxPQUFPLGFBQWEsT0FBTyxPQUFPLENBQUMsR0FBRyxTQUFTO0VBQzdFO0VBQ0E7Q0FDRixDQUFDLENBQUM7QUFDSjtBQUNBLEtBQUssTUFBTSxTQUFTLENBQUMsVUFBVSxJQUFJLEdBQUcsT0FBTyxVQUFVLFNBQVMsT0FBTyxVQUFVO0FBQ2pGLEtBQUssTUFBTSxTQUFTLENBQUMsT0FBTyxNQUFNLEdBQUcsT0FBTyxVQUFVLFNBQVMsT0FBTyxVQUFVO0FBRWhGLElBQU0sb0JBQW9CO0FBQzFCLFNBQVMsU0FBUyxNQUFNO0NBQ3RCLE9BQU8sSUFBSSxZQUFZLElBQUk7QUFDN0I7QUFDQSxJQUFNLGNBQU4sY0FBMEIsT0FBTztDQUMvQixZQUFZLE1BQU07RUFDaEIsTUFBTSxPQUFPLFNBQVMsYUFBYTtHQUNqQyxNQUFNO0dBQ04sT0FBTztFQUNULElBQUksT0FBTyxPQUFPO0dBQ2hCLE1BQU07R0FDTixPQUFPO0VBQ1QsR0FBRyxJQUFJLENBQUM7Q0FDVjtBQUNGO0FBQ0EsU0FBUyxZQUFZLFlBQVk7QUFFakMsU0FBUyxXQUFXO0NBQ2xCLE9BQU8sSUFBSSxjQUFjO0FBQzNCO0FBQ0EsSUFBTSxnQkFBTixjQUE0QixPQUFPO0NBQ2pDLGNBQWM7RUFDWixNQUFNO0dBQ0osTUFBTTtHQUNOLE1BQU0sR0FBRztJQUNQLElBQUksYUFBYSxTQUFTLElBQUksRUFBRSxRQUFRO0lBQ3hDLE9BQU8sT0FBTyxNQUFNO0dBQ3RCO0VBQ0YsQ0FBQztFQUNELEtBQUssbUJBQW1CO0dBQ3RCLEtBQUssV0FBVyxPQUFPLFNBQVM7SUFDOUIsSUFBSSxLQUFLLEtBQUssVUFBVSxDQUFDLEtBQUssT0FBTyxLQUFLLEdBQUc7S0FDM0MsSUFBSSxjQUFjLEtBQUssT0FBTyxLQUFLLENBQUMsR0FBRyxPQUFPO0tBQzlDLElBQUksZUFBZSxLQUFLLE9BQU8sS0FBSyxDQUFDLEdBQUcsT0FBTztJQUNqRDtJQUNBLE9BQU87R0FDVCxDQUFDO0VBQ0gsQ0FBQztDQUNIO0NBQ0EsT0FBTyxVQUFVLFFBQVEsU0FBUztFQUNoQyxPQUFPLEtBQUssS0FBSztHQUNmO0dBQ0EsTUFBTTtHQUNOLFdBQVc7R0FDWCxRQUFRLEVBQ04sT0FBTyxPQUNUO0dBQ0EsS0FBSyxPQUFPO0lBQ1YsT0FBTyxTQUFTLEtBQUssS0FBSyxVQUFVO0dBQ3RDO0VBQ0YsQ0FBQztDQUNIO0NBQ0EsUUFBUSxVQUFVLFFBQVEsU0FBUztFQUNqQyxPQUFPLEtBQUssS0FBSztHQUNmO0dBQ0EsTUFBTTtHQUNOLFdBQVc7R0FDWCxRQUFRLEVBQ04sT0FBTyxRQUNUO0dBQ0EsS0FBSyxPQUFPO0lBQ1YsT0FBTyxTQUFTLEtBQUssS0FBSyxVQUFVO0dBQ3RDO0VBQ0YsQ0FBQztDQUNIO0NBQ0EsUUFBUSxLQUFLO0VBQ1gsT0FBTyxNQUFNLFFBQVEsR0FBRztDQUMxQjtDQUNBLFFBQVEsS0FBSztFQUNYLE9BQU8sTUFBTSxRQUFRLEdBQUc7Q0FDMUI7Q0FDQSxXQUFXO0VBQ1QsT0FBTyxNQUFNLFNBQVM7Q0FDeEI7Q0FDQSxTQUFTLEtBQUs7RUFDWixPQUFPLE1BQU0sU0FBUyxHQUFHO0NBQzNCO0NBQ0EsY0FBYztFQUNaLE9BQU8sTUFBTSxZQUFZO0NBQzNCO0NBQ0EsV0FBVztFQUNULE9BQU8sTUFBTSxTQUFTO0NBQ3hCO0NBQ0EsWUFBWSxLQUFLO0VBQ2YsT0FBTyxNQUFNLFlBQVksR0FBRztDQUM5QjtDQUNBLE1BQU0sR0FBRztFQUNQLE9BQU8sTUFBTSxNQUFNLENBQUM7Q0FDdEI7QUFDRjtBQUNBLFNBQVMsWUFBWSxjQUFjOzs7Ozs7OztBQVluQyxJQUFNLFNBQVM7QUFDZixTQUFTLGFBQWEsTUFBTTtDQUMxQixNQUFNLFNBQVMsZ0JBQWdCLElBQUk7Q0FDbkMsSUFBSSxDQUFDLFFBQVEsT0FBTyxLQUFLLFFBQVEsS0FBSyxNQUFNLElBQUksSUFBSTtDQUdwRCxJQUFJLE9BQU8sTUFBTSxLQUFBLEtBQWEsT0FBTyxjQUFjLEtBQUEsR0FDakQsT0FBTyxJQUFJLEtBQUssT0FBTyxNQUFNLE9BQU8sT0FBTyxPQUFPLEtBQUssT0FBTyxNQUFNLE9BQU8sUUFBUSxPQUFPLFFBQVEsT0FBTyxXQUFXLENBQUMsQ0FBQyxRQUFRO0NBRWhJLElBQUkscUJBQXFCO0NBQ3pCLElBQUksT0FBTyxNQUFNLE9BQU8sT0FBTyxjQUFjLEtBQUEsR0FBVztFQUN0RCxxQkFBcUIsT0FBTyxhQUFhLEtBQUssT0FBTztFQUNyRCxJQUFJLE9BQU8sY0FBYyxLQUFLLHFCQUFxQixJQUFJO0NBQ3pEO0NBQ0EsT0FBTyxLQUFLLElBQUksT0FBTyxNQUFNLE9BQU8sT0FBTyxPQUFPLEtBQUssT0FBTyxNQUFNLE9BQU8sU0FBUyxvQkFBb0IsT0FBTyxRQUFRLE9BQU8sV0FBVztBQUMzSTtBQUNBLFNBQVMsZ0JBQWdCLE1BQU07Q0FDN0IsSUFBSSx1QkFBdUI7Q0FDM0IsTUFBTSxjQUFjLE9BQU8sS0FBSyxJQUFJO0NBQ3BDLElBQUksQ0FBQyxhQUFhLE9BQU87Q0FJekIsT0FBTztFQUNMLE1BQU0sU0FBUyxZQUFZLEVBQUU7RUFDN0IsT0FBTyxTQUFTLFlBQVksSUFBSSxDQUFDLElBQUk7RUFDckMsS0FBSyxTQUFTLFlBQVksSUFBSSxDQUFDO0VBQy9CLE1BQU0sU0FBUyxZQUFZLEVBQUU7RUFDN0IsUUFBUSxTQUFTLFlBQVksRUFBRTtFQUMvQixRQUFRLFNBQVMsWUFBWSxFQUFFO0VBQy9CLGFBQWEsWUFBWSxLQUV6QixTQUFTLFlBQVksRUFBRSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsSUFBSTtFQUMzQyxZQUFZLHlCQUF5QixnQkFBZ0IsWUFBWSxPQUFPLE9BQU8sS0FBSyxJQUFJLGNBQWMsV0FBVyxPQUFPLHdCQUF3QixLQUFBO0VBQ2hKLEdBQUcsWUFBWSxNQUFNLEtBQUE7RUFDckIsV0FBVyxZQUFZLE1BQU0sS0FBQTtFQUM3QixZQUFZLFNBQVMsWUFBWSxHQUFHO0VBQ3BDLGNBQWMsU0FBUyxZQUFZLEdBQUc7Q0FDeEM7QUFDRjtBQUNBLFNBQVMsU0FBUyxLQUFLLGVBQWUsR0FBRztDQUN2QyxPQUFPLE9BQU8sR0FBRyxLQUFLO0FBQ3hCO0FBR0EsSUFBSSxTQUVKO0FBQ0EsSUFBSSxPQUVKO0FBR0EsSUFBSSxRQUFRO0FBSVosSUFBSSxlQUFlLElBQUksT0FBTyxrRkFBNEQ7QUFDMUYsSUFBSSxhQUFZLFVBQVMsU0FBUyxLQUFLLEtBQUssVUFBVSxNQUFNLEtBQUs7QUFDakUsSUFBSSxlQUFlLENBQUMsRUFBRSxTQUFTO0FBQy9CLFNBQVMsV0FBVztDQUNsQixPQUFPLElBQUksYUFBYTtBQUMxQjtBQUNBLElBQU0sZUFBTixjQUEyQixPQUFPO0NBQ2hDLGNBQWM7RUFDWixNQUFNO0dBQ0osTUFBTTtHQUNOLE1BQU0sT0FBTztJQUNYLElBQUksaUJBQWlCLFFBQVEsUUFBUSxNQUFNLFFBQVE7SUFDbkQsT0FBTyxPQUFPLFVBQVU7R0FDMUI7RUFDRixDQUFDO0VBQ0QsS0FBSyxtQkFBbUI7R0FDdEIsS0FBSyxXQUFXLE9BQU8sU0FBUztJQUM5QixJQUFJLENBQUMsS0FBSyxLQUFLLFVBQVUsS0FBSyxPQUFPLEtBQUssR0FBRyxPQUFPO0lBR3BELElBQUksTUFBTSxRQUFRLEtBQUssR0FBRyxPQUFPO0lBQ2pDLE1BQU0sV0FBVyxTQUFTLFFBQVEsTUFBTSxXQUFXLE1BQU0sU0FBUyxJQUFJO0lBR3RFLElBQUksYUFBYSxjQUFjLE9BQU87SUFDdEMsT0FBTztHQUNULENBQUM7RUFDSCxDQUFDO0NBQ0g7Q0FDQSxTQUFTLFNBQVM7RUFDaEIsT0FBTyxNQUFNLFNBQVMsT0FBTyxDQUFDLENBQUMsY0FBYSxXQUFVLE9BQU8sS0FBSztHQUNoRSxTQUFTLFdBQVcsTUFBTTtHQUMxQixNQUFNO0dBQ04sWUFBWTtHQUNaLE9BQU0sVUFBUyxDQUFDLENBQUMsTUFBTTtFQUN6QixDQUFDLENBQUM7Q0FDSjtDQUNBLGNBQWM7RUFDWixPQUFPLE1BQU0sWUFBWSxDQUFDLENBQUMsY0FBYSxXQUFVO0dBQ2hELE9BQU8sUUFBUSxPQUFPLE1BQU0sUUFBTyxNQUFLLEVBQUUsUUFBUSxTQUFTLFVBQVU7R0FDckUsT0FBTztFQUNULENBQUM7Q0FDSDtDQUNBLE9BQU8sUUFBUSxVQUFVLE9BQU8sUUFBUTtFQUN0QyxPQUFPLEtBQUssS0FBSztHQUNmO0dBQ0EsTUFBTTtHQUNOLFdBQVc7R0FDWCxRQUFRLEVBQ04sT0FDRjtHQUNBLFlBQVk7R0FDWixLQUFLLE9BQU87SUFDVixPQUFPLE1BQU0sV0FBVyxLQUFLLFFBQVEsTUFBTTtHQUM3QztFQUNGLENBQUM7Q0FDSDtDQUNBLElBQUksS0FBSyxVQUFVLE9BQU8sS0FBSztFQUM3QixPQUFPLEtBQUssS0FBSztHQUNmO0dBQ0EsTUFBTTtHQUNOLFdBQVc7R0FDWCxRQUFRLEVBQ04sSUFDRjtHQUNBLFlBQVk7R0FDWixLQUFLLE9BQU87SUFDVixPQUFPLE1BQU0sVUFBVSxLQUFLLFFBQVEsR0FBRztHQUN6QztFQUNGLENBQUM7Q0FDSDtDQUNBLElBQUksS0FBSyxVQUFVLE9BQU8sS0FBSztFQUM3QixPQUFPLEtBQUssS0FBSztHQUNmLE1BQU07R0FDTixXQUFXO0dBQ1g7R0FDQSxRQUFRLEVBQ04sSUFDRjtHQUNBLFlBQVk7R0FDWixLQUFLLE9BQU87SUFDVixPQUFPLE1BQU0sVUFBVSxLQUFLLFFBQVEsR0FBRztHQUN6QztFQUNGLENBQUM7Q0FDSDtDQUNBLFFBQVEsT0FBTyxTQUFTO0VBQ3RCLElBQUkscUJBQXFCO0VBQ3pCLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSSxTQUFTO0dBQ1gsSUFBSSxPQUFPLFlBQVksVUFDckIsQ0FBQyxDQUNDLHFCQUFxQixPQUNyQixTQUNBLFFBQ0U7UUFFSixVQUFVO0VBRWQ7RUFDQSxPQUFPLEtBQUssS0FBSztHQUNmLE1BQU0sUUFBUTtHQUNkLFNBQVMsV0FBVyxPQUFPO0dBQzNCLFFBQVEsRUFDTixNQUNGO0dBQ0EsWUFBWTtHQUNaLE9BQU0sVUFBUyxVQUFVLE1BQU0sc0JBQXNCLE1BQU0sT0FBTyxLQUFLLE1BQU07RUFDL0UsQ0FBQztDQUNIO0NBQ0EsTUFBTSxVQUFVLE9BQU8sT0FBTztFQUM1QixPQUFPLEtBQUssUUFBUSxRQUFRO0dBQzFCLE1BQU07R0FDTjtHQUNBLG9CQUFvQjtFQUN0QixDQUFDO0NBQ0g7Q0FDQSxJQUFJLFVBQVUsT0FBTyxLQUFLO0VBQ3hCLE9BQU8sS0FBSyxRQUFRLE1BQU07R0FDeEIsTUFBTTtHQUNOO0dBQ0Esb0JBQW9CO0VBQ3RCLENBQUM7Q0FDSDtDQUNBLEtBQUssVUFBVSxPQUFPLE1BQU07RUFDMUIsT0FBTyxLQUFLLFFBQVEsT0FBTztHQUN6QixNQUFNO0dBQ047R0FDQSxvQkFBb0I7RUFDdEIsQ0FBQztDQUNIO0NBQ0EsU0FBUyxTQUFTO0VBQ2hCLElBQUksVUFBVTtFQUNkLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSSxTQUFTO0dBQ1gsSUFBSSxPQUFPLFlBQVksVUFDckIsQ0FBQyxDQUNDLFVBQVUsSUFDVixjQUFjLE9BQ2QsWUFBWSxLQUFBLEtBQ1Y7UUFFSixVQUFVO0VBRWQ7RUFDQSxPQUFPLEtBQUssUUFBUSxjQUFjO0dBQ2hDLE1BQU07R0FDTixTQUFTLFdBQVcsT0FBTztHQUMzQixvQkFBb0I7RUFDdEIsQ0FBQyxDQUFDLENBQUMsS0FBSztHQUNOLE1BQU07R0FDTixTQUFTLFdBQVcsT0FBTztHQUMzQixRQUFRLEVBQ04sWUFDRjtHQUNBLFlBQVk7R0FDWixPQUFNLFVBQVM7SUFDYixJQUFJLENBQUMsU0FBUyxhQUFhLE9BQU87SUFDbEMsTUFBTSxTQUFTLGdCQUFnQixLQUFLO0lBQ3BDLElBQUksQ0FBQyxRQUFRLE9BQU87SUFDcEIsT0FBTyxDQUFDLENBQUMsT0FBTztHQUNsQjtFQUNGLENBQUMsQ0FBQyxDQUFDLEtBQUs7R0FDTixNQUFNO0dBQ04sU0FBUyxXQUFXLE9BQU87R0FDM0IsUUFBUSxFQUNOLFVBQ0Y7R0FDQSxZQUFZO0dBQ1osT0FBTSxVQUFTO0lBQ2IsSUFBSSxDQUFDLFNBQVMsYUFBYSxLQUFBLEdBQVcsT0FBTztJQUM3QyxNQUFNLFNBQVMsZ0JBQWdCLEtBQUs7SUFDcEMsSUFBSSxDQUFDLFFBQVEsT0FBTztJQUNwQixPQUFPLE9BQU8sY0FBYztHQUM5QjtFQUNGLENBQUM7Q0FDSDtDQUdBLFNBQVM7RUFDUCxPQUFPLEtBQUssUUFBUSxFQUFFLENBQUMsQ0FBQyxXQUFVLFFBQU8sUUFBUSxPQUFPLEtBQUssR0FBRztDQUNsRTtDQUNBLEtBQUssVUFBVSxPQUFPLE1BQU07RUFDMUIsT0FBTyxLQUFLLFdBQVUsUUFBTyxPQUFPLE9BQU8sSUFBSSxLQUFLLElBQUksR0FBRyxDQUFDLENBQUMsS0FBSztHQUNoRTtHQUNBLE1BQU07R0FDTixNQUFNO0VBQ1IsQ0FBQztDQUNIO0NBQ0EsVUFBVSxVQUFVLE9BQU8sV0FBVztFQUNwQyxPQUFPLEtBQUssV0FBVSxVQUFTLENBQUMsU0FBUyxLQUFLLElBQUksTUFBTSxZQUFZLElBQUksS0FBSyxDQUFDLENBQUMsS0FBSztHQUNsRjtHQUNBLE1BQU07R0FDTixXQUFXO0dBQ1gsWUFBWTtHQUNaLE9BQU0sVUFBUyxTQUFTLEtBQUssS0FBSyxVQUFVLE1BQU0sWUFBWTtFQUNoRSxDQUFDO0NBQ0g7Q0FDQSxVQUFVLFVBQVUsT0FBTyxXQUFXO0VBQ3BDLE9BQU8sS0FBSyxXQUFVLFVBQVMsQ0FBQyxTQUFTLEtBQUssSUFBSSxNQUFNLFlBQVksSUFBSSxLQUFLLENBQUMsQ0FBQyxLQUFLO0dBQ2xGO0dBQ0EsTUFBTTtHQUNOLFdBQVc7R0FDWCxZQUFZO0dBQ1osT0FBTSxVQUFTLFNBQVMsS0FBSyxLQUFLLFVBQVUsTUFBTSxZQUFZO0VBQ2hFLENBQUM7Q0FDSDtBQUNGO0FBQ0EsU0FBUyxZQUFZLGFBQWE7QUFNbEMsSUFBSSxXQUFVLFVBQVMsU0FBUyxDQUFDO0FBQ2pDLFNBQVMsV0FBVztDQUNsQixPQUFPLElBQUksYUFBYTtBQUMxQjtBQUNBLElBQU0sZUFBTixjQUEyQixPQUFPO0NBQ2hDLGNBQWM7RUFDWixNQUFNO0dBQ0osTUFBTTtHQUNOLE1BQU0sT0FBTztJQUNYLElBQUksaUJBQWlCLFFBQVEsUUFBUSxNQUFNLFFBQVE7SUFDbkQsT0FBTyxPQUFPLFVBQVUsWUFBWSxDQUFDLFFBQVEsS0FBSztHQUNwRDtFQUNGLENBQUM7RUFDRCxLQUFLLG1CQUFtQjtHQUN0QixLQUFLLFdBQVcsT0FBTyxTQUFTO0lBQzlCLElBQUksQ0FBQyxLQUFLLEtBQUssUUFBUSxPQUFPO0lBQzlCLElBQUksU0FBUztJQUNiLElBQUksT0FBTyxXQUFXLFVBQVU7S0FDOUIsU0FBUyxPQUFPLFFBQVEsT0FBTyxFQUFFO0tBQ2pDLElBQUksV0FBVyxJQUFJLE9BQU87S0FFMUIsU0FBUyxDQUFDO0lBQ1o7SUFJQSxJQUFJLEtBQUssT0FBTyxNQUFNLEtBQUssV0FBVyxNQUFNLE9BQU87SUFDbkQsT0FBTyxXQUFXLE1BQU07R0FDMUIsQ0FBQztFQUNILENBQUM7Q0FDSDtDQUNBLElBQUksS0FBSyxVQUFVLE9BQU8sS0FBSztFQUM3QixPQUFPLEtBQUssS0FBSztHQUNmO0dBQ0EsTUFBTTtHQUNOLFdBQVc7R0FDWCxRQUFRLEVBQ04sSUFDRjtHQUNBLFlBQVk7R0FDWixLQUFLLE9BQU87SUFDVixPQUFPLFNBQVMsS0FBSyxRQUFRLEdBQUc7R0FDbEM7RUFDRixDQUFDO0NBQ0g7Q0FDQSxJQUFJLEtBQUssVUFBVSxPQUFPLEtBQUs7RUFDN0IsT0FBTyxLQUFLLEtBQUs7R0FDZjtHQUNBLE1BQU07R0FDTixXQUFXO0dBQ1gsUUFBUSxFQUNOLElBQ0Y7R0FDQSxZQUFZO0dBQ1osS0FBSyxPQUFPO0lBQ1YsT0FBTyxTQUFTLEtBQUssUUFBUSxHQUFHO0dBQ2xDO0VBQ0YsQ0FBQztDQUNIO0NBQ0EsU0FBUyxNQUFNLFVBQVUsT0FBTyxVQUFVO0VBQ3hDLE9BQU8sS0FBSyxLQUFLO0dBQ2Y7R0FDQSxNQUFNO0dBQ04sV0FBVztHQUNYLFFBQVEsRUFDTixLQUNGO0dBQ0EsWUFBWTtHQUNaLEtBQUssT0FBTztJQUNWLE9BQU8sUUFBUSxLQUFLLFFBQVEsSUFBSTtHQUNsQztFQUNGLENBQUM7Q0FDSDtDQUNBLFNBQVMsTUFBTSxVQUFVLE9BQU8sVUFBVTtFQUN4QyxPQUFPLEtBQUssS0FBSztHQUNmO0dBQ0EsTUFBTTtHQUNOLFdBQVc7R0FDWCxRQUFRLEVBQ04sS0FDRjtHQUNBLFlBQVk7R0FDWixLQUFLLE9BQU87SUFDVixPQUFPLFFBQVEsS0FBSyxRQUFRLElBQUk7R0FDbEM7RUFDRixDQUFDO0NBQ0g7Q0FDQSxTQUFTLE1BQU0sT0FBTyxVQUFVO0VBQzlCLE9BQU8sS0FBSyxTQUFTLEdBQUcsR0FBRztDQUM3QjtDQUNBLFNBQVMsTUFBTSxPQUFPLFVBQVU7RUFDOUIsT0FBTyxLQUFLLFNBQVMsR0FBRyxHQUFHO0NBQzdCO0NBQ0EsUUFBUSxVQUFVLE9BQU8sU0FBUztFQUNoQyxPQUFPLEtBQUssS0FBSztHQUNmLE1BQU07R0FDTjtHQUNBLFlBQVk7R0FDWixPQUFNLFFBQU8sT0FBTyxVQUFVLEdBQUc7RUFDbkMsQ0FBQztDQUNIO0NBQ0EsV0FBVztFQUNULE9BQU8sS0FBSyxXQUFVLFVBQVMsQ0FBQyxTQUFTLEtBQUssSUFBSSxRQUFRLElBQUksS0FBSztDQUNyRTtDQUNBLE1BQU0sUUFBUTtFQUNaLElBQUk7RUFDSixJQUFJLFFBQVE7R0FBQztHQUFRO0dBQVM7R0FBUztFQUFPO0VBQzlDLFdBQVcsVUFBVSxXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVEsWUFBWSxNQUFNO0VBRzFFLElBQUksV0FBVyxTQUFTLE9BQU8sS0FBSyxTQUFTO0VBQzdDLElBQUksTUFBTSxRQUFRLE9BQU8sWUFBWSxDQUFDLE1BQU0sSUFBSSxNQUFNLElBQUksVUFBVSx5Q0FBeUMsTUFBTSxLQUFLLElBQUksQ0FBQztFQUM3SCxPQUFPLEtBQUssV0FBVSxVQUFTLENBQUMsU0FBUyxLQUFLLElBQUksS0FBSyxPQUFPLENBQUMsS0FBSyxJQUFJLEtBQUs7Q0FDL0U7QUFDRjtBQUNBLFNBQVMsWUFBWSxhQUFhO0FBTWxDLElBQUksOEJBQWMsSUFBSSxLQUFLLEVBQUU7QUFDN0IsSUFBSSxVQUFTLFFBQU8sT0FBTyxVQUFVLFNBQVMsS0FBSyxHQUFHLE1BQU07QUFDNUQsU0FBUyxXQUFXO0NBQ2xCLE9BQU8sSUFBSSxXQUFXO0FBQ3hCO0FBQ0EsSUFBTSxhQUFOLE1BQU0sbUJBQW1CLE9BQU87Q0FDOUIsY0FBYztFQUNaLE1BQU07R0FDSixNQUFNO0dBQ04sTUFBTSxHQUFHO0lBQ1AsT0FBTyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUM7R0FDeEM7RUFDRixDQUFDO0VBQ0QsS0FBSyxtQkFBbUI7R0FDdEIsS0FBSyxXQUFXLE9BQU8sU0FBUztJQUc5QixJQUFJLENBQUMsS0FBSyxLQUFLLFVBQVUsS0FBSyxPQUFPLEtBQUssS0FBSyxVQUFVLE1BQU0sT0FBTztJQUN0RSxRQUFRLGFBQWEsS0FBSztJQUcxQixPQUFPLENBQUMsTUFBTSxLQUFLLElBQUksSUFBSSxLQUFLLEtBQUssSUFBSSxXQUFXO0dBQ3RELENBQUM7RUFDSCxDQUFDO0NBQ0g7Q0FDQSxhQUFhLEtBQUssTUFBTTtFQUN0QixJQUFJO0VBQ0osSUFBSSxDQUFDLFVBQVUsTUFBTSxHQUFHLEdBQUc7R0FDekIsSUFBSSxPQUFPLEtBQUssS0FBSyxHQUFHO0dBQ3hCLElBQUksQ0FBQyxLQUFLLFdBQVcsSUFBSSxHQUFHLE1BQU0sSUFBSSxVQUFVLEtBQUssS0FBSyw4REFBOEQ7R0FDeEgsUUFBUTtFQUNWLE9BQ0UsUUFBUTtFQUVWLE9BQU87Q0FDVDtDQUNBLElBQUksS0FBSyxVQUFVLEtBQUssS0FBSztFQUMzQixJQUFJLFFBQVEsS0FBSyxhQUFhLEtBQUssS0FBSztFQUN4QyxPQUFPLEtBQUssS0FBSztHQUNmO0dBQ0EsTUFBTTtHQUNOLFdBQVc7R0FDWCxRQUFRLEVBQ04sSUFDRjtHQUNBLFlBQVk7R0FDWixLQUFLLE9BQU87SUFDVixPQUFPLFNBQVMsS0FBSyxRQUFRLEtBQUs7R0FDcEM7RUFDRixDQUFDO0NBQ0g7Q0FDQSxJQUFJLEtBQUssVUFBVSxLQUFLLEtBQUs7RUFDM0IsSUFBSSxRQUFRLEtBQUssYUFBYSxLQUFLLEtBQUs7RUFDeEMsT0FBTyxLQUFLLEtBQUs7R0FDZjtHQUNBLE1BQU07R0FDTixXQUFXO0dBQ1gsUUFBUSxFQUNOLElBQ0Y7R0FDQSxZQUFZO0dBQ1osS0FBSyxPQUFPO0lBQ1YsT0FBTyxTQUFTLEtBQUssUUFBUSxLQUFLO0dBQ3BDO0VBQ0YsQ0FBQztDQUNIO0FBQ0Y7QUFDQSxXQUFXLGVBQWU7QUFDMUIsU0FBUyxZQUFZLFdBQVc7QUFDaEMsU0FBUyxlQUFlO0FBR3hCLFNBQVMsV0FBVyxRQUFRLGdCQUFnQixDQUFDLEdBQUc7Q0FDOUMsSUFBSSxRQUFRLENBQUM7Q0FDYixJQUFJLHdCQUFRLElBQUksSUFBSTtDQUNwQixJQUFJLFdBQVcsSUFBSSxJQUFJLGNBQWMsS0FBSyxDQUFDLEdBQUcsT0FBTyxHQUFHLEVBQUUsR0FBRyxHQUFHLENBQUM7Q0FDakUsU0FBUyxRQUFRLFNBQVMsS0FBSztFQUM3QixJQUFJLFFBQUEsR0FBT0MscUJBQUFBLE1BQUFBLENBQU0sT0FBTyxDQUFDLENBQUM7RUFDMUIsTUFBTSxJQUFJLElBQUk7RUFDZCxJQUFJLENBQUMsU0FBUyxJQUFJLEdBQUcsSUFBSSxHQUFHLE1BQU0sR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLElBQUksQ0FBQztDQUM3RDtDQUNBLEtBQUssTUFBTSxPQUFPLE9BQU8sS0FBSyxNQUFNLEdBQUc7RUFDckMsSUFBSSxRQUFRLE9BQU87RUFDbkIsTUFBTSxJQUFJLEdBQUc7RUFDYixJQUFJLFVBQVUsTUFBTSxLQUFLLEtBQUssTUFBTSxXQUFXLFFBQVEsTUFBTSxNQUFNLEdBQUc7T0FBTyxJQUFJLFNBQVMsS0FBSyxLQUFLLFVBQVUsT0FBTyxNQUFNLEtBQUssU0FBUSxTQUFRLFFBQVEsTUFBTSxHQUFHLENBQUM7Q0FDcEs7Q0FDQSxPQUFPQyxnQkFBQUEsUUFBUyxNQUFNLE1BQU0sS0FBSyxLQUFLLEdBQUcsS0FBSyxDQUFDLENBQUMsUUFBUTtBQUMxRDtBQUVBLFNBQVMsVUFBVSxLQUFLLEtBQUs7Q0FDM0IsSUFBSSxNQUFNO0NBQ1YsSUFBSSxNQUFNLEtBQUssT0FBTztFQUNwQixJQUFJO0VBQ0osS0FBSyxZQUFZLElBQUksU0FBUyxRQUFRLFVBQVUsU0FBUyxHQUFHLEdBQUc7R0FDN0QsTUFBTTtHQUNOLE9BQU87RUFDVDtDQUNGLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGVBQWUsTUFBTTtDQUM1QixRQUFRLEdBQUcsTUFBTTtFQUNmLE9BQU8sVUFBVSxNQUFNLENBQUMsSUFBSSxVQUFVLE1BQU0sQ0FBQztDQUMvQztBQUNGO0FBRUEsSUFBTSxhQUFhLE9BQU8sR0FBRyxXQUFXO0NBQ3RDLElBQUksT0FBTyxVQUFVLFVBQ25CLE9BQU87Q0FFVCxJQUFJLFNBQVM7Q0FDYixJQUFJO0VBQ0YsU0FBUyxLQUFLLE1BQU0sS0FBSztDQUMzQixTQUFTLEtBQUssQ0FFZDtDQUNBLE9BQU8sT0FBTyxPQUFPLE1BQU0sSUFBSSxTQUFTO0FBQzFDO0FBR0EsU0FBUyxZQUFZLFFBQVE7Q0FDM0IsSUFBSSxZQUFZLFFBQVE7RUFDdEIsTUFBTSxVQUFVLENBQUM7RUFDakIsS0FBSyxNQUFNLENBQUMsS0FBSyxnQkFBZ0IsT0FBTyxRQUFRLE9BQU8sTUFBTSxHQUMzRCxRQUFRLE9BQU8sWUFBWSxXQUFXO0VBRXhDLE9BQU8sT0FBTyxVQUFVLE9BQU87Q0FDakM7Q0FDQSxJQUFJLE9BQU8sU0FBUyxTQUFTO0VBQzNCLE1BQU0sWUFBWSxPQUFPLFNBQVM7RUFDbEMsSUFBSSxVQUFVLFdBQVcsVUFBVSxZQUFZLFlBQVksVUFBVSxTQUFTO0VBQzlFLE9BQU87Q0FDVDtDQUNBLElBQUksT0FBTyxTQUFTLFNBQ2xCLE9BQU8sT0FBTyxTQUFTLENBQUMsQ0FBQyxNQUFNLEVBQzdCLE9BQU8sT0FBTyxLQUFLLE1BQU0sSUFBSSxXQUFXLEVBQzFDLENBQUM7Q0FFSCxJQUFJLGNBQWMsUUFDaEIsT0FBTyxPQUFPLFNBQVM7Q0FFekIsT0FBTztBQUNUO0FBQ0EsSUFBTSxXQUFXLEtBQUssTUFBTTtDQUMxQixNQUFNLE9BQU8sQ0FBQyxJQUFBLEdBQUdDLHFCQUFBQSxjQUFBQSxDQUFjLENBQUMsQ0FBQztDQUNqQyxJQUFJLEtBQUssV0FBVyxHQUFHLE9BQU8sS0FBSyxNQUFNO0NBQ3pDLElBQUksT0FBTyxLQUFLLElBQUk7Q0FDcEIsSUFBSSxVQUFBLEdBQVNILHFCQUFBQSxPQUFBQSxFQUFBQSxHQUFPSSxxQkFBQUEsS0FBQUEsQ0FBSyxJQUFJLEdBQUcsSUFBSSxDQUFDLENBQUMsR0FBRztDQUN6QyxPQUFPLENBQUMsRUFBRSxVQUFVLFFBQVE7QUFDOUI7QUFDQSxJQUFJLFlBQVcsUUFBTyxPQUFPLFVBQVUsU0FBUyxLQUFLLEdBQUcsTUFBTTtBQUM5RCxTQUFTLFFBQVEsS0FBSyxPQUFPO0NBQzNCLElBQUksUUFBUSxPQUFPLEtBQUssSUFBSSxNQUFNO0NBQ2xDLE9BQU8sT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDLFFBQU8sUUFBTyxNQUFNLFFBQVEsR0FBRyxNQUFNLEVBQUU7QUFDbkU7QUFDQSxJQUFNLGNBQWMsZUFBZSxDQUFDLENBQUM7QUFDckMsU0FBUyxTQUFTLE1BQU07Q0FDdEIsT0FBTyxJQUFJLGFBQWEsSUFBSTtBQUM5QjtBQUNBLElBQU0sZUFBTixjQUEyQixPQUFPO0NBQ2hDLFlBQVksTUFBTTtFQUNoQixNQUFNO0dBQ0osTUFBTTtHQUNOLE1BQU0sT0FBTztJQUNYLE9BQU8sU0FBUyxLQUFLLEtBQUssT0FBTyxVQUFVO0dBQzdDO0VBQ0YsQ0FBQztFQUNELEtBQUssU0FBUyxPQUFPLE9BQU8sSUFBSTtFQUNoQyxLQUFLLGNBQWM7RUFDbkIsS0FBSyxTQUFTLENBQUM7RUFDZixLQUFLLGlCQUFpQixDQUFDO0VBQ3ZCLEtBQUssbUJBQW1CO0dBQ3RCLElBQUksTUFDRixLQUFLLE1BQU0sSUFBSTtFQUVuQixDQUFDO0NBQ0g7Q0FDQSxNQUFNLFFBQVEsVUFBVSxDQUFDLEdBQUc7RUFDMUIsSUFBSTtFQUNKLElBQUksUUFBUSxNQUFNLE1BQU0sUUFBUSxPQUFPO0VBR3ZDLElBQUksVUFBVSxLQUFBLEdBQVcsT0FBTyxLQUFLLFdBQVcsT0FBTztFQUN2RCxJQUFJLENBQUMsS0FBSyxXQUFXLEtBQUssR0FBRyxPQUFPO0VBQ3BDLElBQUksU0FBUyxLQUFLO0VBQ2xCLElBQUksU0FBUyx3QkFBd0IsUUFBUSxpQkFBaUIsT0FBTyx3QkFBd0IsS0FBSyxLQUFLO0VBQ3ZHLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxPQUFPLEtBQUssUUFBUSxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsUUFBTyxNQUFLLENBQUMsS0FBSyxPQUFPLFNBQVMsQ0FBQyxDQUFDLENBQUM7RUFDM0YsSUFBSSxvQkFBb0IsQ0FBQztFQUN6QixJQUFJLGVBQWUsT0FBTyxPQUFPLENBQUMsR0FBRyxTQUFTO0dBQzVDLFFBQVE7R0FDUixjQUFjLFFBQVEsZ0JBQWdCO0VBQ3hDLENBQUM7RUFDRCxJQUFJLFlBQVk7RUFDaEIsS0FBSyxNQUFNLFFBQVEsT0FBTztHQUN4QixJQUFJLFFBQVEsT0FBTztHQUNuQixJQUFJLFNBQVUsUUFBUTtHQUN0QixJQUFJLGFBQWEsTUFBTTtHQUN2QixJQUFJLE9BQU87SUFDVCxJQUFJO0lBR0osYUFBYSxRQUFRLFFBQVEsT0FBTyxHQUFHLFFBQVEsS0FBSyxLQUFLLE1BQU07SUFDL0QsUUFBUSxNQUFNLFFBQVE7S0FDcEIsT0FBTztLQUNQLFNBQVMsUUFBUTtLQUNqQixRQUFRO0lBQ1YsQ0FBQztJQUNELElBQUksWUFBWSxpQkFBaUIsU0FBUyxNQUFNLE9BQU8sS0FBQTtJQUN2RCxJQUFJLFNBQVMsYUFBYSxPQUFPLEtBQUssSUFBSSxVQUFVO0lBQ3BELElBQUksYUFBYSxRQUFRLFVBQVUsT0FBTztLQUN4QyxZQUFZLGFBQWEsUUFBUTtLQUNqQztJQUNGO0lBQ0EsYUFBYSxDQUFDLFFBQVEsZ0JBQWdCLENBQUMsU0FBUyxNQUFNLEtBQUssWUFBWSxZQUFZLElBQUk7SUFDdkYsSUFBSSxlQUFlLEtBQUEsR0FDakIsa0JBQWtCLFFBQVE7R0FFOUIsT0FBTyxJQUFJLFVBQVUsQ0FBQyxPQUNwQixrQkFBa0IsUUFBUTtHQUU1QixJQUFJLFdBQVcsUUFBUSxxQkFBcUIsa0JBQWtCLFVBQVUsWUFDdEUsWUFBWTtFQUVoQjtFQUNBLE9BQU8sWUFBWSxvQkFBb0I7Q0FDekM7Q0FDQSxVQUFVLFFBQVEsVUFBVSxDQUFDLEdBQUcsT0FBTyxNQUFNO0VBQzNDLElBQUksRUFDRixPQUFPLENBQUMsR0FDUixnQkFBZ0IsUUFDaEIsWUFBWSxLQUFLLEtBQUssY0FDcEI7RUFDSixRQUFRLE9BQU8sQ0FBQztHQUNkLFFBQVE7R0FDUixPQUFPO0VBQ1QsR0FBRyxHQUFHLElBQUk7RUFHVixRQUFRLGVBQWU7RUFDdkIsUUFBUSxnQkFBZ0I7RUFDeEIsTUFBTSxVQUFVLFFBQVEsU0FBUyxRQUFRLGNBQWMsVUFBVTtHQUMvRCxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsS0FBSyxHQUFHO0lBQ2xDLEtBQUssY0FBYyxLQUFLO0lBQ3hCO0dBQ0Y7R0FDQSxnQkFBZ0IsaUJBQWlCO0dBQ2pDLElBQUksUUFBUSxDQUFDO0dBQ2IsS0FBSyxJQUFJLE9BQU8sS0FBSyxRQUFRO0lBQzNCLElBQUksUUFBUSxLQUFLLE9BQU87SUFDeEIsSUFBSSxDQUFDLFNBQVMsVUFBVSxNQUFNLEtBQUssR0FDakM7SUFFRixNQUFNLEtBQUssTUFBTSxhQUFhO0tBQzVCO0tBQ0E7S0FDQSxRQUFRO0tBQ1IsWUFBWSxRQUFRO0tBQ3BCLGdCQUFnQjtJQUNsQixDQUFDLENBQUM7R0FDSjtHQUNBLEtBQUssU0FBUztJQUNaO0lBQ0E7SUFDQTtJQUNBO0dBQ0YsR0FBRyxRQUFPLGdCQUFlO0lBQ3ZCLEtBQUssWUFBWSxLQUFLLEtBQUssV0FBVyxDQUFDLENBQUMsT0FBTyxZQUFZLEdBQUcsS0FBSztHQUNyRSxDQUFDO0VBQ0gsQ0FBQztDQUNIO0NBQ0EsTUFBTSxNQUFNO0VBQ1YsTUFBTSxPQUFPLE1BQU0sTUFBTSxJQUFJO0VBQzdCLEtBQUssU0FBUyxPQUFPLE9BQU8sQ0FBQyxHQUFHLEtBQUssTUFBTTtFQUMzQyxLQUFLLFNBQVMsS0FBSztFQUNuQixLQUFLLGlCQUFpQixLQUFLO0VBQzNCLEtBQUssY0FBYyxLQUFLO0VBQ3hCLE9BQU87Q0FDVDtDQUNBLE9BQU8sUUFBUTtFQUNiLElBQUksT0FBTyxNQUFNLE9BQU8sTUFBTTtFQUM5QixJQUFJLGFBQWEsS0FBSztFQUN0QixLQUFLLElBQUksQ0FBQyxPQUFPLGdCQUFnQixPQUFPLFFBQVEsS0FBSyxNQUFNLEdBQUc7R0FDNUQsTUFBTSxTQUFTLFdBQVc7R0FDMUIsV0FBVyxTQUFTLFdBQVcsS0FBQSxJQUFZLGNBQWM7RUFDM0Q7RUFDQSxPQUFPLEtBQUssY0FBYSxNQUV6QixFQUFFLFVBQVUsWUFBWSxDQUFDLEdBQUcsS0FBSyxnQkFBZ0IsR0FBRyxPQUFPLGNBQWMsQ0FBQyxDQUFDO0NBQzdFO0NBQ0EsWUFBWSxTQUFTO0VBQ25CLElBQUksYUFBYSxLQUFLLE1BQ3BCLE9BQU8sTUFBTSxZQUFZLE9BQU87RUFJbEMsSUFBSSxDQUFDLEtBQUssT0FBTyxRQUNmO0VBRUYsSUFBSSxNQUFNLENBQUM7RUFDWCxLQUFLLE9BQU8sU0FBUSxRQUFPO0dBQ3pCLElBQUk7R0FDSixNQUFNLFFBQVEsS0FBSyxPQUFPO0dBQzFCLElBQUksZUFBZTtHQUNuQixLQUFLLGdCQUFnQixpQkFBaUIsUUFBUSxjQUFjLE9BQzFELGVBQWUsT0FBTyxPQUFPLENBQUMsR0FBRyxjQUFjO0lBQzdDLFFBQVEsYUFBYTtJQUNyQixPQUFPLGFBQWEsTUFBTTtHQUM1QixDQUFDO0dBRUgsSUFBSSxPQUFPLFNBQVMsZ0JBQWdCLFFBQVEsTUFBTSxXQUFXLFlBQVksSUFBSSxLQUFBO0VBQy9FLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSxVQUFVLE9BQU8sZUFBZTtFQUM5QixJQUFJLE9BQU8sS0FBSyxNQUFNO0VBQ3RCLEtBQUssU0FBUztFQUNkLEtBQUssU0FBUyxXQUFXLE9BQU8sYUFBYTtFQUM3QyxLQUFLLGNBQWMsZUFBZSxPQUFPLEtBQUssS0FBSyxDQUFDO0VBRXBELElBQUksZUFBZSxLQUFLLGlCQUFpQjtFQUN6QyxPQUFPO0NBQ1Q7Q0FDQSxNQUFNLFdBQVcsV0FBVyxDQUFDLEdBQUc7RUFDOUIsT0FBTyxLQUFLLE1BQU0sQ0FBQyxDQUFDLGNBQWEsU0FBUTtHQUN2QyxJQUFJLFFBQVEsS0FBSztHQUNqQixJQUFJLFNBQVMsUUFBUTtJQUNuQixJQUFJLENBQUMsTUFBTSxRQUFRLFNBQVMsRUFBRSxHQUFHLFdBQVcsQ0FBQyxRQUFRO0lBQ3JELFFBQVEsQ0FBQyxHQUFHLEtBQUssZ0JBQWdCLEdBQUcsUUFBUTtHQUM5QztHQUdBLE9BQU8sS0FBSyxVQUFVLE9BQU8sT0FBTyxLQUFLLFFBQVEsU0FBUyxHQUFHLEtBQUs7RUFDcEUsQ0FBQztDQUNIO0NBQ0EsVUFBVTtFQUNSLE1BQU0sVUFBVSxDQUFDO0VBQ2pCLEtBQUssTUFBTSxDQUFDLEtBQUssV0FBVyxPQUFPLFFBQVEsS0FBSyxNQUFNLEdBQ3BELFFBQVEsT0FBTyxjQUFjLFVBQVUsT0FBTyxvQkFBb0IsV0FBVyxPQUFPLFNBQVMsSUFBSTtFQUVuRyxPQUFPLEtBQUssVUFBVSxPQUFPO0NBQy9CO0NBQ0EsY0FBYztFQUVaLE9BRGEsWUFBWSxJQUNmO0NBQ1o7Q0FDQSxLQUFLLE1BQU07RUFDVCxNQUFNLFNBQVMsQ0FBQztFQUNoQixLQUFLLE1BQU0sT0FBTyxNQUNoQixJQUFJLEtBQUssT0FBTyxNQUFNLE9BQU8sT0FBTyxLQUFLLE9BQU87RUFFbEQsT0FBTyxLQUFLLFVBQVUsUUFBUSxLQUFLLGVBQWUsUUFBUSxDQUFDLEdBQUcsT0FBTyxLQUFLLFNBQVMsQ0FBQyxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQztDQUM1RztDQUNBLEtBQUssTUFBTTtFQUNULE1BQU0sWUFBWSxDQUFDO0VBQ25CLEtBQUssTUFBTSxPQUFPLE9BQU8sS0FBSyxLQUFLLE1BQU0sR0FBRztHQUMxQyxJQUFJLEtBQUssU0FBUyxHQUFHLEdBQUc7R0FDeEIsVUFBVSxLQUFLLEdBQUc7RUFDcEI7RUFDQSxPQUFPLEtBQUssS0FBSyxTQUFTO0NBQzVCO0NBQ0EsS0FBSyxNQUFNLElBQUksT0FBTztFQUNwQixJQUFJLGNBQUEsR0FBYUoscUJBQUFBLE9BQUFBLENBQU8sTUFBTSxJQUFJO0VBQ2xDLE9BQU8sS0FBSyxXQUFVLFFBQU87R0FDM0IsSUFBSSxDQUFDLEtBQUssT0FBTztHQUNqQixJQUFJLFNBQVM7R0FDYixJQUFJLFFBQVEsS0FBSyxJQUFJLEdBQUc7SUFDdEIsU0FBUyxPQUFPLE9BQU8sQ0FBQyxHQUFHLEdBQUc7SUFDOUIsSUFBSSxDQUFDLE9BQU8sT0FBTyxPQUFPO0lBQzFCLE9BQU8sTUFBTSxXQUFXLEdBQUc7R0FDN0I7R0FDQSxPQUFPO0VBQ1QsQ0FBQztDQUNIOztDQUdBLE9BQU87RUFDTCxPQUFPLEtBQUssVUFBVSxTQUFTO0NBQ2pDOzs7O0NBS0EsTUFBTSxTQUFTO0VBQ2IsT0FBTyxLQUFLLEtBQUs7R0FDZixNQUFNO0dBQ04sV0FBVztHQUNYLFNBQVMsV0FBVyxPQUFPO0dBQzNCLEtBQUssT0FBTztJQUNWLElBQUksU0FBUyxNQUFNLE9BQU87SUFDMUIsTUFBTSxjQUFjLFFBQVEsS0FBSyxRQUFRLEtBQUs7SUFDOUMsT0FBTyxZQUFZLFdBQVcsS0FBSyxLQUFLLFlBQVksRUFDbEQsUUFBUSxFQUNOLFlBQVksWUFBWSxLQUFLLElBQUksRUFDbkMsRUFDRixDQUFDO0dBQ0g7RUFDRixDQUFDO0NBQ0g7Q0FDQSxlQUFlO0VBQ2IsT0FBTyxLQUFLLE1BQU0sRUFDaEIsV0FBVyxLQUNiLENBQUM7Q0FDSDtDQUNBLFVBQVUsVUFBVSxNQUFNLFVBQVUsT0FBTyxXQUFXO0VBQ3BELElBQUksT0FBTyxZQUFZLFdBQVc7R0FDaEMsVUFBVTtHQUNWLFVBQVU7RUFDWjtFQUNBLElBQUksT0FBTyxLQUFLLEtBQUs7R0FDbkIsTUFBTTtHQUNOLFdBQVc7R0FDRjtHQUNULEtBQUssT0FBTztJQUNWLElBQUksU0FBUyxNQUFNLE9BQU87SUFDMUIsTUFBTSxjQUFjLFFBQVEsS0FBSyxRQUFRLEtBQUs7SUFDOUMsT0FBTyxDQUFDLFdBQVcsWUFBWSxXQUFXLEtBQUssS0FBSyxZQUFZLEVBQzlELFFBQVEsRUFDTixTQUFTLFlBQVksS0FBSyxJQUFJLEVBQ2hDLEVBQ0YsQ0FBQztHQUNIO0VBQ0YsQ0FBQztFQUNELEtBQUssS0FBSyxZQUFZO0VBQ3RCLE9BQU87Q0FDVDtDQUNBLFFBQVEsUUFBUSxNQUFNLFVBQVUsT0FBTyxXQUFXO0VBQ2hELE9BQU8sS0FBSyxVQUFVLENBQUMsT0FBTyxPQUFPO0NBQ3ZDO0NBQ0EsY0FBYyxJQUFJO0VBQ2hCLE9BQU8sS0FBSyxXQUFVLFFBQU87R0FDM0IsSUFBSSxDQUFDLEtBQUssT0FBTztHQUNqQixNQUFNLFNBQVMsQ0FBQztHQUNoQixLQUFLLE1BQU0sT0FBTyxPQUFPLEtBQUssR0FBRyxHQUFHLE9BQU8sR0FBRyxHQUFHLEtBQUssSUFBSTtHQUMxRCxPQUFPO0VBQ1QsQ0FBQztDQUNIO0NBQ0EsWUFBWTtFQUNWLE9BQU8sS0FBSyxjQUFjSyxpQkFBQUEsU0FBUztDQUNyQztDQUNBLFlBQVk7RUFDVixPQUFPLEtBQUssY0FBY0MsaUJBQUFBLFNBQVM7Q0FDckM7Q0FDQSxlQUFlO0VBQ2IsT0FBTyxLQUFLLGVBQWMsU0FBQSxHQUFPQSxpQkFBQUEsVUFBQUEsQ0FBVSxHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUM7Q0FDL0Q7Q0FDQSxTQUFTLFNBQVM7RUFDaEIsTUFBTSxRQUFRLFVBQVUsS0FBSyxRQUFRLE9BQU8sSUFBSSxLQUFBLENBQU0sTUFBTTtFQUM1RCxNQUFNLE9BQU8sTUFBTSxTQUFTLE9BQU87RUFDbkMsS0FBSyxTQUFTLENBQUM7RUFDZixLQUFLLE1BQU0sQ0FBQyxLQUFLLFVBQVUsT0FBTyxRQUFRLEtBQUssTUFBTSxHQUFHO0dBQ3RELElBQUk7R0FDSixJQUFJLGVBQWU7R0FDbkIsS0FBSyxpQkFBaUIsaUJBQWlCLFFBQVEsZUFBZSxPQUM1RCxlQUFlLE9BQU8sT0FBTyxDQUFDLEdBQUcsY0FBYztJQUM3QyxRQUFRLGFBQWE7SUFDckIsT0FBTyxhQUFhLE1BQU07R0FDNUIsQ0FBQztHQUVILEtBQUssT0FBTyxPQUFPLE1BQU0sU0FBUyxZQUFZO0VBQ2hEO0VBQ0EsT0FBTztDQUNUO0FBQ0Y7QUFDQSxTQUFTLFlBQVksYUFBYTtBQUVsQyxTQUFTLFNBQVMsTUFBTTtDQUN0QixPQUFPLElBQUksWUFBWSxJQUFJO0FBQzdCO0FBQ0EsSUFBTSxjQUFOLGNBQTBCLE9BQU87Q0FDL0IsWUFBWSxNQUFNO0VBQ2hCLE1BQU07R0FDSixNQUFNO0dBQ04sTUFBTSxFQUNKLE9BQU8sS0FDVDtHQUNBLE1BQU0sR0FBRztJQUNQLE9BQU8sTUFBTSxRQUFRLENBQUM7R0FDeEI7RUFDRixDQUFDO0VBR0QsS0FBSyxZQUFZLEtBQUs7RUFDdEIsS0FBSyxZQUFZO0NBQ25CO0NBQ0EsTUFBTSxRQUFRLE9BQU87RUFDbkIsTUFBTSxRQUFRLE1BQU0sTUFBTSxRQUFRLEtBQUs7RUFHdkMsSUFBSSxDQUFDLEtBQUssV0FBVyxLQUFLLEtBQUssQ0FBQyxLQUFLLFdBQ25DLE9BQU87RUFFVCxJQUFJLFlBQVk7RUFDaEIsTUFBTSxZQUFZLE1BQU0sS0FBSyxHQUFHLFFBQVE7R0FDdEMsTUFBTSxjQUFjLEtBQUssVUFBVSxLQUFLLEdBQUcsT0FBTyxPQUFPLENBQUMsR0FBRyxPQUFPO0lBQ2xFLE1BQU0sR0FBRyxNQUFNLFFBQVEsR0FBRyxHQUFHLElBQUk7SUFDakMsUUFBUTtJQUNSLGVBQWU7SUFDZixPQUFPO0lBQ1AsT0FBTztHQUNULENBQUMsQ0FBQztHQUNGLElBQUksZ0JBQWdCLEdBQ2xCLFlBQVk7R0FFZCxPQUFPO0VBQ1QsQ0FBQztFQUNELE9BQU8sWUFBWSxZQUFZO0NBQ2pDO0NBQ0EsVUFBVSxRQUFRLFVBQVUsQ0FBQyxHQUFHLE9BQU8sTUFBTTtFQUMzQyxJQUFJO0VBR0osSUFBSSxZQUFZLEtBQUs7RUFFckIsSUFBSSxhQUFhLHFCQUFxQixRQUFRLGNBQWMsT0FBTyxxQkFBcUIsS0FBSyxLQUFLO0VBQ2xHLFFBQVEsaUJBQWlCLFFBQU8sUUFBUTtFQUN4QyxNQUFNLFVBQVUsUUFBUSxTQUFTLFFBQVEsYUFBYSxVQUFVO0dBQzlELElBQUk7R0FDSixJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxLQUFLLFdBQVcsS0FBSyxHQUFHO0lBQ3ZELEtBQUssYUFBYSxLQUFLO0lBQ3ZCO0dBQ0Y7R0FHQSxJQUFJLFFBQVEsSUFBSSxNQUFNLE1BQU0sTUFBTTtHQUNsQyxLQUFLLElBQUksUUFBUSxHQUFHLFFBQVEsTUFBTSxRQUFRLFNBQVM7SUFDakQsSUFBSTtJQUNKLE1BQU0sU0FBUyxVQUFVLGFBQWE7S0FDcEM7S0FDQTtLQUNBLFFBQVE7S0FDUixZQUFZLFFBQVE7S0FDcEIsaUJBQWlCLHdCQUF3QixRQUFRLGtCQUFrQixPQUFPLHdCQUF3QjtJQUNwRyxDQUFDO0dBQ0g7R0FDQSxLQUFLLFNBQVM7SUFDWjtJQUNBO0lBQ0EsZ0JBQWdCLHlCQUF5QixRQUFRLGtCQUFrQixPQUFPLHlCQUF5QjtJQUNuRztHQUNGLEdBQUcsUUFBTyxvQkFBbUIsS0FBSyxnQkFBZ0IsT0FBTyxXQUFXLEdBQUcsS0FBSyxDQUFDO0VBQy9FLENBQUM7Q0FDSDtDQUNBLE1BQU0sTUFBTTtFQUNWLE1BQU0sT0FBTyxNQUFNLE1BQU0sSUFBSTtFQUU3QixLQUFLLFlBQVksS0FBSztFQUN0QixPQUFPO0NBQ1Q7O0NBR0EsT0FBTztFQUNMLE9BQU8sS0FBSyxVQUFVLFNBQVM7Q0FDakM7Q0FDQSxPQUFPLFFBQVE7RUFDYixJQUFJLE9BQU8sTUFBTSxPQUFPLE1BQU07RUFHOUIsS0FBSyxZQUFZLEtBQUs7RUFDdEIsSUFBSSxPQUFPLFdBRVQsS0FBSyxZQUFZLEtBQUssWUFFdEIsS0FBSyxVQUFVLE9BQU8sT0FBTyxTQUFTLElBQUksT0FBTztFQUNuRCxPQUFPO0NBQ1Q7Q0FDQSxHQUFHLFFBQVE7RUFFVCxJQUFJLE9BQU8sS0FBSyxNQUFNO0VBQ3RCLElBQUksQ0FBQyxTQUFTLE1BQU0sR0FBRyxNQUFNLElBQUksVUFBVSw2REFBNkQsV0FBVyxNQUFNLENBQUM7RUFHMUgsS0FBSyxZQUFZO0VBQ2pCLEtBQUssT0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFHLEtBQUssTUFBTSxFQUN2QyxPQUFPLE9BQ1QsQ0FBQztFQUNELE9BQU87Q0FDVDtDQUNBLE9BQU8sUUFBUSxVQUFVLE1BQU0sUUFBUTtFQUNyQyxPQUFPLEtBQUssS0FBSztHQUNmO0dBQ0EsTUFBTTtHQUNOLFdBQVc7R0FDWCxRQUFRLEVBQ04sT0FDRjtHQUNBLFlBQVk7R0FDWixLQUFLLE9BQU87SUFDVixPQUFPLE1BQU0sV0FBVyxLQUFLLFFBQVEsTUFBTTtHQUM3QztFQUNGLENBQUM7Q0FDSDtDQUNBLElBQUksS0FBSyxTQUFTO0VBQ2hCLFVBQVUsV0FBVyxNQUFNO0VBQzNCLE9BQU8sS0FBSyxLQUFLO0dBQ2Y7R0FDQSxNQUFNO0dBQ04sV0FBVztHQUNYLFFBQVEsRUFDTixJQUNGO0dBQ0EsWUFBWTtHQUVaLEtBQUssT0FBTztJQUNWLE9BQU8sTUFBTSxVQUFVLEtBQUssUUFBUSxHQUFHO0dBQ3pDO0VBQ0YsQ0FBQztDQUNIO0NBQ0EsSUFBSSxLQUFLLFNBQVM7RUFDaEIsVUFBVSxXQUFXLE1BQU07RUFDM0IsT0FBTyxLQUFLLEtBQUs7R0FDZjtHQUNBLE1BQU07R0FDTixXQUFXO0dBQ1gsUUFBUSxFQUNOLElBQ0Y7R0FDQSxZQUFZO0dBQ1osS0FBSyxPQUFPO0lBQ1YsT0FBTyxNQUFNLFVBQVUsS0FBSyxRQUFRLEdBQUc7R0FDekM7RUFDRixDQUFDO0NBQ0g7Q0FDQSxTQUFTO0VBQ1AsT0FBTyxLQUFLLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEtBQUssYUFBYTtHQUV6RCxJQUFJLEtBQUssV0FBVyxHQUFHLEdBQUcsT0FBTztHQUNqQyxPQUFPLFlBQVksT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxRQUFRO0VBQ25ELENBQUM7Q0FDSDtDQUNBLFFBQVEsVUFBVTtFQUNoQixJQUFJLFNBQVMsQ0FBQyxZQUFXLE1BQUssQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLE1BQU0sQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDO0VBQ2xFLE9BQU8sS0FBSyxXQUFVLFdBQVUsVUFBVSxPQUFPLE9BQU8sT0FBTyxNQUFNLElBQUksTUFBTTtDQUNqRjtDQUNBLFNBQVMsU0FBUztFQUNoQixNQUFNLFFBQVEsVUFBVSxLQUFLLFFBQVEsT0FBTyxJQUFJLEtBQUEsQ0FBTSxNQUFNO0VBQzVELE1BQU0sT0FBTyxNQUFNLFNBQVMsT0FBTztFQUNuQyxJQUFJLEtBQUssV0FBVztHQUNsQixJQUFJO0dBQ0osSUFBSSxlQUFlO0dBQ25CLEtBQUssZ0JBQWdCLGlCQUFpQixRQUFRLGNBQWMsT0FDMUQsZUFBZSxPQUFPLE9BQU8sQ0FBQyxHQUFHLGNBQWM7SUFDN0MsUUFBUSxhQUFhO0lBQ3JCLE9BQU8sYUFBYSxNQUFNO0dBQzVCLENBQUM7R0FFSCxLQUFLLFlBQVksS0FBSyxVQUFVLFNBQVMsWUFBWTtFQUN2RDtFQUNBLE9BQU87Q0FDVDtBQUNGO0FBQ0EsU0FBUyxZQUFZLFlBQVk7QUFHakMsU0FBUyxTQUFTLFNBQVM7Q0FDekIsT0FBTyxJQUFJLFlBQVksT0FBTztBQUNoQztBQUNBLElBQU0sY0FBTixjQUEwQixPQUFPO0NBQy9CLFlBQVksU0FBUztFQUNuQixNQUFNO0dBQ0osTUFBTTtHQUNOLE1BQU0sRUFDSixPQUFPLFFBQ1Q7R0FDQSxNQUFNLEdBQUc7SUFDUCxNQUFNLFFBQVEsS0FBSyxLQUFLO0lBQ3hCLE9BQU8sTUFBTSxRQUFRLENBQUMsS0FBSyxFQUFFLFdBQVcsTUFBTTtHQUNoRDtFQUNGLENBQUM7RUFDRCxLQUFLLG1CQUFtQjtHQUN0QixLQUFLLFVBQVUsTUFBTSxPQUFPO0VBQzlCLENBQUM7Q0FDSDtDQUNBLE1BQU0sWUFBWSxTQUFTO0VBQ3pCLE1BQU0sRUFDSixVQUNFLEtBQUs7RUFDVCxNQUFNLFFBQVEsTUFBTSxNQUFNLFlBQVksT0FBTztFQUM3QyxJQUFJLENBQUMsS0FBSyxXQUFXLEtBQUssR0FDeEIsT0FBTztFQUVULElBQUksWUFBWTtFQUNoQixNQUFNLFlBQVksTUFBTSxLQUFLLE1BQU0sUUFBUTtHQUN6QyxNQUFNLGNBQWMsS0FBSyxLQUFLLE1BQU0sTUFBTSxPQUFPLE9BQU8sQ0FBQyxHQUFHLFNBQVM7SUFDbkUsTUFBTSxHQUFHLFFBQVEsUUFBUSxHQUFHLEdBQUcsSUFBSTtJQUNuQyxRQUFRO0lBQ1IsZUFBZSxNQUFNO0lBQ3JCLE9BQU8sTUFBTTtJQUNiLE9BQU87R0FDVCxDQUFDLENBQUM7R0FDRixJQUFJLGdCQUFnQixNQUFNLE1BQU0sWUFBWTtHQUM1QyxPQUFPO0VBQ1QsQ0FBQztFQUNELE9BQU8sWUFBWSxZQUFZO0NBQ2pDO0NBQ0EsVUFBVSxRQUFRLFVBQVUsQ0FBQyxHQUFHLE9BQU8sTUFBTTtFQUMzQyxJQUFJLFlBQVksS0FBSyxLQUFLO0VBQzFCLE1BQU0sVUFBVSxRQUFRLFNBQVMsUUFBUSxhQUFhLFVBQVU7R0FDOUQsSUFBSTtHQUVKLElBQUksQ0FBQyxLQUFLLFdBQVcsS0FBSyxHQUFHO0lBQzNCLEtBQUssYUFBYSxLQUFLO0lBQ3ZCO0dBQ0Y7R0FDQSxJQUFJLFFBQVEsQ0FBQztHQUNiLEtBQUssSUFBSSxDQUFDLE9BQU8sZUFBZSxVQUFVLFFBQVEsR0FBRztJQUNuRCxJQUFJO0lBQ0osTUFBTSxTQUFTLFdBQVcsYUFBYTtLQUNyQztLQUNBO0tBQ0EsUUFBUTtLQUNSLFlBQVksUUFBUTtLQUNwQixpQkFBaUIsd0JBQXdCLFFBQVEsa0JBQWtCLE9BQU8sd0JBQXdCO0lBQ3BHLENBQUM7R0FDSDtHQUNBLEtBQUssU0FBUztJQUNaO0lBQ0E7SUFDQSxnQkFBZ0IseUJBQXlCLFFBQVEsa0JBQWtCLE9BQU8seUJBQXlCO0lBQ25HO0dBQ0YsR0FBRyxRQUFPLG9CQUFtQixLQUFLLGdCQUFnQixPQUFPLFdBQVcsR0FBRyxLQUFLLENBQUM7RUFDL0UsQ0FBQztDQUNIO0NBQ0EsU0FBUyxTQUFTO0VBQ2hCLE1BQU0sUUFBUSxVQUFVLEtBQUssUUFBUSxPQUFPLElBQUksS0FBQSxDQUFNLE1BQU07RUFDNUQsTUFBTSxPQUFPLE1BQU0sU0FBUyxPQUFPO0VBQ25DLEtBQUssWUFBWSxLQUFLLEtBQUssTUFBTSxLQUFLLFFBQVEsVUFBVTtHQUN0RCxJQUFJO0dBQ0osSUFBSSxlQUFlO0dBQ25CLEtBQUssZ0JBQWdCLGlCQUFpQixRQUFRLGNBQWMsT0FDMUQsZUFBZSxPQUFPLE9BQU8sQ0FBQyxHQUFHLGNBQWM7SUFDN0MsUUFBUSxhQUFhO0lBQ3JCLE9BQU8sYUFBYSxNQUFNO0dBQzVCLENBQUM7R0FFSCxPQUFPLE9BQU8sU0FBUyxZQUFZO0VBQ3JDLENBQUM7RUFDRCxPQUFPO0NBQ1Q7QUFDRjtBQUNBLFNBQVMsWUFBWSxZQUFZO0FBRWpDLFNBQVMsT0FBTyxTQUFTO0NBQ3ZCLE9BQU8sSUFBSSxLQUFLLE9BQU87QUFDekI7QUFDQSxTQUFTLHFCQUFxQixJQUFJO0NBQ2hDLElBQUk7RUFDRixPQUFPLEdBQUc7Q0FDWixTQUFTLEtBQUs7RUFDWixJQUFJLGdCQUFnQixRQUFRLEdBQUcsR0FBRyxPQUFPLFFBQVEsT0FBTyxHQUFHO0VBQzNELE1BQU07Q0FDUjtBQUNGO0FBQ0EsSUFBTSxPQUFOLE1BQU0sS0FBSztDQUNULFlBQVksU0FBUztFQUNuQixLQUFLLE9BQU87RUFDWixLQUFLLGtCQUFrQjtFQUN2QixLQUFLLE9BQU8sS0FBSztFQUNqQixLQUFLLFlBQVksT0FBTyxVQUFVLENBQUMsTUFBTTtHQUN2QyxJQUFJLFNBQVMsS0FBSyxRQUFRLE9BQU8sT0FBTztHQUN4QyxJQUFJLENBQUMsU0FBUyxNQUFNLEdBQUcsTUFBTSxJQUFJLFVBQVUsNkNBQTZDO0dBQ3hGLElBQUksS0FBSyxLQUFLLFVBQVUsU0FBUyxPQUFPLFNBQVM7R0FDakQsT0FBTyxPQUFPLFFBQVEsT0FBTztFQUMvQjtFQUNBLEtBQUssVUFBVTtFQUNmLEtBQUssT0FBTztHQUNWLE1BQU0sS0FBQTtHQUNOLFVBQVU7RUFDWjtDQUNGO0NBQ0EsTUFBTSxNQUFNO0VBQ1YsTUFBTSxPQUFPLElBQUksS0FBSyxLQUFLLE9BQU87RUFDbEMsS0FBSyxPQUFPLE9BQU8sT0FBTyxDQUFDLEdBQUcsS0FBSyxNQUFNLElBQUk7RUFDN0MsT0FBTztDQUNUO0NBQ0EsWUFBWSxVQUFVO0VBSXBCLE9BSGEsS0FBSyxNQUFNLEVBQ3RCLFNBQ0YsQ0FDVTtDQUNaO0NBQ0EsV0FBVztFQUNULE9BQU8sS0FBSyxZQUFZLElBQUk7Q0FDOUI7Q0FDQSxRQUFRLFNBQVM7RUFDZixPQUFPLEtBQUssU0FBUyxRQUFRLE9BQU8sT0FBTztDQUM3QztDQUNBLEtBQUssT0FBTyxTQUFTO0VBQ25CLE9BQU8sS0FBSyxTQUFTLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxPQUFPLE9BQU87Q0FDMUQ7Q0FDQSxhQUFhLFFBQVE7RUFDbkIsSUFBSSxFQUNGLEtBQ0EsT0FDQSxRQUNBLFlBQ0U7RUFDSixJQUFJLFFBQVEsT0FBTyxTQUFTLE9BQU8sUUFBUTtFQUMzQyxPQUFPLEtBQUssU0FBUyxPQUFPLE9BQU8sT0FBTyxDQUFDLEdBQUcsU0FBUztHQUNyRDtHQUNBO0VBQ0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLE1BQU07Q0FDekI7Q0FDQSxTQUFTLE9BQU8sU0FBUztFQUN2QixPQUFPLDJCQUEyQixLQUFLLFNBQVMsT0FBTyxPQUFPLENBQUMsQ0FBQyxTQUFTLE9BQU8sT0FBTyxDQUFDO0NBQzFGO0NBQ0EsYUFBYSxPQUFPLFNBQVM7RUFDM0IsT0FBTyxLQUFLLFNBQVMsT0FBTyxPQUFPLENBQUMsQ0FBQyxhQUFhLE9BQU8sT0FBTztDQUNsRTtDQUNBLFdBQVcsTUFBTSxPQUFPLFNBQVM7RUFDL0IsT0FBTywyQkFBMkIsS0FBSyxTQUFTLE9BQU8sT0FBTyxDQUFDLENBQUMsV0FBVyxNQUFNLE9BQU8sT0FBTyxDQUFDO0NBQ2xHO0NBQ0EsZUFBZSxNQUFNLE9BQU8sU0FBUztFQUNuQyxPQUFPLEtBQUssU0FBUyxPQUFPLE9BQU8sQ0FBQyxDQUFDLGVBQWUsTUFBTSxPQUFPLE9BQU87Q0FDMUU7Q0FDQSxRQUFRLE9BQU8sU0FBUztFQUN0QixJQUFJO0dBQ0YsT0FBTyxLQUFLLFNBQVMsT0FBTyxPQUFPLENBQUMsQ0FBQyxRQUFRLE9BQU8sT0FBTztFQUM3RCxTQUFTLEtBQUs7R0FDWixJQUFJLGdCQUFnQixRQUFRLEdBQUcsR0FDN0IsT0FBTyxRQUFRLFFBQVEsS0FBSztHQUU5QixNQUFNO0VBQ1I7Q0FDRjtDQUNBLFlBQVksT0FBTyxTQUFTO0VBQzFCLE9BQU8sS0FBSyxTQUFTLE9BQU8sT0FBTyxDQUFDLENBQUMsWUFBWSxPQUFPLE9BQU87Q0FDakU7Q0FDQSxTQUFTLFNBQVM7RUFDaEIsT0FBTyxVQUFVLEtBQUssUUFBUSxPQUFPLENBQUMsQ0FBQyxTQUFTLE9BQU8sSUFBSTtHQUN6RCxNQUFNO0dBQ04sTUFBTSxLQUFLLEtBQUs7R0FDaEIsT0FBTyxLQUFBO0VBQ1Q7Q0FDRjtDQUNBLEtBQUssR0FBRyxNQUFNO0VBQ1osSUFBSSxLQUFLLFdBQVcsR0FBRyxPQUFPLEtBQUssS0FBSztFQUN4QyxJQUFJLE9BQU8sS0FBSyxNQUFNO0VBQ3RCLEtBQUssS0FBSyxPQUFPLE9BQU8sT0FBTyxLQUFLLEtBQUssUUFBUSxDQUFDLEdBQUcsS0FBSyxFQUFFO0VBQzVELE9BQU87Q0FDVDtDQUNBLEtBQUssZUFBZTtFQUNsQixNQUFNLFNBQVM7RUFzQmYsT0FBTztHQXBCTCxTQUFTO0dBQ1QsUUFBUTtHQUNSLE1BQU0sU0FBUyxPQUFPO0lBQ3BCLElBQUk7S0FJRixPQUFPLEVBQ0wsT0FBTyxNQUpZLE9BQU8sU0FBUyxPQUFPLEVBQzFDLFlBQVksTUFDZCxDQUFDLEVBR0Q7SUFDRixTQUFTLEtBQUs7S0FDWixJQUFJLGdCQUFnQixRQUFRLEdBQUcsR0FDN0IsT0FBTyxFQUNMLFFBQVEsMEJBQTBCLEdBQUcsRUFDdkM7S0FFRixNQUFNO0lBQ1I7R0FDRjtFQUVZO0NBQ2hCO0FBQ0Y7QUFFQSxTQUFTLFVBQVUsUUFBUTtDQUN6QixPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsU0FBUSxTQUFRO0VBRWxDLE9BQU8sS0FBSyxPQUFPLEtBQUssQ0FBQyxDQUFDLFNBQVEsV0FBVTtHQUUxQyxPQUFPLEtBQUssQ0FBQyxVQUFVLE9BQU8sS0FBSyxDQUFDO0VBQ3RDLENBQUM7Q0FDSCxDQUFDO0FBQ0g7QUFFQSxTQUFTLFVBQVUsWUFBWSxNQUFNLElBQUk7Q0FDdkMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLFdBQVcsU0FBUyxHQUFHLE1BQU0sSUFBSSxVQUFVLG9EQUFvRDtDQUM1SCxJQUFJLE9BQU8sU0FBUyxVQUFVLE1BQU0sSUFBSSxVQUFVLGdDQUFnQztDQUNsRixJQUFJLE9BQU8sT0FBTyxZQUFZLE1BQU0sSUFBSSxVQUFVLGtDQUFrQztDQUNwRixXQUFXLFVBQVUsUUFBUTtBQUMvQiIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzXX0=