import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/publicRoutes.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=2ae0ea78";
import { Navigate, Route, Routes } from "/node_modules/.vite/deps/react-router.js?v=10fd912d";
import Login from "/src/pages/public/Login/index.tsx";
import Register from "/src/pages/public/Register/index.tsx";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/publicRoutes.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2ae0ea78";
export function PublicRoutes() {
	const $ = _c(5);
	if ($[0] !== "bbee54a8fe09ace0fec559d679ed733df2e1559c0c28013e6e2230636abcc007") {
		for (let $i = 0; $i < 5; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "bbee54a8fe09ace0fec559d679ed733df2e1559c0c28013e6e2230636abcc007";
	}
	let t0;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ _jsxDEV(Route, {
			path: "/",
			element: /* @__PURE__ */ _jsxDEV(Navigate, {
				to: "/login",
				replace: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 35
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 10
		}, this);
		$[1] = t0;
	} else {
		t0 = $[1];
	}
	let t1;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = /* @__PURE__ */ _jsxDEV(Route, {
			path: "login",
			element: /* @__PURE__ */ _jsxDEV(Login, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 22,
				columnNumber: 39
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 10
		}, this);
		$[2] = t1;
	} else {
		t1 = $[2];
	}
	let t2;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = /* @__PURE__ */ _jsxDEV(Route, {
			path: "register",
			element: /* @__PURE__ */ _jsxDEV(Register, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 42
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 29,
			columnNumber: 10
		}, this);
		$[3] = t2;
	} else {
		t2 = $[3];
	}
	let t3;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = /* @__PURE__ */ _jsxDEV(Routes, { children: [
			t0,
			t1,
			t2,
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "*",
				element: /* @__PURE__ */ _jsxDEV(Navigate, {
					to: "/login",
					replace: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 55
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 30
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 36,
			columnNumber: 10
		}, this);
		$[4] = t3;
	} else {
		t3 = $[4];
	}
	return t3;
}
_c2 = PublicRoutes;
var _c2;
$RefreshReg$(_c2, "PublicRoutes");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/publicRoutes.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/publicRoutes.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/publicRoutes.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/publicRoutes.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLFVBQVVDLE9BQU9DLGNBQWM7QUFDeEMsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxjQUFjOzs7QUFFckIsT0FBTyxTQUFBQyxlQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBTCxFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFHREMsS0FBQSx3QkFBQyxPQUFEO0dBQVk7R0FBYSxpQ0FBQyxVQUFEO0lBQWE7SUFBUztHQUFPOzs7OztFQUFHOzs7OztFQUFJTCxFQUFBLEtBQUFLO0NBQUE7RUFBQUEsS0FBQUwsRUFBQTtDQUFBO0NBQUEsSUFBQU07Q0FBQSxJQUFBTixFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFDN0RFLEtBQUEsd0JBQUMsT0FBRDtHQUFZO0dBQWlCLGlDQUFDLE9BQUQsQ0FBTTs7Ozs7RUFBRzs7Ozs7RUFBSU4sRUFBQSxLQUFBTTtDQUFBO0VBQUFBLEtBQUFOLEVBQUE7Q0FBQTtDQUFBLElBQUFPO0NBQUEsSUFBQVAsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBQzFDRyxLQUFBLHdCQUFDLE9BQUQ7R0FBWTtHQUFvQixpQ0FBQyxVQUFELENBQVM7Ozs7O0VBQUc7Ozs7O0VBQUlQLEVBQUEsS0FBQU87Q0FBQTtFQUFBQSxLQUFBUCxFQUFBO0NBQUE7Q0FBQSxJQUFBUTtDQUFBLElBQUFSLEVBQUEsT0FBQUcsT0FBQUMsSUFBQTtFQUhsREksS0FBQSx3QkFBQyxRQUFEO0dBQ0VIO0dBQ0FDO0dBQ0FDO0dBQ0Esd0JBQUMsT0FBRDtJQUFZO0lBQWEsaUNBQUMsVUFBRDtLQUFhO0tBQVM7SUFBTzs7Ozs7R0FBRzs7Ozs7RUFKcEQ7Ozs7O0VBS0VQLEVBQUEsS0FBQVE7Q0FBQTtFQUFBQSxLQUFBUixFQUFBO0NBQUE7Q0FBQSxPQUxUUTtBQUtTIiwibmFtZXMiOlsiTmF2aWdhdGUiLCJSb3V0ZSIsIlJvdXRlcyIsIkxvZ2luIiwiUmVnaXN0ZXIiLCJQdWJsaWNSb3V0ZXMiLCIkIiwiX2MiLCIkaSIsIlN5bWJvbCIsImZvciIsInQwIiwidDEiLCJ0MiIsInQzIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInB1YmxpY1JvdXRlcy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmF2aWdhdGUsIFJvdXRlLCBSb3V0ZXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyXCI7XG5pbXBvcnQgTG9naW4gZnJvbSBcIi4uL3BhZ2VzL3B1YmxpYy9Mb2dpblwiO1xuaW1wb3J0IFJlZ2lzdGVyIGZyb20gXCIuLi9wYWdlcy9wdWJsaWMvUmVnaXN0ZXJcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIFB1YmxpY1JvdXRlcygpIHtcbiAgcmV0dXJuIChcbiAgICA8Um91dGVzPlxuICAgICAgPFJvdXRlIHBhdGg9XCIvXCIgZWxlbWVudD17PE5hdmlnYXRlIHRvPVwiL2xvZ2luXCIgcmVwbGFjZSAvPn0gLz5cbiAgICAgIDxSb3V0ZSBwYXRoPVwibG9naW5cIiBlbGVtZW50PXs8TG9naW4gLz59IC8+XG4gICAgICA8Um91dGUgcGF0aD1cInJlZ2lzdGVyXCIgZWxlbWVudD17PFJlZ2lzdGVyIC8+fSAvPlxuICAgICAgPFJvdXRlIHBhdGg9XCIqXCIgZWxlbWVudD17PE5hdmlnYXRlIHRvPVwiL2xvZ2luXCIgcmVwbGFjZSAvPn0gLz5cbiAgICA8L1JvdXRlcz5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvd2FsbGEvRGVza3RvcC9Qcm9qZXRvcy1wZXNzb2Fpcy9wcm92YS10ZWNuaWNhL2Zyb250LW1pbmktdGFzay1tYW5hZ2VyL3NyYy9yb3V0ZXMvcHVibGljUm91dGVzLnRzeCJ9