import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/tasks/TaskFilters.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=2ae0ea78";
import { priorityLabels, statusLabels } from "/src/components/tasks/labels.ts";
import { Button, Field, FilterGrid, Toolbar, ToolbarHeader } from "/src/components/tasks/styles.ts";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskFilters.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2ae0ea78";
export function TaskFilters(t0) {
	const $ = _c(41);
	if ($[0] !== "3aa94d14652260114fb0079245dbad57f37daa3626ae4b36d7cfd939cedbc0d6") {
		for (let $i = 0; $i < 41; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3aa94d14652260114fb0079245dbad57f37daa3626ae4b36d7cfd939cedbc0d6";
	}
	const { filters, users, onChange, onCreate, isLoadingUsers } = t0;
	let t1;
	if ($[1] !== filters || $[2] !== onChange) {
		t1 = function setFilter(key, value) {
			onChange({
				...filters,
				[key]: value || undefined
			});
		};
		$[1] = filters;
		$[2] = onChange;
		$[3] = t1;
	} else {
		t1 = $[3];
	}
	const setFilter = t1;
	let t2;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", { children: "Tarefas" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 45,
			columnNumber: 15
		}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Organize demandas por status, prioridade e responsavel." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 45,
			columnNumber: 31
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 45,
			columnNumber: 10
		}, this);
		$[4] = t2;
	} else {
		t2 = $[4];
	}
	let t3;
	if ($[5] !== onCreate) {
		t3 = /* @__PURE__ */ _jsxDEV(ToolbarHeader, { children: [t2, /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			onClick: onCreate,
			children: "Criar tarefa"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 52,
			columnNumber: 29
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 52,
			columnNumber: 10
		}, this);
		$[5] = onCreate;
		$[6] = t3;
	} else {
		t3 = $[6];
	}
	const t4 = filters.status ?? "";
	let t5;
	if ($[7] !== setFilter) {
		t5 = (event) => setFilter("status", event.target.value);
		$[7] = setFilter;
		$[8] = t5;
	} else {
		t5 = $[8];
	}
	let t6;
	let t7;
	if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
		t6 = /* @__PURE__ */ _jsxDEV("option", {
			value: "",
			children: "Todos"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 70,
			columnNumber: 10
		}, this);
		t7 = Object.entries(statusLabels).map(_temp);
		$[9] = t6;
		$[10] = t7;
	} else {
		t6 = $[9];
		t7 = $[10];
	}
	let t8;
	if ($[11] !== t4 || $[12] !== t5) {
		t8 = /* @__PURE__ */ _jsxDEV(Field, { children: ["Status", /* @__PURE__ */ _jsxDEV("select", {
			value: t4,
			onChange: t5,
			children: [t6, t7]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 80,
			columnNumber: 23
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 80,
			columnNumber: 10
		}, this);
		$[11] = t4;
		$[12] = t5;
		$[13] = t8;
	} else {
		t8 = $[13];
	}
	const t9 = filters.responsibleId ?? "";
	let t10;
	if ($[14] !== setFilter) {
		t10 = (event_0) => setFilter("responsibleId", event_0.target.value);
		$[14] = setFilter;
		$[15] = t10;
	} else {
		t10 = $[15];
	}
	let t11;
	if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
		t11 = /* @__PURE__ */ _jsxDEV("option", {
			value: "",
			children: "Todos"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 98,
			columnNumber: 11
		}, this);
		$[16] = t11;
	} else {
		t11 = $[16];
	}
	let t12;
	if ($[17] !== users) {
		t12 = users.map(_temp2);
		$[17] = users;
		$[18] = t12;
	} else {
		t12 = $[18];
	}
	let t13;
	if ($[19] !== isLoadingUsers || $[20] !== t10 || $[21] !== t12 || $[22] !== t9) {
		t13 = /* @__PURE__ */ _jsxDEV(Field, { children: ["Responsavel", /* @__PURE__ */ _jsxDEV("select", {
			value: t9,
			onChange: t10,
			disabled: isLoadingUsers,
			children: [t11, t12]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 113,
			columnNumber: 29
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 113,
			columnNumber: 11
		}, this);
		$[19] = isLoadingUsers;
		$[20] = t10;
		$[21] = t12;
		$[22] = t9;
		$[23] = t13;
	} else {
		t13 = $[23];
	}
	const t14 = filters.priority ?? "";
	let t15;
	if ($[24] !== setFilter) {
		t15 = (event_1) => setFilter("priority", event_1.target.value);
		$[24] = setFilter;
		$[25] = t15;
	} else {
		t15 = $[25];
	}
	let t16;
	let t17;
	if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
		t16 = /* @__PURE__ */ _jsxDEV("option", {
			value: "",
			children: "Todas"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 134,
			columnNumber: 11
		}, this);
		t17 = Object.entries(priorityLabels).map(_temp3);
		$[26] = t16;
		$[27] = t17;
	} else {
		t16 = $[26];
		t17 = $[27];
	}
	let t18;
	if ($[28] !== t14 || $[29] !== t15) {
		t18 = /* @__PURE__ */ _jsxDEV(Field, { children: ["Prioridade", /* @__PURE__ */ _jsxDEV("select", {
			value: t14,
			onChange: t15,
			children: [t16, t17]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 144,
			columnNumber: 28
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 144,
			columnNumber: 11
		}, this);
		$[28] = t14;
		$[29] = t15;
		$[30] = t18;
	} else {
		t18 = $[30];
	}
	let t19;
	if ($[31] !== onChange) {
		t19 = /* @__PURE__ */ _jsxDEV(Field, { children: ["Acoes", /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			$variant: "ghost",
			"aria-label": "Limpar filtros",
			onClick: () => onChange({}),
			children: "Limpar filtros"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 153,
			columnNumber: 23
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 153,
			columnNumber: 11
		}, this);
		$[31] = onChange;
		$[32] = t19;
	} else {
		t19 = $[32];
	}
	let t20;
	if ($[33] !== t13 || $[34] !== t18 || $[35] !== t19 || $[36] !== t8) {
		t20 = /* @__PURE__ */ _jsxDEV(FilterGrid, { children: [
			t8,
			t13,
			t18,
			t19
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 161,
			columnNumber: 11
		}, this);
		$[33] = t13;
		$[34] = t18;
		$[35] = t19;
		$[36] = t8;
		$[37] = t20;
	} else {
		t20 = $[37];
	}
	let t21;
	if ($[38] !== t20 || $[39] !== t3) {
		t21 = /* @__PURE__ */ _jsxDEV(Toolbar, { children: [t3, t20] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 172,
			columnNumber: 11
		}, this);
		$[38] = t20;
		$[39] = t3;
		$[40] = t21;
	} else {
		t21 = $[40];
	}
	return t21;
}
_c2 = TaskFilters;
function _temp3(t0) {
	const [priority, label_0] = t0;
	return /* @__PURE__ */ _jsxDEV("option", {
		value: priority,
		children: label_0
	}, priority, false, {
		fileName: _jsxFileName,
		lineNumber: 183,
		columnNumber: 10
	}, this);
}
function _temp2(user) {
	return /* @__PURE__ */ _jsxDEV("option", {
		value: user.id,
		children: user.name
	}, user.id, false, {
		fileName: _jsxFileName,
		lineNumber: 186,
		columnNumber: 10
	}, this);
}
function _temp(t0) {
	const [status, label] = t0;
	return /* @__PURE__ */ _jsxDEV("option", {
		value: status,
		children: label
	}, status, false, {
		fileName: _jsxFileName,
		lineNumber: 190,
		columnNumber: 10
	}, this);
}
var _c2;
$RefreshReg$(_c2, "TaskFilters");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/tasks/TaskFilters.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskFilters.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskFilters.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskFilters.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUVBLFNBQVNBLGdCQUFnQkMsb0JBQW9CO0FBQzdDLFNBQVNDLFFBQVFDLE9BQU9DLFlBQVlDLFNBQVNDLHFCQUFxQjs7O0FBVWxFLE9BQU8sU0FBQUMsWUFBQUMsSUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLElBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFxQixRQUFBSyxTQUFBQyxPQUFBQyxVQUFBQyxVQUFBQyxtQkFBQVY7Q0FBd0UsSUFBQVc7Q0FBQSxJQUFBVixFQUFBLE9BQUFLLFdBQUFMLEVBQUEsT0FBQU8sVUFBQTtFQUNsR0csS0FBQSxTQUFBQyxVQUFBQyxLQUFBQyxPQUFBO0dBQ0VOLFNBQVM7SUFBQSxHQUNKRjtLQUNGTyxNQUFNQyxTQUFBQztHQUNULENBQUM7RUFBQztFQUNIZCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU87RUFBQVAsRUFBQSxLQUFBVTtDQUFBO0VBQUFBLEtBQUFWLEVBQUE7Q0FBQTtDQUxELE1BQUFXLFlBQUFEO0NBS0MsSUFBQUs7Q0FBQSxJQUFBZixFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFLS1csS0FBQSw0Q0FDRSwwQ0FBSSxVQUFZOzs7O1lBQ2hCLHlDQUFHLDBEQUEyRDs7OztVQUMxRDs7Ozs7RUFBQWYsRUFBQSxLQUFBZTtDQUFBO0VBQUFBLEtBQUFmLEVBQUE7Q0FBQTtDQUFBLElBQUFnQjtDQUFBLElBQUFoQixFQUFBLE9BQUFRLFVBQUE7RUFKUlEsS0FBQSx3QkFBQyxlQUFELGFBQ0VELElBS0Esd0JBQUMsUUFBRDtHQUFhO0dBQWtCUDthQUFVO0VBQWxDOzs7O1VBTks7Ozs7O0VBU0VSLEVBQUEsS0FBQVE7RUFBQVIsRUFBQSxLQUFBZ0I7Q0FBQTtFQUFBQSxLQUFBaEIsRUFBQTtDQUFBO0NBS0csTUFBQWlCLEtBQUFaLFFBQU9hLFVBQVA7Q0FBb0IsSUFBQUM7Q0FBQSxJQUFBbkIsRUFBQSxPQUFBVyxXQUFBO0VBQVlRLE1BQUFDLFVBQVdULFVBQVUsVUFBVVMsTUFBS0MsT0FBT1IsS0FBeUI7RUFBQ2IsRUFBQSxLQUFBVztFQUFBWCxFQUFBLEtBQUFtQjtDQUFBO0VBQUFBLEtBQUFuQixFQUFBO0NBQUE7Q0FBQSxJQUFBc0I7Q0FBQSxJQUFBQztDQUFBLElBQUF2QixFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFDbEhrQixLQUFBO0dBQWM7YUFBRztFQUFjOzs7OztFQUM5QkMsS0FBQUMsT0FBTUMsUUFBU2pDLFlBQVksQ0FBQyxDQUFBa0MsSUFBS0MsS0FJakM7RUFBQzNCLEVBQUEsS0FBQXNCO0VBQUF0QixFQUFBLE1BQUF1QjtDQUFBO0VBQUFELEtBQUF0QixFQUFBO0VBQUF1QixLQUFBdkIsRUFBQTtDQUFBO0NBQUEsSUFBQTRCO0NBQUEsSUFBQTVCLEVBQUEsUUFBQWlCLE1BQUFqQixFQUFBLFFBQUFtQixJQUFBO0VBUk5TLEtBQUEsd0JBQUMsT0FBRCxhQUFPLFVBRUw7R0FBZSxPQUFBWDtHQUFnQyxVQUFBRTthQUEvQyxDQUNFRyxJQUNDQyxFQUtNOzs7OztVQVRMOzs7OztFQVVFdkIsRUFBQSxNQUFBaUI7RUFBQWpCLEVBQUEsTUFBQW1CO0VBQUFuQixFQUFBLE1BQUE0QjtDQUFBO0VBQUFBLEtBQUE1QixFQUFBO0NBQUE7Q0FLRyxNQUFBNkIsS0FBQXhCLFFBQU95QixpQkFBUDtDQUEyQixJQUFBQztDQUFBLElBQUEvQixFQUFBLFFBQUFXLFdBQUE7RUFDeEJvQixPQUFBQyxZQUFXckIsVUFBVSxpQkFBaUJTLFFBQUtDLE9BQU9SLEtBQU07RUFBQ2IsRUFBQSxNQUFBVztFQUFBWCxFQUFBLE1BQUErQjtDQUFBO0VBQUFBLE1BQUEvQixFQUFBO0NBQUE7Q0FBQSxJQUFBaUM7Q0FBQSxJQUFBakMsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBR25FNkIsTUFBQTtHQUFjO2FBQUc7RUFBYzs7Ozs7RUFBQWpDLEVBQUEsTUFBQWlDO0NBQUE7RUFBQUEsTUFBQWpDLEVBQUE7Q0FBQTtDQUFBLElBQUFrQztDQUFBLElBQUFsQyxFQUFBLFFBQUFNLE9BQUE7RUFDOUI0QixNQUFBNUIsTUFBS29CLElBQUtTLE1BSVY7RUFBQ25DLEVBQUEsTUFBQU07RUFBQU4sRUFBQSxNQUFBa0M7Q0FBQTtFQUFBQSxNQUFBbEMsRUFBQTtDQUFBO0NBQUEsSUFBQW9DO0NBQUEsSUFBQXBDLEVBQUEsUUFBQVMsa0JBQUFULEVBQUEsUUFBQStCLE9BQUEvQixFQUFBLFFBQUFrQyxPQUFBbEMsRUFBQSxRQUFBNkIsSUFBQTtFQVpOTyxNQUFBLHdCQUFDLE9BQUQsYUFBTyxlQUVMO0dBQ1MsT0FBQVA7R0FDRyxVQUFBRTtHQUNBdEI7YUFIWixDQUtFd0IsS0FDQ0MsR0FLTTs7Ozs7VUFiTDs7Ozs7RUFjRWxDLEVBQUEsTUFBQVM7RUFBQVQsRUFBQSxNQUFBK0I7RUFBQS9CLEVBQUEsTUFBQWtDO0VBQUFsQyxFQUFBLE1BQUE2QjtFQUFBN0IsRUFBQSxNQUFBb0M7Q0FBQTtFQUFBQSxNQUFBcEMsRUFBQTtDQUFBO0NBSVMsTUFBQXFDLE1BQUFoQyxRQUFPaUMsWUFBUDtDQUFzQixJQUFBQztDQUFBLElBQUF2QyxFQUFBLFFBQUFXLFdBQUE7RUFBWTRCLE9BQUFDLFlBQVc3QixVQUFVLFlBQVlTLFFBQUtDLE9BQU9SLEtBQTJCO0VBQUNiLEVBQUEsTUFBQVc7RUFBQVgsRUFBQSxNQUFBdUM7Q0FBQTtFQUFBQSxNQUFBdkMsRUFBQTtDQUFBO0NBQUEsSUFBQXlDO0NBQUEsSUFBQUM7Q0FBQSxJQUFBMUMsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBQ3hIcUMsTUFBQTtHQUFjO2FBQUc7RUFBYzs7Ozs7RUFDOUJDLE1BQUFsQixPQUFNQyxRQUFTbEMsY0FBYyxDQUFDLENBQUFtQyxJQUFLaUIsTUFJbkM7RUFBQzNDLEVBQUEsTUFBQXlDO0VBQUF6QyxFQUFBLE1BQUEwQztDQUFBO0VBQUFELE1BQUF6QyxFQUFBO0VBQUEwQyxNQUFBMUMsRUFBQTtDQUFBO0NBQUEsSUFBQTRDO0NBQUEsSUFBQTVDLEVBQUEsUUFBQXFDLE9BQUFyQyxFQUFBLFFBQUF1QyxLQUFBO0VBUk5LLE1BQUEsd0JBQUMsT0FBRCxhQUFPLGNBRUw7R0FBZSxPQUFBUDtHQUFrQyxVQUFBRTthQUFqRCxDQUNFRSxLQUNDQyxHQUtNOzs7OztVQVRMOzs7OztFQVVFMUMsRUFBQSxNQUFBcUM7RUFBQXJDLEVBQUEsTUFBQXVDO0VBQUF2QyxFQUFBLE1BQUE0QztDQUFBO0VBQUFBLE1BQUE1QyxFQUFBO0NBQUE7Q0FBQSxJQUFBNkM7Q0FBQSxJQUFBN0MsRUFBQSxRQUFBTyxVQUFBO0VBRVJzQyxNQUFBLHdCQUFDLE9BQUQsYUFBTyxTQUVMLHdCQUFDLFFBQUQ7R0FBYTtHQUFrQjtHQUFtQjtHQUEwQixlQUFNdEMsU0FBUyxDQUFDLENBQUM7YUFBRztFQUF6Rjs7OztVQUZIOzs7OztFQUtFUCxFQUFBLE1BQUFPO0VBQUFQLEVBQUEsTUFBQTZDO0NBQUE7RUFBQUEsTUFBQTdDLEVBQUE7Q0FBQTtDQUFBLElBQUE4QztDQUFBLElBQUE5QyxFQUFBLFFBQUFvQyxPQUFBcEMsRUFBQSxRQUFBNEMsT0FBQTVDLEVBQUEsUUFBQTZDLE9BQUE3QyxFQUFBLFFBQUE0QixJQUFBO0VBOUNWa0IsTUFBQSx3QkFBQyxZQUFEO0dBQ0VsQjtHQVlBUTtHQWdCQVE7R0FZQUM7RUF6Q1M7Ozs7O0VBK0NFN0MsRUFBQSxNQUFBb0M7RUFBQXBDLEVBQUEsTUFBQTRDO0VBQUE1QyxFQUFBLE1BQUE2QztFQUFBN0MsRUFBQSxNQUFBNEI7RUFBQTVCLEVBQUEsTUFBQThDO0NBQUE7RUFBQUEsTUFBQTlDLEVBQUE7Q0FBQTtDQUFBLElBQUErQztDQUFBLElBQUEvQyxFQUFBLFFBQUE4QyxPQUFBOUMsRUFBQSxRQUFBZ0IsSUFBQTtFQTNEZitCLE1BQUEsd0JBQUMsU0FBRCxhQUNFL0IsSUFXQThCLEdBWk07Ozs7O0VBNERFOUMsRUFBQSxNQUFBOEM7RUFBQTlDLEVBQUEsTUFBQWdCO0VBQUFoQixFQUFBLE1BQUErQztDQUFBO0VBQUFBLE1BQUEvQyxFQUFBO0NBQUE7Q0FBQSxPQTVEVitDO0FBNERVOztBQXJFUCxTQUFBSixPQUFBNUMsSUFBQTtDQXNEMEMsT0FBQXVDLFVBQUFVLFdBQUFqRDtDQUFpQixPQUNwRDtFQUE4QnVDO1lBQzNCVztDQUNNLEdBRklYOzs7O1FBRUo7QUFBQTtBQXpEaEIsU0FBQUgsT0FBQWUsTUFBQTtDQUFBLE9BMkNPO0VBQTZCLE9BQUFBLEtBQUlDO1lBQzlCRCxLQUFJRTtDQUNFLEdBRklGLEtBQUlDOzs7O1FBRVI7QUFBQTtBQTdDaEIsU0FBQXhCLE1BQUE1QixJQUFBO0NBMEJ3QyxPQUFBbUIsUUFBQStCLFNBQUFsRDtDQUFlLE9BQ2hEO0VBQTRCbUI7WUFDekIrQjtDQUNNLEdBRkkvQjs7OztRQUVKO0FBQUEiLCJuYW1lcyI6WyJwcmlvcml0eUxhYmVscyIsInN0YXR1c0xhYmVscyIsIkJ1dHRvbiIsIkZpZWxkIiwiRmlsdGVyR3JpZCIsIlRvb2xiYXIiLCJUb29sYmFySGVhZGVyIiwiVGFza0ZpbHRlcnMiLCJ0MCIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwiZmlsdGVycyIsInVzZXJzIiwib25DaGFuZ2UiLCJvbkNyZWF0ZSIsImlzTG9hZGluZ1VzZXJzIiwidDEiLCJzZXRGaWx0ZXIiLCJrZXkiLCJ2YWx1ZSIsInVuZGVmaW5lZCIsInQyIiwidDMiLCJ0NCIsInN0YXR1cyIsInQ1IiwiZXZlbnQiLCJ0YXJnZXQiLCJ0NiIsInQ3IiwiT2JqZWN0IiwiZW50cmllcyIsIm1hcCIsIl90ZW1wIiwidDgiLCJ0OSIsInJlc3BvbnNpYmxlSWQiLCJ0MTAiLCJldmVudF8wIiwidDExIiwidDEyIiwiX3RlbXAyIiwidDEzIiwidDE0IiwicHJpb3JpdHkiLCJ0MTUiLCJldmVudF8xIiwidDE2IiwidDE3IiwiX3RlbXAzIiwidDE4IiwidDE5IiwidDIwIiwidDIxIiwibGFiZWxfMCIsImxhYmVsIiwidXNlciIsImlkIiwibmFtZSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUYXNrRmlsdGVycy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBUYXNrRmlsdGVycyBhcyBUYXNrRmlsdGVyc0RhdGEsIFRhc2tQcmlvcml0eSwgVGFza1N0YXR1cyB9IGZyb20gXCIuLi8uLi9pbnRlcmZhY2VzL3Rhc2tzL3Rhc2tcIjtcbmltcG9ydCB0eXBlIHsgVXNlciB9IGZyb20gXCIuLi8uLi9pbnRlcmZhY2VzL3Rhc2tzL3VzZXJcIjtcbmltcG9ydCB7IHByaW9yaXR5TGFiZWxzLCBzdGF0dXNMYWJlbHMgfSBmcm9tIFwiLi9sYWJlbHNcIjtcbmltcG9ydCB7IEJ1dHRvbiwgRmllbGQsIEZpbHRlckdyaWQsIFRvb2xiYXIsIFRvb2xiYXJIZWFkZXIgfSBmcm9tIFwiLi9zdHlsZXNcIjtcblxudHlwZSBUYXNrRmlsdGVyc1Byb3BzID0ge1xuICBmaWx0ZXJzOiBUYXNrRmlsdGVyc0RhdGE7XG4gIHVzZXJzOiBVc2VyW107XG4gIG9uQ2hhbmdlOiAoZmlsdGVyczogVGFza0ZpbHRlcnNEYXRhKSA9PiB2b2lkO1xuICBvbkNyZWF0ZTogKCkgPT4gdm9pZDtcbiAgaXNMb2FkaW5nVXNlcnM/OiBib29sZWFuO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIFRhc2tGaWx0ZXJzKHsgZmlsdGVycywgdXNlcnMsIG9uQ2hhbmdlLCBvbkNyZWF0ZSwgaXNMb2FkaW5nVXNlcnMgfTogVGFza0ZpbHRlcnNQcm9wcykge1xuICBmdW5jdGlvbiBzZXRGaWx0ZXI8S2V5IGV4dGVuZHMga2V5b2YgVGFza0ZpbHRlcnNEYXRhPihrZXk6IEtleSwgdmFsdWU6IFRhc2tGaWx0ZXJzRGF0YVtLZXldIHwgXCJcIikge1xuICAgIG9uQ2hhbmdlKHtcbiAgICAgIC4uLmZpbHRlcnMsXG4gICAgICBba2V5XTogdmFsdWUgfHwgdW5kZWZpbmVkLFxuICAgIH0pO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8VG9vbGJhcj5cbiAgICAgIDxUb29sYmFySGVhZGVyPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMT5UYXJlZmFzPC9oMT5cbiAgICAgICAgICA8cD5Pcmdhbml6ZSBkZW1hbmRhcyBwb3Igc3RhdHVzLCBwcmlvcmlkYWRlIGUgcmVzcG9uc2F2ZWwuPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8QnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtvbkNyZWF0ZX0+XG4gICAgICAgICAgQ3JpYXIgdGFyZWZhXG4gICAgICAgIDwvQnV0dG9uPlxuICAgICAgPC9Ub29sYmFySGVhZGVyPlxuXG4gICAgICA8RmlsdGVyR3JpZD5cbiAgICAgICAgPEZpZWxkPlxuICAgICAgICAgIFN0YXR1c1xuICAgICAgICAgIDxzZWxlY3QgdmFsdWU9e2ZpbHRlcnMuc3RhdHVzID8/IFwiXCJ9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldEZpbHRlcihcInN0YXR1c1wiLCBldmVudC50YXJnZXQudmFsdWUgYXMgVGFza1N0YXR1cyB8IFwiXCIpfT5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5Ub2Rvczwvb3B0aW9uPlxuICAgICAgICAgICAge09iamVjdC5lbnRyaWVzKHN0YXR1c0xhYmVscykubWFwKChbc3RhdHVzLCBsYWJlbF0pID0+IChcbiAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3N0YXR1c30gdmFsdWU9e3N0YXR1c30+XG4gICAgICAgICAgICAgICAge2xhYmVsfVxuICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICA8L0ZpZWxkPlxuXG4gICAgICAgIDxGaWVsZD5cbiAgICAgICAgICBSZXNwb25zYXZlbFxuICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgIHZhbHVlPXtmaWx0ZXJzLnJlc3BvbnNpYmxlSWQgPz8gXCJcIn1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldEZpbHRlcihcInJlc3BvbnNpYmxlSWRcIiwgZXZlbnQudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmdVc2Vyc31cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+VG9kb3M8L29wdGlvbj5cbiAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcbiAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3VzZXIuaWR9IHZhbHVlPXt1c2VyLmlkfT5cbiAgICAgICAgICAgICAgICB7dXNlci5uYW1lfVxuICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICA8L0ZpZWxkPlxuXG4gICAgICAgIDxGaWVsZD5cbiAgICAgICAgICBQcmlvcmlkYWRlXG4gICAgICAgICAgPHNlbGVjdCB2YWx1ZT17ZmlsdGVycy5wcmlvcml0eSA/PyBcIlwifSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRGaWx0ZXIoXCJwcmlvcml0eVwiLCBldmVudC50YXJnZXQudmFsdWUgYXMgVGFza1ByaW9yaXR5IHwgXCJcIil9PlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlRvZGFzPC9vcHRpb24+XG4gICAgICAgICAgICB7T2JqZWN0LmVudHJpZXMocHJpb3JpdHlMYWJlbHMpLm1hcCgoW3ByaW9yaXR5LCBsYWJlbF0pID0+IChcbiAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3ByaW9yaXR5fSB2YWx1ZT17cHJpb3JpdHl9PlxuICAgICAgICAgICAgICAgIHtsYWJlbH1cbiAgICAgICAgICAgICAgPC9vcHRpb24+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgPC9GaWVsZD5cblxuICAgICAgICA8RmllbGQ+XG4gICAgICAgICAgQWNvZXNcbiAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJidXR0b25cIiAkdmFyaWFudD1cImdob3N0XCIgYXJpYS1sYWJlbD1cIkxpbXBhciBmaWx0cm9zXCIgb25DbGljaz17KCkgPT4gb25DaGFuZ2Uoe30pfT5cbiAgICAgICAgICAgIExpbXBhciBmaWx0cm9zXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIDwvRmllbGQ+XG4gICAgICA8L0ZpbHRlckdyaWQ+XG4gICAgPC9Ub29sYmFyPlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy93YWxsYS9EZXNrdG9wL1Byb2pldG9zLXBlc3NvYWlzL3Byb3ZhLXRlY25pY2EvZnJvbnQtbWluaS10YXNrLW1hbmFnZXIvc3JjL2NvbXBvbmVudHMvdGFza3MvVGFza0ZpbHRlcnMudHN4In0=