import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/tasks/TaskStates.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=2ae0ea78";
import { Button, StateBox } from "/src/components/tasks/styles.ts";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskStates.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2ae0ea78";
export function LoadingState(t0) {
	const $ = _c(3);
	if ($[0] !== "a8d1bb64412f93502f172da077d487d530e2b3a959931badd96132cbc8a73043") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "a8d1bb64412f93502f172da077d487d530e2b3a959931badd96132cbc8a73043";
	}
	const { message: t1 } = t0;
	const message = t1 === undefined ? "Carregando tarefas..." : t1;
	let t2;
	if ($[1] !== message) {
		t2 = /* @__PURE__ */ _jsxDEV(StateBox, { children: message }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 10
		}, this);
		$[1] = message;
		$[2] = t2;
	} else {
		t2 = $[2];
	}
	return t2;
}
_c2 = LoadingState;
export function ErrorState(t0) {
	const $ = _c(8);
	if ($[0] !== "a8d1bb64412f93502f172da077d487d530e2b3a959931badd96132cbc8a73043") {
		for (let $i = 0; $i < 8; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "a8d1bb64412f93502f172da077d487d530e2b3a959931badd96132cbc8a73043";
	}
	const { message: t1, onRetry } = t0;
	const message = t1 === undefined ? "Nao foi possivel carregar os dados." : t1;
	let t2;
	if ($[1] !== message) {
		t2 = /* @__PURE__ */ _jsxDEV("strong", { children: message }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 47,
			columnNumber: 10
		}, this);
		$[1] = message;
		$[2] = t2;
	} else {
		t2 = $[2];
	}
	let t3;
	if ($[3] !== onRetry) {
		t3 = onRetry ? /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			onClick: onRetry,
			children: "Tentar novamente"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 20
		}, this) : null;
		$[3] = onRetry;
		$[4] = t3;
	} else {
		t3 = $[4];
	}
	let t4;
	if ($[5] !== t2 || $[6] !== t3) {
		t4 = /* @__PURE__ */ _jsxDEV(StateBox, { children: [t2, t3] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 63,
			columnNumber: 10
		}, this);
		$[5] = t2;
		$[6] = t3;
		$[7] = t4;
	} else {
		t4 = $[7];
	}
	return t4;
}
_c3 = ErrorState;
export function EmptyState(t0) {
	const $ = _c(7);
	if ($[0] !== "a8d1bb64412f93502f172da077d487d530e2b3a959931badd96132cbc8a73043") {
		for (let $i = 0; $i < 7; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "a8d1bb64412f93502f172da077d487d530e2b3a959931badd96132cbc8a73043";
	}
	const { onCreate } = t0;
	let t1;
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = /* @__PURE__ */ _jsxDEV("strong", { children: "Nenhuma tarefa encontrada." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 89,
			columnNumber: 10
		}, this);
		t2 = /* @__PURE__ */ _jsxDEV("span", { children: "Ajuste os filtros ou crie a primeira tarefa do time." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 90,
			columnNumber: 10
		}, this);
		$[1] = t1;
		$[2] = t2;
	} else {
		t1 = $[1];
		t2 = $[2];
	}
	let t3;
	if ($[3] !== onCreate) {
		t3 = onCreate ? /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			onClick: onCreate,
			children: "Criar tarefa"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 99,
			columnNumber: 21
		}, this) : null;
		$[3] = onCreate;
		$[4] = t3;
	} else {
		t3 = $[4];
	}
	let t4;
	if ($[5] !== t3) {
		t4 = /* @__PURE__ */ _jsxDEV(StateBox, { children: [
			t1,
			t2,
			t3
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 107,
			columnNumber: 10
		}, this);
		$[5] = t3;
		$[6] = t4;
	} else {
		t4 = $[6];
	}
	return t4;
}
_c4 = EmptyState;
var _c2, _c3, _c4;
$RefreshReg$(_c2, "LoadingState");
$RefreshReg$(_c3, "ErrorState");
$RefreshReg$(_c4, "EmptyState");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/tasks/TaskStates.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskStates.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskStates.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/tasks/TaskStates.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLFFBQVFDLGdCQUFnQjs7O0FBTWpDLE9BQU8sU0FBQUMsYUFBQUMsSUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFzQixRQUFBSyxTQUFBQyxPQUFBUDtDQUFFLE1BQUFNLFVBQUFDLE9BQUFDLFlBQUEsMEJBQUFEO0NBQWlDLElBQUFFO0NBQUEsSUFBQVIsRUFBQSxPQUFBSyxTQUFBO0VBQ3ZERyxLQUFBLHdCQUFDLFVBQUQsWUFBV0gsUUFBRjs7Ozs7RUFBcUJMLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBUTtDQUFBO0VBQUFBLEtBQUFSLEVBQUE7Q0FBQTtDQUFBLE9BQTlCUTtBQUE4Qjs7QUFRdkMsT0FBTyxTQUFBQyxXQUFBVixJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQW9CLFFBQUFLLFNBQUFDLElBQUFJLFlBQUFYO0NBQUUsTUFBQU0sVUFBQUMsT0FBQUMsWUFBQSx3Q0FBQUQ7Q0FBK0MsSUFBQUU7Q0FBQSxJQUFBUixFQUFBLE9BQUFLLFNBQUE7RUFHdEVHLEtBQUEsOENBQVNILFFBQWlCOzs7OztFQUFBTCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQVE7Q0FBQTtFQUFBQSxLQUFBUixFQUFBO0NBQUE7Q0FBQSxJQUFBVztDQUFBLElBQUFYLEVBQUEsT0FBQVUsU0FBQTtFQUN6QkMsS0FBQUQsVUFDQyx3QkFBQyxRQUFEO0dBQWE7R0FBa0JBO2FBQVM7RUFBakM7Ozs7YUFEUjtFQUlPVixFQUFBLEtBQUFVO0VBQUFWLEVBQUEsS0FBQVc7Q0FBQTtFQUFBQSxLQUFBWCxFQUFBO0NBQUE7Q0FBQSxJQUFBWTtDQUFBLElBQUFaLEVBQUEsT0FBQVEsTUFBQVIsRUFBQSxPQUFBVyxJQUFBO0VBTlZDLEtBQUEsd0JBQUMsVUFBRCxhQUNFSixJQUNDRyxFQUZNOzs7OztFQU9FWCxFQUFBLEtBQUFRO0VBQUFSLEVBQUEsS0FBQVc7RUFBQVgsRUFBQSxLQUFBWTtDQUFBO0VBQUFBLEtBQUFaLEVBQUE7Q0FBQTtDQUFBLE9BUFhZO0FBT1c7O0FBUWYsT0FBTyxTQUFBQyxXQUFBZCxJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQW9CLFFBQUFjLGFBQUFmO0NBQTZCLElBQUFPO0NBQUEsSUFBQUU7Q0FBQSxJQUFBUixFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFHbERFLEtBQUEsOENBQVEsNkJBQW1DOzs7OztFQUMzQ0UsS0FBQSw0Q0FBTSx1REFBMkQ7Ozs7O0VBQUFSLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBUTtDQUFBO0VBQUFGLEtBQUFOLEVBQUE7RUFBQVEsS0FBQVIsRUFBQTtDQUFBO0NBQUEsSUFBQVc7Q0FBQSxJQUFBWCxFQUFBLE9BQUFjLFVBQUE7RUFDaEVILEtBQUFHLFdBQ0Msd0JBQUMsUUFBRDtHQUFhO0dBQWtCQTthQUFVO0VBQWxDOzs7O2FBRFI7RUFJT2QsRUFBQSxLQUFBYztFQUFBZCxFQUFBLEtBQUFXO0NBQUE7RUFBQUEsS0FBQVgsRUFBQTtDQUFBO0NBQUEsSUFBQVk7Q0FBQSxJQUFBWixFQUFBLE9BQUFXLElBQUE7RUFQVkMsS0FBQSx3QkFBQyxVQUFEO0dBQ0VOO0dBQ0FFO0dBQ0NHO0VBSE07Ozs7O0VBUUVYLEVBQUEsS0FBQVc7RUFBQVgsRUFBQSxLQUFBWTtDQUFBO0VBQUFBLEtBQUFaLEVBQUE7Q0FBQTtDQUFBLE9BUlhZO0FBUVciLCJuYW1lcyI6WyJCdXR0b24iLCJTdGF0ZUJveCIsIkxvYWRpbmdTdGF0ZSIsInQwIiwiJCIsIl9jIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJtZXNzYWdlIiwidDEiLCJ1bmRlZmluZWQiLCJ0MiIsIkVycm9yU3RhdGUiLCJvblJldHJ5IiwidDMiLCJ0NCIsIkVtcHR5U3RhdGUiLCJvbkNyZWF0ZSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUYXNrU3RhdGVzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCdXR0b24sIFN0YXRlQm94IH0gZnJvbSBcIi4vc3R5bGVzXCI7XG5cbnR5cGUgTG9hZGluZ1N0YXRlUHJvcHMgPSB7XG4gIG1lc3NhZ2U/OiBzdHJpbmc7XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gTG9hZGluZ1N0YXRlKHsgbWVzc2FnZSA9IFwiQ2FycmVnYW5kbyB0YXJlZmFzLi4uXCIgfTogTG9hZGluZ1N0YXRlUHJvcHMpIHtcbiAgcmV0dXJuIDxTdGF0ZUJveD57bWVzc2FnZX08L1N0YXRlQm94Pjtcbn1cblxudHlwZSBFcnJvclN0YXRlUHJvcHMgPSB7XG4gIG1lc3NhZ2U/OiBzdHJpbmc7XG4gIG9uUmV0cnk/OiAoKSA9PiB2b2lkO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIEVycm9yU3RhdGUoeyBtZXNzYWdlID0gXCJOYW8gZm9pIHBvc3NpdmVsIGNhcnJlZ2FyIG9zIGRhZG9zLlwiLCBvblJldHJ5IH06IEVycm9yU3RhdGVQcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxTdGF0ZUJveD5cbiAgICAgIDxzdHJvbmc+e21lc3NhZ2V9PC9zdHJvbmc+XG4gICAgICB7b25SZXRyeSA/IChcbiAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17b25SZXRyeX0+XG4gICAgICAgICAgVGVudGFyIG5vdmFtZW50ZVxuICAgICAgICA8L0J1dHRvbj5cbiAgICAgICkgOiBudWxsfVxuICAgIDwvU3RhdGVCb3g+XG4gICk7XG59XG5cbnR5cGUgRW1wdHlTdGF0ZVByb3BzID0ge1xuICBvbkNyZWF0ZT86ICgpID0+IHZvaWQ7XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gRW1wdHlTdGF0ZSh7IG9uQ3JlYXRlIH06IEVtcHR5U3RhdGVQcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxTdGF0ZUJveD5cbiAgICAgIDxzdHJvbmc+TmVuaHVtYSB0YXJlZmEgZW5jb250cmFkYS48L3N0cm9uZz5cbiAgICAgIDxzcGFuPkFqdXN0ZSBvcyBmaWx0cm9zIG91IGNyaWUgYSBwcmltZWlyYSB0YXJlZmEgZG8gdGltZS48L3NwYW4+XG4gICAgICB7b25DcmVhdGUgPyAoXG4gICAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e29uQ3JlYXRlfT5cbiAgICAgICAgICBDcmlhciB0YXJlZmFcbiAgICAgICAgPC9CdXR0b24+XG4gICAgICApIDogbnVsbH1cbiAgICA8L1N0YXRlQm94PlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy93YWxsYS9EZXNrdG9wL1Byb2pldG9zLXBlc3NvYWlzL3Byb3ZhLXRlY25pY2EvZnJvbnQtbWluaS10YXNrLW1hbmFnZXIvc3JjL2NvbXBvbmVudHMvdGFza3MvVGFza1N0YXRlcy50c3gifQ==