import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/public/Register/index.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2ae0ea78";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router.js?v=10fd912d";
import { ApiRequestError } from "/src/services/api.ts";
import { registerUser } from "/src/services/authService.ts";
import { ErrorMessage, Field, Form, HeaderGroup, LoginPanel, PageShell, SuccessMessage, SwitchAuthText } from "/src/pages/public/Login/styles.ts";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/public/Register/index.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2ae0ea78";
var _s = $RefreshSig$();
const successMessage = "Cadastro realizado com sucesso! Faca login para continuar.";
function isValidEmail(email) {
	return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
const Register = () => {
	_s();
	const navigate = useNavigate();
	const [name, setName] = useState("");
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [confirmPassword, setConfirmPassword] = useState("");
	const [errors, setErrors] = useState({});
	const [formError, setFormError] = useState("");
	const [success, setSuccess] = useState("");
	const [isSubmitting, setIsSubmitting] = useState(false);
	useEffect(() => {
		if (!success) {
			return;
		}
		const timer = window.setTimeout(() => {
			navigate("/login", { replace: true });
		}, 800);
		return () => window.clearTimeout(timer);
	}, [navigate, success]);
	function validateForm() {
		const nextErrors = {};
		const trimmedName = name.trim();
		const trimmedEmail = email.trim();
		if (!trimmedName) {
			nextErrors.name = "Informe o nome.";
		}
		if (!trimmedEmail) {
			nextErrors.email = "Informe o e-mail.";
		} else if (!isValidEmail(trimmedEmail)) {
			nextErrors.email = "Informe um e-mail valido.";
		}
		if (!password) {
			nextErrors.password = "Informe a senha.";
		}
		if (!confirmPassword) {
			nextErrors.confirmPassword = "Confirme a senha.";
		} else if (password && password !== confirmPassword) {
			nextErrors.confirmPassword = "As senhas devem ser iguais.";
		}
		setErrors(nextErrors);
		return Object.keys(nextErrors).length === 0;
	}
	async function handleSubmit(event) {
		event.preventDefault();
		setFormError("");
		setSuccess("");
		if (!validateForm()) {
			return;
		}
		setIsSubmitting(true);
		try {
			await registerUser({
				name: name.trim(),
				email: email.trim(),
				password
			});
			setSuccess(successMessage);
		} catch (err) {
			const message = err instanceof ApiRequestError ? err.message : "Nao foi possivel realizar o cadastro.";
			setFormError(message);
		} finally {
			setIsSubmitting(false);
		}
	}
	function clearFieldError(field) {
		setErrors((current) => ({
			...current,
			[field]: undefined
		}));
		setFormError("");
	}
	return /* @__PURE__ */ _jsxDEV(PageShell, { children: /* @__PURE__ */ _jsxDEV(LoginPanel, { children: [
		/* @__PURE__ */ _jsxDEV(HeaderGroup, { children: /* @__PURE__ */ _jsxDEV("span", { children: "Mini Task Manager" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 93,
			columnNumber: 11
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 92,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(Form, {
			onSubmit: handleSubmit,
			noValidate: true,
			children: [
				/* @__PURE__ */ _jsxDEV(Field, { children: [
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "name",
						children: "Nome"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						id: "name",
						name: "name",
						type: "text",
						autoComplete: "name",
						value: name,
						onChange: (event_0) => {
							setName(event_0.target.value);
							clearFieldError("name");
						}
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 13
					}, this),
					errors.name ? /* @__PURE__ */ _jsxDEV(ErrorMessage, {
						role: "alert",
						children: errors.name
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 103,
						columnNumber: 28
					}, this) : null
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 97,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(Field, { children: [
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "register-email",
						children: "E-mail"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						id: "register-email",
						name: "email",
						type: "email",
						autoComplete: "email",
						value: email,
						onChange: (event_1) => {
							setEmail(event_1.target.value);
							clearFieldError("email");
						}
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 13
					}, this),
					errors.email ? /* @__PURE__ */ _jsxDEV(ErrorMessage, {
						role: "alert",
						children: errors.email
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 112,
						columnNumber: 29
					}, this) : null
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 106,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(Field, { children: [
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "register-password",
						children: "Senha"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 116,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						id: "register-password",
						name: "password",
						type: "password",
						autoComplete: "new-password",
						value: password,
						onChange: (event_2) => {
							setPassword(event_2.target.value);
							clearFieldError("password");
						}
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 117,
						columnNumber: 13
					}, this),
					errors.password ? /* @__PURE__ */ _jsxDEV(ErrorMessage, {
						role: "alert",
						children: errors.password
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 121,
						columnNumber: 32
					}, this) : null
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 115,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(Field, { children: [
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "confirm-password",
						children: "Confirmar senha"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						id: "confirm-password",
						name: "confirmPassword",
						type: "password",
						autoComplete: "new-password",
						value: confirmPassword,
						onChange: (event_3) => {
							setConfirmPassword(event_3.target.value);
							clearFieldError("confirmPassword");
						}
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 13
					}, this),
					errors.confirmPassword ? /* @__PURE__ */ _jsxDEV(ErrorMessage, {
						role: "alert",
						children: errors.confirmPassword
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 130,
						columnNumber: 39
					}, this) : null
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 124,
					columnNumber: 11
				}, this),
				formError ? /* @__PURE__ */ _jsxDEV(ErrorMessage, {
					role: "alert",
					children: formError
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 133,
					columnNumber: 24
				}, this) : null,
				success ? /* @__PURE__ */ _jsxDEV(SuccessMessage, {
					role: "status",
					children: success
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 134,
					columnNumber: 22
				}, this) : null,
				/* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					disabled: isSubmitting || Boolean(success),
					children: isSubmitting ? "Cadastrando..." : "Cadastrar"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 136,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 96,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(SwitchAuthText, { children: ["Ja possui uma conta? ", /* @__PURE__ */ _jsxDEV(Link, {
			to: "/login",
			children: "Entrar"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 142,
			columnNumber: 32
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 141,
			columnNumber: 9
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 91,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 90,
		columnNumber: 10
	}, this);
};
_s(Register, "mbhzTq9T7klfEf70xZSMZnFidTs=", false, function() {
	return [useNavigate];
});
_c = Register;
export default Register;
var _c;
$RefreshReg$(_c, "Register");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/public/Register/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/public/Register/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/public/Register/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/public/Register/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBRXBDLFNBQVNDLE1BQU1DLG1CQUFtQjtBQUNsQyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQ0VDLGNBQ0FDLE9BQ0FDLE1BQ0FDLGFBQ0FDLFlBQ0FDLFdBQ0FDLGdCQUNBQyxzQkFDSzs7OztBQVNQLE1BQU1DLGlCQUNKO0FBRUYsU0FBU0MsYUFBYUMsT0FBZTtDQUNuQyxPQUFPLDZCQUE2QkMsS0FBS0QsS0FBSztBQUNoRDtBQUVBLE1BQU1FLGlCQUFpQjs7Q0FDckIsTUFBTUMsV0FBV2hCLFlBQVk7Q0FDN0IsTUFBTSxDQUFDaUIsTUFBTUMsV0FBV3BCLFNBQVMsRUFBRTtDQUNuQyxNQUFNLENBQUNlLE9BQU9NLFlBQVlyQixTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDc0IsVUFBVUMsZUFBZXZCLFNBQVMsRUFBRTtDQUMzQyxNQUFNLENBQUN3QixpQkFBaUJDLHNCQUFzQnpCLFNBQVMsRUFBRTtDQUN6RCxNQUFNLENBQUMwQixRQUFRQyxhQUFhM0IsU0FBNkIsQ0FBQyxDQUFDO0NBQzNELE1BQU0sQ0FBQzRCLFdBQVdDLGdCQUFnQjdCLFNBQVMsRUFBRTtDQUM3QyxNQUFNLENBQUM4QixTQUFTQyxjQUFjL0IsU0FBUyxFQUFFO0NBQ3pDLE1BQU0sQ0FBQ2dDLGNBQWNDLG1CQUFtQmpDLFNBQVMsS0FBSztDQUV0REQsZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDK0IsU0FBUztHQUNaO0VBQ0Y7RUFFQSxNQUFNSSxRQUFRQyxPQUFPQyxpQkFBaUI7R0FDcENsQixTQUFTLFVBQVUsRUFBRW1CLFNBQVMsS0FBSyxDQUFDO0VBQ3RDLEdBQUcsR0FBRztFQUVOLGFBQWFGLE9BQU9HLGFBQWFKLEtBQUs7Q0FDeEMsR0FBRyxDQUFDaEIsVUFBVVksT0FBTyxDQUFDO0NBRXRCLFNBQVNTLGVBQWU7RUFDdEIsTUFBTUMsYUFBaUMsQ0FBQztFQUN4QyxNQUFNQyxjQUFjdEIsS0FBS3VCLEtBQUs7RUFDOUIsTUFBTUMsZUFBZTVCLE1BQU0yQixLQUFLO0VBRWhDLElBQUksQ0FBQ0QsYUFBYTtHQUNoQkQsV0FBV3JCLE9BQU87RUFDcEI7RUFFQSxJQUFJLENBQUN3QixjQUFjO0dBQ2pCSCxXQUFXekIsUUFBUTtFQUNyQixPQUFPLElBQUksQ0FBQ0QsYUFBYTZCLFlBQVksR0FBRztHQUN0Q0gsV0FBV3pCLFFBQVE7RUFDckI7RUFFQSxJQUFJLENBQUNPLFVBQVU7R0FDYmtCLFdBQVdsQixXQUFXO0VBQ3hCO0VBRUEsSUFBSSxDQUFDRSxpQkFBaUI7R0FDcEJnQixXQUFXaEIsa0JBQWtCO0VBQy9CLE9BQU8sSUFBSUYsWUFBWUEsYUFBYUUsaUJBQWlCO0dBQ25EZ0IsV0FBV2hCLGtCQUFrQjtFQUMvQjtFQUVBRyxVQUFVYSxVQUFVO0VBQ3BCLE9BQU9JLE9BQU9DLEtBQUtMLFVBQVUsQ0FBQyxDQUFDTSxXQUFXO0NBQzVDO0NBRUEsZUFBZUMsYUFBYUMsT0FBbUM7RUFDN0RBLE1BQU1DLGVBQWU7RUFDckJwQixhQUFhLEVBQUU7RUFDZkUsV0FBVyxFQUFFO0VBRWIsSUFBSSxDQUFDUSxhQUFhLEdBQUc7R0FDbkI7RUFDRjtFQUVBTixnQkFBZ0IsSUFBSTtFQUVwQixJQUFJO0dBQ0YsTUFBTTdCLGFBQWE7SUFDakJlLE1BQU1BLEtBQUt1QixLQUFLO0lBQ2hCM0IsT0FBT0EsTUFBTTJCLEtBQUs7SUFDbEJwQjtHQUNGLENBQUM7R0FDRFMsV0FBV2xCLGNBQWM7RUFDM0IsU0FBU3FDLEtBQUs7R0FDWixNQUFNQyxVQUNKRCxlQUFlL0Msa0JBQ1grQyxJQUFJQyxVQUNKO0dBQ050QixhQUFhc0IsT0FBTztFQUN0QixVQUFVO0dBQ1JsQixnQkFBZ0IsS0FBSztFQUN2QjtDQUNGO0NBRUEsU0FBU21CLGdCQUFnQkMsT0FBaUM7RUFDeEQxQixXQUFXMkIsYUFBYTtHQUFFLEdBQUdBO0lBQVVELFFBQVFFO0VBQVUsRUFBRTtFQUMzRDFCLGFBQWEsRUFBRTtDQUNqQjtDQUVBLE9BQ0Usd0JBQUMsV0FBRCxZQUNFLHdCQUFDLFlBQUQ7RUFDRSx3QkFBQyxhQUFELFlBQ0Usd0JBQUMsUUFBRCxZQUFNLG9CQUF1Qjs7OztXQUNsQjs7Ozs7RUFFYix3QkFBQyxNQUFEO0dBQU0sVUFBVWtCO0dBQWM7YUFBOUI7SUFDRSx3QkFBQyxPQUFEO0tBQ0Usd0JBQUMsU0FBRDtNQUFPLFNBQVE7Z0JBQU87S0FBVzs7Ozs7S0FDakMsd0JBQUMsU0FBRDtNQUNFLElBQUc7TUFDSCxNQUFLO01BQ0wsTUFBSztNQUNMLGNBQWE7TUFDYixPQUFPNUI7TUFDUCxXQUFXNkIsWUFBVTtPQUNuQjVCLFFBQVE0QixRQUFNUSxPQUFPQyxLQUFLO09BQzFCTCxnQkFBZ0IsTUFBTTtNQUN4QjtLQUFFOzs7OztLQUVIMUIsT0FBT1AsT0FBTyx3QkFBQyxjQUFEO01BQWMsTUFBSztnQkFBU08sT0FBT1A7S0FBbUI7Ozs7Z0JBQUk7SUFDcEU7Ozs7O0lBRVAsd0JBQUMsT0FBRDtLQUNFLHdCQUFDLFNBQUQ7TUFBTyxTQUFRO2dCQUFpQjtLQUFhOzs7OztLQUM3Qyx3QkFBQyxTQUFEO01BQ0UsSUFBRztNQUNILE1BQUs7TUFDTCxNQUFLO01BQ0wsY0FBYTtNQUNiLE9BQU9KO01BQ1AsV0FBV2lDLFlBQVU7T0FDbkIzQixTQUFTMkIsUUFBTVEsT0FBT0MsS0FBSztPQUMzQkwsZ0JBQWdCLE9BQU87TUFDekI7S0FBRTs7Ozs7S0FFSDFCLE9BQU9YLFFBQVEsd0JBQUMsY0FBRDtNQUFjLE1BQUs7Z0JBQVNXLE9BQU9YO0tBQW9COzs7O2dCQUFJO0lBQ3RFOzs7OztJQUVQLHdCQUFDLE9BQUQ7S0FDRSx3QkFBQyxTQUFEO01BQU8sU0FBUTtnQkFBb0I7S0FBWTs7Ozs7S0FDL0Msd0JBQUMsU0FBRDtNQUNFLElBQUc7TUFDSCxNQUFLO01BQ0wsTUFBSztNQUNMLGNBQWE7TUFDYixPQUFPTztNQUNQLFdBQVcwQixZQUFVO09BQ25CekIsWUFBWXlCLFFBQU1RLE9BQU9DLEtBQUs7T0FDOUJMLGdCQUFnQixVQUFVO01BQzVCO0tBQUU7Ozs7O0tBRUgxQixPQUFPSixXQUNOLHdCQUFDLGNBQUQ7TUFBYyxNQUFLO2dCQUFTSSxPQUFPSjtLQUF1Qjs7OztnQkFDeEQ7SUFDQzs7Ozs7SUFFUCx3QkFBQyxPQUFEO0tBQ0Usd0JBQUMsU0FBRDtNQUFPLFNBQVE7Z0JBQW1CO0tBQXNCOzs7OztLQUN4RCx3QkFBQyxTQUFEO01BQ0UsSUFBRztNQUNILE1BQUs7TUFDTCxNQUFLO01BQ0wsY0FBYTtNQUNiLE9BQU9FO01BQ1AsV0FBV3dCLFlBQVU7T0FDbkJ2QixtQkFBbUJ1QixRQUFNUSxPQUFPQyxLQUFLO09BQ3JDTCxnQkFBZ0IsaUJBQWlCO01BQ25DO0tBQUU7Ozs7O0tBRUgxQixPQUFPRixrQkFDTix3QkFBQyxjQUFEO01BQWMsTUFBSztnQkFBU0UsT0FBT0Y7S0FBOEI7Ozs7Z0JBQy9EO0lBQ0M7Ozs7O0lBRU5JLFlBQVksd0JBQUMsY0FBRDtLQUFjLE1BQUs7ZUFBU0E7SUFBd0I7Ozs7ZUFBSTtJQUNwRUUsVUFBVSx3QkFBQyxnQkFBRDtLQUFnQixNQUFLO2VBQVVBO0lBQXdCOzs7O2VBQUk7SUFFdEUsd0JBQUMsVUFBRDtLQUFRLE1BQUs7S0FBUyxVQUFVRSxnQkFBZ0IwQixRQUFRNUIsT0FBTztlQUM1REUsZUFBZSxtQkFBbUI7SUFDN0I7Ozs7O0dBQ0o7Ozs7OztFQUVOLHdCQUFDLGdCQUFELGFBQWUseUJBQ1Esd0JBQUMsTUFBRDtHQUFNLElBQUc7YUFBUztFQUFZOzs7O1VBQ3JDOzs7OztDQUNOOzs7O1VBQ0g7Ozs7O0FBRWY7Ozs7O0FBRUEsZUFBZWYiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIkxpbmsiLCJ1c2VOYXZpZ2F0ZSIsIkFwaVJlcXVlc3RFcnJvciIsInJlZ2lzdGVyVXNlciIsIkVycm9yTWVzc2FnZSIsIkZpZWxkIiwiRm9ybSIsIkhlYWRlckdyb3VwIiwiTG9naW5QYW5lbCIsIlBhZ2VTaGVsbCIsIlN1Y2Nlc3NNZXNzYWdlIiwiU3dpdGNoQXV0aFRleHQiLCJzdWNjZXNzTWVzc2FnZSIsImlzVmFsaWRFbWFpbCIsImVtYWlsIiwidGVzdCIsIlJlZ2lzdGVyIiwibmF2aWdhdGUiLCJuYW1lIiwic2V0TmFtZSIsInNldEVtYWlsIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsImNvbmZpcm1QYXNzd29yZCIsInNldENvbmZpcm1QYXNzd29yZCIsImVycm9ycyIsInNldEVycm9ycyIsImZvcm1FcnJvciIsInNldEZvcm1FcnJvciIsInN1Y2Nlc3MiLCJzZXRTdWNjZXNzIiwiaXNTdWJtaXR0aW5nIiwic2V0SXNTdWJtaXR0aW5nIiwidGltZXIiLCJ3aW5kb3ciLCJzZXRUaW1lb3V0IiwicmVwbGFjZSIsImNsZWFyVGltZW91dCIsInZhbGlkYXRlRm9ybSIsIm5leHRFcnJvcnMiLCJ0cmltbWVkTmFtZSIsInRyaW0iLCJ0cmltbWVkRW1haWwiLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwiaGFuZGxlU3VibWl0IiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImVyciIsIm1lc3NhZ2UiLCJjbGVhckZpZWxkRXJyb3IiLCJmaWVsZCIsImN1cnJlbnQiLCJ1bmRlZmluZWQiLCJ0YXJnZXQiLCJ2YWx1ZSIsIkJvb2xlYW4iXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB0eXBlIHsgRm9ybUV2ZW50IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXJcIjtcbmltcG9ydCB7IEFwaVJlcXVlc3RFcnJvciB9IGZyb20gXCIuLi8uLi8uLi9zZXJ2aWNlcy9hcGlcIjtcbmltcG9ydCB7IHJlZ2lzdGVyVXNlciB9IGZyb20gXCIuLi8uLi8uLi9zZXJ2aWNlcy9hdXRoU2VydmljZVwiO1xuaW1wb3J0IHtcbiAgRXJyb3JNZXNzYWdlLFxuICBGaWVsZCxcbiAgRm9ybSxcbiAgSGVhZGVyR3JvdXAsXG4gIExvZ2luUGFuZWwsXG4gIFBhZ2VTaGVsbCxcbiAgU3VjY2Vzc01lc3NhZ2UsXG4gIFN3aXRjaEF1dGhUZXh0LFxufSBmcm9tIFwiLi4vTG9naW4vc3R5bGVzXCI7XG5cbnR5cGUgUmVnaXN0ZXJGb3JtRXJyb3JzID0gUGFydGlhbDx7XG4gIG5hbWU6IHN0cmluZztcbiAgZW1haWw6IHN0cmluZztcbiAgcGFzc3dvcmQ6IHN0cmluZztcbiAgY29uZmlybVBhc3N3b3JkOiBzdHJpbmc7XG59PjtcblxuY29uc3Qgc3VjY2Vzc01lc3NhZ2UgPVxuICBcIkNhZGFzdHJvIHJlYWxpemFkbyBjb20gc3VjZXNzbyEgRmFjYSBsb2dpbiBwYXJhIGNvbnRpbnVhci5cIjtcblxuZnVuY3Rpb24gaXNWYWxpZEVtYWlsKGVtYWlsOiBzdHJpbmcpIHtcbiAgcmV0dXJuIC9eW15cXHNAXStAW15cXHNAXStcXC5bXlxcc0BdKyQvLnRlc3QoZW1haWwpO1xufVxuXG5jb25zdCBSZWdpc3RlciA9ICgpID0+IHtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICBjb25zdCBbbmFtZSwgc2V0TmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2NvbmZpcm1QYXNzd29yZCwgc2V0Q29uZmlybVBhc3N3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGU8UmVnaXN0ZXJGb3JtRXJyb3JzPih7fSk7XG4gIGNvbnN0IFtmb3JtRXJyb3IsIHNldEZvcm1FcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3N1Y2Nlc3MsIHNldFN1Y2Nlc3NdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtpc1N1Ym1pdHRpbmcsIHNldElzU3VibWl0dGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXN1Y2Nlc3MpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCB0aW1lciA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIG5hdmlnYXRlKFwiL2xvZ2luXCIsIHsgcmVwbGFjZTogdHJ1ZSB9KTtcbiAgICB9LCA4MDApO1xuXG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5jbGVhclRpbWVvdXQodGltZXIpO1xuICB9LCBbbmF2aWdhdGUsIHN1Y2Nlc3NdKTtcblxuICBmdW5jdGlvbiB2YWxpZGF0ZUZvcm0oKSB7XG4gICAgY29uc3QgbmV4dEVycm9yczogUmVnaXN0ZXJGb3JtRXJyb3JzID0ge307XG4gICAgY29uc3QgdHJpbW1lZE5hbWUgPSBuYW1lLnRyaW0oKTtcbiAgICBjb25zdCB0cmltbWVkRW1haWwgPSBlbWFpbC50cmltKCk7XG5cbiAgICBpZiAoIXRyaW1tZWROYW1lKSB7XG4gICAgICBuZXh0RXJyb3JzLm5hbWUgPSBcIkluZm9ybWUgbyBub21lLlwiO1xuICAgIH1cblxuICAgIGlmICghdHJpbW1lZEVtYWlsKSB7XG4gICAgICBuZXh0RXJyb3JzLmVtYWlsID0gXCJJbmZvcm1lIG8gZS1tYWlsLlwiO1xuICAgIH0gZWxzZSBpZiAoIWlzVmFsaWRFbWFpbCh0cmltbWVkRW1haWwpKSB7XG4gICAgICBuZXh0RXJyb3JzLmVtYWlsID0gXCJJbmZvcm1lIHVtIGUtbWFpbCB2YWxpZG8uXCI7XG4gICAgfVxuXG4gICAgaWYgKCFwYXNzd29yZCkge1xuICAgICAgbmV4dEVycm9ycy5wYXNzd29yZCA9IFwiSW5mb3JtZSBhIHNlbmhhLlwiO1xuICAgIH1cblxuICAgIGlmICghY29uZmlybVBhc3N3b3JkKSB7XG4gICAgICBuZXh0RXJyb3JzLmNvbmZpcm1QYXNzd29yZCA9IFwiQ29uZmlybWUgYSBzZW5oYS5cIjtcbiAgICB9IGVsc2UgaWYgKHBhc3N3b3JkICYmIHBhc3N3b3JkICE9PSBjb25maXJtUGFzc3dvcmQpIHtcbiAgICAgIG5leHRFcnJvcnMuY29uZmlybVBhc3N3b3JkID0gXCJBcyBzZW5oYXMgZGV2ZW0gc2VyIGlndWFpcy5cIjtcbiAgICB9XG5cbiAgICBzZXRFcnJvcnMobmV4dEVycm9ycyk7XG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKG5leHRFcnJvcnMpLmxlbmd0aCA9PT0gMDtcbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChldmVudDogRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD4pIHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIHNldEZvcm1FcnJvcihcIlwiKTtcbiAgICBzZXRTdWNjZXNzKFwiXCIpO1xuXG4gICAgaWYgKCF2YWxpZGF0ZUZvcm0oKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHNldElzU3VibWl0dGluZyh0cnVlKTtcblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCByZWdpc3RlclVzZXIoe1xuICAgICAgICBuYW1lOiBuYW1lLnRyaW0oKSxcbiAgICAgICAgZW1haWw6IGVtYWlsLnRyaW0oKSxcbiAgICAgICAgcGFzc3dvcmQsXG4gICAgICB9KTtcbiAgICAgIHNldFN1Y2Nlc3Moc3VjY2Vzc01lc3NhZ2UpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc3QgbWVzc2FnZSA9XG4gICAgICAgIGVyciBpbnN0YW5jZW9mIEFwaVJlcXVlc3RFcnJvclxuICAgICAgICAgID8gZXJyLm1lc3NhZ2VcbiAgICAgICAgICA6IFwiTmFvIGZvaSBwb3NzaXZlbCByZWFsaXphciBvIGNhZGFzdHJvLlwiO1xuICAgICAgc2V0Rm9ybUVycm9yKG1lc3NhZ2UpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc1N1Ym1pdHRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIGNsZWFyRmllbGRFcnJvcihmaWVsZDoga2V5b2YgUmVnaXN0ZXJGb3JtRXJyb3JzKSB7XG4gICAgc2V0RXJyb3JzKChjdXJyZW50KSA9PiAoeyAuLi5jdXJyZW50LCBbZmllbGRdOiB1bmRlZmluZWQgfSkpO1xuICAgIHNldEZvcm1FcnJvcihcIlwiKTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPFBhZ2VTaGVsbD5cbiAgICAgIDxMb2dpblBhbmVsPlxuICAgICAgICA8SGVhZGVyR3JvdXA+XG4gICAgICAgICAgPHNwYW4+TWluaSBUYXNrIE1hbmFnZXI8L3NwYW4+XG4gICAgICAgIDwvSGVhZGVyR3JvdXA+XG5cbiAgICAgICAgPEZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gbm9WYWxpZGF0ZT5cbiAgICAgICAgICA8RmllbGQ+XG4gICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm5hbWVcIj5Ob21lPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxuICAgICAgICAgICAgICBuYW1lPVwibmFtZVwiXG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwibmFtZVwiXG4gICAgICAgICAgICAgIHZhbHVlPXtuYW1lfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0TmFtZShldmVudC50YXJnZXQudmFsdWUpO1xuICAgICAgICAgICAgICAgIGNsZWFyRmllbGRFcnJvcihcIm5hbWVcIik7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAge2Vycm9ycy5uYW1lID8gPEVycm9yTWVzc2FnZSByb2xlPVwiYWxlcnRcIj57ZXJyb3JzLm5hbWV9PC9FcnJvck1lc3NhZ2U+IDogbnVsbH1cbiAgICAgICAgICA8L0ZpZWxkPlxuXG4gICAgICAgICAgPEZpZWxkPlxuICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJyZWdpc3Rlci1lbWFpbFwiPkUtbWFpbDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgaWQ9XCJyZWdpc3Rlci1lbWFpbFwiXG4gICAgICAgICAgICAgIG5hbWU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cImVtYWlsXCJcbiAgICAgICAgICAgICAgdmFsdWU9e2VtYWlsfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0RW1haWwoZXZlbnQudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgICAgICAgICBjbGVhckZpZWxkRXJyb3IoXCJlbWFpbFwiKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICB7ZXJyb3JzLmVtYWlsID8gPEVycm9yTWVzc2FnZSByb2xlPVwiYWxlcnRcIj57ZXJyb3JzLmVtYWlsfTwvRXJyb3JNZXNzYWdlPiA6IG51bGx9XG4gICAgICAgICAgPC9GaWVsZD5cblxuICAgICAgICAgIDxGaWVsZD5cbiAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicmVnaXN0ZXItcGFzc3dvcmRcIj5TZW5oYTwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgaWQ9XCJyZWdpc3Rlci1wYXNzd29yZFwiXG4gICAgICAgICAgICAgIG5hbWU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm5ldy1wYXNzd29yZFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4ge1xuICAgICAgICAgICAgICAgIHNldFBhc3N3b3JkKGV2ZW50LnRhcmdldC52YWx1ZSk7XG4gICAgICAgICAgICAgICAgY2xlYXJGaWVsZEVycm9yKFwicGFzc3dvcmRcIik7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAge2Vycm9ycy5wYXNzd29yZCA/IChcbiAgICAgICAgICAgICAgPEVycm9yTWVzc2FnZSByb2xlPVwiYWxlcnRcIj57ZXJyb3JzLnBhc3N3b3JkfTwvRXJyb3JNZXNzYWdlPlxuICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgPC9GaWVsZD5cblxuICAgICAgICAgIDxGaWVsZD5cbiAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiY29uZmlybS1wYXNzd29yZFwiPkNvbmZpcm1hciBzZW5oYTwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgaWQ9XCJjb25maXJtLXBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgbmFtZT1cImNvbmZpcm1QYXNzd29yZFwiXG4gICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm5ldy1wYXNzd29yZFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtjb25maXJtUGFzc3dvcmR9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRDb25maXJtUGFzc3dvcmQoZXZlbnQudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgICAgICAgICBjbGVhckZpZWxkRXJyb3IoXCJjb25maXJtUGFzc3dvcmRcIik7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAge2Vycm9ycy5jb25maXJtUGFzc3dvcmQgPyAoXG4gICAgICAgICAgICAgIDxFcnJvck1lc3NhZ2Ugcm9sZT1cImFsZXJ0XCI+e2Vycm9ycy5jb25maXJtUGFzc3dvcmR9PC9FcnJvck1lc3NhZ2U+XG4gICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICA8L0ZpZWxkPlxuXG4gICAgICAgICAge2Zvcm1FcnJvciA/IDxFcnJvck1lc3NhZ2Ugcm9sZT1cImFsZXJ0XCI+e2Zvcm1FcnJvcn08L0Vycm9yTWVzc2FnZT4gOiBudWxsfVxuICAgICAgICAgIHtzdWNjZXNzID8gPFN1Y2Nlc3NNZXNzYWdlIHJvbGU9XCJzdGF0dXNcIj57c3VjY2Vzc308L1N1Y2Nlc3NNZXNzYWdlPiA6IG51bGx9XG5cbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17aXNTdWJtaXR0aW5nIHx8IEJvb2xlYW4oc3VjY2Vzcyl9PlxuICAgICAgICAgICAge2lzU3VibWl0dGluZyA/IFwiQ2FkYXN0cmFuZG8uLi5cIiA6IFwiQ2FkYXN0cmFyXCJ9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvRm9ybT5cblxuICAgICAgICA8U3dpdGNoQXV0aFRleHQ+XG4gICAgICAgICAgSmEgcG9zc3VpIHVtYSBjb250YT8gPExpbmsgdG89XCIvbG9naW5cIj5FbnRyYXI8L0xpbms+XG4gICAgICAgIDwvU3dpdGNoQXV0aFRleHQ+XG4gICAgICA8L0xvZ2luUGFuZWw+XG4gICAgPC9QYWdlU2hlbGw+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBSZWdpc3RlcjtcbiJdLCJmaWxlIjoiQzovVXNlcnMvd2FsbGEvRGVza3RvcC9Qcm9qZXRvcy1wZXNzb2Fpcy9wcm92YS10ZWNuaWNhL2Zyb250LW1pbmktdGFzay1tYW5hZ2VyL3NyYy9wYWdlcy9wdWJsaWMvUmVnaXN0ZXIvaW5kZXgudHN4In0=