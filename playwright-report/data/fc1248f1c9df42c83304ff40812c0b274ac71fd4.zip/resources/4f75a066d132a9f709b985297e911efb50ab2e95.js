import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/index.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=2ae0ea78";
import { BrowserRouter, Navigate, Route, Routes } from "/node_modules/.vite/deps/react-router.js?v=10fd912d";
import { useAuth } from "/src/hooks/auth.tsx";
import { PrivateRoutes } from "/src/routes/adminRoutes/privateRoutes.tsx";
import { PublicRoutes } from "/src/routes/publicRoutes.tsx";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/index.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2ae0ea78";
var _s = $RefreshSig$();
export function AppRoutes() {
	_s();
	const $ = _c(3);
	if ($[0] !== "fa97c8f6441bca8f522bbab07d038395bdfa536ae66a6d276eab79cc5cad1f98") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "fa97c8f6441bca8f522bbab07d038395bdfa536ae66a6d276eab79cc5cad1f98";
	}
	const { isAuthorized, isLoadingAuth } = useAuth();
	if (isLoadingAuth) {
		return null;
	}
	let t0;
	if ($[1] !== isAuthorized) {
		t0 = /* @__PURE__ */ _jsxDEV(BrowserRouter, { children: /* @__PURE__ */ _jsxDEV(Routes, { children: isAuthorized ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/*",
				element: /* @__PURE__ */ _jsxDEV(PrivateRoutes, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 23,
					columnNumber: 77
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 51
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/login",
				element: /* @__PURE__ */ _jsxDEV(Navigate, {
					to: "/",
					replace: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 23,
					columnNumber: 128
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 98
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/register",
				element: /* @__PURE__ */ _jsxDEV(Navigate, {
					to: "/",
					replace: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 23,
					columnNumber: 199
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 166
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 49
		}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: /* @__PURE__ */ _jsxDEV(Route, {
			path: "/*",
			element: /* @__PURE__ */ _jsxDEV(PublicRoutes, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 271
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 245
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 243
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 25
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 10
		}, this);
		$[1] = isAuthorized;
		$[2] = t0;
	} else {
		t0 = $[2];
	}
	return t0;
}
_s(AppRoutes, "DSN5e0XMcNYL/PibHl/V4Q6E6Sw=", false, function() {
	return [useAuth];
});
_c2 = AppRoutes;
var _c2;
$RefreshReg$(_c2, "AppRoutes");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLGVBQWVDLFVBQVVDLE9BQU9DLGNBQWM7QUFDdkQsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0Msb0JBQW9COzs7O0FBRTdCLE9BQU8sU0FBQUMsWUFBQTs7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FDTCxRQUFBSyxjQUFBQyxrQkFBd0NWLFFBQVE7Q0FFaEQsSUFBSVUsZUFBYTtFQUFBLE9BQ1I7Q0FBSTtDQUNaLElBQUFDO0NBQUEsSUFBQVAsRUFBQSxPQUFBSyxjQUFBO0VBR0NFLEtBQUEsd0JBQUMsZUFBRCxZQUNFLHdCQUFDLFFBQUQsWUFDR0YsZUFBQTtHQUVHLHdCQUFDLE9BQUQ7SUFBWTtJQUFjLGlDQUFDLGVBQUQsQ0FBYzs7Ozs7R0FBRzs7Ozs7R0FDM0Msd0JBQUMsT0FBRDtJQUFZO0lBQWtCLGlDQUFDLFVBQUQ7S0FBYTtLQUFJO0lBQU87Ozs7O0dBQUc7Ozs7O0dBQ3pELHdCQUFDLE9BQUQ7SUFBWTtJQUFxQixpQ0FBQyxVQUFEO0tBQWE7S0FBSTtJQUFPOzs7OztHQUFHOzs7OztFQUFJOzs7O2FBSm5FLCtDQVFHLHdCQUFDLE9BQUQ7R0FBWTtHQUFjLGlDQUFDLGNBQUQsQ0FBYTs7Ozs7RUFBRzs7OztXQUFJOzs7O1dBVDdDOzs7O1dBREs7Ozs7O0VBY0VMLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTztDQUFBO0VBQUFBLEtBQUFQLEVBQUE7Q0FBQTtDQUFBLE9BZGhCTztBQWNnQiIsIm5hbWVzIjpbIkJyb3dzZXJSb3V0ZXIiLCJOYXZpZ2F0ZSIsIlJvdXRlIiwiUm91dGVzIiwidXNlQXV0aCIsIlByaXZhdGVSb3V0ZXMiLCJQdWJsaWNSb3V0ZXMiLCJBcHBSb3V0ZXMiLCIkIiwiX2MiLCIkaSIsIlN5bWJvbCIsImZvciIsImlzQXV0aG9yaXplZCIsImlzTG9hZGluZ0F1dGgiLCJ0MCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQnJvd3NlclJvdXRlciwgTmF2aWdhdGUsIFJvdXRlLCBSb3V0ZXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyXCI7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uL2hvb2tzL2F1dGhcIjtcbmltcG9ydCB7IFByaXZhdGVSb3V0ZXMgfSBmcm9tIFwiLi9hZG1pblJvdXRlcy9wcml2YXRlUm91dGVzXCI7XG5pbXBvcnQgeyBQdWJsaWNSb3V0ZXMgfSBmcm9tIFwiLi9wdWJsaWNSb3V0ZXNcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIEFwcFJvdXRlcygpIHtcbiAgY29uc3QgeyBpc0F1dGhvcml6ZWQsIGlzTG9hZGluZ0F1dGggfSA9IHVzZUF1dGgoKTtcblxuICBpZiAoaXNMb2FkaW5nQXV0aCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8QnJvd3NlclJvdXRlcj5cbiAgICAgIDxSb3V0ZXM+XG4gICAgICAgIHtpc0F1dGhvcml6ZWQgPyAoXG4gICAgICAgICAgPD5cbiAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiLypcIiBlbGVtZW50PXs8UHJpdmF0ZVJvdXRlcyAvPn0gLz5cbiAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2xvZ2luXCIgZWxlbWVudD17PE5hdmlnYXRlIHRvPVwiL1wiIHJlcGxhY2UgLz59IC8+XG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9yZWdpc3RlclwiIGVsZW1lbnQ9ezxOYXZpZ2F0ZSB0bz1cIi9cIiByZXBsYWNlIC8+fSAvPlxuICAgICAgICAgIDwvPlxuICAgICAgICApIDogKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIi8qXCIgZWxlbWVudD17PFB1YmxpY1JvdXRlcyAvPn0gLz5cbiAgICAgICAgICA8Lz5cbiAgICAgICAgKX1cbiAgICAgIDwvUm91dGVzPlxuICAgIDwvQnJvd3NlclJvdXRlcj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvd2FsbGEvRGVza3RvcC9Qcm9qZXRvcy1wZXNzb2Fpcy9wcm92YS10ZWNuaWNhL2Zyb250LW1pbmktdGFzay1tYW5hZ2VyL3NyYy9yb3V0ZXMvaW5kZXgudHN4In0=