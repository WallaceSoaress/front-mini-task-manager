import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/adminRoutes/privateRoutes.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=2ae0ea78";
import { Route, Routes } from "/node_modules/.vite/deps/react-router.js?v=10fd912d";
import Tasks from "/src/pages/private/Tasks/index.tsx";
import Teams from "/src/pages/private/Teams/index.tsx";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/adminRoutes/privateRoutes.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2ae0ea78";
export function PrivateRoutes() {
	const $ = _c(3);
	if ($[0] !== "dd607a87592c289c80026ebb406c22564968f1708314e852655dfdad81c1f9a2") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "dd607a87592c289c80026ebb406c22564968f1708314e852655dfdad81c1f9a2";
	}
	let t0;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ _jsxDEV(Route, {
			path: "/",
			element: /* @__PURE__ */ _jsxDEV(Tasks, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 35
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 10
		}, this);
		$[1] = t0;
	} else {
		t0 = $[1];
	}
	let t1;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = /* @__PURE__ */ _jsxDEV(Routes, { children: [t0, /* @__PURE__ */ _jsxDEV(Route, {
			path: "/teams",
			element: /* @__PURE__ */ _jsxDEV(Teams, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 22,
				columnNumber: 52
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 22
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 10
		}, this);
		$[2] = t1;
	} else {
		t1 = $[2];
	}
	return t1;
}
_c2 = PrivateRoutes;
var _c2;
$RefreshReg$(_c2, "PrivateRoutes");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/adminRoutes/privateRoutes.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/adminRoutes/privateRoutes.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/adminRoutes/privateRoutes.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/routes/adminRoutes/privateRoutes.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLE9BQU9DLGNBQWM7QUFDOUIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxXQUFXOzs7QUFFbEIsT0FBTyxTQUFBQyxnQkFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFLO0NBQUEsSUFBQUwsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBR0RDLEtBQUEsd0JBQUMsT0FBRDtHQUFZO0dBQWEsaUNBQUMsT0FBRCxDQUFNOzs7OztFQUFHOzs7OztFQUFJTCxFQUFBLEtBQUFLO0NBQUE7RUFBQUEsS0FBQUwsRUFBQTtDQUFBO0NBQUEsSUFBQU07Q0FBQSxJQUFBTixFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFEeENFLEtBQUEsd0JBQUMsUUFBRCxhQUNFRCxJQUNBLHdCQUFDLE9BQUQ7R0FBWTtHQUFrQixpQ0FBQyxPQUFELENBQU07Ozs7O0VBQUc7Ozs7VUFGbEM7Ozs7O0VBR0VMLEVBQUEsS0FBQU07Q0FBQTtFQUFBQSxLQUFBTixFQUFBO0NBQUE7Q0FBQSxPQUhUTTtBQUdTIiwibmFtZXMiOlsiUm91dGUiLCJSb3V0ZXMiLCJUYXNrcyIsIlRlYW1zIiwiUHJpdmF0ZVJvdXRlcyIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwidDAiLCJ0MSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJwcml2YXRlUm91dGVzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBSb3V0ZSwgUm91dGVzIH0gZnJvbSBcInJlYWN0LXJvdXRlclwiO1xuaW1wb3J0IFRhc2tzIGZyb20gXCIuLi8uLi9wYWdlcy9wcml2YXRlL1Rhc2tzXCI7XG5pbXBvcnQgVGVhbXMgZnJvbSBcIi4uLy4uL3BhZ2VzL3ByaXZhdGUvVGVhbXNcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIFByaXZhdGVSb3V0ZXMoKSB7XG4gIHJldHVybiAoXG4gICAgPFJvdXRlcz5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL1wiIGVsZW1lbnQ9ezxUYXNrcyAvPn0gLz5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL3RlYW1zXCIgZWxlbWVudD17PFRlYW1zIC8+fSAvPlxuICAgIDwvUm91dGVzPlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy93YWxsYS9EZXNrdG9wL1Byb2pldG9zLXBlc3NvYWlzL3Byb3ZhLXRlY25pY2EvZnJvbnQtbWluaS10YXNrLW1hbmFnZXIvc3JjL3JvdXRlcy9hZG1pblJvdXRlcy9wcml2YXRlUm91dGVzLnRzeCJ9