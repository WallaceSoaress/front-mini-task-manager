import { n as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-BPOCksWG.js?v=f59827d3";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=2ae0ea78";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/react_jsx-runtime.js?v=2ae0ea78";
//#region node_modules/@tanstack/query-core/build/modern/subscribable.js
var Subscribable = class {
	constructor() {
		this.listeners = /* @__PURE__ */ new Set();
		this.subscribe = this.subscribe.bind(this);
	}
	subscribe(listener) {
		this.listeners.add(listener);
		this.onSubscribe();
		return () => {
			this.listeners.delete(listener);
			this.onUnsubscribe();
		};
	}
	hasListeners() {
		return this.listeners.size > 0;
	}
	onSubscribe() {}
	onUnsubscribe() {}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/focusManager.js
var FocusManager = class extends Subscribable {
	#focused;
	#cleanup;
	#setup;
	constructor() {
		super();
		this.#setup = (onFocus) => {
			if (typeof window !== "undefined" && window.addEventListener) {
				const listener = () => onFocus();
				window.addEventListener("visibilitychange", listener, false);
				return () => {
					window.removeEventListener("visibilitychange", listener);
				};
			}
		};
	}
	onSubscribe() {
		if (!this.#cleanup) this.setEventListener(this.#setup);
	}
	onUnsubscribe() {
		if (!this.hasListeners()) {
			this.#cleanup?.();
			this.#cleanup = void 0;
		}
	}
	setEventListener(setup) {
		this.#setup = setup;
		this.#cleanup?.();
		this.#cleanup = setup((focused) => {
			if (typeof focused === "boolean") this.setFocused(focused);
			else this.onFocus();
		});
	}
	setFocused(focused) {
		if (this.#focused !== focused) {
			this.#focused = focused;
			this.onFocus();
		}
	}
	onFocus() {
		const isFocused = this.isFocused();
		this.listeners.forEach((listener) => {
			listener(isFocused);
		});
	}
	isFocused() {
		if (typeof this.#focused === "boolean") return this.#focused;
		return globalThis.document?.visibilityState !== "hidden";
	}
};
var focusManager = new FocusManager();
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/timeoutManager.js
var defaultTimeoutProvider = {
	setTimeout: (callback, delay) => setTimeout(callback, delay),
	clearTimeout: (timeoutId) => clearTimeout(timeoutId),
	setInterval: (callback, delay) => setInterval(callback, delay),
	clearInterval: (intervalId) => clearInterval(intervalId)
};
var TimeoutManager = class {
	#provider = defaultTimeoutProvider;
	#providerCalled = false;
	setTimeoutProvider(provider) {
		if (this.#providerCalled && provider !== this.#provider) console.error(`[timeoutManager]: Switching provider after calls to previous provider might result in unexpected behavior.`, {
			previous: this.#provider,
			provider
		});
		this.#provider = provider;
		this.#providerCalled = false;
	}
	setTimeout(callback, delay) {
		this.#providerCalled = true;
		return this.#provider.setTimeout(callback, delay);
	}
	clearTimeout(timeoutId) {
		this.#provider.clearTimeout(timeoutId);
	}
	setInterval(callback, delay) {
		this.#providerCalled = true;
		return this.#provider.setInterval(callback, delay);
	}
	clearInterval(intervalId) {
		this.#provider.clearInterval(intervalId);
	}
};
var timeoutManager = new TimeoutManager();
function systemSetTimeoutZero(callback) {
	setTimeout(callback, 0);
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/utils.js
var isServer = typeof window === "undefined" || "Deno" in globalThis;
function noop() {}
function functionalUpdate(updater, input) {
	return typeof updater === "function" ? updater(input) : updater;
}
function isValidTimeout(value) {
	return typeof value === "number" && value >= 0 && value !== Infinity;
}
function timeUntilStale(updatedAt, staleTime) {
	return Math.max(updatedAt + (staleTime || 0) - Date.now(), 0);
}
function resolveStaleTime(staleTime, query) {
	return typeof staleTime === "function" ? staleTime(query) : staleTime;
}
function resolveQueryBoolean(option, query) {
	return typeof option === "function" ? option(query) : option;
}
function matchQuery(filters, query) {
	const { type = "all", exact, fetchStatus, predicate, queryKey, stale } = filters;
	if (queryKey) {
		if (exact) {
			if (query.queryHash !== hashQueryKeyByOptions(queryKey, query.options)) return false;
		} else if (!partialMatchKey(query.queryKey, queryKey)) return false;
	}
	if (type !== "all") {
		const isActive = query.isActive();
		if (type === "active" && !isActive) return false;
		if (type === "inactive" && isActive) return false;
	}
	if (typeof stale === "boolean" && query.isStale() !== stale) return false;
	if (fetchStatus && fetchStatus !== query.state.fetchStatus) return false;
	if (predicate && !predicate(query)) return false;
	return true;
}
function matchMutation(filters, mutation) {
	const { exact, status, predicate, mutationKey } = filters;
	if (mutationKey) {
		if (!mutation.options.mutationKey) return false;
		if (exact) {
			if (hashKey(mutation.options.mutationKey) !== hashKey(mutationKey)) return false;
		} else if (!partialMatchKey(mutation.options.mutationKey, mutationKey)) return false;
	}
	if (status && mutation.state.status !== status) return false;
	if (predicate && !predicate(mutation)) return false;
	return true;
}
function hashQueryKeyByOptions(queryKey, options) {
	return (options?.queryKeyHashFn || hashKey)(queryKey);
}
function hashKey(queryKey) {
	return JSON.stringify(queryKey, (_, val) => isPlainObject(val) ? Object.keys(val).sort().reduce((result, key) => {
		result[key] = val[key];
		return result;
	}, {}) : val);
}
function partialMatchKey(a, b) {
	if (a === b) return true;
	if (typeof a !== typeof b) return false;
	if (a && b && typeof a === "object" && typeof b === "object") {
		if (Array.isArray(a) && Array.isArray(b)) {
			for (let i = 0; i < b.length; i++) if (!partialMatchKey(a[i], b[i])) return false;
			return true;
		}
		const bKeys = Object.keys(b);
		for (const key of bKeys) if (!partialMatchKey(a[key], b[key])) return false;
		return true;
	}
	return false;
}
var hasOwn = Object.prototype.hasOwnProperty;
function replaceEqualDeep(a, b, depth = 0) {
	if (a === b) return a;
	if (depth > 500) return b;
	const array = isPlainArray(a) && isPlainArray(b);
	if (!array && !(isPlainObject(a) && isPlainObject(b))) return b;
	const aSize = (array ? a : Object.keys(a)).length;
	const bItems = array ? b : Object.keys(b);
	const bSize = bItems.length;
	const copy = array ? new Array(bSize) : {};
	let equalItems = 0;
	for (let i = 0; i < bSize; i++) {
		const key = array ? i : bItems[i];
		const aItem = a[key];
		const bItem = b[key];
		if (aItem === bItem) {
			copy[key] = aItem;
			if (array ? i < aSize : hasOwn.call(a, key)) equalItems++;
			continue;
		}
		if (aItem === null || bItem === null || typeof aItem !== "object" || typeof bItem !== "object") {
			copy[key] = bItem;
			continue;
		}
		const v = replaceEqualDeep(aItem, bItem, depth + 1);
		copy[key] = v;
		if (v === aItem) equalItems++;
	}
	return aSize === bSize && equalItems === aSize ? a : copy;
}
function shallowEqualObjects(a, b) {
	if (!b || Object.keys(a).length !== Object.keys(b).length) return false;
	for (const key in a) if (a[key] !== b[key]) return false;
	return true;
}
function isPlainArray(value) {
	return Array.isArray(value) && value.length === Object.keys(value).length;
}
function isPlainObject(o) {
	if (!hasObjectPrototype(o)) return false;
	const ctor = o.constructor;
	if (ctor === void 0) return true;
	const prot = ctor.prototype;
	if (!hasObjectPrototype(prot)) return false;
	if (!prot.hasOwnProperty("isPrototypeOf")) return false;
	if (Object.getPrototypeOf(o) !== Object.prototype) return false;
	return true;
}
function hasObjectPrototype(o) {
	return Object.prototype.toString.call(o) === "[object Object]";
}
function sleep(timeout) {
	return new Promise((resolve) => {
		timeoutManager.setTimeout(resolve, timeout);
	});
}
function replaceData(prevData, data, options) {
	if (typeof options.structuralSharing === "function") return options.structuralSharing(prevData, data);
	else if (options.structuralSharing !== false) try {
		return replaceEqualDeep(prevData, data);
	} catch (error) {
		console.error(`Structural sharing requires data to be JSON serializable. To fix this, turn off structuralSharing or return JSON-serializable data from your queryFn. [${options.queryHash}]: ${error}`);
		throw error;
	}
	return data;
}
function keepPreviousData(previousData) {
	return previousData;
}
function addToEnd(items, item, max = 0) {
	const newItems = [...items, item];
	return max && newItems.length > max ? newItems.slice(1) : newItems;
}
function addToStart(items, item, max = 0) {
	const newItems = [item, ...items];
	return max && newItems.length > max ? newItems.slice(0, -1) : newItems;
}
var skipToken = /* @__PURE__ */ Symbol();
function ensureQueryFn(options, fetchOptions) {
	if (options.queryFn === skipToken) console.error(`Attempted to invoke queryFn when set to skipToken. This is likely a configuration error. Query hash: '${options.queryHash}'`);
	if (!options.queryFn && fetchOptions?.initialPromise) return () => fetchOptions.initialPromise;
	if (!options.queryFn || options.queryFn === skipToken) return () => Promise.reject(/* @__PURE__ */ new Error(`Missing queryFn: '${options.queryHash}'`));
	return options.queryFn;
}
function shouldThrowError(throwOnError, params) {
	if (typeof throwOnError === "function") return throwOnError(...params);
	return !!throwOnError;
}
function addConsumeAwareSignal(object, getSignal, onCancelled) {
	let consumed = false;
	let signal;
	Object.defineProperty(object, "signal", {
		enumerable: true,
		get: () => {
			signal ??= getSignal();
			if (consumed) return signal;
			consumed = true;
			if (signal.aborted) onCancelled();
			else signal.addEventListener("abort", onCancelled, { once: true });
			return signal;
		}
	});
	return object;
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/environmentManager.js
var environmentManager = /* @__PURE__ */ (() => {
	let isServerFn = () => isServer;
	return {
		/**
		* Returns whether the current runtime should be treated as a server environment.
		*/
		isServer() {
			return isServerFn();
		},
		/**
		* Overrides the server check globally.
		*/
		setIsServer(isServerValue) {
			isServerFn = isServerValue;
		}
	};
})();
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/thenable.js
function pendingThenable() {
	let resolve;
	let reject;
	const thenable = new Promise((_resolve, _reject) => {
		resolve = _resolve;
		reject = _reject;
	});
	thenable.status = "pending";
	thenable.catch(() => {});
	function finalize(data) {
		Object.assign(thenable, data);
		delete thenable.resolve;
		delete thenable.reject;
	}
	thenable.resolve = (value) => {
		finalize({
			status: "fulfilled",
			value
		});
		resolve(value);
	};
	thenable.reject = (reason) => {
		finalize({
			status: "rejected",
			reason
		});
		reject(reason);
	};
	return thenable;
}
function tryResolveSync(promise) {
	let data;
	promise.then((result) => {
		data = result;
		return result;
	}, noop)?.catch(noop);
	if (data !== void 0) return { data };
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/hydration.js
function defaultTransformerFn(data) {
	return data;
}
function dehydrateMutation(mutation) {
	return {
		mutationKey: mutation.options.mutationKey,
		state: mutation.state,
		...mutation.options.scope && { scope: mutation.options.scope },
		...mutation.meta && { meta: mutation.meta }
	};
}
function dehydrateQuery(query, serializeData, shouldRedactErrors) {
	const dehydratePromise = () => {
		const promise = query.promise?.then(serializeData).catch((error) => {
			if (!shouldRedactErrors(error)) return Promise.reject(error);
			console.error(`A query that was dehydrated as pending ended up rejecting. [${query.queryHash}]: ${error}; The error will be redacted in production builds`);
			return Promise.reject(/* @__PURE__ */ new Error("redacted"));
		});
		promise?.catch(noop);
		return promise;
	};
	return {
		dehydratedAt: Date.now(),
		state: {
			...query.state,
			...query.state.data !== void 0 && { data: serializeData(query.state.data) }
		},
		queryKey: query.queryKey,
		queryHash: query.queryHash,
		...query.state.status === "pending" && { promise: dehydratePromise() },
		...query.meta && { meta: query.meta },
		...query.queryType && { queryType: query.queryType }
	};
}
function defaultShouldDehydrateMutation(mutation) {
	return mutation.state.isPaused;
}
function defaultShouldDehydrateQuery(query) {
	return query.state.status === "success";
}
function defaultShouldRedactErrors(_) {
	return true;
}
function dehydrate(client, options = {}) {
	const filterMutation = options.shouldDehydrateMutation ?? client.getDefaultOptions().dehydrate?.shouldDehydrateMutation ?? defaultShouldDehydrateMutation;
	const mutations = client.getMutationCache().getAll().flatMap((mutation) => filterMutation(mutation) ? [dehydrateMutation(mutation)] : []);
	const filterQuery = options.shouldDehydrateQuery ?? client.getDefaultOptions().dehydrate?.shouldDehydrateQuery ?? defaultShouldDehydrateQuery;
	const shouldRedactErrors = options.shouldRedactErrors ?? client.getDefaultOptions().dehydrate?.shouldRedactErrors ?? defaultShouldRedactErrors;
	const serializeData = options.serializeData ?? client.getDefaultOptions().dehydrate?.serializeData ?? defaultTransformerFn;
	return {
		mutations,
		queries: client.getQueryCache().getAll().flatMap((query) => filterQuery(query) ? [dehydrateQuery(query, serializeData, shouldRedactErrors)] : [])
	};
}
function hydrate(client, dehydratedState, options) {
	if (typeof dehydratedState !== "object" || dehydratedState === null) return;
	const mutationCache = client.getMutationCache();
	const queryCache = client.getQueryCache();
	const deserializeData = options?.defaultOptions?.deserializeData ?? client.getDefaultOptions().hydrate?.deserializeData ?? defaultTransformerFn;
	const mutations = dehydratedState.mutations || [];
	const queries = dehydratedState.queries || [];
	mutations.forEach(({ state, ...mutationOptions }) => {
		mutationCache.build(client, {
			...client.getDefaultOptions().hydrate?.mutations,
			...options?.defaultOptions?.mutations,
			...mutationOptions
		}, state);
	});
	queries.forEach(({ queryKey, state, queryHash, meta, promise, dehydratedAt, queryType }) => {
		const syncData = promise ? tryResolveSync(promise) : void 0;
		const rawData = state.data === void 0 ? syncData?.data : state.data;
		const data = rawData === void 0 ? rawData : deserializeData(rawData);
		let query = queryCache.get(queryHash);
		const existingQueryIsPending = query?.state.status === "pending";
		const existingQueryIsFetching = query?.state.fetchStatus === "fetching";
		if (query) {
			const hasNewerSyncData = syncData && dehydratedAt !== void 0 && dehydratedAt > query.state.dataUpdatedAt;
			if (state.dataUpdatedAt > query.state.dataUpdatedAt || hasNewerSyncData) {
				const { fetchStatus: _ignored, ...serializedState } = state;
				query.setState({
					...serializedState,
					data,
					...state.status === "pending" && data !== void 0 && {
						status: "success",
						dataUpdatedAt: dehydratedAt ?? Date.now(),
						...!existingQueryIsFetching && { fetchStatus: "idle" }
					}
				});
			}
		} else query = queryCache.build(client, {
			...client.getDefaultOptions().hydrate?.queries,
			...options?.defaultOptions?.queries,
			queryKey,
			queryHash,
			meta,
			_type: queryType
		}, {
			...state,
			data,
			fetchStatus: "idle",
			status: state.status === "pending" && data !== void 0 ? "success" : state.status,
			...state.status === "pending" && data !== void 0 && { dataUpdatedAt: dehydratedAt ?? Date.now() }
		});
		if (promise && !syncData && !existingQueryIsPending && !existingQueryIsFetching && (dehydratedAt === void 0 || dehydratedAt > query.state.dataUpdatedAt)) query.fetch(void 0, { initialPromise: Promise.resolve(promise).then(deserializeData) }).catch(noop);
	});
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/notifyManager.js
var defaultScheduler = systemSetTimeoutZero;
function createNotifyManager() {
	let queue = [];
	let transactions = 0;
	let notifyFn = (callback) => {
		callback();
	};
	let batchNotifyFn = (callback) => {
		callback();
	};
	let scheduleFn = defaultScheduler;
	const schedule = (callback) => {
		if (transactions) queue.push(callback);
		else scheduleFn(() => {
			notifyFn(callback);
		});
	};
	const flush = () => {
		const originalQueue = queue;
		queue = [];
		if (originalQueue.length) scheduleFn(() => {
			batchNotifyFn(() => {
				originalQueue.forEach((callback) => {
					notifyFn(callback);
				});
			});
		});
	};
	return {
		batch: (callback) => {
			let result;
			transactions++;
			try {
				result = callback();
			} finally {
				transactions--;
				if (!transactions) flush();
			}
			return result;
		},
		/**
		* All calls to the wrapped function will be batched.
		*/
		batchCalls: (callback) => {
			return (...args) => {
				schedule(() => {
					callback(...args);
				});
			};
		},
		schedule,
		/**
		* Use this method to set a custom notify function.
		* This can be used to for example wrap notifications with `React.act` while running tests.
		*/
		setNotifyFunction: (fn) => {
			notifyFn = fn;
		},
		/**
		* Use this method to set a custom function to batch notifications together into a single tick.
		* By default React Query will use the batch function provided by ReactDOM or React Native.
		*/
		setBatchNotifyFunction: (fn) => {
			batchNotifyFn = fn;
		},
		setScheduler: (fn) => {
			scheduleFn = fn;
		}
	};
}
var notifyManager = createNotifyManager();
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/onlineManager.js
var OnlineManager = class extends Subscribable {
	#online = true;
	#cleanup;
	#setup;
	constructor() {
		super();
		this.#setup = (onOnline) => {
			if (typeof window !== "undefined" && window.addEventListener) {
				const onlineListener = () => onOnline(true);
				const offlineListener = () => onOnline(false);
				window.addEventListener("online", onlineListener, false);
				window.addEventListener("offline", offlineListener, false);
				return () => {
					window.removeEventListener("online", onlineListener);
					window.removeEventListener("offline", offlineListener);
				};
			}
		};
	}
	onSubscribe() {
		if (!this.#cleanup) this.setEventListener(this.#setup);
	}
	onUnsubscribe() {
		if (!this.hasListeners()) {
			this.#cleanup?.();
			this.#cleanup = void 0;
		}
	}
	setEventListener(setup) {
		this.#setup = setup;
		this.#cleanup?.();
		this.#cleanup = setup(this.setOnline.bind(this));
	}
	setOnline(online) {
		if (this.#online !== online) {
			this.#online = online;
			this.listeners.forEach((listener) => {
				listener(online);
			});
		}
	}
	isOnline() {
		return this.#online;
	}
};
var onlineManager = new OnlineManager();
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/retryer.js
function defaultRetryDelay(failureCount) {
	return Math.min(1e3 * 2 ** failureCount, 3e4);
}
function canFetch(networkMode) {
	return (networkMode ?? "online") === "online" ? onlineManager.isOnline() : true;
}
var CancelledError = class extends Error {
	constructor(options) {
		super("CancelledError");
		this.revert = options?.revert;
		this.silent = options?.silent;
	}
};
function isCancelledError(value) {
	return value instanceof CancelledError;
}
function createRetryer(config) {
	let isRetryCancelled = false;
	let failureCount = 0;
	let continueFn;
	const thenable = pendingThenable();
	const isResolved = () => thenable.status !== "pending";
	const cancel = (cancelOptions) => {
		if (!isResolved()) {
			const error = new CancelledError(cancelOptions);
			reject(error);
			config.onCancel?.(error);
		}
	};
	const cancelRetry = () => {
		isRetryCancelled = true;
	};
	const continueRetry = () => {
		isRetryCancelled = false;
	};
	const canContinue = () => focusManager.isFocused() && (config.networkMode === "always" || onlineManager.isOnline()) && config.canRun();
	const canStart = () => canFetch(config.networkMode) && config.canRun();
	const resolve = (value) => {
		if (!isResolved()) {
			continueFn?.();
			thenable.resolve(value);
		}
	};
	const reject = (value) => {
		if (!isResolved()) {
			continueFn?.();
			thenable.reject(value);
		}
	};
	const pause = () => {
		return new Promise((continueResolve) => {
			continueFn = (value) => {
				if (isResolved() || canContinue()) continueResolve(value);
			};
			config.onPause?.();
		}).then(() => {
			continueFn = void 0;
			if (!isResolved()) config.onContinue?.();
		});
	};
	const run = () => {
		if (isResolved()) return;
		let promiseOrValue;
		const initialPromise = failureCount === 0 ? config.initialPromise : void 0;
		try {
			promiseOrValue = initialPromise ?? config.fn();
		} catch (error) {
			promiseOrValue = Promise.reject(error);
		}
		Promise.resolve(promiseOrValue).then(resolve).catch((error) => {
			if (isResolved()) return;
			const retry = config.retry ?? (environmentManager.isServer() ? 0 : 3);
			const retryDelay = config.retryDelay ?? defaultRetryDelay;
			const delay = typeof retryDelay === "function" ? retryDelay(failureCount, error) : retryDelay;
			const shouldRetry = retry === true || typeof retry === "number" && failureCount < retry || typeof retry === "function" && retry(failureCount, error);
			if (isRetryCancelled || !shouldRetry) {
				reject(error);
				return;
			}
			failureCount++;
			config.onFail?.(failureCount, error);
			sleep(delay).then(() => {
				return canContinue() ? void 0 : pause();
			}).then(() => {
				if (isRetryCancelled) reject(error);
				else run();
			});
		});
	};
	return {
		promise: thenable,
		status: () => thenable.status,
		cancel,
		continue: () => {
			continueFn?.();
			return thenable;
		},
		cancelRetry,
		continueRetry,
		canStart,
		start: () => {
			if (canStart()) run();
			else pause().then(run);
			return thenable;
		}
	};
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/removable.js
var Removable = class {
	#gcTimeout;
	destroy() {
		this.clearGcTimeout();
	}
	scheduleGc() {
		this.clearGcTimeout();
		if (isValidTimeout(this.gcTime)) this.#gcTimeout = timeoutManager.setTimeout(() => {
			this.optionalRemove();
		}, this.gcTime);
	}
	updateGcTime(newGcTime) {
		this.gcTime = Math.max(this.gcTime || 0, newGcTime ?? (environmentManager.isServer() ? Infinity : 3e5));
	}
	clearGcTimeout() {
		if (this.#gcTimeout !== void 0) {
			timeoutManager.clearTimeout(this.#gcTimeout);
			this.#gcTimeout = void 0;
		}
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/infiniteQueryBehavior.js
function infiniteQueryBehavior(pages) {
	return { onFetch: (context, query) => {
		const options = context.options;
		const direction = context.fetchOptions?.meta?.fetchMore?.direction;
		const oldPages = context.state.data?.pages || [];
		const oldPageParams = context.state.data?.pageParams || [];
		let result = {
			pages: [],
			pageParams: []
		};
		let currentPage = 0;
		const fetchFn = async () => {
			let cancelled = false;
			const addSignalProperty = (object) => {
				addConsumeAwareSignal(object, () => context.signal, () => cancelled = true);
			};
			const queryFn = ensureQueryFn(context.options, context.fetchOptions);
			const fetchPage = async (data, param, previous) => {
				if (cancelled) return Promise.reject(context.signal.reason);
				if (param == null && data.pages.length) return Promise.resolve(data);
				const createQueryFnContext = () => {
					const queryFnContext2 = {
						client: context.client,
						queryKey: context.queryKey,
						pageParam: param,
						direction: previous ? "backward" : "forward",
						meta: context.options.meta
					};
					addSignalProperty(queryFnContext2);
					return queryFnContext2;
				};
				const queryFnContext = createQueryFnContext();
				const page = await queryFn(queryFnContext);
				const { maxPages } = context.options;
				const addTo = previous ? addToStart : addToEnd;
				return {
					pages: addTo(data.pages, page, maxPages),
					pageParams: addTo(data.pageParams, param, maxPages)
				};
			};
			if (direction && oldPages.length) {
				const previous = direction === "backward";
				const pageParamFn = previous ? getPreviousPageParam : getNextPageParam;
				const oldData = {
					pages: oldPages,
					pageParams: oldPageParams
				};
				result = await fetchPage(oldData, pageParamFn(options, oldData), previous);
			} else {
				const remainingPages = pages ?? oldPages.length;
				do {
					const param = currentPage === 0 ? oldPageParams[0] ?? options.initialPageParam : getNextPageParam(options, result);
					if (currentPage > 0 && param == null) break;
					result = await fetchPage(result, param);
					currentPage++;
				} while (currentPage < remainingPages);
			}
			return result;
		};
		if (context.options.persister) context.fetchFn = () => {
			return context.options.persister?.(fetchFn, {
				client: context.client,
				queryKey: context.queryKey,
				meta: context.options.meta,
				signal: context.signal
			}, query);
		};
		else context.fetchFn = fetchFn;
	} };
}
function getNextPageParam(options, { pages, pageParams }) {
	const lastIndex = pages.length - 1;
	return pages.length > 0 ? options.getNextPageParam(pages[lastIndex], pages, pageParams[lastIndex], pageParams) : void 0;
}
function getPreviousPageParam(options, { pages, pageParams }) {
	return pages.length > 0 ? options.getPreviousPageParam?.(pages[0], pages, pageParams[0], pageParams) : void 0;
}
function hasNextPage(options, data) {
	if (!data) return false;
	return getNextPageParam(options, data) != null;
}
function hasPreviousPage(options, data) {
	if (!data || !options.getPreviousPageParam) return false;
	return getPreviousPageParam(options, data) != null;
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/query.js
var Query = class extends Removable {
	#queryType;
	#initialState;
	#revertState;
	#cache;
	#client;
	#retryer;
	#defaultOptions;
	#abortSignalConsumed;
	constructor(config) {
		super();
		this.#abortSignalConsumed = false;
		this.#defaultOptions = config.defaultOptions;
		this.setOptions(config.options);
		this.observers = [];
		this.#client = config.client;
		this.#cache = this.#client.getQueryCache();
		this.queryKey = config.queryKey;
		this.queryHash = config.queryHash;
		this.#initialState = getDefaultState$1(this.options);
		this.state = config.state ?? this.#initialState;
		this.scheduleGc();
	}
	get meta() {
		return this.options.meta;
	}
	get queryType() {
		return this.#queryType;
	}
	get promise() {
		return this.#retryer?.promise;
	}
	setOptions(options) {
		this.options = {
			...this.#defaultOptions,
			...options
		};
		if (options?._type) this.#queryType = options._type;
		this.updateGcTime(this.options.gcTime);
		if (this.state && this.state.data === void 0) {
			const defaultState = getDefaultState$1(this.options);
			if (defaultState.data !== void 0) {
				this.setState(successState(defaultState.data, defaultState.dataUpdatedAt));
				this.#initialState = defaultState;
			}
		}
	}
	optionalRemove() {
		if (!this.observers.length && this.state.fetchStatus === "idle") this.#cache.remove(this);
	}
	setData(newData, options) {
		const data = replaceData(this.state.data, newData, this.options);
		this.#dispatch({
			data,
			type: "success",
			dataUpdatedAt: options?.updatedAt,
			manual: options?.manual
		});
		return data;
	}
	setState(state) {
		this.#dispatch({
			type: "setState",
			state
		});
	}
	cancel(options) {
		const promise = this.#retryer?.promise;
		this.#retryer?.cancel(options);
		return promise ? promise.then(noop).catch(noop) : Promise.resolve();
	}
	destroy() {
		super.destroy();
		this.cancel({ silent: true });
	}
	get resetState() {
		return this.#initialState;
	}
	reset() {
		this.destroy();
		this.setState(this.resetState);
	}
	isActive() {
		return this.observers.some((observer) => resolveQueryBoolean(observer.options.enabled, this) !== false);
	}
	isDisabled() {
		if (this.getObserversCount() > 0) return !this.isActive();
		return this.options.queryFn === skipToken || !this.isFetched();
	}
	isFetched() {
		return this.state.dataUpdateCount + this.state.errorUpdateCount > 0;
	}
	isStatic() {
		if (this.getObserversCount() > 0) return this.observers.some((observer) => resolveStaleTime(observer.options.staleTime, this) === "static");
		return false;
	}
	isStale() {
		if (this.getObserversCount() > 0) return this.observers.some((observer) => observer.getCurrentResult().isStale);
		return this.state.data === void 0 || this.state.isInvalidated;
	}
	isStaleByTime(staleTime = 0) {
		if (this.state.data === void 0) return true;
		if (staleTime === "static") return false;
		if (this.state.isInvalidated) return true;
		return !timeUntilStale(this.state.dataUpdatedAt, staleTime);
	}
	onFocus() {
		this.observers.find((x) => x.shouldFetchOnWindowFocus())?.refetch({ cancelRefetch: false });
		this.#retryer?.continue();
	}
	onOnline() {
		this.observers.find((x) => x.shouldFetchOnReconnect())?.refetch({ cancelRefetch: false });
		this.#retryer?.continue();
	}
	addObserver(observer) {
		if (!this.observers.includes(observer)) {
			this.observers.push(observer);
			this.clearGcTimeout();
			this.#cache.notify({
				type: "observerAdded",
				query: this,
				observer
			});
		}
	}
	removeObserver(observer) {
		if (this.observers.includes(observer)) {
			this.observers = this.observers.filter((x) => x !== observer);
			if (!this.observers.length) {
				if (this.#retryer) {
					if (this.#abortSignalConsumed || this.#isInitialPausedFetch()) this.#retryer.cancel({ revert: true });
					else this.#retryer.cancelRetry();
				}
				this.scheduleGc();
			}
			this.#cache.notify({
				type: "observerRemoved",
				query: this,
				observer
			});
		}
	}
	getObserversCount() {
		return this.observers.length;
	}
	#isInitialPausedFetch() {
		return this.state.fetchStatus === "paused" && this.state.status === "pending";
	}
	invalidate() {
		if (!this.state.isInvalidated) this.#dispatch({ type: "invalidate" });
	}
	async fetch(options, fetchOptions) {
		if (this.state.fetchStatus !== "idle" && this.#retryer?.status() !== "rejected") {
			if (this.state.data !== void 0 && fetchOptions?.cancelRefetch) this.cancel({ silent: true });
			else if (this.#retryer) {
				this.#retryer.continueRetry();
				return this.#retryer.promise;
			}
		}
		if (options) this.setOptions(options);
		if (!this.options.queryFn) {
			const observer = this.observers.find((x) => x.options.queryFn);
			if (observer) this.setOptions(observer.options);
		}
		if (!Array.isArray(this.options.queryKey)) console.error(`As of v4, queryKey needs to be an Array. If you are using a string like 'repoData', please change it to an Array, e.g. ['repoData']`);
		const abortController = new AbortController();
		const addSignalProperty = (object) => {
			Object.defineProperty(object, "signal", {
				enumerable: true,
				get: () => {
					this.#abortSignalConsumed = true;
					return abortController.signal;
				}
			});
		};
		const fetchFn = () => {
			const queryFn = ensureQueryFn(this.options, fetchOptions);
			const createQueryFnContext = () => {
				const queryFnContext2 = {
					client: this.#client,
					queryKey: this.queryKey,
					meta: this.meta
				};
				addSignalProperty(queryFnContext2);
				return queryFnContext2;
			};
			const queryFnContext = createQueryFnContext();
			this.#abortSignalConsumed = false;
			if (this.options.persister) return this.options.persister(queryFn, queryFnContext, this);
			return queryFn(queryFnContext);
		};
		const createFetchContext = () => {
			const context2 = {
				fetchOptions,
				options: this.options,
				queryKey: this.queryKey,
				client: this.#client,
				state: this.state,
				fetchFn
			};
			addSignalProperty(context2);
			return context2;
		};
		const context = createFetchContext();
		(this.#queryType === "infinite" ? infiniteQueryBehavior(this.options.pages) : this.options.behavior)?.onFetch(context, this);
		this.#revertState = this.state;
		if (this.state.fetchStatus === "idle" || this.state.fetchMeta !== context.fetchOptions?.meta) this.#dispatch({
			type: "fetch",
			meta: context.fetchOptions?.meta
		});
		this.#retryer = createRetryer({
			initialPromise: fetchOptions?.initialPromise,
			fn: context.fetchFn,
			onCancel: (error) => {
				if (error instanceof CancelledError && error.revert) this.setState({
					...this.#revertState,
					fetchStatus: "idle"
				});
				abortController.abort();
			},
			onFail: (failureCount, error) => {
				this.#dispatch({
					type: "failed",
					failureCount,
					error
				});
			},
			onPause: () => {
				this.#dispatch({ type: "pause" });
			},
			onContinue: () => {
				this.#dispatch({ type: "continue" });
			},
			retry: context.options.retry,
			retryDelay: context.options.retryDelay,
			networkMode: context.options.networkMode,
			canRun: () => true
		});
		try {
			const data = await this.#retryer.start();
			if (data === void 0) {
				console.error(`Query data cannot be undefined. Please make sure to return a value other than undefined from your query function. Affected query key: ${this.queryHash}`);
				throw new Error(`${this.queryHash} data is undefined`);
			}
			this.setData(data);
			this.#cache.config.onSuccess?.(data, this);
			this.#cache.config.onSettled?.(data, this.state.error, this);
			return data;
		} catch (error) {
			if (error instanceof CancelledError) {
				if (error.silent) return this.#retryer.promise;
				else if (error.revert) {
					if (this.state.data === void 0) throw error;
					return this.state.data;
				}
			}
			this.#dispatch({
				type: "error",
				error
			});
			this.#cache.config.onError?.(error, this);
			this.#cache.config.onSettled?.(this.state.data, error, this);
			throw error;
		} finally {
			this.scheduleGc();
		}
	}
	#dispatch(action) {
		const reducer = (state) => {
			switch (action.type) {
				case "failed": return {
					...state,
					fetchFailureCount: action.failureCount,
					fetchFailureReason: action.error
				};
				case "pause": return {
					...state,
					fetchStatus: "paused"
				};
				case "continue": return {
					...state,
					fetchStatus: "fetching"
				};
				case "fetch": return {
					...state,
					...fetchState(state.data, this.options),
					fetchMeta: action.meta ?? null
				};
				case "success":
					const newState = {
						...state,
						...successState(action.data, action.dataUpdatedAt),
						dataUpdateCount: state.dataUpdateCount + 1,
						...!action.manual && {
							fetchStatus: "idle",
							fetchFailureCount: 0,
							fetchFailureReason: null
						}
					};
					this.#revertState = action.manual ? newState : void 0;
					return newState;
				case "error":
					const error = action.error;
					return {
						...state,
						error,
						errorUpdateCount: state.errorUpdateCount + 1,
						errorUpdatedAt: Date.now(),
						fetchFailureCount: state.fetchFailureCount + 1,
						fetchFailureReason: error,
						fetchStatus: "idle",
						status: "error",
						isInvalidated: true
					};
				case "invalidate": return {
					...state,
					isInvalidated: true
				};
				case "setState": return {
					...state,
					...action.state
				};
			}
		};
		this.state = reducer(this.state);
		notifyManager.batch(() => {
			this.observers.forEach((observer) => {
				observer.onQueryUpdate();
			});
			this.#cache.notify({
				query: this,
				type: "updated",
				action
			});
		});
	}
};
function fetchState(data, options) {
	return {
		fetchFailureCount: 0,
		fetchFailureReason: null,
		fetchStatus: canFetch(options.networkMode) ? "fetching" : "paused",
		...data === void 0 && {
			error: null,
			status: "pending"
		}
	};
}
function successState(data, dataUpdatedAt) {
	return {
		data,
		dataUpdatedAt: dataUpdatedAt ?? Date.now(),
		error: null,
		isInvalidated: false,
		status: "success"
	};
}
function getDefaultState$1(options) {
	const data = typeof options.initialData === "function" ? options.initialData() : options.initialData;
	const hasData = data !== void 0;
	const initialDataUpdatedAt = hasData ? typeof options.initialDataUpdatedAt === "function" ? options.initialDataUpdatedAt() : options.initialDataUpdatedAt : 0;
	return {
		data,
		dataUpdateCount: 0,
		dataUpdatedAt: hasData ? initialDataUpdatedAt ?? Date.now() : 0,
		error: null,
		errorUpdateCount: 0,
		errorUpdatedAt: 0,
		fetchFailureCount: 0,
		fetchFailureReason: null,
		fetchMeta: null,
		isInvalidated: false,
		status: hasData ? "success" : "pending",
		fetchStatus: "idle"
	};
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queryObserver.js
var QueryObserver = class extends Subscribable {
	constructor(client, options) {
		super();
		this.options = options;
		this.#client = client;
		this.#selectError = null;
		this.#currentThenable = pendingThenable();
		this.bindMethods();
		this.setOptions(options);
	}
	#client;
	#currentQuery = void 0;
	#currentQueryInitialState = void 0;
	#currentResult = void 0;
	#currentResultState;
	#currentResultOptions;
	#currentThenable;
	#selectError;
	#selectFn;
	#selectResult;
	#lastQueryWithDefinedData;
	#staleTimeoutId;
	#refetchIntervalId;
	#currentRefetchInterval;
	#trackedProps = /* @__PURE__ */ new Set();
	bindMethods() {
		this.refetch = this.refetch.bind(this);
	}
	onSubscribe() {
		if (this.listeners.size === 1) {
			this.#currentQuery.addObserver(this);
			if (shouldFetchOnMount(this.#currentQuery, this.options)) this.#executeFetch();
			else this.updateResult();
			this.#updateTimers();
		}
	}
	onUnsubscribe() {
		if (!this.hasListeners()) this.destroy();
	}
	shouldFetchOnReconnect() {
		return shouldFetchOn(this.#currentQuery, this.options, this.options.refetchOnReconnect);
	}
	shouldFetchOnWindowFocus() {
		return shouldFetchOn(this.#currentQuery, this.options, this.options.refetchOnWindowFocus);
	}
	destroy() {
		this.listeners = /* @__PURE__ */ new Set();
		this.#clearStaleTimeout();
		this.#clearRefetchInterval();
		this.#currentQuery.removeObserver(this);
	}
	setOptions(options) {
		const prevOptions = this.options;
		const prevQuery = this.#currentQuery;
		this.options = this.#client.defaultQueryOptions(options);
		if (this.options.enabled !== void 0 && typeof this.options.enabled !== "boolean" && typeof this.options.enabled !== "function" && typeof resolveQueryBoolean(this.options.enabled, this.#currentQuery) !== "boolean") throw new Error("Expected enabled to be a boolean or a callback that returns a boolean");
		this.#updateQuery();
		this.#currentQuery.setOptions(this.options);
		if (prevOptions._defaulted && !shallowEqualObjects(this.options, prevOptions)) this.#client.getQueryCache().notify({
			type: "observerOptionsUpdated",
			query: this.#currentQuery,
			observer: this
		});
		const mounted = this.hasListeners();
		if (mounted && shouldFetchOptionally(this.#currentQuery, prevQuery, this.options, prevOptions)) this.#executeFetch();
		this.updateResult();
		if (mounted && (this.#currentQuery !== prevQuery || resolveQueryBoolean(this.options.enabled, this.#currentQuery) !== resolveQueryBoolean(prevOptions.enabled, this.#currentQuery) || resolveStaleTime(this.options.staleTime, this.#currentQuery) !== resolveStaleTime(prevOptions.staleTime, this.#currentQuery))) this.#updateStaleTimeout();
		const nextRefetchInterval = this.#computeRefetchInterval();
		if (mounted && (this.#currentQuery !== prevQuery || resolveQueryBoolean(this.options.enabled, this.#currentQuery) !== resolveQueryBoolean(prevOptions.enabled, this.#currentQuery) || nextRefetchInterval !== this.#currentRefetchInterval)) this.#updateRefetchInterval(nextRefetchInterval);
	}
	getOptimisticResult(options) {
		const query = this.#client.getQueryCache().build(this.#client, options);
		const result = this.createResult(query, options);
		if (shouldAssignObserverCurrentProperties(this, result)) {
			this.#currentResult = result;
			this.#currentResultOptions = this.options;
			this.#currentResultState = this.#currentQuery.state;
		}
		return result;
	}
	getCurrentResult() {
		return this.#currentResult;
	}
	trackResult(result, onPropTracked) {
		return new Proxy(result, { get: (target, key) => {
			this.trackProp(key);
			onPropTracked?.(key);
			if (key === "promise") {
				this.trackProp("data");
				if (!this.options.experimental_prefetchInRender && this.#currentThenable.status === "pending") this.#currentThenable.reject(/* @__PURE__ */ new Error("experimental_prefetchInRender feature flag is not enabled"));
			}
			return Reflect.get(target, key);
		} });
	}
	trackProp(key) {
		this.#trackedProps.add(key);
	}
	getCurrentQuery() {
		return this.#currentQuery;
	}
	refetch({ ...options } = {}) {
		return this.fetch({ ...options });
	}
	fetchOptimistic(options) {
		const defaultedOptions = this.#client.defaultQueryOptions(options);
		const query = this.#client.getQueryCache().build(this.#client, defaultedOptions);
		return query.fetch().then(() => this.createResult(query, defaultedOptions));
	}
	fetch(fetchOptions) {
		return this.#executeFetch({
			...fetchOptions,
			cancelRefetch: fetchOptions.cancelRefetch ?? true
		}).then(() => {
			this.updateResult();
			return this.#currentResult;
		});
	}
	#executeFetch(fetchOptions) {
		this.#updateQuery();
		let promise = this.#currentQuery.fetch(this.options, fetchOptions);
		if (!fetchOptions?.throwOnError) promise = promise.catch(noop);
		return promise;
	}
	#updateStaleTimeout() {
		this.#clearStaleTimeout();
		const staleTime = resolveStaleTime(this.options.staleTime, this.#currentQuery);
		if (environmentManager.isServer() || this.#currentResult.isStale || !isValidTimeout(staleTime)) return;
		const timeout = timeUntilStale(this.#currentResult.dataUpdatedAt, staleTime) + 1;
		this.#staleTimeoutId = timeoutManager.setTimeout(() => {
			if (!this.#currentResult.isStale) this.updateResult();
		}, timeout);
	}
	#computeRefetchInterval() {
		return (typeof this.options.refetchInterval === "function" ? this.options.refetchInterval(this.#currentQuery) : this.options.refetchInterval) ?? false;
	}
	#updateRefetchInterval(nextInterval) {
		this.#clearRefetchInterval();
		this.#currentRefetchInterval = nextInterval;
		if (environmentManager.isServer() || resolveQueryBoolean(this.options.enabled, this.#currentQuery) === false || !isValidTimeout(this.#currentRefetchInterval) || this.#currentRefetchInterval === 0) return;
		this.#refetchIntervalId = timeoutManager.setInterval(() => {
			if (this.options.refetchIntervalInBackground || focusManager.isFocused()) this.#executeFetch();
		}, this.#currentRefetchInterval);
	}
	#updateTimers() {
		this.#updateStaleTimeout();
		this.#updateRefetchInterval(this.#computeRefetchInterval());
	}
	#clearStaleTimeout() {
		if (this.#staleTimeoutId !== void 0) {
			timeoutManager.clearTimeout(this.#staleTimeoutId);
			this.#staleTimeoutId = void 0;
		}
	}
	#clearRefetchInterval() {
		if (this.#refetchIntervalId !== void 0) {
			timeoutManager.clearInterval(this.#refetchIntervalId);
			this.#refetchIntervalId = void 0;
		}
	}
	createResult(query, options) {
		const prevQuery = this.#currentQuery;
		const prevOptions = this.options;
		const prevResult = this.#currentResult;
		const prevResultState = this.#currentResultState;
		const prevResultOptions = this.#currentResultOptions;
		const queryInitialState = query !== prevQuery ? query.state : this.#currentQueryInitialState;
		const { state } = query;
		let newState = { ...state };
		let isPlaceholderData = false;
		let data;
		if (options._optimisticResults) {
			const mounted = this.hasListeners();
			const fetchOnMount = !mounted && shouldFetchOnMount(query, options);
			const fetchOptionally = mounted && shouldFetchOptionally(query, prevQuery, options, prevOptions);
			if (fetchOnMount || fetchOptionally) newState = {
				...newState,
				...fetchState(state.data, query.options)
			};
			if (options._optimisticResults === "isRestoring") newState.fetchStatus = "idle";
		}
		let { error, errorUpdatedAt, status } = newState;
		data = newState.data;
		let skipSelect = false;
		if (options.placeholderData !== void 0 && data === void 0 && status === "pending") {
			let placeholderData;
			if (prevResult?.isPlaceholderData && options.placeholderData === prevResultOptions?.placeholderData) {
				placeholderData = prevResult.data;
				skipSelect = true;
			} else placeholderData = typeof options.placeholderData === "function" ? options.placeholderData(this.#lastQueryWithDefinedData?.state.data, this.#lastQueryWithDefinedData) : options.placeholderData;
			if (placeholderData !== void 0) {
				status = "success";
				data = replaceData(prevResult?.data, placeholderData, options);
				isPlaceholderData = true;
			}
		}
		if (options.select && data !== void 0 && !skipSelect) {
			if (prevResult && data === prevResultState?.data && options.select === this.#selectFn) data = this.#selectResult;
			else try {
				this.#selectFn = options.select;
				data = options.select(data);
				data = replaceData(prevResult?.data, data, options);
				this.#selectResult = data;
				this.#selectError = null;
			} catch (selectError) {
				this.#selectError = selectError;
			}
		}
		if (this.#selectError) {
			error = this.#selectError;
			data = this.#selectResult;
			errorUpdatedAt = Date.now();
			status = "error";
		}
		const isFetching = newState.fetchStatus === "fetching";
		const isPending = status === "pending";
		const isError = status === "error";
		const isLoading = isPending && isFetching;
		const hasData = data !== void 0;
		const nextResult = {
			status,
			fetchStatus: newState.fetchStatus,
			isPending,
			isSuccess: status === "success",
			isError,
			isInitialLoading: isLoading,
			isLoading,
			data,
			dataUpdatedAt: newState.dataUpdatedAt,
			error,
			errorUpdatedAt,
			failureCount: newState.fetchFailureCount,
			failureReason: newState.fetchFailureReason,
			errorUpdateCount: newState.errorUpdateCount,
			isFetched: query.isFetched(),
			isFetchedAfterMount: newState.dataUpdateCount > queryInitialState.dataUpdateCount || newState.errorUpdateCount > queryInitialState.errorUpdateCount,
			isFetching,
			isRefetching: isFetching && !isPending,
			isLoadingError: isError && !hasData,
			isPaused: newState.fetchStatus === "paused",
			isPlaceholderData,
			isRefetchError: isError && hasData,
			isStale: isStale(query, options),
			refetch: this.refetch,
			promise: this.#currentThenable,
			isEnabled: resolveQueryBoolean(options.enabled, query) !== false
		};
		if (this.options.experimental_prefetchInRender) {
			const hasResultData = nextResult.data !== void 0;
			const isErrorWithoutData = nextResult.status === "error" && !hasResultData;
			const finalizeThenableIfPossible = (thenable) => {
				if (isErrorWithoutData) thenable.reject(nextResult.error);
				else if (hasResultData) thenable.resolve(nextResult.data);
			};
			const recreateThenable = () => {
				const pending = this.#currentThenable = nextResult.promise = pendingThenable();
				finalizeThenableIfPossible(pending);
			};
			const prevThenable = this.#currentThenable;
			switch (prevThenable.status) {
				case "pending":
					if (query.queryHash === prevQuery.queryHash) finalizeThenableIfPossible(prevThenable);
					break;
				case "fulfilled":
					if (isErrorWithoutData || nextResult.data !== prevThenable.value) recreateThenable();
					break;
				case "rejected": if (!isErrorWithoutData || nextResult.error !== prevThenable.reason) recreateThenable();
			}
		}
		return nextResult;
	}
	updateResult() {
		const prevResult = this.#currentResult;
		const nextResult = this.createResult(this.#currentQuery, this.options);
		this.#currentResultState = this.#currentQuery.state;
		this.#currentResultOptions = this.options;
		if (this.#currentResultState.data !== void 0) this.#lastQueryWithDefinedData = this.#currentQuery;
		if (shallowEqualObjects(nextResult, prevResult)) return;
		this.#currentResult = nextResult;
		const shouldNotifyListeners = () => {
			if (!prevResult) return true;
			const { notifyOnChangeProps } = this.options;
			const notifyOnChangePropsValue = typeof notifyOnChangeProps === "function" ? notifyOnChangeProps() : notifyOnChangeProps;
			if (notifyOnChangePropsValue === "all" || !notifyOnChangePropsValue && !this.#trackedProps.size) return true;
			const includedProps = new Set(notifyOnChangePropsValue ?? this.#trackedProps);
			if (this.options.throwOnError) includedProps.add("error");
			return Object.keys(this.#currentResult).some((key) => {
				const typedKey = key;
				return this.#currentResult[typedKey] !== prevResult[typedKey] && includedProps.has(typedKey);
			});
		};
		this.#notify({ listeners: shouldNotifyListeners() });
	}
	#updateQuery() {
		const query = this.#client.getQueryCache().build(this.#client, this.options);
		if (query === this.#currentQuery) return;
		const prevQuery = this.#currentQuery;
		this.#currentQuery = query;
		this.#currentQueryInitialState = query.state;
		if (this.hasListeners()) {
			prevQuery?.removeObserver(this);
			query.addObserver(this);
		}
	}
	onQueryUpdate() {
		this.updateResult();
		if (this.hasListeners()) this.#updateTimers();
	}
	#notify(notifyOptions) {
		notifyManager.batch(() => {
			if (notifyOptions.listeners) this.listeners.forEach((listener) => {
				listener(this.#currentResult);
			});
			this.#client.getQueryCache().notify({
				query: this.#currentQuery,
				type: "observerResultsUpdated"
			});
		});
	}
};
function shouldLoadOnMount(query, options) {
	return resolveQueryBoolean(options.enabled, query) !== false && query.state.data === void 0 && !(query.state.status === "error" && resolveQueryBoolean(options.retryOnMount, query) === false);
}
function shouldFetchOnMount(query, options) {
	return shouldLoadOnMount(query, options) || query.state.data !== void 0 && shouldFetchOn(query, options, options.refetchOnMount);
}
function shouldFetchOn(query, options, field) {
	if (resolveQueryBoolean(options.enabled, query) !== false && resolveStaleTime(options.staleTime, query) !== "static") {
		const value = typeof field === "function" ? field(query) : field;
		return value === "always" || value !== false && isStale(query, options);
	}
	return false;
}
function shouldFetchOptionally(query, prevQuery, options, prevOptions) {
	return (query !== prevQuery || resolveQueryBoolean(prevOptions.enabled, query) === false) && (!options.suspense || query.state.status !== "error") && isStale(query, options);
}
function isStale(query, options) {
	return resolveQueryBoolean(options.enabled, query) !== false && query.isStaleByTime(resolveStaleTime(options.staleTime, query));
}
function shouldAssignObserverCurrentProperties(observer, optimisticResult) {
	if (!shallowEqualObjects(observer.getCurrentResult(), optimisticResult)) return true;
	return false;
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/infiniteQueryObserver.js
var InfiniteQueryObserver = class extends QueryObserver {
	constructor(client, options) {
		super(client, options);
	}
	bindMethods() {
		super.bindMethods();
		this.fetchNextPage = this.fetchNextPage.bind(this);
		this.fetchPreviousPage = this.fetchPreviousPage.bind(this);
	}
	setOptions(options) {
		options._type = "infinite";
		super.setOptions(options);
	}
	getOptimisticResult(options) {
		options._type = "infinite";
		return super.getOptimisticResult(options);
	}
	fetchNextPage(options) {
		return this.fetch({
			...options,
			meta: { fetchMore: { direction: "forward" } }
		});
	}
	fetchPreviousPage(options) {
		return this.fetch({
			...options,
			meta: { fetchMore: { direction: "backward" } }
		});
	}
	createResult(query, options) {
		const { state } = query;
		const parentResult = super.createResult(query, options);
		const { isFetching, isRefetching, isError, isRefetchError } = parentResult;
		const fetchDirection = state.fetchMeta?.fetchMore?.direction;
		const isFetchNextPageError = isError && fetchDirection === "forward";
		const isFetchingNextPage = isFetching && fetchDirection === "forward";
		const isFetchPreviousPageError = isError && fetchDirection === "backward";
		const isFetchingPreviousPage = isFetching && fetchDirection === "backward";
		return {
			...parentResult,
			fetchNextPage: this.fetchNextPage,
			fetchPreviousPage: this.fetchPreviousPage,
			hasNextPage: hasNextPage(options, state.data),
			hasPreviousPage: hasPreviousPage(options, state.data),
			isFetchNextPageError,
			isFetchingNextPage,
			isFetchPreviousPageError,
			isFetchingPreviousPage,
			isRefetchError: isRefetchError && !isFetchNextPageError && !isFetchPreviousPageError,
			isRefetching: isRefetching && !isFetchingNextPage && !isFetchingPreviousPage
		};
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/mutation.js
var Mutation = class extends Removable {
	#client;
	#observers;
	#mutationCache;
	#retryer;
	constructor(config) {
		super();
		this.#client = config.client;
		this.mutationId = config.mutationId;
		this.#mutationCache = config.mutationCache;
		this.#observers = [];
		this.state = config.state || getDefaultState();
		this.setOptions(config.options);
		this.scheduleGc();
	}
	setOptions(options) {
		this.options = options;
		this.updateGcTime(this.options.gcTime);
	}
	get meta() {
		return this.options.meta;
	}
	addObserver(observer) {
		if (!this.#observers.includes(observer)) {
			this.#observers.push(observer);
			this.clearGcTimeout();
			this.#mutationCache.notify({
				type: "observerAdded",
				mutation: this,
				observer
			});
		}
	}
	removeObserver(observer) {
		this.#observers = this.#observers.filter((x) => x !== observer);
		this.scheduleGc();
		this.#mutationCache.notify({
			type: "observerRemoved",
			mutation: this,
			observer
		});
	}
	optionalRemove() {
		if (!this.#observers.length) {
			if (this.state.status === "pending") this.scheduleGc();
			else this.#mutationCache.remove(this);
		}
	}
	continue() {
		return this.#retryer?.continue() ?? this.execute(this.state.variables);
	}
	async execute(variables) {
		const onContinue = () => {
			this.#dispatch({ type: "continue" });
		};
		const mutationFnContext = {
			client: this.#client,
			meta: this.options.meta,
			mutationKey: this.options.mutationKey
		};
		this.#retryer = createRetryer({
			fn: () => {
				if (!this.options.mutationFn) return Promise.reject(/* @__PURE__ */ new Error("No mutationFn found"));
				return this.options.mutationFn(variables, mutationFnContext);
			},
			onFail: (failureCount, error) => {
				this.#dispatch({
					type: "failed",
					failureCount,
					error
				});
			},
			onPause: () => {
				this.#dispatch({ type: "pause" });
			},
			onContinue,
			retry: this.options.retry ?? 0,
			retryDelay: this.options.retryDelay,
			networkMode: this.options.networkMode,
			canRun: () => this.#mutationCache.canRun(this)
		});
		const restored = this.state.status === "pending";
		const isPaused = !this.#retryer.canStart();
		try {
			if (restored) onContinue();
			else {
				this.#dispatch({
					type: "pending",
					variables,
					isPaused
				});
				if (this.#mutationCache.config.onMutate) await this.#mutationCache.config.onMutate(variables, this, mutationFnContext);
				const context = await this.options.onMutate?.(variables, mutationFnContext);
				if (context !== this.state.context) this.#dispatch({
					type: "pending",
					context,
					variables,
					isPaused
				});
			}
			const data = await this.#retryer.start();
			await this.#mutationCache.config.onSuccess?.(data, variables, this.state.context, this, mutationFnContext);
			await this.options.onSuccess?.(data, variables, this.state.context, mutationFnContext);
			await this.#mutationCache.config.onSettled?.(data, null, this.state.variables, this.state.context, this, mutationFnContext);
			await this.options.onSettled?.(data, null, variables, this.state.context, mutationFnContext);
			this.#dispatch({
				type: "success",
				data
			});
			return data;
		} catch (error) {
			try {
				await this.#mutationCache.config.onError?.(error, variables, this.state.context, this, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.options.onError?.(error, variables, this.state.context, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.#mutationCache.config.onSettled?.(void 0, error, this.state.variables, this.state.context, this, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.options.onSettled?.(void 0, error, variables, this.state.context, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			this.#dispatch({
				type: "error",
				error
			});
			throw error;
		} finally {
			this.#mutationCache.runNext(this);
		}
	}
	#dispatch(action) {
		const reducer = (state) => {
			switch (action.type) {
				case "failed": return {
					...state,
					failureCount: action.failureCount,
					failureReason: action.error
				};
				case "pause": return {
					...state,
					isPaused: true
				};
				case "continue": return {
					...state,
					isPaused: false
				};
				case "pending": return {
					...state,
					context: action.context,
					data: void 0,
					failureCount: 0,
					failureReason: null,
					error: null,
					isPaused: action.isPaused,
					status: "pending",
					variables: action.variables,
					submittedAt: Date.now()
				};
				case "success": return {
					...state,
					data: action.data,
					failureCount: 0,
					failureReason: null,
					error: null,
					status: "success",
					isPaused: false
				};
				case "error": return {
					...state,
					data: void 0,
					error: action.error,
					failureCount: state.failureCount + 1,
					failureReason: action.error,
					isPaused: false,
					status: "error"
				};
			}
		};
		this.state = reducer(this.state);
		notifyManager.batch(() => {
			this.#observers.forEach((observer) => {
				observer.onMutationUpdate(action);
			});
			this.#mutationCache.notify({
				mutation: this,
				type: "updated",
				action
			});
		});
	}
};
function getDefaultState() {
	return {
		context: void 0,
		data: void 0,
		error: null,
		failureCount: 0,
		failureReason: null,
		isPaused: false,
		status: "idle",
		variables: void 0,
		submittedAt: 0
	};
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/mutationCache.js
var MutationCache = class extends Subscribable {
	constructor(config = {}) {
		super();
		this.config = config;
		this.#mutations = /* @__PURE__ */ new Set();
		this.#scopes = /* @__PURE__ */ new Map();
		this.#mutationId = 0;
	}
	#mutations;
	#scopes;
	#mutationId;
	build(client, options, state) {
		const mutation = new Mutation({
			client,
			mutationCache: this,
			mutationId: ++this.#mutationId,
			options: client.defaultMutationOptions(options),
			state
		});
		this.add(mutation);
		return mutation;
	}
	add(mutation) {
		this.#mutations.add(mutation);
		const scope = scopeFor(mutation);
		if (typeof scope === "string") {
			const scopedMutations = this.#scopes.get(scope);
			if (scopedMutations) scopedMutations.push(mutation);
			else this.#scopes.set(scope, [mutation]);
		}
		this.notify({
			type: "added",
			mutation
		});
	}
	remove(mutation) {
		if (this.#mutations.delete(mutation)) {
			const scope = scopeFor(mutation);
			if (typeof scope === "string") {
				const scopedMutations = this.#scopes.get(scope);
				if (scopedMutations) {
					if (scopedMutations.length > 1) {
						const index = scopedMutations.indexOf(mutation);
						if (index !== -1) scopedMutations.splice(index, 1);
					} else if (scopedMutations[0] === mutation) this.#scopes.delete(scope);
				}
			}
		}
		this.notify({
			type: "removed",
			mutation
		});
	}
	canRun(mutation) {
		const scope = scopeFor(mutation);
		if (typeof scope === "string") {
			const firstPendingMutation = this.#scopes.get(scope)?.find((m) => m.state.status === "pending");
			return !firstPendingMutation || firstPendingMutation === mutation;
		} else return true;
	}
	runNext(mutation) {
		const scope = scopeFor(mutation);
		if (typeof scope === "string") return (this.#scopes.get(scope)?.find((m) => m !== mutation && m.state.isPaused))?.continue() ?? Promise.resolve();
		else return Promise.resolve();
	}
	clear() {
		notifyManager.batch(() => {
			this.#mutations.forEach((mutation) => {
				this.notify({
					type: "removed",
					mutation
				});
			});
			this.#mutations.clear();
			this.#scopes.clear();
		});
	}
	getAll() {
		return Array.from(this.#mutations);
	}
	find(filters) {
		const defaultedFilters = {
			exact: true,
			...filters
		};
		return this.getAll().find((mutation) => matchMutation(defaultedFilters, mutation));
	}
	findAll(filters = {}) {
		return this.getAll().filter((mutation) => matchMutation(filters, mutation));
	}
	notify(event) {
		notifyManager.batch(() => {
			this.listeners.forEach((listener) => {
				listener(event);
			});
		});
	}
	resumePausedMutations() {
		const pausedMutations = this.getAll().filter((x) => x.state.isPaused);
		return notifyManager.batch(() => Promise.all(pausedMutations.map((mutation) => mutation.continue().catch(noop))));
	}
};
function scopeFor(mutation) {
	return mutation.options.scope?.id;
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/mutationObserver.js
var MutationObserver = class extends Subscribable {
	#client;
	#currentResult = void 0;
	#currentMutation;
	#mutateOptions;
	constructor(client, options) {
		super();
		this.#client = client;
		this.setOptions(options);
		this.bindMethods();
		this.#updateResult();
	}
	bindMethods() {
		this.mutate = this.mutate.bind(this);
		this.reset = this.reset.bind(this);
	}
	setOptions(options) {
		const prevOptions = this.options;
		this.options = this.#client.defaultMutationOptions(options);
		if (!shallowEqualObjects(this.options, prevOptions)) this.#client.getMutationCache().notify({
			type: "observerOptionsUpdated",
			mutation: this.#currentMutation,
			observer: this
		});
		if (prevOptions?.mutationKey && this.options.mutationKey && hashKey(prevOptions.mutationKey) !== hashKey(this.options.mutationKey)) this.reset();
		else if (this.#currentMutation?.state.status === "pending") this.#currentMutation.setOptions(this.options);
	}
	onUnsubscribe() {
		if (!this.hasListeners()) this.#currentMutation?.removeObserver(this);
	}
	onMutationUpdate(action) {
		this.#updateResult();
		this.#notify(action);
	}
	getCurrentResult() {
		return this.#currentResult;
	}
	reset() {
		this.#currentMutation?.removeObserver(this);
		this.#currentMutation = void 0;
		this.#updateResult();
		this.#notify();
	}
	mutate(variables, options) {
		this.#mutateOptions = options;
		this.#currentMutation?.removeObserver(this);
		this.#currentMutation = this.#client.getMutationCache().build(this.#client, this.options);
		this.#currentMutation.addObserver(this);
		return this.#currentMutation.execute(variables);
	}
	#updateResult() {
		const state = this.#currentMutation?.state ?? getDefaultState();
		this.#currentResult = {
			...state,
			isPending: state.status === "pending",
			isSuccess: state.status === "success",
			isError: state.status === "error",
			isIdle: state.status === "idle",
			mutate: this.mutate,
			reset: this.reset
		};
	}
	#notify(action) {
		notifyManager.batch(() => {
			if (this.#mutateOptions && this.hasListeners()) {
				const variables = this.#currentResult.variables;
				const onMutateResult = this.#currentResult.context;
				const context = {
					client: this.#client,
					meta: this.options.meta,
					mutationKey: this.options.mutationKey
				};
				if (action?.type === "success") {
					try {
						this.#mutateOptions.onSuccess?.(action.data, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						this.#mutateOptions.onSettled?.(action.data, null, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
				} else if (action?.type === "error") {
					try {
						this.#mutateOptions.onError?.(action.error, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						this.#mutateOptions.onSettled?.(void 0, action.error, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
				}
			}
			this.listeners.forEach((listener) => {
				listener(this.#currentResult);
			});
		});
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queriesObserver.js
function difference(array1, array2) {
	const excludeSet = new Set(array2);
	return array1.filter((x) => !excludeSet.has(x));
}
function replaceAt(array, index, value) {
	const copy = array.slice(0);
	copy[index] = value;
	return copy;
}
var QueriesObserver = class extends Subscribable {
	#client;
	#result;
	#queries;
	#options;
	#observers;
	#combinedResult;
	#lastCombine;
	#lastResult;
	#lastQueryHashes;
	#observerMatches = [];
	constructor(client, queries, options) {
		super();
		this.#client = client;
		this.#options = options;
		this.#queries = [];
		this.#observers = [];
		this.#result = [];
		this.setQueries(queries);
	}
	onSubscribe() {
		if (this.listeners.size === 1) this.#observers.forEach((observer) => {
			observer.subscribe((result) => {
				this.#onUpdate(observer, result);
			});
		});
	}
	onUnsubscribe() {
		if (!this.listeners.size) this.destroy();
	}
	destroy() {
		this.listeners = /* @__PURE__ */ new Set();
		this.#observers.forEach((observer) => {
			observer.destroy();
		});
	}
	setQueries(queries, options) {
		this.#queries = queries;
		this.#options = options;
		{
			const queryHashes = queries.map((query) => this.#client.defaultQueryOptions(query).queryHash);
			if (new Set(queryHashes).size !== queryHashes.length) console.warn("[QueriesObserver]: Duplicate Queries found. This might result in unexpected behavior.");
		}
		notifyManager.batch(() => {
			const prevObservers = this.#observers;
			const newObserverMatches = this.#findMatchingObservers(this.#queries);
			newObserverMatches.forEach((match) => match.observer.setOptions(match.defaultedQueryOptions));
			const newObservers = newObserverMatches.map((match) => match.observer);
			const newResult = newObservers.map((observer) => observer.getCurrentResult());
			const hasLengthChange = prevObservers.length !== newObservers.length;
			const hasIndexChange = newObservers.some((observer, index) => observer !== prevObservers[index]);
			const hasStructuralChange = hasLengthChange || hasIndexChange;
			const hasResultChange = hasStructuralChange ? true : newResult.some((result, index) => {
				const prev = this.#result[index];
				return !prev || !shallowEqualObjects(result, prev);
			});
			if (!hasStructuralChange && !hasResultChange) return;
			if (hasStructuralChange) {
				this.#observerMatches = newObserverMatches;
				this.#observers = newObservers;
			}
			this.#result = newResult;
			if (!this.hasListeners()) return;
			if (hasStructuralChange) {
				difference(prevObservers, newObservers).forEach((observer) => {
					observer.destroy();
				});
				difference(newObservers, prevObservers).forEach((observer) => {
					observer.subscribe((result) => {
						this.#onUpdate(observer, result);
					});
				});
			}
			this.#notify();
		});
	}
	getCurrentResult() {
		return this.#result;
	}
	getQueries() {
		return this.#observers.map((observer) => observer.getCurrentQuery());
	}
	getObservers() {
		return this.#observers;
	}
	getOptimisticResult(queries, combine) {
		const matches = this.#findMatchingObservers(queries);
		const result = matches.map((match) => match.observer.getOptimisticResult(match.defaultedQueryOptions));
		const queryHashes = matches.map((match) => match.defaultedQueryOptions.queryHash);
		return [
			result,
			(r) => {
				return this.#combineResult(r ?? result, combine, queryHashes);
			},
			() => {
				return this.#trackResult(result, matches);
			}
		];
	}
	#trackResult(result, matches) {
		return matches.map((match, index) => {
			const observerResult = result[index];
			return !match.defaultedQueryOptions.notifyOnChangeProps ? match.observer.trackResult(observerResult, (accessedProp) => {
				matches.forEach((m) => {
					m.observer.trackProp(accessedProp);
				});
			}) : observerResult;
		});
	}
	#combineResult(input, combine, queryHashes) {
		if (combine) {
			const lastHashes = this.#lastQueryHashes;
			const queryHashesChanged = queryHashes !== void 0 && lastHashes !== void 0 && (lastHashes.length !== queryHashes.length || queryHashes.some((hash, i) => hash !== lastHashes[i]));
			if (!this.#combinedResult || this.#result !== this.#lastResult || queryHashesChanged || combine !== this.#lastCombine) {
				this.#lastCombine = combine;
				this.#lastResult = this.#result;
				if (queryHashes !== void 0) this.#lastQueryHashes = queryHashes;
				this.#combinedResult = replaceEqualDeep(this.#combinedResult, combine(input));
			}
			return this.#combinedResult;
		}
		return input;
	}
	#shouldSkipCombine() {
		return this.#options?.combine !== void 0 && this.#observers.some((observer, index) => {
			return observer.options.suspense && this.#result[index]?.data === void 0;
		});
	}
	#findMatchingObservers(queries) {
		const prevObserversMap = /* @__PURE__ */ new Map();
		this.#observers.forEach((observer) => {
			const key = observer.options.queryHash;
			if (!key) return;
			const previousObservers = prevObserversMap.get(key);
			if (previousObservers) previousObservers.push(observer);
			else prevObserversMap.set(key, [observer]);
		});
		const observers = [];
		queries.forEach((options) => {
			const defaultedOptions = this.#client.defaultQueryOptions(options);
			const observer = prevObserversMap.get(defaultedOptions.queryHash)?.shift() ?? new QueryObserver(this.#client, defaultedOptions);
			observers.push({
				defaultedQueryOptions: defaultedOptions,
				observer
			});
		});
		return observers;
	}
	#onUpdate(observer, result) {
		const index = this.#observers.indexOf(observer);
		if (index !== -1) {
			this.#result = replaceAt(this.#result, index, result);
			this.#notify();
		}
	}
	#notify() {
		if (this.hasListeners()) {
			const newTracked = this.#trackResult(this.#result, this.#observerMatches);
			const shouldSkipCombine = this.#shouldSkipCombine();
			const previousResult = this.#combinedResult;
			const newResult = shouldSkipCombine ? previousResult : this.#combineResult(newTracked, this.#options?.combine);
			if (shouldSkipCombine || previousResult !== newResult) notifyManager.batch(() => {
				this.listeners.forEach((listener) => {
					listener(this.#result);
				});
			});
		}
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queryCache.js
var QueryCache = class extends Subscribable {
	constructor(config = {}) {
		super();
		this.config = config;
		this.#queries = /* @__PURE__ */ new Map();
	}
	#queries;
	build(client, options, state) {
		const queryKey = options.queryKey;
		const queryHash = options.queryHash ?? hashQueryKeyByOptions(queryKey, options);
		let query = this.get(queryHash);
		if (!query) {
			query = new Query({
				client,
				queryKey,
				queryHash,
				options: client.defaultQueryOptions(options),
				state,
				defaultOptions: client.getQueryDefaults(queryKey)
			});
			this.add(query);
		}
		return query;
	}
	add(query) {
		if (!this.#queries.has(query.queryHash)) {
			this.#queries.set(query.queryHash, query);
			this.notify({
				type: "added",
				query
			});
		}
	}
	remove(query) {
		const queryInMap = this.#queries.get(query.queryHash);
		if (queryInMap) {
			query.destroy();
			if (queryInMap === query) this.#queries.delete(query.queryHash);
			this.notify({
				type: "removed",
				query
			});
		}
	}
	clear() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				this.remove(query);
			});
		});
	}
	get(queryHash) {
		return this.#queries.get(queryHash);
	}
	getAll() {
		return [...this.#queries.values()];
	}
	find(filters) {
		const defaultedFilters = {
			exact: true,
			...filters
		};
		return this.getAll().find((query) => matchQuery(defaultedFilters, query));
	}
	findAll(filters = {}) {
		const queries = this.getAll();
		return Object.keys(filters).length > 0 ? queries.filter((query) => matchQuery(filters, query)) : queries;
	}
	notify(event) {
		notifyManager.batch(() => {
			this.listeners.forEach((listener) => {
				listener(event);
			});
		});
	}
	onFocus() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				query.onFocus();
			});
		});
	}
	onOnline() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				query.onOnline();
			});
		});
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queryClient.js
var QueryClient = class {
	#queryCache;
	#mutationCache;
	#defaultOptions;
	#queryDefaults;
	#mutationDefaults;
	#mountCount;
	#unsubscribeFocus;
	#unsubscribeOnline;
	constructor(config = {}) {
		this.#queryCache = config.queryCache || new QueryCache();
		this.#mutationCache = config.mutationCache || new MutationCache();
		this.#defaultOptions = config.defaultOptions || {};
		this.#queryDefaults = /* @__PURE__ */ new Map();
		this.#mutationDefaults = /* @__PURE__ */ new Map();
		this.#mountCount = 0;
	}
	mount() {
		this.#mountCount++;
		if (this.#mountCount !== 1) return;
		this.#unsubscribeFocus = focusManager.subscribe(async (focused) => {
			if (focused) {
				await this.resumePausedMutations();
				this.#queryCache.onFocus();
			}
		});
		this.#unsubscribeOnline = onlineManager.subscribe(async (online) => {
			if (online) {
				await this.resumePausedMutations();
				this.#queryCache.onOnline();
			}
		});
	}
	unmount() {
		this.#mountCount--;
		if (this.#mountCount !== 0) return;
		this.#unsubscribeFocus?.();
		this.#unsubscribeFocus = void 0;
		this.#unsubscribeOnline?.();
		this.#unsubscribeOnline = void 0;
	}
	isFetching(filters) {
		return this.#queryCache.findAll({
			...filters,
			fetchStatus: "fetching"
		}).length;
	}
	isMutating(filters) {
		return this.#mutationCache.findAll({
			...filters,
			status: "pending"
		}).length;
	}
	/**
	* Imperative (non-reactive) way to retrieve data for a QueryKey.
	* Should only be used in callbacks or functions where reading the latest data is necessary, e.g. for optimistic updates.
	*
	* Hint: Do not use this function inside a component, because it won't receive updates.
	* Use `useQuery` to create a `QueryObserver` that subscribes to changes.
	*/
	getQueryData(queryKey) {
		const options = this.defaultQueryOptions({ queryKey });
		return this.#queryCache.get(options.queryHash)?.state.data;
	}
	ensureQueryData(options) {
		const defaultedOptions = this.defaultQueryOptions(options);
		const query = this.#queryCache.build(this, defaultedOptions);
		const cachedData = query.state.data;
		if (cachedData === void 0) return this.fetchQuery(options);
		if (options.revalidateIfStale && query.isStaleByTime(resolveStaleTime(defaultedOptions.staleTime, query))) this.prefetchQuery(defaultedOptions);
		return Promise.resolve(cachedData);
	}
	getQueriesData(filters) {
		return this.#queryCache.findAll(filters).map(({ queryKey, state }) => {
			return [queryKey, state.data];
		});
	}
	setQueryData(queryKey, updater, options) {
		const defaultedOptions = this.defaultQueryOptions({ queryKey });
		const prevData = this.#queryCache.get(defaultedOptions.queryHash)?.state.data;
		const data = functionalUpdate(updater, prevData);
		if (data === void 0) return;
		return this.#queryCache.build(this, defaultedOptions).setData(data, {
			...options,
			manual: true
		});
	}
	setQueriesData(filters, updater, options) {
		return notifyManager.batch(() => this.#queryCache.findAll(filters).map(({ queryKey }) => [queryKey, this.setQueryData(queryKey, updater, options)]));
	}
	getQueryState(queryKey) {
		const options = this.defaultQueryOptions({ queryKey });
		return this.#queryCache.get(options.queryHash)?.state;
	}
	removeQueries(filters) {
		const queryCache = this.#queryCache;
		notifyManager.batch(() => {
			queryCache.findAll(filters).forEach((query) => {
				queryCache.remove(query);
			});
		});
	}
	resetQueries(filters, options) {
		const queryCache = this.#queryCache;
		return notifyManager.batch(() => {
			queryCache.findAll(filters).forEach((query) => {
				query.reset();
			});
			return this.refetchQueries({
				type: "active",
				...filters
			}, options);
		});
	}
	cancelQueries(filters, cancelOptions = {}) {
		const defaultedCancelOptions = {
			revert: true,
			...cancelOptions
		};
		const promises = notifyManager.batch(() => this.#queryCache.findAll(filters).map((query) => query.cancel(defaultedCancelOptions)));
		return Promise.all(promises).then(noop).catch(noop);
	}
	invalidateQueries(filters, options = {}) {
		return notifyManager.batch(() => {
			this.#queryCache.findAll(filters).forEach((query) => {
				query.invalidate();
			});
			if (filters?.refetchType === "none") return Promise.resolve();
			return this.refetchQueries({
				...filters,
				type: filters?.refetchType ?? filters?.type ?? "active"
			}, options);
		});
	}
	refetchQueries(filters, options = {}) {
		const fetchOptions = {
			...options,
			cancelRefetch: options.cancelRefetch ?? true
		};
		const promises = notifyManager.batch(() => this.#queryCache.findAll(filters).filter((query) => !query.isDisabled() && !query.isStatic()).map((query) => {
			let promise = query.fetch(void 0, fetchOptions);
			if (!fetchOptions.throwOnError) promise = promise.catch(noop);
			return query.state.fetchStatus === "paused" ? Promise.resolve() : promise;
		}));
		return Promise.all(promises).then(noop);
	}
	fetchQuery(options) {
		const defaultedOptions = this.defaultQueryOptions(options);
		if (defaultedOptions.retry === void 0) defaultedOptions.retry = false;
		const query = this.#queryCache.build(this, defaultedOptions);
		return query.isStaleByTime(resolveStaleTime(defaultedOptions.staleTime, query)) ? query.fetch(defaultedOptions) : Promise.resolve(query.state.data);
	}
	prefetchQuery(options) {
		return this.fetchQuery(options).then(noop).catch(noop);
	}
	fetchInfiniteQuery(options) {
		options._type = "infinite";
		return this.fetchQuery(options);
	}
	prefetchInfiniteQuery(options) {
		return this.fetchInfiniteQuery(options).then(noop).catch(noop);
	}
	ensureInfiniteQueryData(options) {
		options._type = "infinite";
		return this.ensureQueryData(options);
	}
	resumePausedMutations() {
		if (onlineManager.isOnline()) return this.#mutationCache.resumePausedMutations();
		return Promise.resolve();
	}
	getQueryCache() {
		return this.#queryCache;
	}
	getMutationCache() {
		return this.#mutationCache;
	}
	getDefaultOptions() {
		return this.#defaultOptions;
	}
	setDefaultOptions(options) {
		this.#defaultOptions = options;
	}
	setQueryDefaults(queryKey, options) {
		this.#queryDefaults.set(hashKey(queryKey), {
			queryKey,
			defaultOptions: options
		});
	}
	getQueryDefaults(queryKey) {
		const defaults = [...this.#queryDefaults.values()];
		const result = {};
		defaults.forEach((queryDefault) => {
			if (partialMatchKey(queryKey, queryDefault.queryKey)) Object.assign(result, queryDefault.defaultOptions);
		});
		return result;
	}
	setMutationDefaults(mutationKey, options) {
		this.#mutationDefaults.set(hashKey(mutationKey), {
			mutationKey,
			defaultOptions: options
		});
	}
	getMutationDefaults(mutationKey) {
		const defaults = [...this.#mutationDefaults.values()];
		const result = {};
		defaults.forEach((queryDefault) => {
			if (partialMatchKey(mutationKey, queryDefault.mutationKey)) Object.assign(result, queryDefault.defaultOptions);
		});
		return result;
	}
	defaultQueryOptions(options) {
		if (options._defaulted) return options;
		const defaultedOptions = {
			...this.#defaultOptions.queries,
			...this.getQueryDefaults(options.queryKey),
			...options,
			_defaulted: true
		};
		if (!defaultedOptions.queryHash) defaultedOptions.queryHash = hashQueryKeyByOptions(defaultedOptions.queryKey, defaultedOptions);
		if (defaultedOptions.refetchOnReconnect === void 0) defaultedOptions.refetchOnReconnect = defaultedOptions.networkMode !== "always";
		if (defaultedOptions.throwOnError === void 0) defaultedOptions.throwOnError = !!defaultedOptions.suspense;
		if (!defaultedOptions.networkMode && defaultedOptions.persister) defaultedOptions.networkMode = "offlineFirst";
		if (defaultedOptions.queryFn === skipToken) defaultedOptions.enabled = false;
		return defaultedOptions;
	}
	defaultMutationOptions(options) {
		if (options?._defaulted) return options;
		return {
			...this.#defaultOptions.mutations,
			...options?.mutationKey && this.getMutationDefaults(options.mutationKey),
			...options,
			_defaulted: true
		};
	}
	clear() {
		this.#queryCache.clear();
		this.#mutationCache.clear();
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/streamedQuery.js
function streamedQuery({ streamFn, refetchMode = "reset", reducer = (items, chunk) => addToEnd(items, chunk), initialValue = [] }) {
	return async (context) => {
		const query = context.client.getQueryCache().find({
			queryKey: context.queryKey,
			exact: true
		});
		const isRefetch = !!query && query.isFetched();
		if (isRefetch && refetchMode === "reset") query.setState({
			...query.resetState,
			fetchStatus: "fetching"
		});
		let result = initialValue;
		let cancelled = false;
		const stream = await streamFn(addConsumeAwareSignal({
			client: context.client,
			meta: context.meta,
			queryKey: context.queryKey,
			pageParam: context.pageParam,
			direction: context.direction
		}, () => context.signal, () => cancelled = true));
		const isReplaceRefetch = isRefetch && refetchMode === "replace";
		for await (const chunk of stream) {
			if (cancelled) break;
			if (isReplaceRefetch) result = reducer(result, chunk);
			else context.client.setQueryData(context.queryKey, (prev) => reducer(prev === void 0 ? initialValue : prev, chunk));
		}
		if (isReplaceRefetch && !cancelled) context.client.setQueryData(context.queryKey, result);
		return context.client.getQueryData(context.queryKey) ?? initialValue;
	};
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/types.js
var dataTagSymbol = /* @__PURE__ */ Symbol("dataTagSymbol");
var dataTagErrorSymbol = /* @__PURE__ */ Symbol("dataTagErrorSymbol");
var unsetMarker = /* @__PURE__ */ Symbol("unsetMarker");
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var QueryClientContext = import_react.createContext(void 0);
var useQueryClient = (queryClient) => {
	const client = import_react.useContext(QueryClientContext);
	if (queryClient) return queryClient;
	if (!client) throw new Error("No QueryClient set, use QueryClientProvider to set one");
	return client;
};
var QueryClientProvider = ({ client, children }) => {
	import_react.useEffect(() => {
		client.mount();
		return () => {
			client.unmount();
		};
	}, [client]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientContext.Provider, {
		value: client,
		children
	});
};
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/IsRestoringProvider.js
var IsRestoringContext = import_react.createContext(false);
var useIsRestoring = () => import_react.useContext(IsRestoringContext);
var IsRestoringProvider = IsRestoringContext.Provider;
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/QueryErrorResetBoundary.js
function createValue() {
	let isReset = false;
	return {
		clearReset: () => {
			isReset = false;
		},
		reset: () => {
			isReset = true;
		},
		isReset: () => {
			return isReset;
		}
	};
}
var QueryErrorResetBoundaryContext = import_react.createContext(createValue());
var useQueryErrorResetBoundary = () => import_react.useContext(QueryErrorResetBoundaryContext);
var QueryErrorResetBoundary = ({ children }) => {
	const [value] = import_react.useState(() => createValue());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryErrorResetBoundaryContext.Provider, {
		value,
		children: typeof children === "function" ? children(value) : children
	});
};
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/errorBoundaryUtils.js
var ensurePreventErrorBoundaryRetry = (options, errorResetBoundary, query) => {
	const throwOnError = query?.state.error && typeof options.throwOnError === "function" ? shouldThrowError(options.throwOnError, [query.state.error, query]) : options.throwOnError;
	if (options.suspense || options.experimental_prefetchInRender || throwOnError) {
		if (!errorResetBoundary.isReset()) options.retryOnMount = false;
	}
};
var useClearResetErrorBoundary = (errorResetBoundary) => {
	import_react.useEffect(() => {
		errorResetBoundary.clearReset();
	}, [errorResetBoundary]);
};
var getHasError = ({ result, errorResetBoundary, throwOnError, query, suspense }) => {
	return result.isError && !errorResetBoundary.isReset() && !result.isFetching && query && (suspense && result.data === void 0 || shouldThrowError(throwOnError, [result.error, query]));
};
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/suspense.js
var defaultThrowOnError = (_error, query) => query.state.data === void 0;
var ensureSuspenseTimers = (defaultedOptions) => {
	if (defaultedOptions.suspense) {
		const MIN_SUSPENSE_TIME_MS = 1e3;
		const clamp = (value) => value === "static" ? value : Math.max(value ?? MIN_SUSPENSE_TIME_MS, MIN_SUSPENSE_TIME_MS);
		const originalStaleTime = defaultedOptions.staleTime;
		defaultedOptions.staleTime = typeof originalStaleTime === "function" ? (...args) => clamp(originalStaleTime(...args)) : clamp(originalStaleTime);
		if (typeof defaultedOptions.gcTime === "number") defaultedOptions.gcTime = Math.max(defaultedOptions.gcTime, MIN_SUSPENSE_TIME_MS);
	}
};
var willFetch = (result, isRestoring) => result.isLoading && result.isFetching && !isRestoring;
var shouldSuspend = (defaultedOptions, result) => defaultedOptions?.suspense && result.isPending;
var fetchOptimistic = (defaultedOptions, observer, errorResetBoundary) => observer.fetchOptimistic(defaultedOptions).catch(() => {
	errorResetBoundary.clearReset();
});
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useQueries.js
function useQueries({ queries, ...options }, queryClient) {
	const client = useQueryClient(queryClient);
	const isRestoring = useIsRestoring();
	const errorResetBoundary = useQueryErrorResetBoundary();
	const defaultedQueries = import_react.useMemo(() => queries.map((opts) => {
		const defaultedOptions = client.defaultQueryOptions(opts);
		defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : "optimistic";
		return defaultedOptions;
	}), [
		queries,
		client,
		isRestoring
	]);
	defaultedQueries.forEach((queryOptions) => {
		ensureSuspenseTimers(queryOptions);
		const query = client.getQueryCache().get(queryOptions.queryHash);
		ensurePreventErrorBoundaryRetry(queryOptions, errorResetBoundary, query);
	});
	useClearResetErrorBoundary(errorResetBoundary);
	const [observer] = import_react.useState(() => new QueriesObserver(client, defaultedQueries, options));
	const [optimisticResult, getCombinedResult, trackResult] = observer.getOptimisticResult(defaultedQueries, options.combine);
	const shouldSubscribe = !isRestoring && options.subscribed !== false;
	import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => shouldSubscribe ? observer.subscribe(notifyManager.batchCalls(onStoreChange)) : noop, [observer, shouldSubscribe]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	import_react.useEffect(() => {
		observer.setQueries(defaultedQueries, options);
	}, [
		defaultedQueries,
		options,
		observer
	]);
	const suspensePromises = optimisticResult.some((result, index) => shouldSuspend(defaultedQueries[index], result)) ? optimisticResult.flatMap((result, index) => {
		const opts = defaultedQueries[index];
		if (opts && shouldSuspend(opts, result)) return fetchOptimistic(opts, new QueryObserver(client, opts), errorResetBoundary);
		return [];
	}) : [];
	if (suspensePromises.length > 0) throw Promise.all(suspensePromises);
	const firstSingleResultWhichShouldThrow = optimisticResult.find((result, index) => {
		const query = defaultedQueries[index];
		return query && getHasError({
			result,
			errorResetBoundary,
			throwOnError: query.throwOnError,
			query: client.getQueryCache().get(query.queryHash),
			suspense: query.suspense
		});
	});
	if (firstSingleResultWhichShouldThrow?.error) throw firstSingleResultWhichShouldThrow.error;
	return getCombinedResult(trackResult());
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useBaseQuery.js
function useBaseQuery(options, Observer, queryClient) {
	if (typeof options !== "object" || Array.isArray(options)) throw new Error("Bad argument type. Starting with v5, only the \"Object\" form is allowed when calling query related functions. Please use the error stack to find the culprit call. More info here: https://tanstack.com/query/latest/docs/react/guides/migrating-to-v5#supports-a-single-signature-one-object");
	const isRestoring = useIsRestoring();
	const errorResetBoundary = useQueryErrorResetBoundary();
	const client = useQueryClient(queryClient);
	const defaultedOptions = client.defaultQueryOptions(options);
	client.getDefaultOptions().queries?._experimental_beforeQuery?.(defaultedOptions);
	const query = client.getQueryCache().get(defaultedOptions.queryHash);
	if (!defaultedOptions.queryFn) console.error(`[${defaultedOptions.queryHash}]: No queryFn was passed as an option, and no default queryFn was found. The queryFn parameter is only optional when using a default queryFn. More info here: https://tanstack.com/query/latest/docs/framework/react/guides/default-query-function`);
	const subscribed = options.subscribed !== false;
	defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : subscribed ? "optimistic" : void 0;
	ensureSuspenseTimers(defaultedOptions);
	ensurePreventErrorBoundaryRetry(defaultedOptions, errorResetBoundary, query);
	useClearResetErrorBoundary(errorResetBoundary);
	const isNewCacheEntry = !client.getQueryCache().get(defaultedOptions.queryHash);
	const [observer] = import_react.useState(() => new Observer(client, defaultedOptions));
	const result = observer.getOptimisticResult(defaultedOptions);
	const shouldSubscribe = !isRestoring && subscribed;
	import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => {
		const unsubscribe = shouldSubscribe ? observer.subscribe(notifyManager.batchCalls(onStoreChange)) : noop;
		observer.updateResult();
		return unsubscribe;
	}, [observer, shouldSubscribe]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	import_react.useEffect(() => {
		observer.setOptions(defaultedOptions);
	}, [defaultedOptions, observer]);
	if (shouldSuspend(defaultedOptions, result)) throw fetchOptimistic(defaultedOptions, observer, errorResetBoundary);
	if (getHasError({
		result,
		errorResetBoundary,
		throwOnError: defaultedOptions.throwOnError,
		query,
		suspense: defaultedOptions.suspense
	})) throw result.error;
	client.getDefaultOptions().queries?._experimental_afterQuery?.(defaultedOptions, result);
	if (defaultedOptions.experimental_prefetchInRender && !environmentManager.isServer() && willFetch(result, isRestoring)) (isNewCacheEntry ? fetchOptimistic(defaultedOptions, observer, errorResetBoundary) : query?.promise)?.catch(noop).finally(() => {
		observer.updateResult();
	});
	return !defaultedOptions.notifyOnChangeProps ? observer.trackResult(result) : result;
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useQuery.js
function useQuery(options, queryClient) {
	return useBaseQuery(options, QueryObserver, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useSuspenseQuery.js
function useSuspenseQuery(options, queryClient) {
	if (options.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseQuery");
	return useBaseQuery({
		...options,
		enabled: true,
		suspense: true,
		throwOnError: defaultThrowOnError,
		placeholderData: void 0
	}, QueryObserver, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useSuspenseInfiniteQuery.js
function useSuspenseInfiniteQuery(options, queryClient) {
	if (options.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseInfiniteQuery");
	return useBaseQuery({
		...options,
		enabled: true,
		suspense: true,
		throwOnError: defaultThrowOnError
	}, InfiniteQueryObserver, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useSuspenseQueries.js
function useSuspenseQueries(options, queryClient) {
	return useQueries({
		...options,
		queries: options.queries.map((query) => {
			if (query.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseQueries");
			return {
				...query,
				suspense: true,
				throwOnError: defaultThrowOnError,
				enabled: true,
				placeholderData: void 0
			};
		})
	}, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/usePrefetchQuery.js
function usePrefetchQuery(options, queryClient) {
	const client = useQueryClient(queryClient);
	if (!client.getQueryState(options.queryKey)) client.prefetchQuery(options);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/usePrefetchInfiniteQuery.js
function usePrefetchInfiniteQuery(options, queryClient) {
	const client = useQueryClient(queryClient);
	if (!client.getQueryState(options.queryKey)) client.prefetchInfiniteQuery(options);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/queryOptions.js
function queryOptions(options) {
	return options;
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/infiniteQueryOptions.js
function infiniteQueryOptions(options) {
	return options;
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/HydrationBoundary.js
var HydrationBoundary = ({ children, options = {}, state, queryClient }) => {
	const client = useQueryClient(queryClient);
	const optionsRef = import_react.useRef(options);
	import_react.useEffect(() => {
		optionsRef.current = options;
	});
	const hydrationQueue = import_react.useMemo(() => {
		if (state) {
			if (typeof state !== "object") return;
			const queryCache = client.getQueryCache();
			const queries = state.queries || [];
			const newQueries = [];
			const existingQueries = [];
			for (const dehydratedQuery of queries) {
				const existingQuery = queryCache.get(dehydratedQuery.queryHash);
				if (!existingQuery) newQueries.push(dehydratedQuery);
				else if (dehydratedQuery.state.dataUpdatedAt > existingQuery.state.dataUpdatedAt || dehydratedQuery.promise && existingQuery.state.status !== "pending" && existingQuery.state.fetchStatus !== "fetching" && dehydratedQuery.dehydratedAt !== void 0 && dehydratedQuery.dehydratedAt > existingQuery.state.dataUpdatedAt) existingQueries.push(dehydratedQuery);
			}
			if (newQueries.length > 0) hydrate(client, { queries: newQueries }, optionsRef.current);
			if (existingQueries.length > 0) return existingQueries;
		}
	}, [client, state]);
	import_react.useEffect(() => {
		if (hydrationQueue) hydrate(client, { queries: hydrationQueue }, optionsRef.current);
	}, [client, hydrationQueue]);
	return children;
};
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useIsFetching.js
function useIsFetching(filters, queryClient) {
	const client = useQueryClient(queryClient);
	const queryCache = client.getQueryCache();
	return import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => queryCache.subscribe(notifyManager.batchCalls(onStoreChange)), [queryCache]), () => client.isFetching(filters), () => client.isFetching(filters));
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useMutationState.js
function useIsMutating(filters, queryClient) {
	const client = useQueryClient(queryClient);
	return useMutationState({ filters: {
		...filters,
		status: "pending"
	} }, client).length;
}
function getResult(mutationCache, options) {
	return mutationCache.findAll(options.filters).map((mutation) => options.select ? options.select(mutation) : mutation.state);
}
function useMutationState(options = {}, queryClient) {
	const mutationCache = useQueryClient(queryClient).getMutationCache();
	const optionsRef = import_react.useRef(options);
	const result = import_react.useRef(null);
	if (result.current === null) result.current = getResult(mutationCache, options);
	import_react.useEffect(() => {
		optionsRef.current = options;
	});
	return import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => mutationCache.subscribe(() => {
		const nextResult = replaceEqualDeep(result.current, getResult(mutationCache, optionsRef.current));
		if (result.current !== nextResult) {
			result.current = nextResult;
			notifyManager.schedule(onStoreChange);
		}
	}), [mutationCache]), () => result.current, () => result.current);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useMutation.js
function useMutation(options, queryClient) {
	const client = useQueryClient(queryClient);
	const [observer] = import_react.useState(() => new MutationObserver(client, options));
	import_react.useEffect(() => {
		observer.setOptions(options);
	}, [observer, options]);
	const result = import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => observer.subscribe(notifyManager.batchCalls(onStoreChange)), [observer]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	const mutate = import_react.useCallback((variables, mutateOptions) => {
		observer.mutate(variables, mutateOptions).catch(noop);
	}, [observer]);
	if (result.error && shouldThrowError(observer.options.throwOnError, [result.error])) throw result.error;
	return {
		...result,
		mutate,
		mutateAsync: result.mutate
	};
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/mutationOptions.js
function mutationOptions(options) {
	return options;
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useInfiniteQuery.js
function useInfiniteQuery(options, queryClient) {
	return useBaseQuery(options, InfiniteQueryObserver, queryClient);
}
//#endregion
export { CancelledError, HydrationBoundary, InfiniteQueryObserver, IsRestoringProvider, Mutation, MutationCache, MutationObserver, QueriesObserver, Query, QueryCache, QueryClient, QueryClientContext, QueryClientProvider, QueryErrorResetBoundary, QueryObserver, dataTagErrorSymbol, dataTagSymbol, defaultScheduler, defaultShouldDehydrateMutation, defaultShouldDehydrateQuery, dehydrate, environmentManager, streamedQuery as experimental_streamedQuery, focusManager, hashKey, hydrate, infiniteQueryOptions, isCancelledError, isServer, keepPreviousData, matchMutation, matchQuery, mutationOptions, noop, notifyManager, onlineManager, partialMatchKey, queryOptions, replaceEqualDeep, shouldThrowError, skipToken, timeoutManager, unsetMarker, useInfiniteQuery, useIsFetching, useIsMutating, useIsRestoring, useMutation, useMutationState, usePrefetchInfiniteQuery, usePrefetchQuery, useQueries, useQuery, useQueryClient, useQueryErrorResetBoundary, useSuspenseInfiniteQuery, useSuspenseQueries, useSuspenseQuery };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQHRhbnN0YWNrX3JlYWN0LXF1ZXJ5LmpzIiwibmFtZXMiOlsiI3NldHVwIiwiI2NsZWFudXAiLCIjZm9jdXNlZCIsIiNwcm92aWRlckNhbGxlZCIsIiNwcm92aWRlciIsIiNzZXR1cCIsIiNjbGVhbnVwIiwiI29ubGluZSIsIiNnY1RpbWVvdXQiLCIjYWJvcnRTaWduYWxDb25zdW1lZCIsIiNkZWZhdWx0T3B0aW9ucyIsIiNjbGllbnQiLCIjY2FjaGUiLCIjaW5pdGlhbFN0YXRlIiwiZ2V0RGVmYXVsdFN0YXRlIiwiI3F1ZXJ5VHlwZSIsIiNyZXRyeWVyIiwiI2Rpc3BhdGNoIiwiI2lzSW5pdGlhbFBhdXNlZEZldGNoIiwiI3JldmVydFN0YXRlIiwiI2NsaWVudCIsIiNzZWxlY3RFcnJvciIsIiNjdXJyZW50VGhlbmFibGUiLCIjY3VycmVudFF1ZXJ5IiwiI2V4ZWN1dGVGZXRjaCIsIiN1cGRhdGVUaW1lcnMiLCIjY2xlYXJTdGFsZVRpbWVvdXQiLCIjY2xlYXJSZWZldGNoSW50ZXJ2YWwiLCIjdXBkYXRlUXVlcnkiLCIjdXBkYXRlU3RhbGVUaW1lb3V0IiwiI2NvbXB1dGVSZWZldGNoSW50ZXJ2YWwiLCIjY3VycmVudFJlZmV0Y2hJbnRlcnZhbCIsIiN1cGRhdGVSZWZldGNoSW50ZXJ2YWwiLCIjY3VycmVudFJlc3VsdCIsIiNjdXJyZW50UmVzdWx0T3B0aW9ucyIsIiNjdXJyZW50UmVzdWx0U3RhdGUiLCIjdHJhY2tlZFByb3BzIiwiI3N0YWxlVGltZW91dElkIiwiI3JlZmV0Y2hJbnRlcnZhbElkIiwiI2N1cnJlbnRRdWVyeUluaXRpYWxTdGF0ZSIsIiNsYXN0UXVlcnlXaXRoRGVmaW5lZERhdGEiLCIjc2VsZWN0Rm4iLCIjc2VsZWN0UmVzdWx0IiwiI25vdGlmeSIsIiNjbGllbnQiLCIjbXV0YXRpb25DYWNoZSIsIiNvYnNlcnZlcnMiLCIjcmV0cnllciIsIiNkaXNwYXRjaCIsIiNtdXRhdGlvbnMiLCIjc2NvcGVzIiwiI211dGF0aW9uSWQiLCIjY2xpZW50IiwiI3VwZGF0ZVJlc3VsdCIsIiNjdXJyZW50TXV0YXRpb24iLCIjbm90aWZ5IiwiI2N1cnJlbnRSZXN1bHQiLCIjbXV0YXRlT3B0aW9ucyIsIiNjbGllbnQiLCIjb3B0aW9ucyIsIiNxdWVyaWVzIiwiI29ic2VydmVycyIsIiNyZXN1bHQiLCIjb25VcGRhdGUiLCIjZmluZE1hdGNoaW5nT2JzZXJ2ZXJzIiwiI29ic2VydmVyTWF0Y2hlcyIsIiNub3RpZnkiLCIjY29tYmluZVJlc3VsdCIsIiN0cmFja1Jlc3VsdCIsIiNsYXN0UXVlcnlIYXNoZXMiLCIjY29tYmluZWRSZXN1bHQiLCIjbGFzdFJlc3VsdCIsIiNsYXN0Q29tYmluZSIsIiNzaG91bGRTa2lwQ29tYmluZSIsIiNxdWVyaWVzIiwiI3F1ZXJ5Q2FjaGUiLCIjbXV0YXRpb25DYWNoZSIsIiNkZWZhdWx0T3B0aW9ucyIsIiNxdWVyeURlZmF1bHRzIiwiI211dGF0aW9uRGVmYXVsdHMiLCIjbW91bnRDb3VudCIsIiN1bnN1YnNjcmliZUZvY3VzIiwiI3Vuc3Vic2NyaWJlT25saW5lIl0sInNvdXJjZXMiOlsiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3N1YnNjcmliYWJsZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9mb2N1c01hbmFnZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vdGltZW91dE1hbmFnZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vdXRpbHMuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vZW52aXJvbm1lbnRNYW5hZ2VyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3RoZW5hYmxlLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL2h5ZHJhdGlvbi5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9ub3RpZnlNYW5hZ2VyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL29ubGluZU1hbmFnZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vcmV0cnllci5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9yZW1vdmFibGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vaW5maW5pdGVRdWVyeUJlaGF2aW9yLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3F1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3F1ZXJ5T2JzZXJ2ZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vaW5maW5pdGVRdWVyeU9ic2VydmVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL211dGF0aW9uLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL211dGF0aW9uQ2FjaGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vbXV0YXRpb25PYnNlcnZlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9xdWVyaWVzT2JzZXJ2ZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vcXVlcnlDYWNoZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9xdWVyeUNsaWVudC5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9zdHJlYW1lZFF1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3R5cGVzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9Jc1Jlc3RvcmluZ1Byb3ZpZGVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9RdWVyeUVycm9yUmVzZXRCb3VuZGFyeS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vZXJyb3JCb3VuZGFyeVV0aWxzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9zdXNwZW5zZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlUXVlcmllcy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlQmFzZVF1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi91c2VRdWVyeS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlU3VzcGVuc2VRdWVyeS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi91c2VTdXNwZW5zZVF1ZXJpZXMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZVByZWZldGNoUXVlcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZVByZWZldGNoSW5maW5pdGVRdWVyeS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vcXVlcnlPcHRpb25zLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9pbmZpbml0ZVF1ZXJ5T3B0aW9ucy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vSHlkcmF0aW9uQm91bmRhcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZUlzRmV0Y2hpbmcuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZU11dGF0aW9uU3RhdGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZU11dGF0aW9uLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9tdXRhdGlvbk9wdGlvbnMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZUluZmluaXRlUXVlcnkuanMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3JjL3N1YnNjcmliYWJsZS50c1xudmFyIFN1YnNjcmliYWJsZSA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy5saXN0ZW5lcnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuICAgIHRoaXMuc3Vic2NyaWJlID0gdGhpcy5zdWJzY3JpYmUuYmluZCh0aGlzKTtcbiAgfVxuICBzdWJzY3JpYmUobGlzdGVuZXIpIHtcbiAgICB0aGlzLmxpc3RlbmVycy5hZGQobGlzdGVuZXIpO1xuICAgIHRoaXMub25TdWJzY3JpYmUoKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgdGhpcy5saXN0ZW5lcnMuZGVsZXRlKGxpc3RlbmVyKTtcbiAgICAgIHRoaXMub25VbnN1YnNjcmliZSgpO1xuICAgIH07XG4gIH1cbiAgaGFzTGlzdGVuZXJzKCkge1xuICAgIHJldHVybiB0aGlzLmxpc3RlbmVycy5zaXplID4gMDtcbiAgfVxuICBvblN1YnNjcmliZSgpIHtcbiAgfVxuICBvblVuc3Vic2NyaWJlKCkge1xuICB9XG59O1xuZXhwb3J0IHtcbiAgU3Vic2NyaWJhYmxlXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c3Vic2NyaWJhYmxlLmpzLm1hcCIsIi8vIHNyYy9mb2N1c01hbmFnZXIudHNcbmltcG9ydCB7IFN1YnNjcmliYWJsZSB9IGZyb20gXCIuL3N1YnNjcmliYWJsZS5qc1wiO1xudmFyIEZvY3VzTWFuYWdlciA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcbiAgI2ZvY3VzZWQ7XG4gICNjbGVhbnVwO1xuICAjc2V0dXA7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy4jc2V0dXAgPSAob25Gb2N1cykgPT4ge1xuICAgICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgJiYgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIpIHtcbiAgICAgICAgY29uc3QgbGlzdGVuZXIgPSAoKSA9PiBvbkZvY3VzKCk7XG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwidmlzaWJpbGl0eWNoYW5nZVwiLCBsaXN0ZW5lciwgZmFsc2UpO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwidmlzaWJpbGl0eWNoYW5nZVwiLCBsaXN0ZW5lcik7XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfTtcbiAgfVxuICBvblN1YnNjcmliZSgpIHtcbiAgICBpZiAoIXRoaXMuI2NsZWFudXApIHtcbiAgICAgIHRoaXMuc2V0RXZlbnRMaXN0ZW5lcih0aGlzLiNzZXR1cCk7XG4gICAgfVxuICB9XG4gIG9uVW5zdWJzY3JpYmUoKSB7XG4gICAgaWYgKCF0aGlzLmhhc0xpc3RlbmVycygpKSB7XG4gICAgICB0aGlzLiNjbGVhbnVwPy4oKTtcbiAgICAgIHRoaXMuI2NsZWFudXAgPSB2b2lkIDA7XG4gICAgfVxuICB9XG4gIHNldEV2ZW50TGlzdGVuZXIoc2V0dXApIHtcbiAgICB0aGlzLiNzZXR1cCA9IHNldHVwO1xuICAgIHRoaXMuI2NsZWFudXA/LigpO1xuICAgIHRoaXMuI2NsZWFudXAgPSBzZXR1cCgoZm9jdXNlZCkgPT4ge1xuICAgICAgaWYgKHR5cGVvZiBmb2N1c2VkID09PSBcImJvb2xlYW5cIikge1xuICAgICAgICB0aGlzLnNldEZvY3VzZWQoZm9jdXNlZCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLm9uRm9jdXMoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICBzZXRGb2N1c2VkKGZvY3VzZWQpIHtcbiAgICBjb25zdCBjaGFuZ2VkID0gdGhpcy4jZm9jdXNlZCAhPT0gZm9jdXNlZDtcbiAgICBpZiAoY2hhbmdlZCkge1xuICAgICAgdGhpcy4jZm9jdXNlZCA9IGZvY3VzZWQ7XG4gICAgICB0aGlzLm9uRm9jdXMoKTtcbiAgICB9XG4gIH1cbiAgb25Gb2N1cygpIHtcbiAgICBjb25zdCBpc0ZvY3VzZWQgPSB0aGlzLmlzRm9jdXNlZCgpO1xuICAgIHRoaXMubGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG4gICAgICBsaXN0ZW5lcihpc0ZvY3VzZWQpO1xuICAgIH0pO1xuICB9XG4gIGlzRm9jdXNlZCgpIHtcbiAgICBpZiAodHlwZW9mIHRoaXMuI2ZvY3VzZWQgPT09IFwiYm9vbGVhblwiKSB7XG4gICAgICByZXR1cm4gdGhpcy4jZm9jdXNlZDtcbiAgICB9XG4gICAgcmV0dXJuIGdsb2JhbFRoaXMuZG9jdW1lbnQ/LnZpc2liaWxpdHlTdGF0ZSAhPT0gXCJoaWRkZW5cIjtcbiAgfVxufTtcbnZhciBmb2N1c01hbmFnZXIgPSBuZXcgRm9jdXNNYW5hZ2VyKCk7XG5leHBvcnQge1xuICBGb2N1c01hbmFnZXIsXG4gIGZvY3VzTWFuYWdlclxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWZvY3VzTWFuYWdlci5qcy5tYXAiLCIvLyBzcmMvdGltZW91dE1hbmFnZXIudHNcbnZhciBkZWZhdWx0VGltZW91dFByb3ZpZGVyID0ge1xuICAvLyBXZSBuZWVkIHRoZSB3cmFwcGVyIGZ1bmN0aW9uIHN5bnRheCBiZWxvdyBpbnN0ZWFkIG9mIGRpcmVjdCByZWZlcmVuY2VzIHRvXG4gIC8vIGdsb2JhbCBzZXRUaW1lb3V0IGV0Yy5cbiAgLy9cbiAgLy8gQkFEOiBgc2V0VGltZW91dDogc2V0VGltZW91dGBcbiAgLy8gR09PRDogYHNldFRpbWVvdXQ6IChjYiwgZGVsYXkpID0+IHNldFRpbWVvdXQoY2IsIGRlbGF5KWBcbiAgLy9cbiAgLy8gSWYgd2UgdXNlIGRpcmVjdCByZWZlcmVuY2VzIGhlcmUsIHRoZW4gYW55dGhpbmcgdGhhdCB3YW50cyB0byBzcHkgb24gb3JcbiAgLy8gcmVwbGFjZSB0aGUgZ2xvYmFsIHNldFRpbWVvdXQgKGxpa2UgdGVzdHMpIHdvbid0IHdvcmsgc2luY2Ugd2UnbGwgYWxyZWFkeVxuICAvLyBoYXZlIGEgaGFyZCByZWZlcmVuY2UgdG8gdGhlIG9yaWdpbmFsIGltcGxlbWVudGF0aW9uIGF0IHRoZSB0aW1lIHdoZW4gdGhpc1xuICAvLyBmaWxlIHdhcyBpbXBvcnRlZC5cbiAgc2V0VGltZW91dDogKGNhbGxiYWNrLCBkZWxheSkgPT4gc2V0VGltZW91dChjYWxsYmFjaywgZGVsYXkpLFxuICBjbGVhclRpbWVvdXQ6ICh0aW1lb3V0SWQpID0+IGNsZWFyVGltZW91dCh0aW1lb3V0SWQpLFxuICBzZXRJbnRlcnZhbDogKGNhbGxiYWNrLCBkZWxheSkgPT4gc2V0SW50ZXJ2YWwoY2FsbGJhY2ssIGRlbGF5KSxcbiAgY2xlYXJJbnRlcnZhbDogKGludGVydmFsSWQpID0+IGNsZWFySW50ZXJ2YWwoaW50ZXJ2YWxJZClcbn07XG52YXIgVGltZW91dE1hbmFnZXIgPSBjbGFzcyB7XG4gIC8vIFdlIGNhbm5vdCBoYXZlIFRpbWVvdXRNYW5hZ2VyPFQ+IGFzIHdlIG11c3QgaW5zdGFudGlhdGUgaXQgd2l0aCBhIGNvbmNyZXRlXG4gIC8vIHR5cGUgYXQgYXBwIGJvb3Q7IGFuZCBpZiB3ZSBsZWF2ZSB0aGF0IHR5cGUsIHRoZW4gYW55IG5ldyB0aW1lciBwcm92aWRlclxuICAvLyB3b3VsZCBuZWVkIHRvIHN1cHBvcnQgdGhlIGRlZmF1bHQgcHJvdmlkZXIncyBjb25jcmV0ZSB0aW1lciBJRCwgd2hpY2ggaXNcbiAgLy8gaW5mZWFzaWJsZSBhY3Jvc3MgZW52aXJvbm1lbnRzLlxuICAvL1xuICAvLyBXZSBzZXR0bGUgZm9yIHR5cGUgc2FmZXR5IGZvciB0aGUgVGltZW91dFByb3ZpZGVyIHR5cGUsIGFuZCBhY2NlcHQgdGhhdFxuICAvLyB0aGlzIGNsYXNzIGlzIHVuc2FmZSBpbnRlcm5hbGx5IHRvIGFsbG93IGZvciBleHRlbnNpb24uXG4gICNwcm92aWRlciA9IGRlZmF1bHRUaW1lb3V0UHJvdmlkZXI7XG4gICNwcm92aWRlckNhbGxlZCA9IGZhbHNlO1xuICBzZXRUaW1lb3V0UHJvdmlkZXIocHJvdmlkZXIpIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgICBpZiAodGhpcy4jcHJvdmlkZXJDYWxsZWQgJiYgcHJvdmlkZXIgIT09IHRoaXMuI3Byb3ZpZGVyKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgYFt0aW1lb3V0TWFuYWdlcl06IFN3aXRjaGluZyBwcm92aWRlciBhZnRlciBjYWxscyB0byBwcmV2aW91cyBwcm92aWRlciBtaWdodCByZXN1bHQgaW4gdW5leHBlY3RlZCBiZWhhdmlvci5gLFxuICAgICAgICAgIHsgcHJldmlvdXM6IHRoaXMuI3Byb3ZpZGVyLCBwcm92aWRlciB9XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICAgIHRoaXMuI3Byb3ZpZGVyID0gcHJvdmlkZXI7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgdGhpcy4jcHJvdmlkZXJDYWxsZWQgPSBmYWxzZTtcbiAgICB9XG4gIH1cbiAgc2V0VGltZW91dChjYWxsYmFjaywgZGVsYXkpIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgICB0aGlzLiNwcm92aWRlckNhbGxlZCA9IHRydWU7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLiNwcm92aWRlci5zZXRUaW1lb3V0KGNhbGxiYWNrLCBkZWxheSk7XG4gIH1cbiAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCkge1xuICAgIHRoaXMuI3Byb3ZpZGVyLmNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuICB9XG4gIHNldEludGVydmFsKGNhbGxiYWNrLCBkZWxheSkge1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICAgIHRoaXMuI3Byb3ZpZGVyQ2FsbGVkID0gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuI3Byb3ZpZGVyLnNldEludGVydmFsKGNhbGxiYWNrLCBkZWxheSk7XG4gIH1cbiAgY2xlYXJJbnRlcnZhbChpbnRlcnZhbElkKSB7XG4gICAgdGhpcy4jcHJvdmlkZXIuY2xlYXJJbnRlcnZhbChpbnRlcnZhbElkKTtcbiAgfVxufTtcbnZhciB0aW1lb3V0TWFuYWdlciA9IG5ldyBUaW1lb3V0TWFuYWdlcigpO1xuZnVuY3Rpb24gc3lzdGVtU2V0VGltZW91dFplcm8oY2FsbGJhY2spIHtcbiAgc2V0VGltZW91dChjYWxsYmFjaywgMCk7XG59XG5leHBvcnQge1xuICBUaW1lb3V0TWFuYWdlcixcbiAgZGVmYXVsdFRpbWVvdXRQcm92aWRlcixcbiAgc3lzdGVtU2V0VGltZW91dFplcm8sXG4gIHRpbWVvdXRNYW5hZ2VyXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dGltZW91dE1hbmFnZXIuanMubWFwIiwiLy8gc3JjL3V0aWxzLnRzXG5pbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gXCIuL3RpbWVvdXRNYW5hZ2VyLmpzXCI7XG52YXIgaXNTZXJ2ZXIgPSB0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiIHx8IFwiRGVub1wiIGluIGdsb2JhbFRoaXM7XG5mdW5jdGlvbiBub29wKCkge1xufVxuZnVuY3Rpb24gZnVuY3Rpb25hbFVwZGF0ZSh1cGRhdGVyLCBpbnB1dCkge1xuICByZXR1cm4gdHlwZW9mIHVwZGF0ZXIgPT09IFwiZnVuY3Rpb25cIiA/IHVwZGF0ZXIoaW5wdXQpIDogdXBkYXRlcjtcbn1cbmZ1bmN0aW9uIGlzVmFsaWRUaW1lb3V0KHZhbHVlKSB7XG4gIHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwibnVtYmVyXCIgJiYgdmFsdWUgPj0gMCAmJiB2YWx1ZSAhPT0gSW5maW5pdHk7XG59XG5mdW5jdGlvbiB0aW1lVW50aWxTdGFsZSh1cGRhdGVkQXQsIHN0YWxlVGltZSkge1xuICByZXR1cm4gTWF0aC5tYXgodXBkYXRlZEF0ICsgKHN0YWxlVGltZSB8fCAwKSAtIERhdGUubm93KCksIDApO1xufVxuZnVuY3Rpb24gcmVzb2x2ZVN0YWxlVGltZShzdGFsZVRpbWUsIHF1ZXJ5KSB7XG4gIHJldHVybiB0eXBlb2Ygc3RhbGVUaW1lID09PSBcImZ1bmN0aW9uXCIgPyBzdGFsZVRpbWUocXVlcnkpIDogc3RhbGVUaW1lO1xufVxuZnVuY3Rpb24gcmVzb2x2ZVF1ZXJ5Qm9vbGVhbihvcHRpb24sIHF1ZXJ5KSB7XG4gIHJldHVybiB0eXBlb2Ygb3B0aW9uID09PSBcImZ1bmN0aW9uXCIgPyBvcHRpb24ocXVlcnkpIDogb3B0aW9uO1xufVxuZnVuY3Rpb24gbWF0Y2hRdWVyeShmaWx0ZXJzLCBxdWVyeSkge1xuICBjb25zdCB7XG4gICAgdHlwZSA9IFwiYWxsXCIsXG4gICAgZXhhY3QsXG4gICAgZmV0Y2hTdGF0dXMsXG4gICAgcHJlZGljYXRlLFxuICAgIHF1ZXJ5S2V5LFxuICAgIHN0YWxlXG4gIH0gPSBmaWx0ZXJzO1xuICBpZiAocXVlcnlLZXkpIHtcbiAgICBpZiAoZXhhY3QpIHtcbiAgICAgIGlmIChxdWVyeS5xdWVyeUhhc2ggIT09IGhhc2hRdWVyeUtleUJ5T3B0aW9ucyhxdWVyeUtleSwgcXVlcnkub3B0aW9ucykpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoIXBhcnRpYWxNYXRjaEtleShxdWVyeS5xdWVyeUtleSwgcXVlcnlLZXkpKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG4gIGlmICh0eXBlICE9PSBcImFsbFwiKSB7XG4gICAgY29uc3QgaXNBY3RpdmUgPSBxdWVyeS5pc0FjdGl2ZSgpO1xuICAgIGlmICh0eXBlID09PSBcImFjdGl2ZVwiICYmICFpc0FjdGl2ZSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpZiAodHlwZSA9PT0gXCJpbmFjdGl2ZVwiICYmIGlzQWN0aXZlKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG4gIGlmICh0eXBlb2Ygc3RhbGUgPT09IFwiYm9vbGVhblwiICYmIHF1ZXJ5LmlzU3RhbGUoKSAhPT0gc3RhbGUpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKGZldGNoU3RhdHVzICYmIGZldGNoU3RhdHVzICE9PSBxdWVyeS5zdGF0ZS5mZXRjaFN0YXR1cykge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAocHJlZGljYXRlICYmICFwcmVkaWNhdGUocXVlcnkpKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gbWF0Y2hNdXRhdGlvbihmaWx0ZXJzLCBtdXRhdGlvbikge1xuICBjb25zdCB7IGV4YWN0LCBzdGF0dXMsIHByZWRpY2F0ZSwgbXV0YXRpb25LZXkgfSA9IGZpbHRlcnM7XG4gIGlmIChtdXRhdGlvbktleSkge1xuICAgIGlmICghbXV0YXRpb24ub3B0aW9ucy5tdXRhdGlvbktleSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpZiAoZXhhY3QpIHtcbiAgICAgIGlmIChoYXNoS2V5KG11dGF0aW9uLm9wdGlvbnMubXV0YXRpb25LZXkpICE9PSBoYXNoS2V5KG11dGF0aW9uS2V5KSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmICghcGFydGlhbE1hdGNoS2V5KG11dGF0aW9uLm9wdGlvbnMubXV0YXRpb25LZXksIG11dGF0aW9uS2V5KSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuICBpZiAoc3RhdHVzICYmIG11dGF0aW9uLnN0YXRlLnN0YXR1cyAhPT0gc3RhdHVzKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmIChwcmVkaWNhdGUgJiYgIXByZWRpY2F0ZShtdXRhdGlvbikpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiBoYXNoUXVlcnlLZXlCeU9wdGlvbnMocXVlcnlLZXksIG9wdGlvbnMpIHtcbiAgY29uc3QgaGFzaEZuID0gb3B0aW9ucz8ucXVlcnlLZXlIYXNoRm4gfHwgaGFzaEtleTtcbiAgcmV0dXJuIGhhc2hGbihxdWVyeUtleSk7XG59XG5mdW5jdGlvbiBoYXNoS2V5KHF1ZXJ5S2V5KSB7XG4gIHJldHVybiBKU09OLnN0cmluZ2lmeShcbiAgICBxdWVyeUtleSxcbiAgICAoXywgdmFsKSA9PiBpc1BsYWluT2JqZWN0KHZhbCkgPyBPYmplY3Qua2V5cyh2YWwpLnNvcnQoKS5yZWR1Y2UoKHJlc3VsdCwga2V5KSA9PiB7XG4gICAgICByZXN1bHRba2V5XSA9IHZhbFtrZXldO1xuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9LCB7fSkgOiB2YWxcbiAgKTtcbn1cbmZ1bmN0aW9uIHBhcnRpYWxNYXRjaEtleShhLCBiKSB7XG4gIGlmIChhID09PSBiKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgaWYgKHR5cGVvZiBhICE9PSB0eXBlb2YgYikge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoYSAmJiBiICYmIHR5cGVvZiBhID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiBiID09PSBcIm9iamVjdFwiKSB7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoYSkgJiYgQXJyYXkuaXNBcnJheShiKSkge1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBiLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGlmICghcGFydGlhbE1hdGNoS2V5KGFbaV0sIGJbaV0pKSB7XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgY29uc3QgYktleXMgPSBPYmplY3Qua2V5cyhiKTtcbiAgICBmb3IgKGNvbnN0IGtleSBvZiBiS2V5cykge1xuICAgICAgaWYgKCFwYXJ0aWFsTWF0Y2hLZXkoYVtrZXldLCBiW2tleV0pKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxudmFyIGhhc093biA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG5mdW5jdGlvbiByZXBsYWNlRXF1YWxEZWVwKGEsIGIsIGRlcHRoID0gMCkge1xuICBpZiAoYSA9PT0gYikge1xuICAgIHJldHVybiBhO1xuICB9XG4gIGlmIChkZXB0aCA+IDUwMCkgcmV0dXJuIGI7XG4gIGNvbnN0IGFycmF5ID0gaXNQbGFpbkFycmF5KGEpICYmIGlzUGxhaW5BcnJheShiKTtcbiAgaWYgKCFhcnJheSAmJiAhKGlzUGxhaW5PYmplY3QoYSkgJiYgaXNQbGFpbk9iamVjdChiKSkpIHJldHVybiBiO1xuICBjb25zdCBhSXRlbXMgPSBhcnJheSA/IGEgOiBPYmplY3Qua2V5cyhhKTtcbiAgY29uc3QgYVNpemUgPSBhSXRlbXMubGVuZ3RoO1xuICBjb25zdCBiSXRlbXMgPSBhcnJheSA/IGIgOiBPYmplY3Qua2V5cyhiKTtcbiAgY29uc3QgYlNpemUgPSBiSXRlbXMubGVuZ3RoO1xuICBjb25zdCBjb3B5ID0gYXJyYXkgPyBuZXcgQXJyYXkoYlNpemUpIDoge307XG4gIGxldCBlcXVhbEl0ZW1zID0gMDtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBiU2l6ZTsgaSsrKSB7XG4gICAgY29uc3Qga2V5ID0gYXJyYXkgPyBpIDogYkl0ZW1zW2ldO1xuICAgIGNvbnN0IGFJdGVtID0gYVtrZXldO1xuICAgIGNvbnN0IGJJdGVtID0gYltrZXldO1xuICAgIGlmIChhSXRlbSA9PT0gYkl0ZW0pIHtcbiAgICAgIGNvcHlba2V5XSA9IGFJdGVtO1xuICAgICAgaWYgKGFycmF5ID8gaSA8IGFTaXplIDogaGFzT3duLmNhbGwoYSwga2V5KSkgZXF1YWxJdGVtcysrO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChhSXRlbSA9PT0gbnVsbCB8fCBiSXRlbSA9PT0gbnVsbCB8fCB0eXBlb2YgYUl0ZW0gIT09IFwib2JqZWN0XCIgfHwgdHlwZW9mIGJJdGVtICE9PSBcIm9iamVjdFwiKSB7XG4gICAgICBjb3B5W2tleV0gPSBiSXRlbTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCB2ID0gcmVwbGFjZUVxdWFsRGVlcChhSXRlbSwgYkl0ZW0sIGRlcHRoICsgMSk7XG4gICAgY29weVtrZXldID0gdjtcbiAgICBpZiAodiA9PT0gYUl0ZW0pIGVxdWFsSXRlbXMrKztcbiAgfVxuICByZXR1cm4gYVNpemUgPT09IGJTaXplICYmIGVxdWFsSXRlbXMgPT09IGFTaXplID8gYSA6IGNvcHk7XG59XG5mdW5jdGlvbiBzaGFsbG93RXF1YWxPYmplY3RzKGEsIGIpIHtcbiAgaWYgKCFiIHx8IE9iamVjdC5rZXlzKGEpLmxlbmd0aCAhPT0gT2JqZWN0LmtleXMoYikubGVuZ3RoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGZvciAoY29uc3Qga2V5IGluIGEpIHtcbiAgICBpZiAoYVtrZXldICE9PSBiW2tleV0pIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiBpc1BsYWluQXJyYXkodmFsdWUpIHtcbiAgcmV0dXJuIEFycmF5LmlzQXJyYXkodmFsdWUpICYmIHZhbHVlLmxlbmd0aCA9PT0gT2JqZWN0LmtleXModmFsdWUpLmxlbmd0aDtcbn1cbmZ1bmN0aW9uIGlzUGxhaW5PYmplY3Qobykge1xuICBpZiAoIWhhc09iamVjdFByb3RvdHlwZShvKSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBjb25zdCBjdG9yID0gby5jb25zdHJ1Y3RvcjtcbiAgaWYgKGN0b3IgPT09IHZvaWQgMCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGNvbnN0IHByb3QgPSBjdG9yLnByb3RvdHlwZTtcbiAgaWYgKCFoYXNPYmplY3RQcm90b3R5cGUocHJvdCkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKCFwcm90Lmhhc093blByb3BlcnR5KFwiaXNQcm90b3R5cGVPZlwiKSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoT2JqZWN0LmdldFByb3RvdHlwZU9mKG8pICE9PSBPYmplY3QucHJvdG90eXBlKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gaGFzT2JqZWN0UHJvdG90eXBlKG8pIHtcbiAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvKSA9PT0gXCJbb2JqZWN0IE9iamVjdF1cIjtcbn1cbmZ1bmN0aW9uIHNsZWVwKHRpbWVvdXQpIHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgdGltZW91dE1hbmFnZXIuc2V0VGltZW91dChyZXNvbHZlLCB0aW1lb3V0KTtcbiAgfSk7XG59XG5mdW5jdGlvbiByZXBsYWNlRGF0YShwcmV2RGF0YSwgZGF0YSwgb3B0aW9ucykge1xuICBpZiAodHlwZW9mIG9wdGlvbnMuc3RydWN0dXJhbFNoYXJpbmcgPT09IFwiZnVuY3Rpb25cIikge1xuICAgIHJldHVybiBvcHRpb25zLnN0cnVjdHVyYWxTaGFyaW5nKHByZXZEYXRhLCBkYXRhKTtcbiAgfSBlbHNlIGlmIChvcHRpb25zLnN0cnVjdHVyYWxTaGFyaW5nICE9PSBmYWxzZSkge1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiByZXBsYWNlRXF1YWxEZWVwKHByZXZEYXRhLCBkYXRhKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgYFN0cnVjdHVyYWwgc2hhcmluZyByZXF1aXJlcyBkYXRhIHRvIGJlIEpTT04gc2VyaWFsaXphYmxlLiBUbyBmaXggdGhpcywgdHVybiBvZmYgc3RydWN0dXJhbFNoYXJpbmcgb3IgcmV0dXJuIEpTT04tc2VyaWFsaXphYmxlIGRhdGEgZnJvbSB5b3VyIHF1ZXJ5Rm4uIFske29wdGlvbnMucXVlcnlIYXNofV06ICR7ZXJyb3J9YFxuICAgICAgICApO1xuICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHJlcGxhY2VFcXVhbERlZXAocHJldkRhdGEsIGRhdGEpO1xuICB9XG4gIHJldHVybiBkYXRhO1xufVxuZnVuY3Rpb24ga2VlcFByZXZpb3VzRGF0YShwcmV2aW91c0RhdGEpIHtcbiAgcmV0dXJuIHByZXZpb3VzRGF0YTtcbn1cbmZ1bmN0aW9uIGFkZFRvRW5kKGl0ZW1zLCBpdGVtLCBtYXggPSAwKSB7XG4gIGNvbnN0IG5ld0l0ZW1zID0gWy4uLml0ZW1zLCBpdGVtXTtcbiAgcmV0dXJuIG1heCAmJiBuZXdJdGVtcy5sZW5ndGggPiBtYXggPyBuZXdJdGVtcy5zbGljZSgxKSA6IG5ld0l0ZW1zO1xufVxuZnVuY3Rpb24gYWRkVG9TdGFydChpdGVtcywgaXRlbSwgbWF4ID0gMCkge1xuICBjb25zdCBuZXdJdGVtcyA9IFtpdGVtLCAuLi5pdGVtc107XG4gIHJldHVybiBtYXggJiYgbmV3SXRlbXMubGVuZ3RoID4gbWF4ID8gbmV3SXRlbXMuc2xpY2UoMCwgLTEpIDogbmV3SXRlbXM7XG59XG52YXIgc2tpcFRva2VuID0gLyogQF9fUFVSRV9fICovIFN5bWJvbCgpO1xuZnVuY3Rpb24gZW5zdXJlUXVlcnlGbihvcHRpb25zLCBmZXRjaE9wdGlvbnMpIHtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgIGlmIChvcHRpb25zLnF1ZXJ5Rm4gPT09IHNraXBUb2tlbikge1xuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgYEF0dGVtcHRlZCB0byBpbnZva2UgcXVlcnlGbiB3aGVuIHNldCB0byBza2lwVG9rZW4uIFRoaXMgaXMgbGlrZWx5IGEgY29uZmlndXJhdGlvbiBlcnJvci4gUXVlcnkgaGFzaDogJyR7b3B0aW9ucy5xdWVyeUhhc2h9J2BcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIGlmICghb3B0aW9ucy5xdWVyeUZuICYmIGZldGNoT3B0aW9ucz8uaW5pdGlhbFByb21pc2UpIHtcbiAgICByZXR1cm4gKCkgPT4gZmV0Y2hPcHRpb25zLmluaXRpYWxQcm9taXNlO1xuICB9XG4gIGlmICghb3B0aW9ucy5xdWVyeUZuIHx8IG9wdGlvbnMucXVlcnlGbiA9PT0gc2tpcFRva2VuKSB7XG4gICAgcmV0dXJuICgpID0+IFByb21pc2UucmVqZWN0KG5ldyBFcnJvcihgTWlzc2luZyBxdWVyeUZuOiAnJHtvcHRpb25zLnF1ZXJ5SGFzaH0nYCkpO1xuICB9XG4gIHJldHVybiBvcHRpb25zLnF1ZXJ5Rm47XG59XG5mdW5jdGlvbiBzaG91bGRUaHJvd0Vycm9yKHRocm93T25FcnJvciwgcGFyYW1zKSB7XG4gIGlmICh0eXBlb2YgdGhyb3dPbkVycm9yID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICByZXR1cm4gdGhyb3dPbkVycm9yKC4uLnBhcmFtcyk7XG4gIH1cbiAgcmV0dXJuICEhdGhyb3dPbkVycm9yO1xufVxuZnVuY3Rpb24gYWRkQ29uc3VtZUF3YXJlU2lnbmFsKG9iamVjdCwgZ2V0U2lnbmFsLCBvbkNhbmNlbGxlZCkge1xuICBsZXQgY29uc3VtZWQgPSBmYWxzZTtcbiAgbGV0IHNpZ25hbDtcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG9iamVjdCwgXCJzaWduYWxcIiwge1xuICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgZ2V0OiAoKSA9PiB7XG4gICAgICBzaWduYWwgPz89IGdldFNpZ25hbCgpO1xuICAgICAgaWYgKGNvbnN1bWVkKSB7XG4gICAgICAgIHJldHVybiBzaWduYWw7XG4gICAgICB9XG4gICAgICBjb25zdW1lZCA9IHRydWU7XG4gICAgICBpZiAoc2lnbmFsLmFib3J0ZWQpIHtcbiAgICAgICAgb25DYW5jZWxsZWQoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgb25DYW5jZWxsZWQsIHsgb25jZTogdHJ1ZSB9KTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzaWduYWw7XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIG9iamVjdDtcbn1cbmV4cG9ydCB7XG4gIGFkZENvbnN1bWVBd2FyZVNpZ25hbCxcbiAgYWRkVG9FbmQsXG4gIGFkZFRvU3RhcnQsXG4gIGVuc3VyZVF1ZXJ5Rm4sXG4gIGZ1bmN0aW9uYWxVcGRhdGUsXG4gIGhhc2hLZXksXG4gIGhhc2hRdWVyeUtleUJ5T3B0aW9ucyxcbiAgaXNQbGFpbkFycmF5LFxuICBpc1BsYWluT2JqZWN0LFxuICBpc1NlcnZlcixcbiAgaXNWYWxpZFRpbWVvdXQsXG4gIGtlZXBQcmV2aW91c0RhdGEsXG4gIG1hdGNoTXV0YXRpb24sXG4gIG1hdGNoUXVlcnksXG4gIG5vb3AsXG4gIHBhcnRpYWxNYXRjaEtleSxcbiAgcmVwbGFjZURhdGEsXG4gIHJlcGxhY2VFcXVhbERlZXAsXG4gIHJlc29sdmVRdWVyeUJvb2xlYW4sXG4gIHJlc29sdmVTdGFsZVRpbWUsXG4gIHNoYWxsb3dFcXVhbE9iamVjdHMsXG4gIHNob3VsZFRocm93RXJyb3IsXG4gIHNraXBUb2tlbixcbiAgc2xlZXAsXG4gIHRpbWVVbnRpbFN0YWxlXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXRpbHMuanMubWFwIiwiLy8gc3JjL2Vudmlyb25tZW50TWFuYWdlci50c1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xudmFyIGVudmlyb25tZW50TWFuYWdlciA9IC8qIEBfX1BVUkVfXyAqLyAoKCkgPT4ge1xuICBsZXQgaXNTZXJ2ZXJGbiA9ICgpID0+IGlzU2VydmVyO1xuICByZXR1cm4ge1xuICAgIC8qKlxuICAgICAqIFJldHVybnMgd2hldGhlciB0aGUgY3VycmVudCBydW50aW1lIHNob3VsZCBiZSB0cmVhdGVkIGFzIGEgc2VydmVyIGVudmlyb25tZW50LlxuICAgICAqL1xuICAgIGlzU2VydmVyKCkge1xuICAgICAgcmV0dXJuIGlzU2VydmVyRm4oKTtcbiAgICB9LFxuICAgIC8qKlxuICAgICAqIE92ZXJyaWRlcyB0aGUgc2VydmVyIGNoZWNrIGdsb2JhbGx5LlxuICAgICAqL1xuICAgIHNldElzU2VydmVyKGlzU2VydmVyVmFsdWUpIHtcbiAgICAgIGlzU2VydmVyRm4gPSBpc1NlcnZlclZhbHVlO1xuICAgIH1cbiAgfTtcbn0pKCk7XG5leHBvcnQge1xuICBlbnZpcm9ubWVudE1hbmFnZXJcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1lbnZpcm9ubWVudE1hbmFnZXIuanMubWFwIiwiLy8gc3JjL3RoZW5hYmxlLnRzXG5pbXBvcnQgeyBub29wIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmZ1bmN0aW9uIHBlbmRpbmdUaGVuYWJsZSgpIHtcbiAgbGV0IHJlc29sdmU7XG4gIGxldCByZWplY3Q7XG4gIGNvbnN0IHRoZW5hYmxlID0gbmV3IFByb21pc2UoKF9yZXNvbHZlLCBfcmVqZWN0KSA9PiB7XG4gICAgcmVzb2x2ZSA9IF9yZXNvbHZlO1xuICAgIHJlamVjdCA9IF9yZWplY3Q7XG4gIH0pO1xuICB0aGVuYWJsZS5zdGF0dXMgPSBcInBlbmRpbmdcIjtcbiAgdGhlbmFibGUuY2F0Y2goKCkgPT4ge1xuICB9KTtcbiAgZnVuY3Rpb24gZmluYWxpemUoZGF0YSkge1xuICAgIE9iamVjdC5hc3NpZ24odGhlbmFibGUsIGRhdGEpO1xuICAgIGRlbGV0ZSB0aGVuYWJsZS5yZXNvbHZlO1xuICAgIGRlbGV0ZSB0aGVuYWJsZS5yZWplY3Q7XG4gIH1cbiAgdGhlbmFibGUucmVzb2x2ZSA9ICh2YWx1ZSkgPT4ge1xuICAgIGZpbmFsaXplKHtcbiAgICAgIHN0YXR1czogXCJmdWxmaWxsZWRcIixcbiAgICAgIHZhbHVlXG4gICAgfSk7XG4gICAgcmVzb2x2ZSh2YWx1ZSk7XG4gIH07XG4gIHRoZW5hYmxlLnJlamVjdCA9IChyZWFzb24pID0+IHtcbiAgICBmaW5hbGl6ZSh7XG4gICAgICBzdGF0dXM6IFwicmVqZWN0ZWRcIixcbiAgICAgIHJlYXNvblxuICAgIH0pO1xuICAgIHJlamVjdChyZWFzb24pO1xuICB9O1xuICByZXR1cm4gdGhlbmFibGU7XG59XG5mdW5jdGlvbiB0cnlSZXNvbHZlU3luYyhwcm9taXNlKSB7XG4gIGxldCBkYXRhO1xuICBwcm9taXNlLnRoZW4oKHJlc3VsdCkgPT4ge1xuICAgIGRhdGEgPSByZXN1bHQ7XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfSwgbm9vcCk/LmNhdGNoKG5vb3ApO1xuICBpZiAoZGF0YSAhPT0gdm9pZCAwKSB7XG4gICAgcmV0dXJuIHsgZGF0YSB9O1xuICB9XG4gIHJldHVybiB2b2lkIDA7XG59XG5leHBvcnQge1xuICBwZW5kaW5nVGhlbmFibGUsXG4gIHRyeVJlc29sdmVTeW5jXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dGhlbmFibGUuanMubWFwIiwiLy8gc3JjL2h5ZHJhdGlvbi50c1xuaW1wb3J0IHsgdHJ5UmVzb2x2ZVN5bmMgfSBmcm9tIFwiLi90aGVuYWJsZS5qc1wiO1xuaW1wb3J0IHsgbm9vcCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5mdW5jdGlvbiBkZWZhdWx0VHJhbnNmb3JtZXJGbihkYXRhKSB7XG4gIHJldHVybiBkYXRhO1xufVxuZnVuY3Rpb24gZGVoeWRyYXRlTXV0YXRpb24obXV0YXRpb24pIHtcbiAgcmV0dXJuIHtcbiAgICBtdXRhdGlvbktleTogbXV0YXRpb24ub3B0aW9ucy5tdXRhdGlvbktleSxcbiAgICBzdGF0ZTogbXV0YXRpb24uc3RhdGUsXG4gICAgLi4ubXV0YXRpb24ub3B0aW9ucy5zY29wZSAmJiB7IHNjb3BlOiBtdXRhdGlvbi5vcHRpb25zLnNjb3BlIH0sXG4gICAgLi4ubXV0YXRpb24ubWV0YSAmJiB7IG1ldGE6IG11dGF0aW9uLm1ldGEgfVxuICB9O1xufVxuZnVuY3Rpb24gZGVoeWRyYXRlUXVlcnkocXVlcnksIHNlcmlhbGl6ZURhdGEsIHNob3VsZFJlZGFjdEVycm9ycykge1xuICBjb25zdCBkZWh5ZHJhdGVQcm9taXNlID0gKCkgPT4ge1xuICAgIGNvbnN0IHByb21pc2UgPSBxdWVyeS5wcm9taXNlPy50aGVuKHNlcmlhbGl6ZURhdGEpLmNhdGNoKChlcnJvcikgPT4ge1xuICAgICAgaWYgKCFzaG91bGRSZWRhY3RFcnJvcnMoZXJyb3IpKSB7XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gICAgICB9XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgYEEgcXVlcnkgdGhhdCB3YXMgZGVoeWRyYXRlZCBhcyBwZW5kaW5nIGVuZGVkIHVwIHJlamVjdGluZy4gWyR7cXVlcnkucXVlcnlIYXNofV06ICR7ZXJyb3J9OyBUaGUgZXJyb3Igd2lsbCBiZSByZWRhY3RlZCBpbiBwcm9kdWN0aW9uIGJ1aWxkc2BcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChuZXcgRXJyb3IoXCJyZWRhY3RlZFwiKSk7XG4gICAgfSk7XG4gICAgcHJvbWlzZT8uY2F0Y2gobm9vcCk7XG4gICAgcmV0dXJuIHByb21pc2U7XG4gIH07XG4gIHJldHVybiB7XG4gICAgZGVoeWRyYXRlZEF0OiBEYXRlLm5vdygpLFxuICAgIHN0YXRlOiB7XG4gICAgICAuLi5xdWVyeS5zdGF0ZSxcbiAgICAgIC4uLnF1ZXJ5LnN0YXRlLmRhdGEgIT09IHZvaWQgMCAmJiB7XG4gICAgICAgIGRhdGE6IHNlcmlhbGl6ZURhdGEocXVlcnkuc3RhdGUuZGF0YSlcbiAgICAgIH1cbiAgICB9LFxuICAgIHF1ZXJ5S2V5OiBxdWVyeS5xdWVyeUtleSxcbiAgICBxdWVyeUhhc2g6IHF1ZXJ5LnF1ZXJ5SGFzaCxcbiAgICAuLi5xdWVyeS5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiICYmIHtcbiAgICAgIHByb21pc2U6IGRlaHlkcmF0ZVByb21pc2UoKVxuICAgIH0sXG4gICAgLi4ucXVlcnkubWV0YSAmJiB7IG1ldGE6IHF1ZXJ5Lm1ldGEgfSxcbiAgICAuLi5xdWVyeS5xdWVyeVR5cGUgJiYgeyBxdWVyeVR5cGU6IHF1ZXJ5LnF1ZXJ5VHlwZSB9XG4gIH07XG59XG5mdW5jdGlvbiBkZWZhdWx0U2hvdWxkRGVoeWRyYXRlTXV0YXRpb24obXV0YXRpb24pIHtcbiAgcmV0dXJuIG11dGF0aW9uLnN0YXRlLmlzUGF1c2VkO1xufVxuZnVuY3Rpb24gZGVmYXVsdFNob3VsZERlaHlkcmF0ZVF1ZXJ5KHF1ZXJ5KSB7XG4gIHJldHVybiBxdWVyeS5zdGF0ZS5zdGF0dXMgPT09IFwic3VjY2Vzc1wiO1xufVxuZnVuY3Rpb24gZGVmYXVsdFNob3VsZFJlZGFjdEVycm9ycyhfKSB7XG4gIHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gZGVoeWRyYXRlKGNsaWVudCwgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IGZpbHRlck11dGF0aW9uID0gb3B0aW9ucy5zaG91bGREZWh5ZHJhdGVNdXRhdGlvbiA/PyBjbGllbnQuZ2V0RGVmYXVsdE9wdGlvbnMoKS5kZWh5ZHJhdGU/LnNob3VsZERlaHlkcmF0ZU11dGF0aW9uID8/IGRlZmF1bHRTaG91bGREZWh5ZHJhdGVNdXRhdGlvbjtcbiAgY29uc3QgbXV0YXRpb25zID0gY2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKS5nZXRBbGwoKS5mbGF0TWFwKFxuICAgIChtdXRhdGlvbikgPT4gZmlsdGVyTXV0YXRpb24obXV0YXRpb24pID8gW2RlaHlkcmF0ZU11dGF0aW9uKG11dGF0aW9uKV0gOiBbXVxuICApO1xuICBjb25zdCBmaWx0ZXJRdWVyeSA9IG9wdGlvbnMuc2hvdWxkRGVoeWRyYXRlUXVlcnkgPz8gY2xpZW50LmdldERlZmF1bHRPcHRpb25zKCkuZGVoeWRyYXRlPy5zaG91bGREZWh5ZHJhdGVRdWVyeSA/PyBkZWZhdWx0U2hvdWxkRGVoeWRyYXRlUXVlcnk7XG4gIGNvbnN0IHNob3VsZFJlZGFjdEVycm9ycyA9IG9wdGlvbnMuc2hvdWxkUmVkYWN0RXJyb3JzID8/IGNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLmRlaHlkcmF0ZT8uc2hvdWxkUmVkYWN0RXJyb3JzID8/IGRlZmF1bHRTaG91bGRSZWRhY3RFcnJvcnM7XG4gIGNvbnN0IHNlcmlhbGl6ZURhdGEgPSBvcHRpb25zLnNlcmlhbGl6ZURhdGEgPz8gY2xpZW50LmdldERlZmF1bHRPcHRpb25zKCkuZGVoeWRyYXRlPy5zZXJpYWxpemVEYXRhID8/IGRlZmF1bHRUcmFuc2Zvcm1lckZuO1xuICBjb25zdCBxdWVyaWVzID0gY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5nZXRBbGwoKS5mbGF0TWFwKFxuICAgIChxdWVyeSkgPT4gZmlsdGVyUXVlcnkocXVlcnkpID8gW2RlaHlkcmF0ZVF1ZXJ5KHF1ZXJ5LCBzZXJpYWxpemVEYXRhLCBzaG91bGRSZWRhY3RFcnJvcnMpXSA6IFtdXG4gICk7XG4gIHJldHVybiB7IG11dGF0aW9ucywgcXVlcmllcyB9O1xufVxuZnVuY3Rpb24gaHlkcmF0ZShjbGllbnQsIGRlaHlkcmF0ZWRTdGF0ZSwgb3B0aW9ucykge1xuICBpZiAodHlwZW9mIGRlaHlkcmF0ZWRTdGF0ZSAhPT0gXCJvYmplY3RcIiB8fCBkZWh5ZHJhdGVkU3RhdGUgPT09IG51bGwpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgbXV0YXRpb25DYWNoZSA9IGNsaWVudC5nZXRNdXRhdGlvbkNhY2hlKCk7XG4gIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpO1xuICBjb25zdCBkZXNlcmlhbGl6ZURhdGEgPSBvcHRpb25zPy5kZWZhdWx0T3B0aW9ucz8uZGVzZXJpYWxpemVEYXRhID8/IGNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLmh5ZHJhdGU/LmRlc2VyaWFsaXplRGF0YSA/PyBkZWZhdWx0VHJhbnNmb3JtZXJGbjtcbiAgY29uc3QgbXV0YXRpb25zID0gZGVoeWRyYXRlZFN0YXRlLm11dGF0aW9ucyB8fCBbXTtcbiAgY29uc3QgcXVlcmllcyA9IGRlaHlkcmF0ZWRTdGF0ZS5xdWVyaWVzIHx8IFtdO1xuICBtdXRhdGlvbnMuZm9yRWFjaCgoeyBzdGF0ZSwgLi4ubXV0YXRpb25PcHRpb25zIH0pID0+IHtcbiAgICBtdXRhdGlvbkNhY2hlLmJ1aWxkKFxuICAgICAgY2xpZW50LFxuICAgICAge1xuICAgICAgICAuLi5jbGllbnQuZ2V0RGVmYXVsdE9wdGlvbnMoKS5oeWRyYXRlPy5tdXRhdGlvbnMsXG4gICAgICAgIC4uLm9wdGlvbnM/LmRlZmF1bHRPcHRpb25zPy5tdXRhdGlvbnMsXG4gICAgICAgIC4uLm11dGF0aW9uT3B0aW9uc1xuICAgICAgfSxcbiAgICAgIHN0YXRlXG4gICAgKTtcbiAgfSk7XG4gIHF1ZXJpZXMuZm9yRWFjaChcbiAgICAoe1xuICAgICAgcXVlcnlLZXksXG4gICAgICBzdGF0ZSxcbiAgICAgIHF1ZXJ5SGFzaCxcbiAgICAgIG1ldGEsXG4gICAgICBwcm9taXNlLFxuICAgICAgZGVoeWRyYXRlZEF0LFxuICAgICAgcXVlcnlUeXBlXG4gICAgfSkgPT4ge1xuICAgICAgY29uc3Qgc3luY0RhdGEgPSBwcm9taXNlID8gdHJ5UmVzb2x2ZVN5bmMocHJvbWlzZSkgOiB2b2lkIDA7XG4gICAgICBjb25zdCByYXdEYXRhID0gc3RhdGUuZGF0YSA9PT0gdm9pZCAwID8gc3luY0RhdGE/LmRhdGEgOiBzdGF0ZS5kYXRhO1xuICAgICAgY29uc3QgZGF0YSA9IHJhd0RhdGEgPT09IHZvaWQgMCA/IHJhd0RhdGEgOiBkZXNlcmlhbGl6ZURhdGEocmF3RGF0YSk7XG4gICAgICBsZXQgcXVlcnkgPSBxdWVyeUNhY2hlLmdldChxdWVyeUhhc2gpO1xuICAgICAgY29uc3QgZXhpc3RpbmdRdWVyeUlzUGVuZGluZyA9IHF1ZXJ5Py5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiO1xuICAgICAgY29uc3QgZXhpc3RpbmdRdWVyeUlzRmV0Y2hpbmcgPSBxdWVyeT8uc3RhdGUuZmV0Y2hTdGF0dXMgPT09IFwiZmV0Y2hpbmdcIjtcbiAgICAgIGlmIChxdWVyeSkge1xuICAgICAgICBjb25zdCBoYXNOZXdlclN5bmNEYXRhID0gc3luY0RhdGEgJiYgLy8gV2Ugb25seSBuZWVkIHRoaXMgdW5kZWZpbmVkIGNoZWNrIHRvIGhhbmRsZSBvbGRlciBkZWh5ZHJhdGlvblxuICAgICAgICAvLyBwYXlsb2FkcyB0aGF0IG1pZ2h0IG5vdCBoYXZlIGRlaHlkcmF0ZWRBdFxuICAgICAgICBkZWh5ZHJhdGVkQXQgIT09IHZvaWQgMCAmJiBkZWh5ZHJhdGVkQXQgPiBxdWVyeS5zdGF0ZS5kYXRhVXBkYXRlZEF0O1xuICAgICAgICBpZiAoc3RhdGUuZGF0YVVwZGF0ZWRBdCA+IHF1ZXJ5LnN0YXRlLmRhdGFVcGRhdGVkQXQgfHwgaGFzTmV3ZXJTeW5jRGF0YSkge1xuICAgICAgICAgIGNvbnN0IHsgZmV0Y2hTdGF0dXM6IF9pZ25vcmVkLCAuLi5zZXJpYWxpemVkU3RhdGUgfSA9IHN0YXRlO1xuICAgICAgICAgIHF1ZXJ5LnNldFN0YXRlKHtcbiAgICAgICAgICAgIC4uLnNlcmlhbGl6ZWRTdGF0ZSxcbiAgICAgICAgICAgIGRhdGEsXG4gICAgICAgICAgICAvLyBJZiB0aGUgcXVlcnkgd2FzIHBlbmRpbmcgYXQgdGhlIG1vbWVudCBvZiBkZWh5ZHJhdGlvbiwgYnV0IHJlc29sdmVkIHRvIGhhdmUgZGF0YVxuICAgICAgICAgICAgLy8gYmVmb3JlIGh5ZHJhdGlvbiwgd2UgY2FuIGFzc3VtZSB0aGUgcXVlcnkgc2hvdWxkIGJlIGh5ZHJhdGVkIGFzIHN1Y2Nlc3NmdWwuXG4gICAgICAgICAgICAvL1xuICAgICAgICAgICAgLy8gU2luY2UgeW91IGNhbiBvcHQgaW50byBkZWh5ZHJhdGluZyBmYWlsZWQgcXVlcmllcywgYW5kIHRob3NlIGNhbiBoYXZlIGRhdGEgZnJvbVxuICAgICAgICAgICAgLy8gcHJldmlvdXMgc3VjY2Vzc2Z1bCBmZXRjaGVzLCB3ZSBtYWtlIHN1cmUgd2Ugb25seSBkbyB0aGlzIGZvciBwZW5kaW5nIHF1ZXJpZXMuXG4gICAgICAgICAgICAuLi5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiICYmIGRhdGEgIT09IHZvaWQgMCAmJiB7XG4gICAgICAgICAgICAgIHN0YXR1czogXCJzdWNjZXNzXCIsXG4gICAgICAgICAgICAgIGRhdGFVcGRhdGVkQXQ6IGRlaHlkcmF0ZWRBdCA/PyBEYXRlLm5vdygpLFxuICAgICAgICAgICAgICAvLyBQcmVzZXJ2ZSBleGlzdGluZyBmZXRjaFN0YXR1cyBpZiB0aGUgZXhpc3RpbmcgcXVlcnkgaXMgYWN0aXZlbHkgZmV0Y2hpbmcuXG4gICAgICAgICAgICAgIC4uLiFleGlzdGluZ1F1ZXJ5SXNGZXRjaGluZyAmJiB7XG4gICAgICAgICAgICAgICAgZmV0Y2hTdGF0dXM6IFwiaWRsZVwiXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcXVlcnkgPSBxdWVyeUNhY2hlLmJ1aWxkKFxuICAgICAgICAgIGNsaWVudCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICAuLi5jbGllbnQuZ2V0RGVmYXVsdE9wdGlvbnMoKS5oeWRyYXRlPy5xdWVyaWVzLFxuICAgICAgICAgICAgLi4ub3B0aW9ucz8uZGVmYXVsdE9wdGlvbnM/LnF1ZXJpZXMsXG4gICAgICAgICAgICBxdWVyeUtleSxcbiAgICAgICAgICAgIHF1ZXJ5SGFzaCxcbiAgICAgICAgICAgIG1ldGEsXG4gICAgICAgICAgICBfdHlwZTogcXVlcnlUeXBlXG4gICAgICAgICAgfSxcbiAgICAgICAgICAvLyBSZXNldCBmZXRjaCBzdGF0dXMgdG8gaWRsZSB0byBhdm9pZFxuICAgICAgICAgIC8vIHF1ZXJ5IGJlaW5nIHN0dWNrIGluIGZldGNoaW5nIHN0YXRlIHVwb24gaHlkcmF0aW9uXG4gICAgICAgICAge1xuICAgICAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgICAgICBkYXRhLFxuICAgICAgICAgICAgZmV0Y2hTdGF0dXM6IFwiaWRsZVwiLFxuICAgICAgICAgICAgLy8gTGlrZSBhYm92ZSwgaWYgdGhlIHF1ZXJ5IHdhcyBwZW5kaW5nIGF0IHRoZSBtb21lbnQgb2YgZGVoeWRyYXRpb24gYnV0IGhhcyBkYXRhLFxuICAgICAgICAgICAgLy8gd2UgY2FuIGFzc3VtZSBpdCBzaG91bGQgYmUgaHlkcmF0ZWQgYXMgc3VjY2Vzc2Z1bC5cbiAgICAgICAgICAgIHN0YXR1czogc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIiAmJiBkYXRhICE9PSB2b2lkIDAgPyBcInN1Y2Nlc3NcIiA6IHN0YXRlLnN0YXR1cyxcbiAgICAgICAgICAgIC4uLnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIgJiYgZGF0YSAhPT0gdm9pZCAwICYmIHtcbiAgICAgICAgICAgICAgZGF0YVVwZGF0ZWRBdDogZGVoeWRyYXRlZEF0ID8/IERhdGUubm93KClcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBpZiAocHJvbWlzZSAmJiAvLyBJZiB0aGUgZGF0YSB3YXMgc3luY2hyb25vdXNseSBhdmFpbGFibGUsIHRoZXJlIGlzIG5vIG5lZWQgdG8gc2V0IHVwXG4gICAgICAvLyBhIHJldHJ5ZXIgYW5kIHRodXMgbm8gcmVhc29uIHRvIGNhbGwgZmV0Y2hcbiAgICAgICFzeW5jRGF0YSAmJiAhZXhpc3RpbmdRdWVyeUlzUGVuZGluZyAmJiAhZXhpc3RpbmdRdWVyeUlzRmV0Y2hpbmcgJiYgLy8gT25seSBoeWRyYXRlIGlmIGRlaHlkcmF0aW9uIGlzIG5ld2VyIHRoYW4gYW55IGV4aXN0aW5nIGRhdGEsXG4gICAgICAvLyB0aGlzIGlzIGFsd2F5cyB0cnVlIGZvciBuZXcgcXVlcmllc1xuICAgICAgKGRlaHlkcmF0ZWRBdCA9PT0gdm9pZCAwIHx8IGRlaHlkcmF0ZWRBdCA+IHF1ZXJ5LnN0YXRlLmRhdGFVcGRhdGVkQXQpKSB7XG4gICAgICAgIHF1ZXJ5LmZldGNoKHZvaWQgMCwge1xuICAgICAgICAgIC8vIFJTQyB0cmFuc2Zvcm1lZCBwcm9taXNlcyBhcmUgbm90IHRoZW5hYmxlXG4gICAgICAgICAgaW5pdGlhbFByb21pc2U6IFByb21pc2UucmVzb2x2ZShwcm9taXNlKS50aGVuKGRlc2VyaWFsaXplRGF0YSlcbiAgICAgICAgfSkuY2F0Y2gobm9vcCk7XG4gICAgICB9XG4gICAgfVxuICApO1xufVxuZXhwb3J0IHtcbiAgZGVmYXVsdFNob3VsZERlaHlkcmF0ZU11dGF0aW9uLFxuICBkZWZhdWx0U2hvdWxkRGVoeWRyYXRlUXVlcnksXG4gIGRlaHlkcmF0ZSxcbiAgaHlkcmF0ZVxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWh5ZHJhdGlvbi5qcy5tYXAiLCIvLyBzcmMvbm90aWZ5TWFuYWdlci50c1xuaW1wb3J0IHsgc3lzdGVtU2V0VGltZW91dFplcm8gfSBmcm9tIFwiLi90aW1lb3V0TWFuYWdlci5qc1wiO1xudmFyIGRlZmF1bHRTY2hlZHVsZXIgPSBzeXN0ZW1TZXRUaW1lb3V0WmVybztcbmZ1bmN0aW9uIGNyZWF0ZU5vdGlmeU1hbmFnZXIoKSB7XG4gIGxldCBxdWV1ZSA9IFtdO1xuICBsZXQgdHJhbnNhY3Rpb25zID0gMDtcbiAgbGV0IG5vdGlmeUZuID0gKGNhbGxiYWNrKSA9PiB7XG4gICAgY2FsbGJhY2soKTtcbiAgfTtcbiAgbGV0IGJhdGNoTm90aWZ5Rm4gPSAoY2FsbGJhY2spID0+IHtcbiAgICBjYWxsYmFjaygpO1xuICB9O1xuICBsZXQgc2NoZWR1bGVGbiA9IGRlZmF1bHRTY2hlZHVsZXI7XG4gIGNvbnN0IHNjaGVkdWxlID0gKGNhbGxiYWNrKSA9PiB7XG4gICAgaWYgKHRyYW5zYWN0aW9ucykge1xuICAgICAgcXVldWUucHVzaChjYWxsYmFjayk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNjaGVkdWxlRm4oKCkgPT4ge1xuICAgICAgICBub3RpZnlGbihjYWxsYmFjayk7XG4gICAgICB9KTtcbiAgICB9XG4gIH07XG4gIGNvbnN0IGZsdXNoID0gKCkgPT4ge1xuICAgIGNvbnN0IG9yaWdpbmFsUXVldWUgPSBxdWV1ZTtcbiAgICBxdWV1ZSA9IFtdO1xuICAgIGlmIChvcmlnaW5hbFF1ZXVlLmxlbmd0aCkge1xuICAgICAgc2NoZWR1bGVGbigoKSA9PiB7XG4gICAgICAgIGJhdGNoTm90aWZ5Rm4oKCkgPT4ge1xuICAgICAgICAgIG9yaWdpbmFsUXVldWUuZm9yRWFjaCgoY2FsbGJhY2spID0+IHtcbiAgICAgICAgICAgIG5vdGlmeUZuKGNhbGxiYWNrKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9XG4gIH07XG4gIHJldHVybiB7XG4gICAgYmF0Y2g6IChjYWxsYmFjaykgPT4ge1xuICAgICAgbGV0IHJlc3VsdDtcbiAgICAgIHRyYW5zYWN0aW9ucysrO1xuICAgICAgdHJ5IHtcbiAgICAgICAgcmVzdWx0ID0gY2FsbGJhY2soKTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHRyYW5zYWN0aW9ucy0tO1xuICAgICAgICBpZiAoIXRyYW5zYWN0aW9ucykge1xuICAgICAgICAgIGZsdXNoKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfSxcbiAgICAvKipcbiAgICAgKiBBbGwgY2FsbHMgdG8gdGhlIHdyYXBwZWQgZnVuY3Rpb24gd2lsbCBiZSBiYXRjaGVkLlxuICAgICAqL1xuICAgIGJhdGNoQ2FsbHM6IChjYWxsYmFjaykgPT4ge1xuICAgICAgcmV0dXJuICguLi5hcmdzKSA9PiB7XG4gICAgICAgIHNjaGVkdWxlKCgpID0+IHtcbiAgICAgICAgICBjYWxsYmFjayguLi5hcmdzKTtcbiAgICAgICAgfSk7XG4gICAgICB9O1xuICAgIH0sXG4gICAgc2NoZWR1bGUsXG4gICAgLyoqXG4gICAgICogVXNlIHRoaXMgbWV0aG9kIHRvIHNldCBhIGN1c3RvbSBub3RpZnkgZnVuY3Rpb24uXG4gICAgICogVGhpcyBjYW4gYmUgdXNlZCB0byBmb3IgZXhhbXBsZSB3cmFwIG5vdGlmaWNhdGlvbnMgd2l0aCBgUmVhY3QuYWN0YCB3aGlsZSBydW5uaW5nIHRlc3RzLlxuICAgICAqL1xuICAgIHNldE5vdGlmeUZ1bmN0aW9uOiAoZm4pID0+IHtcbiAgICAgIG5vdGlmeUZuID0gZm47XG4gICAgfSxcbiAgICAvKipcbiAgICAgKiBVc2UgdGhpcyBtZXRob2QgdG8gc2V0IGEgY3VzdG9tIGZ1bmN0aW9uIHRvIGJhdGNoIG5vdGlmaWNhdGlvbnMgdG9nZXRoZXIgaW50byBhIHNpbmdsZSB0aWNrLlxuICAgICAqIEJ5IGRlZmF1bHQgUmVhY3QgUXVlcnkgd2lsbCB1c2UgdGhlIGJhdGNoIGZ1bmN0aW9uIHByb3ZpZGVkIGJ5IFJlYWN0RE9NIG9yIFJlYWN0IE5hdGl2ZS5cbiAgICAgKi9cbiAgICBzZXRCYXRjaE5vdGlmeUZ1bmN0aW9uOiAoZm4pID0+IHtcbiAgICAgIGJhdGNoTm90aWZ5Rm4gPSBmbjtcbiAgICB9LFxuICAgIHNldFNjaGVkdWxlcjogKGZuKSA9PiB7XG4gICAgICBzY2hlZHVsZUZuID0gZm47XG4gICAgfVxuICB9O1xufVxudmFyIG5vdGlmeU1hbmFnZXIgPSBjcmVhdGVOb3RpZnlNYW5hZ2VyKCk7XG5leHBvcnQge1xuICBjcmVhdGVOb3RpZnlNYW5hZ2VyLFxuICBkZWZhdWx0U2NoZWR1bGVyLFxuICBub3RpZnlNYW5hZ2VyXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bm90aWZ5TWFuYWdlci5qcy5tYXAiLCIvLyBzcmMvb25saW5lTWFuYWdlci50c1xuaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG52YXIgT25saW5lTWFuYWdlciA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcbiAgI29ubGluZSA9IHRydWU7XG4gICNjbGVhbnVwO1xuICAjc2V0dXA7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy4jc2V0dXAgPSAob25PbmxpbmUpID0+IHtcbiAgICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKSB7XG4gICAgICAgIGNvbnN0IG9ubGluZUxpc3RlbmVyID0gKCkgPT4gb25PbmxpbmUodHJ1ZSk7XG4gICAgICAgIGNvbnN0IG9mZmxpbmVMaXN0ZW5lciA9ICgpID0+IG9uT25saW5lKGZhbHNlKTtcbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJvbmxpbmVcIiwgb25saW5lTGlzdGVuZXIsIGZhbHNlKTtcbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJvZmZsaW5lXCIsIG9mZmxpbmVMaXN0ZW5lciwgZmFsc2UpO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwib25saW5lXCIsIG9ubGluZUxpc3RlbmVyKTtcbiAgICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIm9mZmxpbmVcIiwgb2ZmbGluZUxpc3RlbmVyKTtcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9O1xuICB9XG4gIG9uU3Vic2NyaWJlKCkge1xuICAgIGlmICghdGhpcy4jY2xlYW51cCkge1xuICAgICAgdGhpcy5zZXRFdmVudExpc3RlbmVyKHRoaXMuI3NldHVwKTtcbiAgICB9XG4gIH1cbiAgb25VbnN1YnNjcmliZSgpIHtcbiAgICBpZiAoIXRoaXMuaGFzTGlzdGVuZXJzKCkpIHtcbiAgICAgIHRoaXMuI2NsZWFudXA/LigpO1xuICAgICAgdGhpcy4jY2xlYW51cCA9IHZvaWQgMDtcbiAgICB9XG4gIH1cbiAgc2V0RXZlbnRMaXN0ZW5lcihzZXR1cCkge1xuICAgIHRoaXMuI3NldHVwID0gc2V0dXA7XG4gICAgdGhpcy4jY2xlYW51cD8uKCk7XG4gICAgdGhpcy4jY2xlYW51cCA9IHNldHVwKHRoaXMuc2V0T25saW5lLmJpbmQodGhpcykpO1xuICB9XG4gIHNldE9ubGluZShvbmxpbmUpIHtcbiAgICBjb25zdCBjaGFuZ2VkID0gdGhpcy4jb25saW5lICE9PSBvbmxpbmU7XG4gICAgaWYgKGNoYW5nZWQpIHtcbiAgICAgIHRoaXMuI29ubGluZSA9IG9ubGluZTtcbiAgICAgIHRoaXMubGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG4gICAgICAgIGxpc3RlbmVyKG9ubGluZSk7XG4gICAgICB9KTtcbiAgICB9XG4gIH1cbiAgaXNPbmxpbmUoKSB7XG4gICAgcmV0dXJuIHRoaXMuI29ubGluZTtcbiAgfVxufTtcbnZhciBvbmxpbmVNYW5hZ2VyID0gbmV3IE9ubGluZU1hbmFnZXIoKTtcbmV4cG9ydCB7XG4gIE9ubGluZU1hbmFnZXIsXG4gIG9ubGluZU1hbmFnZXJcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1vbmxpbmVNYW5hZ2VyLmpzLm1hcCIsIi8vIHNyYy9yZXRyeWVyLnRzXG5pbXBvcnQgeyBmb2N1c01hbmFnZXIgfSBmcm9tIFwiLi9mb2N1c01hbmFnZXIuanNcIjtcbmltcG9ydCB7IG9ubGluZU1hbmFnZXIgfSBmcm9tIFwiLi9vbmxpbmVNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBwZW5kaW5nVGhlbmFibGUgfSBmcm9tIFwiLi90aGVuYWJsZS5qc1wiO1xuaW1wb3J0IHsgZW52aXJvbm1lbnRNYW5hZ2VyIH0gZnJvbSBcIi4vZW52aXJvbm1lbnRNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBzbGVlcCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5mdW5jdGlvbiBkZWZhdWx0UmV0cnlEZWxheShmYWlsdXJlQ291bnQpIHtcbiAgcmV0dXJuIE1hdGgubWluKDFlMyAqIDIgKiogZmFpbHVyZUNvdW50LCAzZTQpO1xufVxuZnVuY3Rpb24gY2FuRmV0Y2gobmV0d29ya01vZGUpIHtcbiAgcmV0dXJuIChuZXR3b3JrTW9kZSA/PyBcIm9ubGluZVwiKSA9PT0gXCJvbmxpbmVcIiA/IG9ubGluZU1hbmFnZXIuaXNPbmxpbmUoKSA6IHRydWU7XG59XG52YXIgQ2FuY2VsbGVkRXJyb3IgPSBjbGFzcyBleHRlbmRzIEVycm9yIHtcbiAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgIHN1cGVyKFwiQ2FuY2VsbGVkRXJyb3JcIik7XG4gICAgdGhpcy5yZXZlcnQgPSBvcHRpb25zPy5yZXZlcnQ7XG4gICAgdGhpcy5zaWxlbnQgPSBvcHRpb25zPy5zaWxlbnQ7XG4gIH1cbn07XG5mdW5jdGlvbiBpc0NhbmNlbGxlZEVycm9yKHZhbHVlKSB7XG4gIHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIENhbmNlbGxlZEVycm9yO1xufVxuZnVuY3Rpb24gY3JlYXRlUmV0cnllcihjb25maWcpIHtcbiAgbGV0IGlzUmV0cnlDYW5jZWxsZWQgPSBmYWxzZTtcbiAgbGV0IGZhaWx1cmVDb3VudCA9IDA7XG4gIGxldCBjb250aW51ZUZuO1xuICBjb25zdCB0aGVuYWJsZSA9IHBlbmRpbmdUaGVuYWJsZSgpO1xuICBjb25zdCBpc1Jlc29sdmVkID0gKCkgPT4gdGhlbmFibGUuc3RhdHVzICE9PSBcInBlbmRpbmdcIjtcbiAgY29uc3QgY2FuY2VsID0gKGNhbmNlbE9wdGlvbnMpID0+IHtcbiAgICBpZiAoIWlzUmVzb2x2ZWQoKSkge1xuICAgICAgY29uc3QgZXJyb3IgPSBuZXcgQ2FuY2VsbGVkRXJyb3IoY2FuY2VsT3B0aW9ucyk7XG4gICAgICByZWplY3QoZXJyb3IpO1xuICAgICAgY29uZmlnLm9uQ2FuY2VsPy4oZXJyb3IpO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgY2FuY2VsUmV0cnkgPSAoKSA9PiB7XG4gICAgaXNSZXRyeUNhbmNlbGxlZCA9IHRydWU7XG4gIH07XG4gIGNvbnN0IGNvbnRpbnVlUmV0cnkgPSAoKSA9PiB7XG4gICAgaXNSZXRyeUNhbmNlbGxlZCA9IGZhbHNlO1xuICB9O1xuICBjb25zdCBjYW5Db250aW51ZSA9ICgpID0+IGZvY3VzTWFuYWdlci5pc0ZvY3VzZWQoKSAmJiAoY29uZmlnLm5ldHdvcmtNb2RlID09PSBcImFsd2F5c1wiIHx8IG9ubGluZU1hbmFnZXIuaXNPbmxpbmUoKSkgJiYgY29uZmlnLmNhblJ1bigpO1xuICBjb25zdCBjYW5TdGFydCA9ICgpID0+IGNhbkZldGNoKGNvbmZpZy5uZXR3b3JrTW9kZSkgJiYgY29uZmlnLmNhblJ1bigpO1xuICBjb25zdCByZXNvbHZlID0gKHZhbHVlKSA9PiB7XG4gICAgaWYgKCFpc1Jlc29sdmVkKCkpIHtcbiAgICAgIGNvbnRpbnVlRm4/LigpO1xuICAgICAgdGhlbmFibGUucmVzb2x2ZSh2YWx1ZSk7XG4gICAgfVxuICB9O1xuICBjb25zdCByZWplY3QgPSAodmFsdWUpID0+IHtcbiAgICBpZiAoIWlzUmVzb2x2ZWQoKSkge1xuICAgICAgY29udGludWVGbj8uKCk7XG4gICAgICB0aGVuYWJsZS5yZWplY3QodmFsdWUpO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgcGF1c2UgPSAoKSA9PiB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChjb250aW51ZVJlc29sdmUpID0+IHtcbiAgICAgIGNvbnRpbnVlRm4gPSAodmFsdWUpID0+IHtcbiAgICAgICAgaWYgKGlzUmVzb2x2ZWQoKSB8fCBjYW5Db250aW51ZSgpKSB7XG4gICAgICAgICAgY29udGludWVSZXNvbHZlKHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIGNvbmZpZy5vblBhdXNlPy4oKTtcbiAgICB9KS50aGVuKCgpID0+IHtcbiAgICAgIGNvbnRpbnVlRm4gPSB2b2lkIDA7XG4gICAgICBpZiAoIWlzUmVzb2x2ZWQoKSkge1xuICAgICAgICBjb25maWcub25Db250aW51ZT8uKCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH07XG4gIGNvbnN0IHJ1biA9ICgpID0+IHtcbiAgICBpZiAoaXNSZXNvbHZlZCgpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGxldCBwcm9taXNlT3JWYWx1ZTtcbiAgICBjb25zdCBpbml0aWFsUHJvbWlzZSA9IGZhaWx1cmVDb3VudCA9PT0gMCA/IGNvbmZpZy5pbml0aWFsUHJvbWlzZSA6IHZvaWQgMDtcbiAgICB0cnkge1xuICAgICAgcHJvbWlzZU9yVmFsdWUgPSBpbml0aWFsUHJvbWlzZSA/PyBjb25maWcuZm4oKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgcHJvbWlzZU9yVmFsdWUgPSBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gICAgfVxuICAgIFByb21pc2UucmVzb2x2ZShwcm9taXNlT3JWYWx1ZSkudGhlbihyZXNvbHZlKS5jYXRjaCgoZXJyb3IpID0+IHtcbiAgICAgIGlmIChpc1Jlc29sdmVkKCkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgcmV0cnkgPSBjb25maWcucmV0cnkgPz8gKGVudmlyb25tZW50TWFuYWdlci5pc1NlcnZlcigpID8gMCA6IDMpO1xuICAgICAgY29uc3QgcmV0cnlEZWxheSA9IGNvbmZpZy5yZXRyeURlbGF5ID8/IGRlZmF1bHRSZXRyeURlbGF5O1xuICAgICAgY29uc3QgZGVsYXkgPSB0eXBlb2YgcmV0cnlEZWxheSA9PT0gXCJmdW5jdGlvblwiID8gcmV0cnlEZWxheShmYWlsdXJlQ291bnQsIGVycm9yKSA6IHJldHJ5RGVsYXk7XG4gICAgICBjb25zdCBzaG91bGRSZXRyeSA9IHJldHJ5ID09PSB0cnVlIHx8IHR5cGVvZiByZXRyeSA9PT0gXCJudW1iZXJcIiAmJiBmYWlsdXJlQ291bnQgPCByZXRyeSB8fCB0eXBlb2YgcmV0cnkgPT09IFwiZnVuY3Rpb25cIiAmJiByZXRyeShmYWlsdXJlQ291bnQsIGVycm9yKTtcbiAgICAgIGlmIChpc1JldHJ5Q2FuY2VsbGVkIHx8ICFzaG91bGRSZXRyeSkge1xuICAgICAgICByZWplY3QoZXJyb3IpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBmYWlsdXJlQ291bnQrKztcbiAgICAgIGNvbmZpZy5vbkZhaWw/LihmYWlsdXJlQ291bnQsIGVycm9yKTtcbiAgICAgIHNsZWVwKGRlbGF5KS50aGVuKCgpID0+IHtcbiAgICAgICAgcmV0dXJuIGNhbkNvbnRpbnVlKCkgPyB2b2lkIDAgOiBwYXVzZSgpO1xuICAgICAgfSkudGhlbigoKSA9PiB7XG4gICAgICAgIGlmIChpc1JldHJ5Q2FuY2VsbGVkKSB7XG4gICAgICAgICAgcmVqZWN0KGVycm9yKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBydW4oKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSk7XG4gIH07XG4gIHJldHVybiB7XG4gICAgcHJvbWlzZTogdGhlbmFibGUsXG4gICAgc3RhdHVzOiAoKSA9PiB0aGVuYWJsZS5zdGF0dXMsXG4gICAgY2FuY2VsLFxuICAgIGNvbnRpbnVlOiAoKSA9PiB7XG4gICAgICBjb250aW51ZUZuPy4oKTtcbiAgICAgIHJldHVybiB0aGVuYWJsZTtcbiAgICB9LFxuICAgIGNhbmNlbFJldHJ5LFxuICAgIGNvbnRpbnVlUmV0cnksXG4gICAgY2FuU3RhcnQsXG4gICAgc3RhcnQ6ICgpID0+IHtcbiAgICAgIGlmIChjYW5TdGFydCgpKSB7XG4gICAgICAgIHJ1bigpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcGF1c2UoKS50aGVuKHJ1bik7XG4gICAgICB9XG4gICAgICByZXR1cm4gdGhlbmFibGU7XG4gICAgfVxuICB9O1xufVxuZXhwb3J0IHtcbiAgQ2FuY2VsbGVkRXJyb3IsXG4gIGNhbkZldGNoLFxuICBjcmVhdGVSZXRyeWVyLFxuICBpc0NhbmNlbGxlZEVycm9yXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmV0cnllci5qcy5tYXAiLCIvLyBzcmMvcmVtb3ZhYmxlLnRzXG5pbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gXCIuL3RpbWVvdXRNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBlbnZpcm9ubWVudE1hbmFnZXIgfSBmcm9tIFwiLi9lbnZpcm9ubWVudE1hbmFnZXIuanNcIjtcbmltcG9ydCB7IGlzVmFsaWRUaW1lb3V0IH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbnZhciBSZW1vdmFibGUgPSBjbGFzcyB7XG4gICNnY1RpbWVvdXQ7XG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5jbGVhckdjVGltZW91dCgpO1xuICB9XG4gIHNjaGVkdWxlR2MoKSB7XG4gICAgdGhpcy5jbGVhckdjVGltZW91dCgpO1xuICAgIGlmIChpc1ZhbGlkVGltZW91dCh0aGlzLmdjVGltZSkpIHtcbiAgICAgIHRoaXMuI2djVGltZW91dCA9IHRpbWVvdXRNYW5hZ2VyLnNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICB0aGlzLm9wdGlvbmFsUmVtb3ZlKCk7XG4gICAgICB9LCB0aGlzLmdjVGltZSk7XG4gICAgfVxuICB9XG4gIHVwZGF0ZUdjVGltZShuZXdHY1RpbWUpIHtcbiAgICB0aGlzLmdjVGltZSA9IE1hdGgubWF4KFxuICAgICAgdGhpcy5nY1RpbWUgfHwgMCxcbiAgICAgIG5ld0djVGltZSA/PyAoZW52aXJvbm1lbnRNYW5hZ2VyLmlzU2VydmVyKCkgPyBJbmZpbml0eSA6IDUgKiA2MCAqIDFlMylcbiAgICApO1xuICB9XG4gIGNsZWFyR2NUaW1lb3V0KCkge1xuICAgIGlmICh0aGlzLiNnY1RpbWVvdXQgIT09IHZvaWQgMCkge1xuICAgICAgdGltZW91dE1hbmFnZXIuY2xlYXJUaW1lb3V0KHRoaXMuI2djVGltZW91dCk7XG4gICAgICB0aGlzLiNnY1RpbWVvdXQgPSB2b2lkIDA7XG4gICAgfVxuICB9XG59O1xuZXhwb3J0IHtcbiAgUmVtb3ZhYmxlXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmVtb3ZhYmxlLmpzLm1hcCIsIi8vIHNyYy9pbmZpbml0ZVF1ZXJ5QmVoYXZpb3IudHNcbmltcG9ydCB7XG4gIGFkZENvbnN1bWVBd2FyZVNpZ25hbCxcbiAgYWRkVG9FbmQsXG4gIGFkZFRvU3RhcnQsXG4gIGVuc3VyZVF1ZXJ5Rm5cbn0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmZ1bmN0aW9uIGluZmluaXRlUXVlcnlCZWhhdmlvcihwYWdlcykge1xuICByZXR1cm4ge1xuICAgIG9uRmV0Y2g6IChjb250ZXh0LCBxdWVyeSkgPT4ge1xuICAgICAgY29uc3Qgb3B0aW9ucyA9IGNvbnRleHQub3B0aW9ucztcbiAgICAgIGNvbnN0IGRpcmVjdGlvbiA9IGNvbnRleHQuZmV0Y2hPcHRpb25zPy5tZXRhPy5mZXRjaE1vcmU/LmRpcmVjdGlvbjtcbiAgICAgIGNvbnN0IG9sZFBhZ2VzID0gY29udGV4dC5zdGF0ZS5kYXRhPy5wYWdlcyB8fCBbXTtcbiAgICAgIGNvbnN0IG9sZFBhZ2VQYXJhbXMgPSBjb250ZXh0LnN0YXRlLmRhdGE/LnBhZ2VQYXJhbXMgfHwgW107XG4gICAgICBsZXQgcmVzdWx0ID0geyBwYWdlczogW10sIHBhZ2VQYXJhbXM6IFtdIH07XG4gICAgICBsZXQgY3VycmVudFBhZ2UgPSAwO1xuICAgICAgY29uc3QgZmV0Y2hGbiA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgbGV0IGNhbmNlbGxlZCA9IGZhbHNlO1xuICAgICAgICBjb25zdCBhZGRTaWduYWxQcm9wZXJ0eSA9IChvYmplY3QpID0+IHtcbiAgICAgICAgICBhZGRDb25zdW1lQXdhcmVTaWduYWwoXG4gICAgICAgICAgICBvYmplY3QsXG4gICAgICAgICAgICAoKSA9PiBjb250ZXh0LnNpZ25hbCxcbiAgICAgICAgICAgICgpID0+IGNhbmNlbGxlZCA9IHRydWVcbiAgICAgICAgICApO1xuICAgICAgICB9O1xuICAgICAgICBjb25zdCBxdWVyeUZuID0gZW5zdXJlUXVlcnlGbihjb250ZXh0Lm9wdGlvbnMsIGNvbnRleHQuZmV0Y2hPcHRpb25zKTtcbiAgICAgICAgY29uc3QgZmV0Y2hQYWdlID0gYXN5bmMgKGRhdGEsIHBhcmFtLCBwcmV2aW91cykgPT4ge1xuICAgICAgICAgIGlmIChjYW5jZWxsZWQpIHtcbiAgICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChjb250ZXh0LnNpZ25hbC5yZWFzb24pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAocGFyYW0gPT0gbnVsbCAmJiBkYXRhLnBhZ2VzLmxlbmd0aCkge1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShkYXRhKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3QgY3JlYXRlUXVlcnlGbkNvbnRleHQgPSAoKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBxdWVyeUZuQ29udGV4dDIgPSB7XG4gICAgICAgICAgICAgIGNsaWVudDogY29udGV4dC5jbGllbnQsXG4gICAgICAgICAgICAgIHF1ZXJ5S2V5OiBjb250ZXh0LnF1ZXJ5S2V5LFxuICAgICAgICAgICAgICBwYWdlUGFyYW06IHBhcmFtLFxuICAgICAgICAgICAgICBkaXJlY3Rpb246IHByZXZpb3VzID8gXCJiYWNrd2FyZFwiIDogXCJmb3J3YXJkXCIsXG4gICAgICAgICAgICAgIG1ldGE6IGNvbnRleHQub3B0aW9ucy5tZXRhXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgYWRkU2lnbmFsUHJvcGVydHkocXVlcnlGbkNvbnRleHQyKTtcbiAgICAgICAgICAgIHJldHVybiBxdWVyeUZuQ29udGV4dDI7XG4gICAgICAgICAgfTtcbiAgICAgICAgICBjb25zdCBxdWVyeUZuQ29udGV4dCA9IGNyZWF0ZVF1ZXJ5Rm5Db250ZXh0KCk7XG4gICAgICAgICAgY29uc3QgcGFnZSA9IGF3YWl0IHF1ZXJ5Rm4ocXVlcnlGbkNvbnRleHQpO1xuICAgICAgICAgIGNvbnN0IHsgbWF4UGFnZXMgfSA9IGNvbnRleHQub3B0aW9ucztcbiAgICAgICAgICBjb25zdCBhZGRUbyA9IHByZXZpb3VzID8gYWRkVG9TdGFydCA6IGFkZFRvRW5kO1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBwYWdlczogYWRkVG8oZGF0YS5wYWdlcywgcGFnZSwgbWF4UGFnZXMpLFxuICAgICAgICAgICAgcGFnZVBhcmFtczogYWRkVG8oZGF0YS5wYWdlUGFyYW1zLCBwYXJhbSwgbWF4UGFnZXMpXG4gICAgICAgICAgfTtcbiAgICAgICAgfTtcbiAgICAgICAgaWYgKGRpcmVjdGlvbiAmJiBvbGRQYWdlcy5sZW5ndGgpIHtcbiAgICAgICAgICBjb25zdCBwcmV2aW91cyA9IGRpcmVjdGlvbiA9PT0gXCJiYWNrd2FyZFwiO1xuICAgICAgICAgIGNvbnN0IHBhZ2VQYXJhbUZuID0gcHJldmlvdXMgPyBnZXRQcmV2aW91c1BhZ2VQYXJhbSA6IGdldE5leHRQYWdlUGFyYW07XG4gICAgICAgICAgY29uc3Qgb2xkRGF0YSA9IHtcbiAgICAgICAgICAgIHBhZ2VzOiBvbGRQYWdlcyxcbiAgICAgICAgICAgIHBhZ2VQYXJhbXM6IG9sZFBhZ2VQYXJhbXNcbiAgICAgICAgICB9O1xuICAgICAgICAgIGNvbnN0IHBhcmFtID0gcGFnZVBhcmFtRm4ob3B0aW9ucywgb2xkRGF0YSk7XG4gICAgICAgICAgcmVzdWx0ID0gYXdhaXQgZmV0Y2hQYWdlKG9sZERhdGEsIHBhcmFtLCBwcmV2aW91cyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc3QgcmVtYWluaW5nUGFnZXMgPSBwYWdlcyA/PyBvbGRQYWdlcy5sZW5ndGg7XG4gICAgICAgICAgZG8ge1xuICAgICAgICAgICAgY29uc3QgcGFyYW0gPSBjdXJyZW50UGFnZSA9PT0gMCA/IG9sZFBhZ2VQYXJhbXNbMF0gPz8gb3B0aW9ucy5pbml0aWFsUGFnZVBhcmFtIDogZ2V0TmV4dFBhZ2VQYXJhbShvcHRpb25zLCByZXN1bHQpO1xuICAgICAgICAgICAgaWYgKGN1cnJlbnRQYWdlID4gMCAmJiBwYXJhbSA9PSBudWxsKSB7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgZmV0Y2hQYWdlKHJlc3VsdCwgcGFyYW0pO1xuICAgICAgICAgICAgY3VycmVudFBhZ2UrKztcbiAgICAgICAgICB9IHdoaWxlIChjdXJyZW50UGFnZSA8IHJlbWFpbmluZ1BhZ2VzKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgfTtcbiAgICAgIGlmIChjb250ZXh0Lm9wdGlvbnMucGVyc2lzdGVyKSB7XG4gICAgICAgIGNvbnRleHQuZmV0Y2hGbiA9ICgpID0+IHtcbiAgICAgICAgICByZXR1cm4gY29udGV4dC5vcHRpb25zLnBlcnNpc3Rlcj8uKFxuICAgICAgICAgICAgZmV0Y2hGbixcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgY2xpZW50OiBjb250ZXh0LmNsaWVudCxcbiAgICAgICAgICAgICAgcXVlcnlLZXk6IGNvbnRleHQucXVlcnlLZXksXG4gICAgICAgICAgICAgIG1ldGE6IGNvbnRleHQub3B0aW9ucy5tZXRhLFxuICAgICAgICAgICAgICBzaWduYWw6IGNvbnRleHQuc2lnbmFsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcXVlcnlcbiAgICAgICAgICApO1xuICAgICAgICB9O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29udGV4dC5mZXRjaEZuID0gZmV0Y2hGbjtcbiAgICAgIH1cbiAgICB9XG4gIH07XG59XG5mdW5jdGlvbiBnZXROZXh0UGFnZVBhcmFtKG9wdGlvbnMsIHsgcGFnZXMsIHBhZ2VQYXJhbXMgfSkge1xuICBjb25zdCBsYXN0SW5kZXggPSBwYWdlcy5sZW5ndGggLSAxO1xuICByZXR1cm4gcGFnZXMubGVuZ3RoID4gMCA/IG9wdGlvbnMuZ2V0TmV4dFBhZ2VQYXJhbShcbiAgICBwYWdlc1tsYXN0SW5kZXhdLFxuICAgIHBhZ2VzLFxuICAgIHBhZ2VQYXJhbXNbbGFzdEluZGV4XSxcbiAgICBwYWdlUGFyYW1zXG4gICkgOiB2b2lkIDA7XG59XG5mdW5jdGlvbiBnZXRQcmV2aW91c1BhZ2VQYXJhbShvcHRpb25zLCB7IHBhZ2VzLCBwYWdlUGFyYW1zIH0pIHtcbiAgcmV0dXJuIHBhZ2VzLmxlbmd0aCA+IDAgPyBvcHRpb25zLmdldFByZXZpb3VzUGFnZVBhcmFtPy4ocGFnZXNbMF0sIHBhZ2VzLCBwYWdlUGFyYW1zWzBdLCBwYWdlUGFyYW1zKSA6IHZvaWQgMDtcbn1cbmZ1bmN0aW9uIGhhc05leHRQYWdlKG9wdGlvbnMsIGRhdGEpIHtcbiAgaWYgKCFkYXRhKSByZXR1cm4gZmFsc2U7XG4gIHJldHVybiBnZXROZXh0UGFnZVBhcmFtKG9wdGlvbnMsIGRhdGEpICE9IG51bGw7XG59XG5mdW5jdGlvbiBoYXNQcmV2aW91c1BhZ2Uob3B0aW9ucywgZGF0YSkge1xuICBpZiAoIWRhdGEgfHwgIW9wdGlvbnMuZ2V0UHJldmlvdXNQYWdlUGFyYW0pIHJldHVybiBmYWxzZTtcbiAgcmV0dXJuIGdldFByZXZpb3VzUGFnZVBhcmFtKG9wdGlvbnMsIGRhdGEpICE9IG51bGw7XG59XG5leHBvcnQge1xuICBoYXNOZXh0UGFnZSxcbiAgaGFzUHJldmlvdXNQYWdlLFxuICBpbmZpbml0ZVF1ZXJ5QmVoYXZpb3Jcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmZpbml0ZVF1ZXJ5QmVoYXZpb3IuanMubWFwIiwiLy8gc3JjL3F1ZXJ5LnRzXG5pbXBvcnQge1xuICBlbnN1cmVRdWVyeUZuLFxuICBub29wLFxuICByZXBsYWNlRGF0YSxcbiAgcmVzb2x2ZVF1ZXJ5Qm9vbGVhbixcbiAgcmVzb2x2ZVN0YWxlVGltZSxcbiAgc2tpcFRva2VuLFxuICB0aW1lVW50aWxTdGFsZVxufSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gXCIuL25vdGlmeU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IENhbmNlbGxlZEVycm9yLCBjYW5GZXRjaCwgY3JlYXRlUmV0cnllciB9IGZyb20gXCIuL3JldHJ5ZXIuanNcIjtcbmltcG9ydCB7IFJlbW92YWJsZSB9IGZyb20gXCIuL3JlbW92YWJsZS5qc1wiO1xuaW1wb3J0IHsgaW5maW5pdGVRdWVyeUJlaGF2aW9yIH0gZnJvbSBcIi4vaW5maW5pdGVRdWVyeUJlaGF2aW9yLmpzXCI7XG52YXIgUXVlcnkgPSBjbGFzcyBleHRlbmRzIFJlbW92YWJsZSB7XG4gICNxdWVyeVR5cGU7XG4gICNpbml0aWFsU3RhdGU7XG4gICNyZXZlcnRTdGF0ZTtcbiAgI2NhY2hlO1xuICAjY2xpZW50O1xuICAjcmV0cnllcjtcbiAgI2RlZmF1bHRPcHRpb25zO1xuICAjYWJvcnRTaWduYWxDb25zdW1lZDtcbiAgY29uc3RydWN0b3IoY29uZmlnKSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLiNhYm9ydFNpZ25hbENvbnN1bWVkID0gZmFsc2U7XG4gICAgdGhpcy4jZGVmYXVsdE9wdGlvbnMgPSBjb25maWcuZGVmYXVsdE9wdGlvbnM7XG4gICAgdGhpcy5zZXRPcHRpb25zKGNvbmZpZy5vcHRpb25zKTtcbiAgICB0aGlzLm9ic2VydmVycyA9IFtdO1xuICAgIHRoaXMuI2NsaWVudCA9IGNvbmZpZy5jbGllbnQ7XG4gICAgdGhpcy4jY2FjaGUgPSB0aGlzLiNjbGllbnQuZ2V0UXVlcnlDYWNoZSgpO1xuICAgIHRoaXMucXVlcnlLZXkgPSBjb25maWcucXVlcnlLZXk7XG4gICAgdGhpcy5xdWVyeUhhc2ggPSBjb25maWcucXVlcnlIYXNoO1xuICAgIHRoaXMuI2luaXRpYWxTdGF0ZSA9IGdldERlZmF1bHRTdGF0ZSh0aGlzLm9wdGlvbnMpO1xuICAgIHRoaXMuc3RhdGUgPSBjb25maWcuc3RhdGUgPz8gdGhpcy4jaW5pdGlhbFN0YXRlO1xuICAgIHRoaXMuc2NoZWR1bGVHYygpO1xuICB9XG4gIGdldCBtZXRhKCkge1xuICAgIHJldHVybiB0aGlzLm9wdGlvbnMubWV0YTtcbiAgfVxuICBnZXQgcXVlcnlUeXBlKCkge1xuICAgIHJldHVybiB0aGlzLiNxdWVyeVR5cGU7XG4gIH1cbiAgZ2V0IHByb21pc2UoKSB7XG4gICAgcmV0dXJuIHRoaXMuI3JldHJ5ZXI/LnByb21pc2U7XG4gIH1cbiAgc2V0T3B0aW9ucyhvcHRpb25zKSB7XG4gICAgdGhpcy5vcHRpb25zID0geyAuLi50aGlzLiNkZWZhdWx0T3B0aW9ucywgLi4ub3B0aW9ucyB9O1xuICAgIGlmIChvcHRpb25zPy5fdHlwZSkge1xuICAgICAgdGhpcy4jcXVlcnlUeXBlID0gb3B0aW9ucy5fdHlwZTtcbiAgICB9XG4gICAgdGhpcy51cGRhdGVHY1RpbWUodGhpcy5vcHRpb25zLmdjVGltZSk7XG4gICAgaWYgKHRoaXMuc3RhdGUgJiYgdGhpcy5zdGF0ZS5kYXRhID09PSB2b2lkIDApIHtcbiAgICAgIGNvbnN0IGRlZmF1bHRTdGF0ZSA9IGdldERlZmF1bHRTdGF0ZSh0aGlzLm9wdGlvbnMpO1xuICAgICAgaWYgKGRlZmF1bHRTdGF0ZS5kYXRhICE9PSB2b2lkIDApIHtcbiAgICAgICAgdGhpcy5zZXRTdGF0ZShcbiAgICAgICAgICBzdWNjZXNzU3RhdGUoZGVmYXVsdFN0YXRlLmRhdGEsIGRlZmF1bHRTdGF0ZS5kYXRhVXBkYXRlZEF0KVxuICAgICAgICApO1xuICAgICAgICB0aGlzLiNpbml0aWFsU3RhdGUgPSBkZWZhdWx0U3RhdGU7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIG9wdGlvbmFsUmVtb3ZlKCkge1xuICAgIGlmICghdGhpcy5vYnNlcnZlcnMubGVuZ3RoICYmIHRoaXMuc3RhdGUuZmV0Y2hTdGF0dXMgPT09IFwiaWRsZVwiKSB7XG4gICAgICB0aGlzLiNjYWNoZS5yZW1vdmUodGhpcyk7XG4gICAgfVxuICB9XG4gIHNldERhdGEobmV3RGF0YSwgb3B0aW9ucykge1xuICAgIGNvbnN0IGRhdGEgPSByZXBsYWNlRGF0YSh0aGlzLnN0YXRlLmRhdGEsIG5ld0RhdGEsIHRoaXMub3B0aW9ucyk7XG4gICAgdGhpcy4jZGlzcGF0Y2goe1xuICAgICAgZGF0YSxcbiAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxuICAgICAgZGF0YVVwZGF0ZWRBdDogb3B0aW9ucz8udXBkYXRlZEF0LFxuICAgICAgbWFudWFsOiBvcHRpb25zPy5tYW51YWxcbiAgICB9KTtcbiAgICByZXR1cm4gZGF0YTtcbiAgfVxuICBzZXRTdGF0ZShzdGF0ZSkge1xuICAgIHRoaXMuI2Rpc3BhdGNoKHsgdHlwZTogXCJzZXRTdGF0ZVwiLCBzdGF0ZSB9KTtcbiAgfVxuICBjYW5jZWwob3B0aW9ucykge1xuICAgIGNvbnN0IHByb21pc2UgPSB0aGlzLiNyZXRyeWVyPy5wcm9taXNlO1xuICAgIHRoaXMuI3JldHJ5ZXI/LmNhbmNlbChvcHRpb25zKTtcbiAgICByZXR1cm4gcHJvbWlzZSA/IHByb21pc2UudGhlbihub29wKS5jYXRjaChub29wKSA6IFByb21pc2UucmVzb2x2ZSgpO1xuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgc3VwZXIuZGVzdHJveSgpO1xuICAgIHRoaXMuY2FuY2VsKHsgc2lsZW50OiB0cnVlIH0pO1xuICB9XG4gIGdldCByZXNldFN0YXRlKCkge1xuICAgIHJldHVybiB0aGlzLiNpbml0aWFsU3RhdGU7XG4gIH1cbiAgcmVzZXQoKSB7XG4gICAgdGhpcy5kZXN0cm95KCk7XG4gICAgdGhpcy5zZXRTdGF0ZSh0aGlzLnJlc2V0U3RhdGUpO1xuICB9XG4gIGlzQWN0aXZlKCkge1xuICAgIHJldHVybiB0aGlzLm9ic2VydmVycy5zb21lKFxuICAgICAgKG9ic2VydmVyKSA9PiByZXNvbHZlUXVlcnlCb29sZWFuKG9ic2VydmVyLm9wdGlvbnMuZW5hYmxlZCwgdGhpcykgIT09IGZhbHNlXG4gICAgKTtcbiAgfVxuICBpc0Rpc2FibGVkKCkge1xuICAgIGlmICh0aGlzLmdldE9ic2VydmVyc0NvdW50KCkgPiAwKSB7XG4gICAgICByZXR1cm4gIXRoaXMuaXNBY3RpdmUoKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMub3B0aW9ucy5xdWVyeUZuID09PSBza2lwVG9rZW4gfHwgIXRoaXMuaXNGZXRjaGVkKCk7XG4gIH1cbiAgaXNGZXRjaGVkKCkge1xuICAgIHJldHVybiB0aGlzLnN0YXRlLmRhdGFVcGRhdGVDb3VudCArIHRoaXMuc3RhdGUuZXJyb3JVcGRhdGVDb3VudCA+IDA7XG4gIH1cbiAgaXNTdGF0aWMoKSB7XG4gICAgaWYgKHRoaXMuZ2V0T2JzZXJ2ZXJzQ291bnQoKSA+IDApIHtcbiAgICAgIHJldHVybiB0aGlzLm9ic2VydmVycy5zb21lKFxuICAgICAgICAob2JzZXJ2ZXIpID0+IHJlc29sdmVTdGFsZVRpbWUob2JzZXJ2ZXIub3B0aW9ucy5zdGFsZVRpbWUsIHRoaXMpID09PSBcInN0YXRpY1wiXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaXNTdGFsZSgpIHtcbiAgICBpZiAodGhpcy5nZXRPYnNlcnZlcnNDb3VudCgpID4gMCkge1xuICAgICAgcmV0dXJuIHRoaXMub2JzZXJ2ZXJzLnNvbWUoXG4gICAgICAgIChvYnNlcnZlcikgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpLmlzU3RhbGVcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnN0YXRlLmRhdGEgPT09IHZvaWQgMCB8fCB0aGlzLnN0YXRlLmlzSW52YWxpZGF0ZWQ7XG4gIH1cbiAgaXNTdGFsZUJ5VGltZShzdGFsZVRpbWUgPSAwKSB7XG4gICAgaWYgKHRoaXMuc3RhdGUuZGF0YSA9PT0gdm9pZCAwKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKHN0YWxlVGltZSA9PT0gXCJzdGF0aWNcIikge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpZiAodGhpcy5zdGF0ZS5pc0ludmFsaWRhdGVkKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuICF0aW1lVW50aWxTdGFsZSh0aGlzLnN0YXRlLmRhdGFVcGRhdGVkQXQsIHN0YWxlVGltZSk7XG4gIH1cbiAgb25Gb2N1cygpIHtcbiAgICBjb25zdCBvYnNlcnZlciA9IHRoaXMub2JzZXJ2ZXJzLmZpbmQoKHgpID0+IHguc2hvdWxkRmV0Y2hPbldpbmRvd0ZvY3VzKCkpO1xuICAgIG9ic2VydmVyPy5yZWZldGNoKHsgY2FuY2VsUmVmZXRjaDogZmFsc2UgfSk7XG4gICAgdGhpcy4jcmV0cnllcj8uY29udGludWUoKTtcbiAgfVxuICBvbk9ubGluZSgpIHtcbiAgICBjb25zdCBvYnNlcnZlciA9IHRoaXMub2JzZXJ2ZXJzLmZpbmQoKHgpID0+IHguc2hvdWxkRmV0Y2hPblJlY29ubmVjdCgpKTtcbiAgICBvYnNlcnZlcj8ucmVmZXRjaCh7IGNhbmNlbFJlZmV0Y2g6IGZhbHNlIH0pO1xuICAgIHRoaXMuI3JldHJ5ZXI/LmNvbnRpbnVlKCk7XG4gIH1cbiAgYWRkT2JzZXJ2ZXIob2JzZXJ2ZXIpIHtcbiAgICBpZiAoIXRoaXMub2JzZXJ2ZXJzLmluY2x1ZGVzKG9ic2VydmVyKSkge1xuICAgICAgdGhpcy5vYnNlcnZlcnMucHVzaChvYnNlcnZlcik7XG4gICAgICB0aGlzLmNsZWFyR2NUaW1lb3V0KCk7XG4gICAgICB0aGlzLiNjYWNoZS5ub3RpZnkoeyB0eXBlOiBcIm9ic2VydmVyQWRkZWRcIiwgcXVlcnk6IHRoaXMsIG9ic2VydmVyIH0pO1xuICAgIH1cbiAgfVxuICByZW1vdmVPYnNlcnZlcihvYnNlcnZlcikge1xuICAgIGlmICh0aGlzLm9ic2VydmVycy5pbmNsdWRlcyhvYnNlcnZlcikpIHtcbiAgICAgIHRoaXMub2JzZXJ2ZXJzID0gdGhpcy5vYnNlcnZlcnMuZmlsdGVyKCh4KSA9PiB4ICE9PSBvYnNlcnZlcik7XG4gICAgICBpZiAoIXRoaXMub2JzZXJ2ZXJzLmxlbmd0aCkge1xuICAgICAgICBpZiAodGhpcy4jcmV0cnllcikge1xuICAgICAgICAgIGlmICh0aGlzLiNhYm9ydFNpZ25hbENvbnN1bWVkIHx8IHRoaXMuI2lzSW5pdGlhbFBhdXNlZEZldGNoKCkpIHtcbiAgICAgICAgICAgIHRoaXMuI3JldHJ5ZXIuY2FuY2VsKHsgcmV2ZXJ0OiB0cnVlIH0pO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLiNyZXRyeWVyLmNhbmNlbFJldHJ5KCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHRoaXMuc2NoZWR1bGVHYygpO1xuICAgICAgfVxuICAgICAgdGhpcy4jY2FjaGUubm90aWZ5KHsgdHlwZTogXCJvYnNlcnZlclJlbW92ZWRcIiwgcXVlcnk6IHRoaXMsIG9ic2VydmVyIH0pO1xuICAgIH1cbiAgfVxuICBnZXRPYnNlcnZlcnNDb3VudCgpIHtcbiAgICByZXR1cm4gdGhpcy5vYnNlcnZlcnMubGVuZ3RoO1xuICB9XG4gICNpc0luaXRpYWxQYXVzZWRGZXRjaCgpIHtcbiAgICByZXR1cm4gdGhpcy5zdGF0ZS5mZXRjaFN0YXR1cyA9PT0gXCJwYXVzZWRcIiAmJiB0aGlzLnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCI7XG4gIH1cbiAgaW52YWxpZGF0ZSgpIHtcbiAgICBpZiAoIXRoaXMuc3RhdGUuaXNJbnZhbGlkYXRlZCkge1xuICAgICAgdGhpcy4jZGlzcGF0Y2goeyB0eXBlOiBcImludmFsaWRhdGVcIiB9KTtcbiAgICB9XG4gIH1cbiAgYXN5bmMgZmV0Y2gob3B0aW9ucywgZmV0Y2hPcHRpb25zKSB7XG4gICAgaWYgKHRoaXMuc3RhdGUuZmV0Y2hTdGF0dXMgIT09IFwiaWRsZVwiICYmIC8vIElmIHRoZSBwcm9taXNlIGluIHRoZSByZXRyeWVyIGlzIGFscmVhZHkgcmVqZWN0ZWQsIHdlIGhhdmUgdG8gZGVmaW5pdGVseVxuICAgIC8vIHJlLXN0YXJ0IHRoZSBmZXRjaDsgdGhlcmUgaXMgYSBjaGFuY2UgdGhhdCB0aGUgcXVlcnkgaXMgc3RpbGwgaW4gYVxuICAgIC8vIHBlbmRpbmcgc3RhdGUgd2hlbiB0aGF0IGhhcHBlbnNcbiAgICB0aGlzLiNyZXRyeWVyPy5zdGF0dXMoKSAhPT0gXCJyZWplY3RlZFwiKSB7XG4gICAgICBpZiAodGhpcy5zdGF0ZS5kYXRhICE9PSB2b2lkIDAgJiYgZmV0Y2hPcHRpb25zPy5jYW5jZWxSZWZldGNoKSB7XG4gICAgICAgIHRoaXMuY2FuY2VsKHsgc2lsZW50OiB0cnVlIH0pO1xuICAgICAgfSBlbHNlIGlmICh0aGlzLiNyZXRyeWVyKSB7XG4gICAgICAgIHRoaXMuI3JldHJ5ZXIuY29udGludWVSZXRyeSgpO1xuICAgICAgICByZXR1cm4gdGhpcy4jcmV0cnllci5wcm9taXNlO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAob3B0aW9ucykge1xuICAgICAgdGhpcy5zZXRPcHRpb25zKG9wdGlvbnMpO1xuICAgIH1cbiAgICBpZiAoIXRoaXMub3B0aW9ucy5xdWVyeUZuKSB7XG4gICAgICBjb25zdCBvYnNlcnZlciA9IHRoaXMub2JzZXJ2ZXJzLmZpbmQoKHgpID0+IHgub3B0aW9ucy5xdWVyeUZuKTtcbiAgICAgIGlmIChvYnNlcnZlcikge1xuICAgICAgICB0aGlzLnNldE9wdGlvbnMob2JzZXJ2ZXIub3B0aW9ucyk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICAgIGlmICghQXJyYXkuaXNBcnJheSh0aGlzLm9wdGlvbnMucXVlcnlLZXkpKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgYEFzIG9mIHY0LCBxdWVyeUtleSBuZWVkcyB0byBiZSBhbiBBcnJheS4gSWYgeW91IGFyZSB1c2luZyBhIHN0cmluZyBsaWtlICdyZXBvRGF0YScsIHBsZWFzZSBjaGFuZ2UgaXQgdG8gYW4gQXJyYXksIGUuZy4gWydyZXBvRGF0YSddYFxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBhYm9ydENvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgY29uc3QgYWRkU2lnbmFsUHJvcGVydHkgPSAob2JqZWN0KSA9PiB7XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkob2JqZWN0LCBcInNpZ25hbFwiLCB7XG4gICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgIGdldDogKCkgPT4ge1xuICAgICAgICAgIHRoaXMuI2Fib3J0U2lnbmFsQ29uc3VtZWQgPSB0cnVlO1xuICAgICAgICAgIHJldHVybiBhYm9ydENvbnRyb2xsZXIuc2lnbmFsO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IGZldGNoRm4gPSAoKSA9PiB7XG4gICAgICBjb25zdCBxdWVyeUZuID0gZW5zdXJlUXVlcnlGbih0aGlzLm9wdGlvbnMsIGZldGNoT3B0aW9ucyk7XG4gICAgICBjb25zdCBjcmVhdGVRdWVyeUZuQ29udGV4dCA9ICgpID0+IHtcbiAgICAgICAgY29uc3QgcXVlcnlGbkNvbnRleHQyID0ge1xuICAgICAgICAgIGNsaWVudDogdGhpcy4jY2xpZW50LFxuICAgICAgICAgIHF1ZXJ5S2V5OiB0aGlzLnF1ZXJ5S2V5LFxuICAgICAgICAgIG1ldGE6IHRoaXMubWV0YVxuICAgICAgICB9O1xuICAgICAgICBhZGRTaWduYWxQcm9wZXJ0eShxdWVyeUZuQ29udGV4dDIpO1xuICAgICAgICByZXR1cm4gcXVlcnlGbkNvbnRleHQyO1xuICAgICAgfTtcbiAgICAgIGNvbnN0IHF1ZXJ5Rm5Db250ZXh0ID0gY3JlYXRlUXVlcnlGbkNvbnRleHQoKTtcbiAgICAgIHRoaXMuI2Fib3J0U2lnbmFsQ29uc3VtZWQgPSBmYWxzZTtcbiAgICAgIGlmICh0aGlzLm9wdGlvbnMucGVyc2lzdGVyKSB7XG4gICAgICAgIHJldHVybiB0aGlzLm9wdGlvbnMucGVyc2lzdGVyKFxuICAgICAgICAgIHF1ZXJ5Rm4sXG4gICAgICAgICAgcXVlcnlGbkNvbnRleHQsXG4gICAgICAgICAgdGhpc1xuICAgICAgICApO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHF1ZXJ5Rm4ocXVlcnlGbkNvbnRleHQpO1xuICAgIH07XG4gICAgY29uc3QgY3JlYXRlRmV0Y2hDb250ZXh0ID0gKCkgPT4ge1xuICAgICAgY29uc3QgY29udGV4dDIgPSB7XG4gICAgICAgIGZldGNoT3B0aW9ucyxcbiAgICAgICAgb3B0aW9uczogdGhpcy5vcHRpb25zLFxuICAgICAgICBxdWVyeUtleTogdGhpcy5xdWVyeUtleSxcbiAgICAgICAgY2xpZW50OiB0aGlzLiNjbGllbnQsXG4gICAgICAgIHN0YXRlOiB0aGlzLnN0YXRlLFxuICAgICAgICBmZXRjaEZuXG4gICAgICB9O1xuICAgICAgYWRkU2lnbmFsUHJvcGVydHkoY29udGV4dDIpO1xuICAgICAgcmV0dXJuIGNvbnRleHQyO1xuICAgIH07XG4gICAgY29uc3QgY29udGV4dCA9IGNyZWF0ZUZldGNoQ29udGV4dCgpO1xuICAgIGNvbnN0IGJlaGF2aW9yID0gdGhpcy4jcXVlcnlUeXBlID09PSBcImluZmluaXRlXCIgPyBpbmZpbml0ZVF1ZXJ5QmVoYXZpb3IoXG4gICAgICB0aGlzLm9wdGlvbnMucGFnZXNcbiAgICApIDogdGhpcy5vcHRpb25zLmJlaGF2aW9yO1xuICAgIGJlaGF2aW9yPy5vbkZldGNoKGNvbnRleHQsIHRoaXMpO1xuICAgIHRoaXMuI3JldmVydFN0YXRlID0gdGhpcy5zdGF0ZTtcbiAgICBpZiAodGhpcy5zdGF0ZS5mZXRjaFN0YXR1cyA9PT0gXCJpZGxlXCIgfHwgdGhpcy5zdGF0ZS5mZXRjaE1ldGEgIT09IGNvbnRleHQuZmV0Y2hPcHRpb25zPy5tZXRhKSB7XG4gICAgICB0aGlzLiNkaXNwYXRjaCh7IHR5cGU6IFwiZmV0Y2hcIiwgbWV0YTogY29udGV4dC5mZXRjaE9wdGlvbnM/Lm1ldGEgfSk7XG4gICAgfVxuICAgIHRoaXMuI3JldHJ5ZXIgPSBjcmVhdGVSZXRyeWVyKHtcbiAgICAgIGluaXRpYWxQcm9taXNlOiBmZXRjaE9wdGlvbnM/LmluaXRpYWxQcm9taXNlLFxuICAgICAgZm46IGNvbnRleHQuZmV0Y2hGbixcbiAgICAgIG9uQ2FuY2VsOiAoZXJyb3IpID0+IHtcbiAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgQ2FuY2VsbGVkRXJyb3IgJiYgZXJyb3IucmV2ZXJ0KSB7XG4gICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgICAgICAuLi50aGlzLiNyZXZlcnRTdGF0ZSxcbiAgICAgICAgICAgIGZldGNoU3RhdHVzOiBcImlkbGVcIlxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGFib3J0Q29udHJvbGxlci5hYm9ydCgpO1xuICAgICAgfSxcbiAgICAgIG9uRmFpbDogKGZhaWx1cmVDb3VudCwgZXJyb3IpID0+IHtcbiAgICAgICAgdGhpcy4jZGlzcGF0Y2goeyB0eXBlOiBcImZhaWxlZFwiLCBmYWlsdXJlQ291bnQsIGVycm9yIH0pO1xuICAgICAgfSxcbiAgICAgIG9uUGF1c2U6ICgpID0+IHtcbiAgICAgICAgdGhpcy4jZGlzcGF0Y2goeyB0eXBlOiBcInBhdXNlXCIgfSk7XG4gICAgICB9LFxuICAgICAgb25Db250aW51ZTogKCkgPT4ge1xuICAgICAgICB0aGlzLiNkaXNwYXRjaCh7IHR5cGU6IFwiY29udGludWVcIiB9KTtcbiAgICAgIH0sXG4gICAgICByZXRyeTogY29udGV4dC5vcHRpb25zLnJldHJ5LFxuICAgICAgcmV0cnlEZWxheTogY29udGV4dC5vcHRpb25zLnJldHJ5RGVsYXksXG4gICAgICBuZXR3b3JrTW9kZTogY29udGV4dC5vcHRpb25zLm5ldHdvcmtNb2RlLFxuICAgICAgY2FuUnVuOiAoKSA9PiB0cnVlXG4gICAgfSk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCB0aGlzLiNyZXRyeWVyLnN0YXJ0KCk7XG4gICAgICBpZiAoZGF0YSA9PT0gdm9pZCAwKSB7XG4gICAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgICAgYFF1ZXJ5IGRhdGEgY2Fubm90IGJlIHVuZGVmaW5lZC4gUGxlYXNlIG1ha2Ugc3VyZSB0byByZXR1cm4gYSB2YWx1ZSBvdGhlciB0aGFuIHVuZGVmaW5lZCBmcm9tIHlvdXIgcXVlcnkgZnVuY3Rpb24uIEFmZmVjdGVkIHF1ZXJ5IGtleTogJHt0aGlzLnF1ZXJ5SGFzaH1gXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5xdWVyeUhhc2h9IGRhdGEgaXMgdW5kZWZpbmVkYCk7XG4gICAgICB9XG4gICAgICB0aGlzLnNldERhdGEoZGF0YSk7XG4gICAgICB0aGlzLiNjYWNoZS5jb25maWcub25TdWNjZXNzPy4oZGF0YSwgdGhpcyk7XG4gICAgICB0aGlzLiNjYWNoZS5jb25maWcub25TZXR0bGVkPy4oXG4gICAgICAgIGRhdGEsXG4gICAgICAgIHRoaXMuc3RhdGUuZXJyb3IsXG4gICAgICAgIHRoaXNcbiAgICAgICk7XG4gICAgICByZXR1cm4gZGF0YTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgQ2FuY2VsbGVkRXJyb3IpIHtcbiAgICAgICAgaWYgKGVycm9yLnNpbGVudCkge1xuICAgICAgICAgIHJldHVybiB0aGlzLiNyZXRyeWVyLnByb21pc2U7XG4gICAgICAgIH0gZWxzZSBpZiAoZXJyb3IucmV2ZXJ0KSB7XG4gICAgICAgICAgaWYgKHRoaXMuc3RhdGUuZGF0YSA9PT0gdm9pZCAwKSB7XG4gICAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHRoaXMuc3RhdGUuZGF0YTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgdGhpcy4jZGlzcGF0Y2goe1xuICAgICAgICB0eXBlOiBcImVycm9yXCIsXG4gICAgICAgIGVycm9yXG4gICAgICB9KTtcbiAgICAgIHRoaXMuI2NhY2hlLmNvbmZpZy5vbkVycm9yPy4oXG4gICAgICAgIGVycm9yLFxuICAgICAgICB0aGlzXG4gICAgICApO1xuICAgICAgdGhpcy4jY2FjaGUuY29uZmlnLm9uU2V0dGxlZD8uKFxuICAgICAgICB0aGlzLnN0YXRlLmRhdGEsXG4gICAgICAgIGVycm9yLFxuICAgICAgICB0aGlzXG4gICAgICApO1xuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHRoaXMuc2NoZWR1bGVHYygpO1xuICAgIH1cbiAgfVxuICAjZGlzcGF0Y2goYWN0aW9uKSB7XG4gICAgY29uc3QgcmVkdWNlciA9IChzdGF0ZSkgPT4ge1xuICAgICAgc3dpdGNoIChhY3Rpb24udHlwZSkge1xuICAgICAgICBjYXNlIFwiZmFpbGVkXCI6XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgZmV0Y2hGYWlsdXJlQ291bnQ6IGFjdGlvbi5mYWlsdXJlQ291bnQsXG4gICAgICAgICAgICBmZXRjaEZhaWx1cmVSZWFzb246IGFjdGlvbi5lcnJvclxuICAgICAgICAgIH07XG4gICAgICAgIGNhc2UgXCJwYXVzZVwiOlxuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgIGZldGNoU3RhdHVzOiBcInBhdXNlZFwiXG4gICAgICAgICAgfTtcbiAgICAgICAgY2FzZSBcImNvbnRpbnVlXCI6XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgZmV0Y2hTdGF0dXM6IFwiZmV0Y2hpbmdcIlxuICAgICAgICAgIH07XG4gICAgICAgIGNhc2UgXCJmZXRjaFwiOlxuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgIC4uLmZldGNoU3RhdGUoc3RhdGUuZGF0YSwgdGhpcy5vcHRpb25zKSxcbiAgICAgICAgICAgIGZldGNoTWV0YTogYWN0aW9uLm1ldGEgPz8gbnVsbFxuICAgICAgICAgIH07XG4gICAgICAgIGNhc2UgXCJzdWNjZXNzXCI6XG4gICAgICAgICAgY29uc3QgbmV3U3RhdGUgPSB7XG4gICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgIC4uLnN1Y2Nlc3NTdGF0ZShhY3Rpb24uZGF0YSwgYWN0aW9uLmRhdGFVcGRhdGVkQXQpLFxuICAgICAgICAgICAgZGF0YVVwZGF0ZUNvdW50OiBzdGF0ZS5kYXRhVXBkYXRlQ291bnQgKyAxLFxuICAgICAgICAgICAgLi4uIWFjdGlvbi5tYW51YWwgJiYge1xuICAgICAgICAgICAgICBmZXRjaFN0YXR1czogXCJpZGxlXCIsXG4gICAgICAgICAgICAgIGZldGNoRmFpbHVyZUNvdW50OiAwLFxuICAgICAgICAgICAgICBmZXRjaEZhaWx1cmVSZWFzb246IG51bGxcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9O1xuICAgICAgICAgIHRoaXMuI3JldmVydFN0YXRlID0gYWN0aW9uLm1hbnVhbCA/IG5ld1N0YXRlIDogdm9pZCAwO1xuICAgICAgICAgIHJldHVybiBuZXdTdGF0ZTtcbiAgICAgICAgY2FzZSBcImVycm9yXCI6XG4gICAgICAgICAgY29uc3QgZXJyb3IgPSBhY3Rpb24uZXJyb3I7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgZXJyb3IsXG4gICAgICAgICAgICBlcnJvclVwZGF0ZUNvdW50OiBzdGF0ZS5lcnJvclVwZGF0ZUNvdW50ICsgMSxcbiAgICAgICAgICAgIGVycm9yVXBkYXRlZEF0OiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgZmV0Y2hGYWlsdXJlQ291bnQ6IHN0YXRlLmZldGNoRmFpbHVyZUNvdW50ICsgMSxcbiAgICAgICAgICAgIGZldGNoRmFpbHVyZVJlYXNvbjogZXJyb3IsXG4gICAgICAgICAgICBmZXRjaFN0YXR1czogXCJpZGxlXCIsXG4gICAgICAgICAgICBzdGF0dXM6IFwiZXJyb3JcIixcbiAgICAgICAgICAgIC8vIGZsYWcgZXhpc3RpbmcgZGF0YSBhcyBpbnZhbGlkYXRlZCBpZiB3ZSBnZXQgYSBiYWNrZ3JvdW5kIGVycm9yXG4gICAgICAgICAgICAvLyBub3RlIHRoYXQgXCJubyBkYXRhXCIgYWx3YXlzIG1lYW5zIHN0YWxlIHNvIHdlIGNhbiBzZXQgdW5jb25kaXRpb25hbGx5IGhlcmVcbiAgICAgICAgICAgIGlzSW52YWxpZGF0ZWQ6IHRydWVcbiAgICAgICAgICB9O1xuICAgICAgICBjYXNlIFwiaW52YWxpZGF0ZVwiOlxuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgIGlzSW52YWxpZGF0ZWQ6IHRydWVcbiAgICAgICAgICB9O1xuICAgICAgICBjYXNlIFwic2V0U3RhdGVcIjpcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgICAgICAuLi5hY3Rpb24uc3RhdGVcbiAgICAgICAgICB9O1xuICAgICAgfVxuICAgIH07XG4gICAgdGhpcy5zdGF0ZSA9IHJlZHVjZXIodGhpcy5zdGF0ZSk7XG4gICAgbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG4gICAgICB0aGlzLm9ic2VydmVycy5mb3JFYWNoKChvYnNlcnZlcikgPT4ge1xuICAgICAgICBvYnNlcnZlci5vblF1ZXJ5VXBkYXRlKCk7XG4gICAgICB9KTtcbiAgICAgIHRoaXMuI2NhY2hlLm5vdGlmeSh7IHF1ZXJ5OiB0aGlzLCB0eXBlOiBcInVwZGF0ZWRcIiwgYWN0aW9uIH0pO1xuICAgIH0pO1xuICB9XG59O1xuZnVuY3Rpb24gZmV0Y2hTdGF0ZShkYXRhLCBvcHRpb25zKSB7XG4gIHJldHVybiB7XG4gICAgZmV0Y2hGYWlsdXJlQ291bnQ6IDAsXG4gICAgZmV0Y2hGYWlsdXJlUmVhc29uOiBudWxsLFxuICAgIGZldGNoU3RhdHVzOiBjYW5GZXRjaChvcHRpb25zLm5ldHdvcmtNb2RlKSA/IFwiZmV0Y2hpbmdcIiA6IFwicGF1c2VkXCIsXG4gICAgLi4uZGF0YSA9PT0gdm9pZCAwICYmIHtcbiAgICAgIGVycm9yOiBudWxsLFxuICAgICAgc3RhdHVzOiBcInBlbmRpbmdcIlxuICAgIH1cbiAgfTtcbn1cbmZ1bmN0aW9uIHN1Y2Nlc3NTdGF0ZShkYXRhLCBkYXRhVXBkYXRlZEF0KSB7XG4gIHJldHVybiB7XG4gICAgZGF0YSxcbiAgICBkYXRhVXBkYXRlZEF0OiBkYXRhVXBkYXRlZEF0ID8/IERhdGUubm93KCksXG4gICAgZXJyb3I6IG51bGwsXG4gICAgaXNJbnZhbGlkYXRlZDogZmFsc2UsXG4gICAgc3RhdHVzOiBcInN1Y2Nlc3NcIlxuICB9O1xufVxuZnVuY3Rpb24gZ2V0RGVmYXVsdFN0YXRlKG9wdGlvbnMpIHtcbiAgY29uc3QgZGF0YSA9IHR5cGVvZiBvcHRpb25zLmluaXRpYWxEYXRhID09PSBcImZ1bmN0aW9uXCIgPyBvcHRpb25zLmluaXRpYWxEYXRhKCkgOiBvcHRpb25zLmluaXRpYWxEYXRhO1xuICBjb25zdCBoYXNEYXRhID0gZGF0YSAhPT0gdm9pZCAwO1xuICBjb25zdCBpbml0aWFsRGF0YVVwZGF0ZWRBdCA9IGhhc0RhdGEgPyB0eXBlb2Ygb3B0aW9ucy5pbml0aWFsRGF0YVVwZGF0ZWRBdCA9PT0gXCJmdW5jdGlvblwiID8gb3B0aW9ucy5pbml0aWFsRGF0YVVwZGF0ZWRBdCgpIDogb3B0aW9ucy5pbml0aWFsRGF0YVVwZGF0ZWRBdCA6IDA7XG4gIHJldHVybiB7XG4gICAgZGF0YSxcbiAgICBkYXRhVXBkYXRlQ291bnQ6IDAsXG4gICAgZGF0YVVwZGF0ZWRBdDogaGFzRGF0YSA/IGluaXRpYWxEYXRhVXBkYXRlZEF0ID8/IERhdGUubm93KCkgOiAwLFxuICAgIGVycm9yOiBudWxsLFxuICAgIGVycm9yVXBkYXRlQ291bnQ6IDAsXG4gICAgZXJyb3JVcGRhdGVkQXQ6IDAsXG4gICAgZmV0Y2hGYWlsdXJlQ291bnQ6IDAsXG4gICAgZmV0Y2hGYWlsdXJlUmVhc29uOiBudWxsLFxuICAgIGZldGNoTWV0YTogbnVsbCxcbiAgICBpc0ludmFsaWRhdGVkOiBmYWxzZSxcbiAgICBzdGF0dXM6IGhhc0RhdGEgPyBcInN1Y2Nlc3NcIiA6IFwicGVuZGluZ1wiLFxuICAgIGZldGNoU3RhdHVzOiBcImlkbGVcIlxuICB9O1xufVxuZXhwb3J0IHtcbiAgUXVlcnksXG4gIGZldGNoU3RhdGVcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1xdWVyeS5qcy5tYXAiLCIvLyBzcmMvcXVlcnlPYnNlcnZlci50c1xuaW1wb3J0IHsgZm9jdXNNYW5hZ2VyIH0gZnJvbSBcIi4vZm9jdXNNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBlbnZpcm9ubWVudE1hbmFnZXIgfSBmcm9tIFwiLi9lbnZpcm9ubWVudE1hbmFnZXIuanNcIjtcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBmZXRjaFN0YXRlIH0gZnJvbSBcIi4vcXVlcnkuanNcIjtcbmltcG9ydCB7IFN1YnNjcmliYWJsZSB9IGZyb20gXCIuL3N1YnNjcmliYWJsZS5qc1wiO1xuaW1wb3J0IHsgcGVuZGluZ1RoZW5hYmxlIH0gZnJvbSBcIi4vdGhlbmFibGUuanNcIjtcbmltcG9ydCB7XG4gIGlzVmFsaWRUaW1lb3V0LFxuICBub29wLFxuICByZXBsYWNlRGF0YSxcbiAgcmVzb2x2ZVF1ZXJ5Qm9vbGVhbixcbiAgcmVzb2x2ZVN0YWxlVGltZSxcbiAgc2hhbGxvd0VxdWFsT2JqZWN0cyxcbiAgdGltZVVudGlsU3RhbGVcbn0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmltcG9ydCB7IHRpbWVvdXRNYW5hZ2VyIH0gZnJvbSBcIi4vdGltZW91dE1hbmFnZXIuanNcIjtcbnZhciBRdWVyeU9ic2VydmVyID0gY2xhc3MgZXh0ZW5kcyBTdWJzY3JpYmFibGUge1xuICBjb25zdHJ1Y3RvcihjbGllbnQsIG9wdGlvbnMpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMub3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgdGhpcy4jY2xpZW50ID0gY2xpZW50O1xuICAgIHRoaXMuI3NlbGVjdEVycm9yID0gbnVsbDtcbiAgICB0aGlzLiNjdXJyZW50VGhlbmFibGUgPSBwZW5kaW5nVGhlbmFibGUoKTtcbiAgICB0aGlzLmJpbmRNZXRob2RzKCk7XG4gICAgdGhpcy5zZXRPcHRpb25zKG9wdGlvbnMpO1xuICB9XG4gICNjbGllbnQ7XG4gICNjdXJyZW50UXVlcnkgPSB2b2lkIDA7XG4gICNjdXJyZW50UXVlcnlJbml0aWFsU3RhdGUgPSB2b2lkIDA7XG4gICNjdXJyZW50UmVzdWx0ID0gdm9pZCAwO1xuICAjY3VycmVudFJlc3VsdFN0YXRlO1xuICAjY3VycmVudFJlc3VsdE9wdGlvbnM7XG4gICNjdXJyZW50VGhlbmFibGU7XG4gICNzZWxlY3RFcnJvcjtcbiAgI3NlbGVjdEZuO1xuICAjc2VsZWN0UmVzdWx0O1xuICAvLyBUaGlzIHByb3BlcnR5IGtlZXBzIHRyYWNrIG9mIHRoZSBsYXN0IHF1ZXJ5IHdpdGggZGVmaW5lZCBkYXRhLlxuICAvLyBJdCB3aWxsIGJlIHVzZWQgdG8gcGFzcyB0aGUgcHJldmlvdXMgZGF0YSBhbmQgcXVlcnkgdG8gdGhlIHBsYWNlaG9sZGVyIGZ1bmN0aW9uIGJldHdlZW4gcmVuZGVycy5cbiAgI2xhc3RRdWVyeVdpdGhEZWZpbmVkRGF0YTtcbiAgI3N0YWxlVGltZW91dElkO1xuICAjcmVmZXRjaEludGVydmFsSWQ7XG4gICNjdXJyZW50UmVmZXRjaEludGVydmFsO1xuICAjdHJhY2tlZFByb3BzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcbiAgYmluZE1ldGhvZHMoKSB7XG4gICAgdGhpcy5yZWZldGNoID0gdGhpcy5yZWZldGNoLmJpbmQodGhpcyk7XG4gIH1cbiAgb25TdWJzY3JpYmUoKSB7XG4gICAgaWYgKHRoaXMubGlzdGVuZXJzLnNpemUgPT09IDEpIHtcbiAgICAgIHRoaXMuI2N1cnJlbnRRdWVyeS5hZGRPYnNlcnZlcih0aGlzKTtcbiAgICAgIGlmIChzaG91bGRGZXRjaE9uTW91bnQodGhpcy4jY3VycmVudFF1ZXJ5LCB0aGlzLm9wdGlvbnMpKSB7XG4gICAgICAgIHRoaXMuI2V4ZWN1dGVGZXRjaCgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy51cGRhdGVSZXN1bHQoKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuI3VwZGF0ZVRpbWVycygpO1xuICAgIH1cbiAgfVxuICBvblVuc3Vic2NyaWJlKCkge1xuICAgIGlmICghdGhpcy5oYXNMaXN0ZW5lcnMoKSkge1xuICAgICAgdGhpcy5kZXN0cm95KCk7XG4gICAgfVxuICB9XG4gIHNob3VsZEZldGNoT25SZWNvbm5lY3QoKSB7XG4gICAgcmV0dXJuIHNob3VsZEZldGNoT24oXG4gICAgICB0aGlzLiNjdXJyZW50UXVlcnksXG4gICAgICB0aGlzLm9wdGlvbnMsXG4gICAgICB0aGlzLm9wdGlvbnMucmVmZXRjaE9uUmVjb25uZWN0XG4gICAgKTtcbiAgfVxuICBzaG91bGRGZXRjaE9uV2luZG93Rm9jdXMoKSB7XG4gICAgcmV0dXJuIHNob3VsZEZldGNoT24oXG4gICAgICB0aGlzLiNjdXJyZW50UXVlcnksXG4gICAgICB0aGlzLm9wdGlvbnMsXG4gICAgICB0aGlzLm9wdGlvbnMucmVmZXRjaE9uV2luZG93Rm9jdXNcbiAgICApO1xuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5saXN0ZW5lcnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuICAgIHRoaXMuI2NsZWFyU3RhbGVUaW1lb3V0KCk7XG4gICAgdGhpcy4jY2xlYXJSZWZldGNoSW50ZXJ2YWwoKTtcbiAgICB0aGlzLiNjdXJyZW50UXVlcnkucmVtb3ZlT2JzZXJ2ZXIodGhpcyk7XG4gIH1cbiAgc2V0T3B0aW9ucyhvcHRpb25zKSB7XG4gICAgY29uc3QgcHJldk9wdGlvbnMgPSB0aGlzLm9wdGlvbnM7XG4gICAgY29uc3QgcHJldlF1ZXJ5ID0gdGhpcy4jY3VycmVudFF1ZXJ5O1xuICAgIHRoaXMub3B0aW9ucyA9IHRoaXMuI2NsaWVudC5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuICAgIGlmICh0aGlzLm9wdGlvbnMuZW5hYmxlZCAhPT0gdm9pZCAwICYmIHR5cGVvZiB0aGlzLm9wdGlvbnMuZW5hYmxlZCAhPT0gXCJib29sZWFuXCIgJiYgdHlwZW9mIHRoaXMub3B0aW9ucy5lbmFibGVkICE9PSBcImZ1bmN0aW9uXCIgJiYgdHlwZW9mIHJlc29sdmVRdWVyeUJvb2xlYW4odGhpcy5vcHRpb25zLmVuYWJsZWQsIHRoaXMuI2N1cnJlbnRRdWVyeSkgIT09IFwiYm9vbGVhblwiKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIFwiRXhwZWN0ZWQgZW5hYmxlZCB0byBiZSBhIGJvb2xlYW4gb3IgYSBjYWxsYmFjayB0aGF0IHJldHVybnMgYSBib29sZWFuXCJcbiAgICAgICk7XG4gICAgfVxuICAgIHRoaXMuI3VwZGF0ZVF1ZXJ5KCk7XG4gICAgdGhpcy4jY3VycmVudFF1ZXJ5LnNldE9wdGlvbnModGhpcy5vcHRpb25zKTtcbiAgICBpZiAocHJldk9wdGlvbnMuX2RlZmF1bHRlZCAmJiAhc2hhbGxvd0VxdWFsT2JqZWN0cyh0aGlzLm9wdGlvbnMsIHByZXZPcHRpb25zKSkge1xuICAgICAgdGhpcy4jY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5ub3RpZnkoe1xuICAgICAgICB0eXBlOiBcIm9ic2VydmVyT3B0aW9uc1VwZGF0ZWRcIixcbiAgICAgICAgcXVlcnk6IHRoaXMuI2N1cnJlbnRRdWVyeSxcbiAgICAgICAgb2JzZXJ2ZXI6IHRoaXNcbiAgICAgIH0pO1xuICAgIH1cbiAgICBjb25zdCBtb3VudGVkID0gdGhpcy5oYXNMaXN0ZW5lcnMoKTtcbiAgICBpZiAobW91bnRlZCAmJiBzaG91bGRGZXRjaE9wdGlvbmFsbHkoXG4gICAgICB0aGlzLiNjdXJyZW50UXVlcnksXG4gICAgICBwcmV2UXVlcnksXG4gICAgICB0aGlzLm9wdGlvbnMsXG4gICAgICBwcmV2T3B0aW9uc1xuICAgICkpIHtcbiAgICAgIHRoaXMuI2V4ZWN1dGVGZXRjaCgpO1xuICAgIH1cbiAgICB0aGlzLnVwZGF0ZVJlc3VsdCgpO1xuICAgIGlmIChtb3VudGVkICYmICh0aGlzLiNjdXJyZW50UXVlcnkgIT09IHByZXZRdWVyeSB8fCByZXNvbHZlUXVlcnlCb29sZWFuKHRoaXMub3B0aW9ucy5lbmFibGVkLCB0aGlzLiNjdXJyZW50UXVlcnkpICE9PSByZXNvbHZlUXVlcnlCb29sZWFuKHByZXZPcHRpb25zLmVuYWJsZWQsIHRoaXMuI2N1cnJlbnRRdWVyeSkgfHwgcmVzb2x2ZVN0YWxlVGltZSh0aGlzLm9wdGlvbnMuc3RhbGVUaW1lLCB0aGlzLiNjdXJyZW50UXVlcnkpICE9PSByZXNvbHZlU3RhbGVUaW1lKHByZXZPcHRpb25zLnN0YWxlVGltZSwgdGhpcy4jY3VycmVudFF1ZXJ5KSkpIHtcbiAgICAgIHRoaXMuI3VwZGF0ZVN0YWxlVGltZW91dCgpO1xuICAgIH1cbiAgICBjb25zdCBuZXh0UmVmZXRjaEludGVydmFsID0gdGhpcy4jY29tcHV0ZVJlZmV0Y2hJbnRlcnZhbCgpO1xuICAgIGlmIChtb3VudGVkICYmICh0aGlzLiNjdXJyZW50UXVlcnkgIT09IHByZXZRdWVyeSB8fCByZXNvbHZlUXVlcnlCb29sZWFuKHRoaXMub3B0aW9ucy5lbmFibGVkLCB0aGlzLiNjdXJyZW50UXVlcnkpICE9PSByZXNvbHZlUXVlcnlCb29sZWFuKHByZXZPcHRpb25zLmVuYWJsZWQsIHRoaXMuI2N1cnJlbnRRdWVyeSkgfHwgbmV4dFJlZmV0Y2hJbnRlcnZhbCAhPT0gdGhpcy4jY3VycmVudFJlZmV0Y2hJbnRlcnZhbCkpIHtcbiAgICAgIHRoaXMuI3VwZGF0ZVJlZmV0Y2hJbnRlcnZhbChuZXh0UmVmZXRjaEludGVydmFsKTtcbiAgICB9XG4gIH1cbiAgZ2V0T3B0aW1pc3RpY1Jlc3VsdChvcHRpb25zKSB7XG4gICAgY29uc3QgcXVlcnkgPSB0aGlzLiNjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmJ1aWxkKHRoaXMuI2NsaWVudCwgb3B0aW9ucyk7XG4gICAgY29uc3QgcmVzdWx0ID0gdGhpcy5jcmVhdGVSZXN1bHQocXVlcnksIG9wdGlvbnMpO1xuICAgIGlmIChzaG91bGRBc3NpZ25PYnNlcnZlckN1cnJlbnRQcm9wZXJ0aWVzKHRoaXMsIHJlc3VsdCkpIHtcbiAgICAgIHRoaXMuI2N1cnJlbnRSZXN1bHQgPSByZXN1bHQ7XG4gICAgICB0aGlzLiNjdXJyZW50UmVzdWx0T3B0aW9ucyA9IHRoaXMub3B0aW9ucztcbiAgICAgIHRoaXMuI2N1cnJlbnRSZXN1bHRTdGF0ZSA9IHRoaXMuI2N1cnJlbnRRdWVyeS5zdGF0ZTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuICBnZXRDdXJyZW50UmVzdWx0KCkge1xuICAgIHJldHVybiB0aGlzLiNjdXJyZW50UmVzdWx0O1xuICB9XG4gIHRyYWNrUmVzdWx0KHJlc3VsdCwgb25Qcm9wVHJhY2tlZCkge1xuICAgIHJldHVybiBuZXcgUHJveHkocmVzdWx0LCB7XG4gICAgICBnZXQ6ICh0YXJnZXQsIGtleSkgPT4ge1xuICAgICAgICB0aGlzLnRyYWNrUHJvcChrZXkpO1xuICAgICAgICBvblByb3BUcmFja2VkPy4oa2V5KTtcbiAgICAgICAgaWYgKGtleSA9PT0gXCJwcm9taXNlXCIpIHtcbiAgICAgICAgICB0aGlzLnRyYWNrUHJvcChcImRhdGFcIik7XG4gICAgICAgICAgaWYgKCF0aGlzLm9wdGlvbnMuZXhwZXJpbWVudGFsX3ByZWZldGNoSW5SZW5kZXIgJiYgdGhpcy4jY3VycmVudFRoZW5hYmxlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIpIHtcbiAgICAgICAgICAgIHRoaXMuI2N1cnJlbnRUaGVuYWJsZS5yZWplY3QoXG4gICAgICAgICAgICAgIG5ldyBFcnJvcihcbiAgICAgICAgICAgICAgICBcImV4cGVyaW1lbnRhbF9wcmVmZXRjaEluUmVuZGVyIGZlYXR1cmUgZmxhZyBpcyBub3QgZW5hYmxlZFwiXG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBSZWZsZWN0LmdldCh0YXJnZXQsIGtleSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgdHJhY2tQcm9wKGtleSkge1xuICAgIHRoaXMuI3RyYWNrZWRQcm9wcy5hZGQoa2V5KTtcbiAgfVxuICBnZXRDdXJyZW50UXVlcnkoKSB7XG4gICAgcmV0dXJuIHRoaXMuI2N1cnJlbnRRdWVyeTtcbiAgfVxuICByZWZldGNoKHsgLi4ub3B0aW9ucyB9ID0ge30pIHtcbiAgICByZXR1cm4gdGhpcy5mZXRjaCh7XG4gICAgICAuLi5vcHRpb25zXG4gICAgfSk7XG4gIH1cbiAgZmV0Y2hPcHRpbWlzdGljKG9wdGlvbnMpIHtcbiAgICBjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gdGhpcy4jY2xpZW50LmRlZmF1bHRRdWVyeU9wdGlvbnMob3B0aW9ucyk7XG4gICAgY29uc3QgcXVlcnkgPSB0aGlzLiNjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmJ1aWxkKHRoaXMuI2NsaWVudCwgZGVmYXVsdGVkT3B0aW9ucyk7XG4gICAgcmV0dXJuIHF1ZXJ5LmZldGNoKCkudGhlbigoKSA9PiB0aGlzLmNyZWF0ZVJlc3VsdChxdWVyeSwgZGVmYXVsdGVkT3B0aW9ucykpO1xuICB9XG4gIGZldGNoKGZldGNoT3B0aW9ucykge1xuICAgIHJldHVybiB0aGlzLiNleGVjdXRlRmV0Y2goe1xuICAgICAgLi4uZmV0Y2hPcHRpb25zLFxuICAgICAgY2FuY2VsUmVmZXRjaDogZmV0Y2hPcHRpb25zLmNhbmNlbFJlZmV0Y2ggPz8gdHJ1ZVxuICAgIH0pLnRoZW4oKCkgPT4ge1xuICAgICAgdGhpcy51cGRhdGVSZXN1bHQoKTtcbiAgICAgIHJldHVybiB0aGlzLiNjdXJyZW50UmVzdWx0O1xuICAgIH0pO1xuICB9XG4gICNleGVjdXRlRmV0Y2goZmV0Y2hPcHRpb25zKSB7XG4gICAgdGhpcy4jdXBkYXRlUXVlcnkoKTtcbiAgICBsZXQgcHJvbWlzZSA9IHRoaXMuI2N1cnJlbnRRdWVyeS5mZXRjaChcbiAgICAgIHRoaXMub3B0aW9ucyxcbiAgICAgIGZldGNoT3B0aW9uc1xuICAgICk7XG4gICAgaWYgKCFmZXRjaE9wdGlvbnM/LnRocm93T25FcnJvcikge1xuICAgICAgcHJvbWlzZSA9IHByb21pc2UuY2F0Y2gobm9vcCk7XG4gICAgfVxuICAgIHJldHVybiBwcm9taXNlO1xuICB9XG4gICN1cGRhdGVTdGFsZVRpbWVvdXQoKSB7XG4gICAgdGhpcy4jY2xlYXJTdGFsZVRpbWVvdXQoKTtcbiAgICBjb25zdCBzdGFsZVRpbWUgPSByZXNvbHZlU3RhbGVUaW1lKFxuICAgICAgdGhpcy5vcHRpb25zLnN0YWxlVGltZSxcbiAgICAgIHRoaXMuI2N1cnJlbnRRdWVyeVxuICAgICk7XG4gICAgaWYgKGVudmlyb25tZW50TWFuYWdlci5pc1NlcnZlcigpIHx8IHRoaXMuI2N1cnJlbnRSZXN1bHQuaXNTdGFsZSB8fCAhaXNWYWxpZFRpbWVvdXQoc3RhbGVUaW1lKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCB0aW1lID0gdGltZVVudGlsU3RhbGUodGhpcy4jY3VycmVudFJlc3VsdC5kYXRhVXBkYXRlZEF0LCBzdGFsZVRpbWUpO1xuICAgIGNvbnN0IHRpbWVvdXQgPSB0aW1lICsgMTtcbiAgICB0aGlzLiNzdGFsZVRpbWVvdXRJZCA9IHRpbWVvdXRNYW5hZ2VyLnNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgaWYgKCF0aGlzLiNjdXJyZW50UmVzdWx0LmlzU3RhbGUpIHtcbiAgICAgICAgdGhpcy51cGRhdGVSZXN1bHQoKTtcbiAgICAgIH1cbiAgICB9LCB0aW1lb3V0KTtcbiAgfVxuICAjY29tcHV0ZVJlZmV0Y2hJbnRlcnZhbCgpIHtcbiAgICByZXR1cm4gKHR5cGVvZiB0aGlzLm9wdGlvbnMucmVmZXRjaEludGVydmFsID09PSBcImZ1bmN0aW9uXCIgPyB0aGlzLm9wdGlvbnMucmVmZXRjaEludGVydmFsKHRoaXMuI2N1cnJlbnRRdWVyeSkgOiB0aGlzLm9wdGlvbnMucmVmZXRjaEludGVydmFsKSA/PyBmYWxzZTtcbiAgfVxuICAjdXBkYXRlUmVmZXRjaEludGVydmFsKG5leHRJbnRlcnZhbCkge1xuICAgIHRoaXMuI2NsZWFyUmVmZXRjaEludGVydmFsKCk7XG4gICAgdGhpcy4jY3VycmVudFJlZmV0Y2hJbnRlcnZhbCA9IG5leHRJbnRlcnZhbDtcbiAgICBpZiAoZW52aXJvbm1lbnRNYW5hZ2VyLmlzU2VydmVyKCkgfHwgcmVzb2x2ZVF1ZXJ5Qm9vbGVhbih0aGlzLm9wdGlvbnMuZW5hYmxlZCwgdGhpcy4jY3VycmVudFF1ZXJ5KSA9PT0gZmFsc2UgfHwgIWlzVmFsaWRUaW1lb3V0KHRoaXMuI2N1cnJlbnRSZWZldGNoSW50ZXJ2YWwpIHx8IHRoaXMuI2N1cnJlbnRSZWZldGNoSW50ZXJ2YWwgPT09IDApIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy4jcmVmZXRjaEludGVydmFsSWQgPSB0aW1lb3V0TWFuYWdlci5zZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICBpZiAodGhpcy5vcHRpb25zLnJlZmV0Y2hJbnRlcnZhbEluQmFja2dyb3VuZCB8fCBmb2N1c01hbmFnZXIuaXNGb2N1c2VkKCkpIHtcbiAgICAgICAgdGhpcy4jZXhlY3V0ZUZldGNoKCk7XG4gICAgICB9XG4gICAgfSwgdGhpcy4jY3VycmVudFJlZmV0Y2hJbnRlcnZhbCk7XG4gIH1cbiAgI3VwZGF0ZVRpbWVycygpIHtcbiAgICB0aGlzLiN1cGRhdGVTdGFsZVRpbWVvdXQoKTtcbiAgICB0aGlzLiN1cGRhdGVSZWZldGNoSW50ZXJ2YWwodGhpcy4jY29tcHV0ZVJlZmV0Y2hJbnRlcnZhbCgpKTtcbiAgfVxuICAjY2xlYXJTdGFsZVRpbWVvdXQoKSB7XG4gICAgaWYgKHRoaXMuI3N0YWxlVGltZW91dElkICE9PSB2b2lkIDApIHtcbiAgICAgIHRpbWVvdXRNYW5hZ2VyLmNsZWFyVGltZW91dCh0aGlzLiNzdGFsZVRpbWVvdXRJZCk7XG4gICAgICB0aGlzLiNzdGFsZVRpbWVvdXRJZCA9IHZvaWQgMDtcbiAgICB9XG4gIH1cbiAgI2NsZWFyUmVmZXRjaEludGVydmFsKCkge1xuICAgIGlmICh0aGlzLiNyZWZldGNoSW50ZXJ2YWxJZCAhPT0gdm9pZCAwKSB7XG4gICAgICB0aW1lb3V0TWFuYWdlci5jbGVhckludGVydmFsKHRoaXMuI3JlZmV0Y2hJbnRlcnZhbElkKTtcbiAgICAgIHRoaXMuI3JlZmV0Y2hJbnRlcnZhbElkID0gdm9pZCAwO1xuICAgIH1cbiAgfVxuICBjcmVhdGVSZXN1bHQocXVlcnksIG9wdGlvbnMpIHtcbiAgICBjb25zdCBwcmV2UXVlcnkgPSB0aGlzLiNjdXJyZW50UXVlcnk7XG4gICAgY29uc3QgcHJldk9wdGlvbnMgPSB0aGlzLm9wdGlvbnM7XG4gICAgY29uc3QgcHJldlJlc3VsdCA9IHRoaXMuI2N1cnJlbnRSZXN1bHQ7XG4gICAgY29uc3QgcHJldlJlc3VsdFN0YXRlID0gdGhpcy4jY3VycmVudFJlc3VsdFN0YXRlO1xuICAgIGNvbnN0IHByZXZSZXN1bHRPcHRpb25zID0gdGhpcy4jY3VycmVudFJlc3VsdE9wdGlvbnM7XG4gICAgY29uc3QgcXVlcnlDaGFuZ2UgPSBxdWVyeSAhPT0gcHJldlF1ZXJ5O1xuICAgIGNvbnN0IHF1ZXJ5SW5pdGlhbFN0YXRlID0gcXVlcnlDaGFuZ2UgPyBxdWVyeS5zdGF0ZSA6IHRoaXMuI2N1cnJlbnRRdWVyeUluaXRpYWxTdGF0ZTtcbiAgICBjb25zdCB7IHN0YXRlIH0gPSBxdWVyeTtcbiAgICBsZXQgbmV3U3RhdGUgPSB7IC4uLnN0YXRlIH07XG4gICAgbGV0IGlzUGxhY2Vob2xkZXJEYXRhID0gZmFsc2U7XG4gICAgbGV0IGRhdGE7XG4gICAgaWYgKG9wdGlvbnMuX29wdGltaXN0aWNSZXN1bHRzKSB7XG4gICAgICBjb25zdCBtb3VudGVkID0gdGhpcy5oYXNMaXN0ZW5lcnMoKTtcbiAgICAgIGNvbnN0IGZldGNoT25Nb3VudCA9ICFtb3VudGVkICYmIHNob3VsZEZldGNoT25Nb3VudChxdWVyeSwgb3B0aW9ucyk7XG4gICAgICBjb25zdCBmZXRjaE9wdGlvbmFsbHkgPSBtb3VudGVkICYmIHNob3VsZEZldGNoT3B0aW9uYWxseShxdWVyeSwgcHJldlF1ZXJ5LCBvcHRpb25zLCBwcmV2T3B0aW9ucyk7XG4gICAgICBpZiAoZmV0Y2hPbk1vdW50IHx8IGZldGNoT3B0aW9uYWxseSkge1xuICAgICAgICBuZXdTdGF0ZSA9IHtcbiAgICAgICAgICAuLi5uZXdTdGF0ZSxcbiAgICAgICAgICAuLi5mZXRjaFN0YXRlKHN0YXRlLmRhdGEsIHF1ZXJ5Lm9wdGlvbnMpXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBpZiAob3B0aW9ucy5fb3B0aW1pc3RpY1Jlc3VsdHMgPT09IFwiaXNSZXN0b3JpbmdcIikge1xuICAgICAgICBuZXdTdGF0ZS5mZXRjaFN0YXR1cyA9IFwiaWRsZVwiO1xuICAgICAgfVxuICAgIH1cbiAgICBsZXQgeyBlcnJvciwgZXJyb3JVcGRhdGVkQXQsIHN0YXR1cyB9ID0gbmV3U3RhdGU7XG4gICAgZGF0YSA9IG5ld1N0YXRlLmRhdGE7XG4gICAgbGV0IHNraXBTZWxlY3QgPSBmYWxzZTtcbiAgICBpZiAob3B0aW9ucy5wbGFjZWhvbGRlckRhdGEgIT09IHZvaWQgMCAmJiBkYXRhID09PSB2b2lkIDAgJiYgc3RhdHVzID09PSBcInBlbmRpbmdcIikge1xuICAgICAgbGV0IHBsYWNlaG9sZGVyRGF0YTtcbiAgICAgIGlmIChwcmV2UmVzdWx0Py5pc1BsYWNlaG9sZGVyRGF0YSAmJiBvcHRpb25zLnBsYWNlaG9sZGVyRGF0YSA9PT0gcHJldlJlc3VsdE9wdGlvbnM/LnBsYWNlaG9sZGVyRGF0YSkge1xuICAgICAgICBwbGFjZWhvbGRlckRhdGEgPSBwcmV2UmVzdWx0LmRhdGE7XG4gICAgICAgIHNraXBTZWxlY3QgPSB0cnVlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcGxhY2Vob2xkZXJEYXRhID0gdHlwZW9mIG9wdGlvbnMucGxhY2Vob2xkZXJEYXRhID09PSBcImZ1bmN0aW9uXCIgPyBvcHRpb25zLnBsYWNlaG9sZGVyRGF0YShcbiAgICAgICAgICB0aGlzLiNsYXN0UXVlcnlXaXRoRGVmaW5lZERhdGE/LnN0YXRlLmRhdGEsXG4gICAgICAgICAgdGhpcy4jbGFzdFF1ZXJ5V2l0aERlZmluZWREYXRhXG4gICAgICAgICkgOiBvcHRpb25zLnBsYWNlaG9sZGVyRGF0YTtcbiAgICAgIH1cbiAgICAgIGlmIChwbGFjZWhvbGRlckRhdGEgIT09IHZvaWQgMCkge1xuICAgICAgICBzdGF0dXMgPSBcInN1Y2Nlc3NcIjtcbiAgICAgICAgZGF0YSA9IHJlcGxhY2VEYXRhKFxuICAgICAgICAgIHByZXZSZXN1bHQ/LmRhdGEsXG4gICAgICAgICAgcGxhY2Vob2xkZXJEYXRhLFxuICAgICAgICAgIG9wdGlvbnNcbiAgICAgICAgKTtcbiAgICAgICAgaXNQbGFjZWhvbGRlckRhdGEgPSB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAob3B0aW9ucy5zZWxlY3QgJiYgZGF0YSAhPT0gdm9pZCAwICYmICFza2lwU2VsZWN0KSB7XG4gICAgICBpZiAocHJldlJlc3VsdCAmJiBkYXRhID09PSBwcmV2UmVzdWx0U3RhdGU/LmRhdGEgJiYgb3B0aW9ucy5zZWxlY3QgPT09IHRoaXMuI3NlbGVjdEZuKSB7XG4gICAgICAgIGRhdGEgPSB0aGlzLiNzZWxlY3RSZXN1bHQ7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIHRoaXMuI3NlbGVjdEZuID0gb3B0aW9ucy5zZWxlY3Q7XG4gICAgICAgICAgZGF0YSA9IG9wdGlvbnMuc2VsZWN0KGRhdGEpO1xuICAgICAgICAgIGRhdGEgPSByZXBsYWNlRGF0YShwcmV2UmVzdWx0Py5kYXRhLCBkYXRhLCBvcHRpb25zKTtcbiAgICAgICAgICB0aGlzLiNzZWxlY3RSZXN1bHQgPSBkYXRhO1xuICAgICAgICAgIHRoaXMuI3NlbGVjdEVycm9yID0gbnVsbDtcbiAgICAgICAgfSBjYXRjaCAoc2VsZWN0RXJyb3IpIHtcbiAgICAgICAgICB0aGlzLiNzZWxlY3RFcnJvciA9IHNlbGVjdEVycm9yO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGlmICh0aGlzLiNzZWxlY3RFcnJvcikge1xuICAgICAgZXJyb3IgPSB0aGlzLiNzZWxlY3RFcnJvcjtcbiAgICAgIGRhdGEgPSB0aGlzLiNzZWxlY3RSZXN1bHQ7XG4gICAgICBlcnJvclVwZGF0ZWRBdCA9IERhdGUubm93KCk7XG4gICAgICBzdGF0dXMgPSBcImVycm9yXCI7XG4gICAgfVxuICAgIGNvbnN0IGlzRmV0Y2hpbmcgPSBuZXdTdGF0ZS5mZXRjaFN0YXR1cyA9PT0gXCJmZXRjaGluZ1wiO1xuICAgIGNvbnN0IGlzUGVuZGluZyA9IHN0YXR1cyA9PT0gXCJwZW5kaW5nXCI7XG4gICAgY29uc3QgaXNFcnJvciA9IHN0YXR1cyA9PT0gXCJlcnJvclwiO1xuICAgIGNvbnN0IGlzTG9hZGluZyA9IGlzUGVuZGluZyAmJiBpc0ZldGNoaW5nO1xuICAgIGNvbnN0IGhhc0RhdGEgPSBkYXRhICE9PSB2b2lkIDA7XG4gICAgY29uc3QgcmVzdWx0ID0ge1xuICAgICAgc3RhdHVzLFxuICAgICAgZmV0Y2hTdGF0dXM6IG5ld1N0YXRlLmZldGNoU3RhdHVzLFxuICAgICAgaXNQZW5kaW5nLFxuICAgICAgaXNTdWNjZXNzOiBzdGF0dXMgPT09IFwic3VjY2Vzc1wiLFxuICAgICAgaXNFcnJvcixcbiAgICAgIGlzSW5pdGlhbExvYWRpbmc6IGlzTG9hZGluZyxcbiAgICAgIGlzTG9hZGluZyxcbiAgICAgIGRhdGEsXG4gICAgICBkYXRhVXBkYXRlZEF0OiBuZXdTdGF0ZS5kYXRhVXBkYXRlZEF0LFxuICAgICAgZXJyb3IsXG4gICAgICBlcnJvclVwZGF0ZWRBdCxcbiAgICAgIGZhaWx1cmVDb3VudDogbmV3U3RhdGUuZmV0Y2hGYWlsdXJlQ291bnQsXG4gICAgICBmYWlsdXJlUmVhc29uOiBuZXdTdGF0ZS5mZXRjaEZhaWx1cmVSZWFzb24sXG4gICAgICBlcnJvclVwZGF0ZUNvdW50OiBuZXdTdGF0ZS5lcnJvclVwZGF0ZUNvdW50LFxuICAgICAgaXNGZXRjaGVkOiBxdWVyeS5pc0ZldGNoZWQoKSxcbiAgICAgIGlzRmV0Y2hlZEFmdGVyTW91bnQ6IG5ld1N0YXRlLmRhdGFVcGRhdGVDb3VudCA+IHF1ZXJ5SW5pdGlhbFN0YXRlLmRhdGFVcGRhdGVDb3VudCB8fCBuZXdTdGF0ZS5lcnJvclVwZGF0ZUNvdW50ID4gcXVlcnlJbml0aWFsU3RhdGUuZXJyb3JVcGRhdGVDb3VudCxcbiAgICAgIGlzRmV0Y2hpbmcsXG4gICAgICBpc1JlZmV0Y2hpbmc6IGlzRmV0Y2hpbmcgJiYgIWlzUGVuZGluZyxcbiAgICAgIGlzTG9hZGluZ0Vycm9yOiBpc0Vycm9yICYmICFoYXNEYXRhLFxuICAgICAgaXNQYXVzZWQ6IG5ld1N0YXRlLmZldGNoU3RhdHVzID09PSBcInBhdXNlZFwiLFxuICAgICAgaXNQbGFjZWhvbGRlckRhdGEsXG4gICAgICBpc1JlZmV0Y2hFcnJvcjogaXNFcnJvciAmJiBoYXNEYXRhLFxuICAgICAgaXNTdGFsZTogaXNTdGFsZShxdWVyeSwgb3B0aW9ucyksXG4gICAgICByZWZldGNoOiB0aGlzLnJlZmV0Y2gsXG4gICAgICBwcm9taXNlOiB0aGlzLiNjdXJyZW50VGhlbmFibGUsXG4gICAgICBpc0VuYWJsZWQ6IHJlc29sdmVRdWVyeUJvb2xlYW4ob3B0aW9ucy5lbmFibGVkLCBxdWVyeSkgIT09IGZhbHNlXG4gICAgfTtcbiAgICBjb25zdCBuZXh0UmVzdWx0ID0gcmVzdWx0O1xuICAgIGlmICh0aGlzLm9wdGlvbnMuZXhwZXJpbWVudGFsX3ByZWZldGNoSW5SZW5kZXIpIHtcbiAgICAgIGNvbnN0IGhhc1Jlc3VsdERhdGEgPSBuZXh0UmVzdWx0LmRhdGEgIT09IHZvaWQgMDtcbiAgICAgIGNvbnN0IGlzRXJyb3JXaXRob3V0RGF0YSA9IG5leHRSZXN1bHQuc3RhdHVzID09PSBcImVycm9yXCIgJiYgIWhhc1Jlc3VsdERhdGE7XG4gICAgICBjb25zdCBmaW5hbGl6ZVRoZW5hYmxlSWZQb3NzaWJsZSA9ICh0aGVuYWJsZSkgPT4ge1xuICAgICAgICBpZiAoaXNFcnJvcldpdGhvdXREYXRhKSB7XG4gICAgICAgICAgdGhlbmFibGUucmVqZWN0KG5leHRSZXN1bHQuZXJyb3IpO1xuICAgICAgICB9IGVsc2UgaWYgKGhhc1Jlc3VsdERhdGEpIHtcbiAgICAgICAgICB0aGVuYWJsZS5yZXNvbHZlKG5leHRSZXN1bHQuZGF0YSk7XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICBjb25zdCByZWNyZWF0ZVRoZW5hYmxlID0gKCkgPT4ge1xuICAgICAgICBjb25zdCBwZW5kaW5nID0gdGhpcy4jY3VycmVudFRoZW5hYmxlID0gbmV4dFJlc3VsdC5wcm9taXNlID0gcGVuZGluZ1RoZW5hYmxlKCk7XG4gICAgICAgIGZpbmFsaXplVGhlbmFibGVJZlBvc3NpYmxlKHBlbmRpbmcpO1xuICAgICAgfTtcbiAgICAgIGNvbnN0IHByZXZUaGVuYWJsZSA9IHRoaXMuI2N1cnJlbnRUaGVuYWJsZTtcbiAgICAgIHN3aXRjaCAocHJldlRoZW5hYmxlLnN0YXR1cykge1xuICAgICAgICBjYXNlIFwicGVuZGluZ1wiOlxuICAgICAgICAgIGlmIChxdWVyeS5xdWVyeUhhc2ggPT09IHByZXZRdWVyeS5xdWVyeUhhc2gpIHtcbiAgICAgICAgICAgIGZpbmFsaXplVGhlbmFibGVJZlBvc3NpYmxlKHByZXZUaGVuYWJsZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwiZnVsZmlsbGVkXCI6XG4gICAgICAgICAgaWYgKGlzRXJyb3JXaXRob3V0RGF0YSB8fCBuZXh0UmVzdWx0LmRhdGEgIT09IHByZXZUaGVuYWJsZS52YWx1ZSkge1xuICAgICAgICAgICAgcmVjcmVhdGVUaGVuYWJsZSgpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcInJlamVjdGVkXCI6XG4gICAgICAgICAgaWYgKCFpc0Vycm9yV2l0aG91dERhdGEgfHwgbmV4dFJlc3VsdC5lcnJvciAhPT0gcHJldlRoZW5hYmxlLnJlYXNvbikge1xuICAgICAgICAgICAgcmVjcmVhdGVUaGVuYWJsZSgpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG5leHRSZXN1bHQ7XG4gIH1cbiAgdXBkYXRlUmVzdWx0KCkge1xuICAgIGNvbnN0IHByZXZSZXN1bHQgPSB0aGlzLiNjdXJyZW50UmVzdWx0O1xuICAgIGNvbnN0IG5leHRSZXN1bHQgPSB0aGlzLmNyZWF0ZVJlc3VsdCh0aGlzLiNjdXJyZW50UXVlcnksIHRoaXMub3B0aW9ucyk7XG4gICAgdGhpcy4jY3VycmVudFJlc3VsdFN0YXRlID0gdGhpcy4jY3VycmVudFF1ZXJ5LnN0YXRlO1xuICAgIHRoaXMuI2N1cnJlbnRSZXN1bHRPcHRpb25zID0gdGhpcy5vcHRpb25zO1xuICAgIGlmICh0aGlzLiNjdXJyZW50UmVzdWx0U3RhdGUuZGF0YSAhPT0gdm9pZCAwKSB7XG4gICAgICB0aGlzLiNsYXN0UXVlcnlXaXRoRGVmaW5lZERhdGEgPSB0aGlzLiNjdXJyZW50UXVlcnk7XG4gICAgfVxuICAgIGlmIChzaGFsbG93RXF1YWxPYmplY3RzKG5leHRSZXN1bHQsIHByZXZSZXN1bHQpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMuI2N1cnJlbnRSZXN1bHQgPSBuZXh0UmVzdWx0O1xuICAgIGNvbnN0IHNob3VsZE5vdGlmeUxpc3RlbmVycyA9ICgpID0+IHtcbiAgICAgIGlmICghcHJldlJlc3VsdCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHsgbm90aWZ5T25DaGFuZ2VQcm9wcyB9ID0gdGhpcy5vcHRpb25zO1xuICAgICAgY29uc3Qgbm90aWZ5T25DaGFuZ2VQcm9wc1ZhbHVlID0gdHlwZW9mIG5vdGlmeU9uQ2hhbmdlUHJvcHMgPT09IFwiZnVuY3Rpb25cIiA/IG5vdGlmeU9uQ2hhbmdlUHJvcHMoKSA6IG5vdGlmeU9uQ2hhbmdlUHJvcHM7XG4gICAgICBpZiAobm90aWZ5T25DaGFuZ2VQcm9wc1ZhbHVlID09PSBcImFsbFwiIHx8ICFub3RpZnlPbkNoYW5nZVByb3BzVmFsdWUgJiYgIXRoaXMuI3RyYWNrZWRQcm9wcy5zaXplKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgICAgY29uc3QgaW5jbHVkZWRQcm9wcyA9IG5ldyBTZXQoXG4gICAgICAgIG5vdGlmeU9uQ2hhbmdlUHJvcHNWYWx1ZSA/PyB0aGlzLiN0cmFja2VkUHJvcHNcbiAgICAgICk7XG4gICAgICBpZiAodGhpcy5vcHRpb25zLnRocm93T25FcnJvcikge1xuICAgICAgICBpbmNsdWRlZFByb3BzLmFkZChcImVycm9yXCIpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIE9iamVjdC5rZXlzKHRoaXMuI2N1cnJlbnRSZXN1bHQpLnNvbWUoKGtleSkgPT4ge1xuICAgICAgICBjb25zdCB0eXBlZEtleSA9IGtleTtcbiAgICAgICAgY29uc3QgY2hhbmdlZCA9IHRoaXMuI2N1cnJlbnRSZXN1bHRbdHlwZWRLZXldICE9PSBwcmV2UmVzdWx0W3R5cGVkS2V5XTtcbiAgICAgICAgcmV0dXJuIGNoYW5nZWQgJiYgaW5jbHVkZWRQcm9wcy5oYXModHlwZWRLZXkpO1xuICAgICAgfSk7XG4gICAgfTtcbiAgICB0aGlzLiNub3RpZnkoeyBsaXN0ZW5lcnM6IHNob3VsZE5vdGlmeUxpc3RlbmVycygpIH0pO1xuICB9XG4gICN1cGRhdGVRdWVyeSgpIHtcbiAgICBjb25zdCBxdWVyeSA9IHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCkuYnVpbGQodGhpcy4jY2xpZW50LCB0aGlzLm9wdGlvbnMpO1xuICAgIGlmIChxdWVyeSA9PT0gdGhpcy4jY3VycmVudFF1ZXJ5KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHByZXZRdWVyeSA9IHRoaXMuI2N1cnJlbnRRdWVyeTtcbiAgICB0aGlzLiNjdXJyZW50UXVlcnkgPSBxdWVyeTtcbiAgICB0aGlzLiNjdXJyZW50UXVlcnlJbml0aWFsU3RhdGUgPSBxdWVyeS5zdGF0ZTtcbiAgICBpZiAodGhpcy5oYXNMaXN0ZW5lcnMoKSkge1xuICAgICAgcHJldlF1ZXJ5Py5yZW1vdmVPYnNlcnZlcih0aGlzKTtcbiAgICAgIHF1ZXJ5LmFkZE9ic2VydmVyKHRoaXMpO1xuICAgIH1cbiAgfVxuICBvblF1ZXJ5VXBkYXRlKCkge1xuICAgIHRoaXMudXBkYXRlUmVzdWx0KCk7XG4gICAgaWYgKHRoaXMuaGFzTGlzdGVuZXJzKCkpIHtcbiAgICAgIHRoaXMuI3VwZGF0ZVRpbWVycygpO1xuICAgIH1cbiAgfVxuICAjbm90aWZ5KG5vdGlmeU9wdGlvbnMpIHtcbiAgICBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcbiAgICAgIGlmIChub3RpZnlPcHRpb25zLmxpc3RlbmVycykge1xuICAgICAgICB0aGlzLmxpc3RlbmVycy5mb3JFYWNoKChsaXN0ZW5lcikgPT4ge1xuICAgICAgICAgIGxpc3RlbmVyKHRoaXMuI2N1cnJlbnRSZXN1bHQpO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCkubm90aWZ5KHtcbiAgICAgICAgcXVlcnk6IHRoaXMuI2N1cnJlbnRRdWVyeSxcbiAgICAgICAgdHlwZTogXCJvYnNlcnZlclJlc3VsdHNVcGRhdGVkXCJcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG59O1xuZnVuY3Rpb24gc2hvdWxkTG9hZE9uTW91bnQocXVlcnksIG9wdGlvbnMpIHtcbiAgcmV0dXJuIHJlc29sdmVRdWVyeUJvb2xlYW4ob3B0aW9ucy5lbmFibGVkLCBxdWVyeSkgIT09IGZhbHNlICYmIHF1ZXJ5LnN0YXRlLmRhdGEgPT09IHZvaWQgMCAmJiAhKHF1ZXJ5LnN0YXRlLnN0YXR1cyA9PT0gXCJlcnJvclwiICYmIHJlc29sdmVRdWVyeUJvb2xlYW4ob3B0aW9ucy5yZXRyeU9uTW91bnQsIHF1ZXJ5KSA9PT0gZmFsc2UpO1xufVxuZnVuY3Rpb24gc2hvdWxkRmV0Y2hPbk1vdW50KHF1ZXJ5LCBvcHRpb25zKSB7XG4gIHJldHVybiBzaG91bGRMb2FkT25Nb3VudChxdWVyeSwgb3B0aW9ucykgfHwgcXVlcnkuc3RhdGUuZGF0YSAhPT0gdm9pZCAwICYmIHNob3VsZEZldGNoT24ocXVlcnksIG9wdGlvbnMsIG9wdGlvbnMucmVmZXRjaE9uTW91bnQpO1xufVxuZnVuY3Rpb24gc2hvdWxkRmV0Y2hPbihxdWVyeSwgb3B0aW9ucywgZmllbGQpIHtcbiAgaWYgKHJlc29sdmVRdWVyeUJvb2xlYW4ob3B0aW9ucy5lbmFibGVkLCBxdWVyeSkgIT09IGZhbHNlICYmIHJlc29sdmVTdGFsZVRpbWUob3B0aW9ucy5zdGFsZVRpbWUsIHF1ZXJ5KSAhPT0gXCJzdGF0aWNcIikge1xuICAgIGNvbnN0IHZhbHVlID0gdHlwZW9mIGZpZWxkID09PSBcImZ1bmN0aW9uXCIgPyBmaWVsZChxdWVyeSkgOiBmaWVsZDtcbiAgICByZXR1cm4gdmFsdWUgPT09IFwiYWx3YXlzXCIgfHwgdmFsdWUgIT09IGZhbHNlICYmIGlzU3RhbGUocXVlcnksIG9wdGlvbnMpO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIHNob3VsZEZldGNoT3B0aW9uYWxseShxdWVyeSwgcHJldlF1ZXJ5LCBvcHRpb25zLCBwcmV2T3B0aW9ucykge1xuICByZXR1cm4gKHF1ZXJ5ICE9PSBwcmV2UXVlcnkgfHwgcmVzb2x2ZVF1ZXJ5Qm9vbGVhbihwcmV2T3B0aW9ucy5lbmFibGVkLCBxdWVyeSkgPT09IGZhbHNlKSAmJiAoIW9wdGlvbnMuc3VzcGVuc2UgfHwgcXVlcnkuc3RhdGUuc3RhdHVzICE9PSBcImVycm9yXCIpICYmIGlzU3RhbGUocXVlcnksIG9wdGlvbnMpO1xufVxuZnVuY3Rpb24gaXNTdGFsZShxdWVyeSwgb3B0aW9ucykge1xuICByZXR1cm4gcmVzb2x2ZVF1ZXJ5Qm9vbGVhbihvcHRpb25zLmVuYWJsZWQsIHF1ZXJ5KSAhPT0gZmFsc2UgJiYgcXVlcnkuaXNTdGFsZUJ5VGltZShyZXNvbHZlU3RhbGVUaW1lKG9wdGlvbnMuc3RhbGVUaW1lLCBxdWVyeSkpO1xufVxuZnVuY3Rpb24gc2hvdWxkQXNzaWduT2JzZXJ2ZXJDdXJyZW50UHJvcGVydGllcyhvYnNlcnZlciwgb3B0aW1pc3RpY1Jlc3VsdCkge1xuICBpZiAoIXNoYWxsb3dFcXVhbE9iamVjdHMob2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpLCBvcHRpbWlzdGljUmVzdWx0KSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbmV4cG9ydCB7XG4gIFF1ZXJ5T2JzZXJ2ZXJcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1xdWVyeU9ic2VydmVyLmpzLm1hcCIsIi8vIHNyYy9pbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIudHNcbmltcG9ydCB7IFF1ZXJ5T2JzZXJ2ZXIgfSBmcm9tIFwiLi9xdWVyeU9ic2VydmVyLmpzXCI7XG5pbXBvcnQgeyBoYXNOZXh0UGFnZSwgaGFzUHJldmlvdXNQYWdlIH0gZnJvbSBcIi4vaW5maW5pdGVRdWVyeUJlaGF2aW9yLmpzXCI7XG52YXIgSW5maW5pdGVRdWVyeU9ic2VydmVyID0gY2xhc3MgZXh0ZW5kcyBRdWVyeU9ic2VydmVyIHtcbiAgY29uc3RydWN0b3IoY2xpZW50LCBvcHRpb25zKSB7XG4gICAgc3VwZXIoY2xpZW50LCBvcHRpb25zKTtcbiAgfVxuICBiaW5kTWV0aG9kcygpIHtcbiAgICBzdXBlci5iaW5kTWV0aG9kcygpO1xuICAgIHRoaXMuZmV0Y2hOZXh0UGFnZSA9IHRoaXMuZmV0Y2hOZXh0UGFnZS5iaW5kKHRoaXMpO1xuICAgIHRoaXMuZmV0Y2hQcmV2aW91c1BhZ2UgPSB0aGlzLmZldGNoUHJldmlvdXNQYWdlLmJpbmQodGhpcyk7XG4gIH1cbiAgc2V0T3B0aW9ucyhvcHRpb25zKSB7XG4gICAgb3B0aW9ucy5fdHlwZSA9IFwiaW5maW5pdGVcIjtcbiAgICBzdXBlci5zZXRPcHRpb25zKG9wdGlvbnMpO1xuICB9XG4gIGdldE9wdGltaXN0aWNSZXN1bHQob3B0aW9ucykge1xuICAgIG9wdGlvbnMuX3R5cGUgPSBcImluZmluaXRlXCI7XG4gICAgcmV0dXJuIHN1cGVyLmdldE9wdGltaXN0aWNSZXN1bHQob3B0aW9ucyk7XG4gIH1cbiAgZmV0Y2hOZXh0UGFnZShvcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMuZmV0Y2goe1xuICAgICAgLi4ub3B0aW9ucyxcbiAgICAgIG1ldGE6IHtcbiAgICAgICAgZmV0Y2hNb3JlOiB7IGRpcmVjdGlvbjogXCJmb3J3YXJkXCIgfVxuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIGZldGNoUHJldmlvdXNQYWdlKG9wdGlvbnMpIHtcbiAgICByZXR1cm4gdGhpcy5mZXRjaCh7XG4gICAgICAuLi5vcHRpb25zLFxuICAgICAgbWV0YToge1xuICAgICAgICBmZXRjaE1vcmU6IHsgZGlyZWN0aW9uOiBcImJhY2t3YXJkXCIgfVxuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIGNyZWF0ZVJlc3VsdChxdWVyeSwgb3B0aW9ucykge1xuICAgIGNvbnN0IHsgc3RhdGUgfSA9IHF1ZXJ5O1xuICAgIGNvbnN0IHBhcmVudFJlc3VsdCA9IHN1cGVyLmNyZWF0ZVJlc3VsdChxdWVyeSwgb3B0aW9ucyk7XG4gICAgY29uc3QgeyBpc0ZldGNoaW5nLCBpc1JlZmV0Y2hpbmcsIGlzRXJyb3IsIGlzUmVmZXRjaEVycm9yIH0gPSBwYXJlbnRSZXN1bHQ7XG4gICAgY29uc3QgZmV0Y2hEaXJlY3Rpb24gPSBzdGF0ZS5mZXRjaE1ldGE/LmZldGNoTW9yZT8uZGlyZWN0aW9uO1xuICAgIGNvbnN0IGlzRmV0Y2hOZXh0UGFnZUVycm9yID0gaXNFcnJvciAmJiBmZXRjaERpcmVjdGlvbiA9PT0gXCJmb3J3YXJkXCI7XG4gICAgY29uc3QgaXNGZXRjaGluZ05leHRQYWdlID0gaXNGZXRjaGluZyAmJiBmZXRjaERpcmVjdGlvbiA9PT0gXCJmb3J3YXJkXCI7XG4gICAgY29uc3QgaXNGZXRjaFByZXZpb3VzUGFnZUVycm9yID0gaXNFcnJvciAmJiBmZXRjaERpcmVjdGlvbiA9PT0gXCJiYWNrd2FyZFwiO1xuICAgIGNvbnN0IGlzRmV0Y2hpbmdQcmV2aW91c1BhZ2UgPSBpc0ZldGNoaW5nICYmIGZldGNoRGlyZWN0aW9uID09PSBcImJhY2t3YXJkXCI7XG4gICAgY29uc3QgcmVzdWx0ID0ge1xuICAgICAgLi4ucGFyZW50UmVzdWx0LFxuICAgICAgZmV0Y2hOZXh0UGFnZTogdGhpcy5mZXRjaE5leHRQYWdlLFxuICAgICAgZmV0Y2hQcmV2aW91c1BhZ2U6IHRoaXMuZmV0Y2hQcmV2aW91c1BhZ2UsXG4gICAgICBoYXNOZXh0UGFnZTogaGFzTmV4dFBhZ2Uob3B0aW9ucywgc3RhdGUuZGF0YSksXG4gICAgICBoYXNQcmV2aW91c1BhZ2U6IGhhc1ByZXZpb3VzUGFnZShvcHRpb25zLCBzdGF0ZS5kYXRhKSxcbiAgICAgIGlzRmV0Y2hOZXh0UGFnZUVycm9yLFxuICAgICAgaXNGZXRjaGluZ05leHRQYWdlLFxuICAgICAgaXNGZXRjaFByZXZpb3VzUGFnZUVycm9yLFxuICAgICAgaXNGZXRjaGluZ1ByZXZpb3VzUGFnZSxcbiAgICAgIGlzUmVmZXRjaEVycm9yOiBpc1JlZmV0Y2hFcnJvciAmJiAhaXNGZXRjaE5leHRQYWdlRXJyb3IgJiYgIWlzRmV0Y2hQcmV2aW91c1BhZ2VFcnJvcixcbiAgICAgIGlzUmVmZXRjaGluZzogaXNSZWZldGNoaW5nICYmICFpc0ZldGNoaW5nTmV4dFBhZ2UgJiYgIWlzRmV0Y2hpbmdQcmV2aW91c1BhZ2VcbiAgICB9O1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cbn07XG5leHBvcnQge1xuICBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXJcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIuanMubWFwIiwiLy8gc3JjL211dGF0aW9uLnRzXG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIi4vbm90aWZ5TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgUmVtb3ZhYmxlIH0gZnJvbSBcIi4vcmVtb3ZhYmxlLmpzXCI7XG5pbXBvcnQgeyBjcmVhdGVSZXRyeWVyIH0gZnJvbSBcIi4vcmV0cnllci5qc1wiO1xudmFyIE11dGF0aW9uID0gY2xhc3MgZXh0ZW5kcyBSZW1vdmFibGUge1xuICAjY2xpZW50O1xuICAjb2JzZXJ2ZXJzO1xuICAjbXV0YXRpb25DYWNoZTtcbiAgI3JldHJ5ZXI7XG4gIGNvbnN0cnVjdG9yKGNvbmZpZykge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy4jY2xpZW50ID0gY29uZmlnLmNsaWVudDtcbiAgICB0aGlzLm11dGF0aW9uSWQgPSBjb25maWcubXV0YXRpb25JZDtcbiAgICB0aGlzLiNtdXRhdGlvbkNhY2hlID0gY29uZmlnLm11dGF0aW9uQ2FjaGU7XG4gICAgdGhpcy4jb2JzZXJ2ZXJzID0gW107XG4gICAgdGhpcy5zdGF0ZSA9IGNvbmZpZy5zdGF0ZSB8fCBnZXREZWZhdWx0U3RhdGUoKTtcbiAgICB0aGlzLnNldE9wdGlvbnMoY29uZmlnLm9wdGlvbnMpO1xuICAgIHRoaXMuc2NoZWR1bGVHYygpO1xuICB9XG4gIHNldE9wdGlvbnMob3B0aW9ucykge1xuICAgIHRoaXMub3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgdGhpcy51cGRhdGVHY1RpbWUodGhpcy5vcHRpb25zLmdjVGltZSk7XG4gIH1cbiAgZ2V0IG1ldGEoKSB7XG4gICAgcmV0dXJuIHRoaXMub3B0aW9ucy5tZXRhO1xuICB9XG4gIGFkZE9ic2VydmVyKG9ic2VydmVyKSB7XG4gICAgaWYgKCF0aGlzLiNvYnNlcnZlcnMuaW5jbHVkZXMob2JzZXJ2ZXIpKSB7XG4gICAgICB0aGlzLiNvYnNlcnZlcnMucHVzaChvYnNlcnZlcik7XG4gICAgICB0aGlzLmNsZWFyR2NUaW1lb3V0KCk7XG4gICAgICB0aGlzLiNtdXRhdGlvbkNhY2hlLm5vdGlmeSh7XG4gICAgICAgIHR5cGU6IFwib2JzZXJ2ZXJBZGRlZFwiLFxuICAgICAgICBtdXRhdGlvbjogdGhpcyxcbiAgICAgICAgb2JzZXJ2ZXJcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICByZW1vdmVPYnNlcnZlcihvYnNlcnZlcikge1xuICAgIHRoaXMuI29ic2VydmVycyA9IHRoaXMuI29ic2VydmVycy5maWx0ZXIoKHgpID0+IHggIT09IG9ic2VydmVyKTtcbiAgICB0aGlzLnNjaGVkdWxlR2MoKTtcbiAgICB0aGlzLiNtdXRhdGlvbkNhY2hlLm5vdGlmeSh7XG4gICAgICB0eXBlOiBcIm9ic2VydmVyUmVtb3ZlZFwiLFxuICAgICAgbXV0YXRpb246IHRoaXMsXG4gICAgICBvYnNlcnZlclxuICAgIH0pO1xuICB9XG4gIG9wdGlvbmFsUmVtb3ZlKCkge1xuICAgIGlmICghdGhpcy4jb2JzZXJ2ZXJzLmxlbmd0aCkge1xuICAgICAgaWYgKHRoaXMuc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIikge1xuICAgICAgICB0aGlzLnNjaGVkdWxlR2MoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuI211dGF0aW9uQ2FjaGUucmVtb3ZlKHRoaXMpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBjb250aW51ZSgpIHtcbiAgICByZXR1cm4gdGhpcy4jcmV0cnllcj8uY29udGludWUoKSA/PyAvLyBjb250aW51aW5nIGEgbXV0YXRpb24gYXNzdW1lcyB0aGF0IHZhcmlhYmxlcyBhcmUgc2V0LCBtdXRhdGlvbiBtdXN0IGhhdmUgYmVlbiBkZWh5ZHJhdGVkIGJlZm9yZVxuICAgIHRoaXMuZXhlY3V0ZSh0aGlzLnN0YXRlLnZhcmlhYmxlcyk7XG4gIH1cbiAgYXN5bmMgZXhlY3V0ZSh2YXJpYWJsZXMpIHtcbiAgICBjb25zdCBvbkNvbnRpbnVlID0gKCkgPT4ge1xuICAgICAgdGhpcy4jZGlzcGF0Y2goeyB0eXBlOiBcImNvbnRpbnVlXCIgfSk7XG4gICAgfTtcbiAgICBjb25zdCBtdXRhdGlvbkZuQ29udGV4dCA9IHtcbiAgICAgIGNsaWVudDogdGhpcy4jY2xpZW50LFxuICAgICAgbWV0YTogdGhpcy5vcHRpb25zLm1ldGEsXG4gICAgICBtdXRhdGlvbktleTogdGhpcy5vcHRpb25zLm11dGF0aW9uS2V5XG4gICAgfTtcbiAgICB0aGlzLiNyZXRyeWVyID0gY3JlYXRlUmV0cnllcih7XG4gICAgICBmbjogKCkgPT4ge1xuICAgICAgICBpZiAoIXRoaXMub3B0aW9ucy5tdXRhdGlvbkZuKSB7XG4gICAgICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBFcnJvcihcIk5vIG11dGF0aW9uRm4gZm91bmRcIikpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLm9wdGlvbnMubXV0YXRpb25Gbih2YXJpYWJsZXMsIG11dGF0aW9uRm5Db250ZXh0KTtcbiAgICAgIH0sXG4gICAgICBvbkZhaWw6IChmYWlsdXJlQ291bnQsIGVycm9yKSA9PiB7XG4gICAgICAgIHRoaXMuI2Rpc3BhdGNoKHsgdHlwZTogXCJmYWlsZWRcIiwgZmFpbHVyZUNvdW50LCBlcnJvciB9KTtcbiAgICAgIH0sXG4gICAgICBvblBhdXNlOiAoKSA9PiB7XG4gICAgICAgIHRoaXMuI2Rpc3BhdGNoKHsgdHlwZTogXCJwYXVzZVwiIH0pO1xuICAgICAgfSxcbiAgICAgIG9uQ29udGludWUsXG4gICAgICByZXRyeTogdGhpcy5vcHRpb25zLnJldHJ5ID8/IDAsXG4gICAgICByZXRyeURlbGF5OiB0aGlzLm9wdGlvbnMucmV0cnlEZWxheSxcbiAgICAgIG5ldHdvcmtNb2RlOiB0aGlzLm9wdGlvbnMubmV0d29ya01vZGUsXG4gICAgICBjYW5SdW46ICgpID0+IHRoaXMuI211dGF0aW9uQ2FjaGUuY2FuUnVuKHRoaXMpXG4gICAgfSk7XG4gICAgY29uc3QgcmVzdG9yZWQgPSB0aGlzLnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCI7XG4gICAgY29uc3QgaXNQYXVzZWQgPSAhdGhpcy4jcmV0cnllci5jYW5TdGFydCgpO1xuICAgIHRyeSB7XG4gICAgICBpZiAocmVzdG9yZWQpIHtcbiAgICAgICAgb25Db250aW51ZSgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy4jZGlzcGF0Y2goeyB0eXBlOiBcInBlbmRpbmdcIiwgdmFyaWFibGVzLCBpc1BhdXNlZCB9KTtcbiAgICAgICAgaWYgKHRoaXMuI211dGF0aW9uQ2FjaGUuY29uZmlnLm9uTXV0YXRlKSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy4jbXV0YXRpb25DYWNoZS5jb25maWcub25NdXRhdGUoXG4gICAgICAgICAgICB2YXJpYWJsZXMsXG4gICAgICAgICAgICB0aGlzLFxuICAgICAgICAgICAgbXV0YXRpb25GbkNvbnRleHRcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGNvbnRleHQgPSBhd2FpdCB0aGlzLm9wdGlvbnMub25NdXRhdGU/LihcbiAgICAgICAgICB2YXJpYWJsZXMsXG4gICAgICAgICAgbXV0YXRpb25GbkNvbnRleHRcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKGNvbnRleHQgIT09IHRoaXMuc3RhdGUuY29udGV4dCkge1xuICAgICAgICAgIHRoaXMuI2Rpc3BhdGNoKHtcbiAgICAgICAgICAgIHR5cGU6IFwicGVuZGluZ1wiLFxuICAgICAgICAgICAgY29udGV4dCxcbiAgICAgICAgICAgIHZhcmlhYmxlcyxcbiAgICAgICAgICAgIGlzUGF1c2VkXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCB0aGlzLiNyZXRyeWVyLnN0YXJ0KCk7XG4gICAgICBhd2FpdCB0aGlzLiNtdXRhdGlvbkNhY2hlLmNvbmZpZy5vblN1Y2Nlc3M/LihcbiAgICAgICAgZGF0YSxcbiAgICAgICAgdmFyaWFibGVzLFxuICAgICAgICB0aGlzLnN0YXRlLmNvbnRleHQsXG4gICAgICAgIHRoaXMsXG4gICAgICAgIG11dGF0aW9uRm5Db250ZXh0XG4gICAgICApO1xuICAgICAgYXdhaXQgdGhpcy5vcHRpb25zLm9uU3VjY2Vzcz8uKFxuICAgICAgICBkYXRhLFxuICAgICAgICB2YXJpYWJsZXMsXG4gICAgICAgIHRoaXMuc3RhdGUuY29udGV4dCxcbiAgICAgICAgbXV0YXRpb25GbkNvbnRleHRcbiAgICAgICk7XG4gICAgICBhd2FpdCB0aGlzLiNtdXRhdGlvbkNhY2hlLmNvbmZpZy5vblNldHRsZWQ/LihcbiAgICAgICAgZGF0YSxcbiAgICAgICAgbnVsbCxcbiAgICAgICAgdGhpcy5zdGF0ZS52YXJpYWJsZXMsXG4gICAgICAgIHRoaXMuc3RhdGUuY29udGV4dCxcbiAgICAgICAgdGhpcyxcbiAgICAgICAgbXV0YXRpb25GbkNvbnRleHRcbiAgICAgICk7XG4gICAgICBhd2FpdCB0aGlzLm9wdGlvbnMub25TZXR0bGVkPy4oXG4gICAgICAgIGRhdGEsXG4gICAgICAgIG51bGwsXG4gICAgICAgIHZhcmlhYmxlcyxcbiAgICAgICAgdGhpcy5zdGF0ZS5jb250ZXh0LFxuICAgICAgICBtdXRhdGlvbkZuQ29udGV4dFxuICAgICAgKTtcbiAgICAgIHRoaXMuI2Rpc3BhdGNoKHsgdHlwZTogXCJzdWNjZXNzXCIsIGRhdGEgfSk7XG4gICAgICByZXR1cm4gZGF0YTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgdGhpcy4jbXV0YXRpb25DYWNoZS5jb25maWcub25FcnJvcj8uKFxuICAgICAgICAgIGVycm9yLFxuICAgICAgICAgIHZhcmlhYmxlcyxcbiAgICAgICAgICB0aGlzLnN0YXRlLmNvbnRleHQsXG4gICAgICAgICAgdGhpcyxcbiAgICAgICAgICBtdXRhdGlvbkZuQ29udGV4dFxuICAgICAgICApO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICB2b2lkIFByb21pc2UucmVqZWN0KGUpO1xuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgdGhpcy5vcHRpb25zLm9uRXJyb3I/LihcbiAgICAgICAgICBlcnJvcixcbiAgICAgICAgICB2YXJpYWJsZXMsXG4gICAgICAgICAgdGhpcy5zdGF0ZS5jb250ZXh0LFxuICAgICAgICAgIG11dGF0aW9uRm5Db250ZXh0XG4gICAgICAgICk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHZvaWQgUHJvbWlzZS5yZWplY3QoZSk7XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCB0aGlzLiNtdXRhdGlvbkNhY2hlLmNvbmZpZy5vblNldHRsZWQ/LihcbiAgICAgICAgICB2b2lkIDAsXG4gICAgICAgICAgZXJyb3IsXG4gICAgICAgICAgdGhpcy5zdGF0ZS52YXJpYWJsZXMsXG4gICAgICAgICAgdGhpcy5zdGF0ZS5jb250ZXh0LFxuICAgICAgICAgIHRoaXMsXG4gICAgICAgICAgbXV0YXRpb25GbkNvbnRleHRcbiAgICAgICAgKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgdm9pZCBQcm9taXNlLnJlamVjdChlKTtcbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IHRoaXMub3B0aW9ucy5vblNldHRsZWQ/LihcbiAgICAgICAgICB2b2lkIDAsXG4gICAgICAgICAgZXJyb3IsXG4gICAgICAgICAgdmFyaWFibGVzLFxuICAgICAgICAgIHRoaXMuc3RhdGUuY29udGV4dCxcbiAgICAgICAgICBtdXRhdGlvbkZuQ29udGV4dFxuICAgICAgICApO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICB2b2lkIFByb21pc2UucmVqZWN0KGUpO1xuICAgICAgfVxuICAgICAgdGhpcy4jZGlzcGF0Y2goeyB0eXBlOiBcImVycm9yXCIsIGVycm9yIH0pO1xuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHRoaXMuI211dGF0aW9uQ2FjaGUucnVuTmV4dCh0aGlzKTtcbiAgICB9XG4gIH1cbiAgI2Rpc3BhdGNoKGFjdGlvbikge1xuICAgIGNvbnN0IHJlZHVjZXIgPSAoc3RhdGUpID0+IHtcbiAgICAgIHN3aXRjaCAoYWN0aW9uLnR5cGUpIHtcbiAgICAgICAgY2FzZSBcImZhaWxlZFwiOlxuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgIGZhaWx1cmVDb3VudDogYWN0aW9uLmZhaWx1cmVDb3VudCxcbiAgICAgICAgICAgIGZhaWx1cmVSZWFzb246IGFjdGlvbi5lcnJvclxuICAgICAgICAgIH07XG4gICAgICAgIGNhc2UgXCJwYXVzZVwiOlxuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgIGlzUGF1c2VkOiB0cnVlXG4gICAgICAgICAgfTtcbiAgICAgICAgY2FzZSBcImNvbnRpbnVlXCI6XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgaXNQYXVzZWQ6IGZhbHNlXG4gICAgICAgICAgfTtcbiAgICAgICAgY2FzZSBcInBlbmRpbmdcIjpcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgICAgICBjb250ZXh0OiBhY3Rpb24uY29udGV4dCxcbiAgICAgICAgICAgIGRhdGE6IHZvaWQgMCxcbiAgICAgICAgICAgIGZhaWx1cmVDb3VudDogMCxcbiAgICAgICAgICAgIGZhaWx1cmVSZWFzb246IG51bGwsXG4gICAgICAgICAgICBlcnJvcjogbnVsbCxcbiAgICAgICAgICAgIGlzUGF1c2VkOiBhY3Rpb24uaXNQYXVzZWQsXG4gICAgICAgICAgICBzdGF0dXM6IFwicGVuZGluZ1wiLFxuICAgICAgICAgICAgdmFyaWFibGVzOiBhY3Rpb24udmFyaWFibGVzLFxuICAgICAgICAgICAgc3VibWl0dGVkQXQ6IERhdGUubm93KClcbiAgICAgICAgICB9O1xuICAgICAgICBjYXNlIFwic3VjY2Vzc1wiOlxuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgIGRhdGE6IGFjdGlvbi5kYXRhLFxuICAgICAgICAgICAgZmFpbHVyZUNvdW50OiAwLFxuICAgICAgICAgICAgZmFpbHVyZVJlYXNvbjogbnVsbCxcbiAgICAgICAgICAgIGVycm9yOiBudWxsLFxuICAgICAgICAgICAgc3RhdHVzOiBcInN1Y2Nlc3NcIixcbiAgICAgICAgICAgIGlzUGF1c2VkOiBmYWxzZVxuICAgICAgICAgIH07XG4gICAgICAgIGNhc2UgXCJlcnJvclwiOlxuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgIGRhdGE6IHZvaWQgMCxcbiAgICAgICAgICAgIGVycm9yOiBhY3Rpb24uZXJyb3IsXG4gICAgICAgICAgICBmYWlsdXJlQ291bnQ6IHN0YXRlLmZhaWx1cmVDb3VudCArIDEsXG4gICAgICAgICAgICBmYWlsdXJlUmVhc29uOiBhY3Rpb24uZXJyb3IsXG4gICAgICAgICAgICBpc1BhdXNlZDogZmFsc2UsXG4gICAgICAgICAgICBzdGF0dXM6IFwiZXJyb3JcIlxuICAgICAgICAgIH07XG4gICAgICB9XG4gICAgfTtcbiAgICB0aGlzLnN0YXRlID0gcmVkdWNlcih0aGlzLnN0YXRlKTtcbiAgICBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcbiAgICAgIHRoaXMuI29ic2VydmVycy5mb3JFYWNoKChvYnNlcnZlcikgPT4ge1xuICAgICAgICBvYnNlcnZlci5vbk11dGF0aW9uVXBkYXRlKGFjdGlvbik7XG4gICAgICB9KTtcbiAgICAgIHRoaXMuI211dGF0aW9uQ2FjaGUubm90aWZ5KHtcbiAgICAgICAgbXV0YXRpb246IHRoaXMsXG4gICAgICAgIHR5cGU6IFwidXBkYXRlZFwiLFxuICAgICAgICBhY3Rpb25cbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG59O1xuZnVuY3Rpb24gZ2V0RGVmYXVsdFN0YXRlKCkge1xuICByZXR1cm4ge1xuICAgIGNvbnRleHQ6IHZvaWQgMCxcbiAgICBkYXRhOiB2b2lkIDAsXG4gICAgZXJyb3I6IG51bGwsXG4gICAgZmFpbHVyZUNvdW50OiAwLFxuICAgIGZhaWx1cmVSZWFzb246IG51bGwsXG4gICAgaXNQYXVzZWQ6IGZhbHNlLFxuICAgIHN0YXR1czogXCJpZGxlXCIsXG4gICAgdmFyaWFibGVzOiB2b2lkIDAsXG4gICAgc3VibWl0dGVkQXQ6IDBcbiAgfTtcbn1cbmV4cG9ydCB7XG4gIE11dGF0aW9uLFxuICBnZXREZWZhdWx0U3RhdGVcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1tdXRhdGlvbi5qcy5tYXAiLCIvLyBzcmMvbXV0YXRpb25DYWNoZS50c1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gXCIuL25vdGlmeU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IE11dGF0aW9uIH0gZnJvbSBcIi4vbXV0YXRpb24uanNcIjtcbmltcG9ydCB7IG1hdGNoTXV0YXRpb24sIG5vb3AgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG52YXIgTXV0YXRpb25DYWNoZSA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcbiAgY29uc3RydWN0b3IoY29uZmlnID0ge30pIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuY29uZmlnID0gY29uZmlnO1xuICAgIHRoaXMuI211dGF0aW9ucyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gICAgdGhpcy4jc2NvcGVzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgICB0aGlzLiNtdXRhdGlvbklkID0gMDtcbiAgfVxuICAjbXV0YXRpb25zO1xuICAjc2NvcGVzO1xuICAjbXV0YXRpb25JZDtcbiAgYnVpbGQoY2xpZW50LCBvcHRpb25zLCBzdGF0ZSkge1xuICAgIGNvbnN0IG11dGF0aW9uID0gbmV3IE11dGF0aW9uKHtcbiAgICAgIGNsaWVudCxcbiAgICAgIG11dGF0aW9uQ2FjaGU6IHRoaXMsXG4gICAgICBtdXRhdGlvbklkOiArK3RoaXMuI211dGF0aW9uSWQsXG4gICAgICBvcHRpb25zOiBjbGllbnQuZGVmYXVsdE11dGF0aW9uT3B0aW9ucyhvcHRpb25zKSxcbiAgICAgIHN0YXRlXG4gICAgfSk7XG4gICAgdGhpcy5hZGQobXV0YXRpb24pO1xuICAgIHJldHVybiBtdXRhdGlvbjtcbiAgfVxuICBhZGQobXV0YXRpb24pIHtcbiAgICB0aGlzLiNtdXRhdGlvbnMuYWRkKG11dGF0aW9uKTtcbiAgICBjb25zdCBzY29wZSA9IHNjb3BlRm9yKG11dGF0aW9uKTtcbiAgICBpZiAodHlwZW9mIHNjb3BlID09PSBcInN0cmluZ1wiKSB7XG4gICAgICBjb25zdCBzY29wZWRNdXRhdGlvbnMgPSB0aGlzLiNzY29wZXMuZ2V0KHNjb3BlKTtcbiAgICAgIGlmIChzY29wZWRNdXRhdGlvbnMpIHtcbiAgICAgICAgc2NvcGVkTXV0YXRpb25zLnB1c2gobXV0YXRpb24pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy4jc2NvcGVzLnNldChzY29wZSwgW211dGF0aW9uXSk7XG4gICAgICB9XG4gICAgfVxuICAgIHRoaXMubm90aWZ5KHsgdHlwZTogXCJhZGRlZFwiLCBtdXRhdGlvbiB9KTtcbiAgfVxuICByZW1vdmUobXV0YXRpb24pIHtcbiAgICBpZiAodGhpcy4jbXV0YXRpb25zLmRlbGV0ZShtdXRhdGlvbikpIHtcbiAgICAgIGNvbnN0IHNjb3BlID0gc2NvcGVGb3IobXV0YXRpb24pO1xuICAgICAgaWYgKHR5cGVvZiBzY29wZSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICBjb25zdCBzY29wZWRNdXRhdGlvbnMgPSB0aGlzLiNzY29wZXMuZ2V0KHNjb3BlKTtcbiAgICAgICAgaWYgKHNjb3BlZE11dGF0aW9ucykge1xuICAgICAgICAgIGlmIChzY29wZWRNdXRhdGlvbnMubGVuZ3RoID4gMSkge1xuICAgICAgICAgICAgY29uc3QgaW5kZXggPSBzY29wZWRNdXRhdGlvbnMuaW5kZXhPZihtdXRhdGlvbik7XG4gICAgICAgICAgICBpZiAoaW5kZXggIT09IC0xKSB7XG4gICAgICAgICAgICAgIHNjb3BlZE11dGF0aW9ucy5zcGxpY2UoaW5kZXgsIDEpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSBpZiAoc2NvcGVkTXV0YXRpb25zWzBdID09PSBtdXRhdGlvbikge1xuICAgICAgICAgICAgdGhpcy4jc2NvcGVzLmRlbGV0ZShzY29wZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIHRoaXMubm90aWZ5KHsgdHlwZTogXCJyZW1vdmVkXCIsIG11dGF0aW9uIH0pO1xuICB9XG4gIGNhblJ1bihtdXRhdGlvbikge1xuICAgIGNvbnN0IHNjb3BlID0gc2NvcGVGb3IobXV0YXRpb24pO1xuICAgIGlmICh0eXBlb2Ygc2NvcGUgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIGNvbnN0IG11dGF0aW9uc1dpdGhTYW1lU2NvcGUgPSB0aGlzLiNzY29wZXMuZ2V0KHNjb3BlKTtcbiAgICAgIGNvbnN0IGZpcnN0UGVuZGluZ011dGF0aW9uID0gbXV0YXRpb25zV2l0aFNhbWVTY29wZT8uZmluZChcbiAgICAgICAgKG0pID0+IG0uc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIlxuICAgICAgKTtcbiAgICAgIHJldHVybiAhZmlyc3RQZW5kaW5nTXV0YXRpb24gfHwgZmlyc3RQZW5kaW5nTXV0YXRpb24gPT09IG11dGF0aW9uO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gIH1cbiAgcnVuTmV4dChtdXRhdGlvbikge1xuICAgIGNvbnN0IHNjb3BlID0gc2NvcGVGb3IobXV0YXRpb24pO1xuICAgIGlmICh0eXBlb2Ygc2NvcGUgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIGNvbnN0IGZvdW5kTXV0YXRpb24gPSB0aGlzLiNzY29wZXMuZ2V0KHNjb3BlKT8uZmluZCgobSkgPT4gbSAhPT0gbXV0YXRpb24gJiYgbS5zdGF0ZS5pc1BhdXNlZCk7XG4gICAgICByZXR1cm4gZm91bmRNdXRhdGlvbj8uY29udGludWUoKSA/PyBQcm9taXNlLnJlc29sdmUoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgIH1cbiAgfVxuICBjbGVhcigpIHtcbiAgICBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcbiAgICAgIHRoaXMuI211dGF0aW9ucy5mb3JFYWNoKChtdXRhdGlvbikgPT4ge1xuICAgICAgICB0aGlzLm5vdGlmeSh7IHR5cGU6IFwicmVtb3ZlZFwiLCBtdXRhdGlvbiB9KTtcbiAgICAgIH0pO1xuICAgICAgdGhpcy4jbXV0YXRpb25zLmNsZWFyKCk7XG4gICAgICB0aGlzLiNzY29wZXMuY2xlYXIoKTtcbiAgICB9KTtcbiAgfVxuICBnZXRBbGwoKSB7XG4gICAgcmV0dXJuIEFycmF5LmZyb20odGhpcy4jbXV0YXRpb25zKTtcbiAgfVxuICBmaW5kKGZpbHRlcnMpIHtcbiAgICBjb25zdCBkZWZhdWx0ZWRGaWx0ZXJzID0geyBleGFjdDogdHJ1ZSwgLi4uZmlsdGVycyB9O1xuICAgIHJldHVybiB0aGlzLmdldEFsbCgpLmZpbmQoXG4gICAgICAobXV0YXRpb24pID0+IG1hdGNoTXV0YXRpb24oZGVmYXVsdGVkRmlsdGVycywgbXV0YXRpb24pXG4gICAgKTtcbiAgfVxuICBmaW5kQWxsKGZpbHRlcnMgPSB7fSkge1xuICAgIHJldHVybiB0aGlzLmdldEFsbCgpLmZpbHRlcigobXV0YXRpb24pID0+IG1hdGNoTXV0YXRpb24oZmlsdGVycywgbXV0YXRpb24pKTtcbiAgfVxuICBub3RpZnkoZXZlbnQpIHtcbiAgICBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcbiAgICAgIHRoaXMubGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG4gICAgICAgIGxpc3RlbmVyKGV2ZW50KTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG4gIHJlc3VtZVBhdXNlZE11dGF0aW9ucygpIHtcbiAgICBjb25zdCBwYXVzZWRNdXRhdGlvbnMgPSB0aGlzLmdldEFsbCgpLmZpbHRlcigoeCkgPT4geC5zdGF0ZS5pc1BhdXNlZCk7XG4gICAgcmV0dXJuIG5vdGlmeU1hbmFnZXIuYmF0Y2goXG4gICAgICAoKSA9PiBQcm9taXNlLmFsbChcbiAgICAgICAgcGF1c2VkTXV0YXRpb25zLm1hcCgobXV0YXRpb24pID0+IG11dGF0aW9uLmNvbnRpbnVlKCkuY2F0Y2gobm9vcCkpXG4gICAgICApXG4gICAgKTtcbiAgfVxufTtcbmZ1bmN0aW9uIHNjb3BlRm9yKG11dGF0aW9uKSB7XG4gIHJldHVybiBtdXRhdGlvbi5vcHRpb25zLnNjb3BlPy5pZDtcbn1cbmV4cG9ydCB7XG4gIE11dGF0aW9uQ2FjaGVcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1tdXRhdGlvbkNhY2hlLmpzLm1hcCIsIi8vIHNyYy9tdXRhdGlvbk9ic2VydmVyLnRzXG5pbXBvcnQgeyBnZXREZWZhdWx0U3RhdGUgfSBmcm9tIFwiLi9tdXRhdGlvbi5qc1wiO1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gXCIuL25vdGlmeU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IFN1YnNjcmliYWJsZSB9IGZyb20gXCIuL3N1YnNjcmliYWJsZS5qc1wiO1xuaW1wb3J0IHsgaGFzaEtleSwgc2hhbGxvd0VxdWFsT2JqZWN0cyB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG52YXIgTXV0YXRpb25PYnNlcnZlciA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcbiAgI2NsaWVudDtcbiAgI2N1cnJlbnRSZXN1bHQgPSB2b2lkIDA7XG4gICNjdXJyZW50TXV0YXRpb247XG4gICNtdXRhdGVPcHRpb25zO1xuICBjb25zdHJ1Y3RvcihjbGllbnQsIG9wdGlvbnMpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuI2NsaWVudCA9IGNsaWVudDtcbiAgICB0aGlzLnNldE9wdGlvbnMob3B0aW9ucyk7XG4gICAgdGhpcy5iaW5kTWV0aG9kcygpO1xuICAgIHRoaXMuI3VwZGF0ZVJlc3VsdCgpO1xuICB9XG4gIGJpbmRNZXRob2RzKCkge1xuICAgIHRoaXMubXV0YXRlID0gdGhpcy5tdXRhdGUuYmluZCh0aGlzKTtcbiAgICB0aGlzLnJlc2V0ID0gdGhpcy5yZXNldC5iaW5kKHRoaXMpO1xuICB9XG4gIHNldE9wdGlvbnMob3B0aW9ucykge1xuICAgIGNvbnN0IHByZXZPcHRpb25zID0gdGhpcy5vcHRpb25zO1xuICAgIHRoaXMub3B0aW9ucyA9IHRoaXMuI2NsaWVudC5kZWZhdWx0TXV0YXRpb25PcHRpb25zKG9wdGlvbnMpO1xuICAgIGlmICghc2hhbGxvd0VxdWFsT2JqZWN0cyh0aGlzLm9wdGlvbnMsIHByZXZPcHRpb25zKSkge1xuICAgICAgdGhpcy4jY2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKS5ub3RpZnkoe1xuICAgICAgICB0eXBlOiBcIm9ic2VydmVyT3B0aW9uc1VwZGF0ZWRcIixcbiAgICAgICAgbXV0YXRpb246IHRoaXMuI2N1cnJlbnRNdXRhdGlvbixcbiAgICAgICAgb2JzZXJ2ZXI6IHRoaXNcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAocHJldk9wdGlvbnM/Lm11dGF0aW9uS2V5ICYmIHRoaXMub3B0aW9ucy5tdXRhdGlvbktleSAmJiBoYXNoS2V5KHByZXZPcHRpb25zLm11dGF0aW9uS2V5KSAhPT0gaGFzaEtleSh0aGlzLm9wdGlvbnMubXV0YXRpb25LZXkpKSB7XG4gICAgICB0aGlzLnJlc2V0KCk7XG4gICAgfSBlbHNlIGlmICh0aGlzLiNjdXJyZW50TXV0YXRpb24/LnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIpIHtcbiAgICAgIHRoaXMuI2N1cnJlbnRNdXRhdGlvbi5zZXRPcHRpb25zKHRoaXMub3B0aW9ucyk7XG4gICAgfVxuICB9XG4gIG9uVW5zdWJzY3JpYmUoKSB7XG4gICAgaWYgKCF0aGlzLmhhc0xpc3RlbmVycygpKSB7XG4gICAgICB0aGlzLiNjdXJyZW50TXV0YXRpb24/LnJlbW92ZU9ic2VydmVyKHRoaXMpO1xuICAgIH1cbiAgfVxuICBvbk11dGF0aW9uVXBkYXRlKGFjdGlvbikge1xuICAgIHRoaXMuI3VwZGF0ZVJlc3VsdCgpO1xuICAgIHRoaXMuI25vdGlmeShhY3Rpb24pO1xuICB9XG4gIGdldEN1cnJlbnRSZXN1bHQoKSB7XG4gICAgcmV0dXJuIHRoaXMuI2N1cnJlbnRSZXN1bHQ7XG4gIH1cbiAgcmVzZXQoKSB7XG4gICAgdGhpcy4jY3VycmVudE11dGF0aW9uPy5yZW1vdmVPYnNlcnZlcih0aGlzKTtcbiAgICB0aGlzLiNjdXJyZW50TXV0YXRpb24gPSB2b2lkIDA7XG4gICAgdGhpcy4jdXBkYXRlUmVzdWx0KCk7XG4gICAgdGhpcy4jbm90aWZ5KCk7XG4gIH1cbiAgbXV0YXRlKHZhcmlhYmxlcywgb3B0aW9ucykge1xuICAgIHRoaXMuI211dGF0ZU9wdGlvbnMgPSBvcHRpb25zO1xuICAgIHRoaXMuI2N1cnJlbnRNdXRhdGlvbj8ucmVtb3ZlT2JzZXJ2ZXIodGhpcyk7XG4gICAgdGhpcy4jY3VycmVudE11dGF0aW9uID0gdGhpcy4jY2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKS5idWlsZCh0aGlzLiNjbGllbnQsIHRoaXMub3B0aW9ucyk7XG4gICAgdGhpcy4jY3VycmVudE11dGF0aW9uLmFkZE9ic2VydmVyKHRoaXMpO1xuICAgIHJldHVybiB0aGlzLiNjdXJyZW50TXV0YXRpb24uZXhlY3V0ZSh2YXJpYWJsZXMpO1xuICB9XG4gICN1cGRhdGVSZXN1bHQoKSB7XG4gICAgY29uc3Qgc3RhdGUgPSB0aGlzLiNjdXJyZW50TXV0YXRpb24/LnN0YXRlID8/IGdldERlZmF1bHRTdGF0ZSgpO1xuICAgIHRoaXMuI2N1cnJlbnRSZXN1bHQgPSB7XG4gICAgICAuLi5zdGF0ZSxcbiAgICAgIGlzUGVuZGluZzogc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIixcbiAgICAgIGlzU3VjY2Vzczogc3RhdGUuc3RhdHVzID09PSBcInN1Y2Nlc3NcIixcbiAgICAgIGlzRXJyb3I6IHN0YXRlLnN0YXR1cyA9PT0gXCJlcnJvclwiLFxuICAgICAgaXNJZGxlOiBzdGF0ZS5zdGF0dXMgPT09IFwiaWRsZVwiLFxuICAgICAgbXV0YXRlOiB0aGlzLm11dGF0ZSxcbiAgICAgIHJlc2V0OiB0aGlzLnJlc2V0XG4gICAgfTtcbiAgfVxuICAjbm90aWZ5KGFjdGlvbikge1xuICAgIG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuICAgICAgaWYgKHRoaXMuI211dGF0ZU9wdGlvbnMgJiYgdGhpcy5oYXNMaXN0ZW5lcnMoKSkge1xuICAgICAgICBjb25zdCB2YXJpYWJsZXMgPSB0aGlzLiNjdXJyZW50UmVzdWx0LnZhcmlhYmxlcztcbiAgICAgICAgY29uc3Qgb25NdXRhdGVSZXN1bHQgPSB0aGlzLiNjdXJyZW50UmVzdWx0LmNvbnRleHQ7XG4gICAgICAgIGNvbnN0IGNvbnRleHQgPSB7XG4gICAgICAgICAgY2xpZW50OiB0aGlzLiNjbGllbnQsXG4gICAgICAgICAgbWV0YTogdGhpcy5vcHRpb25zLm1ldGEsXG4gICAgICAgICAgbXV0YXRpb25LZXk6IHRoaXMub3B0aW9ucy5tdXRhdGlvbktleVxuICAgICAgICB9O1xuICAgICAgICBpZiAoYWN0aW9uPy50eXBlID09PSBcInN1Y2Nlc3NcIikge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICB0aGlzLiNtdXRhdGVPcHRpb25zLm9uU3VjY2Vzcz8uKFxuICAgICAgICAgICAgICBhY3Rpb24uZGF0YSxcbiAgICAgICAgICAgICAgdmFyaWFibGVzLFxuICAgICAgICAgICAgICBvbk11dGF0ZVJlc3VsdCxcbiAgICAgICAgICAgICAgY29udGV4dFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICB2b2lkIFByb21pc2UucmVqZWN0KGUpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgdGhpcy4jbXV0YXRlT3B0aW9ucy5vblNldHRsZWQ/LihcbiAgICAgICAgICAgICAgYWN0aW9uLmRhdGEsXG4gICAgICAgICAgICAgIG51bGwsXG4gICAgICAgICAgICAgIHZhcmlhYmxlcyxcbiAgICAgICAgICAgICAgb25NdXRhdGVSZXN1bHQsXG4gICAgICAgICAgICAgIGNvbnRleHRcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgdm9pZCBQcm9taXNlLnJlamVjdChlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAoYWN0aW9uPy50eXBlID09PSBcImVycm9yXCIpIHtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgdGhpcy4jbXV0YXRlT3B0aW9ucy5vbkVycm9yPy4oXG4gICAgICAgICAgICAgIGFjdGlvbi5lcnJvcixcbiAgICAgICAgICAgICAgdmFyaWFibGVzLFxuICAgICAgICAgICAgICBvbk11dGF0ZVJlc3VsdCxcbiAgICAgICAgICAgICAgY29udGV4dFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICB2b2lkIFByb21pc2UucmVqZWN0KGUpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgdGhpcy4jbXV0YXRlT3B0aW9ucy5vblNldHRsZWQ/LihcbiAgICAgICAgICAgICAgdm9pZCAwLFxuICAgICAgICAgICAgICBhY3Rpb24uZXJyb3IsXG4gICAgICAgICAgICAgIHZhcmlhYmxlcyxcbiAgICAgICAgICAgICAgb25NdXRhdGVSZXN1bHQsXG4gICAgICAgICAgICAgIGNvbnRleHRcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgdm9pZCBQcm9taXNlLnJlamVjdChlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRoaXMubGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG4gICAgICAgIGxpc3RlbmVyKHRoaXMuI2N1cnJlbnRSZXN1bHQpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbn07XG5leHBvcnQge1xuICBNdXRhdGlvbk9ic2VydmVyXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bXV0YXRpb25PYnNlcnZlci5qcy5tYXAiLCIvLyBzcmMvcXVlcmllc09ic2VydmVyLnRzXG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIi4vbm90aWZ5TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgUXVlcnlPYnNlcnZlciB9IGZyb20gXCIuL3F1ZXJ5T2JzZXJ2ZXIuanNcIjtcbmltcG9ydCB7IFN1YnNjcmliYWJsZSB9IGZyb20gXCIuL3N1YnNjcmliYWJsZS5qc1wiO1xuaW1wb3J0IHsgcmVwbGFjZUVxdWFsRGVlcCwgc2hhbGxvd0VxdWFsT2JqZWN0cyB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5mdW5jdGlvbiBkaWZmZXJlbmNlKGFycmF5MSwgYXJyYXkyKSB7XG4gIGNvbnN0IGV4Y2x1ZGVTZXQgPSBuZXcgU2V0KGFycmF5Mik7XG4gIHJldHVybiBhcnJheTEuZmlsdGVyKCh4KSA9PiAhZXhjbHVkZVNldC5oYXMoeCkpO1xufVxuZnVuY3Rpb24gcmVwbGFjZUF0KGFycmF5LCBpbmRleCwgdmFsdWUpIHtcbiAgY29uc3QgY29weSA9IGFycmF5LnNsaWNlKDApO1xuICBjb3B5W2luZGV4XSA9IHZhbHVlO1xuICByZXR1cm4gY29weTtcbn1cbnZhciBRdWVyaWVzT2JzZXJ2ZXIgPSBjbGFzcyBleHRlbmRzIFN1YnNjcmliYWJsZSB7XG4gICNjbGllbnQ7XG4gICNyZXN1bHQ7XG4gICNxdWVyaWVzO1xuICAjb3B0aW9ucztcbiAgI29ic2VydmVycztcbiAgI2NvbWJpbmVkUmVzdWx0O1xuICAjbGFzdENvbWJpbmU7XG4gICNsYXN0UmVzdWx0O1xuICAjbGFzdFF1ZXJ5SGFzaGVzO1xuICAjb2JzZXJ2ZXJNYXRjaGVzID0gW107XG4gIGNvbnN0cnVjdG9yKGNsaWVudCwgcXVlcmllcywgb3B0aW9ucykge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy4jY2xpZW50ID0gY2xpZW50O1xuICAgIHRoaXMuI29wdGlvbnMgPSBvcHRpb25zO1xuICAgIHRoaXMuI3F1ZXJpZXMgPSBbXTtcbiAgICB0aGlzLiNvYnNlcnZlcnMgPSBbXTtcbiAgICB0aGlzLiNyZXN1bHQgPSBbXTtcbiAgICB0aGlzLnNldFF1ZXJpZXMocXVlcmllcyk7XG4gIH1cbiAgb25TdWJzY3JpYmUoKSB7XG4gICAgaWYgKHRoaXMubGlzdGVuZXJzLnNpemUgPT09IDEpIHtcbiAgICAgIHRoaXMuI29ic2VydmVycy5mb3JFYWNoKChvYnNlcnZlcikgPT4ge1xuICAgICAgICBvYnNlcnZlci5zdWJzY3JpYmUoKHJlc3VsdCkgPT4ge1xuICAgICAgICAgIHRoaXMuI29uVXBkYXRlKG9ic2VydmVyLCByZXN1bHQpO1xuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBvblVuc3Vic2NyaWJlKCkge1xuICAgIGlmICghdGhpcy5saXN0ZW5lcnMuc2l6ZSkge1xuICAgICAgdGhpcy5kZXN0cm95KCk7XG4gICAgfVxuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5saXN0ZW5lcnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuICAgIHRoaXMuI29ic2VydmVycy5mb3JFYWNoKChvYnNlcnZlcikgPT4ge1xuICAgICAgb2JzZXJ2ZXIuZGVzdHJveSgpO1xuICAgIH0pO1xuICB9XG4gIHNldFF1ZXJpZXMocXVlcmllcywgb3B0aW9ucykge1xuICAgIHRoaXMuI3F1ZXJpZXMgPSBxdWVyaWVzO1xuICAgIHRoaXMuI29wdGlvbnMgPSBvcHRpb25zO1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICAgIGNvbnN0IHF1ZXJ5SGFzaGVzID0gcXVlcmllcy5tYXAoXG4gICAgICAgIChxdWVyeSkgPT4gdGhpcy4jY2xpZW50LmRlZmF1bHRRdWVyeU9wdGlvbnMocXVlcnkpLnF1ZXJ5SGFzaFxuICAgICAgKTtcbiAgICAgIGlmIChuZXcgU2V0KHF1ZXJ5SGFzaGVzKS5zaXplICE9PSBxdWVyeUhhc2hlcy5sZW5ndGgpIHtcbiAgICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICAgIFwiW1F1ZXJpZXNPYnNlcnZlcl06IER1cGxpY2F0ZSBRdWVyaWVzIGZvdW5kLiBUaGlzIG1pZ2h0IHJlc3VsdCBpbiB1bmV4cGVjdGVkIGJlaGF2aW9yLlwiXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICAgIG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuICAgICAgY29uc3QgcHJldk9ic2VydmVycyA9IHRoaXMuI29ic2VydmVycztcbiAgICAgIGNvbnN0IG5ld09ic2VydmVyTWF0Y2hlcyA9IHRoaXMuI2ZpbmRNYXRjaGluZ09ic2VydmVycyh0aGlzLiNxdWVyaWVzKTtcbiAgICAgIG5ld09ic2VydmVyTWF0Y2hlcy5mb3JFYWNoKFxuICAgICAgICAobWF0Y2gpID0+IG1hdGNoLm9ic2VydmVyLnNldE9wdGlvbnMobWF0Y2guZGVmYXVsdGVkUXVlcnlPcHRpb25zKVxuICAgICAgKTtcbiAgICAgIGNvbnN0IG5ld09ic2VydmVycyA9IG5ld09ic2VydmVyTWF0Y2hlcy5tYXAoKG1hdGNoKSA9PiBtYXRjaC5vYnNlcnZlcik7XG4gICAgICBjb25zdCBuZXdSZXN1bHQgPSBuZXdPYnNlcnZlcnMubWFwKFxuICAgICAgICAob2JzZXJ2ZXIpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKVxuICAgICAgKTtcbiAgICAgIGNvbnN0IGhhc0xlbmd0aENoYW5nZSA9IHByZXZPYnNlcnZlcnMubGVuZ3RoICE9PSBuZXdPYnNlcnZlcnMubGVuZ3RoO1xuICAgICAgY29uc3QgaGFzSW5kZXhDaGFuZ2UgPSBuZXdPYnNlcnZlcnMuc29tZShcbiAgICAgICAgKG9ic2VydmVyLCBpbmRleCkgPT4gb2JzZXJ2ZXIgIT09IHByZXZPYnNlcnZlcnNbaW5kZXhdXG4gICAgICApO1xuICAgICAgY29uc3QgaGFzU3RydWN0dXJhbENoYW5nZSA9IGhhc0xlbmd0aENoYW5nZSB8fCBoYXNJbmRleENoYW5nZTtcbiAgICAgIGNvbnN0IGhhc1Jlc3VsdENoYW5nZSA9IGhhc1N0cnVjdHVyYWxDaGFuZ2UgPyB0cnVlIDogbmV3UmVzdWx0LnNvbWUoKHJlc3VsdCwgaW5kZXgpID0+IHtcbiAgICAgICAgY29uc3QgcHJldiA9IHRoaXMuI3Jlc3VsdFtpbmRleF07XG4gICAgICAgIHJldHVybiAhcHJldiB8fCAhc2hhbGxvd0VxdWFsT2JqZWN0cyhyZXN1bHQsIHByZXYpO1xuICAgICAgfSk7XG4gICAgICBpZiAoIWhhc1N0cnVjdHVyYWxDaGFuZ2UgJiYgIWhhc1Jlc3VsdENoYW5nZSkgcmV0dXJuO1xuICAgICAgaWYgKGhhc1N0cnVjdHVyYWxDaGFuZ2UpIHtcbiAgICAgICAgdGhpcy4jb2JzZXJ2ZXJNYXRjaGVzID0gbmV3T2JzZXJ2ZXJNYXRjaGVzO1xuICAgICAgICB0aGlzLiNvYnNlcnZlcnMgPSBuZXdPYnNlcnZlcnM7XG4gICAgICB9XG4gICAgICB0aGlzLiNyZXN1bHQgPSBuZXdSZXN1bHQ7XG4gICAgICBpZiAoIXRoaXMuaGFzTGlzdGVuZXJzKCkpIHJldHVybjtcbiAgICAgIGlmIChoYXNTdHJ1Y3R1cmFsQ2hhbmdlKSB7XG4gICAgICAgIGRpZmZlcmVuY2UocHJldk9ic2VydmVycywgbmV3T2JzZXJ2ZXJzKS5mb3JFYWNoKChvYnNlcnZlcikgPT4ge1xuICAgICAgICAgIG9ic2VydmVyLmRlc3Ryb3koKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGRpZmZlcmVuY2UobmV3T2JzZXJ2ZXJzLCBwcmV2T2JzZXJ2ZXJzKS5mb3JFYWNoKChvYnNlcnZlcikgPT4ge1xuICAgICAgICAgIG9ic2VydmVyLnN1YnNjcmliZSgocmVzdWx0KSA9PiB7XG4gICAgICAgICAgICB0aGlzLiNvblVwZGF0ZShvYnNlcnZlciwgcmVzdWx0KTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICB0aGlzLiNub3RpZnkoKTtcbiAgICB9KTtcbiAgfVxuICBnZXRDdXJyZW50UmVzdWx0KCkge1xuICAgIHJldHVybiB0aGlzLiNyZXN1bHQ7XG4gIH1cbiAgZ2V0UXVlcmllcygpIHtcbiAgICByZXR1cm4gdGhpcy4jb2JzZXJ2ZXJzLm1hcCgob2JzZXJ2ZXIpID0+IG9ic2VydmVyLmdldEN1cnJlbnRRdWVyeSgpKTtcbiAgfVxuICBnZXRPYnNlcnZlcnMoKSB7XG4gICAgcmV0dXJuIHRoaXMuI29ic2VydmVycztcbiAgfVxuICBnZXRPcHRpbWlzdGljUmVzdWx0KHF1ZXJpZXMsIGNvbWJpbmUpIHtcbiAgICBjb25zdCBtYXRjaGVzID0gdGhpcy4jZmluZE1hdGNoaW5nT2JzZXJ2ZXJzKHF1ZXJpZXMpO1xuICAgIGNvbnN0IHJlc3VsdCA9IG1hdGNoZXMubWFwKFxuICAgICAgKG1hdGNoKSA9PiBtYXRjaC5vYnNlcnZlci5nZXRPcHRpbWlzdGljUmVzdWx0KG1hdGNoLmRlZmF1bHRlZFF1ZXJ5T3B0aW9ucylcbiAgICApO1xuICAgIGNvbnN0IHF1ZXJ5SGFzaGVzID0gbWF0Y2hlcy5tYXAoXG4gICAgICAobWF0Y2gpID0+IG1hdGNoLmRlZmF1bHRlZFF1ZXJ5T3B0aW9ucy5xdWVyeUhhc2hcbiAgICApO1xuICAgIHJldHVybiBbXG4gICAgICByZXN1bHQsXG4gICAgICAocikgPT4ge1xuICAgICAgICByZXR1cm4gdGhpcy4jY29tYmluZVJlc3VsdChyID8/IHJlc3VsdCwgY29tYmluZSwgcXVlcnlIYXNoZXMpO1xuICAgICAgfSxcbiAgICAgICgpID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuI3RyYWNrUmVzdWx0KHJlc3VsdCwgbWF0Y2hlcyk7XG4gICAgICB9XG4gICAgXTtcbiAgfVxuICAjdHJhY2tSZXN1bHQocmVzdWx0LCBtYXRjaGVzKSB7XG4gICAgcmV0dXJuIG1hdGNoZXMubWFwKChtYXRjaCwgaW5kZXgpID0+IHtcbiAgICAgIGNvbnN0IG9ic2VydmVyUmVzdWx0ID0gcmVzdWx0W2luZGV4XTtcbiAgICAgIHJldHVybiAhbWF0Y2guZGVmYXVsdGVkUXVlcnlPcHRpb25zLm5vdGlmeU9uQ2hhbmdlUHJvcHMgPyBtYXRjaC5vYnNlcnZlci50cmFja1Jlc3VsdChvYnNlcnZlclJlc3VsdCwgKGFjY2Vzc2VkUHJvcCkgPT4ge1xuICAgICAgICBtYXRjaGVzLmZvckVhY2goKG0pID0+IHtcbiAgICAgICAgICBtLm9ic2VydmVyLnRyYWNrUHJvcChhY2Nlc3NlZFByb3ApO1xuICAgICAgICB9KTtcbiAgICAgIH0pIDogb2JzZXJ2ZXJSZXN1bHQ7XG4gICAgfSk7XG4gIH1cbiAgI2NvbWJpbmVSZXN1bHQoaW5wdXQsIGNvbWJpbmUsIHF1ZXJ5SGFzaGVzKSB7XG4gICAgaWYgKGNvbWJpbmUpIHtcbiAgICAgIGNvbnN0IGxhc3RIYXNoZXMgPSB0aGlzLiNsYXN0UXVlcnlIYXNoZXM7XG4gICAgICBjb25zdCBxdWVyeUhhc2hlc0NoYW5nZWQgPSBxdWVyeUhhc2hlcyAhPT0gdm9pZCAwICYmIGxhc3RIYXNoZXMgIT09IHZvaWQgMCAmJiAobGFzdEhhc2hlcy5sZW5ndGggIT09IHF1ZXJ5SGFzaGVzLmxlbmd0aCB8fCBxdWVyeUhhc2hlcy5zb21lKChoYXNoLCBpKSA9PiBoYXNoICE9PSBsYXN0SGFzaGVzW2ldKSk7XG4gICAgICBpZiAoIXRoaXMuI2NvbWJpbmVkUmVzdWx0IHx8IHRoaXMuI3Jlc3VsdCAhPT0gdGhpcy4jbGFzdFJlc3VsdCB8fCBxdWVyeUhhc2hlc0NoYW5nZWQgfHwgY29tYmluZSAhPT0gdGhpcy4jbGFzdENvbWJpbmUpIHtcbiAgICAgICAgdGhpcy4jbGFzdENvbWJpbmUgPSBjb21iaW5lO1xuICAgICAgICB0aGlzLiNsYXN0UmVzdWx0ID0gdGhpcy4jcmVzdWx0O1xuICAgICAgICBpZiAocXVlcnlIYXNoZXMgIT09IHZvaWQgMCkge1xuICAgICAgICAgIHRoaXMuI2xhc3RRdWVyeUhhc2hlcyA9IHF1ZXJ5SGFzaGVzO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuI2NvbWJpbmVkUmVzdWx0ID0gcmVwbGFjZUVxdWFsRGVlcChcbiAgICAgICAgICB0aGlzLiNjb21iaW5lZFJlc3VsdCxcbiAgICAgICAgICBjb21iaW5lKGlucHV0KVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRoaXMuI2NvbWJpbmVkUmVzdWx0O1xuICAgIH1cbiAgICByZXR1cm4gaW5wdXQ7XG4gIH1cbiAgI3Nob3VsZFNraXBDb21iaW5lKCkge1xuICAgIHJldHVybiB0aGlzLiNvcHRpb25zPy5jb21iaW5lICE9PSB2b2lkIDAgJiYgdGhpcy4jb2JzZXJ2ZXJzLnNvbWUoKG9ic2VydmVyLCBpbmRleCkgPT4ge1xuICAgICAgcmV0dXJuIG9ic2VydmVyLm9wdGlvbnMuc3VzcGVuc2UgJiYgdGhpcy4jcmVzdWx0W2luZGV4XT8uZGF0YSA9PT0gdm9pZCAwO1xuICAgIH0pO1xuICB9XG4gICNmaW5kTWF0Y2hpbmdPYnNlcnZlcnMocXVlcmllcykge1xuICAgIGNvbnN0IHByZXZPYnNlcnZlcnNNYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICAgIHRoaXMuI29ic2VydmVycy5mb3JFYWNoKChvYnNlcnZlcikgPT4ge1xuICAgICAgY29uc3Qga2V5ID0gb2JzZXJ2ZXIub3B0aW9ucy5xdWVyeUhhc2g7XG4gICAgICBpZiAoIWtleSkgcmV0dXJuO1xuICAgICAgY29uc3QgcHJldmlvdXNPYnNlcnZlcnMgPSBwcmV2T2JzZXJ2ZXJzTWFwLmdldChrZXkpO1xuICAgICAgaWYgKHByZXZpb3VzT2JzZXJ2ZXJzKSB7XG4gICAgICAgIHByZXZpb3VzT2JzZXJ2ZXJzLnB1c2gob2JzZXJ2ZXIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcHJldk9ic2VydmVyc01hcC5zZXQoa2V5LCBbb2JzZXJ2ZXJdKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBjb25zdCBvYnNlcnZlcnMgPSBbXTtcbiAgICBxdWVyaWVzLmZvckVhY2goKG9wdGlvbnMpID0+IHtcbiAgICAgIGNvbnN0IGRlZmF1bHRlZE9wdGlvbnMgPSB0aGlzLiNjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKTtcbiAgICAgIGNvbnN0IG1hdGNoID0gcHJldk9ic2VydmVyc01hcC5nZXQoZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUhhc2gpPy5zaGlmdCgpO1xuICAgICAgY29uc3Qgb2JzZXJ2ZXIgPSBtYXRjaCA/PyBuZXcgUXVlcnlPYnNlcnZlcih0aGlzLiNjbGllbnQsIGRlZmF1bHRlZE9wdGlvbnMpO1xuICAgICAgb2JzZXJ2ZXJzLnB1c2goe1xuICAgICAgICBkZWZhdWx0ZWRRdWVyeU9wdGlvbnM6IGRlZmF1bHRlZE9wdGlvbnMsXG4gICAgICAgIG9ic2VydmVyXG4gICAgICB9KTtcbiAgICB9KTtcbiAgICByZXR1cm4gb2JzZXJ2ZXJzO1xuICB9XG4gICNvblVwZGF0ZShvYnNlcnZlciwgcmVzdWx0KSB7XG4gICAgY29uc3QgaW5kZXggPSB0aGlzLiNvYnNlcnZlcnMuaW5kZXhPZihvYnNlcnZlcik7XG4gICAgaWYgKGluZGV4ICE9PSAtMSkge1xuICAgICAgdGhpcy4jcmVzdWx0ID0gcmVwbGFjZUF0KHRoaXMuI3Jlc3VsdCwgaW5kZXgsIHJlc3VsdCk7XG4gICAgICB0aGlzLiNub3RpZnkoKTtcbiAgICB9XG4gIH1cbiAgI25vdGlmeSgpIHtcbiAgICBpZiAodGhpcy5oYXNMaXN0ZW5lcnMoKSkge1xuICAgICAgY29uc3QgbmV3VHJhY2tlZCA9IHRoaXMuI3RyYWNrUmVzdWx0KHRoaXMuI3Jlc3VsdCwgdGhpcy4jb2JzZXJ2ZXJNYXRjaGVzKTtcbiAgICAgIGNvbnN0IHNob3VsZFNraXBDb21iaW5lID0gdGhpcy4jc2hvdWxkU2tpcENvbWJpbmUoKTtcbiAgICAgIGNvbnN0IHByZXZpb3VzUmVzdWx0ID0gdGhpcy4jY29tYmluZWRSZXN1bHQ7XG4gICAgICBjb25zdCBuZXdSZXN1bHQgPSBzaG91bGRTa2lwQ29tYmluZSA/IHByZXZpb3VzUmVzdWx0IDogdGhpcy4jY29tYmluZVJlc3VsdChuZXdUcmFja2VkLCB0aGlzLiNvcHRpb25zPy5jb21iaW5lKTtcbiAgICAgIGlmIChzaG91bGRTa2lwQ29tYmluZSB8fCBwcmV2aW91c1Jlc3VsdCAhPT0gbmV3UmVzdWx0KSB7XG4gICAgICAgIG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuICAgICAgICAgIHRoaXMubGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG4gICAgICAgICAgICBsaXN0ZW5lcih0aGlzLiNyZXN1bHQpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn07XG5leHBvcnQge1xuICBRdWVyaWVzT2JzZXJ2ZXJcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1xdWVyaWVzT2JzZXJ2ZXIuanMubWFwIiwiLy8gc3JjL3F1ZXJ5Q2FjaGUudHNcbmltcG9ydCB7IGhhc2hRdWVyeUtleUJ5T3B0aW9ucywgbWF0Y2hRdWVyeSB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBRdWVyeSB9IGZyb20gXCIuL3F1ZXJ5LmpzXCI7XG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIi4vbm90aWZ5TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG52YXIgUXVlcnlDYWNoZSA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcbiAgY29uc3RydWN0b3IoY29uZmlnID0ge30pIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuY29uZmlnID0gY29uZmlnO1xuICAgIHRoaXMuI3F1ZXJpZXMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICB9XG4gICNxdWVyaWVzO1xuICBidWlsZChjbGllbnQsIG9wdGlvbnMsIHN0YXRlKSB7XG4gICAgY29uc3QgcXVlcnlLZXkgPSBvcHRpb25zLnF1ZXJ5S2V5O1xuICAgIGNvbnN0IHF1ZXJ5SGFzaCA9IG9wdGlvbnMucXVlcnlIYXNoID8/IGhhc2hRdWVyeUtleUJ5T3B0aW9ucyhxdWVyeUtleSwgb3B0aW9ucyk7XG4gICAgbGV0IHF1ZXJ5ID0gdGhpcy5nZXQocXVlcnlIYXNoKTtcbiAgICBpZiAoIXF1ZXJ5KSB7XG4gICAgICBxdWVyeSA9IG5ldyBRdWVyeSh7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgcXVlcnlLZXksXG4gICAgICAgIHF1ZXJ5SGFzaCxcbiAgICAgICAgb3B0aW9uczogY2xpZW50LmRlZmF1bHRRdWVyeU9wdGlvbnMob3B0aW9ucyksXG4gICAgICAgIHN0YXRlLFxuICAgICAgICBkZWZhdWx0T3B0aW9uczogY2xpZW50LmdldFF1ZXJ5RGVmYXVsdHMocXVlcnlLZXkpXG4gICAgICB9KTtcbiAgICAgIHRoaXMuYWRkKHF1ZXJ5KTtcbiAgICB9XG4gICAgcmV0dXJuIHF1ZXJ5O1xuICB9XG4gIGFkZChxdWVyeSkge1xuICAgIGlmICghdGhpcy4jcXVlcmllcy5oYXMocXVlcnkucXVlcnlIYXNoKSkge1xuICAgICAgdGhpcy4jcXVlcmllcy5zZXQocXVlcnkucXVlcnlIYXNoLCBxdWVyeSk7XG4gICAgICB0aGlzLm5vdGlmeSh7XG4gICAgICAgIHR5cGU6IFwiYWRkZWRcIixcbiAgICAgICAgcXVlcnlcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICByZW1vdmUocXVlcnkpIHtcbiAgICBjb25zdCBxdWVyeUluTWFwID0gdGhpcy4jcXVlcmllcy5nZXQocXVlcnkucXVlcnlIYXNoKTtcbiAgICBpZiAocXVlcnlJbk1hcCkge1xuICAgICAgcXVlcnkuZGVzdHJveSgpO1xuICAgICAgaWYgKHF1ZXJ5SW5NYXAgPT09IHF1ZXJ5KSB7XG4gICAgICAgIHRoaXMuI3F1ZXJpZXMuZGVsZXRlKHF1ZXJ5LnF1ZXJ5SGFzaCk7XG4gICAgICB9XG4gICAgICB0aGlzLm5vdGlmeSh7IHR5cGU6IFwicmVtb3ZlZFwiLCBxdWVyeSB9KTtcbiAgICB9XG4gIH1cbiAgY2xlYXIoKSB7XG4gICAgbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG4gICAgICB0aGlzLmdldEFsbCgpLmZvckVhY2goKHF1ZXJ5KSA9PiB7XG4gICAgICAgIHRoaXMucmVtb3ZlKHF1ZXJ5KTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG4gIGdldChxdWVyeUhhc2gpIHtcbiAgICByZXR1cm4gdGhpcy4jcXVlcmllcy5nZXQocXVlcnlIYXNoKTtcbiAgfVxuICBnZXRBbGwoKSB7XG4gICAgcmV0dXJuIFsuLi50aGlzLiNxdWVyaWVzLnZhbHVlcygpXTtcbiAgfVxuICBmaW5kKGZpbHRlcnMpIHtcbiAgICBjb25zdCBkZWZhdWx0ZWRGaWx0ZXJzID0geyBleGFjdDogdHJ1ZSwgLi4uZmlsdGVycyB9O1xuICAgIHJldHVybiB0aGlzLmdldEFsbCgpLmZpbmQoXG4gICAgICAocXVlcnkpID0+IG1hdGNoUXVlcnkoZGVmYXVsdGVkRmlsdGVycywgcXVlcnkpXG4gICAgKTtcbiAgfVxuICBmaW5kQWxsKGZpbHRlcnMgPSB7fSkge1xuICAgIGNvbnN0IHF1ZXJpZXMgPSB0aGlzLmdldEFsbCgpO1xuICAgIHJldHVybiBPYmplY3Qua2V5cyhmaWx0ZXJzKS5sZW5ndGggPiAwID8gcXVlcmllcy5maWx0ZXIoKHF1ZXJ5KSA9PiBtYXRjaFF1ZXJ5KGZpbHRlcnMsIHF1ZXJ5KSkgOiBxdWVyaWVzO1xuICB9XG4gIG5vdGlmeShldmVudCkge1xuICAgIG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuICAgICAgdGhpcy5saXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcbiAgICAgICAgbGlzdGVuZXIoZXZlbnQpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbiAgb25Gb2N1cygpIHtcbiAgICBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcbiAgICAgIHRoaXMuZ2V0QWxsKCkuZm9yRWFjaCgocXVlcnkpID0+IHtcbiAgICAgICAgcXVlcnkub25Gb2N1cygpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbiAgb25PbmxpbmUoKSB7XG4gICAgbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG4gICAgICB0aGlzLmdldEFsbCgpLmZvckVhY2goKHF1ZXJ5KSA9PiB7XG4gICAgICAgIHF1ZXJ5Lm9uT25saW5lKCk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxufTtcbmV4cG9ydCB7XG4gIFF1ZXJ5Q2FjaGVcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1xdWVyeUNhY2hlLmpzLm1hcCIsIi8vIHNyYy9xdWVyeUNsaWVudC50c1xuaW1wb3J0IHtcbiAgZnVuY3Rpb25hbFVwZGF0ZSxcbiAgaGFzaEtleSxcbiAgaGFzaFF1ZXJ5S2V5QnlPcHRpb25zLFxuICBub29wLFxuICBwYXJ0aWFsTWF0Y2hLZXksXG4gIHJlc29sdmVTdGFsZVRpbWUsXG4gIHNraXBUb2tlblxufSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgUXVlcnlDYWNoZSB9IGZyb20gXCIuL3F1ZXJ5Q2FjaGUuanNcIjtcbmltcG9ydCB7IE11dGF0aW9uQ2FjaGUgfSBmcm9tIFwiLi9tdXRhdGlvbkNhY2hlLmpzXCI7XG5pbXBvcnQgeyBmb2N1c01hbmFnZXIgfSBmcm9tIFwiLi9mb2N1c01hbmFnZXIuanNcIjtcbmltcG9ydCB7IG9ubGluZU1hbmFnZXIgfSBmcm9tIFwiLi9vbmxpbmVNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIi4vbm90aWZ5TWFuYWdlci5qc1wiO1xudmFyIFF1ZXJ5Q2xpZW50ID0gY2xhc3Mge1xuICAjcXVlcnlDYWNoZTtcbiAgI211dGF0aW9uQ2FjaGU7XG4gICNkZWZhdWx0T3B0aW9ucztcbiAgI3F1ZXJ5RGVmYXVsdHM7XG4gICNtdXRhdGlvbkRlZmF1bHRzO1xuICAjbW91bnRDb3VudDtcbiAgI3Vuc3Vic2NyaWJlRm9jdXM7XG4gICN1bnN1YnNjcmliZU9ubGluZTtcbiAgY29uc3RydWN0b3IoY29uZmlnID0ge30pIHtcbiAgICB0aGlzLiNxdWVyeUNhY2hlID0gY29uZmlnLnF1ZXJ5Q2FjaGUgfHwgbmV3IFF1ZXJ5Q2FjaGUoKTtcbiAgICB0aGlzLiNtdXRhdGlvbkNhY2hlID0gY29uZmlnLm11dGF0aW9uQ2FjaGUgfHwgbmV3IE11dGF0aW9uQ2FjaGUoKTtcbiAgICB0aGlzLiNkZWZhdWx0T3B0aW9ucyA9IGNvbmZpZy5kZWZhdWx0T3B0aW9ucyB8fCB7fTtcbiAgICB0aGlzLiNxdWVyeURlZmF1bHRzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgICB0aGlzLiNtdXRhdGlvbkRlZmF1bHRzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgICB0aGlzLiNtb3VudENvdW50ID0gMDtcbiAgfVxuICBtb3VudCgpIHtcbiAgICB0aGlzLiNtb3VudENvdW50Kys7XG4gICAgaWYgKHRoaXMuI21vdW50Q291bnQgIT09IDEpIHJldHVybjtcbiAgICB0aGlzLiN1bnN1YnNjcmliZUZvY3VzID0gZm9jdXNNYW5hZ2VyLnN1YnNjcmliZShhc3luYyAoZm9jdXNlZCkgPT4ge1xuICAgICAgaWYgKGZvY3VzZWQpIHtcbiAgICAgICAgYXdhaXQgdGhpcy5yZXN1bWVQYXVzZWRNdXRhdGlvbnMoKTtcbiAgICAgICAgdGhpcy4jcXVlcnlDYWNoZS5vbkZvY3VzKCk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgdGhpcy4jdW5zdWJzY3JpYmVPbmxpbmUgPSBvbmxpbmVNYW5hZ2VyLnN1YnNjcmliZShhc3luYyAob25saW5lKSA9PiB7XG4gICAgICBpZiAob25saW5lKSB7XG4gICAgICAgIGF3YWl0IHRoaXMucmVzdW1lUGF1c2VkTXV0YXRpb25zKCk7XG4gICAgICAgIHRoaXMuI3F1ZXJ5Q2FjaGUub25PbmxpbmUoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICB1bm1vdW50KCkge1xuICAgIHRoaXMuI21vdW50Q291bnQtLTtcbiAgICBpZiAodGhpcy4jbW91bnRDb3VudCAhPT0gMCkgcmV0dXJuO1xuICAgIHRoaXMuI3Vuc3Vic2NyaWJlRm9jdXM/LigpO1xuICAgIHRoaXMuI3Vuc3Vic2NyaWJlRm9jdXMgPSB2b2lkIDA7XG4gICAgdGhpcy4jdW5zdWJzY3JpYmVPbmxpbmU/LigpO1xuICAgIHRoaXMuI3Vuc3Vic2NyaWJlT25saW5lID0gdm9pZCAwO1xuICB9XG4gIGlzRmV0Y2hpbmcoZmlsdGVycykge1xuICAgIHJldHVybiB0aGlzLiNxdWVyeUNhY2hlLmZpbmRBbGwoeyAuLi5maWx0ZXJzLCBmZXRjaFN0YXR1czogXCJmZXRjaGluZ1wiIH0pLmxlbmd0aDtcbiAgfVxuICBpc011dGF0aW5nKGZpbHRlcnMpIHtcbiAgICByZXR1cm4gdGhpcy4jbXV0YXRpb25DYWNoZS5maW5kQWxsKHsgLi4uZmlsdGVycywgc3RhdHVzOiBcInBlbmRpbmdcIiB9KS5sZW5ndGg7XG4gIH1cbiAgLyoqXG4gICAqIEltcGVyYXRpdmUgKG5vbi1yZWFjdGl2ZSkgd2F5IHRvIHJldHJpZXZlIGRhdGEgZm9yIGEgUXVlcnlLZXkuXG4gICAqIFNob3VsZCBvbmx5IGJlIHVzZWQgaW4gY2FsbGJhY2tzIG9yIGZ1bmN0aW9ucyB3aGVyZSByZWFkaW5nIHRoZSBsYXRlc3QgZGF0YSBpcyBuZWNlc3NhcnksIGUuZy4gZm9yIG9wdGltaXN0aWMgdXBkYXRlcy5cbiAgICpcbiAgICogSGludDogRG8gbm90IHVzZSB0aGlzIGZ1bmN0aW9uIGluc2lkZSBhIGNvbXBvbmVudCwgYmVjYXVzZSBpdCB3b24ndCByZWNlaXZlIHVwZGF0ZXMuXG4gICAqIFVzZSBgdXNlUXVlcnlgIHRvIGNyZWF0ZSBhIGBRdWVyeU9ic2VydmVyYCB0aGF0IHN1YnNjcmliZXMgdG8gY2hhbmdlcy5cbiAgICovXG4gIGdldFF1ZXJ5RGF0YShxdWVyeUtleSkge1xuICAgIGNvbnN0IG9wdGlvbnMgPSB0aGlzLmRlZmF1bHRRdWVyeU9wdGlvbnMoeyBxdWVyeUtleSB9KTtcbiAgICByZXR1cm4gdGhpcy4jcXVlcnlDYWNoZS5nZXQob3B0aW9ucy5xdWVyeUhhc2gpPy5zdGF0ZS5kYXRhO1xuICB9XG4gIGVuc3VyZVF1ZXJ5RGF0YShvcHRpb25zKSB7XG4gICAgY29uc3QgZGVmYXVsdGVkT3B0aW9ucyA9IHRoaXMuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKTtcbiAgICBjb25zdCBxdWVyeSA9IHRoaXMuI3F1ZXJ5Q2FjaGUuYnVpbGQodGhpcywgZGVmYXVsdGVkT3B0aW9ucyk7XG4gICAgY29uc3QgY2FjaGVkRGF0YSA9IHF1ZXJ5LnN0YXRlLmRhdGE7XG4gICAgaWYgKGNhY2hlZERhdGEgPT09IHZvaWQgMCkge1xuICAgICAgcmV0dXJuIHRoaXMuZmV0Y2hRdWVyeShvcHRpb25zKTtcbiAgICB9XG4gICAgaWYgKG9wdGlvbnMucmV2YWxpZGF0ZUlmU3RhbGUgJiYgcXVlcnkuaXNTdGFsZUJ5VGltZShyZXNvbHZlU3RhbGVUaW1lKGRlZmF1bHRlZE9wdGlvbnMuc3RhbGVUaW1lLCBxdWVyeSkpKSB7XG4gICAgICB2b2lkIHRoaXMucHJlZmV0Y2hRdWVyeShkZWZhdWx0ZWRPcHRpb25zKTtcbiAgICB9XG4gICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShjYWNoZWREYXRhKTtcbiAgfVxuICBnZXRRdWVyaWVzRGF0YShmaWx0ZXJzKSB7XG4gICAgcmV0dXJuIHRoaXMuI3F1ZXJ5Q2FjaGUuZmluZEFsbChmaWx0ZXJzKS5tYXAoKHsgcXVlcnlLZXksIHN0YXRlIH0pID0+IHtcbiAgICAgIGNvbnN0IGRhdGEgPSBzdGF0ZS5kYXRhO1xuICAgICAgcmV0dXJuIFtxdWVyeUtleSwgZGF0YV07XG4gICAgfSk7XG4gIH1cbiAgc2V0UXVlcnlEYXRhKHF1ZXJ5S2V5LCB1cGRhdGVyLCBvcHRpb25zKSB7XG4gICAgY29uc3QgZGVmYXVsdGVkT3B0aW9ucyA9IHRoaXMuZGVmYXVsdFF1ZXJ5T3B0aW9ucyh7IHF1ZXJ5S2V5IH0pO1xuICAgIGNvbnN0IHF1ZXJ5ID0gdGhpcy4jcXVlcnlDYWNoZS5nZXQoXG4gICAgICBkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5SGFzaFxuICAgICk7XG4gICAgY29uc3QgcHJldkRhdGEgPSBxdWVyeT8uc3RhdGUuZGF0YTtcbiAgICBjb25zdCBkYXRhID0gZnVuY3Rpb25hbFVwZGF0ZSh1cGRhdGVyLCBwcmV2RGF0YSk7XG4gICAgaWYgKGRhdGEgPT09IHZvaWQgMCkge1xuICAgICAgcmV0dXJuIHZvaWQgMDtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuI3F1ZXJ5Q2FjaGUuYnVpbGQodGhpcywgZGVmYXVsdGVkT3B0aW9ucykuc2V0RGF0YShkYXRhLCB7IC4uLm9wdGlvbnMsIG1hbnVhbDogdHJ1ZSB9KTtcbiAgfVxuICBzZXRRdWVyaWVzRGF0YShmaWx0ZXJzLCB1cGRhdGVyLCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIG5vdGlmeU1hbmFnZXIuYmF0Y2goXG4gICAgICAoKSA9PiB0aGlzLiNxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycykubWFwKCh7IHF1ZXJ5S2V5IH0pID0+IFtcbiAgICAgICAgcXVlcnlLZXksXG4gICAgICAgIHRoaXMuc2V0UXVlcnlEYXRhKHF1ZXJ5S2V5LCB1cGRhdGVyLCBvcHRpb25zKVxuICAgICAgXSlcbiAgICApO1xuICB9XG4gIGdldFF1ZXJ5U3RhdGUocXVlcnlLZXkpIHtcbiAgICBjb25zdCBvcHRpb25zID0gdGhpcy5kZWZhdWx0UXVlcnlPcHRpb25zKHsgcXVlcnlLZXkgfSk7XG4gICAgcmV0dXJuIHRoaXMuI3F1ZXJ5Q2FjaGUuZ2V0KFxuICAgICAgb3B0aW9ucy5xdWVyeUhhc2hcbiAgICApPy5zdGF0ZTtcbiAgfVxuICByZW1vdmVRdWVyaWVzKGZpbHRlcnMpIHtcbiAgICBjb25zdCBxdWVyeUNhY2hlID0gdGhpcy4jcXVlcnlDYWNoZTtcbiAgICBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcbiAgICAgIHF1ZXJ5Q2FjaGUuZmluZEFsbChmaWx0ZXJzKS5mb3JFYWNoKChxdWVyeSkgPT4ge1xuICAgICAgICBxdWVyeUNhY2hlLnJlbW92ZShxdWVyeSk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuICByZXNldFF1ZXJpZXMoZmlsdGVycywgb3B0aW9ucykge1xuICAgIGNvbnN0IHF1ZXJ5Q2FjaGUgPSB0aGlzLiNxdWVyeUNhY2hlO1xuICAgIHJldHVybiBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcbiAgICAgIHF1ZXJ5Q2FjaGUuZmluZEFsbChmaWx0ZXJzKS5mb3JFYWNoKChxdWVyeSkgPT4ge1xuICAgICAgICBxdWVyeS5yZXNldCgpO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gdGhpcy5yZWZldGNoUXVlcmllcyhcbiAgICAgICAge1xuICAgICAgICAgIHR5cGU6IFwiYWN0aXZlXCIsXG4gICAgICAgICAgLi4uZmlsdGVyc1xuICAgICAgICB9LFxuICAgICAgICBvcHRpb25zXG4gICAgICApO1xuICAgIH0pO1xuICB9XG4gIGNhbmNlbFF1ZXJpZXMoZmlsdGVycywgY2FuY2VsT3B0aW9ucyA9IHt9KSB7XG4gICAgY29uc3QgZGVmYXVsdGVkQ2FuY2VsT3B0aW9ucyA9IHsgcmV2ZXJ0OiB0cnVlLCAuLi5jYW5jZWxPcHRpb25zIH07XG4gICAgY29uc3QgcHJvbWlzZXMgPSBub3RpZnlNYW5hZ2VyLmJhdGNoKFxuICAgICAgKCkgPT4gdGhpcy4jcXVlcnlDYWNoZS5maW5kQWxsKGZpbHRlcnMpLm1hcCgocXVlcnkpID0+IHF1ZXJ5LmNhbmNlbChkZWZhdWx0ZWRDYW5jZWxPcHRpb25zKSlcbiAgICApO1xuICAgIHJldHVybiBQcm9taXNlLmFsbChwcm9taXNlcykudGhlbihub29wKS5jYXRjaChub29wKTtcbiAgfVxuICBpbnZhbGlkYXRlUXVlcmllcyhmaWx0ZXJzLCBvcHRpb25zID0ge30pIHtcbiAgICByZXR1cm4gbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG4gICAgICB0aGlzLiNxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycykuZm9yRWFjaCgocXVlcnkpID0+IHtcbiAgICAgICAgcXVlcnkuaW52YWxpZGF0ZSgpO1xuICAgICAgfSk7XG4gICAgICBpZiAoZmlsdGVycz8ucmVmZXRjaFR5cGUgPT09IFwibm9uZVwiKSB7XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0aGlzLnJlZmV0Y2hRdWVyaWVzKFxuICAgICAgICB7XG4gICAgICAgICAgLi4uZmlsdGVycyxcbiAgICAgICAgICB0eXBlOiBmaWx0ZXJzPy5yZWZldGNoVHlwZSA/PyBmaWx0ZXJzPy50eXBlID8/IFwiYWN0aXZlXCJcbiAgICAgICAgfSxcbiAgICAgICAgb3B0aW9uc1xuICAgICAgKTtcbiAgICB9KTtcbiAgfVxuICByZWZldGNoUXVlcmllcyhmaWx0ZXJzLCBvcHRpb25zID0ge30pIHtcbiAgICBjb25zdCBmZXRjaE9wdGlvbnMgPSB7XG4gICAgICAuLi5vcHRpb25zLFxuICAgICAgY2FuY2VsUmVmZXRjaDogb3B0aW9ucy5jYW5jZWxSZWZldGNoID8/IHRydWVcbiAgICB9O1xuICAgIGNvbnN0IHByb21pc2VzID0gbm90aWZ5TWFuYWdlci5iYXRjaChcbiAgICAgICgpID0+IHRoaXMuI3F1ZXJ5Q2FjaGUuZmluZEFsbChmaWx0ZXJzKS5maWx0ZXIoKHF1ZXJ5KSA9PiAhcXVlcnkuaXNEaXNhYmxlZCgpICYmICFxdWVyeS5pc1N0YXRpYygpKS5tYXAoKHF1ZXJ5KSA9PiB7XG4gICAgICAgIGxldCBwcm9taXNlID0gcXVlcnkuZmV0Y2godm9pZCAwLCBmZXRjaE9wdGlvbnMpO1xuICAgICAgICBpZiAoIWZldGNoT3B0aW9ucy50aHJvd09uRXJyb3IpIHtcbiAgICAgICAgICBwcm9taXNlID0gcHJvbWlzZS5jYXRjaChub29wKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcXVlcnkuc3RhdGUuZmV0Y2hTdGF0dXMgPT09IFwicGF1c2VkXCIgPyBQcm9taXNlLnJlc29sdmUoKSA6IHByb21pc2U7XG4gICAgICB9KVxuICAgICk7XG4gICAgcmV0dXJuIFByb21pc2UuYWxsKHByb21pc2VzKS50aGVuKG5vb3ApO1xuICB9XG4gIGZldGNoUXVlcnkob3B0aW9ucykge1xuICAgIGNvbnN0IGRlZmF1bHRlZE9wdGlvbnMgPSB0aGlzLmRlZmF1bHRRdWVyeU9wdGlvbnMob3B0aW9ucyk7XG4gICAgaWYgKGRlZmF1bHRlZE9wdGlvbnMucmV0cnkgPT09IHZvaWQgMCkge1xuICAgICAgZGVmYXVsdGVkT3B0aW9ucy5yZXRyeSA9IGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBxdWVyeSA9IHRoaXMuI3F1ZXJ5Q2FjaGUuYnVpbGQodGhpcywgZGVmYXVsdGVkT3B0aW9ucyk7XG4gICAgcmV0dXJuIHF1ZXJ5LmlzU3RhbGVCeVRpbWUoXG4gICAgICByZXNvbHZlU3RhbGVUaW1lKGRlZmF1bHRlZE9wdGlvbnMuc3RhbGVUaW1lLCBxdWVyeSlcbiAgICApID8gcXVlcnkuZmV0Y2goZGVmYXVsdGVkT3B0aW9ucykgOiBQcm9taXNlLnJlc29sdmUocXVlcnkuc3RhdGUuZGF0YSk7XG4gIH1cbiAgcHJlZmV0Y2hRdWVyeShvcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMuZmV0Y2hRdWVyeShvcHRpb25zKS50aGVuKG5vb3ApLmNhdGNoKG5vb3ApO1xuICB9XG4gIGZldGNoSW5maW5pdGVRdWVyeShvcHRpb25zKSB7XG4gICAgb3B0aW9ucy5fdHlwZSA9IFwiaW5maW5pdGVcIjtcbiAgICByZXR1cm4gdGhpcy5mZXRjaFF1ZXJ5KG9wdGlvbnMpO1xuICB9XG4gIHByZWZldGNoSW5maW5pdGVRdWVyeShvcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMuZmV0Y2hJbmZpbml0ZVF1ZXJ5KG9wdGlvbnMpLnRoZW4obm9vcCkuY2F0Y2gobm9vcCk7XG4gIH1cbiAgZW5zdXJlSW5maW5pdGVRdWVyeURhdGEob3B0aW9ucykge1xuICAgIG9wdGlvbnMuX3R5cGUgPSBcImluZmluaXRlXCI7XG4gICAgcmV0dXJuIHRoaXMuZW5zdXJlUXVlcnlEYXRhKG9wdGlvbnMpO1xuICB9XG4gIHJlc3VtZVBhdXNlZE11dGF0aW9ucygpIHtcbiAgICBpZiAob25saW5lTWFuYWdlci5pc09ubGluZSgpKSB7XG4gICAgICByZXR1cm4gdGhpcy4jbXV0YXRpb25DYWNoZS5yZXN1bWVQYXVzZWRNdXRhdGlvbnMoKTtcbiAgICB9XG4gICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICB9XG4gIGdldFF1ZXJ5Q2FjaGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuI3F1ZXJ5Q2FjaGU7XG4gIH1cbiAgZ2V0TXV0YXRpb25DYWNoZSgpIHtcbiAgICByZXR1cm4gdGhpcy4jbXV0YXRpb25DYWNoZTtcbiAgfVxuICBnZXREZWZhdWx0T3B0aW9ucygpIHtcbiAgICByZXR1cm4gdGhpcy4jZGVmYXVsdE9wdGlvbnM7XG4gIH1cbiAgc2V0RGVmYXVsdE9wdGlvbnMob3B0aW9ucykge1xuICAgIHRoaXMuI2RlZmF1bHRPcHRpb25zID0gb3B0aW9ucztcbiAgfVxuICBzZXRRdWVyeURlZmF1bHRzKHF1ZXJ5S2V5LCBvcHRpb25zKSB7XG4gICAgdGhpcy4jcXVlcnlEZWZhdWx0cy5zZXQoaGFzaEtleShxdWVyeUtleSksIHtcbiAgICAgIHF1ZXJ5S2V5LFxuICAgICAgZGVmYXVsdE9wdGlvbnM6IG9wdGlvbnNcbiAgICB9KTtcbiAgfVxuICBnZXRRdWVyeURlZmF1bHRzKHF1ZXJ5S2V5KSB7XG4gICAgY29uc3QgZGVmYXVsdHMgPSBbLi4udGhpcy4jcXVlcnlEZWZhdWx0cy52YWx1ZXMoKV07XG4gICAgY29uc3QgcmVzdWx0ID0ge307XG4gICAgZGVmYXVsdHMuZm9yRWFjaCgocXVlcnlEZWZhdWx0KSA9PiB7XG4gICAgICBpZiAocGFydGlhbE1hdGNoS2V5KHF1ZXJ5S2V5LCBxdWVyeURlZmF1bHQucXVlcnlLZXkpKSB7XG4gICAgICAgIE9iamVjdC5hc3NpZ24ocmVzdWx0LCBxdWVyeURlZmF1bHQuZGVmYXVsdE9wdGlvbnMpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cbiAgc2V0TXV0YXRpb25EZWZhdWx0cyhtdXRhdGlvbktleSwgb3B0aW9ucykge1xuICAgIHRoaXMuI211dGF0aW9uRGVmYXVsdHMuc2V0KGhhc2hLZXkobXV0YXRpb25LZXkpLCB7XG4gICAgICBtdXRhdGlvbktleSxcbiAgICAgIGRlZmF1bHRPcHRpb25zOiBvcHRpb25zXG4gICAgfSk7XG4gIH1cbiAgZ2V0TXV0YXRpb25EZWZhdWx0cyhtdXRhdGlvbktleSkge1xuICAgIGNvbnN0IGRlZmF1bHRzID0gWy4uLnRoaXMuI211dGF0aW9uRGVmYXVsdHMudmFsdWVzKCldO1xuICAgIGNvbnN0IHJlc3VsdCA9IHt9O1xuICAgIGRlZmF1bHRzLmZvckVhY2goKHF1ZXJ5RGVmYXVsdCkgPT4ge1xuICAgICAgaWYgKHBhcnRpYWxNYXRjaEtleShtdXRhdGlvbktleSwgcXVlcnlEZWZhdWx0Lm11dGF0aW9uS2V5KSkge1xuICAgICAgICBPYmplY3QuYXNzaWduKHJlc3VsdCwgcXVlcnlEZWZhdWx0LmRlZmF1bHRPcHRpb25zKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG4gIGRlZmF1bHRRdWVyeU9wdGlvbnMob3B0aW9ucykge1xuICAgIGlmIChvcHRpb25zLl9kZWZhdWx0ZWQpIHtcbiAgICAgIHJldHVybiBvcHRpb25zO1xuICAgIH1cbiAgICBjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0ge1xuICAgICAgLi4udGhpcy4jZGVmYXVsdE9wdGlvbnMucXVlcmllcyxcbiAgICAgIC4uLnRoaXMuZ2V0UXVlcnlEZWZhdWx0cyhvcHRpb25zLnF1ZXJ5S2V5KSxcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgICBfZGVmYXVsdGVkOiB0cnVlXG4gICAgfTtcbiAgICBpZiAoIWRlZmF1bHRlZE9wdGlvbnMucXVlcnlIYXNoKSB7XG4gICAgICBkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5SGFzaCA9IGhhc2hRdWVyeUtleUJ5T3B0aW9ucyhcbiAgICAgICAgZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUtleSxcbiAgICAgICAgZGVmYXVsdGVkT3B0aW9uc1xuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKGRlZmF1bHRlZE9wdGlvbnMucmVmZXRjaE9uUmVjb25uZWN0ID09PSB2b2lkIDApIHtcbiAgICAgIGRlZmF1bHRlZE9wdGlvbnMucmVmZXRjaE9uUmVjb25uZWN0ID0gZGVmYXVsdGVkT3B0aW9ucy5uZXR3b3JrTW9kZSAhPT0gXCJhbHdheXNcIjtcbiAgICB9XG4gICAgaWYgKGRlZmF1bHRlZE9wdGlvbnMudGhyb3dPbkVycm9yID09PSB2b2lkIDApIHtcbiAgICAgIGRlZmF1bHRlZE9wdGlvbnMudGhyb3dPbkVycm9yID0gISFkZWZhdWx0ZWRPcHRpb25zLnN1c3BlbnNlO1xuICAgIH1cbiAgICBpZiAoIWRlZmF1bHRlZE9wdGlvbnMubmV0d29ya01vZGUgJiYgZGVmYXVsdGVkT3B0aW9ucy5wZXJzaXN0ZXIpIHtcbiAgICAgIGRlZmF1bHRlZE9wdGlvbnMubmV0d29ya01vZGUgPSBcIm9mZmxpbmVGaXJzdFwiO1xuICAgIH1cbiAgICBpZiAoZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUZuID09PSBza2lwVG9rZW4pIHtcbiAgICAgIGRlZmF1bHRlZE9wdGlvbnMuZW5hYmxlZCA9IGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gZGVmYXVsdGVkT3B0aW9ucztcbiAgfVxuICBkZWZhdWx0TXV0YXRpb25PcHRpb25zKG9wdGlvbnMpIHtcbiAgICBpZiAob3B0aW9ucz8uX2RlZmF1bHRlZCkge1xuICAgICAgcmV0dXJuIG9wdGlvbnM7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAuLi50aGlzLiNkZWZhdWx0T3B0aW9ucy5tdXRhdGlvbnMsXG4gICAgICAuLi5vcHRpb25zPy5tdXRhdGlvbktleSAmJiB0aGlzLmdldE11dGF0aW9uRGVmYXVsdHMob3B0aW9ucy5tdXRhdGlvbktleSksXG4gICAgICAuLi5vcHRpb25zLFxuICAgICAgX2RlZmF1bHRlZDogdHJ1ZVxuICAgIH07XG4gIH1cbiAgY2xlYXIoKSB7XG4gICAgdGhpcy4jcXVlcnlDYWNoZS5jbGVhcigpO1xuICAgIHRoaXMuI211dGF0aW9uQ2FjaGUuY2xlYXIoKTtcbiAgfVxufTtcbmV4cG9ydCB7XG4gIFF1ZXJ5Q2xpZW50XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cXVlcnlDbGllbnQuanMubWFwIiwiLy8gc3JjL3N0cmVhbWVkUXVlcnkudHNcbmltcG9ydCB7IGFkZENvbnN1bWVBd2FyZVNpZ25hbCwgYWRkVG9FbmQgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuZnVuY3Rpb24gc3RyZWFtZWRRdWVyeSh7XG4gIHN0cmVhbUZuLFxuICByZWZldGNoTW9kZSA9IFwicmVzZXRcIixcbiAgcmVkdWNlciA9IChpdGVtcywgY2h1bmspID0+IGFkZFRvRW5kKGl0ZW1zLCBjaHVuayksXG4gIGluaXRpYWxWYWx1ZSA9IFtdXG59KSB7XG4gIHJldHVybiBhc3luYyAoY29udGV4dCkgPT4ge1xuICAgIGNvbnN0IHF1ZXJ5ID0gY29udGV4dC5jbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmZpbmQoeyBxdWVyeUtleTogY29udGV4dC5xdWVyeUtleSwgZXhhY3Q6IHRydWUgfSk7XG4gICAgY29uc3QgaXNSZWZldGNoID0gISFxdWVyeSAmJiBxdWVyeS5pc0ZldGNoZWQoKTtcbiAgICBpZiAoaXNSZWZldGNoICYmIHJlZmV0Y2hNb2RlID09PSBcInJlc2V0XCIpIHtcbiAgICAgIHF1ZXJ5LnNldFN0YXRlKHtcbiAgICAgICAgLi4ucXVlcnkucmVzZXRTdGF0ZSxcbiAgICAgICAgZmV0Y2hTdGF0dXM6IFwiZmV0Y2hpbmdcIlxuICAgICAgfSk7XG4gICAgfVxuICAgIGxldCByZXN1bHQgPSBpbml0aWFsVmFsdWU7XG4gICAgbGV0IGNhbmNlbGxlZCA9IGZhbHNlO1xuICAgIGNvbnN0IHN0cmVhbUZuQ29udGV4dCA9IGFkZENvbnN1bWVBd2FyZVNpZ25hbChcbiAgICAgIHtcbiAgICAgICAgY2xpZW50OiBjb250ZXh0LmNsaWVudCxcbiAgICAgICAgbWV0YTogY29udGV4dC5tZXRhLFxuICAgICAgICBxdWVyeUtleTogY29udGV4dC5xdWVyeUtleSxcbiAgICAgICAgcGFnZVBhcmFtOiBjb250ZXh0LnBhZ2VQYXJhbSxcbiAgICAgICAgZGlyZWN0aW9uOiBjb250ZXh0LmRpcmVjdGlvblxuICAgICAgfSxcbiAgICAgICgpID0+IGNvbnRleHQuc2lnbmFsLFxuICAgICAgKCkgPT4gY2FuY2VsbGVkID0gdHJ1ZVxuICAgICk7XG4gICAgY29uc3Qgc3RyZWFtID0gYXdhaXQgc3RyZWFtRm4oc3RyZWFtRm5Db250ZXh0KTtcbiAgICBjb25zdCBpc1JlcGxhY2VSZWZldGNoID0gaXNSZWZldGNoICYmIHJlZmV0Y2hNb2RlID09PSBcInJlcGxhY2VcIjtcbiAgICBmb3IgYXdhaXQgKGNvbnN0IGNodW5rIG9mIHN0cmVhbSkge1xuICAgICAgaWYgKGNhbmNlbGxlZCkge1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGlmIChpc1JlcGxhY2VSZWZldGNoKSB7XG4gICAgICAgIHJlc3VsdCA9IHJlZHVjZXIocmVzdWx0LCBjaHVuayk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb250ZXh0LmNsaWVudC5zZXRRdWVyeURhdGEoXG4gICAgICAgICAgY29udGV4dC5xdWVyeUtleSxcbiAgICAgICAgICAocHJldikgPT4gcmVkdWNlcihwcmV2ID09PSB2b2lkIDAgPyBpbml0aWFsVmFsdWUgOiBwcmV2LCBjaHVuaylcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGlzUmVwbGFjZVJlZmV0Y2ggJiYgIWNhbmNlbGxlZCkge1xuICAgICAgY29udGV4dC5jbGllbnQuc2V0UXVlcnlEYXRhKGNvbnRleHQucXVlcnlLZXksIHJlc3VsdCk7XG4gICAgfVxuICAgIHJldHVybiBjb250ZXh0LmNsaWVudC5nZXRRdWVyeURhdGEoY29udGV4dC5xdWVyeUtleSkgPz8gaW5pdGlhbFZhbHVlO1xuICB9O1xufVxuZXhwb3J0IHtcbiAgc3RyZWFtZWRRdWVyeVxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXN0cmVhbWVkUXVlcnkuanMubWFwIiwiLy8gc3JjL3R5cGVzLnRzXG52YXIgZGF0YVRhZ1N5bWJvbCA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJkYXRhVGFnU3ltYm9sXCIpO1xudmFyIGRhdGFUYWdFcnJvclN5bWJvbCA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJkYXRhVGFnRXJyb3JTeW1ib2xcIik7XG52YXIgdW5zZXRNYXJrZXIgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sKFwidW5zZXRNYXJrZXJcIik7XG5leHBvcnQge1xuICBkYXRhVGFnRXJyb3JTeW1ib2wsXG4gIGRhdGFUYWdTeW1ib2wsXG4gIHVuc2V0TWFya2VyXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dHlwZXMuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5cbi8vIHNyYy9RdWVyeUNsaWVudFByb3ZpZGVyLnRzeFxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbnZhciBRdWVyeUNsaWVudENvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KFxuICB2b2lkIDBcbik7XG52YXIgdXNlUXVlcnlDbGllbnQgPSAocXVlcnlDbGllbnQpID0+IHtcbiAgY29uc3QgY2xpZW50ID0gUmVhY3QudXNlQ29udGV4dChRdWVyeUNsaWVudENvbnRleHQpO1xuICBpZiAocXVlcnlDbGllbnQpIHtcbiAgICByZXR1cm4gcXVlcnlDbGllbnQ7XG4gIH1cbiAgaWYgKCFjbGllbnQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJObyBRdWVyeUNsaWVudCBzZXQsIHVzZSBRdWVyeUNsaWVudFByb3ZpZGVyIHRvIHNldCBvbmVcIik7XG4gIH1cbiAgcmV0dXJuIGNsaWVudDtcbn07XG52YXIgUXVlcnlDbGllbnRQcm92aWRlciA9ICh7XG4gIGNsaWVudCxcbiAgY2hpbGRyZW5cbn0pID0+IHtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBjbGllbnQubW91bnQoKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgY2xpZW50LnVubW91bnQoKTtcbiAgICB9O1xuICB9LCBbY2xpZW50XSk7XG4gIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFF1ZXJ5Q2xpZW50Q29udGV4dC5Qcm92aWRlciwgeyB2YWx1ZTogY2xpZW50LCBjaGlsZHJlbiB9KTtcbn07XG5leHBvcnQge1xuICBRdWVyeUNsaWVudENvbnRleHQsXG4gIFF1ZXJ5Q2xpZW50UHJvdmlkZXIsXG4gIHVzZVF1ZXJ5Q2xpZW50XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9UXVlcnlDbGllbnRQcm92aWRlci5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcblxuLy8gc3JjL0lzUmVzdG9yaW5nUHJvdmlkZXIudHNcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xudmFyIElzUmVzdG9yaW5nQ29udGV4dCA9IFJlYWN0LmNyZWF0ZUNvbnRleHQoZmFsc2UpO1xudmFyIHVzZUlzUmVzdG9yaW5nID0gKCkgPT4gUmVhY3QudXNlQ29udGV4dChJc1Jlc3RvcmluZ0NvbnRleHQpO1xudmFyIElzUmVzdG9yaW5nUHJvdmlkZXIgPSBJc1Jlc3RvcmluZ0NvbnRleHQuUHJvdmlkZXI7XG5leHBvcnQge1xuICBJc1Jlc3RvcmluZ1Byb3ZpZGVyLFxuICB1c2VJc1Jlc3RvcmluZ1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUlzUmVzdG9yaW5nUHJvdmlkZXIuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5cbi8vIHNyYy9RdWVyeUVycm9yUmVzZXRCb3VuZGFyeS50c3hcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5mdW5jdGlvbiBjcmVhdGVWYWx1ZSgpIHtcbiAgbGV0IGlzUmVzZXQgPSBmYWxzZTtcbiAgcmV0dXJuIHtcbiAgICBjbGVhclJlc2V0OiAoKSA9PiB7XG4gICAgICBpc1Jlc2V0ID0gZmFsc2U7XG4gICAgfSxcbiAgICByZXNldDogKCkgPT4ge1xuICAgICAgaXNSZXNldCA9IHRydWU7XG4gICAgfSxcbiAgICBpc1Jlc2V0OiAoKSA9PiB7XG4gICAgICByZXR1cm4gaXNSZXNldDtcbiAgICB9XG4gIH07XG59XG52YXIgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnlDb250ZXh0ID0gUmVhY3QuY3JlYXRlQ29udGV4dChjcmVhdGVWYWx1ZSgpKTtcbnZhciB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSA9ICgpID0+IFJlYWN0LnVzZUNvbnRleHQoUXVlcnlFcnJvclJlc2V0Qm91bmRhcnlDb250ZXh0KTtcbnZhciBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSA9ICh7XG4gIGNoaWxkcmVuXG59KSA9PiB7XG4gIGNvbnN0IFt2YWx1ZV0gPSBSZWFjdC51c2VTdGF0ZSgoKSA9PiBjcmVhdGVWYWx1ZSgpKTtcbiAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goUXVlcnlFcnJvclJlc2V0Qm91bmRhcnlDb250ZXh0LlByb3ZpZGVyLCB7IHZhbHVlLCBjaGlsZHJlbjogdHlwZW9mIGNoaWxkcmVuID09PSBcImZ1bmN0aW9uXCIgPyBjaGlsZHJlbih2YWx1ZSkgOiBjaGlsZHJlbiB9KTtcbn07XG5leHBvcnQge1xuICBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSxcbiAgdXNlUXVlcnlFcnJvclJlc2V0Qm91bmRhcnlcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1RdWVyeUVycm9yUmVzZXRCb3VuZGFyeS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcblxuLy8gc3JjL2Vycm9yQm91bmRhcnlVdGlscy50c1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBzaG91bGRUaHJvd0Vycm9yIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG52YXIgZW5zdXJlUHJldmVudEVycm9yQm91bmRhcnlSZXRyeSA9IChvcHRpb25zLCBlcnJvclJlc2V0Qm91bmRhcnksIHF1ZXJ5KSA9PiB7XG4gIGNvbnN0IHRocm93T25FcnJvciA9IHF1ZXJ5Py5zdGF0ZS5lcnJvciAmJiB0eXBlb2Ygb3B0aW9ucy50aHJvd09uRXJyb3IgPT09IFwiZnVuY3Rpb25cIiA/IHNob3VsZFRocm93RXJyb3Iob3B0aW9ucy50aHJvd09uRXJyb3IsIFtxdWVyeS5zdGF0ZS5lcnJvciwgcXVlcnldKSA6IG9wdGlvbnMudGhyb3dPbkVycm9yO1xuICBpZiAob3B0aW9ucy5zdXNwZW5zZSB8fCBvcHRpb25zLmV4cGVyaW1lbnRhbF9wcmVmZXRjaEluUmVuZGVyIHx8IHRocm93T25FcnJvcikge1xuICAgIGlmICghZXJyb3JSZXNldEJvdW5kYXJ5LmlzUmVzZXQoKSkge1xuICAgICAgb3B0aW9ucy5yZXRyeU9uTW91bnQgPSBmYWxzZTtcbiAgICB9XG4gIH1cbn07XG52YXIgdXNlQ2xlYXJSZXNldEVycm9yQm91bmRhcnkgPSAoZXJyb3JSZXNldEJvdW5kYXJ5KSA9PiB7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZXJyb3JSZXNldEJvdW5kYXJ5LmNsZWFyUmVzZXQoKTtcbiAgfSwgW2Vycm9yUmVzZXRCb3VuZGFyeV0pO1xufTtcbnZhciBnZXRIYXNFcnJvciA9ICh7XG4gIHJlc3VsdCxcbiAgZXJyb3JSZXNldEJvdW5kYXJ5LFxuICB0aHJvd09uRXJyb3IsXG4gIHF1ZXJ5LFxuICBzdXNwZW5zZVxufSkgPT4ge1xuICByZXR1cm4gcmVzdWx0LmlzRXJyb3IgJiYgIWVycm9yUmVzZXRCb3VuZGFyeS5pc1Jlc2V0KCkgJiYgIXJlc3VsdC5pc0ZldGNoaW5nICYmIHF1ZXJ5ICYmIChzdXNwZW5zZSAmJiByZXN1bHQuZGF0YSA9PT0gdm9pZCAwIHx8IHNob3VsZFRocm93RXJyb3IodGhyb3dPbkVycm9yLCBbcmVzdWx0LmVycm9yLCBxdWVyeV0pKTtcbn07XG5leHBvcnQge1xuICBlbnN1cmVQcmV2ZW50RXJyb3JCb3VuZGFyeVJldHJ5LFxuICBnZXRIYXNFcnJvcixcbiAgdXNlQ2xlYXJSZXNldEVycm9yQm91bmRhcnlcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1lcnJvckJvdW5kYXJ5VXRpbHMuanMubWFwIiwiLy8gc3JjL3N1c3BlbnNlLnRzXG52YXIgZGVmYXVsdFRocm93T25FcnJvciA9IChfZXJyb3IsIHF1ZXJ5KSA9PiBxdWVyeS5zdGF0ZS5kYXRhID09PSB2b2lkIDA7XG52YXIgZW5zdXJlU3VzcGVuc2VUaW1lcnMgPSAoZGVmYXVsdGVkT3B0aW9ucykgPT4ge1xuICBpZiAoZGVmYXVsdGVkT3B0aW9ucy5zdXNwZW5zZSkge1xuICAgIGNvbnN0IE1JTl9TVVNQRU5TRV9USU1FX01TID0gMWUzO1xuICAgIGNvbnN0IGNsYW1wID0gKHZhbHVlKSA9PiB2YWx1ZSA9PT0gXCJzdGF0aWNcIiA/IHZhbHVlIDogTWF0aC5tYXgodmFsdWUgPz8gTUlOX1NVU1BFTlNFX1RJTUVfTVMsIE1JTl9TVVNQRU5TRV9USU1FX01TKTtcbiAgICBjb25zdCBvcmlnaW5hbFN0YWxlVGltZSA9IGRlZmF1bHRlZE9wdGlvbnMuc3RhbGVUaW1lO1xuICAgIGRlZmF1bHRlZE9wdGlvbnMuc3RhbGVUaW1lID0gdHlwZW9mIG9yaWdpbmFsU3RhbGVUaW1lID09PSBcImZ1bmN0aW9uXCIgPyAoLi4uYXJncykgPT4gY2xhbXAob3JpZ2luYWxTdGFsZVRpbWUoLi4uYXJncykpIDogY2xhbXAob3JpZ2luYWxTdGFsZVRpbWUpO1xuICAgIGlmICh0eXBlb2YgZGVmYXVsdGVkT3B0aW9ucy5nY1RpbWUgPT09IFwibnVtYmVyXCIpIHtcbiAgICAgIGRlZmF1bHRlZE9wdGlvbnMuZ2NUaW1lID0gTWF0aC5tYXgoXG4gICAgICAgIGRlZmF1bHRlZE9wdGlvbnMuZ2NUaW1lLFxuICAgICAgICBNSU5fU1VTUEVOU0VfVElNRV9NU1xuICAgICAgKTtcbiAgICB9XG4gIH1cbn07XG52YXIgd2lsbEZldGNoID0gKHJlc3VsdCwgaXNSZXN0b3JpbmcpID0+IHJlc3VsdC5pc0xvYWRpbmcgJiYgcmVzdWx0LmlzRmV0Y2hpbmcgJiYgIWlzUmVzdG9yaW5nO1xudmFyIHNob3VsZFN1c3BlbmQgPSAoZGVmYXVsdGVkT3B0aW9ucywgcmVzdWx0KSA9PiBkZWZhdWx0ZWRPcHRpb25zPy5zdXNwZW5zZSAmJiByZXN1bHQuaXNQZW5kaW5nO1xudmFyIGZldGNoT3B0aW1pc3RpYyA9IChkZWZhdWx0ZWRPcHRpb25zLCBvYnNlcnZlciwgZXJyb3JSZXNldEJvdW5kYXJ5KSA9PiBvYnNlcnZlci5mZXRjaE9wdGltaXN0aWMoZGVmYXVsdGVkT3B0aW9ucykuY2F0Y2goKCkgPT4ge1xuICBlcnJvclJlc2V0Qm91bmRhcnkuY2xlYXJSZXNldCgpO1xufSk7XG5leHBvcnQge1xuICBkZWZhdWx0VGhyb3dPbkVycm9yLFxuICBlbnN1cmVTdXNwZW5zZVRpbWVycyxcbiAgZmV0Y2hPcHRpbWlzdGljLFxuICBzaG91bGRTdXNwZW5kLFxuICB3aWxsRmV0Y2hcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1zdXNwZW5zZS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcblxuLy8gc3JjL3VzZVF1ZXJpZXMudHNcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHtcbiAgUXVlcmllc09ic2VydmVyLFxuICBRdWVyeU9ic2VydmVyLFxuICBub29wLFxuICBub3RpZnlNYW5hZ2VyXG59IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyB1c2VJc1Jlc3RvcmluZyB9IGZyb20gXCIuL0lzUmVzdG9yaW5nUHJvdmlkZXIuanNcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH0gZnJvbSBcIi4vUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkuanNcIjtcbmltcG9ydCB7XG4gIGVuc3VyZVByZXZlbnRFcnJvckJvdW5kYXJ5UmV0cnksXG4gIGdldEhhc0Vycm9yLFxuICB1c2VDbGVhclJlc2V0RXJyb3JCb3VuZGFyeVxufSBmcm9tIFwiLi9lcnJvckJvdW5kYXJ5VXRpbHMuanNcIjtcbmltcG9ydCB7XG4gIGVuc3VyZVN1c3BlbnNlVGltZXJzLFxuICBmZXRjaE9wdGltaXN0aWMsXG4gIHNob3VsZFN1c3BlbmRcbn0gZnJvbSBcIi4vc3VzcGVuc2UuanNcIjtcbmZ1bmN0aW9uIHVzZVF1ZXJpZXMoe1xuICBxdWVyaWVzLFxuICAuLi5vcHRpb25zXG59LCBxdWVyeUNsaWVudCkge1xuICBjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudChxdWVyeUNsaWVudCk7XG4gIGNvbnN0IGlzUmVzdG9yaW5nID0gdXNlSXNSZXN0b3JpbmcoKTtcbiAgY29uc3QgZXJyb3JSZXNldEJvdW5kYXJ5ID0gdXNlUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkoKTtcbiAgY29uc3QgZGVmYXVsdGVkUXVlcmllcyA9IFJlYWN0LnVzZU1lbW8oXG4gICAgKCkgPT4gcXVlcmllcy5tYXAoKG9wdHMpID0+IHtcbiAgICAgIGNvbnN0IGRlZmF1bHRlZE9wdGlvbnMgPSBjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhcbiAgICAgICAgb3B0c1xuICAgICAgKTtcbiAgICAgIGRlZmF1bHRlZE9wdGlvbnMuX29wdGltaXN0aWNSZXN1bHRzID0gaXNSZXN0b3JpbmcgPyBcImlzUmVzdG9yaW5nXCIgOiBcIm9wdGltaXN0aWNcIjtcbiAgICAgIHJldHVybiBkZWZhdWx0ZWRPcHRpb25zO1xuICAgIH0pLFxuICAgIFtxdWVyaWVzLCBjbGllbnQsIGlzUmVzdG9yaW5nXVxuICApO1xuICBkZWZhdWx0ZWRRdWVyaWVzLmZvckVhY2goKHF1ZXJ5T3B0aW9ucykgPT4ge1xuICAgIGVuc3VyZVN1c3BlbnNlVGltZXJzKHF1ZXJ5T3B0aW9ucyk7XG4gICAgY29uc3QgcXVlcnkgPSBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmdldChxdWVyeU9wdGlvbnMucXVlcnlIYXNoKTtcbiAgICBlbnN1cmVQcmV2ZW50RXJyb3JCb3VuZGFyeVJldHJ5KHF1ZXJ5T3B0aW9ucywgZXJyb3JSZXNldEJvdW5kYXJ5LCBxdWVyeSk7XG4gIH0pO1xuICB1c2VDbGVhclJlc2V0RXJyb3JCb3VuZGFyeShlcnJvclJlc2V0Qm91bmRhcnkpO1xuICBjb25zdCBbb2JzZXJ2ZXJdID0gUmVhY3QudXNlU3RhdGUoXG4gICAgKCkgPT4gbmV3IFF1ZXJpZXNPYnNlcnZlcihcbiAgICAgIGNsaWVudCxcbiAgICAgIGRlZmF1bHRlZFF1ZXJpZXMsXG4gICAgICBvcHRpb25zXG4gICAgKVxuICApO1xuICBjb25zdCBbb3B0aW1pc3RpY1Jlc3VsdCwgZ2V0Q29tYmluZWRSZXN1bHQsIHRyYWNrUmVzdWx0XSA9IG9ic2VydmVyLmdldE9wdGltaXN0aWNSZXN1bHQoXG4gICAgZGVmYXVsdGVkUXVlcmllcyxcbiAgICBvcHRpb25zLmNvbWJpbmVcbiAgKTtcbiAgY29uc3Qgc2hvdWxkU3Vic2NyaWJlID0gIWlzUmVzdG9yaW5nICYmIG9wdGlvbnMuc3Vic2NyaWJlZCAhPT0gZmFsc2U7XG4gIFJlYWN0LnVzZVN5bmNFeHRlcm5hbFN0b3JlKFxuICAgIFJlYWN0LnVzZUNhbGxiYWNrKFxuICAgICAgKG9uU3RvcmVDaGFuZ2UpID0+IHNob3VsZFN1YnNjcmliZSA/IG9ic2VydmVyLnN1YnNjcmliZShub3RpZnlNYW5hZ2VyLmJhdGNoQ2FsbHMob25TdG9yZUNoYW5nZSkpIDogbm9vcCxcbiAgICAgIFtvYnNlcnZlciwgc2hvdWxkU3Vic2NyaWJlXVxuICAgICksXG4gICAgKCkgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpLFxuICAgICgpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKVxuICApO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIG9ic2VydmVyLnNldFF1ZXJpZXMoXG4gICAgICBkZWZhdWx0ZWRRdWVyaWVzLFxuICAgICAgb3B0aW9uc1xuICAgICk7XG4gIH0sIFtkZWZhdWx0ZWRRdWVyaWVzLCBvcHRpb25zLCBvYnNlcnZlcl0pO1xuICBjb25zdCBzaG91bGRBdExlYXN0T25lU3VzcGVuZCA9IG9wdGltaXN0aWNSZXN1bHQuc29tZShcbiAgICAocmVzdWx0LCBpbmRleCkgPT4gc2hvdWxkU3VzcGVuZChkZWZhdWx0ZWRRdWVyaWVzW2luZGV4XSwgcmVzdWx0KVxuICApO1xuICBjb25zdCBzdXNwZW5zZVByb21pc2VzID0gc2hvdWxkQXRMZWFzdE9uZVN1c3BlbmQgPyBvcHRpbWlzdGljUmVzdWx0LmZsYXRNYXAoKHJlc3VsdCwgaW5kZXgpID0+IHtcbiAgICBjb25zdCBvcHRzID0gZGVmYXVsdGVkUXVlcmllc1tpbmRleF07XG4gICAgaWYgKG9wdHMgJiYgc2hvdWxkU3VzcGVuZChvcHRzLCByZXN1bHQpKSB7XG4gICAgICBjb25zdCBxdWVyeU9ic2VydmVyID0gbmV3IFF1ZXJ5T2JzZXJ2ZXIoY2xpZW50LCBvcHRzKTtcbiAgICAgIHJldHVybiBmZXRjaE9wdGltaXN0aWMob3B0cywgcXVlcnlPYnNlcnZlciwgZXJyb3JSZXNldEJvdW5kYXJ5KTtcbiAgICB9XG4gICAgcmV0dXJuIFtdO1xuICB9KSA6IFtdO1xuICBpZiAoc3VzcGVuc2VQcm9taXNlcy5sZW5ndGggPiAwKSB7XG4gICAgdGhyb3cgUHJvbWlzZS5hbGwoc3VzcGVuc2VQcm9taXNlcyk7XG4gIH1cbiAgY29uc3QgZmlyc3RTaW5nbGVSZXN1bHRXaGljaFNob3VsZFRocm93ID0gb3B0aW1pc3RpY1Jlc3VsdC5maW5kKFxuICAgIChyZXN1bHQsIGluZGV4KSA9PiB7XG4gICAgICBjb25zdCBxdWVyeSA9IGRlZmF1bHRlZFF1ZXJpZXNbaW5kZXhdO1xuICAgICAgcmV0dXJuIHF1ZXJ5ICYmIGdldEhhc0Vycm9yKHtcbiAgICAgICAgcmVzdWx0LFxuICAgICAgICBlcnJvclJlc2V0Qm91bmRhcnksXG4gICAgICAgIHRocm93T25FcnJvcjogcXVlcnkudGhyb3dPbkVycm9yLFxuICAgICAgICBxdWVyeTogY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5nZXQocXVlcnkucXVlcnlIYXNoKSxcbiAgICAgICAgc3VzcGVuc2U6IHF1ZXJ5LnN1c3BlbnNlXG4gICAgICB9KTtcbiAgICB9XG4gICk7XG4gIGlmIChmaXJzdFNpbmdsZVJlc3VsdFdoaWNoU2hvdWxkVGhyb3c/LmVycm9yKSB7XG4gICAgdGhyb3cgZmlyc3RTaW5nbGVSZXN1bHRXaGljaFNob3VsZFRocm93LmVycm9yO1xuICB9XG4gIHJldHVybiBnZXRDb21iaW5lZFJlc3VsdCh0cmFja1Jlc3VsdCgpKTtcbn1cbmV4cG9ydCB7XG4gIHVzZVF1ZXJpZXNcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VRdWVyaWVzLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuXG4vLyBzcmMvdXNlQmFzZVF1ZXJ5LnRzXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGVudmlyb25tZW50TWFuYWdlciwgbm9vcCwgbm90aWZ5TWFuYWdlciB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSB9IGZyb20gXCIuL1F1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LmpzXCI7XG5pbXBvcnQge1xuICBlbnN1cmVQcmV2ZW50RXJyb3JCb3VuZGFyeVJldHJ5LFxuICBnZXRIYXNFcnJvcixcbiAgdXNlQ2xlYXJSZXNldEVycm9yQm91bmRhcnlcbn0gZnJvbSBcIi4vZXJyb3JCb3VuZGFyeVV0aWxzLmpzXCI7XG5pbXBvcnQgeyB1c2VJc1Jlc3RvcmluZyB9IGZyb20gXCIuL0lzUmVzdG9yaW5nUHJvdmlkZXIuanNcIjtcbmltcG9ydCB7XG4gIGVuc3VyZVN1c3BlbnNlVGltZXJzLFxuICBmZXRjaE9wdGltaXN0aWMsXG4gIHNob3VsZFN1c3BlbmQsXG4gIHdpbGxGZXRjaFxufSBmcm9tIFwiLi9zdXNwZW5zZS5qc1wiO1xuZnVuY3Rpb24gdXNlQmFzZVF1ZXJ5KG9wdGlvbnMsIE9ic2VydmVyLCBxdWVyeUNsaWVudCkge1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgaWYgKHR5cGVvZiBvcHRpb25zICE9PSBcIm9iamVjdFwiIHx8IEFycmF5LmlzQXJyYXkob3B0aW9ucykpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgJ0JhZCBhcmd1bWVudCB0eXBlLiBTdGFydGluZyB3aXRoIHY1LCBvbmx5IHRoZSBcIk9iamVjdFwiIGZvcm0gaXMgYWxsb3dlZCB3aGVuIGNhbGxpbmcgcXVlcnkgcmVsYXRlZCBmdW5jdGlvbnMuIFBsZWFzZSB1c2UgdGhlIGVycm9yIHN0YWNrIHRvIGZpbmQgdGhlIGN1bHByaXQgY2FsbC4gTW9yZSBpbmZvIGhlcmU6IGh0dHBzOi8vdGFuc3RhY2suY29tL3F1ZXJ5L2xhdGVzdC9kb2NzL3JlYWN0L2d1aWRlcy9taWdyYXRpbmctdG8tdjUjc3VwcG9ydHMtYS1zaW5nbGUtc2lnbmF0dXJlLW9uZS1vYmplY3QnXG4gICAgICApO1xuICAgIH1cbiAgfVxuICBjb25zdCBpc1Jlc3RvcmluZyA9IHVzZUlzUmVzdG9yaW5nKCk7XG4gIGNvbnN0IGVycm9yUmVzZXRCb3VuZGFyeSA9IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5KCk7XG4gIGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KTtcbiAgY29uc3QgZGVmYXVsdGVkT3B0aW9ucyA9IGNsaWVudC5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuICBjbGllbnQuZ2V0RGVmYXVsdE9wdGlvbnMoKS5xdWVyaWVzPy5fZXhwZXJpbWVudGFsX2JlZm9yZVF1ZXJ5Py4oXG4gICAgZGVmYXVsdGVkT3B0aW9uc1xuICApO1xuICBjb25zdCBxdWVyeSA9IGNsaWVudC5nZXRRdWVyeUNhY2hlKCkuZ2V0KGRlZmF1bHRlZE9wdGlvbnMucXVlcnlIYXNoKTtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgIGlmICghZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUZuKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgWyR7ZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUhhc2h9XTogTm8gcXVlcnlGbiB3YXMgcGFzc2VkIGFzIGFuIG9wdGlvbiwgYW5kIG5vIGRlZmF1bHQgcXVlcnlGbiB3YXMgZm91bmQuIFRoZSBxdWVyeUZuIHBhcmFtZXRlciBpcyBvbmx5IG9wdGlvbmFsIHdoZW4gdXNpbmcgYSBkZWZhdWx0IHF1ZXJ5Rm4uIE1vcmUgaW5mbyBoZXJlOiBodHRwczovL3RhbnN0YWNrLmNvbS9xdWVyeS9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvZ3VpZGVzL2RlZmF1bHQtcXVlcnktZnVuY3Rpb25gXG4gICAgICApO1xuICAgIH1cbiAgfVxuICBjb25zdCBzdWJzY3JpYmVkID0gb3B0aW9ucy5zdWJzY3JpYmVkICE9PSBmYWxzZTtcbiAgZGVmYXVsdGVkT3B0aW9ucy5fb3B0aW1pc3RpY1Jlc3VsdHMgPSBpc1Jlc3RvcmluZyA/IFwiaXNSZXN0b3JpbmdcIiA6IHN1YnNjcmliZWQgPyBcIm9wdGltaXN0aWNcIiA6IHZvaWQgMDtcbiAgZW5zdXJlU3VzcGVuc2VUaW1lcnMoZGVmYXVsdGVkT3B0aW9ucyk7XG4gIGVuc3VyZVByZXZlbnRFcnJvckJvdW5kYXJ5UmV0cnkoZGVmYXVsdGVkT3B0aW9ucywgZXJyb3JSZXNldEJvdW5kYXJ5LCBxdWVyeSk7XG4gIHVzZUNsZWFyUmVzZXRFcnJvckJvdW5kYXJ5KGVycm9yUmVzZXRCb3VuZGFyeSk7XG4gIGNvbnN0IGlzTmV3Q2FjaGVFbnRyeSA9ICFjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmdldChkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5SGFzaCk7XG4gIGNvbnN0IFtvYnNlcnZlcl0gPSBSZWFjdC51c2VTdGF0ZShcbiAgICAoKSA9PiBuZXcgT2JzZXJ2ZXIoXG4gICAgICBjbGllbnQsXG4gICAgICBkZWZhdWx0ZWRPcHRpb25zXG4gICAgKVxuICApO1xuICBjb25zdCByZXN1bHQgPSBvYnNlcnZlci5nZXRPcHRpbWlzdGljUmVzdWx0KGRlZmF1bHRlZE9wdGlvbnMpO1xuICBjb25zdCBzaG91bGRTdWJzY3JpYmUgPSAhaXNSZXN0b3JpbmcgJiYgc3Vic2NyaWJlZDtcbiAgUmVhY3QudXNlU3luY0V4dGVybmFsU3RvcmUoXG4gICAgUmVhY3QudXNlQ2FsbGJhY2soXG4gICAgICAob25TdG9yZUNoYW5nZSkgPT4ge1xuICAgICAgICBjb25zdCB1bnN1YnNjcmliZSA9IHNob3VsZFN1YnNjcmliZSA/IG9ic2VydmVyLnN1YnNjcmliZShub3RpZnlNYW5hZ2VyLmJhdGNoQ2FsbHMob25TdG9yZUNoYW5nZSkpIDogbm9vcDtcbiAgICAgICAgb2JzZXJ2ZXIudXBkYXRlUmVzdWx0KCk7XG4gICAgICAgIHJldHVybiB1bnN1YnNjcmliZTtcbiAgICAgIH0sXG4gICAgICBbb2JzZXJ2ZXIsIHNob3VsZFN1YnNjcmliZV1cbiAgICApLFxuICAgICgpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKSxcbiAgICAoKSA9PiBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KClcbiAgKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBvYnNlcnZlci5zZXRPcHRpb25zKGRlZmF1bHRlZE9wdGlvbnMpO1xuICB9LCBbZGVmYXVsdGVkT3B0aW9ucywgb2JzZXJ2ZXJdKTtcbiAgaWYgKHNob3VsZFN1c3BlbmQoZGVmYXVsdGVkT3B0aW9ucywgcmVzdWx0KSkge1xuICAgIHRocm93IGZldGNoT3B0aW1pc3RpYyhkZWZhdWx0ZWRPcHRpb25zLCBvYnNlcnZlciwgZXJyb3JSZXNldEJvdW5kYXJ5KTtcbiAgfVxuICBpZiAoZ2V0SGFzRXJyb3Ioe1xuICAgIHJlc3VsdCxcbiAgICBlcnJvclJlc2V0Qm91bmRhcnksXG4gICAgdGhyb3dPbkVycm9yOiBkZWZhdWx0ZWRPcHRpb25zLnRocm93T25FcnJvcixcbiAgICBxdWVyeSxcbiAgICBzdXNwZW5zZTogZGVmYXVsdGVkT3B0aW9ucy5zdXNwZW5zZVxuICB9KSkge1xuICAgIHRocm93IHJlc3VsdC5lcnJvcjtcbiAgfVxuICA7XG4gIGNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLnF1ZXJpZXM/Ll9leHBlcmltZW50YWxfYWZ0ZXJRdWVyeT8uKFxuICAgIGRlZmF1bHRlZE9wdGlvbnMsXG4gICAgcmVzdWx0XG4gICk7XG4gIGlmIChkZWZhdWx0ZWRPcHRpb25zLmV4cGVyaW1lbnRhbF9wcmVmZXRjaEluUmVuZGVyICYmICFlbnZpcm9ubWVudE1hbmFnZXIuaXNTZXJ2ZXIoKSAmJiB3aWxsRmV0Y2gocmVzdWx0LCBpc1Jlc3RvcmluZykpIHtcbiAgICBjb25zdCBwcm9taXNlID0gaXNOZXdDYWNoZUVudHJ5ID8gKFxuICAgICAgLy8gRmV0Y2ggaW1tZWRpYXRlbHkgb24gcmVuZGVyIGluIG9yZGVyIHRvIGVuc3VyZSBgLnByb21pc2VgIGlzIHJlc29sdmVkIGV2ZW4gaWYgdGhlIGNvbXBvbmVudCBpcyB1bm1vdW50ZWRcbiAgICAgIGZldGNoT3B0aW1pc3RpYyhkZWZhdWx0ZWRPcHRpb25zLCBvYnNlcnZlciwgZXJyb3JSZXNldEJvdW5kYXJ5KVxuICAgICkgOiAoXG4gICAgICAvLyBzdWJzY3JpYmUgdG8gdGhlIFwiY2FjaGUgcHJvbWlzZVwiIHNvIHRoYXQgd2UgY2FuIGZpbmFsaXplIHRoZSBjdXJyZW50VGhlbmFibGUgb25jZSBkYXRhIGNvbWVzIGluXG4gICAgICBxdWVyeT8ucHJvbWlzZVxuICAgICk7XG4gICAgcHJvbWlzZT8uY2F0Y2gobm9vcCkuZmluYWxseSgoKSA9PiB7XG4gICAgICBvYnNlcnZlci51cGRhdGVSZXN1bHQoKTtcbiAgICB9KTtcbiAgfVxuICByZXR1cm4gIWRlZmF1bHRlZE9wdGlvbnMubm90aWZ5T25DaGFuZ2VQcm9wcyA/IG9ic2VydmVyLnRyYWNrUmVzdWx0KHJlc3VsdCkgOiByZXN1bHQ7XG59XG5leHBvcnQge1xuICB1c2VCYXNlUXVlcnlcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VCYXNlUXVlcnkuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5cbi8vIHNyYy91c2VRdWVyeS50c1xuaW1wb3J0IHsgUXVlcnlPYnNlcnZlciB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuaW1wb3J0IHsgdXNlQmFzZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlQmFzZVF1ZXJ5LmpzXCI7XG5mdW5jdGlvbiB1c2VRdWVyeShvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuICByZXR1cm4gdXNlQmFzZVF1ZXJ5KG9wdGlvbnMsIFF1ZXJ5T2JzZXJ2ZXIsIHF1ZXJ5Q2xpZW50KTtcbn1cbmV4cG9ydCB7XG4gIHVzZVF1ZXJ5XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlUXVlcnkuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5cbi8vIHNyYy91c2VTdXNwZW5zZVF1ZXJ5LnRzXG5pbXBvcnQgeyBRdWVyeU9ic2VydmVyLCBza2lwVG9rZW4gfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbmltcG9ydCB7IHVzZUJhc2VRdWVyeSB9IGZyb20gXCIuL3VzZUJhc2VRdWVyeS5qc1wiO1xuaW1wb3J0IHsgZGVmYXVsdFRocm93T25FcnJvciB9IGZyb20gXCIuL3N1c3BlbnNlLmpzXCI7XG5mdW5jdGlvbiB1c2VTdXNwZW5zZVF1ZXJ5KG9wdGlvbnMsIHF1ZXJ5Q2xpZW50KSB7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICBpZiAob3B0aW9ucy5xdWVyeUZuID09PSBza2lwVG9rZW4pIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJza2lwVG9rZW4gaXMgbm90IGFsbG93ZWQgZm9yIHVzZVN1c3BlbnNlUXVlcnlcIik7XG4gICAgfVxuICB9XG4gIHJldHVybiB1c2VCYXNlUXVlcnkoXG4gICAge1xuICAgICAgLi4ub3B0aW9ucyxcbiAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICBzdXNwZW5zZTogdHJ1ZSxcbiAgICAgIHRocm93T25FcnJvcjogZGVmYXVsdFRocm93T25FcnJvcixcbiAgICAgIHBsYWNlaG9sZGVyRGF0YTogdm9pZCAwXG4gICAgfSxcbiAgICBRdWVyeU9ic2VydmVyLFxuICAgIHF1ZXJ5Q2xpZW50XG4gICk7XG59XG5leHBvcnQge1xuICB1c2VTdXNwZW5zZVF1ZXJ5XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlU3VzcGVuc2VRdWVyeS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcblxuLy8gc3JjL3VzZVN1c3BlbnNlSW5maW5pdGVRdWVyeS50c1xuaW1wb3J0IHsgSW5maW5pdGVRdWVyeU9ic2VydmVyLCBza2lwVG9rZW4gfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbmltcG9ydCB7IHVzZUJhc2VRdWVyeSB9IGZyb20gXCIuL3VzZUJhc2VRdWVyeS5qc1wiO1xuaW1wb3J0IHsgZGVmYXVsdFRocm93T25FcnJvciB9IGZyb20gXCIuL3N1c3BlbnNlLmpzXCI7XG5mdW5jdGlvbiB1c2VTdXNwZW5zZUluZmluaXRlUXVlcnkob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgIGlmIChvcHRpb25zLnF1ZXJ5Rm4gPT09IHNraXBUb2tlbikge1xuICAgICAgY29uc29sZS5lcnJvcihcInNraXBUb2tlbiBpcyBub3QgYWxsb3dlZCBmb3IgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5XCIpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdXNlQmFzZVF1ZXJ5KFxuICAgIHtcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgc3VzcGVuc2U6IHRydWUsXG4gICAgICB0aHJvd09uRXJyb3I6IGRlZmF1bHRUaHJvd09uRXJyb3JcbiAgICB9LFxuICAgIEluZmluaXRlUXVlcnlPYnNlcnZlcixcbiAgICBxdWVyeUNsaWVudFxuICApO1xufVxuZXhwb3J0IHtcbiAgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5LmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuXG4vLyBzcmMvdXNlU3VzcGVuc2VRdWVyaWVzLnRzXG5pbXBvcnQgeyBza2lwVG9rZW4gfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbmltcG9ydCB7IHVzZVF1ZXJpZXMgfSBmcm9tIFwiLi91c2VRdWVyaWVzLmpzXCI7XG5pbXBvcnQgeyBkZWZhdWx0VGhyb3dPbkVycm9yIH0gZnJvbSBcIi4vc3VzcGVuc2UuanNcIjtcbmZ1bmN0aW9uIHVzZVN1c3BlbnNlUXVlcmllcyhvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuICByZXR1cm4gdXNlUXVlcmllcyhcbiAgICB7XG4gICAgICAuLi5vcHRpb25zLFxuICAgICAgcXVlcmllczogb3B0aW9ucy5xdWVyaWVzLm1hcCgocXVlcnkpID0+IHtcbiAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgICAgIGlmIChxdWVyeS5xdWVyeUZuID09PSBza2lwVG9rZW4pIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJza2lwVG9rZW4gaXMgbm90IGFsbG93ZWQgZm9yIHVzZVN1c3BlbnNlUXVlcmllc1wiKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAuLi5xdWVyeSxcbiAgICAgICAgICBzdXNwZW5zZTogdHJ1ZSxcbiAgICAgICAgICB0aHJvd09uRXJyb3I6IGRlZmF1bHRUaHJvd09uRXJyb3IsXG4gICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICBwbGFjZWhvbGRlckRhdGE6IHZvaWQgMFxuICAgICAgICB9O1xuICAgICAgfSlcbiAgICB9LFxuICAgIHF1ZXJ5Q2xpZW50XG4gICk7XG59XG5leHBvcnQge1xuICB1c2VTdXNwZW5zZVF1ZXJpZXNcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VTdXNwZW5zZVF1ZXJpZXMuanMubWFwIiwiLy8gc3JjL3VzZVByZWZldGNoUXVlcnkudHN4XG5pbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmZ1bmN0aW9uIHVzZVByZWZldGNoUXVlcnkob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcbiAgY29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuICBpZiAoIWNsaWVudC5nZXRRdWVyeVN0YXRlKG9wdGlvbnMucXVlcnlLZXkpKSB7XG4gICAgY2xpZW50LnByZWZldGNoUXVlcnkob3B0aW9ucyk7XG4gIH1cbn1cbmV4cG9ydCB7XG4gIHVzZVByZWZldGNoUXVlcnlcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VQcmVmZXRjaFF1ZXJ5LmpzLm1hcCIsIi8vIHNyYy91c2VQcmVmZXRjaEluZmluaXRlUXVlcnkudHN4XG5pbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmZ1bmN0aW9uIHVzZVByZWZldGNoSW5maW5pdGVRdWVyeShvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuICBjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudChxdWVyeUNsaWVudCk7XG4gIGlmICghY2xpZW50LmdldFF1ZXJ5U3RhdGUob3B0aW9ucy5xdWVyeUtleSkpIHtcbiAgICBjbGllbnQucHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5KG9wdGlvbnMpO1xuICB9XG59XG5leHBvcnQge1xuICB1c2VQcmVmZXRjaEluZmluaXRlUXVlcnlcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VQcmVmZXRjaEluZmluaXRlUXVlcnkuanMubWFwIiwiLy8gc3JjL3F1ZXJ5T3B0aW9ucy50c1xuZnVuY3Rpb24gcXVlcnlPcHRpb25zKG9wdGlvbnMpIHtcbiAgcmV0dXJuIG9wdGlvbnM7XG59XG5leHBvcnQge1xuICBxdWVyeU9wdGlvbnNcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1xdWVyeU9wdGlvbnMuanMubWFwIiwiLy8gc3JjL2luZmluaXRlUXVlcnlPcHRpb25zLnRzXG5mdW5jdGlvbiBpbmZpbml0ZVF1ZXJ5T3B0aW9ucyhvcHRpb25zKSB7XG4gIHJldHVybiBvcHRpb25zO1xufVxuZXhwb3J0IHtcbiAgaW5maW5pdGVRdWVyeU9wdGlvbnNcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmZpbml0ZVF1ZXJ5T3B0aW9ucy5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcblxuLy8gc3JjL0h5ZHJhdGlvbkJvdW5kYXJ5LnRzeFxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBoeWRyYXRlIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG5pbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbnZhciBIeWRyYXRpb25Cb3VuZGFyeSA9ICh7XG4gIGNoaWxkcmVuLFxuICBvcHRpb25zID0ge30sXG4gIHN0YXRlLFxuICBxdWVyeUNsaWVudFxufSkgPT4ge1xuICBjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudChxdWVyeUNsaWVudCk7XG4gIGNvbnN0IG9wdGlvbnNSZWYgPSBSZWFjdC51c2VSZWYob3B0aW9ucyk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgb3B0aW9uc1JlZi5jdXJyZW50ID0gb3B0aW9ucztcbiAgfSk7XG4gIGNvbnN0IGh5ZHJhdGlvblF1ZXVlID0gUmVhY3QudXNlTWVtbygoKSA9PiB7XG4gICAgaWYgKHN0YXRlKSB7XG4gICAgICBpZiAodHlwZW9mIHN0YXRlICE9PSBcIm9iamVjdFwiKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpO1xuICAgICAgY29uc3QgcXVlcmllcyA9IHN0YXRlLnF1ZXJpZXMgfHwgW107XG4gICAgICBjb25zdCBuZXdRdWVyaWVzID0gW107XG4gICAgICBjb25zdCBleGlzdGluZ1F1ZXJpZXMgPSBbXTtcbiAgICAgIGZvciAoY29uc3QgZGVoeWRyYXRlZFF1ZXJ5IG9mIHF1ZXJpZXMpIHtcbiAgICAgICAgY29uc3QgZXhpc3RpbmdRdWVyeSA9IHF1ZXJ5Q2FjaGUuZ2V0KGRlaHlkcmF0ZWRRdWVyeS5xdWVyeUhhc2gpO1xuICAgICAgICBpZiAoIWV4aXN0aW5nUXVlcnkpIHtcbiAgICAgICAgICBuZXdRdWVyaWVzLnB1c2goZGVoeWRyYXRlZFF1ZXJ5KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zdCBoeWRyYXRpb25Jc05ld2VyID0gZGVoeWRyYXRlZFF1ZXJ5LnN0YXRlLmRhdGFVcGRhdGVkQXQgPiBleGlzdGluZ1F1ZXJ5LnN0YXRlLmRhdGFVcGRhdGVkQXQgfHwgZGVoeWRyYXRlZFF1ZXJ5LnByb21pc2UgJiYgZXhpc3RpbmdRdWVyeS5zdGF0ZS5zdGF0dXMgIT09IFwicGVuZGluZ1wiICYmIGV4aXN0aW5nUXVlcnkuc3RhdGUuZmV0Y2hTdGF0dXMgIT09IFwiZmV0Y2hpbmdcIiAmJiBkZWh5ZHJhdGVkUXVlcnkuZGVoeWRyYXRlZEF0ICE9PSB2b2lkIDAgJiYgZGVoeWRyYXRlZFF1ZXJ5LmRlaHlkcmF0ZWRBdCA+IGV4aXN0aW5nUXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdDtcbiAgICAgICAgICBpZiAoaHlkcmF0aW9uSXNOZXdlcikge1xuICAgICAgICAgICAgZXhpc3RpbmdRdWVyaWVzLnB1c2goZGVoeWRyYXRlZFF1ZXJ5KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChuZXdRdWVyaWVzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgaHlkcmF0ZShjbGllbnQsIHsgcXVlcmllczogbmV3UXVlcmllcyB9LCBvcHRpb25zUmVmLmN1cnJlbnQpO1xuICAgICAgfVxuICAgICAgaWYgKGV4aXN0aW5nUXVlcmllcy5sZW5ndGggPiAwKSB7XG4gICAgICAgIHJldHVybiBleGlzdGluZ1F1ZXJpZXM7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB2b2lkIDA7XG4gIH0sIFtjbGllbnQsIHN0YXRlXSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGh5ZHJhdGlvblF1ZXVlKSB7XG4gICAgICBoeWRyYXRlKGNsaWVudCwgeyBxdWVyaWVzOiBoeWRyYXRpb25RdWV1ZSB9LCBvcHRpb25zUmVmLmN1cnJlbnQpO1xuICAgIH1cbiAgfSwgW2NsaWVudCwgaHlkcmF0aW9uUXVldWVdKTtcbiAgcmV0dXJuIGNoaWxkcmVuO1xufTtcbmV4cG9ydCB7XG4gIEh5ZHJhdGlvbkJvdW5kYXJ5XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9SHlkcmF0aW9uQm91bmRhcnkuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5cbi8vIHNyYy91c2VJc0ZldGNoaW5nLnRzXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIi4vUXVlcnlDbGllbnRQcm92aWRlci5qc1wiO1xuZnVuY3Rpb24gdXNlSXNGZXRjaGluZyhmaWx0ZXJzLCBxdWVyeUNsaWVudCkge1xuICBjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudChxdWVyeUNsaWVudCk7XG4gIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpO1xuICByZXR1cm4gUmVhY3QudXNlU3luY0V4dGVybmFsU3RvcmUoXG4gICAgUmVhY3QudXNlQ2FsbGJhY2soXG4gICAgICAob25TdG9yZUNoYW5nZSkgPT4gcXVlcnlDYWNoZS5zdWJzY3JpYmUobm90aWZ5TWFuYWdlci5iYXRjaENhbGxzKG9uU3RvcmVDaGFuZ2UpKSxcbiAgICAgIFtxdWVyeUNhY2hlXVxuICAgICksXG4gICAgKCkgPT4gY2xpZW50LmlzRmV0Y2hpbmcoZmlsdGVycyksXG4gICAgKCkgPT4gY2xpZW50LmlzRmV0Y2hpbmcoZmlsdGVycylcbiAgKTtcbn1cbmV4cG9ydCB7XG4gIHVzZUlzRmV0Y2hpbmdcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VJc0ZldGNoaW5nLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuXG4vLyBzcmMvdXNlTXV0YXRpb25TdGF0ZS50c1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyLCByZXBsYWNlRXF1YWxEZWVwIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG5pbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmZ1bmN0aW9uIHVzZUlzTXV0YXRpbmcoZmlsdGVycywgcXVlcnlDbGllbnQpIHtcbiAgY29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuICByZXR1cm4gdXNlTXV0YXRpb25TdGF0ZShcbiAgICB7IGZpbHRlcnM6IHsgLi4uZmlsdGVycywgc3RhdHVzOiBcInBlbmRpbmdcIiB9IH0sXG4gICAgY2xpZW50XG4gICkubGVuZ3RoO1xufVxuZnVuY3Rpb24gZ2V0UmVzdWx0KG11dGF0aW9uQ2FjaGUsIG9wdGlvbnMpIHtcbiAgcmV0dXJuIG11dGF0aW9uQ2FjaGUuZmluZEFsbChvcHRpb25zLmZpbHRlcnMpLm1hcChcbiAgICAobXV0YXRpb24pID0+IG9wdGlvbnMuc2VsZWN0ID8gb3B0aW9ucy5zZWxlY3QobXV0YXRpb24pIDogbXV0YXRpb24uc3RhdGVcbiAgKTtcbn1cbmZ1bmN0aW9uIHVzZU11dGF0aW9uU3RhdGUob3B0aW9ucyA9IHt9LCBxdWVyeUNsaWVudCkge1xuICBjb25zdCBtdXRhdGlvbkNhY2hlID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpLmdldE11dGF0aW9uQ2FjaGUoKTtcbiAgY29uc3Qgb3B0aW9uc1JlZiA9IFJlYWN0LnVzZVJlZihvcHRpb25zKTtcbiAgY29uc3QgcmVzdWx0ID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBpZiAocmVzdWx0LmN1cnJlbnQgPT09IG51bGwpIHtcbiAgICByZXN1bHQuY3VycmVudCA9IGdldFJlc3VsdChtdXRhdGlvbkNhY2hlLCBvcHRpb25zKTtcbiAgfVxuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIG9wdGlvbnNSZWYuY3VycmVudCA9IG9wdGlvbnM7XG4gIH0pO1xuICByZXR1cm4gUmVhY3QudXNlU3luY0V4dGVybmFsU3RvcmUoXG4gICAgUmVhY3QudXNlQ2FsbGJhY2soXG4gICAgICAob25TdG9yZUNoYW5nZSkgPT4gbXV0YXRpb25DYWNoZS5zdWJzY3JpYmUoKCkgPT4ge1xuICAgICAgICBjb25zdCBuZXh0UmVzdWx0ID0gcmVwbGFjZUVxdWFsRGVlcChcbiAgICAgICAgICByZXN1bHQuY3VycmVudCxcbiAgICAgICAgICBnZXRSZXN1bHQobXV0YXRpb25DYWNoZSwgb3B0aW9uc1JlZi5jdXJyZW50KVxuICAgICAgICApO1xuICAgICAgICBpZiAocmVzdWx0LmN1cnJlbnQgIT09IG5leHRSZXN1bHQpIHtcbiAgICAgICAgICByZXN1bHQuY3VycmVudCA9IG5leHRSZXN1bHQ7XG4gICAgICAgICAgbm90aWZ5TWFuYWdlci5zY2hlZHVsZShvblN0b3JlQ2hhbmdlKTtcbiAgICAgICAgfVxuICAgICAgfSksXG4gICAgICBbbXV0YXRpb25DYWNoZV1cbiAgICApLFxuICAgICgpID0+IHJlc3VsdC5jdXJyZW50LFxuICAgICgpID0+IHJlc3VsdC5jdXJyZW50XG4gICk7XG59XG5leHBvcnQge1xuICB1c2VJc011dGF0aW5nLFxuICB1c2VNdXRhdGlvblN0YXRlXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlTXV0YXRpb25TdGF0ZS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcblxuLy8gc3JjL3VzZU11dGF0aW9uLnRzXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7XG4gIE11dGF0aW9uT2JzZXJ2ZXIsXG4gIG5vb3AsXG4gIG5vdGlmeU1hbmFnZXIsXG4gIHNob3VsZFRocm93RXJyb3Jcbn0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG5pbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmZ1bmN0aW9uIHVzZU11dGF0aW9uKG9wdGlvbnMsIHF1ZXJ5Q2xpZW50KSB7XG4gIGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KTtcbiAgY29uc3QgW29ic2VydmVyXSA9IFJlYWN0LnVzZVN0YXRlKFxuICAgICgpID0+IG5ldyBNdXRhdGlvbk9ic2VydmVyKFxuICAgICAgY2xpZW50LFxuICAgICAgb3B0aW9uc1xuICAgIClcbiAgKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBvYnNlcnZlci5zZXRPcHRpb25zKG9wdGlvbnMpO1xuICB9LCBbb2JzZXJ2ZXIsIG9wdGlvbnNdKTtcbiAgY29uc3QgcmVzdWx0ID0gUmVhY3QudXNlU3luY0V4dGVybmFsU3RvcmUoXG4gICAgUmVhY3QudXNlQ2FsbGJhY2soXG4gICAgICAob25TdG9yZUNoYW5nZSkgPT4gb2JzZXJ2ZXIuc3Vic2NyaWJlKG5vdGlmeU1hbmFnZXIuYmF0Y2hDYWxscyhvblN0b3JlQ2hhbmdlKSksXG4gICAgICBbb2JzZXJ2ZXJdXG4gICAgKSxcbiAgICAoKSA9PiBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KCksXG4gICAgKCkgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpXG4gICk7XG4gIGNvbnN0IG11dGF0ZSA9IFJlYWN0LnVzZUNhbGxiYWNrKFxuICAgICh2YXJpYWJsZXMsIG11dGF0ZU9wdGlvbnMpID0+IHtcbiAgICAgIG9ic2VydmVyLm11dGF0ZSh2YXJpYWJsZXMsIG11dGF0ZU9wdGlvbnMpLmNhdGNoKG5vb3ApO1xuICAgIH0sXG4gICAgW29ic2VydmVyXVxuICApO1xuICBpZiAocmVzdWx0LmVycm9yICYmIHNob3VsZFRocm93RXJyb3Iob2JzZXJ2ZXIub3B0aW9ucy50aHJvd09uRXJyb3IsIFtyZXN1bHQuZXJyb3JdKSkge1xuICAgIHRocm93IHJlc3VsdC5lcnJvcjtcbiAgfVxuICByZXR1cm4geyAuLi5yZXN1bHQsIG11dGF0ZSwgbXV0YXRlQXN5bmM6IHJlc3VsdC5tdXRhdGUgfTtcbn1cbmV4cG9ydCB7XG4gIHVzZU11dGF0aW9uXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlTXV0YXRpb24uanMubWFwIiwiLy8gc3JjL211dGF0aW9uT3B0aW9ucy50c1xuZnVuY3Rpb24gbXV0YXRpb25PcHRpb25zKG9wdGlvbnMpIHtcbiAgcmV0dXJuIG9wdGlvbnM7XG59XG5leHBvcnQge1xuICBtdXRhdGlvbk9wdGlvbnNcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1tdXRhdGlvbk9wdGlvbnMuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5cbi8vIHNyYy91c2VJbmZpbml0ZVF1ZXJ5LnRzXG5pbXBvcnQgeyBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbmltcG9ydCB7IHVzZUJhc2VRdWVyeSB9IGZyb20gXCIuL3VzZUJhc2VRdWVyeS5qc1wiO1xuZnVuY3Rpb24gdXNlSW5maW5pdGVRdWVyeShvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuICByZXR1cm4gdXNlQmFzZVF1ZXJ5KFxuICAgIG9wdGlvbnMsXG4gICAgSW5maW5pdGVRdWVyeU9ic2VydmVyLFxuICAgIHF1ZXJ5Q2xpZW50XG4gICk7XG59XG5leHBvcnQge1xuICB1c2VJbmZpbml0ZVF1ZXJ5XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlSW5maW5pdGVRdWVyeS5qcy5tYXAiXSwibWFwcGluZ3MiOiI7Ozs7QUFDQSxJQUFJLGVBQWUsTUFBTTtDQUN2QixjQUFjO0VBQ1osS0FBSyw0QkFBNEIsSUFBSSxJQUFJO0VBQ3pDLEtBQUssWUFBWSxLQUFLLFVBQVUsS0FBSyxJQUFJO0NBQzNDO0NBQ0EsVUFBVSxVQUFVO0VBQ2xCLEtBQUssVUFBVSxJQUFJLFFBQVE7RUFDM0IsS0FBSyxZQUFZO0VBQ2pCLGFBQWE7R0FDWCxLQUFLLFVBQVUsT0FBTyxRQUFRO0dBQzlCLEtBQUssY0FBYztFQUNyQjtDQUNGO0NBQ0EsZUFBZTtFQUNiLE9BQU8sS0FBSyxVQUFVLE9BQU87Q0FDL0I7Q0FDQSxjQUFjLENBQ2Q7Q0FDQSxnQkFBZ0IsQ0FDaEI7QUFDRjs7O0FDbkJBLElBQUksZUFBZSxjQUFjLGFBQWE7Q0FDNUM7Q0FDQTtDQUNBO0NBQ0EsY0FBYztFQUNaLE1BQU07RUFDTixLQUFLQSxVQUFVLFlBQVk7R0FDekIsSUFBSSxPQUFPLFdBQVcsZUFBZSxPQUFPLGtCQUFrQjtJQUM1RCxNQUFNLGlCQUFpQixRQUFRO0lBQy9CLE9BQU8saUJBQWlCLG9CQUFvQixVQUFVLEtBQUs7SUFDM0QsYUFBYTtLQUNYLE9BQU8sb0JBQW9CLG9CQUFvQixRQUFRO0lBQ3pEO0dBQ0Y7RUFFRjtDQUNGO0NBQ0EsY0FBYztFQUNaLElBQUksQ0FBQyxLQUFLQyxVQUNSLEtBQUssaUJBQWlCLEtBQUtELE1BQU07Q0FFckM7Q0FDQSxnQkFBZ0I7RUFDZCxJQUFJLENBQUMsS0FBSyxhQUFhLEdBQUc7R0FDeEIsS0FBS0MsV0FBVztHQUNoQixLQUFLQSxXQUFXLEtBQUs7RUFDdkI7Q0FDRjtDQUNBLGlCQUFpQixPQUFPO0VBQ3RCLEtBQUtELFNBQVM7RUFDZCxLQUFLQyxXQUFXO0VBQ2hCLEtBQUtBLFdBQVcsT0FBTyxZQUFZO0dBQ2pDLElBQUksT0FBTyxZQUFZLFdBQ3JCLEtBQUssV0FBVyxPQUFPO1FBRXZCLEtBQUssUUFBUTtFQUVqQixDQUFDO0NBQ0g7Q0FDQSxXQUFXLFNBQVM7RUFFbEIsSUFEZ0IsS0FBS0MsYUFBYSxTQUNyQjtHQUNYLEtBQUtBLFdBQVc7R0FDaEIsS0FBSyxRQUFRO0VBQ2Y7Q0FDRjtDQUNBLFVBQVU7RUFDUixNQUFNLFlBQVksS0FBSyxVQUFVO0VBQ2pDLEtBQUssVUFBVSxTQUFTLGFBQWE7R0FDbkMsU0FBUyxTQUFTO0VBQ3BCLENBQUM7Q0FDSDtDQUNBLFlBQVk7RUFDVixJQUFJLE9BQU8sS0FBS0EsYUFBYSxXQUMzQixPQUFPLEtBQUtBO0VBRWQsT0FBTyxXQUFXLFVBQVUsb0JBQW9CO0NBQ2xEO0FBQ0Y7QUFDQSxJQUFJLGVBQWUsSUFBSSxhQUFhOzs7QUM1RHBDLElBQUkseUJBQXlCO0NBVzNCLGFBQWEsVUFBVSxVQUFVLFdBQVcsVUFBVSxLQUFLO0NBQzNELGVBQWUsY0FBYyxhQUFhLFNBQVM7Q0FDbkQsY0FBYyxVQUFVLFVBQVUsWUFBWSxVQUFVLEtBQUs7Q0FDN0QsZ0JBQWdCLGVBQWUsY0FBYyxVQUFVO0FBQ3pEO0FBQ0EsSUFBSSxpQkFBaUIsTUFBTTtDQVF6QixZQUFZO0NBQ1osa0JBQWtCO0NBQ2xCLG1CQUFtQixVQUFVO0VBRXpCLElBQUksS0FBS0MsbUJBQW1CLGFBQWEsS0FBS0MsV0FDNUMsUUFBUSxNQUNOLDhHQUNBO0dBQUUsVUFBVSxLQUFLQTtHQUFXO0VBQVMsQ0FDdkM7RUFHSixLQUFLQSxZQUFZO0VBRWYsS0FBS0Qsa0JBQWtCO0NBRTNCO0NBQ0EsV0FBVyxVQUFVLE9BQU87RUFFeEIsS0FBS0Esa0JBQWtCO0VBRXpCLE9BQU8sS0FBS0MsVUFBVSxXQUFXLFVBQVUsS0FBSztDQUNsRDtDQUNBLGFBQWEsV0FBVztFQUN0QixLQUFLQSxVQUFVLGFBQWEsU0FBUztDQUN2QztDQUNBLFlBQVksVUFBVSxPQUFPO0VBRXpCLEtBQUtELGtCQUFrQjtFQUV6QixPQUFPLEtBQUtDLFVBQVUsWUFBWSxVQUFVLEtBQUs7Q0FDbkQ7Q0FDQSxjQUFjLFlBQVk7RUFDeEIsS0FBS0EsVUFBVSxjQUFjLFVBQVU7Q0FDekM7QUFDRjtBQUNBLElBQUksaUJBQWlCLElBQUksZUFBZTtBQUN4QyxTQUFTLHFCQUFxQixVQUFVO0NBQ3RDLFdBQVcsVUFBVSxDQUFDO0FBQ3hCOzs7QUM3REEsSUFBSSxXQUFXLE9BQU8sV0FBVyxlQUFlLFVBQVU7QUFDMUQsU0FBUyxPQUFPLENBQ2hCO0FBQ0EsU0FBUyxpQkFBaUIsU0FBUyxPQUFPO0NBQ3hDLE9BQU8sT0FBTyxZQUFZLGFBQWEsUUFBUSxLQUFLLElBQUk7QUFDMUQ7QUFDQSxTQUFTLGVBQWUsT0FBTztDQUM3QixPQUFPLE9BQU8sVUFBVSxZQUFZLFNBQVMsS0FBSyxVQUFVO0FBQzlEO0FBQ0EsU0FBUyxlQUFlLFdBQVcsV0FBVztDQUM1QyxPQUFPLEtBQUssSUFBSSxhQUFhLGFBQWEsS0FBSyxLQUFLLElBQUksR0FBRyxDQUFDO0FBQzlEO0FBQ0EsU0FBUyxpQkFBaUIsV0FBVyxPQUFPO0NBQzFDLE9BQU8sT0FBTyxjQUFjLGFBQWEsVUFBVSxLQUFLLElBQUk7QUFDOUQ7QUFDQSxTQUFTLG9CQUFvQixRQUFRLE9BQU87Q0FDMUMsT0FBTyxPQUFPLFdBQVcsYUFBYSxPQUFPLEtBQUssSUFBSTtBQUN4RDtBQUNBLFNBQVMsV0FBVyxTQUFTLE9BQU87Q0FDbEMsTUFBTSxFQUNKLE9BQU8sT0FDUCxPQUNBLGFBQ0EsV0FDQSxVQUNBLFVBQ0U7Q0FDSixJQUFJLFVBQVU7RUFDWixJQUFJLE9BQ0U7T0FBQSxNQUFNLGNBQWMsc0JBQXNCLFVBQVUsTUFBTSxPQUFPLEdBQ25FLE9BQU87RUFBQSxPQUVKLElBQUksQ0FBQyxnQkFBZ0IsTUFBTSxVQUFVLFFBQVEsR0FDbEQsT0FBTztDQUVYO0NBQ0EsSUFBSSxTQUFTLE9BQU87RUFDbEIsTUFBTSxXQUFXLE1BQU0sU0FBUztFQUNoQyxJQUFJLFNBQVMsWUFBWSxDQUFDLFVBQ3hCLE9BQU87RUFFVCxJQUFJLFNBQVMsY0FBYyxVQUN6QixPQUFPO0NBRVg7Q0FDQSxJQUFJLE9BQU8sVUFBVSxhQUFhLE1BQU0sUUFBUSxNQUFNLE9BQ3BELE9BQU87Q0FFVCxJQUFJLGVBQWUsZ0JBQWdCLE1BQU0sTUFBTSxhQUM3QyxPQUFPO0NBRVQsSUFBSSxhQUFhLENBQUMsVUFBVSxLQUFLLEdBQy9CLE9BQU87Q0FFVCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGNBQWMsU0FBUyxVQUFVO0NBQ3hDLE1BQU0sRUFBRSxPQUFPLFFBQVEsV0FBVyxnQkFBZ0I7Q0FDbEQsSUFBSSxhQUFhO0VBQ2YsSUFBSSxDQUFDLFNBQVMsUUFBUSxhQUNwQixPQUFPO0VBRVQsSUFBSSxPQUNFO09BQUEsUUFBUSxTQUFTLFFBQVEsV0FBVyxNQUFNLFFBQVEsV0FBVyxHQUMvRCxPQUFPO0VBQUEsT0FFSixJQUFJLENBQUMsZ0JBQWdCLFNBQVMsUUFBUSxhQUFhLFdBQVcsR0FDbkUsT0FBTztDQUVYO0NBQ0EsSUFBSSxVQUFVLFNBQVMsTUFBTSxXQUFXLFFBQ3RDLE9BQU87Q0FFVCxJQUFJLGFBQWEsQ0FBQyxVQUFVLFFBQVEsR0FDbEMsT0FBTztDQUVULE9BQU87QUFDVDtBQUNBLFNBQVMsc0JBQXNCLFVBQVUsU0FBUztDQUVoRCxRQURlLFNBQVMsa0JBQWtCLFFBQUEsQ0FDNUIsUUFBUTtBQUN4QjtBQUNBLFNBQVMsUUFBUSxVQUFVO0NBQ3pCLE9BQU8sS0FBSyxVQUNWLFdBQ0MsR0FBRyxRQUFRLGNBQWMsR0FBRyxJQUFJLE9BQU8sS0FBSyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLFFBQVEsUUFBUTtFQUMvRSxPQUFPLE9BQU8sSUFBSTtFQUNsQixPQUFPO0NBQ1QsR0FBRyxDQUFDLENBQUMsSUFBSSxHQUNYO0FBQ0Y7QUFDQSxTQUFTLGdCQUFnQixHQUFHLEdBQUc7Q0FDN0IsSUFBSSxNQUFNLEdBQ1IsT0FBTztDQUVULElBQUksT0FBTyxNQUFNLE9BQU8sR0FDdEIsT0FBTztDQUVULElBQUksS0FBSyxLQUFLLE9BQU8sTUFBTSxZQUFZLE9BQU8sTUFBTSxVQUFVO0VBQzVELElBQUksTUFBTSxRQUFRLENBQUMsS0FBSyxNQUFNLFFBQVEsQ0FBQyxHQUFHO0dBQ3hDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FDNUIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLElBQUksRUFBRSxFQUFFLEdBQzdCLE9BQU87R0FHWCxPQUFPO0VBQ1Q7RUFDQSxNQUFNLFFBQVEsT0FBTyxLQUFLLENBQUM7RUFDM0IsS0FBSyxNQUFNLE9BQU8sT0FDaEIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLE1BQU0sRUFBRSxJQUFJLEdBQ2pDLE9BQU87RUFHWCxPQUFPO0NBQ1Q7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxJQUFJLFNBQVMsT0FBTyxVQUFVO0FBQzlCLFNBQVMsaUJBQWlCLEdBQUcsR0FBRyxRQUFRLEdBQUc7Q0FDekMsSUFBSSxNQUFNLEdBQ1IsT0FBTztDQUVULElBQUksUUFBUSxLQUFLLE9BQU87Q0FDeEIsTUFBTSxRQUFRLGFBQWEsQ0FBQyxLQUFLLGFBQWEsQ0FBQztDQUMvQyxJQUFJLENBQUMsU0FBUyxFQUFFLGNBQWMsQ0FBQyxLQUFLLGNBQWMsQ0FBQyxJQUFJLE9BQU87Q0FFOUQsTUFBTSxTQURTLFFBQVEsSUFBSSxPQUFPLEtBQUssQ0FBQyxFQUFBLENBQ25CO0NBQ3JCLE1BQU0sU0FBUyxRQUFRLElBQUksT0FBTyxLQUFLLENBQUM7Q0FDeEMsTUFBTSxRQUFRLE9BQU87Q0FDckIsTUFBTSxPQUFPLFFBQVEsSUFBSSxNQUFNLEtBQUssSUFBSSxDQUFDO0NBQ3pDLElBQUksYUFBYTtDQUNqQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxLQUFLO0VBQzlCLE1BQU0sTUFBTSxRQUFRLElBQUksT0FBTztFQUMvQixNQUFNLFFBQVEsRUFBRTtFQUNoQixNQUFNLFFBQVEsRUFBRTtFQUNoQixJQUFJLFVBQVUsT0FBTztHQUNuQixLQUFLLE9BQU87R0FDWixJQUFJLFFBQVEsSUFBSSxRQUFRLE9BQU8sS0FBSyxHQUFHLEdBQUcsR0FBRztHQUM3QztFQUNGO0VBQ0EsSUFBSSxVQUFVLFFBQVEsVUFBVSxRQUFRLE9BQU8sVUFBVSxZQUFZLE9BQU8sVUFBVSxVQUFVO0dBQzlGLEtBQUssT0FBTztHQUNaO0VBQ0Y7RUFDQSxNQUFNLElBQUksaUJBQWlCLE9BQU8sT0FBTyxRQUFRLENBQUM7RUFDbEQsS0FBSyxPQUFPO0VBQ1osSUFBSSxNQUFNLE9BQU87Q0FDbkI7Q0FDQSxPQUFPLFVBQVUsU0FBUyxlQUFlLFFBQVEsSUFBSTtBQUN2RDtBQUNBLFNBQVMsb0JBQW9CLEdBQUcsR0FBRztDQUNqQyxJQUFJLENBQUMsS0FBSyxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsV0FBVyxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFDakQsT0FBTztDQUVULEtBQUssTUFBTSxPQUFPLEdBQ2hCLElBQUksRUFBRSxTQUFTLEVBQUUsTUFDZixPQUFPO0NBR1gsT0FBTztBQUNUO0FBQ0EsU0FBUyxhQUFhLE9BQU87Q0FDM0IsT0FBTyxNQUFNLFFBQVEsS0FBSyxLQUFLLE1BQU0sV0FBVyxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUM7QUFDckU7QUFDQSxTQUFTLGNBQWMsR0FBRztDQUN4QixJQUFJLENBQUMsbUJBQW1CLENBQUMsR0FDdkIsT0FBTztDQUVULE1BQU0sT0FBTyxFQUFFO0NBQ2YsSUFBSSxTQUFTLEtBQUssR0FDaEIsT0FBTztDQUVULE1BQU0sT0FBTyxLQUFLO0NBQ2xCLElBQUksQ0FBQyxtQkFBbUIsSUFBSSxHQUMxQixPQUFPO0NBRVQsSUFBSSxDQUFDLEtBQUssZUFBZSxlQUFlLEdBQ3RDLE9BQU87Q0FFVCxJQUFJLE9BQU8sZUFBZSxDQUFDLE1BQU0sT0FBTyxXQUN0QyxPQUFPO0NBRVQsT0FBTztBQUNUO0FBQ0EsU0FBUyxtQkFBbUIsR0FBRztDQUM3QixPQUFPLE9BQU8sVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNO0FBQy9DO0FBQ0EsU0FBUyxNQUFNLFNBQVM7Q0FDdEIsT0FBTyxJQUFJLFNBQVMsWUFBWTtFQUM5QixlQUFlLFdBQVcsU0FBUyxPQUFPO0NBQzVDLENBQUM7QUFDSDtBQUNBLFNBQVMsWUFBWSxVQUFVLE1BQU0sU0FBUztDQUM1QyxJQUFJLE9BQU8sUUFBUSxzQkFBc0IsWUFDdkMsT0FBTyxRQUFRLGtCQUFrQixVQUFVLElBQUk7TUFDMUMsSUFBSSxRQUFRLHNCQUFzQixPQUVyQyxJQUFJO0VBQ0YsT0FBTyxpQkFBaUIsVUFBVSxJQUFJO0NBQ3hDLFNBQVMsT0FBTztFQUNkLFFBQVEsTUFDTiwwSkFBMEosUUFBUSxVQUFVLEtBQUssT0FDbkw7RUFDQSxNQUFNO0NBQ1I7Q0FJSixPQUFPO0FBQ1Q7QUFDQSxTQUFTLGlCQUFpQixjQUFjO0NBQ3RDLE9BQU87QUFDVDtBQUNBLFNBQVMsU0FBUyxPQUFPLE1BQU0sTUFBTSxHQUFHO0NBQ3RDLE1BQU0sV0FBVyxDQUFDLEdBQUcsT0FBTyxJQUFJO0NBQ2hDLE9BQU8sT0FBTyxTQUFTLFNBQVMsTUFBTSxTQUFTLE1BQU0sQ0FBQyxJQUFJO0FBQzVEO0FBQ0EsU0FBUyxXQUFXLE9BQU8sTUFBTSxNQUFNLEdBQUc7Q0FDeEMsTUFBTSxXQUFXLENBQUMsTUFBTSxHQUFHLEtBQUs7Q0FDaEMsT0FBTyxPQUFPLFNBQVMsU0FBUyxNQUFNLFNBQVMsTUFBTSxHQUFHLEVBQUUsSUFBSTtBQUNoRTtBQUNBLElBQUksWUFBNEIsdUJBQU87QUFDdkMsU0FBUyxjQUFjLFNBQVMsY0FBYztDQUUxQyxJQUFJLFFBQVEsWUFBWSxXQUN0QixRQUFRLE1BQ04seUdBQXlHLFFBQVEsVUFBVSxFQUM3SDtDQUdKLElBQUksQ0FBQyxRQUFRLFdBQVcsY0FBYyxnQkFDcEMsYUFBYSxhQUFhO0NBRTVCLElBQUksQ0FBQyxRQUFRLFdBQVcsUUFBUSxZQUFZLFdBQzFDLGFBQWEsUUFBUSx1QkFBTyxJQUFJLE1BQU0scUJBQXFCLFFBQVEsVUFBVSxFQUFFLENBQUM7Q0FFbEYsT0FBTyxRQUFRO0FBQ2pCO0FBQ0EsU0FBUyxpQkFBaUIsY0FBYyxRQUFRO0NBQzlDLElBQUksT0FBTyxpQkFBaUIsWUFDMUIsT0FBTyxhQUFhLEdBQUcsTUFBTTtDQUUvQixPQUFPLENBQUMsQ0FBQztBQUNYO0FBQ0EsU0FBUyxzQkFBc0IsUUFBUSxXQUFXLGFBQWE7Q0FDN0QsSUFBSSxXQUFXO0NBQ2YsSUFBSTtDQUNKLE9BQU8sZUFBZSxRQUFRLFVBQVU7RUFDdEMsWUFBWTtFQUNaLFdBQVc7R0FDVCxXQUFXLFVBQVU7R0FDckIsSUFBSSxVQUNGLE9BQU87R0FFVCxXQUFXO0dBQ1gsSUFBSSxPQUFPLFNBQ1QsWUFBWTtRQUVaLE9BQU8saUJBQWlCLFNBQVMsYUFBYSxFQUFFLE1BQU0sS0FBSyxDQUFDO0dBRTlELE9BQU87RUFDVDtDQUNGLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7OztBQ3hRQSxJQUFJLHFCQUFxQyx1QkFBTztDQUM5QyxJQUFJLG1CQUFtQjtDQUN2QixPQUFPOzs7O0VBSUwsV0FBVztHQUNULE9BQU8sV0FBVztFQUNwQjs7OztFQUlBLFlBQVksZUFBZTtHQUN6QixhQUFhO0VBQ2Y7Q0FDRjtBQUNGLEVBQUEsQ0FBRzs7O0FDaEJILFNBQVMsa0JBQWtCO0NBQ3pCLElBQUk7Q0FDSixJQUFJO0NBQ0osTUFBTSxXQUFXLElBQUksU0FBUyxVQUFVLFlBQVk7RUFDbEQsVUFBVTtFQUNWLFNBQVM7Q0FDWCxDQUFDO0NBQ0QsU0FBUyxTQUFTO0NBQ2xCLFNBQVMsWUFBWSxDQUNyQixDQUFDO0NBQ0QsU0FBUyxTQUFTLE1BQU07RUFDdEIsT0FBTyxPQUFPLFVBQVUsSUFBSTtFQUM1QixPQUFPLFNBQVM7RUFDaEIsT0FBTyxTQUFTO0NBQ2xCO0NBQ0EsU0FBUyxXQUFXLFVBQVU7RUFDNUIsU0FBUztHQUNQLFFBQVE7R0FDUjtFQUNGLENBQUM7RUFDRCxRQUFRLEtBQUs7Q0FDZjtDQUNBLFNBQVMsVUFBVSxXQUFXO0VBQzVCLFNBQVM7R0FDUCxRQUFRO0dBQ1I7RUFDRixDQUFDO0VBQ0QsT0FBTyxNQUFNO0NBQ2Y7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGVBQWUsU0FBUztDQUMvQixJQUFJO0NBQ0osUUFBUSxNQUFNLFdBQVc7RUFDdkIsT0FBTztFQUNQLE9BQU87Q0FDVCxHQUFHLElBQUksQ0FBQyxFQUFFLE1BQU0sSUFBSTtDQUNwQixJQUFJLFNBQVMsS0FBSyxHQUNoQixPQUFPLEVBQUUsS0FBSztBQUdsQjs7O0FDeENBLFNBQVMscUJBQXFCLE1BQU07Q0FDbEMsT0FBTztBQUNUO0FBQ0EsU0FBUyxrQkFBa0IsVUFBVTtDQUNuQyxPQUFPO0VBQ0wsYUFBYSxTQUFTLFFBQVE7RUFDOUIsT0FBTyxTQUFTO0VBQ2hCLEdBQUcsU0FBUyxRQUFRLFNBQVMsRUFBRSxPQUFPLFNBQVMsUUFBUSxNQUFNO0VBQzdELEdBQUcsU0FBUyxRQUFRLEVBQUUsTUFBTSxTQUFTLEtBQUs7Q0FDNUM7QUFDRjtBQUNBLFNBQVMsZUFBZSxPQUFPLGVBQWUsb0JBQW9CO0NBQ2hFLE1BQU0seUJBQXlCO0VBQzdCLE1BQU0sVUFBVSxNQUFNLFNBQVMsS0FBSyxhQUFhLENBQUMsQ0FBQyxPQUFPLFVBQVU7R0FDbEUsSUFBSSxDQUFDLG1CQUFtQixLQUFLLEdBQzNCLE9BQU8sUUFBUSxPQUFPLEtBQUs7R0FHM0IsUUFBUSxNQUNOLCtEQUErRCxNQUFNLFVBQVUsS0FBSyxNQUFNLGtEQUM1RjtHQUVGLE9BQU8sUUFBUSx1QkFBTyxJQUFJLE1BQU0sVUFBVSxDQUFDO0VBQzdDLENBQUM7RUFDRCxTQUFTLE1BQU0sSUFBSTtFQUNuQixPQUFPO0NBQ1Q7Q0FDQSxPQUFPO0VBQ0wsY0FBYyxLQUFLLElBQUk7RUFDdkIsT0FBTztHQUNMLEdBQUcsTUFBTTtHQUNULEdBQUcsTUFBTSxNQUFNLFNBQVMsS0FBSyxLQUFLLEVBQ2hDLE1BQU0sY0FBYyxNQUFNLE1BQU0sSUFBSSxFQUN0QztFQUNGO0VBQ0EsVUFBVSxNQUFNO0VBQ2hCLFdBQVcsTUFBTTtFQUNqQixHQUFHLE1BQU0sTUFBTSxXQUFXLGFBQWEsRUFDckMsU0FBUyxpQkFBaUIsRUFDNUI7RUFDQSxHQUFHLE1BQU0sUUFBUSxFQUFFLE1BQU0sTUFBTSxLQUFLO0VBQ3BDLEdBQUcsTUFBTSxhQUFhLEVBQUUsV0FBVyxNQUFNLFVBQVU7Q0FDckQ7QUFDRjtBQUNBLFNBQVMsK0JBQStCLFVBQVU7Q0FDaEQsT0FBTyxTQUFTLE1BQU07QUFDeEI7QUFDQSxTQUFTLDRCQUE0QixPQUFPO0NBQzFDLE9BQU8sTUFBTSxNQUFNLFdBQVc7QUFDaEM7QUFDQSxTQUFTLDBCQUEwQixHQUFHO0NBQ3BDLE9BQU87QUFDVDtBQUNBLFNBQVMsVUFBVSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0NBQ3ZDLE1BQU0saUJBQWlCLFFBQVEsMkJBQTJCLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxXQUFXLDJCQUEyQjtDQUMzSCxNQUFNLFlBQVksT0FBTyxpQkFBaUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQ2xELGFBQWEsZUFBZSxRQUFRLElBQUksQ0FBQyxrQkFBa0IsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUM1RTtDQUNBLE1BQU0sY0FBYyxRQUFRLHdCQUF3QixPQUFPLGtCQUFrQixDQUFDLENBQUMsV0FBVyx3QkFBd0I7Q0FDbEgsTUFBTSxxQkFBcUIsUUFBUSxzQkFBc0IsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLFdBQVcsc0JBQXNCO0NBQ3JILE1BQU0sZ0JBQWdCLFFBQVEsaUJBQWlCLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxXQUFXLGlCQUFpQjtDQUl0RyxPQUFPO0VBQUU7RUFBVyxTQUhKLE9BQU8sY0FBYyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsU0FDN0MsVUFBVSxZQUFZLEtBQUssSUFBSSxDQUFDLGVBQWUsT0FBTyxlQUFlLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUV0RTtDQUFFO0FBQzlCO0FBQ0EsU0FBUyxRQUFRLFFBQVEsaUJBQWlCLFNBQVM7Q0FDakQsSUFBSSxPQUFPLG9CQUFvQixZQUFZLG9CQUFvQixNQUM3RDtDQUVGLE1BQU0sZ0JBQWdCLE9BQU8saUJBQWlCO0NBQzlDLE1BQU0sYUFBYSxPQUFPLGNBQWM7Q0FDeEMsTUFBTSxrQkFBa0IsU0FBUyxnQkFBZ0IsbUJBQW1CLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxTQUFTLG1CQUFtQjtDQUMzSCxNQUFNLFlBQVksZ0JBQWdCLGFBQWEsQ0FBQztDQUNoRCxNQUFNLFVBQVUsZ0JBQWdCLFdBQVcsQ0FBQztDQUM1QyxVQUFVLFNBQVMsRUFBRSxPQUFPLEdBQUcsc0JBQXNCO0VBQ25ELGNBQWMsTUFDWixRQUNBO0dBQ0UsR0FBRyxPQUFPLGtCQUFrQixDQUFDLENBQUMsU0FBUztHQUN2QyxHQUFHLFNBQVMsZ0JBQWdCO0dBQzVCLEdBQUc7RUFDTCxHQUNBLEtBQ0Y7Q0FDRixDQUFDO0NBQ0QsUUFBUSxTQUNMLEVBQ0MsVUFDQSxPQUNBLFdBQ0EsTUFDQSxTQUNBLGNBQ0EsZ0JBQ0k7RUFDSixNQUFNLFdBQVcsVUFBVSxlQUFlLE9BQU8sSUFBSSxLQUFLO0VBQzFELE1BQU0sVUFBVSxNQUFNLFNBQVMsS0FBSyxJQUFJLFVBQVUsT0FBTyxNQUFNO0VBQy9ELE1BQU0sT0FBTyxZQUFZLEtBQUssSUFBSSxVQUFVLGdCQUFnQixPQUFPO0VBQ25FLElBQUksUUFBUSxXQUFXLElBQUksU0FBUztFQUNwQyxNQUFNLHlCQUF5QixPQUFPLE1BQU0sV0FBVztFQUN2RCxNQUFNLDBCQUEwQixPQUFPLE1BQU0sZ0JBQWdCO0VBQzdELElBQUksT0FBTztHQUNULE1BQU0sbUJBQW1CLFlBRXpCLGlCQUFpQixLQUFLLEtBQUssZUFBZSxNQUFNLE1BQU07R0FDdEQsSUFBSSxNQUFNLGdCQUFnQixNQUFNLE1BQU0saUJBQWlCLGtCQUFrQjtJQUN2RSxNQUFNLEVBQUUsYUFBYSxVQUFVLEdBQUcsb0JBQW9CO0lBQ3RELE1BQU0sU0FBUztLQUNiLEdBQUc7S0FDSDtLQU1BLEdBQUcsTUFBTSxXQUFXLGFBQWEsU0FBUyxLQUFLLEtBQUs7TUFDbEQsUUFBUTtNQUNSLGVBQWUsZ0JBQWdCLEtBQUssSUFBSTtNQUV4QyxHQUFHLENBQUMsMkJBQTJCLEVBQzdCLGFBQWEsT0FDZjtLQUNGO0lBQ0YsQ0FBQztHQUNIO0VBQ0YsT0FDRSxRQUFRLFdBQVcsTUFDakIsUUFDQTtHQUNFLEdBQUcsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLFNBQVM7R0FDdkMsR0FBRyxTQUFTLGdCQUFnQjtHQUM1QjtHQUNBO0dBQ0E7R0FDQSxPQUFPO0VBQ1QsR0FHQTtHQUNFLEdBQUc7R0FDSDtHQUNBLGFBQWE7R0FHYixRQUFRLE1BQU0sV0FBVyxhQUFhLFNBQVMsS0FBSyxJQUFJLFlBQVksTUFBTTtHQUMxRSxHQUFHLE1BQU0sV0FBVyxhQUFhLFNBQVMsS0FBSyxLQUFLLEVBQ2xELGVBQWUsZ0JBQWdCLEtBQUssSUFBSSxFQUMxQztFQUNGLENBQ0Y7RUFFRixJQUFJLFdBRUosQ0FBQyxZQUFZLENBQUMsMEJBQTBCLENBQUMsNEJBRXhDLGlCQUFpQixLQUFLLEtBQUssZUFBZSxNQUFNLE1BQU0sZ0JBQ3JELE1BQU0sTUFBTSxLQUFLLEdBQUcsRUFFbEIsZ0JBQWdCLFFBQVEsUUFBUSxPQUFPLENBQUMsQ0FBQyxLQUFLLGVBQWUsRUFDL0QsQ0FBQyxDQUFDLENBQUMsTUFBTSxJQUFJO0NBRWpCLENBQ0Y7QUFDRjs7O0FDcktBLElBQUksbUJBQW1CO0FBQ3ZCLFNBQVMsc0JBQXNCO0NBQzdCLElBQUksUUFBUSxDQUFDO0NBQ2IsSUFBSSxlQUFlO0NBQ25CLElBQUksWUFBWSxhQUFhO0VBQzNCLFNBQVM7Q0FDWDtDQUNBLElBQUksaUJBQWlCLGFBQWE7RUFDaEMsU0FBUztDQUNYO0NBQ0EsSUFBSSxhQUFhO0NBQ2pCLE1BQU0sWUFBWSxhQUFhO0VBQzdCLElBQUksY0FDRixNQUFNLEtBQUssUUFBUTtPQUVuQixpQkFBaUI7R0FDZixTQUFTLFFBQVE7RUFDbkIsQ0FBQztDQUVMO0NBQ0EsTUFBTSxjQUFjO0VBQ2xCLE1BQU0sZ0JBQWdCO0VBQ3RCLFFBQVEsQ0FBQztFQUNULElBQUksY0FBYyxRQUNoQixpQkFBaUI7R0FDZixvQkFBb0I7SUFDbEIsY0FBYyxTQUFTLGFBQWE7S0FDbEMsU0FBUyxRQUFRO0lBQ25CLENBQUM7R0FDSCxDQUFDO0VBQ0gsQ0FBQztDQUVMO0NBQ0EsT0FBTztFQUNMLFFBQVEsYUFBYTtHQUNuQixJQUFJO0dBQ0o7R0FDQSxJQUFJO0lBQ0YsU0FBUyxTQUFTO0dBQ3BCLFVBQVU7SUFDUjtJQUNBLElBQUksQ0FBQyxjQUNILE1BQU07R0FFVjtHQUNBLE9BQU87RUFDVDs7OztFQUlBLGFBQWEsYUFBYTtHQUN4QixRQUFRLEdBQUcsU0FBUztJQUNsQixlQUFlO0tBQ2IsU0FBUyxHQUFHLElBQUk7SUFDbEIsQ0FBQztHQUNIO0VBQ0Y7RUFDQTs7Ozs7RUFLQSxvQkFBb0IsT0FBTztHQUN6QixXQUFXO0VBQ2I7Ozs7O0VBS0EseUJBQXlCLE9BQU87R0FDOUIsZ0JBQWdCO0VBQ2xCO0VBQ0EsZUFBZSxPQUFPO0dBQ3BCLGFBQWE7RUFDZjtDQUNGO0FBQ0Y7QUFDQSxJQUFJLGdCQUFnQixvQkFBb0I7OztBQzdFeEMsSUFBSSxnQkFBZ0IsY0FBYyxhQUFhO0NBQzdDLFVBQVU7Q0FDVjtDQUNBO0NBQ0EsY0FBYztFQUNaLE1BQU07RUFDTixLQUFLQyxVQUFVLGFBQWE7R0FDMUIsSUFBSSxPQUFPLFdBQVcsZUFBZSxPQUFPLGtCQUFrQjtJQUM1RCxNQUFNLHVCQUF1QixTQUFTLElBQUk7SUFDMUMsTUFBTSx3QkFBd0IsU0FBUyxLQUFLO0lBQzVDLE9BQU8saUJBQWlCLFVBQVUsZ0JBQWdCLEtBQUs7SUFDdkQsT0FBTyxpQkFBaUIsV0FBVyxpQkFBaUIsS0FBSztJQUN6RCxhQUFhO0tBQ1gsT0FBTyxvQkFBb0IsVUFBVSxjQUFjO0tBQ25ELE9BQU8sb0JBQW9CLFdBQVcsZUFBZTtJQUN2RDtHQUNGO0VBRUY7Q0FDRjtDQUNBLGNBQWM7RUFDWixJQUFJLENBQUMsS0FBS0MsVUFDUixLQUFLLGlCQUFpQixLQUFLRCxNQUFNO0NBRXJDO0NBQ0EsZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLEtBQUssYUFBYSxHQUFHO0dBQ3hCLEtBQUtDLFdBQVc7R0FDaEIsS0FBS0EsV0FBVyxLQUFLO0VBQ3ZCO0NBQ0Y7Q0FDQSxpQkFBaUIsT0FBTztFQUN0QixLQUFLRCxTQUFTO0VBQ2QsS0FBS0MsV0FBVztFQUNoQixLQUFLQSxXQUFXLE1BQU0sS0FBSyxVQUFVLEtBQUssSUFBSSxDQUFDO0NBQ2pEO0NBQ0EsVUFBVSxRQUFRO0VBRWhCLElBRGdCLEtBQUtDLFlBQVksUUFDcEI7R0FDWCxLQUFLQSxVQUFVO0dBQ2YsS0FBSyxVQUFVLFNBQVMsYUFBYTtJQUNuQyxTQUFTLE1BQU07R0FDakIsQ0FBQztFQUNIO0NBQ0Y7Q0FDQSxXQUFXO0VBQ1QsT0FBTyxLQUFLQTtDQUNkO0FBQ0Y7QUFDQSxJQUFJLGdCQUFnQixJQUFJLGNBQWM7OztBQzdDdEMsU0FBUyxrQkFBa0IsY0FBYztDQUN2QyxPQUFPLEtBQUssSUFBSSxNQUFNLEtBQUssY0FBYyxHQUFHO0FBQzlDO0FBQ0EsU0FBUyxTQUFTLGFBQWE7Q0FDN0IsUUFBUSxlQUFlLGNBQWMsV0FBVyxjQUFjLFNBQVMsSUFBSTtBQUM3RTtBQUNBLElBQUksaUJBQWlCLGNBQWMsTUFBTTtDQUN2QyxZQUFZLFNBQVM7RUFDbkIsTUFBTSxnQkFBZ0I7RUFDdEIsS0FBSyxTQUFTLFNBQVM7RUFDdkIsS0FBSyxTQUFTLFNBQVM7Q0FDekI7QUFDRjtBQUNBLFNBQVMsaUJBQWlCLE9BQU87Q0FDL0IsT0FBTyxpQkFBaUI7QUFDMUI7QUFDQSxTQUFTLGNBQWMsUUFBUTtDQUM3QixJQUFJLG1CQUFtQjtDQUN2QixJQUFJLGVBQWU7Q0FDbkIsSUFBSTtDQUNKLE1BQU0sV0FBVyxnQkFBZ0I7Q0FDakMsTUFBTSxtQkFBbUIsU0FBUyxXQUFXO0NBQzdDLE1BQU0sVUFBVSxrQkFBa0I7RUFDaEMsSUFBSSxDQUFDLFdBQVcsR0FBRztHQUNqQixNQUFNLFFBQVEsSUFBSSxlQUFlLGFBQWE7R0FDOUMsT0FBTyxLQUFLO0dBQ1osT0FBTyxXQUFXLEtBQUs7RUFDekI7Q0FDRjtDQUNBLE1BQU0sb0JBQW9CO0VBQ3hCLG1CQUFtQjtDQUNyQjtDQUNBLE1BQU0sc0JBQXNCO0VBQzFCLG1CQUFtQjtDQUNyQjtDQUNBLE1BQU0sb0JBQW9CLGFBQWEsVUFBVSxNQUFNLE9BQU8sZ0JBQWdCLFlBQVksY0FBYyxTQUFTLE1BQU0sT0FBTyxPQUFPO0NBQ3JJLE1BQU0saUJBQWlCLFNBQVMsT0FBTyxXQUFXLEtBQUssT0FBTyxPQUFPO0NBQ3JFLE1BQU0sV0FBVyxVQUFVO0VBQ3pCLElBQUksQ0FBQyxXQUFXLEdBQUc7R0FDakIsYUFBYTtHQUNiLFNBQVMsUUFBUSxLQUFLO0VBQ3hCO0NBQ0Y7Q0FDQSxNQUFNLFVBQVUsVUFBVTtFQUN4QixJQUFJLENBQUMsV0FBVyxHQUFHO0dBQ2pCLGFBQWE7R0FDYixTQUFTLE9BQU8sS0FBSztFQUN2QjtDQUNGO0NBQ0EsTUFBTSxjQUFjO0VBQ2xCLE9BQU8sSUFBSSxTQUFTLG9CQUFvQjtHQUN0QyxjQUFjLFVBQVU7SUFDdEIsSUFBSSxXQUFXLEtBQUssWUFBWSxHQUM5QixnQkFBZ0IsS0FBSztHQUV6QjtHQUNBLE9BQU8sVUFBVTtFQUNuQixDQUFDLENBQUMsQ0FBQyxXQUFXO0dBQ1osYUFBYSxLQUFLO0dBQ2xCLElBQUksQ0FBQyxXQUFXLEdBQ2QsT0FBTyxhQUFhO0VBRXhCLENBQUM7Q0FDSDtDQUNBLE1BQU0sWUFBWTtFQUNoQixJQUFJLFdBQVcsR0FDYjtFQUVGLElBQUk7RUFDSixNQUFNLGlCQUFpQixpQkFBaUIsSUFBSSxPQUFPLGlCQUFpQixLQUFLO0VBQ3pFLElBQUk7R0FDRixpQkFBaUIsa0JBQWtCLE9BQU8sR0FBRztFQUMvQyxTQUFTLE9BQU87R0FDZCxpQkFBaUIsUUFBUSxPQUFPLEtBQUs7RUFDdkM7RUFDQSxRQUFRLFFBQVEsY0FBYyxDQUFDLENBQUMsS0FBSyxPQUFPLENBQUMsQ0FBQyxPQUFPLFVBQVU7R0FDN0QsSUFBSSxXQUFXLEdBQ2I7R0FFRixNQUFNLFFBQVEsT0FBTyxVQUFVLG1CQUFtQixTQUFTLElBQUksSUFBSTtHQUNuRSxNQUFNLGFBQWEsT0FBTyxjQUFjO0dBQ3hDLE1BQU0sUUFBUSxPQUFPLGVBQWUsYUFBYSxXQUFXLGNBQWMsS0FBSyxJQUFJO0dBQ25GLE1BQU0sY0FBYyxVQUFVLFFBQVEsT0FBTyxVQUFVLFlBQVksZUFBZSxTQUFTLE9BQU8sVUFBVSxjQUFjLE1BQU0sY0FBYyxLQUFLO0dBQ25KLElBQUksb0JBQW9CLENBQUMsYUFBYTtJQUNwQyxPQUFPLEtBQUs7SUFDWjtHQUNGO0dBQ0E7R0FDQSxPQUFPLFNBQVMsY0FBYyxLQUFLO0dBQ25DLE1BQU0sS0FBSyxDQUFDLENBQUMsV0FBVztJQUN0QixPQUFPLFlBQVksSUFBSSxLQUFLLElBQUksTUFBTTtHQUN4QyxDQUFDLENBQUMsQ0FBQyxXQUFXO0lBQ1osSUFBSSxrQkFDRixPQUFPLEtBQUs7U0FFWixJQUFJO0dBRVIsQ0FBQztFQUNILENBQUM7Q0FDSDtDQUNBLE9BQU87RUFDTCxTQUFTO0VBQ1QsY0FBYyxTQUFTO0VBQ3ZCO0VBQ0EsZ0JBQWdCO0dBQ2QsYUFBYTtHQUNiLE9BQU87RUFDVDtFQUNBO0VBQ0E7RUFDQTtFQUNBLGFBQWE7R0FDWCxJQUFJLFNBQVMsR0FDWCxJQUFJO1FBRUosTUFBTSxDQUFDLENBQUMsS0FBSyxHQUFHO0dBRWxCLE9BQU87RUFDVDtDQUNGO0FBQ0Y7OztBQzFIQSxJQUFJLFlBQVksTUFBTTtDQUNwQjtDQUNBLFVBQVU7RUFDUixLQUFLLGVBQWU7Q0FDdEI7Q0FDQSxhQUFhO0VBQ1gsS0FBSyxlQUFlO0VBQ3BCLElBQUksZUFBZSxLQUFLLE1BQU0sR0FDNUIsS0FBS0MsYUFBYSxlQUFlLGlCQUFpQjtHQUNoRCxLQUFLLGVBQWU7RUFDdEIsR0FBRyxLQUFLLE1BQU07Q0FFbEI7Q0FDQSxhQUFhLFdBQVc7RUFDdEIsS0FBSyxTQUFTLEtBQUssSUFDakIsS0FBSyxVQUFVLEdBQ2YsY0FBYyxtQkFBbUIsU0FBUyxJQUFJLFdBQVcsSUFDM0Q7Q0FDRjtDQUNBLGlCQUFpQjtFQUNmLElBQUksS0FBS0EsZUFBZSxLQUFLLEdBQUc7R0FDOUIsZUFBZSxhQUFhLEtBQUtBLFVBQVU7R0FDM0MsS0FBS0EsYUFBYSxLQUFLO0VBQ3pCO0NBQ0Y7QUFDRjs7O0FDdEJBLFNBQVMsc0JBQXNCLE9BQU87Q0FDcEMsT0FBTyxFQUNMLFVBQVUsU0FBUyxVQUFVO0VBQzNCLE1BQU0sVUFBVSxRQUFRO0VBQ3hCLE1BQU0sWUFBWSxRQUFRLGNBQWMsTUFBTSxXQUFXO0VBQ3pELE1BQU0sV0FBVyxRQUFRLE1BQU0sTUFBTSxTQUFTLENBQUM7RUFDL0MsTUFBTSxnQkFBZ0IsUUFBUSxNQUFNLE1BQU0sY0FBYyxDQUFDO0VBQ3pELElBQUksU0FBUztHQUFFLE9BQU8sQ0FBQztHQUFHLFlBQVksQ0FBQztFQUFFO0VBQ3pDLElBQUksY0FBYztFQUNsQixNQUFNLFVBQVUsWUFBWTtHQUMxQixJQUFJLFlBQVk7R0FDaEIsTUFBTSxxQkFBcUIsV0FBVztJQUNwQyxzQkFDRSxjQUNNLFFBQVEsY0FDUixZQUFZLElBQ3BCO0dBQ0Y7R0FDQSxNQUFNLFVBQVUsY0FBYyxRQUFRLFNBQVMsUUFBUSxZQUFZO0dBQ25FLE1BQU0sWUFBWSxPQUFPLE1BQU0sT0FBTyxhQUFhO0lBQ2pELElBQUksV0FDRixPQUFPLFFBQVEsT0FBTyxRQUFRLE9BQU8sTUFBTTtJQUU3QyxJQUFJLFNBQVMsUUFBUSxLQUFLLE1BQU0sUUFDOUIsT0FBTyxRQUFRLFFBQVEsSUFBSTtJQUU3QixNQUFNLDZCQUE2QjtLQUNqQyxNQUFNLGtCQUFrQjtNQUN0QixRQUFRLFFBQVE7TUFDaEIsVUFBVSxRQUFRO01BQ2xCLFdBQVc7TUFDWCxXQUFXLFdBQVcsYUFBYTtNQUNuQyxNQUFNLFFBQVEsUUFBUTtLQUN4QjtLQUNBLGtCQUFrQixlQUFlO0tBQ2pDLE9BQU87SUFDVDtJQUNBLE1BQU0saUJBQWlCLHFCQUFxQjtJQUM1QyxNQUFNLE9BQU8sTUFBTSxRQUFRLGNBQWM7SUFDekMsTUFBTSxFQUFFLGFBQWEsUUFBUTtJQUM3QixNQUFNLFFBQVEsV0FBVyxhQUFhO0lBQ3RDLE9BQU87S0FDTCxPQUFPLE1BQU0sS0FBSyxPQUFPLE1BQU0sUUFBUTtLQUN2QyxZQUFZLE1BQU0sS0FBSyxZQUFZLE9BQU8sUUFBUTtJQUNwRDtHQUNGO0dBQ0EsSUFBSSxhQUFhLFNBQVMsUUFBUTtJQUNoQyxNQUFNLFdBQVcsY0FBYztJQUMvQixNQUFNLGNBQWMsV0FBVyx1QkFBdUI7SUFDdEQsTUFBTSxVQUFVO0tBQ2QsT0FBTztLQUNQLFlBQVk7SUFDZDtJQUVBLFNBQVMsTUFBTSxVQUFVLFNBRFgsWUFBWSxTQUFTLE9BQ0csR0FBRyxRQUFRO0dBQ25ELE9BQU87SUFDTCxNQUFNLGlCQUFpQixTQUFTLFNBQVM7SUFDekMsR0FBRztLQUNELE1BQU0sUUFBUSxnQkFBZ0IsSUFBSSxjQUFjLE1BQU0sUUFBUSxtQkFBbUIsaUJBQWlCLFNBQVMsTUFBTTtLQUNqSCxJQUFJLGNBQWMsS0FBSyxTQUFTLE1BQzlCO0tBRUYsU0FBUyxNQUFNLFVBQVUsUUFBUSxLQUFLO0tBQ3RDO0lBQ0YsU0FBUyxjQUFjO0dBQ3pCO0dBQ0EsT0FBTztFQUNUO0VBQ0EsSUFBSSxRQUFRLFFBQVEsV0FDbEIsUUFBUSxnQkFBZ0I7R0FDdEIsT0FBTyxRQUFRLFFBQVEsWUFDckIsU0FDQTtJQUNFLFFBQVEsUUFBUTtJQUNoQixVQUFVLFFBQVE7SUFDbEIsTUFBTSxRQUFRLFFBQVE7SUFDdEIsUUFBUSxRQUFRO0dBQ2xCLEdBQ0EsS0FDRjtFQUNGO09BRUEsUUFBUSxVQUFVO0NBRXRCLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsaUJBQWlCLFNBQVMsRUFBRSxPQUFPLGNBQWM7Q0FDeEQsTUFBTSxZQUFZLE1BQU0sU0FBUztDQUNqQyxPQUFPLE1BQU0sU0FBUyxJQUFJLFFBQVEsaUJBQ2hDLE1BQU0sWUFDTixPQUNBLFdBQVcsWUFDWCxVQUNGLElBQUksS0FBSztBQUNYO0FBQ0EsU0FBUyxxQkFBcUIsU0FBUyxFQUFFLE9BQU8sY0FBYztDQUM1RCxPQUFPLE1BQU0sU0FBUyxJQUFJLFFBQVEsdUJBQXVCLE1BQU0sSUFBSSxPQUFPLFdBQVcsSUFBSSxVQUFVLElBQUksS0FBSztBQUM5RztBQUNBLFNBQVMsWUFBWSxTQUFTLE1BQU07Q0FDbEMsSUFBSSxDQUFDLE1BQU0sT0FBTztDQUNsQixPQUFPLGlCQUFpQixTQUFTLElBQUksS0FBSztBQUM1QztBQUNBLFNBQVMsZ0JBQWdCLFNBQVMsTUFBTTtDQUN0QyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsc0JBQXNCLE9BQU87Q0FDbkQsT0FBTyxxQkFBcUIsU0FBUyxJQUFJLEtBQUs7QUFDaEQ7OztBQ25HQSxJQUFJLFFBQVEsY0FBYyxVQUFVO0NBQ2xDO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxZQUFZLFFBQVE7RUFDbEIsTUFBTTtFQUNOLEtBQUtDLHVCQUF1QjtFQUM1QixLQUFLQyxrQkFBa0IsT0FBTztFQUM5QixLQUFLLFdBQVcsT0FBTyxPQUFPO0VBQzlCLEtBQUssWUFBWSxDQUFDO0VBQ2xCLEtBQUtDLFVBQVUsT0FBTztFQUN0QixLQUFLQyxTQUFTLEtBQUtELFFBQVEsY0FBYztFQUN6QyxLQUFLLFdBQVcsT0FBTztFQUN2QixLQUFLLFlBQVksT0FBTztFQUN4QixLQUFLRSxnQkFBZ0JDLGtCQUFnQixLQUFLLE9BQU87RUFDakQsS0FBSyxRQUFRLE9BQU8sU0FBUyxLQUFLRDtFQUNsQyxLQUFLLFdBQVc7Q0FDbEI7Q0FDQSxJQUFJLE9BQU87RUFDVCxPQUFPLEtBQUssUUFBUTtDQUN0QjtDQUNBLElBQUksWUFBWTtFQUNkLE9BQU8sS0FBS0U7Q0FDZDtDQUNBLElBQUksVUFBVTtFQUNaLE9BQU8sS0FBS0MsVUFBVTtDQUN4QjtDQUNBLFdBQVcsU0FBUztFQUNsQixLQUFLLFVBQVU7R0FBRSxHQUFHLEtBQUtOO0dBQWlCLEdBQUc7RUFBUTtFQUNyRCxJQUFJLFNBQVMsT0FDWCxLQUFLSyxhQUFhLFFBQVE7RUFFNUIsS0FBSyxhQUFhLEtBQUssUUFBUSxNQUFNO0VBQ3JDLElBQUksS0FBSyxTQUFTLEtBQUssTUFBTSxTQUFTLEtBQUssR0FBRztHQUM1QyxNQUFNLGVBQWVELGtCQUFnQixLQUFLLE9BQU87R0FDakQsSUFBSSxhQUFhLFNBQVMsS0FBSyxHQUFHO0lBQ2hDLEtBQUssU0FDSCxhQUFhLGFBQWEsTUFBTSxhQUFhLGFBQWEsQ0FDNUQ7SUFDQSxLQUFLRCxnQkFBZ0I7R0FDdkI7RUFDRjtDQUNGO0NBQ0EsaUJBQWlCO0VBQ2YsSUFBSSxDQUFDLEtBQUssVUFBVSxVQUFVLEtBQUssTUFBTSxnQkFBZ0IsUUFDdkQsS0FBS0QsT0FBTyxPQUFPLElBQUk7Q0FFM0I7Q0FDQSxRQUFRLFNBQVMsU0FBUztFQUN4QixNQUFNLE9BQU8sWUFBWSxLQUFLLE1BQU0sTUFBTSxTQUFTLEtBQUssT0FBTztFQUMvRCxLQUFLSyxVQUFVO0dBQ2I7R0FDQSxNQUFNO0dBQ04sZUFBZSxTQUFTO0dBQ3hCLFFBQVEsU0FBUztFQUNuQixDQUFDO0VBQ0QsT0FBTztDQUNUO0NBQ0EsU0FBUyxPQUFPO0VBQ2QsS0FBS0EsVUFBVTtHQUFFLE1BQU07R0FBWTtFQUFNLENBQUM7Q0FDNUM7Q0FDQSxPQUFPLFNBQVM7RUFDZCxNQUFNLFVBQVUsS0FBS0QsVUFBVTtFQUMvQixLQUFLQSxVQUFVLE9BQU8sT0FBTztFQUM3QixPQUFPLFVBQVUsUUFBUSxLQUFLLElBQUksQ0FBQyxDQUFDLE1BQU0sSUFBSSxJQUFJLFFBQVEsUUFBUTtDQUNwRTtDQUNBLFVBQVU7RUFDUixNQUFNLFFBQVE7RUFDZCxLQUFLLE9BQU8sRUFBRSxRQUFRLEtBQUssQ0FBQztDQUM5QjtDQUNBLElBQUksYUFBYTtFQUNmLE9BQU8sS0FBS0g7Q0FDZDtDQUNBLFFBQVE7RUFDTixLQUFLLFFBQVE7RUFDYixLQUFLLFNBQVMsS0FBSyxVQUFVO0NBQy9CO0NBQ0EsV0FBVztFQUNULE9BQU8sS0FBSyxVQUFVLE1BQ25CLGFBQWEsb0JBQW9CLFNBQVMsUUFBUSxTQUFTLElBQUksTUFBTSxLQUN4RTtDQUNGO0NBQ0EsYUFBYTtFQUNYLElBQUksS0FBSyxrQkFBa0IsSUFBSSxHQUM3QixPQUFPLENBQUMsS0FBSyxTQUFTO0VBRXhCLE9BQU8sS0FBSyxRQUFRLFlBQVksYUFBYSxDQUFDLEtBQUssVUFBVTtDQUMvRDtDQUNBLFlBQVk7RUFDVixPQUFPLEtBQUssTUFBTSxrQkFBa0IsS0FBSyxNQUFNLG1CQUFtQjtDQUNwRTtDQUNBLFdBQVc7RUFDVCxJQUFJLEtBQUssa0JBQWtCLElBQUksR0FDN0IsT0FBTyxLQUFLLFVBQVUsTUFDbkIsYUFBYSxpQkFBaUIsU0FBUyxRQUFRLFdBQVcsSUFBSSxNQUFNLFFBQ3ZFO0VBRUYsT0FBTztDQUNUO0NBQ0EsVUFBVTtFQUNSLElBQUksS0FBSyxrQkFBa0IsSUFBSSxHQUM3QixPQUFPLEtBQUssVUFBVSxNQUNuQixhQUFhLFNBQVMsaUJBQWlCLENBQUMsQ0FBQyxPQUM1QztFQUVGLE9BQU8sS0FBSyxNQUFNLFNBQVMsS0FBSyxLQUFLLEtBQUssTUFBTTtDQUNsRDtDQUNBLGNBQWMsWUFBWSxHQUFHO0VBQzNCLElBQUksS0FBSyxNQUFNLFNBQVMsS0FBSyxHQUMzQixPQUFPO0VBRVQsSUFBSSxjQUFjLFVBQ2hCLE9BQU87RUFFVCxJQUFJLEtBQUssTUFBTSxlQUNiLE9BQU87RUFFVCxPQUFPLENBQUMsZUFBZSxLQUFLLE1BQU0sZUFBZSxTQUFTO0NBQzVEO0NBQ0EsVUFBVTtFQUVSLEtBRHNCLFVBQVUsTUFBTSxNQUFNLEVBQUUseUJBQXlCLENBQ2hFLENBQUMsRUFBRSxRQUFRLEVBQUUsZUFBZSxNQUFNLENBQUM7RUFDMUMsS0FBS0csVUFBVSxTQUFTO0NBQzFCO0NBQ0EsV0FBVztFQUVULEtBRHNCLFVBQVUsTUFBTSxNQUFNLEVBQUUsdUJBQXVCLENBQzlELENBQUMsRUFBRSxRQUFRLEVBQUUsZUFBZSxNQUFNLENBQUM7RUFDMUMsS0FBS0EsVUFBVSxTQUFTO0NBQzFCO0NBQ0EsWUFBWSxVQUFVO0VBQ3BCLElBQUksQ0FBQyxLQUFLLFVBQVUsU0FBUyxRQUFRLEdBQUc7R0FDdEMsS0FBSyxVQUFVLEtBQUssUUFBUTtHQUM1QixLQUFLLGVBQWU7R0FDcEIsS0FBS0osT0FBTyxPQUFPO0lBQUUsTUFBTTtJQUFpQixPQUFPO0lBQU07R0FBUyxDQUFDO0VBQ3JFO0NBQ0Y7Q0FDQSxlQUFlLFVBQVU7RUFDdkIsSUFBSSxLQUFLLFVBQVUsU0FBUyxRQUFRLEdBQUc7R0FDckMsS0FBSyxZQUFZLEtBQUssVUFBVSxRQUFRLE1BQU0sTUFBTSxRQUFRO0dBQzVELElBQUksQ0FBQyxLQUFLLFVBQVUsUUFBUTtJQUMxQixJQUFJLEtBQUtJLFVBQVU7S0FDakIsSUFBSSxLQUFLUCx3QkFBd0IsS0FBS1Msc0JBQXNCLEdBQzFELEtBQUtGLFNBQVMsT0FBTyxFQUFFLFFBQVEsS0FBSyxDQUFDO1VBRXJDLEtBQUtBLFNBQVMsWUFBWTtJQUU5QjtJQUNBLEtBQUssV0FBVztHQUNsQjtHQUNBLEtBQUtKLE9BQU8sT0FBTztJQUFFLE1BQU07SUFBbUIsT0FBTztJQUFNO0dBQVMsQ0FBQztFQUN2RTtDQUNGO0NBQ0Esb0JBQW9CO0VBQ2xCLE9BQU8sS0FBSyxVQUFVO0NBQ3hCO0NBQ0Esd0JBQXdCO0VBQ3RCLE9BQU8sS0FBSyxNQUFNLGdCQUFnQixZQUFZLEtBQUssTUFBTSxXQUFXO0NBQ3RFO0NBQ0EsYUFBYTtFQUNYLElBQUksQ0FBQyxLQUFLLE1BQU0sZUFDZCxLQUFLSyxVQUFVLEVBQUUsTUFBTSxhQUFhLENBQUM7Q0FFekM7Q0FDQSxNQUFNLE1BQU0sU0FBUyxjQUFjO0VBQ2pDLElBQUksS0FBSyxNQUFNLGdCQUFnQixVQUcvQixLQUFLRCxVQUFVLE9BQU8sTUFBTSxZQUFZO0dBQ3RDLElBQUksS0FBSyxNQUFNLFNBQVMsS0FBSyxLQUFLLGNBQWMsZUFDOUMsS0FBSyxPQUFPLEVBQUUsUUFBUSxLQUFLLENBQUM7UUFDdkIsSUFBSSxLQUFLQSxVQUFVO0lBQ3hCLEtBQUtBLFNBQVMsY0FBYztJQUM1QixPQUFPLEtBQUtBLFNBQVM7R0FDdkI7RUFDRjtFQUNBLElBQUksU0FDRixLQUFLLFdBQVcsT0FBTztFQUV6QixJQUFJLENBQUMsS0FBSyxRQUFRLFNBQVM7R0FDekIsTUFBTSxXQUFXLEtBQUssVUFBVSxNQUFNLE1BQU0sRUFBRSxRQUFRLE9BQU87R0FDN0QsSUFBSSxVQUNGLEtBQUssV0FBVyxTQUFTLE9BQU87RUFFcEM7RUFFRSxJQUFJLENBQUMsTUFBTSxRQUFRLEtBQUssUUFBUSxRQUFRLEdBQ3RDLFFBQVEsTUFDTixxSUFDRjtFQUdKLE1BQU0sa0JBQWtCLElBQUksZ0JBQWdCO0VBQzVDLE1BQU0scUJBQXFCLFdBQVc7R0FDcEMsT0FBTyxlQUFlLFFBQVEsVUFBVTtJQUN0QyxZQUFZO0lBQ1osV0FBVztLQUNULEtBQUtQLHVCQUF1QjtLQUM1QixPQUFPLGdCQUFnQjtJQUN6QjtHQUNGLENBQUM7RUFDSDtFQUNBLE1BQU0sZ0JBQWdCO0dBQ3BCLE1BQU0sVUFBVSxjQUFjLEtBQUssU0FBUyxZQUFZO0dBQ3hELE1BQU0sNkJBQTZCO0lBQ2pDLE1BQU0sa0JBQWtCO0tBQ3RCLFFBQVEsS0FBS0U7S0FDYixVQUFVLEtBQUs7S0FDZixNQUFNLEtBQUs7SUFDYjtJQUNBLGtCQUFrQixlQUFlO0lBQ2pDLE9BQU87R0FDVDtHQUNBLE1BQU0saUJBQWlCLHFCQUFxQjtHQUM1QyxLQUFLRix1QkFBdUI7R0FDNUIsSUFBSSxLQUFLLFFBQVEsV0FDZixPQUFPLEtBQUssUUFBUSxVQUNsQixTQUNBLGdCQUNBLElBQ0Y7R0FFRixPQUFPLFFBQVEsY0FBYztFQUMvQjtFQUNBLE1BQU0sMkJBQTJCO0dBQy9CLE1BQU0sV0FBVztJQUNmO0lBQ0EsU0FBUyxLQUFLO0lBQ2QsVUFBVSxLQUFLO0lBQ2YsUUFBUSxLQUFLRTtJQUNiLE9BQU8sS0FBSztJQUNaO0dBQ0Y7R0FDQSxrQkFBa0IsUUFBUTtHQUMxQixPQUFPO0VBQ1Q7RUFDQSxNQUFNLFVBQVUsbUJBQW1CO0VBSW5DLENBSGlCLEtBQUtJLGVBQWUsYUFBYSxzQkFDaEQsS0FBSyxRQUFRLEtBQ2YsSUFBSSxLQUFLLFFBQVEsU0FBQSxFQUNQLFFBQVEsU0FBUyxJQUFJO0VBQy9CLEtBQUtJLGVBQWUsS0FBSztFQUN6QixJQUFJLEtBQUssTUFBTSxnQkFBZ0IsVUFBVSxLQUFLLE1BQU0sY0FBYyxRQUFRLGNBQWMsTUFDdEYsS0FBS0YsVUFBVTtHQUFFLE1BQU07R0FBUyxNQUFNLFFBQVEsY0FBYztFQUFLLENBQUM7RUFFcEUsS0FBS0QsV0FBVyxjQUFjO0dBQzVCLGdCQUFnQixjQUFjO0dBQzlCLElBQUksUUFBUTtHQUNaLFdBQVcsVUFBVTtJQUNuQixJQUFJLGlCQUFpQixrQkFBa0IsTUFBTSxRQUMzQyxLQUFLLFNBQVM7S0FDWixHQUFHLEtBQUtHO0tBQ1IsYUFBYTtJQUNmLENBQUM7SUFFSCxnQkFBZ0IsTUFBTTtHQUN4QjtHQUNBLFNBQVMsY0FBYyxVQUFVO0lBQy9CLEtBQUtGLFVBQVU7S0FBRSxNQUFNO0tBQVU7S0FBYztJQUFNLENBQUM7R0FDeEQ7R0FDQSxlQUFlO0lBQ2IsS0FBS0EsVUFBVSxFQUFFLE1BQU0sUUFBUSxDQUFDO0dBQ2xDO0dBQ0Esa0JBQWtCO0lBQ2hCLEtBQUtBLFVBQVUsRUFBRSxNQUFNLFdBQVcsQ0FBQztHQUNyQztHQUNBLE9BQU8sUUFBUSxRQUFRO0dBQ3ZCLFlBQVksUUFBUSxRQUFRO0dBQzVCLGFBQWEsUUFBUSxRQUFRO0dBQzdCLGNBQWM7RUFDaEIsQ0FBQztFQUNELElBQUk7R0FDRixNQUFNLE9BQU8sTUFBTSxLQUFLRCxTQUFTLE1BQU07R0FDdkMsSUFBSSxTQUFTLEtBQUssR0FBRztJQUVqQixRQUFRLE1BQ04seUlBQXlJLEtBQUssV0FDaEo7SUFFRixNQUFNLElBQUksTUFBTSxHQUFHLEtBQUssVUFBVSxtQkFBbUI7R0FDdkQ7R0FDQSxLQUFLLFFBQVEsSUFBSTtHQUNqQixLQUFLSixPQUFPLE9BQU8sWUFBWSxNQUFNLElBQUk7R0FDekMsS0FBS0EsT0FBTyxPQUFPLFlBQ2pCLE1BQ0EsS0FBSyxNQUFNLE9BQ1gsSUFDRjtHQUNBLE9BQU87RUFDVCxTQUFTLE9BQU87R0FDZCxJQUFJLGlCQUFpQixnQkFBZ0I7SUFDbkMsSUFBSSxNQUFNLFFBQ1IsT0FBTyxLQUFLSSxTQUFTO1NBQ2hCLElBQUksTUFBTSxRQUFRO0tBQ3ZCLElBQUksS0FBSyxNQUFNLFNBQVMsS0FBSyxHQUMzQixNQUFNO0tBRVIsT0FBTyxLQUFLLE1BQU07SUFDcEI7R0FDRjtHQUNBLEtBQUtDLFVBQVU7SUFDYixNQUFNO0lBQ047R0FDRixDQUFDO0dBQ0QsS0FBS0wsT0FBTyxPQUFPLFVBQ2pCLE9BQ0EsSUFDRjtHQUNBLEtBQUtBLE9BQU8sT0FBTyxZQUNqQixLQUFLLE1BQU0sTUFDWCxPQUNBLElBQ0Y7R0FDQSxNQUFNO0VBQ1IsVUFBVTtHQUNSLEtBQUssV0FBVztFQUNsQjtDQUNGO0NBQ0EsVUFBVSxRQUFRO0VBQ2hCLE1BQU0sV0FBVyxVQUFVO0dBQ3pCLFFBQVEsT0FBTyxNQUFmO0lBQ0UsS0FBSyxVQUNILE9BQU87S0FDTCxHQUFHO0tBQ0gsbUJBQW1CLE9BQU87S0FDMUIsb0JBQW9CLE9BQU87SUFDN0I7SUFDRixLQUFLLFNBQ0gsT0FBTztLQUNMLEdBQUc7S0FDSCxhQUFhO0lBQ2Y7SUFDRixLQUFLLFlBQ0gsT0FBTztLQUNMLEdBQUc7S0FDSCxhQUFhO0lBQ2Y7SUFDRixLQUFLLFNBQ0gsT0FBTztLQUNMLEdBQUc7S0FDSCxHQUFHLFdBQVcsTUFBTSxNQUFNLEtBQUssT0FBTztLQUN0QyxXQUFXLE9BQU8sUUFBUTtJQUM1QjtJQUNGLEtBQUs7S0FDSCxNQUFNLFdBQVc7TUFDZixHQUFHO01BQ0gsR0FBRyxhQUFhLE9BQU8sTUFBTSxPQUFPLGFBQWE7TUFDakQsaUJBQWlCLE1BQU0sa0JBQWtCO01BQ3pDLEdBQUcsQ0FBQyxPQUFPLFVBQVU7T0FDbkIsYUFBYTtPQUNiLG1CQUFtQjtPQUNuQixvQkFBb0I7TUFDdEI7S0FDRjtLQUNBLEtBQUtPLGVBQWUsT0FBTyxTQUFTLFdBQVcsS0FBSztLQUNwRCxPQUFPO0lBQ1QsS0FBSztLQUNILE1BQU0sUUFBUSxPQUFPO0tBQ3JCLE9BQU87TUFDTCxHQUFHO01BQ0g7TUFDQSxrQkFBa0IsTUFBTSxtQkFBbUI7TUFDM0MsZ0JBQWdCLEtBQUssSUFBSTtNQUN6QixtQkFBbUIsTUFBTSxvQkFBb0I7TUFDN0Msb0JBQW9CO01BQ3BCLGFBQWE7TUFDYixRQUFRO01BR1IsZUFBZTtLQUNqQjtJQUNGLEtBQUssY0FDSCxPQUFPO0tBQ0wsR0FBRztLQUNILGVBQWU7SUFDakI7SUFDRixLQUFLLFlBQ0gsT0FBTztLQUNMLEdBQUc7S0FDSCxHQUFHLE9BQU87SUFDWjtHQUNKO0VBQ0Y7RUFDQSxLQUFLLFFBQVEsUUFBUSxLQUFLLEtBQUs7RUFDL0IsY0FBYyxZQUFZO0dBQ3hCLEtBQUssVUFBVSxTQUFTLGFBQWE7SUFDbkMsU0FBUyxjQUFjO0dBQ3pCLENBQUM7R0FDRCxLQUFLUCxPQUFPLE9BQU87SUFBRSxPQUFPO0lBQU0sTUFBTTtJQUFXO0dBQU8sQ0FBQztFQUM3RCxDQUFDO0NBQ0g7QUFDRjtBQUNBLFNBQVMsV0FBVyxNQUFNLFNBQVM7Q0FDakMsT0FBTztFQUNMLG1CQUFtQjtFQUNuQixvQkFBb0I7RUFDcEIsYUFBYSxTQUFTLFFBQVEsV0FBVyxJQUFJLGFBQWE7RUFDMUQsR0FBRyxTQUFTLEtBQUssS0FBSztHQUNwQixPQUFPO0dBQ1AsUUFBUTtFQUNWO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsYUFBYSxNQUFNLGVBQWU7Q0FDekMsT0FBTztFQUNMO0VBQ0EsZUFBZSxpQkFBaUIsS0FBSyxJQUFJO0VBQ3pDLE9BQU87RUFDUCxlQUFlO0VBQ2YsUUFBUTtDQUNWO0FBQ0Y7QUFDQSxTQUFTRSxrQkFBZ0IsU0FBUztDQUNoQyxNQUFNLE9BQU8sT0FBTyxRQUFRLGdCQUFnQixhQUFhLFFBQVEsWUFBWSxJQUFJLFFBQVE7Q0FDekYsTUFBTSxVQUFVLFNBQVMsS0FBSztDQUM5QixNQUFNLHVCQUF1QixVQUFVLE9BQU8sUUFBUSx5QkFBeUIsYUFBYSxRQUFRLHFCQUFxQixJQUFJLFFBQVEsdUJBQXVCO0NBQzVKLE9BQU87RUFDTDtFQUNBLGlCQUFpQjtFQUNqQixlQUFlLFVBQVUsd0JBQXdCLEtBQUssSUFBSSxJQUFJO0VBQzlELE9BQU87RUFDUCxrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLG1CQUFtQjtFQUNuQixvQkFBb0I7RUFDcEIsV0FBVztFQUNYLGVBQWU7RUFDZixRQUFRLFVBQVUsWUFBWTtFQUM5QixhQUFhO0NBQ2Y7QUFDRjs7O0FDL2FBLElBQUksZ0JBQWdCLGNBQWMsYUFBYTtDQUM3QyxZQUFZLFFBQVEsU0FBUztFQUMzQixNQUFNO0VBQ04sS0FBSyxVQUFVO0VBQ2YsS0FBS00sVUFBVTtFQUNmLEtBQUtDLGVBQWU7RUFDcEIsS0FBS0MsbUJBQW1CLGdCQUFnQjtFQUN4QyxLQUFLLFlBQVk7RUFDakIsS0FBSyxXQUFXLE9BQU87Q0FDekI7Q0FDQTtDQUNBLGdCQUFnQixLQUFLO0NBQ3JCLDRCQUE0QixLQUFLO0NBQ2pDLGlCQUFpQixLQUFLO0NBQ3RCO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUdBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsZ0NBQWdDLElBQUksSUFBSTtDQUN4QyxjQUFjO0VBQ1osS0FBSyxVQUFVLEtBQUssUUFBUSxLQUFLLElBQUk7Q0FDdkM7Q0FDQSxjQUFjO0VBQ1osSUFBSSxLQUFLLFVBQVUsU0FBUyxHQUFHO0dBQzdCLEtBQUtDLGNBQWMsWUFBWSxJQUFJO0dBQ25DLElBQUksbUJBQW1CLEtBQUtBLGVBQWUsS0FBSyxPQUFPLEdBQ3JELEtBQUtDLGNBQWM7UUFFbkIsS0FBSyxhQUFhO0dBRXBCLEtBQUtDLGNBQWM7RUFDckI7Q0FDRjtDQUNBLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxLQUFLLGFBQWEsR0FDckIsS0FBSyxRQUFRO0NBRWpCO0NBQ0EseUJBQXlCO0VBQ3ZCLE9BQU8sY0FDTCxLQUFLRixlQUNMLEtBQUssU0FDTCxLQUFLLFFBQVEsa0JBQ2Y7Q0FDRjtDQUNBLDJCQUEyQjtFQUN6QixPQUFPLGNBQ0wsS0FBS0EsZUFDTCxLQUFLLFNBQ0wsS0FBSyxRQUFRLG9CQUNmO0NBQ0Y7Q0FDQSxVQUFVO0VBQ1IsS0FBSyw0QkFBNEIsSUFBSSxJQUFJO0VBQ3pDLEtBQUtHLG1CQUFtQjtFQUN4QixLQUFLQyxzQkFBc0I7RUFDM0IsS0FBS0osY0FBYyxlQUFlLElBQUk7Q0FDeEM7Q0FDQSxXQUFXLFNBQVM7RUFDbEIsTUFBTSxjQUFjLEtBQUs7RUFDekIsTUFBTSxZQUFZLEtBQUtBO0VBQ3ZCLEtBQUssVUFBVSxLQUFLSCxRQUFRLG9CQUFvQixPQUFPO0VBQ3ZELElBQUksS0FBSyxRQUFRLFlBQVksS0FBSyxLQUFLLE9BQU8sS0FBSyxRQUFRLFlBQVksYUFBYSxPQUFPLEtBQUssUUFBUSxZQUFZLGNBQWMsT0FBTyxvQkFBb0IsS0FBSyxRQUFRLFNBQVMsS0FBS0csYUFBYSxNQUFNLFdBQ3pNLE1BQU0sSUFBSSxNQUNSLHVFQUNGO0VBRUYsS0FBS0ssYUFBYTtFQUNsQixLQUFLTCxjQUFjLFdBQVcsS0FBSyxPQUFPO0VBQzFDLElBQUksWUFBWSxjQUFjLENBQUMsb0JBQW9CLEtBQUssU0FBUyxXQUFXLEdBQzFFLEtBQUtILFFBQVEsY0FBYyxDQUFDLENBQUMsT0FBTztHQUNsQyxNQUFNO0dBQ04sT0FBTyxLQUFLRztHQUNaLFVBQVU7RUFDWixDQUFDO0VBRUgsTUFBTSxVQUFVLEtBQUssYUFBYTtFQUNsQyxJQUFJLFdBQVcsc0JBQ2IsS0FBS0EsZUFDTCxXQUNBLEtBQUssU0FDTCxXQUNGLEdBQ0UsS0FBS0MsY0FBYztFQUVyQixLQUFLLGFBQWE7RUFDbEIsSUFBSSxZQUFZLEtBQUtELGtCQUFrQixhQUFhLG9CQUFvQixLQUFLLFFBQVEsU0FBUyxLQUFLQSxhQUFhLE1BQU0sb0JBQW9CLFlBQVksU0FBUyxLQUFLQSxhQUFhLEtBQUssaUJBQWlCLEtBQUssUUFBUSxXQUFXLEtBQUtBLGFBQWEsTUFBTSxpQkFBaUIsWUFBWSxXQUFXLEtBQUtBLGFBQWEsSUFDL1MsS0FBS00sb0JBQW9CO0VBRTNCLE1BQU0sc0JBQXNCLEtBQUtDLHdCQUF3QjtFQUN6RCxJQUFJLFlBQVksS0FBS1Asa0JBQWtCLGFBQWEsb0JBQW9CLEtBQUssUUFBUSxTQUFTLEtBQUtBLGFBQWEsTUFBTSxvQkFBb0IsWUFBWSxTQUFTLEtBQUtBLGFBQWEsS0FBSyx3QkFBd0IsS0FBS1EsMEJBQ2pOLEtBQUtDLHVCQUF1QixtQkFBbUI7Q0FFbkQ7Q0FDQSxvQkFBb0IsU0FBUztFQUMzQixNQUFNLFFBQVEsS0FBS1osUUFBUSxjQUFjLENBQUMsQ0FBQyxNQUFNLEtBQUtBLFNBQVMsT0FBTztFQUN0RSxNQUFNLFNBQVMsS0FBSyxhQUFhLE9BQU8sT0FBTztFQUMvQyxJQUFJLHNDQUFzQyxNQUFNLE1BQU0sR0FBRztHQUN2RCxLQUFLYSxpQkFBaUI7R0FDdEIsS0FBS0Msd0JBQXdCLEtBQUs7R0FDbEMsS0FBS0Msc0JBQXNCLEtBQUtaLGNBQWM7RUFDaEQ7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxtQkFBbUI7RUFDakIsT0FBTyxLQUFLVTtDQUNkO0NBQ0EsWUFBWSxRQUFRLGVBQWU7RUFDakMsT0FBTyxJQUFJLE1BQU0sUUFBUSxFQUN2QixNQUFNLFFBQVEsUUFBUTtHQUNwQixLQUFLLFVBQVUsR0FBRztHQUNsQixnQkFBZ0IsR0FBRztHQUNuQixJQUFJLFFBQVEsV0FBVztJQUNyQixLQUFLLFVBQVUsTUFBTTtJQUNyQixJQUFJLENBQUMsS0FBSyxRQUFRLGlDQUFpQyxLQUFLWCxpQkFBaUIsV0FBVyxXQUNsRixLQUFLQSxpQkFBaUIsdUJBQ3BCLElBQUksTUFDRiwyREFDRixDQUNGO0dBRUo7R0FDQSxPQUFPLFFBQVEsSUFBSSxRQUFRLEdBQUc7RUFDaEMsRUFDRixDQUFDO0NBQ0g7Q0FDQSxVQUFVLEtBQUs7RUFDYixLQUFLYyxjQUFjLElBQUksR0FBRztDQUM1QjtDQUNBLGtCQUFrQjtFQUNoQixPQUFPLEtBQUtiO0NBQ2Q7Q0FDQSxRQUFRLEVBQUUsR0FBRyxZQUFZLENBQUMsR0FBRztFQUMzQixPQUFPLEtBQUssTUFBTSxFQUNoQixHQUFHLFFBQ0wsQ0FBQztDQUNIO0NBQ0EsZ0JBQWdCLFNBQVM7RUFDdkIsTUFBTSxtQkFBbUIsS0FBS0gsUUFBUSxvQkFBb0IsT0FBTztFQUNqRSxNQUFNLFFBQVEsS0FBS0EsUUFBUSxjQUFjLENBQUMsQ0FBQyxNQUFNLEtBQUtBLFNBQVMsZ0JBQWdCO0VBQy9FLE9BQU8sTUFBTSxNQUFNLENBQUMsQ0FBQyxXQUFXLEtBQUssYUFBYSxPQUFPLGdCQUFnQixDQUFDO0NBQzVFO0NBQ0EsTUFBTSxjQUFjO0VBQ2xCLE9BQU8sS0FBS0ksY0FBYztHQUN4QixHQUFHO0dBQ0gsZUFBZSxhQUFhLGlCQUFpQjtFQUMvQyxDQUFDLENBQUMsQ0FBQyxXQUFXO0dBQ1osS0FBSyxhQUFhO0dBQ2xCLE9BQU8sS0FBS1M7RUFDZCxDQUFDO0NBQ0g7Q0FDQSxjQUFjLGNBQWM7RUFDMUIsS0FBS0wsYUFBYTtFQUNsQixJQUFJLFVBQVUsS0FBS0wsY0FBYyxNQUMvQixLQUFLLFNBQ0wsWUFDRjtFQUNBLElBQUksQ0FBQyxjQUFjLGNBQ2pCLFVBQVUsUUFBUSxNQUFNLElBQUk7RUFFOUIsT0FBTztDQUNUO0NBQ0Esc0JBQXNCO0VBQ3BCLEtBQUtHLG1CQUFtQjtFQUN4QixNQUFNLFlBQVksaUJBQ2hCLEtBQUssUUFBUSxXQUNiLEtBQUtILGFBQ1A7RUFDQSxJQUFJLG1CQUFtQixTQUFTLEtBQUssS0FBS1UsZUFBZSxXQUFXLENBQUMsZUFBZSxTQUFTLEdBQzNGO0VBR0YsTUFBTSxVQURPLGVBQWUsS0FBS0EsZUFBZSxlQUFlLFNBQzVDLElBQUk7RUFDdkIsS0FBS0ksa0JBQWtCLGVBQWUsaUJBQWlCO0dBQ3JELElBQUksQ0FBQyxLQUFLSixlQUFlLFNBQ3ZCLEtBQUssYUFBYTtFQUV0QixHQUFHLE9BQU87Q0FDWjtDQUNBLDBCQUEwQjtFQUN4QixRQUFRLE9BQU8sS0FBSyxRQUFRLG9CQUFvQixhQUFhLEtBQUssUUFBUSxnQkFBZ0IsS0FBS1YsYUFBYSxJQUFJLEtBQUssUUFBUSxvQkFBb0I7Q0FDbko7Q0FDQSx1QkFBdUIsY0FBYztFQUNuQyxLQUFLSSxzQkFBc0I7RUFDM0IsS0FBS0ksMEJBQTBCO0VBQy9CLElBQUksbUJBQW1CLFNBQVMsS0FBSyxvQkFBb0IsS0FBSyxRQUFRLFNBQVMsS0FBS1IsYUFBYSxNQUFNLFNBQVMsQ0FBQyxlQUFlLEtBQUtRLHVCQUF1QixLQUFLLEtBQUtBLDRCQUE0QixHQUNoTTtFQUVGLEtBQUtPLHFCQUFxQixlQUFlLGtCQUFrQjtHQUN6RCxJQUFJLEtBQUssUUFBUSwrQkFBK0IsYUFBYSxVQUFVLEdBQ3JFLEtBQUtkLGNBQWM7RUFFdkIsR0FBRyxLQUFLTyx1QkFBdUI7Q0FDakM7Q0FDQSxnQkFBZ0I7RUFDZCxLQUFLRixvQkFBb0I7RUFDekIsS0FBS0csdUJBQXVCLEtBQUtGLHdCQUF3QixDQUFDO0NBQzVEO0NBQ0EscUJBQXFCO0VBQ25CLElBQUksS0FBS08sb0JBQW9CLEtBQUssR0FBRztHQUNuQyxlQUFlLGFBQWEsS0FBS0EsZUFBZTtHQUNoRCxLQUFLQSxrQkFBa0IsS0FBSztFQUM5QjtDQUNGO0NBQ0Esd0JBQXdCO0VBQ3RCLElBQUksS0FBS0MsdUJBQXVCLEtBQUssR0FBRztHQUN0QyxlQUFlLGNBQWMsS0FBS0Esa0JBQWtCO0dBQ3BELEtBQUtBLHFCQUFxQixLQUFLO0VBQ2pDO0NBQ0Y7Q0FDQSxhQUFhLE9BQU8sU0FBUztFQUMzQixNQUFNLFlBQVksS0FBS2Y7RUFDdkIsTUFBTSxjQUFjLEtBQUs7RUFDekIsTUFBTSxhQUFhLEtBQUtVO0VBQ3hCLE1BQU0sa0JBQWtCLEtBQUtFO0VBQzdCLE1BQU0sb0JBQW9CLEtBQUtEO0VBRS9CLE1BQU0sb0JBRGMsVUFBVSxZQUNVLE1BQU0sUUFBUSxLQUFLSztFQUMzRCxNQUFNLEVBQUUsVUFBVTtFQUNsQixJQUFJLFdBQVcsRUFBRSxHQUFHLE1BQU07RUFDMUIsSUFBSSxvQkFBb0I7RUFDeEIsSUFBSTtFQUNKLElBQUksUUFBUSxvQkFBb0I7R0FDOUIsTUFBTSxVQUFVLEtBQUssYUFBYTtHQUNsQyxNQUFNLGVBQWUsQ0FBQyxXQUFXLG1CQUFtQixPQUFPLE9BQU87R0FDbEUsTUFBTSxrQkFBa0IsV0FBVyxzQkFBc0IsT0FBTyxXQUFXLFNBQVMsV0FBVztHQUMvRixJQUFJLGdCQUFnQixpQkFDbEIsV0FBVztJQUNULEdBQUc7SUFDSCxHQUFHLFdBQVcsTUFBTSxNQUFNLE1BQU0sT0FBTztHQUN6QztHQUVGLElBQUksUUFBUSx1QkFBdUIsZUFDakMsU0FBUyxjQUFjO0VBRTNCO0VBQ0EsSUFBSSxFQUFFLE9BQU8sZ0JBQWdCLFdBQVc7RUFDeEMsT0FBTyxTQUFTO0VBQ2hCLElBQUksYUFBYTtFQUNqQixJQUFJLFFBQVEsb0JBQW9CLEtBQUssS0FBSyxTQUFTLEtBQUssS0FBSyxXQUFXLFdBQVc7R0FDakYsSUFBSTtHQUNKLElBQUksWUFBWSxxQkFBcUIsUUFBUSxvQkFBb0IsbUJBQW1CLGlCQUFpQjtJQUNuRyxrQkFBa0IsV0FBVztJQUM3QixhQUFhO0dBQ2YsT0FDRSxrQkFBa0IsT0FBTyxRQUFRLG9CQUFvQixhQUFhLFFBQVEsZ0JBQ3hFLEtBQUtDLDJCQUEyQixNQUFNLE1BQ3RDLEtBQUtBLHlCQUNQLElBQUksUUFBUTtHQUVkLElBQUksb0JBQW9CLEtBQUssR0FBRztJQUM5QixTQUFTO0lBQ1QsT0FBTyxZQUNMLFlBQVksTUFDWixpQkFDQSxPQUNGO0lBQ0Esb0JBQW9CO0dBQ3RCO0VBQ0Y7RUFDQSxJQUFJLFFBQVEsVUFBVSxTQUFTLEtBQUssS0FBSyxDQUFDLFlBQVk7R0FDcEQsSUFBSSxjQUFjLFNBQVMsaUJBQWlCLFFBQVEsUUFBUSxXQUFXLEtBQUtDLFdBQzFFLE9BQU8sS0FBS0M7UUFFWixJQUFJO0lBQ0YsS0FBS0QsWUFBWSxRQUFRO0lBQ3pCLE9BQU8sUUFBUSxPQUFPLElBQUk7SUFDMUIsT0FBTyxZQUFZLFlBQVksTUFBTSxNQUFNLE9BQU87SUFDbEQsS0FBS0MsZ0JBQWdCO0lBQ3JCLEtBQUtyQixlQUFlO0dBQ3RCLFNBQVMsYUFBYTtJQUNwQixLQUFLQSxlQUFlO0dBQ3RCO0VBRUo7RUFDQSxJQUFJLEtBQUtBLGNBQWM7R0FDckIsUUFBUSxLQUFLQTtHQUNiLE9BQU8sS0FBS3FCO0dBQ1osaUJBQWlCLEtBQUssSUFBSTtHQUMxQixTQUFTO0VBQ1g7RUFDQSxNQUFNLGFBQWEsU0FBUyxnQkFBZ0I7RUFDNUMsTUFBTSxZQUFZLFdBQVc7RUFDN0IsTUFBTSxVQUFVLFdBQVc7RUFDM0IsTUFBTSxZQUFZLGFBQWE7RUFDL0IsTUFBTSxVQUFVLFNBQVMsS0FBSztFQTZCOUIsTUFBTSxhQUFhO0dBM0JqQjtHQUNBLGFBQWEsU0FBUztHQUN0QjtHQUNBLFdBQVcsV0FBVztHQUN0QjtHQUNBLGtCQUFrQjtHQUNsQjtHQUNBO0dBQ0EsZUFBZSxTQUFTO0dBQ3hCO0dBQ0E7R0FDQSxjQUFjLFNBQVM7R0FDdkIsZUFBZSxTQUFTO0dBQ3hCLGtCQUFrQixTQUFTO0dBQzNCLFdBQVcsTUFBTSxVQUFVO0dBQzNCLHFCQUFxQixTQUFTLGtCQUFrQixrQkFBa0IsbUJBQW1CLFNBQVMsbUJBQW1CLGtCQUFrQjtHQUNuSTtHQUNBLGNBQWMsY0FBYyxDQUFDO0dBQzdCLGdCQUFnQixXQUFXLENBQUM7R0FDNUIsVUFBVSxTQUFTLGdCQUFnQjtHQUNuQztHQUNBLGdCQUFnQixXQUFXO0dBQzNCLFNBQVMsUUFBUSxPQUFPLE9BQU87R0FDL0IsU0FBUyxLQUFLO0dBQ2QsU0FBUyxLQUFLcEI7R0FDZCxXQUFXLG9CQUFvQixRQUFRLFNBQVMsS0FBSyxNQUFNO0VBRXJDO0VBQ3hCLElBQUksS0FBSyxRQUFRLCtCQUErQjtHQUM5QyxNQUFNLGdCQUFnQixXQUFXLFNBQVMsS0FBSztHQUMvQyxNQUFNLHFCQUFxQixXQUFXLFdBQVcsV0FBVyxDQUFDO0dBQzdELE1BQU0sOEJBQThCLGFBQWE7SUFDL0MsSUFBSSxvQkFDRixTQUFTLE9BQU8sV0FBVyxLQUFLO1NBQzNCLElBQUksZUFDVCxTQUFTLFFBQVEsV0FBVyxJQUFJO0dBRXBDO0dBQ0EsTUFBTSx5QkFBeUI7SUFDN0IsTUFBTSxVQUFVLEtBQUtBLG1CQUFtQixXQUFXLFVBQVUsZ0JBQWdCO0lBQzdFLDJCQUEyQixPQUFPO0dBQ3BDO0dBQ0EsTUFBTSxlQUFlLEtBQUtBO0dBQzFCLFFBQVEsYUFBYSxRQUFyQjtJQUNFLEtBQUs7S0FDSCxJQUFJLE1BQU0sY0FBYyxVQUFVLFdBQ2hDLDJCQUEyQixZQUFZO0tBRXpDO0lBQ0YsS0FBSztLQUNILElBQUksc0JBQXNCLFdBQVcsU0FBUyxhQUFhLE9BQ3pELGlCQUFpQjtLQUVuQjtJQUNGLEtBQUssWUFDSCxJQUFJLENBQUMsc0JBQXNCLFdBQVcsVUFBVSxhQUFhLFFBQzNELGlCQUFpQjtHQUd2QjtFQUNGO0VBQ0EsT0FBTztDQUNUO0NBQ0EsZUFBZTtFQUNiLE1BQU0sYUFBYSxLQUFLVztFQUN4QixNQUFNLGFBQWEsS0FBSyxhQUFhLEtBQUtWLGVBQWUsS0FBSyxPQUFPO0VBQ3JFLEtBQUtZLHNCQUFzQixLQUFLWixjQUFjO0VBQzlDLEtBQUtXLHdCQUF3QixLQUFLO0VBQ2xDLElBQUksS0FBS0Msb0JBQW9CLFNBQVMsS0FBSyxHQUN6QyxLQUFLSyw0QkFBNEIsS0FBS2pCO0VBRXhDLElBQUksb0JBQW9CLFlBQVksVUFBVSxHQUM1QztFQUVGLEtBQUtVLGlCQUFpQjtFQUN0QixNQUFNLDhCQUE4QjtHQUNsQyxJQUFJLENBQUMsWUFDSCxPQUFPO0dBRVQsTUFBTSxFQUFFLHdCQUF3QixLQUFLO0dBQ3JDLE1BQU0sMkJBQTJCLE9BQU8sd0JBQXdCLGFBQWEsb0JBQW9CLElBQUk7R0FDckcsSUFBSSw2QkFBNkIsU0FBUyxDQUFDLDRCQUE0QixDQUFDLEtBQUtHLGNBQWMsTUFDekYsT0FBTztHQUVULE1BQU0sZ0JBQWdCLElBQUksSUFDeEIsNEJBQTRCLEtBQUtBLGFBQ25DO0dBQ0EsSUFBSSxLQUFLLFFBQVEsY0FDZixjQUFjLElBQUksT0FBTztHQUUzQixPQUFPLE9BQU8sS0FBSyxLQUFLSCxjQUFjLENBQUMsQ0FBQyxNQUFNLFFBQVE7SUFDcEQsTUFBTSxXQUFXO0lBRWpCLE9BRGdCLEtBQUtBLGVBQWUsY0FBYyxXQUFXLGFBQzNDLGNBQWMsSUFBSSxRQUFRO0dBQzlDLENBQUM7RUFDSDtFQUNBLEtBQUtVLFFBQVEsRUFBRSxXQUFXLHNCQUFzQixFQUFFLENBQUM7Q0FDckQ7Q0FDQSxlQUFlO0VBQ2IsTUFBTSxRQUFRLEtBQUt2QixRQUFRLGNBQWMsQ0FBQyxDQUFDLE1BQU0sS0FBS0EsU0FBUyxLQUFLLE9BQU87RUFDM0UsSUFBSSxVQUFVLEtBQUtHLGVBQ2pCO0VBRUYsTUFBTSxZQUFZLEtBQUtBO0VBQ3ZCLEtBQUtBLGdCQUFnQjtFQUNyQixLQUFLZ0IsNEJBQTRCLE1BQU07RUFDdkMsSUFBSSxLQUFLLGFBQWEsR0FBRztHQUN2QixXQUFXLGVBQWUsSUFBSTtHQUM5QixNQUFNLFlBQVksSUFBSTtFQUN4QjtDQUNGO0NBQ0EsZ0JBQWdCO0VBQ2QsS0FBSyxhQUFhO0VBQ2xCLElBQUksS0FBSyxhQUFhLEdBQ3BCLEtBQUtkLGNBQWM7Q0FFdkI7Q0FDQSxRQUFRLGVBQWU7RUFDckIsY0FBYyxZQUFZO0dBQ3hCLElBQUksY0FBYyxXQUNoQixLQUFLLFVBQVUsU0FBUyxhQUFhO0lBQ25DLFNBQVMsS0FBS1EsY0FBYztHQUM5QixDQUFDO0dBRUgsS0FBS2IsUUFBUSxjQUFjLENBQUMsQ0FBQyxPQUFPO0lBQ2xDLE9BQU8sS0FBS0c7SUFDWixNQUFNO0dBQ1IsQ0FBQztFQUNILENBQUM7Q0FDSDtBQUNGO0FBQ0EsU0FBUyxrQkFBa0IsT0FBTyxTQUFTO0NBQ3pDLE9BQU8sb0JBQW9CLFFBQVEsU0FBUyxLQUFLLE1BQU0sU0FBUyxNQUFNLE1BQU0sU0FBUyxLQUFLLEtBQUssRUFBRSxNQUFNLE1BQU0sV0FBVyxXQUFXLG9CQUFvQixRQUFRLGNBQWMsS0FBSyxNQUFNO0FBQzFMO0FBQ0EsU0FBUyxtQkFBbUIsT0FBTyxTQUFTO0NBQzFDLE9BQU8sa0JBQWtCLE9BQU8sT0FBTyxLQUFLLE1BQU0sTUFBTSxTQUFTLEtBQUssS0FBSyxjQUFjLE9BQU8sU0FBUyxRQUFRLGNBQWM7QUFDakk7QUFDQSxTQUFTLGNBQWMsT0FBTyxTQUFTLE9BQU87Q0FDNUMsSUFBSSxvQkFBb0IsUUFBUSxTQUFTLEtBQUssTUFBTSxTQUFTLGlCQUFpQixRQUFRLFdBQVcsS0FBSyxNQUFNLFVBQVU7RUFDcEgsTUFBTSxRQUFRLE9BQU8sVUFBVSxhQUFhLE1BQU0sS0FBSyxJQUFJO0VBQzNELE9BQU8sVUFBVSxZQUFZLFVBQVUsU0FBUyxRQUFRLE9BQU8sT0FBTztDQUN4RTtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsc0JBQXNCLE9BQU8sV0FBVyxTQUFTLGFBQWE7Q0FDckUsUUFBUSxVQUFVLGFBQWEsb0JBQW9CLFlBQVksU0FBUyxLQUFLLE1BQU0sV0FBVyxDQUFDLFFBQVEsWUFBWSxNQUFNLE1BQU0sV0FBVyxZQUFZLFFBQVEsT0FBTyxPQUFPO0FBQzlLO0FBQ0EsU0FBUyxRQUFRLE9BQU8sU0FBUztDQUMvQixPQUFPLG9CQUFvQixRQUFRLFNBQVMsS0FBSyxNQUFNLFNBQVMsTUFBTSxjQUFjLGlCQUFpQixRQUFRLFdBQVcsS0FBSyxDQUFDO0FBQ2hJO0FBQ0EsU0FBUyxzQ0FBc0MsVUFBVSxrQkFBa0I7Q0FDekUsSUFBSSxDQUFDLG9CQUFvQixTQUFTLGlCQUFpQixHQUFHLGdCQUFnQixHQUNwRSxPQUFPO0NBRVQsT0FBTztBQUNUOzs7QUNoZEEsSUFBSSx3QkFBd0IsY0FBYyxjQUFjO0NBQ3RELFlBQVksUUFBUSxTQUFTO0VBQzNCLE1BQU0sUUFBUSxPQUFPO0NBQ3ZCO0NBQ0EsY0FBYztFQUNaLE1BQU0sWUFBWTtFQUNsQixLQUFLLGdCQUFnQixLQUFLLGNBQWMsS0FBSyxJQUFJO0VBQ2pELEtBQUssb0JBQW9CLEtBQUssa0JBQWtCLEtBQUssSUFBSTtDQUMzRDtDQUNBLFdBQVcsU0FBUztFQUNsQixRQUFRLFFBQVE7RUFDaEIsTUFBTSxXQUFXLE9BQU87Q0FDMUI7Q0FDQSxvQkFBb0IsU0FBUztFQUMzQixRQUFRLFFBQVE7RUFDaEIsT0FBTyxNQUFNLG9CQUFvQixPQUFPO0NBQzFDO0NBQ0EsY0FBYyxTQUFTO0VBQ3JCLE9BQU8sS0FBSyxNQUFNO0dBQ2hCLEdBQUc7R0FDSCxNQUFNLEVBQ0osV0FBVyxFQUFFLFdBQVcsVUFBVSxFQUNwQztFQUNGLENBQUM7Q0FDSDtDQUNBLGtCQUFrQixTQUFTO0VBQ3pCLE9BQU8sS0FBSyxNQUFNO0dBQ2hCLEdBQUc7R0FDSCxNQUFNLEVBQ0osV0FBVyxFQUFFLFdBQVcsV0FBVyxFQUNyQztFQUNGLENBQUM7Q0FDSDtDQUNBLGFBQWEsT0FBTyxTQUFTO0VBQzNCLE1BQU0sRUFBRSxVQUFVO0VBQ2xCLE1BQU0sZUFBZSxNQUFNLGFBQWEsT0FBTyxPQUFPO0VBQ3RELE1BQU0sRUFBRSxZQUFZLGNBQWMsU0FBUyxtQkFBbUI7RUFDOUQsTUFBTSxpQkFBaUIsTUFBTSxXQUFXLFdBQVc7RUFDbkQsTUFBTSx1QkFBdUIsV0FBVyxtQkFBbUI7RUFDM0QsTUFBTSxxQkFBcUIsY0FBYyxtQkFBbUI7RUFDNUQsTUFBTSwyQkFBMkIsV0FBVyxtQkFBbUI7RUFDL0QsTUFBTSx5QkFBeUIsY0FBYyxtQkFBbUI7RUFjaEUsT0FBTztHQVpMLEdBQUc7R0FDSCxlQUFlLEtBQUs7R0FDcEIsbUJBQW1CLEtBQUs7R0FDeEIsYUFBYSxZQUFZLFNBQVMsTUFBTSxJQUFJO0dBQzVDLGlCQUFpQixnQkFBZ0IsU0FBUyxNQUFNLElBQUk7R0FDcEQ7R0FDQTtHQUNBO0dBQ0E7R0FDQSxnQkFBZ0Isa0JBQWtCLENBQUMsd0JBQXdCLENBQUM7R0FDNUQsY0FBYyxnQkFBZ0IsQ0FBQyxzQkFBc0IsQ0FBQztFQUU1QztDQUNkO0FBQ0Y7OztBQ3hEQSxJQUFJLFdBQVcsY0FBYyxVQUFVO0NBQ3JDO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsWUFBWSxRQUFRO0VBQ2xCLE1BQU07RUFDTixLQUFLcUIsVUFBVSxPQUFPO0VBQ3RCLEtBQUssYUFBYSxPQUFPO0VBQ3pCLEtBQUtDLGlCQUFpQixPQUFPO0VBQzdCLEtBQUtDLGFBQWEsQ0FBQztFQUNuQixLQUFLLFFBQVEsT0FBTyxTQUFTLGdCQUFnQjtFQUM3QyxLQUFLLFdBQVcsT0FBTyxPQUFPO0VBQzlCLEtBQUssV0FBVztDQUNsQjtDQUNBLFdBQVcsU0FBUztFQUNsQixLQUFLLFVBQVU7RUFDZixLQUFLLGFBQWEsS0FBSyxRQUFRLE1BQU07Q0FDdkM7Q0FDQSxJQUFJLE9BQU87RUFDVCxPQUFPLEtBQUssUUFBUTtDQUN0QjtDQUNBLFlBQVksVUFBVTtFQUNwQixJQUFJLENBQUMsS0FBS0EsV0FBVyxTQUFTLFFBQVEsR0FBRztHQUN2QyxLQUFLQSxXQUFXLEtBQUssUUFBUTtHQUM3QixLQUFLLGVBQWU7R0FDcEIsS0FBS0QsZUFBZSxPQUFPO0lBQ3pCLE1BQU07SUFDTixVQUFVO0lBQ1Y7R0FDRixDQUFDO0VBQ0g7Q0FDRjtDQUNBLGVBQWUsVUFBVTtFQUN2QixLQUFLQyxhQUFhLEtBQUtBLFdBQVcsUUFBUSxNQUFNLE1BQU0sUUFBUTtFQUM5RCxLQUFLLFdBQVc7RUFDaEIsS0FBS0QsZUFBZSxPQUFPO0dBQ3pCLE1BQU07R0FDTixVQUFVO0dBQ1Y7RUFDRixDQUFDO0NBQ0g7Q0FDQSxpQkFBaUI7RUFDZixJQUFJLENBQUMsS0FBS0MsV0FBVyxRQUFRO0dBQzNCLElBQUksS0FBSyxNQUFNLFdBQVcsV0FDeEIsS0FBSyxXQUFXO1FBRWhCLEtBQUtELGVBQWUsT0FBTyxJQUFJO0VBRW5DO0NBQ0Y7Q0FDQSxXQUFXO0VBQ1QsT0FBTyxLQUFLRSxVQUFVLFNBQVMsS0FDL0IsS0FBSyxRQUFRLEtBQUssTUFBTSxTQUFTO0NBQ25DO0NBQ0EsTUFBTSxRQUFRLFdBQVc7RUFDdkIsTUFBTSxtQkFBbUI7R0FDdkIsS0FBS0MsVUFBVSxFQUFFLE1BQU0sV0FBVyxDQUFDO0VBQ3JDO0VBQ0EsTUFBTSxvQkFBb0I7R0FDeEIsUUFBUSxLQUFLSjtHQUNiLE1BQU0sS0FBSyxRQUFRO0dBQ25CLGFBQWEsS0FBSyxRQUFRO0VBQzVCO0VBQ0EsS0FBS0csV0FBVyxjQUFjO0dBQzVCLFVBQVU7SUFDUixJQUFJLENBQUMsS0FBSyxRQUFRLFlBQ2hCLE9BQU8sUUFBUSx1QkFBTyxJQUFJLE1BQU0scUJBQXFCLENBQUM7SUFFeEQsT0FBTyxLQUFLLFFBQVEsV0FBVyxXQUFXLGlCQUFpQjtHQUM3RDtHQUNBLFNBQVMsY0FBYyxVQUFVO0lBQy9CLEtBQUtDLFVBQVU7S0FBRSxNQUFNO0tBQVU7S0FBYztJQUFNLENBQUM7R0FDeEQ7R0FDQSxlQUFlO0lBQ2IsS0FBS0EsVUFBVSxFQUFFLE1BQU0sUUFBUSxDQUFDO0dBQ2xDO0dBQ0E7R0FDQSxPQUFPLEtBQUssUUFBUSxTQUFTO0dBQzdCLFlBQVksS0FBSyxRQUFRO0dBQ3pCLGFBQWEsS0FBSyxRQUFRO0dBQzFCLGNBQWMsS0FBS0gsZUFBZSxPQUFPLElBQUk7RUFDL0MsQ0FBQztFQUNELE1BQU0sV0FBVyxLQUFLLE1BQU0sV0FBVztFQUN2QyxNQUFNLFdBQVcsQ0FBQyxLQUFLRSxTQUFTLFNBQVM7RUFDekMsSUFBSTtHQUNGLElBQUksVUFDRixXQUFXO1FBQ047SUFDTCxLQUFLQyxVQUFVO0tBQUUsTUFBTTtLQUFXO0tBQVc7SUFBUyxDQUFDO0lBQ3ZELElBQUksS0FBS0gsZUFBZSxPQUFPLFVBQzdCLE1BQU0sS0FBS0EsZUFBZSxPQUFPLFNBQy9CLFdBQ0EsTUFDQSxpQkFDRjtJQUVGLE1BQU0sVUFBVSxNQUFNLEtBQUssUUFBUSxXQUNqQyxXQUNBLGlCQUNGO0lBQ0EsSUFBSSxZQUFZLEtBQUssTUFBTSxTQUN6QixLQUFLRyxVQUFVO0tBQ2IsTUFBTTtLQUNOO0tBQ0E7S0FDQTtJQUNGLENBQUM7R0FFTDtHQUNBLE1BQU0sT0FBTyxNQUFNLEtBQUtELFNBQVMsTUFBTTtHQUN2QyxNQUFNLEtBQUtGLGVBQWUsT0FBTyxZQUMvQixNQUNBLFdBQ0EsS0FBSyxNQUFNLFNBQ1gsTUFDQSxpQkFDRjtHQUNBLE1BQU0sS0FBSyxRQUFRLFlBQ2pCLE1BQ0EsV0FDQSxLQUFLLE1BQU0sU0FDWCxpQkFDRjtHQUNBLE1BQU0sS0FBS0EsZUFBZSxPQUFPLFlBQy9CLE1BQ0EsTUFDQSxLQUFLLE1BQU0sV0FDWCxLQUFLLE1BQU0sU0FDWCxNQUNBLGlCQUNGO0dBQ0EsTUFBTSxLQUFLLFFBQVEsWUFDakIsTUFDQSxNQUNBLFdBQ0EsS0FBSyxNQUFNLFNBQ1gsaUJBQ0Y7R0FDQSxLQUFLRyxVQUFVO0lBQUUsTUFBTTtJQUFXO0dBQUssQ0FBQztHQUN4QyxPQUFPO0VBQ1QsU0FBUyxPQUFPO0dBQ2QsSUFBSTtJQUNGLE1BQU0sS0FBS0gsZUFBZSxPQUFPLFVBQy9CLE9BQ0EsV0FDQSxLQUFLLE1BQU0sU0FDWCxNQUNBLGlCQUNGO0dBQ0YsU0FBUyxHQUFHO0lBQ1YsUUFBYSxPQUFPLENBQUM7R0FDdkI7R0FDQSxJQUFJO0lBQ0YsTUFBTSxLQUFLLFFBQVEsVUFDakIsT0FDQSxXQUNBLEtBQUssTUFBTSxTQUNYLGlCQUNGO0dBQ0YsU0FBUyxHQUFHO0lBQ1YsUUFBYSxPQUFPLENBQUM7R0FDdkI7R0FDQSxJQUFJO0lBQ0YsTUFBTSxLQUFLQSxlQUFlLE9BQU8sWUFDL0IsS0FBSyxHQUNMLE9BQ0EsS0FBSyxNQUFNLFdBQ1gsS0FBSyxNQUFNLFNBQ1gsTUFDQSxpQkFDRjtHQUNGLFNBQVMsR0FBRztJQUNWLFFBQWEsT0FBTyxDQUFDO0dBQ3ZCO0dBQ0EsSUFBSTtJQUNGLE1BQU0sS0FBSyxRQUFRLFlBQ2pCLEtBQUssR0FDTCxPQUNBLFdBQ0EsS0FBSyxNQUFNLFNBQ1gsaUJBQ0Y7R0FDRixTQUFTLEdBQUc7SUFDVixRQUFhLE9BQU8sQ0FBQztHQUN2QjtHQUNBLEtBQUtHLFVBQVU7SUFBRSxNQUFNO0lBQVM7R0FBTSxDQUFDO0dBQ3ZDLE1BQU07RUFDUixVQUFVO0dBQ1IsS0FBS0gsZUFBZSxRQUFRLElBQUk7RUFDbEM7Q0FDRjtDQUNBLFVBQVUsUUFBUTtFQUNoQixNQUFNLFdBQVcsVUFBVTtHQUN6QixRQUFRLE9BQU8sTUFBZjtJQUNFLEtBQUssVUFDSCxPQUFPO0tBQ0wsR0FBRztLQUNILGNBQWMsT0FBTztLQUNyQixlQUFlLE9BQU87SUFDeEI7SUFDRixLQUFLLFNBQ0gsT0FBTztLQUNMLEdBQUc7S0FDSCxVQUFVO0lBQ1o7SUFDRixLQUFLLFlBQ0gsT0FBTztLQUNMLEdBQUc7S0FDSCxVQUFVO0lBQ1o7SUFDRixLQUFLLFdBQ0gsT0FBTztLQUNMLEdBQUc7S0FDSCxTQUFTLE9BQU87S0FDaEIsTUFBTSxLQUFLO0tBQ1gsY0FBYztLQUNkLGVBQWU7S0FDZixPQUFPO0tBQ1AsVUFBVSxPQUFPO0tBQ2pCLFFBQVE7S0FDUixXQUFXLE9BQU87S0FDbEIsYUFBYSxLQUFLLElBQUk7SUFDeEI7SUFDRixLQUFLLFdBQ0gsT0FBTztLQUNMLEdBQUc7S0FDSCxNQUFNLE9BQU87S0FDYixjQUFjO0tBQ2QsZUFBZTtLQUNmLE9BQU87S0FDUCxRQUFRO0tBQ1IsVUFBVTtJQUNaO0lBQ0YsS0FBSyxTQUNILE9BQU87S0FDTCxHQUFHO0tBQ0gsTUFBTSxLQUFLO0tBQ1gsT0FBTyxPQUFPO0tBQ2QsY0FBYyxNQUFNLGVBQWU7S0FDbkMsZUFBZSxPQUFPO0tBQ3RCLFVBQVU7S0FDVixRQUFRO0lBQ1Y7R0FDSjtFQUNGO0VBQ0EsS0FBSyxRQUFRLFFBQVEsS0FBSyxLQUFLO0VBQy9CLGNBQWMsWUFBWTtHQUN4QixLQUFLQyxXQUFXLFNBQVMsYUFBYTtJQUNwQyxTQUFTLGlCQUFpQixNQUFNO0dBQ2xDLENBQUM7R0FDRCxLQUFLRCxlQUFlLE9BQU87SUFDekIsVUFBVTtJQUNWLE1BQU07SUFDTjtHQUNGLENBQUM7RUFDSCxDQUFDO0NBQ0g7QUFDRjtBQUNBLFNBQVMsa0JBQWtCO0NBQ3pCLE9BQU87RUFDTCxTQUFTLEtBQUs7RUFDZCxNQUFNLEtBQUs7RUFDWCxPQUFPO0VBQ1AsY0FBYztFQUNkLGVBQWU7RUFDZixVQUFVO0VBQ1YsUUFBUTtFQUNSLFdBQVcsS0FBSztFQUNoQixhQUFhO0NBQ2Y7QUFDRjs7O0FDOVFBLElBQUksZ0JBQWdCLGNBQWMsYUFBYTtDQUM3QyxZQUFZLFNBQVMsQ0FBQyxHQUFHO0VBQ3ZCLE1BQU07RUFDTixLQUFLLFNBQVM7RUFDZCxLQUFLSSw2QkFBNkIsSUFBSSxJQUFJO0VBQzFDLEtBQUtDLDBCQUEwQixJQUFJLElBQUk7RUFDdkMsS0FBS0MsY0FBYztDQUNyQjtDQUNBO0NBQ0E7Q0FDQTtDQUNBLE1BQU0sUUFBUSxTQUFTLE9BQU87RUFDNUIsTUFBTSxXQUFXLElBQUksU0FBUztHQUM1QjtHQUNBLGVBQWU7R0FDZixZQUFZLEVBQUUsS0FBS0E7R0FDbkIsU0FBUyxPQUFPLHVCQUF1QixPQUFPO0dBQzlDO0VBQ0YsQ0FBQztFQUNELEtBQUssSUFBSSxRQUFRO0VBQ2pCLE9BQU87Q0FDVDtDQUNBLElBQUksVUFBVTtFQUNaLEtBQUtGLFdBQVcsSUFBSSxRQUFRO0VBQzVCLE1BQU0sUUFBUSxTQUFTLFFBQVE7RUFDL0IsSUFBSSxPQUFPLFVBQVUsVUFBVTtHQUM3QixNQUFNLGtCQUFrQixLQUFLQyxRQUFRLElBQUksS0FBSztHQUM5QyxJQUFJLGlCQUNGLGdCQUFnQixLQUFLLFFBQVE7UUFFN0IsS0FBS0EsUUFBUSxJQUFJLE9BQU8sQ0FBQyxRQUFRLENBQUM7RUFFdEM7RUFDQSxLQUFLLE9BQU87R0FBRSxNQUFNO0dBQVM7RUFBUyxDQUFDO0NBQ3pDO0NBQ0EsT0FBTyxVQUFVO0VBQ2YsSUFBSSxLQUFLRCxXQUFXLE9BQU8sUUFBUSxHQUFHO0dBQ3BDLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDL0IsSUFBSSxPQUFPLFVBQVUsVUFBVTtJQUM3QixNQUFNLGtCQUFrQixLQUFLQyxRQUFRLElBQUksS0FBSztJQUM5QyxJQUFJLGlCQUFpQjtLQUNuQixJQUFJLGdCQUFnQixTQUFTLEdBQUc7TUFDOUIsTUFBTSxRQUFRLGdCQUFnQixRQUFRLFFBQVE7TUFDOUMsSUFBSSxVQUFVLElBQ1osZ0JBQWdCLE9BQU8sT0FBTyxDQUFDO0tBRW5DLE9BQU8sSUFBSSxnQkFBZ0IsT0FBTyxVQUNoQyxLQUFLQSxRQUFRLE9BQU8sS0FBSztJQUU3QjtHQUNGO0VBQ0Y7RUFDQSxLQUFLLE9BQU87R0FBRSxNQUFNO0dBQVc7RUFBUyxDQUFDO0NBQzNDO0NBQ0EsT0FBTyxVQUFVO0VBQ2YsTUFBTSxRQUFRLFNBQVMsUUFBUTtFQUMvQixJQUFJLE9BQU8sVUFBVSxVQUFVO0dBRTdCLE1BQU0sdUJBRHlCLEtBQUtBLFFBQVEsSUFBSSxLQUNFLENBQUMsRUFBRSxNQUNsRCxNQUFNLEVBQUUsTUFBTSxXQUFXLFNBQzVCO0dBQ0EsT0FBTyxDQUFDLHdCQUF3Qix5QkFBeUI7RUFDM0QsT0FDRSxPQUFPO0NBRVg7Q0FDQSxRQUFRLFVBQVU7RUFDaEIsTUFBTSxRQUFRLFNBQVMsUUFBUTtFQUMvQixJQUFJLE9BQU8sVUFBVSxVQUVuQixRQURzQixLQUFLQSxRQUFRLElBQUksS0FBSyxDQUFDLEVBQUUsTUFBTSxNQUFNLE1BQU0sWUFBWSxFQUFFLE1BQU0sUUFBUSxFQUFBLEVBQ3ZFLFNBQVMsS0FBSyxRQUFRLFFBQVE7T0FFcEQsT0FBTyxRQUFRLFFBQVE7Q0FFM0I7Q0FDQSxRQUFRO0VBQ04sY0FBYyxZQUFZO0dBQ3hCLEtBQUtELFdBQVcsU0FBUyxhQUFhO0lBQ3BDLEtBQUssT0FBTztLQUFFLE1BQU07S0FBVztJQUFTLENBQUM7R0FDM0MsQ0FBQztHQUNELEtBQUtBLFdBQVcsTUFBTTtHQUN0QixLQUFLQyxRQUFRLE1BQU07RUFDckIsQ0FBQztDQUNIO0NBQ0EsU0FBUztFQUNQLE9BQU8sTUFBTSxLQUFLLEtBQUtELFVBQVU7Q0FDbkM7Q0FDQSxLQUFLLFNBQVM7RUFDWixNQUFNLG1CQUFtQjtHQUFFLE9BQU87R0FBTSxHQUFHO0VBQVE7RUFDbkQsT0FBTyxLQUFLLE9BQU8sQ0FBQyxDQUFDLE1BQ2xCLGFBQWEsY0FBYyxrQkFBa0IsUUFBUSxDQUN4RDtDQUNGO0NBQ0EsUUFBUSxVQUFVLENBQUMsR0FBRztFQUNwQixPQUFPLEtBQUssT0FBTyxDQUFDLENBQUMsUUFBUSxhQUFhLGNBQWMsU0FBUyxRQUFRLENBQUM7Q0FDNUU7Q0FDQSxPQUFPLE9BQU87RUFDWixjQUFjLFlBQVk7R0FDeEIsS0FBSyxVQUFVLFNBQVMsYUFBYTtJQUNuQyxTQUFTLEtBQUs7R0FDaEIsQ0FBQztFQUNILENBQUM7Q0FDSDtDQUNBLHdCQUF3QjtFQUN0QixNQUFNLGtCQUFrQixLQUFLLE9BQU8sQ0FBQyxDQUFDLFFBQVEsTUFBTSxFQUFFLE1BQU0sUUFBUTtFQUNwRSxPQUFPLGNBQWMsWUFDYixRQUFRLElBQ1osZ0JBQWdCLEtBQUssYUFBYSxTQUFTLFNBQVMsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQ25FLENBQ0Y7Q0FDRjtBQUNGO0FBQ0EsU0FBUyxTQUFTLFVBQVU7Q0FDMUIsT0FBTyxTQUFTLFFBQVEsT0FBTztBQUNqQzs7O0FDbEhBLElBQUksbUJBQW1CLGNBQWMsYUFBYTtDQUNoRDtDQUNBLGlCQUFpQixLQUFLO0NBQ3RCO0NBQ0E7Q0FDQSxZQUFZLFFBQVEsU0FBUztFQUMzQixNQUFNO0VBQ04sS0FBS0csVUFBVTtFQUNmLEtBQUssV0FBVyxPQUFPO0VBQ3ZCLEtBQUssWUFBWTtFQUNqQixLQUFLQyxjQUFjO0NBQ3JCO0NBQ0EsY0FBYztFQUNaLEtBQUssU0FBUyxLQUFLLE9BQU8sS0FBSyxJQUFJO0VBQ25DLEtBQUssUUFBUSxLQUFLLE1BQU0sS0FBSyxJQUFJO0NBQ25DO0NBQ0EsV0FBVyxTQUFTO0VBQ2xCLE1BQU0sY0FBYyxLQUFLO0VBQ3pCLEtBQUssVUFBVSxLQUFLRCxRQUFRLHVCQUF1QixPQUFPO0VBQzFELElBQUksQ0FBQyxvQkFBb0IsS0FBSyxTQUFTLFdBQVcsR0FDaEQsS0FBS0EsUUFBUSxpQkFBaUIsQ0FBQyxDQUFDLE9BQU87R0FDckMsTUFBTTtHQUNOLFVBQVUsS0FBS0U7R0FDZixVQUFVO0VBQ1osQ0FBQztFQUVILElBQUksYUFBYSxlQUFlLEtBQUssUUFBUSxlQUFlLFFBQVEsWUFBWSxXQUFXLE1BQU0sUUFBUSxLQUFLLFFBQVEsV0FBVyxHQUMvSCxLQUFLLE1BQU07T0FDTixJQUFJLEtBQUtBLGtCQUFrQixNQUFNLFdBQVcsV0FDakQsS0FBS0EsaUJBQWlCLFdBQVcsS0FBSyxPQUFPO0NBRWpEO0NBQ0EsZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLEtBQUssYUFBYSxHQUNyQixLQUFLQSxrQkFBa0IsZUFBZSxJQUFJO0NBRTlDO0NBQ0EsaUJBQWlCLFFBQVE7RUFDdkIsS0FBS0QsY0FBYztFQUNuQixLQUFLRSxRQUFRLE1BQU07Q0FDckI7Q0FDQSxtQkFBbUI7RUFDakIsT0FBTyxLQUFLQztDQUNkO0NBQ0EsUUFBUTtFQUNOLEtBQUtGLGtCQUFrQixlQUFlLElBQUk7RUFDMUMsS0FBS0EsbUJBQW1CLEtBQUs7RUFDN0IsS0FBS0QsY0FBYztFQUNuQixLQUFLRSxRQUFRO0NBQ2Y7Q0FDQSxPQUFPLFdBQVcsU0FBUztFQUN6QixLQUFLRSxpQkFBaUI7RUFDdEIsS0FBS0gsa0JBQWtCLGVBQWUsSUFBSTtFQUMxQyxLQUFLQSxtQkFBbUIsS0FBS0YsUUFBUSxpQkFBaUIsQ0FBQyxDQUFDLE1BQU0sS0FBS0EsU0FBUyxLQUFLLE9BQU87RUFDeEYsS0FBS0UsaUJBQWlCLFlBQVksSUFBSTtFQUN0QyxPQUFPLEtBQUtBLGlCQUFpQixRQUFRLFNBQVM7Q0FDaEQ7Q0FDQSxnQkFBZ0I7RUFDZCxNQUFNLFFBQVEsS0FBS0Esa0JBQWtCLFNBQVMsZ0JBQWdCO0VBQzlELEtBQUtFLGlCQUFpQjtHQUNwQixHQUFHO0dBQ0gsV0FBVyxNQUFNLFdBQVc7R0FDNUIsV0FBVyxNQUFNLFdBQVc7R0FDNUIsU0FBUyxNQUFNLFdBQVc7R0FDMUIsUUFBUSxNQUFNLFdBQVc7R0FDekIsUUFBUSxLQUFLO0dBQ2IsT0FBTyxLQUFLO0VBQ2Q7Q0FDRjtDQUNBLFFBQVEsUUFBUTtFQUNkLGNBQWMsWUFBWTtHQUN4QixJQUFJLEtBQUtDLGtCQUFrQixLQUFLLGFBQWEsR0FBRztJQUM5QyxNQUFNLFlBQVksS0FBS0QsZUFBZTtJQUN0QyxNQUFNLGlCQUFpQixLQUFLQSxlQUFlO0lBQzNDLE1BQU0sVUFBVTtLQUNkLFFBQVEsS0FBS0o7S0FDYixNQUFNLEtBQUssUUFBUTtLQUNuQixhQUFhLEtBQUssUUFBUTtJQUM1QjtJQUNBLElBQUksUUFBUSxTQUFTLFdBQVc7S0FDOUIsSUFBSTtNQUNGLEtBQUtLLGVBQWUsWUFDbEIsT0FBTyxNQUNQLFdBQ0EsZ0JBQ0EsT0FDRjtLQUNGLFNBQVMsR0FBRztNQUNWLFFBQWEsT0FBTyxDQUFDO0tBQ3ZCO0tBQ0EsSUFBSTtNQUNGLEtBQUtBLGVBQWUsWUFDbEIsT0FBTyxNQUNQLE1BQ0EsV0FDQSxnQkFDQSxPQUNGO0tBQ0YsU0FBUyxHQUFHO01BQ1YsUUFBYSxPQUFPLENBQUM7S0FDdkI7SUFDRixPQUFPLElBQUksUUFBUSxTQUFTLFNBQVM7S0FDbkMsSUFBSTtNQUNGLEtBQUtBLGVBQWUsVUFDbEIsT0FBTyxPQUNQLFdBQ0EsZ0JBQ0EsT0FDRjtLQUNGLFNBQVMsR0FBRztNQUNWLFFBQWEsT0FBTyxDQUFDO0tBQ3ZCO0tBQ0EsSUFBSTtNQUNGLEtBQUtBLGVBQWUsWUFDbEIsS0FBSyxHQUNMLE9BQU8sT0FDUCxXQUNBLGdCQUNBLE9BQ0Y7S0FDRixTQUFTLEdBQUc7TUFDVixRQUFhLE9BQU8sQ0FBQztLQUN2QjtJQUNGO0dBQ0Y7R0FDQSxLQUFLLFVBQVUsU0FBUyxhQUFhO0lBQ25DLFNBQVMsS0FBS0QsY0FBYztHQUM5QixDQUFDO0VBQ0gsQ0FBQztDQUNIO0FBQ0Y7OztBQ2xJQSxTQUFTLFdBQVcsUUFBUSxRQUFRO0NBQ2xDLE1BQU0sYUFBYSxJQUFJLElBQUksTUFBTTtDQUNqQyxPQUFPLE9BQU8sUUFBUSxNQUFNLENBQUMsV0FBVyxJQUFJLENBQUMsQ0FBQztBQUNoRDtBQUNBLFNBQVMsVUFBVSxPQUFPLE9BQU8sT0FBTztDQUN0QyxNQUFNLE9BQU8sTUFBTSxNQUFNLENBQUM7Q0FDMUIsS0FBSyxTQUFTO0NBQ2QsT0FBTztBQUNUO0FBQ0EsSUFBSSxrQkFBa0IsY0FBYyxhQUFhO0NBQy9DO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBLG1CQUFtQixDQUFDO0NBQ3BCLFlBQVksUUFBUSxTQUFTLFNBQVM7RUFDcEMsTUFBTTtFQUNOLEtBQUtFLFVBQVU7RUFDZixLQUFLQyxXQUFXO0VBQ2hCLEtBQUtDLFdBQVcsQ0FBQztFQUNqQixLQUFLQyxhQUFhLENBQUM7RUFDbkIsS0FBS0MsVUFBVSxDQUFDO0VBQ2hCLEtBQUssV0FBVyxPQUFPO0NBQ3pCO0NBQ0EsY0FBYztFQUNaLElBQUksS0FBSyxVQUFVLFNBQVMsR0FDMUIsS0FBS0QsV0FBVyxTQUFTLGFBQWE7R0FDcEMsU0FBUyxXQUFXLFdBQVc7SUFDN0IsS0FBS0UsVUFBVSxVQUFVLE1BQU07R0FDakMsQ0FBQztFQUNILENBQUM7Q0FFTDtDQUNBLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxLQUFLLFVBQVUsTUFDbEIsS0FBSyxRQUFRO0NBRWpCO0NBQ0EsVUFBVTtFQUNSLEtBQUssNEJBQTRCLElBQUksSUFBSTtFQUN6QyxLQUFLRixXQUFXLFNBQVMsYUFBYTtHQUNwQyxTQUFTLFFBQVE7RUFDbkIsQ0FBQztDQUNIO0NBQ0EsV0FBVyxTQUFTLFNBQVM7RUFDM0IsS0FBS0QsV0FBVztFQUNoQixLQUFLRCxXQUFXO0VBQzJCO0dBQ3pDLE1BQU0sY0FBYyxRQUFRLEtBQ3pCLFVBQVUsS0FBS0QsUUFBUSxvQkFBb0IsS0FBSyxDQUFDLENBQUMsU0FDckQ7R0FDQSxJQUFJLElBQUksSUFBSSxXQUFXLENBQUMsQ0FBQyxTQUFTLFlBQVksUUFDNUMsUUFBUSxLQUNOLHVGQUNGO0VBRUo7RUFDQSxjQUFjLFlBQVk7R0FDeEIsTUFBTSxnQkFBZ0IsS0FBS0c7R0FDM0IsTUFBTSxxQkFBcUIsS0FBS0csdUJBQXVCLEtBQUtKLFFBQVE7R0FDcEUsbUJBQW1CLFNBQ2hCLFVBQVUsTUFBTSxTQUFTLFdBQVcsTUFBTSxxQkFBcUIsQ0FDbEU7R0FDQSxNQUFNLGVBQWUsbUJBQW1CLEtBQUssVUFBVSxNQUFNLFFBQVE7R0FDckUsTUFBTSxZQUFZLGFBQWEsS0FDNUIsYUFBYSxTQUFTLGlCQUFpQixDQUMxQztHQUNBLE1BQU0sa0JBQWtCLGNBQWMsV0FBVyxhQUFhO0dBQzlELE1BQU0saUJBQWlCLGFBQWEsTUFDakMsVUFBVSxVQUFVLGFBQWEsY0FBYyxNQUNsRDtHQUNBLE1BQU0sc0JBQXNCLG1CQUFtQjtHQUMvQyxNQUFNLGtCQUFrQixzQkFBc0IsT0FBTyxVQUFVLE1BQU0sUUFBUSxVQUFVO0lBQ3JGLE1BQU0sT0FBTyxLQUFLRSxRQUFRO0lBQzFCLE9BQU8sQ0FBQyxRQUFRLENBQUMsb0JBQW9CLFFBQVEsSUFBSTtHQUNuRCxDQUFDO0dBQ0QsSUFBSSxDQUFDLHVCQUF1QixDQUFDLGlCQUFpQjtHQUM5QyxJQUFJLHFCQUFxQjtJQUN2QixLQUFLRyxtQkFBbUI7SUFDeEIsS0FBS0osYUFBYTtHQUNwQjtHQUNBLEtBQUtDLFVBQVU7R0FDZixJQUFJLENBQUMsS0FBSyxhQUFhLEdBQUc7R0FDMUIsSUFBSSxxQkFBcUI7SUFDdkIsV0FBVyxlQUFlLFlBQVksQ0FBQyxDQUFDLFNBQVMsYUFBYTtLQUM1RCxTQUFTLFFBQVE7SUFDbkIsQ0FBQztJQUNELFdBQVcsY0FBYyxhQUFhLENBQUMsQ0FBQyxTQUFTLGFBQWE7S0FDNUQsU0FBUyxXQUFXLFdBQVc7TUFDN0IsS0FBS0MsVUFBVSxVQUFVLE1BQU07S0FDakMsQ0FBQztJQUNILENBQUM7R0FDSDtHQUNBLEtBQUtHLFFBQVE7RUFDZixDQUFDO0NBQ0g7Q0FDQSxtQkFBbUI7RUFDakIsT0FBTyxLQUFLSjtDQUNkO0NBQ0EsYUFBYTtFQUNYLE9BQU8sS0FBS0QsV0FBVyxLQUFLLGFBQWEsU0FBUyxnQkFBZ0IsQ0FBQztDQUNyRTtDQUNBLGVBQWU7RUFDYixPQUFPLEtBQUtBO0NBQ2Q7Q0FDQSxvQkFBb0IsU0FBUyxTQUFTO0VBQ3BDLE1BQU0sVUFBVSxLQUFLRyx1QkFBdUIsT0FBTztFQUNuRCxNQUFNLFNBQVMsUUFBUSxLQUNwQixVQUFVLE1BQU0sU0FBUyxvQkFBb0IsTUFBTSxxQkFBcUIsQ0FDM0U7RUFDQSxNQUFNLGNBQWMsUUFBUSxLQUN6QixVQUFVLE1BQU0sc0JBQXNCLFNBQ3pDO0VBQ0EsT0FBTztHQUNMO0lBQ0MsTUFBTTtJQUNMLE9BQU8sS0FBS0csZUFBZSxLQUFLLFFBQVEsU0FBUyxXQUFXO0dBQzlEO1NBQ007SUFDSixPQUFPLEtBQUtDLGFBQWEsUUFBUSxPQUFPO0dBQzFDO0VBQ0Y7Q0FDRjtDQUNBLGFBQWEsUUFBUSxTQUFTO0VBQzVCLE9BQU8sUUFBUSxLQUFLLE9BQU8sVUFBVTtHQUNuQyxNQUFNLGlCQUFpQixPQUFPO0dBQzlCLE9BQU8sQ0FBQyxNQUFNLHNCQUFzQixzQkFBc0IsTUFBTSxTQUFTLFlBQVksaUJBQWlCLGlCQUFpQjtJQUNySCxRQUFRLFNBQVMsTUFBTTtLQUNyQixFQUFFLFNBQVMsVUFBVSxZQUFZO0lBQ25DLENBQUM7R0FDSCxDQUFDLElBQUk7RUFDUCxDQUFDO0NBQ0g7Q0FDQSxlQUFlLE9BQU8sU0FBUyxhQUFhO0VBQzFDLElBQUksU0FBUztHQUNYLE1BQU0sYUFBYSxLQUFLQztHQUN4QixNQUFNLHFCQUFxQixnQkFBZ0IsS0FBSyxLQUFLLGVBQWUsS0FBSyxNQUFNLFdBQVcsV0FBVyxZQUFZLFVBQVUsWUFBWSxNQUFNLE1BQU0sTUFBTSxTQUFTLFdBQVcsRUFBRTtHQUMvSyxJQUFJLENBQUMsS0FBS0MsbUJBQW1CLEtBQUtSLFlBQVksS0FBS1MsZUFBZSxzQkFBc0IsWUFBWSxLQUFLQyxjQUFjO0lBQ3JILEtBQUtBLGVBQWU7SUFDcEIsS0FBS0QsY0FBYyxLQUFLVDtJQUN4QixJQUFJLGdCQUFnQixLQUFLLEdBQ3ZCLEtBQUtPLG1CQUFtQjtJQUUxQixLQUFLQyxrQkFBa0IsaUJBQ3JCLEtBQUtBLGlCQUNMLFFBQVEsS0FBSyxDQUNmO0dBQ0Y7R0FDQSxPQUFPLEtBQUtBO0VBQ2Q7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxxQkFBcUI7RUFDbkIsT0FBTyxLQUFLWCxVQUFVLFlBQVksS0FBSyxLQUFLLEtBQUtFLFdBQVcsTUFBTSxVQUFVLFVBQVU7R0FDcEYsT0FBTyxTQUFTLFFBQVEsWUFBWSxLQUFLQyxRQUFRLE1BQU0sRUFBRSxTQUFTLEtBQUs7RUFDekUsQ0FBQztDQUNIO0NBQ0EsdUJBQXVCLFNBQVM7RUFDOUIsTUFBTSxtQ0FBbUMsSUFBSSxJQUFJO0VBQ2pELEtBQUtELFdBQVcsU0FBUyxhQUFhO0dBQ3BDLE1BQU0sTUFBTSxTQUFTLFFBQVE7R0FDN0IsSUFBSSxDQUFDLEtBQUs7R0FDVixNQUFNLG9CQUFvQixpQkFBaUIsSUFBSSxHQUFHO0dBQ2xELElBQUksbUJBQ0Ysa0JBQWtCLEtBQUssUUFBUTtRQUUvQixpQkFBaUIsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDO0VBRXhDLENBQUM7RUFDRCxNQUFNLFlBQVksQ0FBQztFQUNuQixRQUFRLFNBQVMsWUFBWTtHQUMzQixNQUFNLG1CQUFtQixLQUFLSCxRQUFRLG9CQUFvQixPQUFPO0dBRWpFLE1BQU0sV0FEUSxpQkFBaUIsSUFBSSxpQkFBaUIsU0FBUyxDQUFDLEVBQUUsTUFBTSxLQUM1QyxJQUFJLGNBQWMsS0FBS0EsU0FBUyxnQkFBZ0I7R0FDMUUsVUFBVSxLQUFLO0lBQ2IsdUJBQXVCO0lBQ3ZCO0dBQ0YsQ0FBQztFQUNILENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSxVQUFVLFVBQVUsUUFBUTtFQUMxQixNQUFNLFFBQVEsS0FBS0csV0FBVyxRQUFRLFFBQVE7RUFDOUMsSUFBSSxVQUFVLElBQUk7R0FDaEIsS0FBS0MsVUFBVSxVQUFVLEtBQUtBLFNBQVMsT0FBTyxNQUFNO0dBQ3BELEtBQUtJLFFBQVE7RUFDZjtDQUNGO0NBQ0EsVUFBVTtFQUNSLElBQUksS0FBSyxhQUFhLEdBQUc7R0FDdkIsTUFBTSxhQUFhLEtBQUtFLGFBQWEsS0FBS04sU0FBUyxLQUFLRyxnQkFBZ0I7R0FDeEUsTUFBTSxvQkFBb0IsS0FBS1EsbUJBQW1CO0dBQ2xELE1BQU0saUJBQWlCLEtBQUtIO0dBQzVCLE1BQU0sWUFBWSxvQkFBb0IsaUJBQWlCLEtBQUtILGVBQWUsWUFBWSxLQUFLUixVQUFVLE9BQU87R0FDN0csSUFBSSxxQkFBcUIsbUJBQW1CLFdBQzFDLGNBQWMsWUFBWTtJQUN4QixLQUFLLFVBQVUsU0FBUyxhQUFhO0tBQ25DLFNBQVMsS0FBS0csT0FBTztJQUN2QixDQUFDO0dBQ0gsQ0FBQztFQUVMO0NBQ0Y7QUFDRjs7O0FDaE5BLElBQUksYUFBYSxjQUFjLGFBQWE7Q0FDMUMsWUFBWSxTQUFTLENBQUMsR0FBRztFQUN2QixNQUFNO0VBQ04sS0FBSyxTQUFTO0VBQ2QsS0FBS1ksMkJBQTJCLElBQUksSUFBSTtDQUMxQztDQUNBO0NBQ0EsTUFBTSxRQUFRLFNBQVMsT0FBTztFQUM1QixNQUFNLFdBQVcsUUFBUTtFQUN6QixNQUFNLFlBQVksUUFBUSxhQUFhLHNCQUFzQixVQUFVLE9BQU87RUFDOUUsSUFBSSxRQUFRLEtBQUssSUFBSSxTQUFTO0VBQzlCLElBQUksQ0FBQyxPQUFPO0dBQ1YsUUFBUSxJQUFJLE1BQU07SUFDaEI7SUFDQTtJQUNBO0lBQ0EsU0FBUyxPQUFPLG9CQUFvQixPQUFPO0lBQzNDO0lBQ0EsZ0JBQWdCLE9BQU8saUJBQWlCLFFBQVE7R0FDbEQsQ0FBQztHQUNELEtBQUssSUFBSSxLQUFLO0VBQ2hCO0VBQ0EsT0FBTztDQUNUO0NBQ0EsSUFBSSxPQUFPO0VBQ1QsSUFBSSxDQUFDLEtBQUtBLFNBQVMsSUFBSSxNQUFNLFNBQVMsR0FBRztHQUN2QyxLQUFLQSxTQUFTLElBQUksTUFBTSxXQUFXLEtBQUs7R0FDeEMsS0FBSyxPQUFPO0lBQ1YsTUFBTTtJQUNOO0dBQ0YsQ0FBQztFQUNIO0NBQ0Y7Q0FDQSxPQUFPLE9BQU87RUFDWixNQUFNLGFBQWEsS0FBS0EsU0FBUyxJQUFJLE1BQU0sU0FBUztFQUNwRCxJQUFJLFlBQVk7R0FDZCxNQUFNLFFBQVE7R0FDZCxJQUFJLGVBQWUsT0FDakIsS0FBS0EsU0FBUyxPQUFPLE1BQU0sU0FBUztHQUV0QyxLQUFLLE9BQU87SUFBRSxNQUFNO0lBQVc7R0FBTSxDQUFDO0VBQ3hDO0NBQ0Y7Q0FDQSxRQUFRO0VBQ04sY0FBYyxZQUFZO0dBQ3hCLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxVQUFVO0lBQy9CLEtBQUssT0FBTyxLQUFLO0dBQ25CLENBQUM7RUFDSCxDQUFDO0NBQ0g7Q0FDQSxJQUFJLFdBQVc7RUFDYixPQUFPLEtBQUtBLFNBQVMsSUFBSSxTQUFTO0NBQ3BDO0NBQ0EsU0FBUztFQUNQLE9BQU8sQ0FBQyxHQUFHLEtBQUtBLFNBQVMsT0FBTyxDQUFDO0NBQ25DO0NBQ0EsS0FBSyxTQUFTO0VBQ1osTUFBTSxtQkFBbUI7R0FBRSxPQUFPO0dBQU0sR0FBRztFQUFRO0VBQ25ELE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQyxNQUNsQixVQUFVLFdBQVcsa0JBQWtCLEtBQUssQ0FDL0M7Q0FDRjtDQUNBLFFBQVEsVUFBVSxDQUFDLEdBQUc7RUFDcEIsTUFBTSxVQUFVLEtBQUssT0FBTztFQUM1QixPQUFPLE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQyxTQUFTLElBQUksUUFBUSxRQUFRLFVBQVUsV0FBVyxTQUFTLEtBQUssQ0FBQyxJQUFJO0NBQ25HO0NBQ0EsT0FBTyxPQUFPO0VBQ1osY0FBYyxZQUFZO0dBQ3hCLEtBQUssVUFBVSxTQUFTLGFBQWE7SUFDbkMsU0FBUyxLQUFLO0dBQ2hCLENBQUM7RUFDSCxDQUFDO0NBQ0g7Q0FDQSxVQUFVO0VBQ1IsY0FBYyxZQUFZO0dBQ3hCLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxVQUFVO0lBQy9CLE1BQU0sUUFBUTtHQUNoQixDQUFDO0VBQ0gsQ0FBQztDQUNIO0NBQ0EsV0FBVztFQUNULGNBQWMsWUFBWTtHQUN4QixLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsVUFBVTtJQUMvQixNQUFNLFNBQVM7R0FDakIsQ0FBQztFQUNILENBQUM7Q0FDSDtBQUNGOzs7QUM3RUEsSUFBSSxjQUFjLE1BQU07Q0FDdEI7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBLFlBQVksU0FBUyxDQUFDLEdBQUc7RUFDdkIsS0FBS0MsY0FBYyxPQUFPLGNBQWMsSUFBSSxXQUFXO0VBQ3ZELEtBQUtDLGlCQUFpQixPQUFPLGlCQUFpQixJQUFJLGNBQWM7RUFDaEUsS0FBS0Msa0JBQWtCLE9BQU8sa0JBQWtCLENBQUM7RUFDakQsS0FBS0MsaUNBQWlDLElBQUksSUFBSTtFQUM5QyxLQUFLQyxvQ0FBb0MsSUFBSSxJQUFJO0VBQ2pELEtBQUtDLGNBQWM7Q0FDckI7Q0FDQSxRQUFRO0VBQ04sS0FBS0E7RUFDTCxJQUFJLEtBQUtBLGdCQUFnQixHQUFHO0VBQzVCLEtBQUtDLG9CQUFvQixhQUFhLFVBQVUsT0FBTyxZQUFZO0dBQ2pFLElBQUksU0FBUztJQUNYLE1BQU0sS0FBSyxzQkFBc0I7SUFDakMsS0FBS04sWUFBWSxRQUFRO0dBQzNCO0VBQ0YsQ0FBQztFQUNELEtBQUtPLHFCQUFxQixjQUFjLFVBQVUsT0FBTyxXQUFXO0dBQ2xFLElBQUksUUFBUTtJQUNWLE1BQU0sS0FBSyxzQkFBc0I7SUFDakMsS0FBS1AsWUFBWSxTQUFTO0dBQzVCO0VBQ0YsQ0FBQztDQUNIO0NBQ0EsVUFBVTtFQUNSLEtBQUtLO0VBQ0wsSUFBSSxLQUFLQSxnQkFBZ0IsR0FBRztFQUM1QixLQUFLQyxvQkFBb0I7RUFDekIsS0FBS0Esb0JBQW9CLEtBQUs7RUFDOUIsS0FBS0MscUJBQXFCO0VBQzFCLEtBQUtBLHFCQUFxQixLQUFLO0NBQ2pDO0NBQ0EsV0FBVyxTQUFTO0VBQ2xCLE9BQU8sS0FBS1AsWUFBWSxRQUFRO0dBQUUsR0FBRztHQUFTLGFBQWE7RUFBVyxDQUFDLENBQUMsQ0FBQztDQUMzRTtDQUNBLFdBQVcsU0FBUztFQUNsQixPQUFPLEtBQUtDLGVBQWUsUUFBUTtHQUFFLEdBQUc7R0FBUyxRQUFRO0VBQVUsQ0FBQyxDQUFDLENBQUM7Q0FDeEU7Ozs7Ozs7O0NBUUEsYUFBYSxVQUFVO0VBQ3JCLE1BQU0sVUFBVSxLQUFLLG9CQUFvQixFQUFFLFNBQVMsQ0FBQztFQUNyRCxPQUFPLEtBQUtELFlBQVksSUFBSSxRQUFRLFNBQVMsQ0FBQyxFQUFFLE1BQU07Q0FDeEQ7Q0FDQSxnQkFBZ0IsU0FBUztFQUN2QixNQUFNLG1CQUFtQixLQUFLLG9CQUFvQixPQUFPO0VBQ3pELE1BQU0sUUFBUSxLQUFLQSxZQUFZLE1BQU0sTUFBTSxnQkFBZ0I7RUFDM0QsTUFBTSxhQUFhLE1BQU0sTUFBTTtFQUMvQixJQUFJLGVBQWUsS0FBSyxHQUN0QixPQUFPLEtBQUssV0FBVyxPQUFPO0VBRWhDLElBQUksUUFBUSxxQkFBcUIsTUFBTSxjQUFjLGlCQUFpQixpQkFBaUIsV0FBVyxLQUFLLENBQUMsR0FDdEcsS0FBVSxjQUFjLGdCQUFnQjtFQUUxQyxPQUFPLFFBQVEsUUFBUSxVQUFVO0NBQ25DO0NBQ0EsZUFBZSxTQUFTO0VBQ3RCLE9BQU8sS0FBS0EsWUFBWSxRQUFRLE9BQU8sQ0FBQyxDQUFDLEtBQUssRUFBRSxVQUFVLFlBQVk7R0FFcEUsT0FBTyxDQUFDLFVBREssTUFBTSxJQUNHO0VBQ3hCLENBQUM7Q0FDSDtDQUNBLGFBQWEsVUFBVSxTQUFTLFNBQVM7RUFDdkMsTUFBTSxtQkFBbUIsS0FBSyxvQkFBb0IsRUFBRSxTQUFTLENBQUM7RUFJOUQsTUFBTSxXQUhRLEtBQUtBLFlBQVksSUFDN0IsaUJBQWlCLFNBRUUsQ0FBQyxFQUFFLE1BQU07RUFDOUIsTUFBTSxPQUFPLGlCQUFpQixTQUFTLFFBQVE7RUFDL0MsSUFBSSxTQUFTLEtBQUssR0FDaEI7RUFFRixPQUFPLEtBQUtBLFlBQVksTUFBTSxNQUFNLGdCQUFnQixDQUFDLENBQUMsUUFBUSxNQUFNO0dBQUUsR0FBRztHQUFTLFFBQVE7RUFBSyxDQUFDO0NBQ2xHO0NBQ0EsZUFBZSxTQUFTLFNBQVMsU0FBUztFQUN4QyxPQUFPLGNBQWMsWUFDYixLQUFLQSxZQUFZLFFBQVEsT0FBTyxDQUFDLENBQUMsS0FBSyxFQUFFLGVBQWUsQ0FDNUQsVUFDQSxLQUFLLGFBQWEsVUFBVSxTQUFTLE9BQU8sQ0FDOUMsQ0FBQyxDQUNIO0NBQ0Y7Q0FDQSxjQUFjLFVBQVU7RUFDdEIsTUFBTSxVQUFVLEtBQUssb0JBQW9CLEVBQUUsU0FBUyxDQUFDO0VBQ3JELE9BQU8sS0FBS0EsWUFBWSxJQUN0QixRQUFRLFNBQ1YsQ0FBQyxFQUFFO0NBQ0w7Q0FDQSxjQUFjLFNBQVM7RUFDckIsTUFBTSxhQUFhLEtBQUtBO0VBQ3hCLGNBQWMsWUFBWTtHQUN4QixXQUFXLFFBQVEsT0FBTyxDQUFDLENBQUMsU0FBUyxVQUFVO0lBQzdDLFdBQVcsT0FBTyxLQUFLO0dBQ3pCLENBQUM7RUFDSCxDQUFDO0NBQ0g7Q0FDQSxhQUFhLFNBQVMsU0FBUztFQUM3QixNQUFNLGFBQWEsS0FBS0E7RUFDeEIsT0FBTyxjQUFjLFlBQVk7R0FDL0IsV0FBVyxRQUFRLE9BQU8sQ0FBQyxDQUFDLFNBQVMsVUFBVTtJQUM3QyxNQUFNLE1BQU07R0FDZCxDQUFDO0dBQ0QsT0FBTyxLQUFLLGVBQ1Y7SUFDRSxNQUFNO0lBQ04sR0FBRztHQUNMLEdBQ0EsT0FDRjtFQUNGLENBQUM7Q0FDSDtDQUNBLGNBQWMsU0FBUyxnQkFBZ0IsQ0FBQyxHQUFHO0VBQ3pDLE1BQU0seUJBQXlCO0dBQUUsUUFBUTtHQUFNLEdBQUc7RUFBYztFQUNoRSxNQUFNLFdBQVcsY0FBYyxZQUN2QixLQUFLQSxZQUFZLFFBQVEsT0FBTyxDQUFDLENBQUMsS0FBSyxVQUFVLE1BQU0sT0FBTyxzQkFBc0IsQ0FBQyxDQUM3RjtFQUNBLE9BQU8sUUFBUSxJQUFJLFFBQVEsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsTUFBTSxJQUFJO0NBQ3BEO0NBQ0Esa0JBQWtCLFNBQVMsVUFBVSxDQUFDLEdBQUc7RUFDdkMsT0FBTyxjQUFjLFlBQVk7R0FDL0IsS0FBS0EsWUFBWSxRQUFRLE9BQU8sQ0FBQyxDQUFDLFNBQVMsVUFBVTtJQUNuRCxNQUFNLFdBQVc7R0FDbkIsQ0FBQztHQUNELElBQUksU0FBUyxnQkFBZ0IsUUFDM0IsT0FBTyxRQUFRLFFBQVE7R0FFekIsT0FBTyxLQUFLLGVBQ1Y7SUFDRSxHQUFHO0lBQ0gsTUFBTSxTQUFTLGVBQWUsU0FBUyxRQUFRO0dBQ2pELEdBQ0EsT0FDRjtFQUNGLENBQUM7Q0FDSDtDQUNBLGVBQWUsU0FBUyxVQUFVLENBQUMsR0FBRztFQUNwQyxNQUFNLGVBQWU7R0FDbkIsR0FBRztHQUNILGVBQWUsUUFBUSxpQkFBaUI7RUFDMUM7RUFDQSxNQUFNLFdBQVcsY0FBYyxZQUN2QixLQUFLQSxZQUFZLFFBQVEsT0FBTyxDQUFDLENBQUMsUUFBUSxVQUFVLENBQUMsTUFBTSxXQUFXLEtBQUssQ0FBQyxNQUFNLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxVQUFVO0dBQ2pILElBQUksVUFBVSxNQUFNLE1BQU0sS0FBSyxHQUFHLFlBQVk7R0FDOUMsSUFBSSxDQUFDLGFBQWEsY0FDaEIsVUFBVSxRQUFRLE1BQU0sSUFBSTtHQUU5QixPQUFPLE1BQU0sTUFBTSxnQkFBZ0IsV0FBVyxRQUFRLFFBQVEsSUFBSTtFQUNwRSxDQUFDLENBQ0g7RUFDQSxPQUFPLFFBQVEsSUFBSSxRQUFRLENBQUMsQ0FBQyxLQUFLLElBQUk7Q0FDeEM7Q0FDQSxXQUFXLFNBQVM7RUFDbEIsTUFBTSxtQkFBbUIsS0FBSyxvQkFBb0IsT0FBTztFQUN6RCxJQUFJLGlCQUFpQixVQUFVLEtBQUssR0FDbEMsaUJBQWlCLFFBQVE7RUFFM0IsTUFBTSxRQUFRLEtBQUtBLFlBQVksTUFBTSxNQUFNLGdCQUFnQjtFQUMzRCxPQUFPLE1BQU0sY0FDWCxpQkFBaUIsaUJBQWlCLFdBQVcsS0FBSyxDQUNwRCxJQUFJLE1BQU0sTUFBTSxnQkFBZ0IsSUFBSSxRQUFRLFFBQVEsTUFBTSxNQUFNLElBQUk7Q0FDdEU7Q0FDQSxjQUFjLFNBQVM7RUFDckIsT0FBTyxLQUFLLFdBQVcsT0FBTyxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxNQUFNLElBQUk7Q0FDdkQ7Q0FDQSxtQkFBbUIsU0FBUztFQUMxQixRQUFRLFFBQVE7RUFDaEIsT0FBTyxLQUFLLFdBQVcsT0FBTztDQUNoQztDQUNBLHNCQUFzQixTQUFTO0VBQzdCLE9BQU8sS0FBSyxtQkFBbUIsT0FBTyxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxNQUFNLElBQUk7Q0FDL0Q7Q0FDQSx3QkFBd0IsU0FBUztFQUMvQixRQUFRLFFBQVE7RUFDaEIsT0FBTyxLQUFLLGdCQUFnQixPQUFPO0NBQ3JDO0NBQ0Esd0JBQXdCO0VBQ3RCLElBQUksY0FBYyxTQUFTLEdBQ3pCLE9BQU8sS0FBS0MsZUFBZSxzQkFBc0I7RUFFbkQsT0FBTyxRQUFRLFFBQVE7Q0FDekI7Q0FDQSxnQkFBZ0I7RUFDZCxPQUFPLEtBQUtEO0NBQ2Q7Q0FDQSxtQkFBbUI7RUFDakIsT0FBTyxLQUFLQztDQUNkO0NBQ0Esb0JBQW9CO0VBQ2xCLE9BQU8sS0FBS0M7Q0FDZDtDQUNBLGtCQUFrQixTQUFTO0VBQ3pCLEtBQUtBLGtCQUFrQjtDQUN6QjtDQUNBLGlCQUFpQixVQUFVLFNBQVM7RUFDbEMsS0FBS0MsZUFBZSxJQUFJLFFBQVEsUUFBUSxHQUFHO0dBQ3pDO0dBQ0EsZ0JBQWdCO0VBQ2xCLENBQUM7Q0FDSDtDQUNBLGlCQUFpQixVQUFVO0VBQ3pCLE1BQU0sV0FBVyxDQUFDLEdBQUcsS0FBS0EsZUFBZSxPQUFPLENBQUM7RUFDakQsTUFBTSxTQUFTLENBQUM7RUFDaEIsU0FBUyxTQUFTLGlCQUFpQjtHQUNqQyxJQUFJLGdCQUFnQixVQUFVLGFBQWEsUUFBUSxHQUNqRCxPQUFPLE9BQU8sUUFBUSxhQUFhLGNBQWM7RUFFckQsQ0FBQztFQUNELE9BQU87Q0FDVDtDQUNBLG9CQUFvQixhQUFhLFNBQVM7RUFDeEMsS0FBS0Msa0JBQWtCLElBQUksUUFBUSxXQUFXLEdBQUc7R0FDL0M7R0FDQSxnQkFBZ0I7RUFDbEIsQ0FBQztDQUNIO0NBQ0Esb0JBQW9CLGFBQWE7RUFDL0IsTUFBTSxXQUFXLENBQUMsR0FBRyxLQUFLQSxrQkFBa0IsT0FBTyxDQUFDO0VBQ3BELE1BQU0sU0FBUyxDQUFDO0VBQ2hCLFNBQVMsU0FBUyxpQkFBaUI7R0FDakMsSUFBSSxnQkFBZ0IsYUFBYSxhQUFhLFdBQVcsR0FDdkQsT0FBTyxPQUFPLFFBQVEsYUFBYSxjQUFjO0VBRXJELENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSxvQkFBb0IsU0FBUztFQUMzQixJQUFJLFFBQVEsWUFDVixPQUFPO0VBRVQsTUFBTSxtQkFBbUI7R0FDdkIsR0FBRyxLQUFLRixnQkFBZ0I7R0FDeEIsR0FBRyxLQUFLLGlCQUFpQixRQUFRLFFBQVE7R0FDekMsR0FBRztHQUNILFlBQVk7RUFDZDtFQUNBLElBQUksQ0FBQyxpQkFBaUIsV0FDcEIsaUJBQWlCLFlBQVksc0JBQzNCLGlCQUFpQixVQUNqQixnQkFDRjtFQUVGLElBQUksaUJBQWlCLHVCQUF1QixLQUFLLEdBQy9DLGlCQUFpQixxQkFBcUIsaUJBQWlCLGdCQUFnQjtFQUV6RSxJQUFJLGlCQUFpQixpQkFBaUIsS0FBSyxHQUN6QyxpQkFBaUIsZUFBZSxDQUFDLENBQUMsaUJBQWlCO0VBRXJELElBQUksQ0FBQyxpQkFBaUIsZUFBZSxpQkFBaUIsV0FDcEQsaUJBQWlCLGNBQWM7RUFFakMsSUFBSSxpQkFBaUIsWUFBWSxXQUMvQixpQkFBaUIsVUFBVTtFQUU3QixPQUFPO0NBQ1Q7Q0FDQSx1QkFBdUIsU0FBUztFQUM5QixJQUFJLFNBQVMsWUFDWCxPQUFPO0VBRVQsT0FBTztHQUNMLEdBQUcsS0FBS0EsZ0JBQWdCO0dBQ3hCLEdBQUcsU0FBUyxlQUFlLEtBQUssb0JBQW9CLFFBQVEsV0FBVztHQUN2RSxHQUFHO0dBQ0gsWUFBWTtFQUNkO0NBQ0Y7Q0FDQSxRQUFRO0VBQ04sS0FBS0YsWUFBWSxNQUFNO0VBQ3ZCLEtBQUtDLGVBQWUsTUFBTTtDQUM1QjtBQUNGOzs7QUN6U0EsU0FBUyxjQUFjLEVBQ3JCLFVBQ0EsY0FBYyxTQUNkLFdBQVcsT0FBTyxVQUFVLFNBQVMsT0FBTyxLQUFLLEdBQ2pELGVBQWUsQ0FBQyxLQUNmO0NBQ0QsT0FBTyxPQUFPLFlBQVk7RUFDeEIsTUFBTSxRQUFRLFFBQVEsT0FBTyxjQUFjLENBQUMsQ0FBQyxLQUFLO0dBQUUsVUFBVSxRQUFRO0dBQVUsT0FBTztFQUFLLENBQUM7RUFDN0YsTUFBTSxZQUFZLENBQUMsQ0FBQyxTQUFTLE1BQU0sVUFBVTtFQUM3QyxJQUFJLGFBQWEsZ0JBQWdCLFNBQy9CLE1BQU0sU0FBUztHQUNiLEdBQUcsTUFBTTtHQUNULGFBQWE7RUFDZixDQUFDO0VBRUgsSUFBSSxTQUFTO0VBQ2IsSUFBSSxZQUFZO0VBWWhCLE1BQU0sU0FBUyxNQUFNLFNBWEcsc0JBQ3RCO0dBQ0UsUUFBUSxRQUFRO0dBQ2hCLE1BQU0sUUFBUTtHQUNkLFVBQVUsUUFBUTtHQUNsQixXQUFXLFFBQVE7R0FDbkIsV0FBVyxRQUFRO0VBQ3JCLFNBQ00sUUFBUSxjQUNSLFlBQVksSUFFd0IsQ0FBQztFQUM3QyxNQUFNLG1CQUFtQixhQUFhLGdCQUFnQjtFQUN0RCxXQUFXLE1BQU0sU0FBUyxRQUFRO0dBQ2hDLElBQUksV0FDRjtHQUVGLElBQUksa0JBQ0YsU0FBUyxRQUFRLFFBQVEsS0FBSztRQUU5QixRQUFRLE9BQU8sYUFDYixRQUFRLFdBQ1AsU0FBUyxRQUFRLFNBQVMsS0FBSyxJQUFJLGVBQWUsTUFBTSxLQUFLLENBQ2hFO0VBRUo7RUFDQSxJQUFJLG9CQUFvQixDQUFDLFdBQ3ZCLFFBQVEsT0FBTyxhQUFhLFFBQVEsVUFBVSxNQUFNO0VBRXRELE9BQU8sUUFBUSxPQUFPLGFBQWEsUUFBUSxRQUFRLEtBQUs7Q0FDMUQ7QUFDRjs7O0FDakRBLElBQUksZ0JBQWdDLHVCQUFPLGVBQWU7QUFDMUQsSUFBSSxxQkFBcUMsdUJBQU8sb0JBQW9CO0FBQ3BFLElBQUksY0FBOEIsdUJBQU8sYUFBYTs7Ozs7QUNFdEQsSUFBSSxxQkFBQSxhQUEyQixjQUM3QixLQUFLLENBQ1A7QUFDQSxJQUFJLGtCQUFrQixnQkFBZ0I7Q0FDcEMsTUFBTSxTQUFBLGFBQWUsV0FBVyxrQkFBa0I7Q0FDbEQsSUFBSSxhQUNGLE9BQU87Q0FFVCxJQUFJLENBQUMsUUFDSCxNQUFNLElBQUksTUFBTSx3REFBd0Q7Q0FFMUUsT0FBTztBQUNUO0FBQ0EsSUFBSSx1QkFBdUIsRUFDekIsUUFDQSxlQUNJO0NBQ0osYUFBTSxnQkFBZ0I7RUFDcEIsT0FBTyxNQUFNO0VBQ2IsYUFBYTtHQUNYLE9BQU8sUUFBUTtFQUNqQjtDQUNGLEdBQUcsQ0FBQyxNQUFNLENBQUM7Q0FDWCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxtQkFBbUIsVUFBVTtFQUFFLE9BQU87RUFBUTtDQUFTLENBQUM7QUFDckY7OztBQ3pCQSxJQUFJLHFCQUFBLGFBQTJCLGNBQWMsS0FBSztBQUNsRCxJQUFJLHVCQUFBLGFBQTZCLFdBQVcsa0JBQWtCO0FBQzlELElBQUksc0JBQXNCLG1CQUFtQjs7O0FDRDdDLFNBQVMsY0FBYztDQUNyQixJQUFJLFVBQVU7Q0FDZCxPQUFPO0VBQ0wsa0JBQWtCO0dBQ2hCLFVBQVU7RUFDWjtFQUNBLGFBQWE7R0FDWCxVQUFVO0VBQ1o7RUFDQSxlQUFlO0dBQ2IsT0FBTztFQUNUO0NBQ0Y7QUFDRjtBQUNBLElBQUksaUNBQUEsYUFBdUMsY0FBYyxZQUFZLENBQUM7QUFDdEUsSUFBSSxtQ0FBQSxhQUF5QyxXQUFXLDhCQUE4QjtBQUN0RixJQUFJLDJCQUEyQixFQUM3QixlQUNJO0NBQ0osTUFBTSxDQUFDLFNBQUEsYUFBZSxlQUFlLFlBQVksQ0FBQztDQUNsRCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSwrQkFBK0IsVUFBVTtFQUFFO0VBQU8sVUFBVSxPQUFPLGFBQWEsYUFBYSxTQUFTLEtBQUssSUFBSTtDQUFTLENBQUM7QUFDdEo7OztBQ3JCQSxJQUFJLG1DQUFtQyxTQUFTLG9CQUFvQixVQUFVO0NBQzVFLE1BQU0sZUFBZSxPQUFPLE1BQU0sU0FBUyxPQUFPLFFBQVEsaUJBQWlCLGFBQWEsaUJBQWlCLFFBQVEsY0FBYyxDQUFDLE1BQU0sTUFBTSxPQUFPLEtBQUssQ0FBQyxJQUFJLFFBQVE7Q0FDckssSUFBSSxRQUFRLFlBQVksUUFBUSxpQ0FBaUMsY0FDM0Q7TUFBQSxDQUFDLG1CQUFtQixRQUFRLEdBQzlCLFFBQVEsZUFBZTtDQUFBO0FBRzdCO0FBQ0EsSUFBSSw4QkFBOEIsdUJBQXVCO0NBQ3ZELGFBQU0sZ0JBQWdCO0VBQ3BCLG1CQUFtQixXQUFXO0NBQ2hDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQztBQUN6QjtBQUNBLElBQUksZUFBZSxFQUNqQixRQUNBLG9CQUNBLGNBQ0EsT0FDQSxlQUNJO0NBQ0osT0FBTyxPQUFPLFdBQVcsQ0FBQyxtQkFBbUIsUUFBUSxLQUFLLENBQUMsT0FBTyxjQUFjLFVBQVUsWUFBWSxPQUFPLFNBQVMsS0FBSyxLQUFLLGlCQUFpQixjQUFjLENBQUMsT0FBTyxPQUFPLEtBQUssQ0FBQztBQUN0TDs7O0FDekJBLElBQUksdUJBQXVCLFFBQVEsVUFBVSxNQUFNLE1BQU0sU0FBUyxLQUFLO0FBQ3ZFLElBQUksd0JBQXdCLHFCQUFxQjtDQUMvQyxJQUFJLGlCQUFpQixVQUFVO0VBQzdCLE1BQU0sdUJBQXVCO0VBQzdCLE1BQU0sU0FBUyxVQUFVLFVBQVUsV0FBVyxRQUFRLEtBQUssSUFBSSxTQUFTLHNCQUFzQixvQkFBb0I7RUFDbEgsTUFBTSxvQkFBb0IsaUJBQWlCO0VBQzNDLGlCQUFpQixZQUFZLE9BQU8sc0JBQXNCLGNBQWMsR0FBRyxTQUFTLE1BQU0sa0JBQWtCLEdBQUcsSUFBSSxDQUFDLElBQUksTUFBTSxpQkFBaUI7RUFDL0ksSUFBSSxPQUFPLGlCQUFpQixXQUFXLFVBQ3JDLGlCQUFpQixTQUFTLEtBQUssSUFDN0IsaUJBQWlCLFFBQ2pCLG9CQUNGO0NBRUo7QUFDRjtBQUNBLElBQUksYUFBYSxRQUFRLGdCQUFnQixPQUFPLGFBQWEsT0FBTyxjQUFjLENBQUM7QUFDbkYsSUFBSSxpQkFBaUIsa0JBQWtCLFdBQVcsa0JBQWtCLFlBQVksT0FBTztBQUN2RixJQUFJLG1CQUFtQixrQkFBa0IsVUFBVSx1QkFBdUIsU0FBUyxnQkFBZ0IsZ0JBQWdCLENBQUMsQ0FBQyxZQUFZO0NBQy9ILG1CQUFtQixXQUFXO0FBQ2hDLENBQUM7OztBQ0dELFNBQVMsV0FBVyxFQUNsQixTQUNBLEdBQUcsV0FDRixhQUFhO0NBQ2QsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxNQUFNLGNBQWMsZUFBZTtDQUNuQyxNQUFNLHFCQUFxQiwyQkFBMkI7Q0FDdEQsTUFBTSxtQkFBQSxhQUF5QixjQUN2QixRQUFRLEtBQUssU0FBUztFQUMxQixNQUFNLG1CQUFtQixPQUFPLG9CQUM5QixJQUNGO0VBQ0EsaUJBQWlCLHFCQUFxQixjQUFjLGdCQUFnQjtFQUNwRSxPQUFPO0NBQ1QsQ0FBQyxHQUNEO0VBQUM7RUFBUztFQUFRO0NBQVcsQ0FDL0I7Q0FDQSxpQkFBaUIsU0FBUyxpQkFBaUI7RUFDekMscUJBQXFCLFlBQVk7RUFDakMsTUFBTSxRQUFRLE9BQU8sY0FBYyxDQUFDLENBQUMsSUFBSSxhQUFhLFNBQVM7RUFDL0QsZ0NBQWdDLGNBQWMsb0JBQW9CLEtBQUs7Q0FDekUsQ0FBQztDQUNELDJCQUEyQixrQkFBa0I7Q0FDN0MsTUFBTSxDQUFDLFlBQUEsYUFBa0IsZUFDakIsSUFBSSxnQkFDUixRQUNBLGtCQUNBLE9BQ0YsQ0FDRjtDQUNBLE1BQU0sQ0FBQyxrQkFBa0IsbUJBQW1CLGVBQWUsU0FBUyxvQkFDbEUsa0JBQ0EsUUFBUSxPQUNWO0NBQ0EsTUFBTSxrQkFBa0IsQ0FBQyxlQUFlLFFBQVEsZUFBZTtDQUMvRCxhQUFNLHFCQUFBLGFBQ0UsYUFDSCxrQkFBa0Isa0JBQWtCLFNBQVMsVUFBVSxjQUFjLFdBQVcsYUFBYSxDQUFDLElBQUksTUFDbkcsQ0FBQyxVQUFVLGVBQWUsQ0FDNUIsU0FDTSxTQUFTLGlCQUFpQixTQUMxQixTQUFTLGlCQUFpQixDQUNsQztDQUNBLGFBQU0sZ0JBQWdCO0VBQ3BCLFNBQVMsV0FDUCxrQkFDQSxPQUNGO0NBQ0YsR0FBRztFQUFDO0VBQWtCO0VBQVM7Q0FBUSxDQUFDO0NBSXhDLE1BQU0sbUJBSDBCLGlCQUFpQixNQUM5QyxRQUFRLFVBQVUsY0FBYyxpQkFBaUIsUUFBUSxNQUFNLENBRW5CLElBQUksaUJBQWlCLFNBQVMsUUFBUSxVQUFVO0VBQzdGLE1BQU0sT0FBTyxpQkFBaUI7RUFDOUIsSUFBSSxRQUFRLGNBQWMsTUFBTSxNQUFNLEdBRXBDLE9BQU8sZ0JBQWdCLE1BQU0sSUFESCxjQUFjLFFBQVEsSUFDbkIsR0FBZSxrQkFBa0I7RUFFaEUsT0FBTyxDQUFDO0NBQ1YsQ0FBQyxJQUFJLENBQUM7Q0FDTixJQUFJLGlCQUFpQixTQUFTLEdBQzVCLE1BQU0sUUFBUSxJQUFJLGdCQUFnQjtDQUVwQyxNQUFNLG9DQUFvQyxpQkFBaUIsTUFDeEQsUUFBUSxVQUFVO0VBQ2pCLE1BQU0sUUFBUSxpQkFBaUI7RUFDL0IsT0FBTyxTQUFTLFlBQVk7R0FDMUI7R0FDQTtHQUNBLGNBQWMsTUFBTTtHQUNwQixPQUFPLE9BQU8sY0FBYyxDQUFDLENBQUMsSUFBSSxNQUFNLFNBQVM7R0FDakQsVUFBVSxNQUFNO0VBQ2xCLENBQUM7Q0FDSCxDQUNGO0NBQ0EsSUFBSSxtQ0FBbUMsT0FDckMsTUFBTSxrQ0FBa0M7Q0FFMUMsT0FBTyxrQkFBa0IsWUFBWSxDQUFDO0FBQ3hDOzs7QUNuRkEsU0FBUyxhQUFhLFNBQVMsVUFBVSxhQUFhO0NBRWxELElBQUksT0FBTyxZQUFZLFlBQVksTUFBTSxRQUFRLE9BQU8sR0FDdEQsTUFBTSxJQUFJLE1BQ1IsZ1NBQ0Y7Q0FHSixNQUFNLGNBQWMsZUFBZTtDQUNuQyxNQUFNLHFCQUFxQiwyQkFBMkI7Q0FDdEQsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxNQUFNLG1CQUFtQixPQUFPLG9CQUFvQixPQUFPO0NBQzNELE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxTQUFTLDRCQUNsQyxnQkFDRjtDQUNBLE1BQU0sUUFBUSxPQUFPLGNBQWMsQ0FBQyxDQUFDLElBQUksaUJBQWlCLFNBQVM7Q0FFakUsSUFBSSxDQUFDLGlCQUFpQixTQUNwQixRQUFRLE1BQ04sSUFBSSxpQkFBaUIsVUFBVSxtUEFDakM7Q0FHSixNQUFNLGFBQWEsUUFBUSxlQUFlO0NBQzFDLGlCQUFpQixxQkFBcUIsY0FBYyxnQkFBZ0IsYUFBYSxlQUFlLEtBQUs7Q0FDckcscUJBQXFCLGdCQUFnQjtDQUNyQyxnQ0FBZ0Msa0JBQWtCLG9CQUFvQixLQUFLO0NBQzNFLDJCQUEyQixrQkFBa0I7Q0FDN0MsTUFBTSxrQkFBa0IsQ0FBQyxPQUFPLGNBQWMsQ0FBQyxDQUFDLElBQUksaUJBQWlCLFNBQVM7Q0FDOUUsTUFBTSxDQUFDLFlBQUEsYUFBa0IsZUFDakIsSUFBSSxTQUNSLFFBQ0EsZ0JBQ0YsQ0FDRjtDQUNBLE1BQU0sU0FBUyxTQUFTLG9CQUFvQixnQkFBZ0I7Q0FDNUQsTUFBTSxrQkFBa0IsQ0FBQyxlQUFlO0NBQ3hDLGFBQU0scUJBQUEsYUFDRSxhQUNILGtCQUFrQjtFQUNqQixNQUFNLGNBQWMsa0JBQWtCLFNBQVMsVUFBVSxjQUFjLFdBQVcsYUFBYSxDQUFDLElBQUk7RUFDcEcsU0FBUyxhQUFhO0VBQ3RCLE9BQU87Q0FDVCxHQUNBLENBQUMsVUFBVSxlQUFlLENBQzVCLFNBQ00sU0FBUyxpQkFBaUIsU0FDMUIsU0FBUyxpQkFBaUIsQ0FDbEM7Q0FDQSxhQUFNLGdCQUFnQjtFQUNwQixTQUFTLFdBQVcsZ0JBQWdCO0NBQ3RDLEdBQUcsQ0FBQyxrQkFBa0IsUUFBUSxDQUFDO0NBQy9CLElBQUksY0FBYyxrQkFBa0IsTUFBTSxHQUN4QyxNQUFNLGdCQUFnQixrQkFBa0IsVUFBVSxrQkFBa0I7Q0FFdEUsSUFBSSxZQUFZO0VBQ2Q7RUFDQTtFQUNBLGNBQWMsaUJBQWlCO0VBQy9CO0VBQ0EsVUFBVSxpQkFBaUI7Q0FDN0IsQ0FBQyxHQUNDLE1BQU0sT0FBTztDQUdmLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxTQUFTLDJCQUNsQyxrQkFDQSxNQUNGO0NBQ0EsSUFBSSxpQkFBaUIsaUNBQWlDLENBQUMsbUJBQW1CLFNBQVMsS0FBSyxVQUFVLFFBQVEsV0FBVyxHQVFuSCxDQVBnQixrQkFFZCxnQkFBZ0Isa0JBQWtCLFVBQVUsa0JBQWtCLElBRzlELE9BQU8sUUFBQSxFQUVBLE1BQU0sSUFBSSxDQUFDLENBQUMsY0FBYztFQUNqQyxTQUFTLGFBQWE7Q0FDeEIsQ0FBQztDQUVILE9BQU8sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsWUFBWSxNQUFNLElBQUk7QUFDaEY7OztBQ2hHQSxTQUFTLFNBQVMsU0FBUyxhQUFhO0NBQ3RDLE9BQU8sYUFBYSxTQUFTLGVBQWUsV0FBVztBQUN6RDs7O0FDREEsU0FBUyxpQkFBaUIsU0FBUyxhQUFhO0NBRTVDLElBQUksUUFBUSxZQUFZLFdBQ3RCLFFBQVEsTUFBTSwrQ0FBK0M7Q0FHakUsT0FBTyxhQUNMO0VBQ0UsR0FBRztFQUNILFNBQVM7RUFDVCxVQUFVO0VBQ1YsY0FBYztFQUNkLGlCQUFpQixLQUFLO0NBQ3hCLEdBQ0EsZUFDQSxXQUNGO0FBQ0Y7OztBQ2pCQSxTQUFTLHlCQUF5QixTQUFTLGFBQWE7Q0FFcEQsSUFBSSxRQUFRLFlBQVksV0FDdEIsUUFBUSxNQUFNLHVEQUF1RDtDQUd6RSxPQUFPLGFBQ0w7RUFDRSxHQUFHO0VBQ0gsU0FBUztFQUNULFVBQVU7RUFDVixjQUFjO0NBQ2hCLEdBQ0EsdUJBQ0EsV0FDRjtBQUNGOzs7QUNoQkEsU0FBUyxtQkFBbUIsU0FBUyxhQUFhO0NBQ2hELE9BQU8sV0FDTDtFQUNFLEdBQUc7RUFDSCxTQUFTLFFBQVEsUUFBUSxLQUFLLFVBQVU7R0FFcEMsSUFBSSxNQUFNLFlBQVksV0FDcEIsUUFBUSxNQUFNLGlEQUFpRDtHQUduRSxPQUFPO0lBQ0wsR0FBRztJQUNILFVBQVU7SUFDVixjQUFjO0lBQ2QsU0FBUztJQUNULGlCQUFpQixLQUFLO0dBQ3hCO0VBQ0YsQ0FBQztDQUNILEdBQ0EsV0FDRjtBQUNGOzs7QUN6QkEsU0FBUyxpQkFBaUIsU0FBUyxhQUFhO0NBQzlDLE1BQU0sU0FBUyxlQUFlLFdBQVc7Q0FDekMsSUFBSSxDQUFDLE9BQU8sY0FBYyxRQUFRLFFBQVEsR0FDeEMsT0FBTyxjQUFjLE9BQU87QUFFaEM7OztBQ0xBLFNBQVMseUJBQXlCLFNBQVMsYUFBYTtDQUN0RCxNQUFNLFNBQVMsZUFBZSxXQUFXO0NBQ3pDLElBQUksQ0FBQyxPQUFPLGNBQWMsUUFBUSxRQUFRLEdBQ3hDLE9BQU8sc0JBQXNCLE9BQU87QUFFeEM7OztBQ05BLFNBQVMsYUFBYSxTQUFTO0NBQzdCLE9BQU87QUFDVDs7O0FDRkEsU0FBUyxxQkFBcUIsU0FBUztDQUNyQyxPQUFPO0FBQ1Q7OztBQ0dBLElBQUkscUJBQXFCLEVBQ3ZCLFVBQ0EsVUFBVSxDQUFDLEdBQ1gsT0FDQSxrQkFDSTtDQUNKLE1BQU0sU0FBUyxlQUFlLFdBQVc7Q0FDekMsTUFBTSxhQUFBLGFBQW1CLE9BQU8sT0FBTztDQUN2QyxhQUFNLGdCQUFnQjtFQUNwQixXQUFXLFVBQVU7Q0FDdkIsQ0FBQztDQUNELE1BQU0saUJBQUEsYUFBdUIsY0FBYztFQUN6QyxJQUFJLE9BQU87R0FDVCxJQUFJLE9BQU8sVUFBVSxVQUNuQjtHQUVGLE1BQU0sYUFBYSxPQUFPLGNBQWM7R0FDeEMsTUFBTSxVQUFVLE1BQU0sV0FBVyxDQUFDO0dBQ2xDLE1BQU0sYUFBYSxDQUFDO0dBQ3BCLE1BQU0sa0JBQWtCLENBQUM7R0FDekIsS0FBSyxNQUFNLG1CQUFtQixTQUFTO0lBQ3JDLE1BQU0sZ0JBQWdCLFdBQVcsSUFBSSxnQkFBZ0IsU0FBUztJQUM5RCxJQUFJLENBQUMsZUFDSCxXQUFXLEtBQUssZUFBZTtTQUcvQixJQUR5QixnQkFBZ0IsTUFBTSxnQkFBZ0IsY0FBYyxNQUFNLGlCQUFpQixnQkFBZ0IsV0FBVyxjQUFjLE1BQU0sV0FBVyxhQUFhLGNBQWMsTUFBTSxnQkFBZ0IsY0FBYyxnQkFBZ0IsaUJBQWlCLEtBQUssS0FBSyxnQkFBZ0IsZUFBZSxjQUFjLE1BQU0sZUFFelQsZ0JBQWdCLEtBQUssZUFBZTtHQUcxQztHQUNBLElBQUksV0FBVyxTQUFTLEdBQ3RCLFFBQVEsUUFBUSxFQUFFLFNBQVMsV0FBVyxHQUFHLFdBQVcsT0FBTztHQUU3RCxJQUFJLGdCQUFnQixTQUFTLEdBQzNCLE9BQU87RUFFWDtDQUVGLEdBQUcsQ0FBQyxRQUFRLEtBQUssQ0FBQztDQUNsQixhQUFNLGdCQUFnQjtFQUNwQixJQUFJLGdCQUNGLFFBQVEsUUFBUSxFQUFFLFNBQVMsZUFBZSxHQUFHLFdBQVcsT0FBTztDQUVuRSxHQUFHLENBQUMsUUFBUSxjQUFjLENBQUM7Q0FDM0IsT0FBTztBQUNUOzs7QUM5Q0EsU0FBUyxjQUFjLFNBQVMsYUFBYTtDQUMzQyxNQUFNLFNBQVMsZUFBZSxXQUFXO0NBQ3pDLE1BQU0sYUFBYSxPQUFPLGNBQWM7Q0FDeEMsT0FBQSxhQUFhLHFCQUFBLGFBQ0wsYUFDSCxrQkFBa0IsV0FBVyxVQUFVLGNBQWMsV0FBVyxhQUFhLENBQUMsR0FDL0UsQ0FBQyxVQUFVLENBQ2IsU0FDTSxPQUFPLFdBQVcsT0FBTyxTQUN6QixPQUFPLFdBQVcsT0FBTyxDQUNqQztBQUNGOzs7QUNYQSxTQUFTLGNBQWMsU0FBUyxhQUFhO0NBQzNDLE1BQU0sU0FBUyxlQUFlLFdBQVc7Q0FDekMsT0FBTyxpQkFDTCxFQUFFLFNBQVM7RUFBRSxHQUFHO0VBQVMsUUFBUTtDQUFVLEVBQUUsR0FDN0MsTUFDRixDQUFDLENBQUM7QUFDSjtBQUNBLFNBQVMsVUFBVSxlQUFlLFNBQVM7Q0FDekMsT0FBTyxjQUFjLFFBQVEsUUFBUSxPQUFPLENBQUMsQ0FBQyxLQUMzQyxhQUFhLFFBQVEsU0FBUyxRQUFRLE9BQU8sUUFBUSxJQUFJLFNBQVMsS0FDckU7QUFDRjtBQUNBLFNBQVMsaUJBQWlCLFVBQVUsQ0FBQyxHQUFHLGFBQWE7Q0FDbkQsTUFBTSxnQkFBZ0IsZUFBZSxXQUFXLENBQUMsQ0FBQyxpQkFBaUI7Q0FDbkUsTUFBTSxhQUFBLGFBQW1CLE9BQU8sT0FBTztDQUN2QyxNQUFNLFNBQUEsYUFBZSxPQUFPLElBQUk7Q0FDaEMsSUFBSSxPQUFPLFlBQVksTUFDckIsT0FBTyxVQUFVLFVBQVUsZUFBZSxPQUFPO0NBRW5ELGFBQU0sZ0JBQWdCO0VBQ3BCLFdBQVcsVUFBVTtDQUN2QixDQUFDO0NBQ0QsT0FBQSxhQUFhLHFCQUFBLGFBQ0wsYUFDSCxrQkFBa0IsY0FBYyxnQkFBZ0I7RUFDL0MsTUFBTSxhQUFhLGlCQUNqQixPQUFPLFNBQ1AsVUFBVSxlQUFlLFdBQVcsT0FBTyxDQUM3QztFQUNBLElBQUksT0FBTyxZQUFZLFlBQVk7R0FDakMsT0FBTyxVQUFVO0dBQ2pCLGNBQWMsU0FBUyxhQUFhO0VBQ3RDO0NBQ0YsQ0FBQyxHQUNELENBQUMsYUFBYSxDQUNoQixTQUNNLE9BQU8sZUFDUCxPQUFPLE9BQ2Y7QUFDRjs7O0FDbENBLFNBQVMsWUFBWSxTQUFTLGFBQWE7Q0FDekMsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxNQUFNLENBQUMsWUFBQSxhQUFrQixlQUNqQixJQUFJLGlCQUNSLFFBQ0EsT0FDRixDQUNGO0NBQ0EsYUFBTSxnQkFBZ0I7RUFDcEIsU0FBUyxXQUFXLE9BQU87Q0FDN0IsR0FBRyxDQUFDLFVBQVUsT0FBTyxDQUFDO0NBQ3RCLE1BQU0sU0FBQSxhQUFlLHFCQUFBLGFBQ2IsYUFDSCxrQkFBa0IsU0FBUyxVQUFVLGNBQWMsV0FBVyxhQUFhLENBQUMsR0FDN0UsQ0FBQyxRQUFRLENBQ1gsU0FDTSxTQUFTLGlCQUFpQixTQUMxQixTQUFTLGlCQUFpQixDQUNsQztDQUNBLE1BQU0sU0FBQSxhQUFlLGFBQ2xCLFdBQVcsa0JBQWtCO0VBQzVCLFNBQVMsT0FBTyxXQUFXLGFBQWEsQ0FBQyxDQUFDLE1BQU0sSUFBSTtDQUN0RCxHQUNBLENBQUMsUUFBUSxDQUNYO0NBQ0EsSUFBSSxPQUFPLFNBQVMsaUJBQWlCLFNBQVMsUUFBUSxjQUFjLENBQUMsT0FBTyxLQUFLLENBQUMsR0FDaEYsTUFBTSxPQUFPO0NBRWYsT0FBTztFQUFFLEdBQUc7RUFBUTtFQUFRLGFBQWEsT0FBTztDQUFPO0FBQ3pEOzs7QUN2Q0EsU0FBUyxnQkFBZ0IsU0FBUztDQUNoQyxPQUFPO0FBQ1Q7OztBQ0VBLFNBQVMsaUJBQWlCLFNBQVMsYUFBYTtDQUM5QyxPQUFPLGFBQ0wsU0FDQSx1QkFDQSxXQUNGO0FBQ0YiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOCwxOSwyMCwyMSwyMiwyMywyNCwyNSwyNiwyNywyOCwyOSwzMCwzMSwzMiwzMywzNCwzNSwzNiwzNywzOCwzOSw0MCw0MSw0Miw0M119