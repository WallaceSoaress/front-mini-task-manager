import styled from "/node_modules/.vite/deps/styled-components.js?v=85d7ad7c";
export const Navigation = styled.nav`
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;

  a {
    min-height: 36px;
    display: inline-flex;
    align-items: center;
    border: 1px solid ${({ theme }) => theme.colors.border};
    border-radius: 8px;
    padding: 0 12px;
    color: ${({ theme }) => theme.colors.text_black};
    background: ${({ theme }) => theme.colors.white};
    font-size: 14px;
    font-weight: 700;
    text-decoration: none;
  }

  a.active {
    border-color: ${({ theme }) => theme.colors.primary_dark};
    color: ${({ theme }) => theme.colors.text_white};
    background: ${({ theme }) => theme.colors.primary_dark};
  }

  @media (max-width: 560px) {
    width: 100%;

    a {
      flex: 1;
      justify-content: center;
    }
  }
`;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsT0FBT0EsWUFBWTtBQUVuQixPQUFPLE1BQU1DLGFBQWFELE9BQU9FLEdBQUc7Ozs7Ozs7Ozs7eUJBVVgsRUFBRUMsWUFBWUEsTUFBTUMsT0FBT0MsT0FBTTs7O2NBRzVDLEVBQUVGLFlBQVlBLE1BQU1DLE9BQU9FLFdBQVU7bUJBQ2hDLEVBQUVILFlBQVlBLE1BQU1DLE9BQU9HLE1BQUs7Ozs7Ozs7cUJBTzlCLEVBQUVKLFlBQVlBLE1BQU1DLE9BQU9JLGFBQVk7Y0FDOUMsRUFBRUwsWUFBWUEsTUFBTUMsT0FBT0ssV0FBVTttQkFDaEMsRUFBRU4sWUFBWUEsTUFBTUMsT0FBT0ksYUFBWSIsIm5hbWVzIjpbInN0eWxlZCIsIk5hdmlnYXRpb24iLCJuYXYiLCJ0aGVtZSIsImNvbG9ycyIsImJvcmRlciIsInRleHRfYmxhY2siLCJ3aGl0ZSIsInByaW1hcnlfZGFyayIsInRleHRfd2hpdGUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsic3R5bGVzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XG5cbmV4cG9ydCBjb25zdCBOYXZpZ2F0aW9uID0gc3R5bGVkLm5hdmBcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgZ2FwOiA4cHg7XG4gIGZsZXgtd3JhcDogd3JhcDtcblxuICBhIHtcbiAgICBtaW4taGVpZ2h0OiAzNnB4O1xuICAgIGRpc3BsYXk6IGlubGluZS1mbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgYm9yZGVyOiAxcHggc29saWQgJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMuYm9yZGVyfTtcbiAgICBib3JkZXItcmFkaXVzOiA4cHg7XG4gICAgcGFkZGluZzogMCAxMnB4O1xuICAgIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy50ZXh0X2JsYWNrfTtcbiAgICBiYWNrZ3JvdW5kOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy53aGl0ZX07XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xuICB9XG5cbiAgYS5hY3RpdmUge1xuICAgIGJvcmRlci1jb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMucHJpbWFyeV9kYXJrfTtcbiAgICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMudGV4dF93aGl0ZX07XG4gICAgYmFja2dyb3VuZDogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMucHJpbWFyeV9kYXJrfTtcbiAgfVxuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1NjBweCkge1xuICAgIHdpZHRoOiAxMDAlO1xuXG4gICAgYSB7XG4gICAgICBmbGV4OiAxO1xuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgfVxuICB9XG5gO1xuIl0sImZpbGUiOiJDOi9Vc2Vycy93YWxsYS9EZXNrdG9wL1Byb2pldG9zLXBlc3NvYWlzL3Byb3ZhLXRlY25pY2EvZnJvbnQtbWluaS10YXNrLW1hbmFnZXIvc3JjL2NvbXBvbmVudHMvbGF5b3V0L3N0eWxlcy50cyJ9