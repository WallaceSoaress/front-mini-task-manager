import { n as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-BPOCksWG.js?v=f59827d3";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=2ae0ea78";
//#region node_modules/react-hook-form/dist/index.esm.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var isCheckBoxInput = (element) => element.type === "checkbox";
var isFileInput = (element) => element.type === "file";
var isDateObject = (value) => value instanceof Date;
var isNullOrUndefined = (value) => value == null;
var isObjectType = (value) => typeof value === "object";
var isObject = (value) => !isNullOrUndefined(value) && !Array.isArray(value) && isObjectType(value) && !isDateObject(value);
var getEventValue = (event) => isObject(event) && event.target ? isCheckBoxInput(event.target) ? event.target.checked : isFileInput(event.target) ? event.target.files : event.target.value : event;
var isNameInFieldArray = (names, name) => name.split(".").some((part, index, arr) => !isNaN(Number(part)) && names.has(arr.slice(0, index).join(".")));
var isPlainObject = (tempObject) => {
	const prototypeCopy = tempObject.constructor && tempObject.constructor.prototype;
	return isObject(prototypeCopy) && prototypeCopy.hasOwnProperty("isPrototypeOf");
};
var isWeb = typeof window !== "undefined" && typeof window.HTMLElement !== "undefined" && typeof document !== "undefined";
function cloneObject(data) {
	if (data instanceof Date) return new Date(data);
	const isFileListInstance = typeof FileList !== "undefined" && data instanceof FileList;
	if (isWeb && (data instanceof Blob || isFileListInstance)) return data;
	const isArray = Array.isArray(data);
	if (!isArray && !(isObject(data) && isPlainObject(data))) return data;
	const copy = isArray ? [] : Object.create(Object.getPrototypeOf(data));
	for (const key in data) if (Object.prototype.hasOwnProperty.call(data, key)) copy[key] = cloneObject(data[key]);
	return copy;
}
var EVENTS = {
	BLUR: "blur",
	FOCUS_OUT: "focusout",
	CHANGE: "change",
	SUBMIT: "submit",
	TRIGGER: "trigger",
	VALID: "valid"
};
var VALIDATION_MODE = {
	onBlur: "onBlur",
	onChange: "onChange",
	onSubmit: "onSubmit",
	onTouched: "onTouched",
	all: "all"
};
var INPUT_VALIDATION_RULES = {
	max: "max",
	min: "min",
	maxLength: "maxLength",
	minLength: "minLength",
	pattern: "pattern",
	required: "required",
	validate: "validate"
};
var ROOT_ERROR_TYPE = "root";
var PROTOTYPE_KEYWORDS = [
	"__proto__",
	"constructor",
	"prototype"
];
var IS_KEY_RE = /^\w*$/;
var isKey = (value) => IS_KEY_RE.test(value);
var isUndefined = (val) => val === void 0;
var FIELD_PATH_RE = /[.[\]'"]/;
var stringToPath = (input) => input.split(FIELD_PATH_RE).filter(Boolean);
var get = (object, path, defaultValue) => {
	if (!path || !isObject(object)) return defaultValue;
	const paths = isKey(path) ? [path] : stringToPath(path);
	if (paths.some((key) => PROTOTYPE_KEYWORDS.includes(key))) return defaultValue;
	const result = paths.reduce((result, key) => {
		return isNullOrUndefined(result) ? void 0 : result[key];
	}, object);
	return isUndefined(result) || result === object ? isUndefined(object[path]) ? defaultValue : object[path] : result;
};
var isBoolean = (value) => typeof value === "boolean";
var isFunction = (value) => typeof value === "function";
var set = (object, path, value) => {
	let index = -1;
	const tempPath = isKey(path) ? [path] : stringToPath(path);
	const length = tempPath.length;
	const lastIndex = length - 1;
	while (++index < length) {
		const key = tempPath[index];
		let newValue = value;
		if (index !== lastIndex) {
			const objValue = object[key];
			newValue = isObject(objValue) || Array.isArray(objValue) ? objValue : !isNaN(+tempPath[index + 1]) ? [] : {};
		}
		if (PROTOTYPE_KEYWORDS.includes(key)) return;
		object[key] = newValue;
		object = object[key];
	}
};
/**
* Separate context for `control` to prevent unnecessary rerenders.
* Internal hooks that only need control use this instead of full form context.
*/
var HookFormControlContext = import_react.createContext(null);
HookFormControlContext.displayName = "HookFormControlContext";
/**
* @internal Internal hook to access only control from context.
*/
var useFormControlContext = () => import_react.useContext(HookFormControlContext);
var getProxyFormState = (formState, control, localProxyFormState, isRoot = true) => {
	const result = {};
	for (const key in formState) Object.defineProperty(result, key, { get: () => {
		const _key = key;
		if (control._proxyFormState[_key] !== VALIDATION_MODE.all) control._proxyFormState[_key] = !isRoot || VALIDATION_MODE.all;
		localProxyFormState && (localProxyFormState[_key] = true);
		return formState[_key];
	} });
	return result;
};
var useIsomorphicLayoutEffect = isWeb ? import_react.useLayoutEffect : import_react.useEffect;
var isPrimitive = (value) => isNullOrUndefined(value) || !isObjectType(value);
var isEmptyObjectWithCustomPrototype = (object, keys) => keys.length === 0 && !Array.isArray(object) && !isPlainObject(object);
function deepEqual(object1, object2, visited = /* @__PURE__ */ new WeakMap()) {
	if (object1 === object2) return true;
	if (isPrimitive(object1) || isPrimitive(object2)) return Object.is(object1, object2);
	if (isDateObject(object1) && isDateObject(object2)) return Object.is(object1.getTime(), object2.getTime());
	const keys1 = Object.keys(object1);
	const keys2 = Object.keys(object2);
	if (keys1.length !== keys2.length) return false;
	if (isEmptyObjectWithCustomPrototype(object1, keys1) || isEmptyObjectWithCustomPrototype(object2, keys2)) return Object.is(object1, object2);
	if (!keys1.length && Array.isArray(object1) !== Array.isArray(object2)) return false;
	const visitedPairs = visited.get(object1);
	if (visitedPairs && visitedPairs.has(object2)) return true;
	if (visitedPairs) visitedPairs.add(object2);
	else {
		const ws = /* @__PURE__ */ new WeakSet();
		ws.add(object2);
		visited.set(object1, ws);
	}
	for (const key of keys1) {
		const val1 = object1[key];
		if (!(key in object2)) return false;
		if (key !== "ref") {
			const val2 = object2[key];
			if (isDateObject(val1) && isDateObject(val2) || (isObject(val1) || Array.isArray(val1)) && (isObject(val2) || Array.isArray(val2)) ? !deepEqual(val1, val2, visited) : !Object.is(val1, val2)) return false;
		}
	}
	return true;
}
function useResyncOnReconnect() {
	const _connected = import_react.useRef(false);
	const _prevValue = import_react.useRef(void 0);
	return {
		resyncIfNeeded: import_react.useCallback((enabled, getCurrentValue, setValue) => {
			if (enabled && _connected.current) {
				const currentValue = getCurrentValue();
				if (!deepEqual(_prevValue.current, currentValue)) setValue(currentValue);
			}
			_connected.current = true;
		}, []),
		snapshot: import_react.useCallback((enabled, getCurrentValue) => {
			if (enabled) _prevValue.current = cloneObject(getCurrentValue());
		}, [])
	};
}
/**
* Subscribes to each form state and isolates re-renders at the custom hook level. It has its own scope for form state subscriptions, so it will not affect other useFormState or useForm instances. Using this hook can reduce the re-render impact on large and complex form applications.
*
* @remarks
* [API](https://react-hook-form.com/docs/useformstate) • [Demo](https://codesandbox.io/s/useformstate-75xly)
*
* @param props - Include options to specify fields to subscribe to. {@link UseFormStateReturn}
*
* @example
* ```tsx
* function App() {
*   const { register, handleSubmit, control } = useForm({
*     defaultValues: {
*     firstName: "firstName"
*   }});
*   const { dirtyFields } = useFormState({
*     control
*   });
*   const onSubmit = (data) => console.log(data);
*
*   return (
*     <form onSubmit={handleSubmit(onSubmit)}>
*       <input {...register("firstName")} placeholder="First Name" />
*       {dirtyFields.firstName && <p>Field is dirty.</p>}
*       <input type="submit" />
*     </form>
*   );
* }
* ```
*/
function useFormState(props) {
	const formControl = useFormControlContext();
	const { control = formControl, disabled, name, exact } = props || {};
	const [formState, updateFormState] = import_react.useState(() => ({
		...control._formState,
		defaultValues: control._defaultValues
	}));
	const _localProxyFormState = import_react.useRef({
		isDirty: false,
		isLoading: false,
		dirtyFields: false,
		touchedFields: false,
		validatingFields: false,
		isValidating: false,
		isValid: false,
		errors: false
	});
	const { resyncIfNeeded, snapshot } = useResyncOnReconnect();
	useIsomorphicLayoutEffect(() => {
		const getCurrentFormState = () => ({
			...control._formState,
			defaultValues: control._defaultValues
		});
		resyncIfNeeded(!disabled, getCurrentFormState, updateFormState);
		const unsubscribe = control._subscribe({
			name,
			formState: _localProxyFormState.current,
			exact,
			callback: (formState) => {
				!disabled && updateFormState({
					...control._formState,
					...formState,
					defaultValues: control._defaultValues
				});
			}
		});
		return () => {
			unsubscribe();
			snapshot(!disabled, getCurrentFormState);
		};
	}, [
		name,
		disabled,
		exact,
		resyncIfNeeded,
		snapshot
	]);
	import_react.useEffect(() => {
		_localProxyFormState.current.isValid && control._setValid(true);
	}, [control]);
	return import_react.useMemo(() => getProxyFormState(formState, control, _localProxyFormState.current, false), [formState, control]);
}
var isString = (value) => typeof value === "string";
var generateWatchOutput = (names, _names, formValues, isGlobal, defaultValue) => {
	if (isString(names)) {
		isGlobal && _names.watch.add(names);
		return get(formValues, names, defaultValue);
	}
	if (Array.isArray(names)) return names.map((fieldName) => (isGlobal && _names.watch.add(fieldName), get(formValues, fieldName)));
	isGlobal && (_names.watchAll = true);
	return formValues;
};
/**
* Custom hook to subscribe to field changes and isolate re-rendering at the component level.
*
* @remarks
*
* [API](https://react-hook-form.com/docs/usewatch) • [Demo](https://codesandbox.io/s/react-hook-form-v7-ts-usewatch-h9i5e)
*
* @example
* ```tsx
* const { control } = useForm();
* const values = useWatch({
*   name: "fieldName",
*   control,
* })
* ```
*/
function useWatch(props) {
	const formControl = useFormControlContext();
	const { control = formControl, name, defaultValue, disabled, exact, compute } = props || {};
	const _defaultValue = import_react.useRef(defaultValue);
	const _compute = import_react.useRef(compute);
	const _computeFormValues = import_react.useRef(void 0);
	const _prevControl = import_react.useRef(control);
	const _prevName = import_react.useRef(name);
	_compute.current = compute;
	const [value, updateValue] = import_react.useState(() => {
		const defaultValue = control._getWatch(name, _defaultValue.current);
		return _compute.current ? _compute.current(defaultValue) : defaultValue;
	});
	const getCurrentOutput = import_react.useCallback((values) => {
		const formValues = generateWatchOutput(name, control._names, values || control._formValues, false, _defaultValue.current);
		return _compute.current ? _compute.current(formValues) : formValues;
	}, [
		control._formValues,
		control._names,
		name
	]);
	const refreshValue = import_react.useCallback((values) => {
		if (!disabled) {
			const formValues = generateWatchOutput(name, control._names, values || control._formValues, false, _defaultValue.current);
			if (_compute.current) {
				const computedFormValues = _compute.current(formValues);
				if (!deepEqual(computedFormValues, _computeFormValues.current)) {
					updateValue(computedFormValues);
					_computeFormValues.current = computedFormValues;
				}
			} else updateValue(formValues);
		}
	}, [
		control._formValues,
		control._names,
		disabled,
		name
	]);
	const { resyncIfNeeded, snapshot } = useResyncOnReconnect();
	const _refreshValue = import_react.useRef(refreshValue);
	_refreshValue.current = refreshValue;
	const _getCurrentOutput = import_react.useRef(getCurrentOutput);
	_getCurrentOutput.current = getCurrentOutput;
	useIsomorphicLayoutEffect(() => {
		if (_prevControl.current !== control || !deepEqual(_prevName.current, name)) {
			_prevControl.current = control;
			_prevName.current = name;
			_refreshValue.current();
		} else resyncIfNeeded(!disabled, () => _getCurrentOutput.current(), (currentValue) => {
			updateValue(currentValue);
			_computeFormValues.current = currentValue;
		});
		const unsubscribe = control._subscribe({
			name,
			formState: { values: true },
			exact,
			callback: (formState) => {
				_refreshValue.current(formState.values);
			}
		});
		return () => {
			unsubscribe();
			snapshot(!disabled, () => _getCurrentOutput.current());
		};
	}, [
		control,
		exact,
		name,
		disabled,
		resyncIfNeeded,
		snapshot
	]);
	import_react.useEffect(() => control._removeUnmounted());
	const controlChanged = _prevControl.current !== control;
	const prevName = _prevName.current;
	const computedOutput = import_react.useMemo(() => {
		if (disabled) return null;
		const nameChanged = !controlChanged && !deepEqual(prevName, name);
		return controlChanged || nameChanged ? getCurrentOutput() : null;
	}, [
		disabled,
		controlChanged,
		name,
		prevName,
		getCurrentOutput
	]);
	return computedOutput !== null ? computedOutput : value;
}
/**
* Custom hook to work with controlled component, this function provide you with both form and field level state. Re-render is isolated at the hook level.
*
* @remarks
* [API](https://react-hook-form.com/docs/usecontroller) • [Demo](https://codesandbox.io/s/usecontroller-0o8px)
*
* @param props - the path name to the form field value, and validation rules.
*
* @returns field properties, field and form state. {@link UseControllerReturn}
*
* @example
* ```tsx
* function Input(props) {
*   const { field, fieldState, formState } = useController(props);
*   return (
*     <div>
*       <input {...field} placeholder={props.name} />
*       <p>{fieldState.isTouched && "Touched"}</p>
*       <p>{formState.isSubmitted ? "submitted" : ""}</p>
*     </div>
*   );
* }
* ```
*/
function useController(props) {
	const formControl = useFormControlContext();
	const { name, disabled, control = formControl, shouldUnregister, defaultValue, exact = true } = props;
	const isArrayField = isNameInFieldArray(control._names.array, name);
	const value = useWatch({
		control,
		name,
		defaultValue: import_react.useMemo(() => get(control._formValues, name, get(control._defaultValues, name, defaultValue)), [
			control,
			name,
			defaultValue
		]),
		exact
	});
	const formState = useFormState({
		control,
		name,
		exact
	});
	const _props = import_react.useRef(props);
	const _proxyRef = import_react.useRef(null);
	const _registerProps = import_react.useRef(control.register(name, {
		...props.rules,
		value,
		...isBoolean(props.disabled) ? { disabled: props.disabled } : {}
	}));
	_props.current = props;
	const fieldState = import_react.useMemo(() => Object.defineProperties({}, {
		invalid: {
			enumerable: true,
			get: () => !!get(formState.errors, name)
		},
		isDirty: {
			enumerable: true,
			get: () => !!get(formState.dirtyFields, name)
		},
		isTouched: {
			enumerable: true,
			get: () => !!get(formState.touchedFields, name)
		},
		isValidating: {
			enumerable: true,
			get: () => !!get(formState.validatingFields, name)
		},
		error: {
			enumerable: true,
			get: () => get(formState.errors, name)
		}
	}), [formState, name]);
	const onChange = import_react.useCallback((event) => {
		const value = getEventValue(event);
		if (!get(control._fields, name)) _registerProps.current = control.register(name, {
			..._props.current.rules,
			value
		});
		return _registerProps.current.onChange({
			target: {
				value: getEventValue(event),
				name
			},
			type: EVENTS.CHANGE
		});
	}, [name, control]);
	const onBlur = import_react.useCallback(() => _registerProps.current.onBlur({
		target: {
			value: get(control._formValues, name),
			name
		},
		type: EVENTS.BLUR
	}), [name, control._formValues]);
	const ref = import_react.useCallback((elm) => {
		if (elm) _proxyRef.current = {
			focus: () => isFunction(elm.focus) && elm.focus(),
			select: () => isFunction(elm.select) && elm.select(),
			setCustomValidity: (message) => isFunction(elm.setCustomValidity) && elm.setCustomValidity(message),
			reportValidity: () => isFunction(elm.reportValidity) && elm.reportValidity()
		};
		const field = get(control._fields, name);
		if (field && field._f && elm) field._f.ref = _proxyRef.current;
	}, [control._fields, name]);
	const field = import_react.useMemo(() => ({
		name,
		value,
		...isBoolean(disabled) || formState.disabled ? { disabled: formState.disabled || disabled } : {},
		onChange,
		onBlur,
		ref
	}), [
		name,
		disabled,
		formState.disabled,
		onChange,
		onBlur,
		ref,
		value
	]);
	import_react.useEffect(() => {
		const _shouldUnregisterField = control._options.shouldUnregister || shouldUnregister;
		_registerProps.current = control.register(name, {
			..._props.current.rules,
			...isBoolean(_props.current.disabled) ? { disabled: _props.current.disabled } : {}
		});
		const updateMounted = (name, value) => {
			const field = get(control._fields, name);
			if (field && field._f) field._f.mount = value;
		};
		updateMounted(name, true);
		if (_shouldUnregisterField) {
			const value = cloneObject(get(shouldUnregister ? control._defaultValues : control._options.values || control._defaultValues, name, get(control._options.defaultValues, name, _props.current.defaultValue)));
			set(control._defaultValues, name, value);
			if (isUndefined(get(control._formValues, name))) set(control._formValues, name, value);
		}
		!isArrayField && control.register(name);
		if (_proxyRef.current) {
			const field = get(control._fields, name);
			if (field && field._f) field._f.ref = _proxyRef.current;
		}
		return () => {
			(isArrayField ? _shouldUnregisterField && !control._state.action : _shouldUnregisterField) ? control.unregister(name) : updateMounted(name, false);
		};
	}, [
		name,
		control,
		isArrayField,
		shouldUnregister
	]);
	import_react.useEffect(() => {
		control._setDisabledField({
			disabled,
			name
		});
	}, [
		disabled,
		name,
		control
	]);
	return import_react.useMemo(() => ({
		field,
		formState,
		fieldState
	}), [
		field,
		formState,
		fieldState
	]);
}
/**
* Component based on `useController` hook to work with controlled component.
*
* @remarks
* [API](https://react-hook-form.com/docs/usecontroller/controller) • [Demo](https://codesandbox.io/s/react-hook-form-v6-controller-ts-jwyzw) • [Video](https://www.youtube.com/watch?v=N2UNk_UCVyA)
*
* @param props - the path name to the form field value, and validation rules.
*
* @returns provide field handler functions, field and form state.
*
* @example
* ```tsx
* function App() {
*   const { control } = useForm<FormValues>({
*     defaultValues: {
*       test: ""
*     }
*   });
*
*   return (
*     <form>
*       <Controller
*         control={control}
*         name="test"
*         render={({ field: { onChange, onBlur, value, ref }, formState, fieldState }) => (
*           <>
*             <input
*               onChange={onChange} // send value to hook form
*               onBlur={onBlur} // notify when input is touched
*               value={value} // return updated value
*               ref={ref} // set ref for focus management
*             />
*             <p>{formState.isSubmitted ? "submitted" : ""}</p>
*             <p>{fieldState.isTouched ? "touched" : ""}</p>
*           </>
*         )}
*       />
*     </form>
*   );
* }
* ```
*/
var Controller = (props) => props.render(useController(props));
var generateId = () => {
	if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
	const d = typeof performance === "undefined" ? Date.now() : performance.now() * 1e3;
	return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
		const r = (Math.random() * 16 + d) % 16 | 0;
		return (c == "x" ? r : r & 3 | 8).toString(16);
	});
};
var getFocusFieldName = (name, index, options = {}) => options.shouldFocus || isUndefined(options.shouldFocus) ? options.focusName || `${name}.${isUndefined(options.focusIndex) ? index : options.focusIndex}.` : "";
var getValidationModes = (mode) => ({
	isOnSubmit: !mode || mode === VALIDATION_MODE.onSubmit,
	isOnBlur: mode === VALIDATION_MODE.onBlur,
	isOnChange: mode === VALIDATION_MODE.onChange,
	isOnAll: mode === VALIDATION_MODE.all,
	isOnTouch: mode === VALIDATION_MODE.onTouched
});
var isWatched = (name, _names, isBlurEvent) => {
	if (isBlurEvent) return false;
	if (_names.watchAll || _names.watch.has(name)) return true;
	for (const watchName of _names.watch) if (name.startsWith(watchName) && name.charAt(watchName.length) === ".") return true;
	return false;
};
var iterateFieldsByAction = (fields, action, fieldsNames, abortEarly) => {
	for (const key of fieldsNames || Object.keys(fields)) {
		if (key === "_f") continue;
		const field = fieldsNames ? get(fields, key) : fields[key];
		if (field) {
			const { _f } = field;
			if (_f) {
				if (_f.refs && _f.refs[0] && action(_f.refs[0], key) && !abortEarly) return true;
				else if (_f.ref && action(_f.ref, _f.name) && !abortEarly) return true;
				else if (iterateFieldsByAction(field, action)) break;
			} else if (isObject(field) || Array.isArray(field)) {
				if (iterateFieldsByAction(field, action)) break;
			}
		}
	}
};
var updateFieldArrayRootError = (errors, error, name) => {
	const existingErrors = get(errors, name);
	const fieldArrayErrors = Array.isArray(existingErrors) ? existingErrors : [];
	set(fieldArrayErrors, ROOT_ERROR_TYPE, error[name]);
	set(errors, name, fieldArrayErrors);
	return errors;
};
var isEmptyObject = (value) => isObject(value) && !Object.keys(value).length;
var isHTMLElement = (value) => {
	if (!isWeb) return false;
	const owner = value ? value.ownerDocument : 0;
	return value instanceof (owner && owner.defaultView ? owner.defaultView.HTMLElement : HTMLElement);
};
var isRadioInput = (element) => element.type === "radio";
var isRegex = (value) => value instanceof RegExp;
var appendErrors = (name, validateAllFieldCriteria, errors, type, message) => validateAllFieldCriteria ? {
	...errors[name],
	types: {
		...errors[name] && errors[name].types ? errors[name].types : {},
		[type]: message || true
	}
} : {};
var defaultResult = {
	value: false,
	isValid: false
};
var validResult = {
	value: true,
	isValid: true
};
var getCheckboxValue = (options) => {
	if (Array.isArray(options)) {
		if (options.length > 1) {
			const values = options.filter((option) => option && option.checked && !option.disabled).map((option) => option.value);
			return {
				value: values,
				isValid: !!values.length
			};
		}
		return options[0].checked && !options[0].disabled ? options[0].attributes && !isUndefined(options[0].attributes.value) ? isUndefined(options[0].value) || options[0].value === "" ? validResult : {
			value: options[0].value,
			isValid: true
		} : validResult : defaultResult;
	}
	return defaultResult;
};
var defaultReturn = {
	isValid: false,
	value: null
};
var getRadioValue = (options) => Array.isArray(options) ? options.reduce((previous, option) => option && option.checked && !option.disabled ? {
	isValid: true,
	value: option.value
} : previous, defaultReturn) : defaultReturn;
function getValidateError(result, ref, type = "validate") {
	if (isString(result) || Array.isArray(result) && result.every(isString) || isBoolean(result) && !result) return {
		type,
		message: isString(result) ? result : "",
		ref
	};
}
var getValueAndMessage = (validationData) => isObject(validationData) && !isRegex(validationData) ? validationData : {
	value: validationData,
	message: ""
};
var validateField = async (field, disabledFieldNames, formValues, validateAllFieldCriteria, shouldUseNativeValidation, isFieldArray) => {
	const { ref, refs, required, maxLength, minLength, min, max, pattern, validate, name, valueAsNumber, mount } = field._f;
	const inputValue = get(formValues, name);
	if (!mount || disabledFieldNames.has(name)) return {};
	const inputRef = refs ? refs[0] : ref;
	const setCustomValidity = (message) => {
		if (shouldUseNativeValidation && inputRef.reportValidity) {
			const validityMessage = isBoolean(message) ? "" : message || "";
			if (refs) refs.forEach((ref) => ref.setCustomValidity(validityMessage));
			else inputRef.setCustomValidity(validityMessage);
			inputRef.reportValidity();
		}
	};
	const error = {};
	const isRadio = isRadioInput(ref);
	const isCheckBox = isCheckBoxInput(ref);
	const isRadioOrCheckbox = isRadio || isCheckBox;
	const isEmpty = (valueAsNumber || isFileInput(ref)) && isUndefined(ref.value) && isUndefined(inputValue) || isHTMLElement(ref) && ref.value === "" || inputValue === "" || Array.isArray(inputValue) && !inputValue.length;
	const appendErrorsCurry = appendErrors.bind(null, name, validateAllFieldCriteria, error);
	const getMinMaxMessage = (exceedMax, maxLengthMessage, minLengthMessage, maxType = INPUT_VALIDATION_RULES.maxLength, minType = INPUT_VALIDATION_RULES.minLength) => {
		const message = exceedMax ? maxLengthMessage : minLengthMessage;
		error[name] = {
			type: exceedMax ? maxType : minType,
			message,
			ref,
			...appendErrorsCurry(exceedMax ? maxType : minType, message)
		};
	};
	if (isFieldArray ? !Array.isArray(inputValue) || !inputValue.length : required && (!isRadioOrCheckbox && (isEmpty || isNullOrUndefined(inputValue)) || isBoolean(inputValue) && !inputValue || isCheckBox && !getCheckboxValue(refs).isValid || isRadio && !getRadioValue(refs).isValid)) {
		const { value, message } = isString(required) ? {
			value: !!required,
			message: required
		} : getValueAndMessage(required);
		if (value) {
			error[name] = {
				type: INPUT_VALIDATION_RULES.required,
				message,
				ref: inputRef,
				...appendErrorsCurry(INPUT_VALIDATION_RULES.required, message)
			};
			if (!validateAllFieldCriteria) {
				setCustomValidity(message);
				return error;
			}
		}
	}
	if (!isEmpty && (!isNullOrUndefined(min) || !isNullOrUndefined(max))) {
		let exceedMax;
		let exceedMin;
		const maxOutput = getValueAndMessage(max);
		const minOutput = getValueAndMessage(min);
		if (!isNullOrUndefined(inputValue) && !isDateObject(inputValue) && !isNaN(inputValue)) {
			const valueNumber = ref.valueAsNumber || (inputValue ? +inputValue : inputValue);
			if (!isNullOrUndefined(maxOutput.value)) exceedMax = valueNumber > maxOutput.value;
			if (!isNullOrUndefined(minOutput.value)) exceedMin = valueNumber < minOutput.value;
		} else {
			const valueDate = ref.valueAsDate || new Date(inputValue);
			const convertTimeToDate = (time) => /* @__PURE__ */ new Date((/* @__PURE__ */ new Date()).toDateString() + " " + time);
			const isTime = ref.type == "time";
			const isWeek = ref.type == "week";
			if (isString(maxOutput.value) && inputValue) exceedMax = isTime ? convertTimeToDate(inputValue) > convertTimeToDate(maxOutput.value) : isWeek ? inputValue > maxOutput.value : valueDate > new Date(maxOutput.value);
			if (isString(minOutput.value) && inputValue) exceedMin = isTime ? convertTimeToDate(inputValue) < convertTimeToDate(minOutput.value) : isWeek ? inputValue < minOutput.value : valueDate < new Date(minOutput.value);
		}
		if (exceedMax || exceedMin) {
			getMinMaxMessage(!!exceedMax, maxOutput.message, minOutput.message, INPUT_VALIDATION_RULES.max, INPUT_VALIDATION_RULES.min);
			if (!validateAllFieldCriteria) {
				setCustomValidity(error[name].message);
				return error;
			}
		}
	}
	if ((maxLength || minLength) && !isEmpty && (isString(inputValue) || isFieldArray && Array.isArray(inputValue))) {
		const maxLengthOutput = getValueAndMessage(maxLength);
		const minLengthOutput = getValueAndMessage(minLength);
		const exceedMax = !isNullOrUndefined(maxLengthOutput.value) && inputValue.length > +maxLengthOutput.value;
		const exceedMin = !isNullOrUndefined(minLengthOutput.value) && inputValue.length < +minLengthOutput.value;
		if (exceedMax || exceedMin) {
			getMinMaxMessage(exceedMax, maxLengthOutput.message, minLengthOutput.message);
			if (!validateAllFieldCriteria) {
				setCustomValidity(error[name].message);
				return error;
			}
		}
	}
	if (pattern && !isEmpty && isString(inputValue)) {
		const { value: patternValue, message } = getValueAndMessage(pattern);
		if (isRegex(patternValue) && !inputValue.match(patternValue)) {
			error[name] = {
				type: INPUT_VALIDATION_RULES.pattern,
				message,
				ref,
				...appendErrorsCurry(INPUT_VALIDATION_RULES.pattern, message)
			};
			if (!validateAllFieldCriteria) {
				setCustomValidity(message);
				return error;
			}
		}
	}
	if (validate) {
		if (isFunction(validate)) {
			const validateError = getValidateError(await validate(inputValue, formValues), inputRef);
			if (validateError) {
				error[name] = {
					...validateError,
					...appendErrorsCurry(INPUT_VALIDATION_RULES.validate, validateError.message)
				};
				if (!validateAllFieldCriteria) {
					setCustomValidity(validateError.message);
					return error;
				}
			}
		} else if (isObject(validate)) {
			let validationResult = {};
			for (const key in validate) {
				if (!isEmptyObject(validationResult) && !validateAllFieldCriteria) break;
				const validateError = getValidateError(await validate[key](inputValue, formValues), inputRef, key);
				if (validateError) {
					validationResult = {
						...validateError,
						...appendErrorsCurry(key, validateError.message)
					};
					setCustomValidity(validateError.message);
					if (validateAllFieldCriteria) error[name] = validationResult;
				}
			}
			if (!isEmptyObject(validationResult)) {
				error[name] = {
					ref: inputRef,
					...validationResult
				};
				if (!validateAllFieldCriteria) return error;
			}
		}
	}
	setCustomValidity(true);
	return error;
};
var convertToArrayPayload = (value) => Array.isArray(value) ? value : [value];
var appendAt = (data, value) => [...data, ...convertToArrayPayload(value)];
var fillEmptyArray = (value) => Array.isArray(value) ? value.map(() => void 0) : void 0;
function insert(data, index, value) {
	return [
		...data.slice(0, index),
		...convertToArrayPayload(value),
		...data.slice(index)
	];
}
var moveArrayAt = (data, from, to) => {
	if (!Array.isArray(data)) return [];
	if (isUndefined(data[to])) data[to] = void 0;
	data.splice(to, 0, data.splice(from, 1)[0]);
	return data;
};
var prependAt = (data, value) => [...convertToArrayPayload(value), ...convertToArrayPayload(data)];
var compact = (value) => Array.isArray(value) ? value.filter(Boolean) : [];
function removeAtIndexes(data, indexes) {
	let i = 0;
	const temp = [...data];
	for (const index of indexes) {
		temp.splice(index - i, 1);
		i++;
	}
	return compact(temp).length ? temp : [];
}
var removeArrayAt = (data, index) => isUndefined(index) ? [] : removeAtIndexes(data, convertToArrayPayload(index).sort((a, b) => a - b));
var swapArrayAt = (data, indexA, indexB) => {
	[data[indexA], data[indexB]] = [data[indexB], data[indexA]];
};
function baseGet(object, updatePath) {
	const length = updatePath.length - 1;
	let index = 0;
	while (index < length) {
		if (isNullOrUndefined(object)) {
			object = void 0;
			break;
		}
		object = object[updatePath[index]];
		index++;
	}
	return object;
}
function isEmptyArray(obj) {
	for (const key in obj) if (obj.hasOwnProperty(key) && !isUndefined(obj[key])) return false;
	return true;
}
function unset(object, path) {
	if (isString(path) && Object.prototype.hasOwnProperty.call(object, path)) {
		delete object[path];
		return object;
	}
	const paths = Array.isArray(path) ? path : isKey(path) ? [path] : stringToPath(path);
	if (paths.some((segment) => PROTOTYPE_KEYWORDS.includes(String(segment)))) return object;
	const childObject = paths.length === 1 ? object : baseGet(object, paths);
	const index = paths.length - 1;
	const key = paths[index];
	if (childObject) delete childObject[key];
	if (index !== 0 && (isObject(childObject) && isEmptyObject(childObject) || Array.isArray(childObject) && isEmptyArray(childObject))) unset(object, paths.slice(0, -1));
	return object;
}
var updateAt = (fieldValues, index, value) => {
	fieldValues[index] = value;
	return fieldValues;
};
/**
* A custom hook that exposes convenient methods to perform operations with a list of dynamic inputs that need to be appended, updated, removed etc. • [Demo](https://codesandbox.io/s/react-hook-form-usefieldarray-ssugn) • [Video](https://youtu.be/4MrbfGSFY2A)
*
* @remarks
* [API](https://react-hook-form.com/docs/usefieldarray) • [Demo](https://codesandbox.io/s/react-hook-form-usefieldarray-ssugn)
*
* @param props - useFieldArray props
*
* @returns methods - functions to manipulate with the Field Arrays (dynamic inputs) {@link UseFieldArrayReturn}
*
* @example
* ```tsx
* function App() {
*   const { register, control, handleSubmit, reset, trigger, setError } = useForm({
*     defaultValues: {
*       test: []
*     }
*   });
*   const { fields, append } = useFieldArray({
*     control,
*     name: "test"
*   });
*
*   return (
*     <form onSubmit={handleSubmit(data => console.log(data))}>
*       {fields.map((item, index) => (
*          <input key={item.id} {...register(`test.${index}.firstName`)}  />
*       ))}
*       <button type="button" onClick={() => append({ firstName: "bill" })}>
*         append
*       </button>
*       <input type="submit" />
*     </form>
*   );
* }
* ```
*/
function useFieldArray(props) {
	const formControl = useFormControlContext();
	const { control = formControl, name, keyName = "id", disabled, shouldUnregister, rules } = props;
	const [fields, setFields] = import_react.useState(control._getFieldArray(name));
	const ids = import_react.useRef(control._getFieldArray(name).map(generateId));
	const _actioned = import_react.useRef(false);
	if (!disabled) control._names.array.add(name);
	import_react.useMemo(() => !disabled && rules && fields.length >= 0 && control.register(name, rules), [
		control,
		name,
		fields.length,
		rules,
		disabled
	]);
	useIsomorphicLayoutEffect(() => {
		if (disabled) return;
		return control._subjects.array.subscribe({ next: ({ values, name: fieldArrayName }) => {
			if (fieldArrayName === name || !fieldArrayName) {
				const fieldValues = get(values, name);
				if (Array.isArray(fieldValues)) {
					setFields(fieldValues);
					ids.current = fieldValues.map(generateId);
				} else if (!fieldArrayName) {
					setFields([]);
					ids.current = [];
				}
			}
		} }).unsubscribe;
	}, [
		control,
		name,
		disabled
	]);
	const updateValues = import_react.useCallback((updatedFieldArrayValues) => {
		_actioned.current = true;
		control._setFieldArray(name, updatedFieldArrayValues);
	}, [control, name]);
	const append = (value, options) => {
		if (disabled) return;
		const appendValue = convertToArrayPayload(cloneObject(value));
		const updatedFieldArrayValues = appendAt(control._getFieldArray(name), appendValue);
		control._names.focus = getFocusFieldName(name, updatedFieldArrayValues.length - 1, options);
		ids.current = appendAt(ids.current, appendValue.map(generateId));
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, appendAt, { argA: fillEmptyArray(value) });
	};
	const prepend = (value, options) => {
		if (disabled) return;
		const prependValue = convertToArrayPayload(cloneObject(value));
		const updatedFieldArrayValues = prependAt(control._getFieldArray(name), prependValue);
		control._names.focus = getFocusFieldName(name, 0, options);
		ids.current = prependAt(ids.current, prependValue.map(generateId));
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, prependAt, { argA: fillEmptyArray(value) });
	};
	const remove = (index) => {
		if (disabled) return;
		const updatedFieldArrayValues = removeArrayAt(control._getFieldArray(name), index);
		ids.current = removeArrayAt(ids.current, index);
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		!Array.isArray(get(control._fields, name)) && set(control._fields, name, void 0);
		control._setFieldArray(name, updatedFieldArrayValues, removeArrayAt, { argA: index });
	};
	const insert$1 = (index, value, options) => {
		if (disabled) return;
		const insertValue = convertToArrayPayload(cloneObject(value));
		const updatedFieldArrayValues = insert(control._getFieldArray(name), index, insertValue);
		control._names.focus = getFocusFieldName(name, index, options);
		ids.current = insert(ids.current, index, insertValue.map(generateId));
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, insert, {
			argA: index,
			argB: fillEmptyArray(value)
		});
	};
	const swap = (indexA, indexB) => {
		if (disabled) return;
		const updatedFieldArrayValues = control._getFieldArray(name);
		swapArrayAt(updatedFieldArrayValues, indexA, indexB);
		swapArrayAt(ids.current, indexA, indexB);
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, swapArrayAt, {
			argA: indexA,
			argB: indexB
		}, false);
	};
	const move = (from, to) => {
		if (disabled) return;
		const updatedFieldArrayValues = control._getFieldArray(name);
		moveArrayAt(updatedFieldArrayValues, from, to);
		moveArrayAt(ids.current, from, to);
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, moveArrayAt, {
			argA: from,
			argB: to
		}, false);
	};
	const update = (index, value) => {
		if (disabled) return;
		const updateValue = cloneObject(value);
		const updatedFieldArrayValues = updateAt(control._getFieldArray(name), index, updateValue);
		ids.current = [...updatedFieldArrayValues].map((item, i) => !item || i === index ? generateId() : ids.current[i]);
		updateValues(updatedFieldArrayValues);
		setFields([...updatedFieldArrayValues]);
		control._setFieldArray(name, updatedFieldArrayValues, updateAt, {
			argA: index,
			argB: updateValue
		}, true, false);
	};
	const replace = (value) => {
		if (disabled) return;
		const updatedFieldArrayValues = convertToArrayPayload(cloneObject(value));
		ids.current = updatedFieldArrayValues.map(generateId);
		updateValues([...updatedFieldArrayValues]);
		setFields([...updatedFieldArrayValues]);
		control._setFieldArray(name, [...updatedFieldArrayValues], (data) => data, {}, true, false);
	};
	import_react.useEffect(() => {
		if (disabled) {
			control._state.actionArrayLengths.delete(name);
			return;
		}
		control._state.action = false;
		control._state.actionArrayLengths.delete(name);
		isWatched(name, control._names) && control._subjects.state.next({ ...control._formState });
		const validationModes = getValidationModes(control._options.mode);
		if (_actioned.current && (!validationModes.isOnSubmit || control._formState.isSubmitted) && !getValidationModes(control._options.reValidateMode).isOnSubmit && !validationModes.isOnBlur) {
			if (control._options.resolver) control._runSchema([name]).then((result) => {
				var _a, _b;
				control._updateIsValidating([name]);
				const error = get(result.errors, name);
				const existingError = get(control._formState.errors, name);
				const existingErrorType = existingError && (existingError.type || ((_a = existingError.root) === null || _a === void 0 ? void 0 : _a.type));
				const existingErrorMessage = existingError && (existingError.message || ((_b = existingError.root) === null || _b === void 0 ? void 0 : _b.message));
				if (existingError ? !error && existingErrorType || error && (existingErrorType !== error.type || existingErrorMessage !== error.message) : error && error.type) {
					if (error) isObject(error) && !Object.keys(error).some((key) => !Number.isNaN(+key)) ? updateFieldArrayRootError(control._formState.errors, { [name]: error }, name) : set(control._formState.errors, name, error);
					else unset(control._formState.errors, name);
					control._subjects.state.next({ errors: control._formState.errors });
				}
			});
			else {
				const field = get(control._fields, name);
				if (field && field._f && !(getValidationModes(control._options.reValidateMode).isOnSubmit && getValidationModes(control._options.mode).isOnSubmit)) validateField(field, control._names.disabled, control._formValues, control._options.criteriaMode === VALIDATION_MODE.all, control._options.shouldUseNativeValidation, true).then((error) => !isEmptyObject(error) && control._subjects.state.next({ errors: updateFieldArrayRootError(control._formState.errors, error, name) }));
			}
		}
		_actioned.current && control._subjects.state.next({
			name,
			values: cloneObject(control._formValues)
		});
		control._names.focus && iterateFieldsByAction(control._fields, (ref, key) => {
			if (control._names.focus && key.startsWith(control._names.focus) && ref.focus) {
				ref.focus();
				return 1;
			}
		});
		control._names.focus = "";
		control._setValid();
		_actioned.current = false;
	}, [
		fields,
		name,
		control,
		disabled
	]);
	import_react.useEffect(() => {
		if (!disabled) !get(control._formValues, name) && control._setFieldArray(name);
		return () => {
			control._state.actionArrayLengths.delete(name);
			if (disabled) return;
			const shouldKeepFieldArrayValues = !(control._options.shouldUnregister || shouldUnregister);
			const updateMounted = (name, value) => {
				const field = get(control._fields, name);
				if (field && field._f) field._f.mount = value;
			};
			if (_actioned.current && shouldKeepFieldArrayValues) control._subjects.state.next({
				name,
				values: cloneObject(control._formValues)
			});
			shouldKeepFieldArrayValues ? updateMounted(name, false) : control.unregister(name);
		};
	}, [
		name,
		control,
		keyName,
		shouldUnregister,
		disabled
	]);
	return {
		swap: import_react.useCallback(swap, [
			updateValues,
			name,
			control,
			disabled
		]),
		move: import_react.useCallback(move, [
			updateValues,
			name,
			control,
			disabled
		]),
		prepend: import_react.useCallback(prepend, [
			updateValues,
			name,
			control,
			disabled
		]),
		append: import_react.useCallback(append, [
			updateValues,
			name,
			control,
			disabled
		]),
		remove: import_react.useCallback(remove, [
			updateValues,
			name,
			control,
			disabled
		]),
		insert: import_react.useCallback(insert$1, [
			updateValues,
			name,
			control,
			disabled
		]),
		update: import_react.useCallback(update, [
			updateValues,
			name,
			control,
			disabled
		]),
		replace: import_react.useCallback(replace, [
			updateValues,
			name,
			control,
			disabled
		]),
		fields: import_react.useMemo(() => fields.map((field, index) => ({
			...field,
			...isBoolean(disabled) ? { disabled } : {},
			[keyName]: ids.current[index] || generateId()
		})), [
			fields,
			keyName,
			disabled
		])
	};
}
/**
* Component based on `useFieldArray` hook to work with controlled component.
*
* @example
* ```tsx
* function App() {
*   const { control, register } = useForm<FormValues>({
*     defaultValues: {
*       test: [
*         {
*           value: '',
*         },
*       ],
*     },
*   });
*
*   return (
*     <form>
*       <FieldArray
*         control={control}
*         name="test"
*         render={({ fields }) =>
*           fields.map((field, index) => (
*             <input key={field.id} {...register(`test.${index}.value`)} />
*           ))
*         }
*       />
*     </form>
*   );
* }
* ```
*/
var FieldArray = (props) => props.render(useFieldArray(props));
var flatten = (obj) => {
	const output = {};
	for (const key of Object.keys(obj)) if (isObjectType(obj[key]) && obj[key] !== null && !isDateObject(obj[key])) {
		const nested = flatten(obj[key]);
		for (const nestedKey of Object.keys(nested)) output[`${key}.${nestedKey}`] = nested[nestedKey];
	} else output[key] = obj[key];
	return output;
};
function jsonToFormData(json) {
	const result = new FormData();
	const flattenFormValues = flatten(json);
	for (const key in flattenFormValues) result.append(key, flattenFormValues[key]);
	return result;
}
function safeJSONStringify(value) {
	try {
		return JSON.stringify(value);
	} catch (_a) {
		return "";
	}
}
function noop() {}
var HookFormContext = import_react.createContext(null);
HookFormContext.displayName = "HookFormContext";
/**
* This custom hook allows you to access the form context. useFormContext is intended to be used in deeply nested structures, where it would become inconvenient to pass the context as a prop. To be used with {@link FormProvider}.
*
* @remarks
* [API](https://react-hook-form.com/docs/useformcontext) • [Demo](https://codesandbox.io/s/react-hook-form-v7-form-context-ytudi)
*
* @returns return all useForm methods
*
* @example
* ```tsx
* function App() {
*   const methods = useForm();
*   const onSubmit = data => console.log(data);
*
*   return (
*     <FormProvider {...methods} >
*       <form onSubmit={methods.handleSubmit(onSubmit)}>
*         <NestedInput />
*         <input type="submit" />
*       </form>
*     </FormProvider>
*   );
* }
*
*  function NestedInput() {
*   const { register } = useFormContext(); // retrieve all hook methods
*   return <input {...register("test")} />;
* }
* ```
*/
var useFormContext = () => import_react.useContext(HookFormContext);
/**
* A provider component that propagates the `useForm` methods to all children components via [React Context](https://react.dev/reference/react/useContext) API. To be used with {@link useFormContext}.
*
* @remarks
* [API](https://react-hook-form.com/docs/useformcontext) • [Demo](https://codesandbox.io/s/react-hook-form-v7-form-context-ytudi)
*
* @param props - all useForm methods
*
* @example
* ```tsx
* function App() {
*   const methods = useForm();
*   const onSubmit = data => console.log(data);
*
*   return (
*     <FormProvider {...methods} >
*       <form onSubmit={methods.handleSubmit(onSubmit)}>
*         <NestedInput />
*         <input type="submit" />
*       </form>
*     </FormProvider>
*   );
* }
*
*  function NestedInput() {
*   const { register } = useFormContext(); // retrieve all hook methods
*   return <input {...register("test")} />;
* }
* ```
*/
var FormProvider = ({ children, watch, getValues, getFieldState, setError, clearErrors, setValue, setValues, trigger, formState, resetField, reset, resetDefaultValues, handleSubmit, unregister, control, register, setFocus, subscribe }) => {
	const memoizedValue = import_react.useMemo(() => ({
		watch,
		getValues,
		getFieldState,
		setError,
		clearErrors,
		setValue,
		setValues,
		trigger,
		formState,
		resetField,
		reset,
		resetDefaultValues,
		handleSubmit,
		unregister,
		control,
		register,
		setFocus,
		subscribe
	}), [
		clearErrors,
		control,
		formState,
		getFieldState,
		getValues,
		handleSubmit,
		register,
		reset,
		resetDefaultValues,
		resetField,
		setError,
		setFocus,
		setValue,
		setValues,
		subscribe,
		trigger,
		unregister,
		watch
	]);
	return import_react.createElement(HookFormContext.Provider, { value: memoizedValue }, import_react.createElement(HookFormControlContext.Provider, { value: memoizedValue.control }, children));
};
var POST_REQUEST = "post";
function defaultValidateStatus(status) {
	return status >= 200 && status < 300;
}
/**
* Form component to manage submission.
*
* @param props - to setup submission detail. {@link FormProps}
*
* @returns form component or headless render prop.
*
* @example
* ```tsx
* function App() {
*   const { control, formState: { errors } } = useForm();
*
*   return (
*     <Form action="/api" control={control}>
*       <input {...register("name")} />
*       <p>{errors?.root?.server && 'Server error'}</p>
*       <button>Submit</button>
*     </Form>
*   );
* }
* ```
*/
function Form(props) {
	const methods = useFormContext();
	const [mounted, setMounted] = import_react.useState(false);
	const { control = methods.control, onSubmit = noop, children, action, method = POST_REQUEST, headers, encType, onError = noop, render, onSuccess = noop, validateStatus = defaultValidateStatus, ...rest } = props;
	const handleSubmit = import_react.useMemo(() => {
		return control.handleSubmit(async (data, event) => {
			const formData = jsonToFormData(data);
			const formDataJson = safeJSONStringify(data);
			if (onSubmit) await onSubmit({
				data,
				event,
				method,
				formData,
				formDataJson
			});
			if (isString(action)) try {
				const shouldStringifySubmissionData = headers && headers["Content-Type"] && headers["Content-Type"].includes("json") || encType && encType.includes("json");
				const response = await fetch(action, {
					method,
					headers: {
						...headers,
						...encType && encType !== "multipart/form-data" && { "Content-Type": encType }
					},
					body: shouldStringifySubmissionData ? formDataJson : formData
				});
				if (response && !validateStatus(response.status)) {
					onError({ response });
					return { type: String(response.status) };
				} else onSuccess({ response });
			} catch (error) {
				onError({ error });
				return { type: "" };
			}
			if (isFunction(action)) try {
				await action(formData);
			} catch (error) {
				onError({ error });
				return { type: "" };
			}
		});
	}, [
		control,
		onSubmit,
		method,
		action,
		headers,
		encType,
		validateStatus,
		onError,
		onSuccess
	]);
	const submit = import_react.useCallback(async (event) => {
		const err = await handleSubmit(event);
		if (err && control) {
			control._subjects.state.next({ isSubmitSuccessful: false });
			control.setError("root.server", err);
		}
	}, [handleSubmit, control]);
	import_react.useEffect(() => {
		setMounted(true);
	}, []);
	if (render) return render({ submit });
	return import_react.createElement("form", {
		noValidate: mounted,
		action,
		...!isFunction(action) && {
			method,
			encType
		},
		onSubmit: submit,
		...rest
	}, children);
}
var FormState = ({ control, disabled, exact, name, render }) => render(useFormState({
	control,
	name,
	disabled,
	exact
}));
/** @deprecated Use `FormState` instead. Kept as an alias for backward compatibility. */
var FormStateSubscribe = FormState;
var createSubject = () => {
	let _observers = [];
	const next = (value) => {
		for (const observer of _observers) observer.next && observer.next(value);
	};
	const subscribe = (observer) => {
		_observers.push(observer);
		return { unsubscribe: () => {
			_observers = _observers.filter((o) => o !== observer);
		} };
	};
	const unsubscribe = () => {
		_observers = [];
	};
	return {
		get observers() {
			return _observers;
		},
		next,
		subscribe,
		unsubscribe
	};
};
function extractFormValues(fieldsState, formValues) {
	const values = {};
	for (const key in fieldsState) if (fieldsState.hasOwnProperty(key)) {
		const fieldState = fieldsState[key];
		const fieldValue = formValues[key];
		if (fieldState && isObject(fieldState) && fieldValue) {
			const nestedFieldsState = extractFormValues(fieldState, fieldValue);
			if (isObject(nestedFieldsState)) values[key] = nestedFieldsState;
		} else if (fieldsState[key]) values[key] = fieldValue;
	}
	return values;
}
var isMultipleSelect = (element) => element.type === `select-multiple`;
var isRadioOrCheckbox = (ref) => isRadioInput(ref) || isCheckBoxInput(ref);
var live = (ref) => isHTMLElement(ref) && ref.isConnected;
function isDirtyContainer(value) {
	return Array.isArray(value) || isObject(value);
}
function collectDirtyFieldNames(dirtyTree, cachedDirtyFields, prefix = "", names = []) {
	for (const key in dirtyTree) {
		const path = prefix ? `${prefix}.${key}` : key;
		const value = dirtyTree[key];
		if (isDirtyContainer(value) && isDirtyContainer(get(cachedDirtyFields, path))) collectDirtyFieldNames(value, cachedDirtyFields, path, names);
		else names.push(path);
	}
	return names;
}
var objectHasFunction = (data) => {
	for (const key in data) if (isFunction(data[key])) return true;
	return false;
};
function isTraversable(value) {
	return Array.isArray(value) || isObject(value) && !objectHasFunction(value);
}
function isRegisteredLeaf(fieldRef) {
	return !!(fieldRef && "_f" in fieldRef);
}
function isEmptyDirtyContainer(value) {
	return Array.isArray(value) ? !value.some((item) => !isUndefined(item)) : !Object.keys(value).length;
}
function clearDirtyField(container, key) {
	if (Array.isArray(container)) container[key] = void 0;
	else delete container[key];
}
function markFieldsDirty(data, fields = {}, fieldRefs) {
	for (const key in data) {
		const value = data[key];
		const fieldRef = fieldRefs && fieldRefs[key];
		if (isTraversable(value) && (!Array.isArray(value) || !isRegisteredLeaf(fieldRef))) {
			fields[key] = Array.isArray(value) ? [] : {};
			markFieldsDirty(value, fields[key], fieldRef);
			if (isEmptyDirtyContainer(fields[key])) clearDirtyField(fields, key);
		} else if (!isUndefined(value)) fields[key] = true;
	}
	return fields;
}
function getDirtyFields(data, formValues, dirtyFieldsFromValues, fieldRefs) {
	if (!dirtyFieldsFromValues) dirtyFieldsFromValues = markFieldsDirty(formValues, {}, fieldRefs);
	for (const key in data) {
		const value = data[key];
		const fieldRef = fieldRefs && fieldRefs[key];
		if (isTraversable(value) && (!Array.isArray(value) || !isRegisteredLeaf(fieldRef))) {
			if (isUndefined(formValues) || isPrimitive(dirtyFieldsFromValues[key])) dirtyFieldsFromValues[key] = markFieldsDirty(value, Array.isArray(value) ? [] : {}, fieldRef);
			else getDirtyFields(value, isNullOrUndefined(formValues) ? {} : formValues[key], dirtyFieldsFromValues[key], fieldRef);
			if (isEmptyDirtyContainer(dirtyFieldsFromValues[key])) clearDirtyField(dirtyFieldsFromValues, key);
		} else if (deepEqual(value, formValues[key])) clearDirtyField(dirtyFieldsFromValues, key);
		else dirtyFieldsFromValues[key] = true;
	}
	return dirtyFieldsFromValues;
}
var getFieldValueAs = (value, { valueAsNumber, valueAsDate, setValueAs }) => isUndefined(value) ? value : valueAsNumber ? value === "" ? NaN : value ? +value : value : valueAsDate && isString(value) ? new Date(value) : setValueAs ? setValueAs(value) : value;
function getFieldValue(_f) {
	const ref = _f.ref;
	if (isFileInput(ref)) return ref.files;
	if (isRadioInput(ref)) return getRadioValue(_f.refs).value;
	if (isMultipleSelect(ref)) return [...ref.selectedOptions].map(({ value }) => value);
	if (isCheckBoxInput(ref)) return getCheckboxValue(_f.refs).value;
	return getFieldValueAs(ref.value, _f);
}
var getResolverOptions = (fieldsNames, _fields, criteriaMode, shouldUseNativeValidation) => {
	const fields = {};
	for (const name of fieldsNames) {
		const field = get(_fields, name);
		field && set(fields, name, field._f);
	}
	return {
		criteriaMode,
		names: [...fieldsNames],
		fields,
		shouldUseNativeValidation
	};
};
var getRuleValue = (rule) => isUndefined(rule) ? rule : isRegex(rule) ? rule.source : isObject(rule) ? isRegex(rule.value) ? rule.value.source : rule.value : rule;
var ASYNC_FUNCTION = "AsyncFunction";
var hasPromiseValidation = (fieldReference) => {
	if (!fieldReference || !fieldReference.validate) return false;
	if (isFunction(fieldReference.validate)) return fieldReference.validate.constructor.name === ASYNC_FUNCTION;
	if (isObject(fieldReference.validate)) {
		for (const key in fieldReference.validate) if (fieldReference.validate[key].constructor.name === ASYNC_FUNCTION) return true;
	}
	return false;
};
var hasValidation = (options) => options.mount && (options.required || options.min || options.max || options.maxLength || options.minLength || options.pattern || options.validate);
function schemaErrorLookup(errors, _fields, name) {
	const error = get(errors, name);
	if (error || isKey(name)) return {
		error,
		name
	};
	const names = name.split(".");
	while (names.length) {
		const fieldName = names.join(".");
		const field = get(_fields, fieldName);
		const foundError = get(errors, fieldName);
		if (field && !Array.isArray(field) && name !== fieldName) return { name };
		if (foundError && foundError.type) return {
			name: fieldName,
			error: foundError
		};
		if (foundError && foundError.root && foundError.root.type) return {
			name: `${fieldName}.root`,
			error: foundError.root
		};
		names.pop();
	}
	return { name };
}
var shouldRenderFormState = (formStateData, _proxyFormState, updateFormState, isRoot) => {
	updateFormState(formStateData);
	const keys = Object.keys(formStateData).filter((key) => key !== "name");
	return !keys.length || isRoot && keys.length >= Object.keys(_proxyFormState).length || keys.find((key) => _proxyFormState[key] === (!isRoot || VALIDATION_MODE.all));
};
var shouldSubscribeByName = (name, signalName, exact) => !name || !signalName || name === signalName || convertToArrayPayload(name).some((currentName) => currentName && (exact ? currentName === signalName || currentName.startsWith(signalName + ".") : currentName.startsWith(signalName) || signalName.startsWith(currentName)));
var skipValidation = (isBlurEvent, isTouched, isSubmitted, reValidateMode, mode) => {
	if (mode.isOnAll) return false;
	else if (!isSubmitted && mode.isOnTouch) return !(isTouched || isBlurEvent);
	else if (isSubmitted ? reValidateMode.isOnBlur : mode.isOnBlur) return !isBlurEvent;
	else if (isSubmitted ? reValidateMode.isOnChange : mode.isOnChange) return isBlurEvent;
	return true;
};
var unsetEmptyArray = (ref, name) => {
	const array = get(ref, name);
	!compact(array).length && !(array !== null && array !== void 0 && array.root) && unset(ref, name);
};
var defaultOptions = {
	mode: VALIDATION_MODE.onSubmit,
	reValidateMode: VALIDATION_MODE.onChange,
	shouldFocusError: true
};
var FORM_ERROR_TYPE = "form";
var updateDirtyFields = (dirtyFields, nextDirtyFields) => {
	for (const key in dirtyFields) if (!(key in nextDirtyFields)) delete dirtyFields[key];
	Object.assign(dirtyFields, nextDirtyFields);
};
var DEFAULT_FORM_STATE = {
	submitCount: 0,
	isDirty: false,
	isReady: false,
	isValidating: false,
	isSubmitted: false,
	isSubmitting: false,
	isSubmitSuccessful: false,
	isValid: false,
	touchedFields: {},
	dirtyFields: {},
	validatingFields: {}
};
function createFormControl(props = {}) {
	let _options = {
		...defaultOptions,
		...props
	};
	let _formState = {
		...cloneObject(DEFAULT_FORM_STATE),
		isLoading: isFunction(_options.defaultValues),
		errors: _options.errors || {},
		disabled: _options.disabled || false
	};
	let _fields = {};
	let _defaultValues = isObject(_options.defaultValues) || isObject(_options.values) ? cloneObject(_options.defaultValues || _options.values) || {} : {};
	let _formValues = _options.shouldUnregister ? {} : cloneObject(_defaultValues);
	let _state = {
		action: false,
		actionArrayLengths: /* @__PURE__ */ new Map(),
		mount: false,
		watch: false,
		keepIsValid: false
	};
	let _names = {
		mount: /* @__PURE__ */ new Set(),
		disabled: /* @__PURE__ */ new Set(),
		unMount: /* @__PURE__ */ new Set(),
		array: /* @__PURE__ */ new Set(),
		watch: /* @__PURE__ */ new Set(),
		registerName: /* @__PURE__ */ new Set()
	};
	const delayErrorCallbacks = {};
	const timers = {};
	let _valuesSubscriberCount = 0;
	let _validationModeBeforeSubmit = getValidationModes(_options.mode);
	let _validationModeAfterSubmit = getValidationModes(_options.reValidateMode);
	const defaultProxyFormState = {
		isDirty: false,
		dirtyFields: false,
		validatingFields: false,
		touchedFields: false,
		isValidating: false,
		isValid: false,
		errors: false
	};
	const _proxyFormState = { ...defaultProxyFormState };
	let _proxySubscribeFormState = { ..._proxyFormState };
	const _subjects = {
		array: createSubject(),
		state: createSubject()
	};
	let _setValidCallId = 0;
	const shouldDisplayAllAssociatedErrors = _options.criteriaMode === VALIDATION_MODE.all;
	const debounce = (name, callback) => (wait) => {
		clearTimeout(timers[name]);
		timers[name] = setTimeout(callback, wait);
	};
	const _setValid = async (shouldUpdateValid) => {
		if (_state.keepIsValid) return;
		if (!_options.disabled && (_proxyFormState.isValid || _proxySubscribeFormState.isValid || shouldUpdateValid)) {
			const callId = ++_setValidCallId;
			let isValid;
			if (_options.resolver) {
				isValid = isEmptyObject((await _runSchema()).errors);
				callId === _setValidCallId && _updateIsValidating();
			} else isValid = await executeBuiltInValidation({
				fields: _fields,
				onlyCheckValid: true,
				eventType: EVENTS.VALID
			});
			if (callId === _setValidCallId && isValid !== _formState.isValid) _subjects.state.next({ isValid });
		}
	};
	const _updateIsValidating = (names, isValidating) => {
		if (!_options.disabled && (_proxyFormState.isValidating || _proxyFormState.validatingFields || _proxySubscribeFormState.isValidating || _proxySubscribeFormState.validatingFields)) {
			(names || Array.from(_names.mount)).forEach((name) => {
				if (name) isValidating ? set(_formState.validatingFields, name, isValidating) : unset(_formState.validatingFields, name);
			});
			_subjects.state.next({
				validatingFields: _formState.validatingFields,
				isValidating: !isEmptyObject(_formState.validatingFields)
			});
		}
	};
	const _updateDirtyFields = () => {
		_formState.dirtyFields = getDirtyFields(_defaultValues, _formValues, void 0, _fields);
	};
	const _setFieldArray = (name, values = [], method, args, shouldSetValues = true, shouldUpdateFieldsAndState = true) => {
		if (args && method && !_options.disabled) {
			_state.action = true;
			if (!_state.actionArrayLengths.has(name)) {
				const preActionFields = get(_fields, name);
				_state.actionArrayLengths.set(name, Array.isArray(preActionFields) ? preActionFields.length : 0);
			}
			if (shouldUpdateFieldsAndState && Array.isArray(get(_fields, name))) {
				const fieldValues = method(get(_fields, name), args.argA, args.argB);
				shouldSetValues && set(_fields, name, fieldValues);
			}
			if (shouldUpdateFieldsAndState && Array.isArray(get(_formState.errors, name))) {
				const fieldArrayErrors = get(_formState.errors, name);
				const rootError = fieldArrayErrors.root;
				const errors = method(fieldArrayErrors, args.argA, args.argB) || fieldArrayErrors;
				if (rootError) errors.root = rootError;
				shouldSetValues && set(_formState.errors, name, errors);
				unsetEmptyArray(_formState.errors, name);
			}
			if ((_proxyFormState.touchedFields || _proxySubscribeFormState.touchedFields) && shouldUpdateFieldsAndState && Array.isArray(get(_formState.touchedFields, name))) {
				const touchedFields = method(get(_formState.touchedFields, name), args.argA, args.argB);
				shouldSetValues && set(_formState.touchedFields, name, touchedFields);
			}
			if (_proxyFormState.dirtyFields || _proxySubscribeFormState.dirtyFields) _updateDirtyFields();
			_subjects.state.next({
				name,
				isDirty: _getDirty(name, values),
				dirtyFields: _formState.dirtyFields,
				errors: _formState.errors,
				isValid: _formState.isValid
			});
		} else set(_formValues, name, values);
	};
	const updateErrors = (name, error) => {
		set(_formState.errors, name, error);
		_formState.errors = { ..._formState.errors };
		_subjects.state.next({ errors: _formState.errors });
	};
	const _setErrors = (errors) => {
		_formState.errors = errors;
		_subjects.state.next({
			errors: _formState.errors,
			isValid: false
		});
	};
	const hasExplicitNullIntermediate = (name) => {
		const segments = isKey(name) ? [name] : stringToPath(name);
		let formValues = _formValues;
		let defaultValues = _defaultValues;
		for (let i = 0; i < segments.length - 1; i++) {
			const key = segments[i];
			formValues = isNullOrUndefined(formValues) ? formValues : formValues[key];
			defaultValues = isNullOrUndefined(defaultValues) ? defaultValues : defaultValues[key];
			if (formValues === null && defaultValues !== null) return true;
		}
		return false;
	};
	const isStaleArrayIndex = (name) => {
		if (!_state.actionArrayLengths.size) return false;
		const segments = isKey(name) ? [name] : stringToPath(name);
		let node = _formValues;
		let path = "";
		let ownerDepth = -1;
		let ownerPreActionLength = 0;
		for (let i = 0; i < segments.length; i++) {
			if (isNullOrUndefined(node)) return false;
			const key = segments[i];
			path = path ? `${path}.${key}` : key;
			if (Array.isArray(node) && +key >= node.length) return ownerDepth === -1 ? false : i === ownerDepth ? +key < ownerPreActionLength : true;
			if (_state.actionArrayLengths.has(path)) {
				ownerDepth = i + 1;
				ownerPreActionLength = _state.actionArrayLengths.get(path);
			}
			node = node[key];
		}
		return false;
	};
	const updateValidAndValue = (name, shouldSkipSetValueAs, value, ref) => {
		const field = get(_fields, name);
		if (field) {
			if (hasExplicitNullIntermediate(name) || isStaleArrayIndex(name)) return;
			const wasUnsetInFormValues = isUndefined(get(_formValues, name));
			const defaultValue = get(_formValues, name, isUndefined(value) ? get(_defaultValues, name) : value);
			isUndefined(defaultValue) || ref && ref.defaultChecked || shouldSkipSetValueAs ? set(_formValues, name, shouldSkipSetValueAs ? defaultValue : getFieldValue(field._f)) : setFieldValue(name, defaultValue);
			if (_state.mount && !_state.action) {
				_setValid();
				if (wasUnsetInFormValues && _formState.isDirty && (_proxyFormState.isDirty || _proxySubscribeFormState.isDirty)) {
					if (!_getDirty()) {
						_formState.isDirty = false;
						_subjects.state.next({ ..._formState });
					}
				}
				if (props.shouldUnregister && wasUnsetInFormValues && !isUndefined(get(_formValues, name)) && isWatched(name, _names)) _state.watch = true;
			}
		}
	};
	const updateTouchAndDirty = (name, fieldValue, isBlurEvent, shouldDirty, shouldRender) => {
		let shouldUpdateField = false;
		let isPreviousDirty = false;
		const output = { name };
		if (!_options.disabled || shouldDirty === true) {
			if (!isBlurEvent || shouldDirty) {
				const isCurrentFieldPristine = deepEqual(get(_defaultValues, name), fieldValue);
				if (_proxyFormState.isDirty || _proxySubscribeFormState.isDirty) {
					isPreviousDirty = _formState.isDirty;
					_formState.isDirty = output.isDirty = !isCurrentFieldPristine || _getDirty();
					shouldUpdateField = isPreviousDirty !== output.isDirty;
				}
				isPreviousDirty = !!get(_formState.dirtyFields, name);
				if (isCurrentFieldPristine !== _formState.isDirty) updateDirtyFields(_formState.dirtyFields, getDirtyFields(_defaultValues, _formValues, void 0, _fields));
				else isCurrentFieldPristine ? unset(_formState.dirtyFields, name) : set(_formState.dirtyFields, name, true);
				output.dirtyFields = _formState.dirtyFields;
				shouldUpdateField = shouldUpdateField || (_proxyFormState.dirtyFields || _proxySubscribeFormState.dirtyFields) && isPreviousDirty !== !isCurrentFieldPristine;
			}
			if (isBlurEvent) {
				const isPreviousFieldTouched = get(_formState.touchedFields, name);
				if (!isPreviousFieldTouched) {
					set(_formState.touchedFields, name, isBlurEvent);
					output.touchedFields = _formState.touchedFields;
					shouldUpdateField = shouldUpdateField || (_proxyFormState.touchedFields || _proxySubscribeFormState.touchedFields) && isPreviousFieldTouched !== isBlurEvent;
				}
			}
			shouldUpdateField && shouldRender && _subjects.state.next(output);
		}
		return shouldUpdateField ? output : {};
	};
	const shouldRenderByError = (name, isValid, error, fieldState) => {
		const previousFieldError = get(_formState.errors, name);
		const shouldUpdateValid = (_proxyFormState.isValid || _proxySubscribeFormState.isValid) && isBoolean(isValid) && _formState.isValid !== isValid;
		if (_options.delayError && error) {
			delayErrorCallbacks[name] = debounce(name, () => updateErrors(name, error));
			delayErrorCallbacks[name](_options.delayError);
		} else {
			clearTimeout(timers[name]);
			delete delayErrorCallbacks[name];
			error ? set(_formState.errors, name, error) : unset(_formState.errors, name);
			_formState.errors = { ..._formState.errors };
		}
		if ((error ? !deepEqual(previousFieldError, error) : previousFieldError) || !isEmptyObject(fieldState) || shouldUpdateValid) {
			const updatedFormState = {
				...fieldState,
				...shouldUpdateValid && isBoolean(isValid) ? { isValid } : {},
				errors: _formState.errors,
				name
			};
			_formState = {
				..._formState,
				...updatedFormState
			};
			_subjects.state.next(updatedFormState);
		}
	};
	const _runSchema = async (name) => {
		_updateIsValidating(name, true);
		return await _options.resolver(_formValues, _options.context, getResolverOptions(name || _names.mount, _fields, _options.criteriaMode, _options.shouldUseNativeValidation));
	};
	const executeSchemaAndUpdateState = async (names) => {
		const { errors } = await _runSchema(names);
		_updateIsValidating(names);
		if (names) {
			for (const name of names) {
				const error = get(errors, name);
				error ? _names.array.has(name) && isObject(error) && !Object.keys(error).some((key) => !Number.isNaN(Number(key))) ? updateFieldArrayRootError(_formState.errors, { [name]: error }, name) : set(_formState.errors, name, error) : unset(_formState.errors, name);
			}
			_formState.errors = { ..._formState.errors };
		} else _formState.errors = errors;
		return errors;
	};
	const validateForm = async ({ name, eventType }) => {
		if (props.validate) {
			const result = await props.validate({
				formValues: _formValues,
				formState: _formState,
				name,
				eventType
			});
			if (isObject(result)) for (const key in result) {
				const error = result[key];
				if (error) setError(`${FORM_ERROR_TYPE}.${key}`, {
					message: isString(error.message) ? error.message : "",
					type: error.type || INPUT_VALIDATION_RULES.validate
				});
			}
			else if (isString(result) || !result) setError(FORM_ERROR_TYPE, {
				message: result || "",
				type: INPUT_VALIDATION_RULES.validate
			});
			else clearErrors(FORM_ERROR_TYPE);
			return result;
		}
		return true;
	};
	const executeBuiltInValidation = async ({ fields, onlyCheckValid, name, eventType, context = {
		valid: true,
		runRootValidation: false
	} }) => {
		if (props.validate) {
			context.runRootValidation = true;
			if (!await validateForm({
				name,
				eventType
			})) {
				context.valid = false;
				if (onlyCheckValid) return context.valid;
			}
		}
		for (const name in fields) {
			const field = fields[name];
			if (field) {
				const { _f, ...fieldValue } = field;
				if (_f) {
					const isFieldArrayRoot = _names.array.has(_f.name);
					const isPromiseFunction = field._f && hasPromiseValidation(field._f);
					const shouldTrackIsValidatingState = _proxyFormState.validatingFields || _proxyFormState.isValidating || _proxySubscribeFormState.validatingFields || _proxySubscribeFormState.isValidating;
					if (isPromiseFunction && shouldTrackIsValidatingState) _updateIsValidating([_f.name], true);
					const fieldError = await validateField(field, _names.disabled, _formValues, shouldDisplayAllAssociatedErrors, _options.shouldUseNativeValidation && !onlyCheckValid, isFieldArrayRoot);
					if (isPromiseFunction && shouldTrackIsValidatingState) _updateIsValidating([_f.name]);
					if (fieldError[_f.name]) {
						context.valid = false;
						if (onlyCheckValid) break;
					}
					!onlyCheckValid && (get(fieldError, _f.name) ? isFieldArrayRoot ? updateFieldArrayRootError(_formState.errors, fieldError, _f.name) : set(_formState.errors, _f.name, fieldError[_f.name]) : unset(_formState.errors, _f.name));
					if (props.shouldUseNativeValidation && fieldError[_f.name]) break;
				}
				!isEmptyObject(fieldValue) && await executeBuiltInValidation({
					context,
					onlyCheckValid,
					fields: fieldValue,
					name,
					eventType
				});
			}
		}
		return context.valid;
	};
	const _removeUnmounted = () => {
		for (const name of _names.unMount) {
			const field = get(_fields, name);
			field && (field._f.refs ? field._f.refs.every((ref) => !live(ref)) : !live(field._f.ref)) && unregister(name);
		}
		_names.unMount = /* @__PURE__ */ new Set();
	};
	const _getDirty = (name, data) => (name && data && set(_formValues, name, data), !deepEqual(_state.mount ? _formValues : _defaultValues, _defaultValues));
	const _getWatch = (names, defaultValue, isGlobal) => generateWatchOutput(names, _names, { ..._state.mount ? _formValues : isUndefined(defaultValue) || isString(names) ? _defaultValues : defaultValue }, isGlobal, defaultValue);
	const _getFieldArray = (name) => compact(get(_state.mount ? _formValues : _defaultValues, name, _options.shouldUnregister ? get(_defaultValues, name, []) : []));
	const setFieldValue = (name, value, options = {}, skipClone = false, skipRender = false, skipValueRender = false) => {
		const field = get(_fields, name);
		let fieldValue = value;
		if (field) {
			const fieldReference = field._f;
			if (fieldReference) {
				!fieldReference.disabled && set(_formValues, name, getFieldValueAs(value, fieldReference));
				fieldValue = isHTMLElement(fieldReference.ref) && isNullOrUndefined(value) ? "" : value;
				if (isMultipleSelect(fieldReference.ref)) [...fieldReference.ref.options].forEach((optionRef) => optionRef.selected = fieldValue.includes(optionRef.value));
				else if (fieldReference.refs) {
					if (isCheckBoxInput(fieldReference.ref)) fieldReference.refs.forEach((checkboxRef) => {
						if (!checkboxRef.defaultChecked || !checkboxRef.disabled) {
							if (Array.isArray(fieldValue)) checkboxRef.checked = !!fieldValue.find((data) => data === checkboxRef.value);
							else checkboxRef.checked = fieldValue === checkboxRef.value || !!fieldValue;
						}
					});
					else fieldReference.refs.forEach((radioRef) => radioRef.checked = radioRef.value === fieldValue);
				} else if (isFileInput(fieldReference.ref)) fieldReference.ref.value = "";
				else {
					fieldReference.ref.value = fieldValue;
					if (!fieldReference.ref.type && !skipRender && !skipValueRender) _subjects.state.next({
						name,
						values: skipClone ? _formValues : cloneObject(_formValues)
					});
				}
			}
		}
		(options.shouldDirty || options.shouldTouch) && updateTouchAndDirty(name, fieldValue, options.shouldTouch, options.shouldDirty, !skipRender);
		options.shouldValidate && trigger(name, { delayError: options.delayError });
	};
	const setFieldValues = (name, value, options, skipClone = false, skipRender = false, skipValueRender = false) => {
		if (_names.array.has(name)) _subjects.array.next({
			name,
			values: skipClone ? _formValues : cloneObject(_formValues)
		});
		for (const fieldKey in value) {
			if (!value.hasOwnProperty(fieldKey)) return;
			const fieldValue = value[fieldKey];
			const fieldName = name + "." + fieldKey;
			const field = get(_fields, fieldName);
			(_names.array.has(name) || isObject(fieldValue) || field && !field._f) && !isDateObject(fieldValue) ? setFieldValues(fieldName, fieldValue, options, skipClone, skipRender, skipValueRender) : setFieldValue(fieldName, fieldValue, options, skipClone, skipRender, skipValueRender);
		}
	};
	const _setValue = (name, value, options, skipClone, skipStateEmit = false) => {
		const field = get(_fields, name);
		const isFieldArray = _names.array.has(name);
		const cloneValue = skipClone ? value : cloneObject(value);
		const isValueUnchanged = deepEqual(get(_formValues, name), cloneValue);
		if (!isValueUnchanged) set(_formValues, name, cloneValue);
		if (isFieldArray) {
			_subjects.array.next({
				name,
				values: skipClone ? _formValues : cloneObject(_formValues)
			});
			if ((_proxyFormState.isDirty || _proxyFormState.dirtyFields || _proxySubscribeFormState.isDirty || _proxySubscribeFormState.dirtyFields) && options.shouldDirty) {
				_updateDirtyFields();
				if (!skipStateEmit) _subjects.state.next({
					name,
					dirtyFields: _formState.dirtyFields,
					isDirty: _getDirty(name, cloneValue)
				});
			}
		} else {
			const isEmpty = Array.isArray(cloneValue) && !cloneValue.length || isEmptyObject(cloneValue);
			const skipValueRender = !isValueUnchanged && !skipStateEmit;
			if (!field || field._f || isNullOrUndefined(cloneValue) || isEmpty) setFieldValue(name, cloneValue, options, skipClone, skipStateEmit, skipValueRender);
			else setFieldValues(name, cloneValue, options, skipClone, skipStateEmit, skipValueRender);
		}
		if (!isValueUnchanged && !skipStateEmit) {
			const watched = isWatched(name, _names);
			const values = skipClone ? _formValues : cloneObject(_formValues);
			_subjects.state.next({
				...watched && _formState,
				name: _state.mount || watched ? name : void 0,
				values
			});
		}
	};
	const setValue = (name, value, options = {}) => _setValue(name, value, options, false);
	const setValues = (formValues, options = {}) => {
		const updatedFormValues = isFunction(formValues) ? formValues(_formValues) : formValues;
		if (!deepEqual(_formValues, updatedFormValues)) {
			_formValues = {
				..._formValues,
				...updatedFormValues
			};
			const flattenedUpdates = flatten(updatedFormValues);
			for (const fieldName of _names.mount) if (fieldName in flattenedUpdates) _setValue(fieldName, flattenedUpdates[fieldName], options, true, true);
			_subjects.state.next({
				..._formState,
				name: void 0,
				type: void 0,
				..._valuesSubscriberCount ? { values: _formValues } : {}
			});
			if (options.shouldValidate) _setValid();
		}
	};
	const onChange = async (event) => {
		_state.mount = true;
		const target = event.target;
		let name = target.name;
		let isFieldValueUpdated = true;
		const field = get(_fields, name);
		const _updateIsFieldValueUpdated = (fieldValue) => {
			isFieldValueUpdated = Number.isNaN(fieldValue) || isDateObject(fieldValue) && isNaN(fieldValue.getTime()) || deepEqual(fieldValue, get(_formValues, name, fieldValue));
		};
		if (field) {
			let error;
			let isValid;
			const fieldValue = target.type ? getFieldValue(field._f) : getEventValue(event);
			const isBlurEvent = event.type === EVENTS.BLUR || event.type === EVENTS.FOCUS_OUT;
			const hasNoValidationEffect = !hasValidation(field._f) && !props.validate && !_options.resolver && !get(_formState.errors, name) && !field._f.deps;
			const shouldSkipValidation = hasNoValidationEffect || skipValidation(isBlurEvent, get(_formState.touchedFields, name), _formState.isSubmitted, _validationModeAfterSubmit, _validationModeBeforeSubmit);
			const watched = isWatched(name, _names, isBlurEvent);
			set(_formValues, name, fieldValue);
			if (isBlurEvent) {
				if (!target || !target.readOnly) {
					field._f.onBlur && field._f.onBlur(event);
					const pendingDelayError = delayErrorCallbacks[name];
					pendingDelayError && pendingDelayError(0);
				}
			} else if (field._f.onChange) field._f.onChange(event);
			const fieldState = updateTouchAndDirty(name, fieldValue, isBlurEvent);
			const shouldRender = !isEmptyObject(fieldState) || watched;
			!isBlurEvent && _subjects.state.next({
				name,
				type: event.type,
				..._valuesSubscriberCount ? { values: cloneObject(_formValues) } : {}
			});
			if (shouldSkipValidation) {
				if ((!hasNoValidationEffect || !_formState.isValid) && (_proxyFormState.isValid || _proxySubscribeFormState.isValid)) {
					if (_options.mode === "onBlur") {
						if (isBlurEvent) _setValid();
					} else if (!isBlurEvent) _setValid();
				}
				return shouldRender && _subjects.state.next({
					name,
					...watched ? {} : fieldState
				});
			}
			if (!_options.resolver && props.validate) await validateForm({
				name,
				eventType: event.type
			});
			!isBlurEvent && watched && _subjects.state.next({ ..._formState });
			if (_options.resolver) {
				const { errors } = await _runSchema([name]);
				_updateIsValidating([name]);
				_updateIsFieldValueUpdated(fieldValue);
				if (!isFieldValueUpdated) {
					!isEmptyObject(fieldState) && _subjects.state.next(fieldState);
					return;
				}
				const previousErrorLookupResult = schemaErrorLookup(_formState.errors, _fields, name);
				const errorLookupResult = schemaErrorLookup(errors, _fields, previousErrorLookupResult.name || name);
				error = errorLookupResult.error;
				name = errorLookupResult.name;
				isValid = isEmptyObject(errors);
			} else {
				_updateIsValidating([name], true);
				error = (await validateField(field, _names.disabled, _formValues, shouldDisplayAllAssociatedErrors, _options.shouldUseNativeValidation))[name];
				_updateIsValidating([name]);
				_updateIsFieldValueUpdated(fieldValue);
				if (isFieldValueUpdated) {
					if (error) isValid = false;
					else if (_proxyFormState.isValid || _proxySubscribeFormState.isValid) isValid = await executeBuiltInValidation({
						fields: _fields,
						onlyCheckValid: true,
						name,
						eventType: event.type
					});
				}
			}
			if (isFieldValueUpdated) {
				field._f.deps && (!Array.isArray(field._f.deps) || field._f.deps.length > 0) && trigger(field._f.deps);
				shouldRenderByError(name, isValid, error, fieldState);
			}
		}
	};
	const _focusInput = (ref, key) => {
		if (get(_formState.errors, key) && ref.focus) {
			ref.focus();
			return 1;
		}
	};
	const trigger = async (name, options = {}) => {
		let isValid;
		let validationResult;
		const fieldNames = convertToArrayPayload(name);
		if (_options.resolver) {
			const errors = await executeSchemaAndUpdateState(isUndefined(name) ? name : fieldNames);
			isValid = isEmptyObject(errors);
			validationResult = name ? !fieldNames.some((name) => get(errors, name)) : isValid;
		} else if (name) {
			validationResult = (await Promise.all(fieldNames.map(async (fieldName) => {
				const field = get(_fields, fieldName);
				return await executeBuiltInValidation({
					fields: field && field._f ? { [fieldName]: field } : field,
					eventType: EVENTS.TRIGGER
				});
			}))).every(Boolean);
			!(!validationResult && !_formState.isValid) && _setValid();
		} else validationResult = isValid = await executeBuiltInValidation({
			fields: _fields,
			name,
			eventType: EVENTS.TRIGGER
		});
		if (options.delayError && _options.delayError && isString(name)) {
			const error = get(_formState.errors, name);
			if (error) {
				unset(_formState.errors, name);
				delayErrorCallbacks[name] = debounce(name, () => updateErrors(name, error));
				delayErrorCallbacks[name](_options.delayError);
			} else {
				clearTimeout(timers[name]);
				delete delayErrorCallbacks[name];
			}
		}
		_subjects.state.next({
			...!isString(name) || (_proxyFormState.isValid || _proxySubscribeFormState.isValid) && isValid !== _formState.isValid ? {} : { name },
			..._options.resolver || !name ? { isValid } : {},
			errors: _formState.errors
		});
		options.shouldFocus && !validationResult && iterateFieldsByAction(_fields, _focusInput, name ? fieldNames : _names.mount);
		return validationResult;
	};
	const getValues = (fieldNames, config) => {
		let values = { ..._state.mount ? _formValues : _defaultValues };
		if (config) values = extractFormValues(config.dirtyFields ? _formState.dirtyFields : _formState.touchedFields, values);
		return isUndefined(fieldNames) ? values : isString(fieldNames) ? get(values, fieldNames) : fieldNames.map((name) => get(values, name));
	};
	const getFieldState = (name, formState) => ({
		invalid: !!get((formState || _formState).errors, name),
		isDirty: !!get((formState || _formState).dirtyFields, name),
		error: get((formState || _formState).errors, name),
		isValidating: !!get(_formState.validatingFields, name),
		isTouched: !!get((formState || _formState).touchedFields, name)
	});
	const clearErrors = (name) => {
		const names = name ? convertToArrayPayload(name) : void 0;
		names === null || names === void 0 || names.forEach((inputName) => unset(_formState.errors, inputName));
		if (names) names.forEach((inputName) => {
			_subjects.state.next({
				name: inputName,
				errors: _formState.errors
			});
		});
		else {
			_formState.errors = {};
			_subjects.state.next({ errors: _formState.errors });
		}
	};
	const setError = (name, error, options) => {
		const ref = (get(_fields, name, { _f: {} })._f || {}).ref;
		const { ref: currentRef, message, type, ...restOfErrorTree } = get(_formState.errors, name) || {};
		set(_formState.errors, name, {
			...restOfErrorTree,
			...error,
			ref
		});
		_subjects.state.next({
			name,
			errors: _formState.errors,
			isValid: false
		});
		options && options.shouldFocus && ref && ref.focus && ref.focus();
	};
	const watch = (name, defaultValue) => {
		if (isFunction(name)) {
			_valuesSubscriberCount++;
			const { unsubscribe } = _subjects.state.subscribe({ next: (payload) => "values" in payload && name(payload.values || _getWatch(void 0, defaultValue), payload) });
			let called = false;
			return { unsubscribe: () => {
				if (called) return;
				called = true;
				_valuesSubscriberCount--;
				unsubscribe();
			} };
		}
		return _getWatch(name, defaultValue, true);
	};
	const _subscribe = (props) => {
		var _a;
		const needsValues = !!((_a = props.formState) === null || _a === void 0 ? void 0 : _a.values);
		if (needsValues) _valuesSubscriberCount++;
		const { unsubscribe } = _subjects.state.subscribe({ next: (formState) => {
			if (shouldSubscribeByName(props.name, formState.name, props.exact) && shouldRenderFormState(formState, props.formState || _proxyFormState, _setFormState, props.reRenderRoot)) {
				const snapshot = { ..._formValues };
				props.callback({
					values: snapshot,
					..._formState,
					...formState,
					defaultValues: _defaultValues
				});
			}
		} });
		if (!needsValues) return unsubscribe;
		let called = false;
		return () => {
			if (called) return;
			called = true;
			_valuesSubscriberCount--;
			unsubscribe();
		};
	};
	const subscribe = (props) => {
		_state.mount = true;
		_proxySubscribeFormState = {
			..._proxySubscribeFormState,
			...props.formState
		};
		return _subscribe({
			...props,
			formState: {
				...defaultProxyFormState,
				...props.formState
			}
		});
	};
	const unregister = (name, options = {}) => {
		for (const fieldName of name ? convertToArrayPayload(name) : _names.mount) {
			_names.mount.delete(fieldName);
			_names.array.delete(fieldName);
			if (!options.keepValue) {
				unset(_fields, fieldName);
				unset(_formValues, fieldName);
			}
			!options.keepError && unset(_formState.errors, fieldName);
			!options.keepDirty && unset(_formState.dirtyFields, fieldName);
			!options.keepTouched && unset(_formState.touchedFields, fieldName);
			!options.keepIsValidating && unset(_formState.validatingFields, fieldName);
			!_options.shouldUnregister && !options.keepDefaultValue && unset(_defaultValues, fieldName);
		}
		_subjects.state.next({ values: cloneObject(_formValues) });
		_subjects.state.next({
			..._formState,
			...!options.keepDirty ? {} : { isDirty: _getDirty() }
		});
		!options.keepIsValid && _setValid();
	};
	const _setDisabledField = ({ disabled, name }) => {
		if (isBoolean(disabled) && _state.mount || !!disabled || _names.disabled.has(name)) {
			const disabledStateChanged = _names.disabled.has(name) !== !!disabled;
			disabled ? _names.disabled.add(name) : _names.disabled.delete(name);
			disabledStateChanged && _state.mount && !_state.action && _setValid();
		}
	};
	const register = (name, options = {}) => {
		let field = get(_fields, name);
		const disabledIsDefined = isBoolean(options.disabled) || isBoolean(_options.disabled);
		const shouldRevalidateRemount = !_names.registerName.has(name) && field && field._f && !field._f.mount;
		set(_fields, name, {
			...field || {},
			_f: {
				...field && field._f ? field._f : { ref: { name } },
				name,
				mount: true,
				...options
			}
		});
		_names.mount.add(name);
		if (field && !shouldRevalidateRemount) _setDisabledField({
			disabled: isBoolean(options.disabled) ? options.disabled : _options.disabled,
			name
		});
		else updateValidAndValue(name, true, options.value);
		return {
			...disabledIsDefined ? { disabled: options.disabled || _options.disabled } : {},
			..._options.progressive ? {
				required: !!options.required,
				min: getRuleValue(options.min),
				max: getRuleValue(options.max),
				minLength: getRuleValue(options.minLength),
				maxLength: getRuleValue(options.maxLength),
				pattern: getRuleValue(options.pattern)
			} : {},
			name,
			onChange,
			onBlur: onChange,
			ref: (ref) => {
				if (ref) {
					_names.registerName.add(name);
					register(name, options);
					_names.registerName.delete(name);
					field = get(_fields, name);
					const fieldRef = isUndefined(ref.value) ? ref.querySelectorAll ? ref.querySelectorAll("input,select,textarea")[0] || ref : ref : ref;
					const radioOrCheckbox = isRadioOrCheckbox(fieldRef);
					const refs = field._f.refs || [];
					if (radioOrCheckbox ? refs.find((option) => option === fieldRef) : fieldRef === field._f.ref) return;
					const newField = { ...field._f };
					if (radioOrCheckbox) {
						newField.refs = [
							...refs.filter(live),
							fieldRef,
							...Array.isArray(get(_defaultValues, name)) ? [{}] : []
						];
						newField.ref = {
							type: fieldRef.type,
							name
						};
					} else {
						newField.ref = fieldRef;
						delete newField.refs;
					}
					set(_fields, name, { _f: newField });
					updateValidAndValue(name, false, void 0, fieldRef);
				} else {
					field = get(_fields, name, {});
					if (field._f) field._f.mount = false;
					(_options.shouldUnregister || options.shouldUnregister) && !(isNameInFieldArray(_names.array, name) && _state.action) && _names.unMount.add(name);
				}
			}
		};
	};
	const _focusError = () => _options.shouldFocusError && !_options.shouldUseNativeValidation && iterateFieldsByAction(_fields, _focusInput, _names.mount);
	const _disableForm = (disabled) => {
		if (isBoolean(disabled)) {
			_subjects.state.next({ disabled });
			iterateFieldsByAction(_fields, (ref, name) => {
				const currentField = get(_fields, name);
				if (currentField) {
					ref.disabled = currentField._f.disabled || disabled;
					if (Array.isArray(currentField._f.refs)) currentField._f.refs.forEach((inputRef) => {
						inputRef.disabled = currentField._f.disabled || disabled;
					});
				}
			}, 0, false);
		}
	};
	const handleSubmit = (onValid, onInvalid) => async (e) => {
		let result = void 0;
		let onValidError = void 0;
		if (e) {
			e.preventDefault && e.preventDefault();
			e.persist && e.persist();
		}
		let fieldValues = cloneObject(_formValues);
		_subjects.state.next({ isSubmitting: true });
		if (_options.resolver) {
			const { errors, values } = await _runSchema();
			_updateIsValidating();
			_formState.errors = errors;
			fieldValues = cloneObject(values);
		} else await executeBuiltInValidation({
			fields: _fields,
			eventType: EVENTS.SUBMIT
		});
		if (_names.disabled.size) for (const name of _names.disabled) unset(fieldValues, name);
		unset(_formState.errors, ROOT_ERROR_TYPE);
		if (isEmptyObject(_formState.errors)) {
			_subjects.state.next({ errors: {} });
			try {
				result = await onValid(fieldValues, e);
			} catch (error) {
				onValidError = error;
			}
		} else {
			if (onInvalid) await onInvalid({ ..._formState.errors }, e);
			_focusError();
			setTimeout(_focusError);
		}
		_subjects.state.next({
			isSubmitted: true,
			isSubmitting: false,
			isSubmitSuccessful: isEmptyObject(_formState.errors) && !onValidError,
			submitCount: _formState.submitCount + 1,
			errors: _formState.errors
		});
		if (onValidError) throw onValidError;
		return result;
	};
	const resetField = (name, options = {}) => {
		if (get(_fields, name)) {
			if (isUndefined(options.defaultValue)) setValue(name, cloneObject(get(_defaultValues, name)));
			else {
				setValue(name, options.defaultValue);
				set(_defaultValues, name, cloneObject(options.defaultValue));
			}
			if (!options.keepTouched) unset(_formState.touchedFields, name);
			if (!options.keepDirty) {
				unset(_formState.dirtyFields, name);
				_formState.isDirty = options.defaultValue ? _getDirty(name, cloneObject(get(_defaultValues, name))) : _getDirty();
			}
			if (!options.keepError) {
				unset(_formState.errors, name);
				_proxyFormState.isValid && _setValid();
			}
			_subjects.state.next({ ..._formState });
		}
	};
	const _reset = (formValues, keepStateOptions = {}) => {
		const updatedValues = formValues ? cloneObject(formValues) : _defaultValues;
		const cloneUpdatedValues = cloneObject(updatedValues);
		const isEmptyResetValues = isEmptyObject(formValues);
		const values = cloneUpdatedValues;
		const fieldRefs = _fields;
		if (!keepStateOptions.keepDefaultValues) _defaultValues = updatedValues;
		if (!keepStateOptions.keepValues) {
			if (keepStateOptions.keepDirtyValues) {
				const fieldsToCheck = /* @__PURE__ */ new Set([..._names.mount, ...collectDirtyFieldNames(getDirtyFields(_defaultValues, _formValues, void 0, fieldRefs), _formState.dirtyFields)]);
				for (const fieldName of Array.from(fieldsToCheck)) {
					const isDirty = get(_formState.dirtyFields, fieldName);
					const existingValue = get(_formValues, fieldName);
					const newValue = get(values, fieldName);
					if (isDirty && !isUndefined(existingValue)) set(values, fieldName, existingValue);
					else if (!isDirty && !isUndefined(newValue)) setValue(fieldName, newValue);
				}
			} else {
				if (isWeb && isUndefined(formValues)) for (const name of _names.mount) {
					const field = get(_fields, name);
					if (field && field._f) {
						const fieldReference = Array.isArray(field._f.refs) ? field._f.refs[0] : field._f.ref;
						if (isHTMLElement(fieldReference)) {
							const form = fieldReference.closest("form");
							if (form) {
								form.reset();
								break;
							}
						}
					}
				}
				if (keepStateOptions.keepFieldsRef) for (const fieldName of _names.mount) setValue(fieldName, get(values, fieldName));
				else _fields = {};
			}
			if (_options.shouldUnregister) {
				_formValues = keepStateOptions.keepDefaultValues ? cloneObject(_defaultValues) : {};
				if (keepStateOptions.keepFieldsRef) for (const fieldName of _names.mount) set(_formValues, fieldName, get(values, fieldName));
			} else _formValues = cloneObject(values);
			_subjects.array.next({ values: { ...values } });
			_subjects.state.next({
				name: void 0,
				type: void 0,
				values: { ...values }
			});
		}
		_names = {
			mount: keepStateOptions.keepDirtyValues ? _names.mount : /* @__PURE__ */ new Set(),
			unMount: /* @__PURE__ */ new Set(),
			array: /* @__PURE__ */ new Set(),
			registerName: /* @__PURE__ */ new Set(),
			disabled: /* @__PURE__ */ new Set(),
			watch: /* @__PURE__ */ new Set(),
			watchAll: false,
			focus: ""
		};
		_state.mount = !_proxyFormState.isValid || !!keepStateOptions.keepIsValid || !!keepStateOptions.keepDirtyValues || !_options.shouldUnregister && !isEmptyObject(values);
		_state.watch = !!_options.shouldUnregister;
		_state.keepIsValid = !!keepStateOptions.keepIsValid;
		_state.action = false;
		_state.actionArrayLengths.clear();
		if (!keepStateOptions.keepErrors) _formState.errors = {};
		_subjects.state.next({
			submitCount: keepStateOptions.keepSubmitCount ? _formState.submitCount : 0,
			isDirty: isEmptyResetValues ? false : keepStateOptions.keepDirty ? _formState.isDirty : keepStateOptions.keepValues ? _getDirty() : !!(keepStateOptions.keepDefaultValues && !deepEqual(formValues, _defaultValues)),
			isSubmitted: keepStateOptions.keepIsSubmitted ? _formState.isSubmitted : false,
			dirtyFields: isEmptyResetValues ? {} : keepStateOptions.keepDirtyValues ? keepStateOptions.keepDefaultValues && _formValues ? getDirtyFields(_defaultValues, _formValues, void 0, fieldRefs) : _formState.dirtyFields : keepStateOptions.keepDefaultValues && formValues ? getDirtyFields(_defaultValues, formValues, void 0, fieldRefs) : keepStateOptions.keepDirty ? _formState.dirtyFields : {},
			touchedFields: keepStateOptions.keepTouched ? _formState.touchedFields : {},
			errors: keepStateOptions.keepErrors ? _formState.errors : {},
			isSubmitSuccessful: keepStateOptions.keepIsSubmitSuccessful ? _formState.isSubmitSuccessful : false,
			isSubmitting: false,
			defaultValues: _defaultValues
		});
	};
	const reset = (formValues, keepStateOptions) => _reset(isFunction(formValues) ? formValues(_formValues) : formValues, {
		..._options.resetOptions,
		...keepStateOptions
	});
	const setFocus = (name, options = {}) => {
		const field = get(_fields, name);
		const fieldReference = field && field._f;
		if (fieldReference) {
			const fieldRef = fieldReference.refs ? fieldReference.refs[0] : fieldReference.ref;
			if (fieldRef.focus) setTimeout(() => {
				fieldRef.focus();
				options.shouldSelect && isFunction(fieldRef.select) && fieldRef.select();
			});
		}
	};
	const _setFormState = (updatedFormState) => {
		const { name, type, values, ...formState } = updatedFormState;
		_formState = {
			..._formState,
			...formState
		};
	};
	_subjects.state.subscribe({ next: _setFormState });
	const _resetDefaultValues = () => isFunction(_options.defaultValues) && _options.defaultValues().then((values) => {
		reset(values, _options.resetOptions);
		_subjects.state.next({ isLoading: false });
	});
	const resetDefaultValues = (values, options = {}) => {
		_defaultValues = cloneObject(values);
		if (!options.keepDirty) {
			const newDirtyFields = getDirtyFields(_defaultValues, _formValues, void 0, _fields);
			_formState.dirtyFields = newDirtyFields;
			_formState.isDirty = !isEmptyObject(newDirtyFields);
		}
		if (!options.keepIsValid) _setValid();
		_subjects.state.next({
			..._formState,
			defaultValues: _defaultValues
		});
	};
	const methods = {
		control: {
			register,
			unregister,
			getFieldState,
			handleSubmit,
			setError,
			_subscribe,
			_runSchema,
			_updateIsValidating,
			_focusError,
			_getWatch,
			_getDirty,
			_setValid,
			_setFieldArray,
			_setDisabledField,
			_setErrors,
			_getFieldArray,
			_reset,
			_resetDefaultValues,
			_removeUnmounted,
			_disableForm,
			_subjects,
			_proxyFormState,
			get _fields() {
				return _fields;
			},
			get _formValues() {
				return _formValues;
			},
			get _state() {
				return _state;
			},
			set _state(value) {
				_state = value;
			},
			get _defaultValues() {
				return _defaultValues;
			},
			get _names() {
				return _names;
			},
			set _names(value) {
				_names = value;
			},
			get _formState() {
				return _formState;
			},
			get _options() {
				return _options;
			},
			set _options(value) {
				_options = {
					..._options,
					...value
				};
				_validationModeBeforeSubmit = getValidationModes(_options.mode);
				_validationModeAfterSubmit = getValidationModes(_options.reValidateMode);
			}
		},
		subscribe,
		trigger,
		register,
		handleSubmit,
		watch,
		setValue,
		setValues,
		getValues,
		reset,
		resetField,
		resetDefaultValues,
		clearErrors,
		unregister,
		setError,
		setFocus,
		getFieldState
	};
	return {
		...methods,
		formControl: methods
	};
}
/**
* Custom hook to manage the entire form.
*
* @remarks
* [API](https://react-hook-form.com/docs/useform) • [Demo](https://codesandbox.io/s/react-hook-form-get-started-ts-5ksmm) • [Video](https://www.youtube.com/watch?v=RkXv4AXXC_4)
*
* @param props - form configuration and validation parameters.
*
* @returns methods - individual functions to manage the form state. {@link UseFormReturn}
*
* @example
* ```tsx
* function App() {
*   const { register, handleSubmit, watch, formState: { errors } } = useForm();
*   const onSubmit = data => console.log(data);
*
*   console.log(watch("example"));
*
*   return (
*     <form onSubmit={handleSubmit(onSubmit)}>
*       <input defaultValue="test" {...register("example")} />
*       <input {...register("exampleRequired", { required: true })} />
*       {errors.exampleRequired && <span>This field is required</span>}
*       <button>Submit</button>
*     </form>
*   );
* }
* ```
*/
function useForm(props = {}) {
	const _formControl = import_react.useRef(void 0);
	const _values = import_react.useRef(void 0);
	const _formControlProp = import_react.useRef(props.formControl);
	const [formState, updateFormState] = import_react.useState(() => ({
		...cloneObject(DEFAULT_FORM_STATE),
		isLoading: isFunction(props.defaultValues),
		errors: props.errors || {},
		disabled: props.disabled || false,
		defaultValues: isFunction(props.defaultValues) ? void 0 : props.defaultValues
	}));
	if (!_formControl.current || props.formControl && _formControlProp.current !== props.formControl) {
		_formControlProp.current = props.formControl;
		if (props.formControl) {
			_formControl.current = {
				...props.formControl,
				formState
			};
			if (props.defaultValues && !isFunction(props.defaultValues)) props.formControl.reset(props.defaultValues, props.resetOptions);
		} else {
			const { formControl, ...rest } = createFormControl(props);
			_formControl.current = {
				...rest,
				formState
			};
		}
	}
	const control = _formControl.current.control;
	control._options = props;
	const { resyncIfNeeded, snapshot } = useResyncOnReconnect();
	useIsomorphicLayoutEffect(() => {
		const getCurrentFormState = () => ({
			...control._formState,
			defaultValues: control._defaultValues
		});
		resyncIfNeeded(true, getCurrentFormState, updateFormState);
		const unsubscribe = control._subscribe({
			formState: control._proxyFormState,
			callback: () => updateFormState({
				...control._formState,
				defaultValues: control._defaultValues
			}),
			reRenderRoot: true
		});
		updateFormState((data) => ({
			...data,
			isReady: true
		}));
		control._formState.isReady = true;
		return () => {
			unsubscribe();
			snapshot(true, getCurrentFormState);
		};
	}, [
		control,
		resyncIfNeeded,
		snapshot
	]);
	import_react.useEffect(() => control._disableForm(props.disabled), [control, props.disabled]);
	import_react.useEffect(() => {
		if (props.mode) control._options.mode = props.mode;
		if (props.reValidateMode) control._options.reValidateMode = props.reValidateMode;
	}, [
		control,
		props.mode,
		props.reValidateMode
	]);
	import_react.useEffect(() => {
		if (props.errors) {
			control._setErrors(props.errors);
			control._focusError();
		}
	}, [control, props.errors]);
	import_react.useEffect(() => {
		props.shouldUnregister && control._subjects.state.next({ values: control._getWatch() });
	}, [control, props.shouldUnregister]);
	import_react.useEffect(() => {
		if (control._proxyFormState.isDirty) {
			const isDirty = control._getDirty();
			if (isDirty !== formState.isDirty) control._subjects.state.next({ isDirty });
		}
	}, [control, formState.isDirty]);
	import_react.useEffect(() => {
		var _a;
		if (props.values && !deepEqual(props.values, _values.current)) {
			control._reset(props.values, {
				keepFieldsRef: true,
				...control._options.resetOptions
			});
			if (!((_a = control._options.resetOptions) === null || _a === void 0 ? void 0 : _a.keepIsValid)) control._setValid();
			_values.current = props.values;
			updateFormState((state) => ({ ...state }));
		} else control._resetDefaultValues();
	}, [control, props.values]);
	import_react.useEffect(() => {
		if (!control._state.mount) {
			control._setValid();
			control._state.mount = true;
		}
		if (control._state.watch) {
			control._state.watch = false;
			control._subjects.state.next({ ...control._formState });
		}
		control._removeUnmounted();
	});
	_formControl.current.formState = import_react.useMemo(() => getProxyFormState(formState, control), [control, formState]);
	return _formControl.current;
}
/**
* Watch component that subscribes to form field changes and re-renders when watched fields update.
*
* @param control - The form control object from useForm
* @param name - Can be field name, array of field names, or undefined to watch the entire form
* @param disabled - Disable subscription
* @param exact - Whether to watch exact field names or not
* @param defaultValue - The default value to use if the field is not yet set
* @param compute - Function to compute derived values from watched fields
* @param render - The function that receives watched values and returns ReactNode
* @returns The result of calling render function with watched values
*
* @example
* The `Watch` component only re-render when the values of `foo`, `bar`, and `baz.qux` change.
* The types of `foo`, `bar`, and `baz.qux` are precisely inferred.
*
* ```tsx
* const { control } = useForm();
*
* <Watch
*   control={control}
*   names={['foo', 'bar', 'baz.qux']}
*   render={([foo, bar, baz_qux]) => <div>{foo}{bar}{baz_qux}</div>}
* />
* ```
*/
var Watch = (props) => props.render(useWatch({
	name: props.names,
	...props
}));
//#endregion
export { Controller, FieldArray, Form, FormProvider, FormState, FormStateSubscribe, Watch, appendErrors, createFormControl, get, set, useController, useFieldArray, useForm, useFormContext, useFormState, useWatch };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVhY3QtaG9vay1mb3JtLmpzIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIi4uLy4uL3JlYWN0LWhvb2stZm9ybS9kaXN0L2luZGV4LmVzbS5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcblxudmFyIGlzQ2hlY2tCb3hJbnB1dCA9IChlbGVtZW50KSA9PiBlbGVtZW50LnR5cGUgPT09ICdjaGVja2JveCc7XG5cbnZhciBpc0ZpbGVJbnB1dCA9IChlbGVtZW50KSA9PiBlbGVtZW50LnR5cGUgPT09ICdmaWxlJztcblxudmFyIGlzRGF0ZU9iamVjdCA9ICh2YWx1ZSkgPT4gdmFsdWUgaW5zdGFuY2VvZiBEYXRlO1xuXG52YXIgaXNOdWxsT3JVbmRlZmluZWQgPSAodmFsdWUpID0+IHZhbHVlID09IG51bGw7XG5cbmNvbnN0IGlzT2JqZWN0VHlwZSA9ICh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JztcbnZhciBpc09iamVjdCA9ICh2YWx1ZSkgPT4gIWlzTnVsbE9yVW5kZWZpbmVkKHZhbHVlKSAmJlxuICAgICFBcnJheS5pc0FycmF5KHZhbHVlKSAmJlxuICAgIGlzT2JqZWN0VHlwZSh2YWx1ZSkgJiZcbiAgICAhaXNEYXRlT2JqZWN0KHZhbHVlKTtcblxudmFyIGdldEV2ZW50VmFsdWUgPSAoZXZlbnQpID0+IGlzT2JqZWN0KGV2ZW50KSAmJiBldmVudC50YXJnZXRcbiAgICA/IGlzQ2hlY2tCb3hJbnB1dChldmVudC50YXJnZXQpXG4gICAgICAgID8gZXZlbnQudGFyZ2V0LmNoZWNrZWRcbiAgICAgICAgOiBpc0ZpbGVJbnB1dChldmVudC50YXJnZXQpXG4gICAgICAgICAgICA/IGV2ZW50LnRhcmdldC5maWxlc1xuICAgICAgICAgICAgOiBldmVudC50YXJnZXQudmFsdWVcbiAgICA6IGV2ZW50O1xuXG52YXIgaXNOYW1lSW5GaWVsZEFycmF5ID0gKG5hbWVzLCBuYW1lKSA9PiBuYW1lXG4gICAgLnNwbGl0KCcuJylcbiAgICAuc29tZSgocGFydCwgaW5kZXgsIGFycikgPT4gIWlzTmFOKE51bWJlcihwYXJ0KSkgJiYgbmFtZXMuaGFzKGFyci5zbGljZSgwLCBpbmRleCkuam9pbignLicpKSk7XG5cbnZhciBpc1BsYWluT2JqZWN0ID0gKHRlbXBPYmplY3QpID0+IHtcbiAgICBjb25zdCBwcm90b3R5cGVDb3B5ID0gdGVtcE9iamVjdC5jb25zdHJ1Y3RvciAmJiB0ZW1wT2JqZWN0LmNvbnN0cnVjdG9yLnByb3RvdHlwZTtcbiAgICByZXR1cm4gKGlzT2JqZWN0KHByb3RvdHlwZUNvcHkpICYmIHByb3RvdHlwZUNvcHkuaGFzT3duUHJvcGVydHkoJ2lzUHJvdG90eXBlT2YnKSk7XG59O1xuXG52YXIgaXNXZWIgPSB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJlxuICAgIHR5cGVvZiB3aW5kb3cuSFRNTEVsZW1lbnQgIT09ICd1bmRlZmluZWQnICYmXG4gICAgdHlwZW9mIGRvY3VtZW50ICE9PSAndW5kZWZpbmVkJztcblxuZnVuY3Rpb24gY2xvbmVPYmplY3QoZGF0YSkge1xuICAgIGlmIChkYXRhIGluc3RhbmNlb2YgRGF0ZSkge1xuICAgICAgICByZXR1cm4gbmV3IERhdGUoZGF0YSk7XG4gICAgfVxuICAgIGNvbnN0IGlzRmlsZUxpc3RJbnN0YW5jZSA9IHR5cGVvZiBGaWxlTGlzdCAhPT0gJ3VuZGVmaW5lZCcgJiYgZGF0YSBpbnN0YW5jZW9mIEZpbGVMaXN0O1xuICAgIGlmIChpc1dlYiAmJiAoZGF0YSBpbnN0YW5jZW9mIEJsb2IgfHwgaXNGaWxlTGlzdEluc3RhbmNlKSkge1xuICAgICAgICByZXR1cm4gZGF0YTtcbiAgICB9XG4gICAgY29uc3QgaXNBcnJheSA9IEFycmF5LmlzQXJyYXkoZGF0YSk7XG4gICAgaWYgKCFpc0FycmF5ICYmICEoaXNPYmplY3QoZGF0YSkgJiYgaXNQbGFpbk9iamVjdChkYXRhKSkpIHtcbiAgICAgICAgcmV0dXJuIGRhdGE7XG4gICAgfVxuICAgIGNvbnN0IGNvcHkgPSBpc0FycmF5ID8gW10gOiBPYmplY3QuY3JlYXRlKE9iamVjdC5nZXRQcm90b3R5cGVPZihkYXRhKSk7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZGF0YSkge1xuICAgICAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGRhdGEsIGtleSkpIHtcbiAgICAgICAgICAgIGNvcHlba2V5XSA9IGNsb25lT2JqZWN0KGRhdGFba2V5XSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGNvcHk7XG59XG5cbmNvbnN0IEVWRU5UUyA9IHtcbiAgICBCTFVSOiAnYmx1cicsXG4gICAgRk9DVVNfT1VUOiAnZm9jdXNvdXQnLFxuICAgIENIQU5HRTogJ2NoYW5nZScsXG4gICAgU1VCTUlUOiAnc3VibWl0JyxcbiAgICBUUklHR0VSOiAndHJpZ2dlcicsXG4gICAgVkFMSUQ6ICd2YWxpZCcsXG59O1xuY29uc3QgVkFMSURBVElPTl9NT0RFID0ge1xuICAgIG9uQmx1cjogJ29uQmx1cicsXG4gICAgb25DaGFuZ2U6ICdvbkNoYW5nZScsXG4gICAgb25TdWJtaXQ6ICdvblN1Ym1pdCcsXG4gICAgb25Ub3VjaGVkOiAnb25Ub3VjaGVkJyxcbiAgICBhbGw6ICdhbGwnLFxufTtcbmNvbnN0IElOUFVUX1ZBTElEQVRJT05fUlVMRVMgPSB7XG4gICAgbWF4OiAnbWF4JyxcbiAgICBtaW46ICdtaW4nLFxuICAgIG1heExlbmd0aDogJ21heExlbmd0aCcsXG4gICAgbWluTGVuZ3RoOiAnbWluTGVuZ3RoJyxcbiAgICBwYXR0ZXJuOiAncGF0dGVybicsXG4gICAgcmVxdWlyZWQ6ICdyZXF1aXJlZCcsXG4gICAgdmFsaWRhdGU6ICd2YWxpZGF0ZScsXG59O1xuY29uc3QgUk9PVF9FUlJPUl9UWVBFID0gJ3Jvb3QnO1xuY29uc3QgUFJPVE9UWVBFX0tFWVdPUkRTID0gWydfX3Byb3RvX18nLCAnY29uc3RydWN0b3InLCAncHJvdG90eXBlJ107XG5cbmNvbnN0IElTX0tFWV9SRSA9IC9eXFx3KiQvO1xudmFyIGlzS2V5ID0gKHZhbHVlKSA9PiBJU19LRVlfUkUudGVzdCh2YWx1ZSk7XG5cbnZhciBpc1VuZGVmaW5lZCA9ICh2YWwpID0+IHZhbCA9PT0gdW5kZWZpbmVkO1xuXG5jb25zdCBGSUVMRF9QQVRIX1JFID0gL1suW1xcXSdcIl0vO1xudmFyIHN0cmluZ1RvUGF0aCA9IChpbnB1dCkgPT4gaW5wdXQuc3BsaXQoRklFTERfUEFUSF9SRSkuZmlsdGVyKEJvb2xlYW4pO1xuXG52YXIgZ2V0ID0gKG9iamVjdCwgcGF0aCwgZGVmYXVsdFZhbHVlKSA9PiB7XG4gICAgaWYgKCFwYXRoIHx8ICFpc09iamVjdChvYmplY3QpKSB7XG4gICAgICAgIHJldHVybiBkZWZhdWx0VmFsdWU7XG4gICAgfVxuICAgIGNvbnN0IHBhdGhzID0gaXNLZXkocGF0aCkgPyBbcGF0aF0gOiBzdHJpbmdUb1BhdGgocGF0aCk7XG4gICAgaWYgKHBhdGhzLnNvbWUoKGtleSkgPT4gUFJPVE9UWVBFX0tFWVdPUkRTLmluY2x1ZGVzKGtleSkpKSB7XG4gICAgICAgIHJldHVybiBkZWZhdWx0VmFsdWU7XG4gICAgfVxuICAgIGNvbnN0IHJlc3VsdCA9IHBhdGhzLnJlZHVjZSgocmVzdWx0LCBrZXkpID0+IHtcbiAgICAgICAgcmV0dXJuIGlzTnVsbE9yVW5kZWZpbmVkKHJlc3VsdCkgPyB1bmRlZmluZWQgOiByZXN1bHRba2V5XTtcbiAgICB9LCBvYmplY3QpO1xuICAgIHJldHVybiBpc1VuZGVmaW5lZChyZXN1bHQpIHx8IHJlc3VsdCA9PT0gb2JqZWN0XG4gICAgICAgID8gaXNVbmRlZmluZWQob2JqZWN0W3BhdGhdKVxuICAgICAgICAgICAgPyBkZWZhdWx0VmFsdWVcbiAgICAgICAgICAgIDogb2JqZWN0W3BhdGhdXG4gICAgICAgIDogcmVzdWx0O1xufTtcblxudmFyIGlzQm9vbGVhbiA9ICh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbic7XG5cbnZhciBpc0Z1bmN0aW9uID0gKHZhbHVlKSA9PiB0eXBlb2YgdmFsdWUgPT09ICdmdW5jdGlvbic7XG5cbnZhciBzZXQgPSAob2JqZWN0LCBwYXRoLCB2YWx1ZSkgPT4ge1xuICAgIGxldCBpbmRleCA9IC0xO1xuICAgIGNvbnN0IHRlbXBQYXRoID0gaXNLZXkocGF0aCkgPyBbcGF0aF0gOiBzdHJpbmdUb1BhdGgocGF0aCk7XG4gICAgY29uc3QgbGVuZ3RoID0gdGVtcFBhdGgubGVuZ3RoO1xuICAgIGNvbnN0IGxhc3RJbmRleCA9IGxlbmd0aCAtIDE7XG4gICAgd2hpbGUgKCsraW5kZXggPCBsZW5ndGgpIHtcbiAgICAgICAgY29uc3Qga2V5ID0gdGVtcFBhdGhbaW5kZXhdO1xuICAgICAgICBsZXQgbmV3VmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgaWYgKGluZGV4ICE9PSBsYXN0SW5kZXgpIHtcbiAgICAgICAgICAgIGNvbnN0IG9ialZhbHVlID0gb2JqZWN0W2tleV07XG4gICAgICAgICAgICBuZXdWYWx1ZSA9XG4gICAgICAgICAgICAgICAgaXNPYmplY3Qob2JqVmFsdWUpIHx8IEFycmF5LmlzQXJyYXkob2JqVmFsdWUpXG4gICAgICAgICAgICAgICAgICAgID8gb2JqVmFsdWVcbiAgICAgICAgICAgICAgICAgICAgOiAhaXNOYU4oK3RlbXBQYXRoW2luZGV4ICsgMV0pXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFtdXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHt9O1xuICAgICAgICB9XG4gICAgICAgIGlmIChQUk9UT1RZUEVfS0VZV09SRFMuaW5jbHVkZXMoa2V5KSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIG9iamVjdFtrZXldID0gbmV3VmFsdWU7XG4gICAgICAgIG9iamVjdCA9IG9iamVjdFtrZXldO1xuICAgIH1cbn07XG5cbi8qKlxuICogU2VwYXJhdGUgY29udGV4dCBmb3IgYGNvbnRyb2xgIHRvIHByZXZlbnQgdW5uZWNlc3NhcnkgcmVyZW5kZXJzLlxuICogSW50ZXJuYWwgaG9va3MgdGhhdCBvbmx5IG5lZWQgY29udHJvbCB1c2UgdGhpcyBpbnN0ZWFkIG9mIGZ1bGwgZm9ybSBjb250ZXh0LlxuICovXG5jb25zdCBIb29rRm9ybUNvbnRyb2xDb250ZXh0ID0gUmVhY3QuY3JlYXRlQ29udGV4dChudWxsKTtcbkhvb2tGb3JtQ29udHJvbENvbnRleHQuZGlzcGxheU5hbWUgPSAnSG9va0Zvcm1Db250cm9sQ29udGV4dCc7XG4vKipcbiAqIEBpbnRlcm5hbCBJbnRlcm5hbCBob29rIHRvIGFjY2VzcyBvbmx5IGNvbnRyb2wgZnJvbSBjb250ZXh0LlxuICovXG5jb25zdCB1c2VGb3JtQ29udHJvbENvbnRleHQgPSAoKSA9PiBSZWFjdC51c2VDb250ZXh0KEhvb2tGb3JtQ29udHJvbENvbnRleHQpO1xuXG52YXIgZ2V0UHJveHlGb3JtU3RhdGUgPSAoZm9ybVN0YXRlLCBjb250cm9sLCBsb2NhbFByb3h5Rm9ybVN0YXRlLCBpc1Jvb3QgPSB0cnVlKSA9PiB7XG4gICAgY29uc3QgcmVzdWx0ID0ge307XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZm9ybVN0YXRlKSB7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShyZXN1bHQsIGtleSwge1xuICAgICAgICAgICAgZ2V0OiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgX2tleSA9IGtleTtcbiAgICAgICAgICAgICAgICBpZiAoY29udHJvbC5fcHJveHlGb3JtU3RhdGVbX2tleV0gIT09IFZBTElEQVRJT05fTU9ERS5hbGwpIHtcbiAgICAgICAgICAgICAgICAgICAgY29udHJvbC5fcHJveHlGb3JtU3RhdGVbX2tleV0gPSAhaXNSb290IHx8IFZBTElEQVRJT05fTU9ERS5hbGw7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGxvY2FsUHJveHlGb3JtU3RhdGUgJiYgKGxvY2FsUHJveHlGb3JtU3RhdGVbX2tleV0gPSB0cnVlKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZm9ybVN0YXRlW19rZXldO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59O1xuXG5jb25zdCB1c2VJc29tb3JwaGljTGF5b3V0RWZmZWN0ID0gaXNXZWJcbiAgICA/IFJlYWN0LnVzZUxheW91dEVmZmVjdFxuICAgIDogUmVhY3QudXNlRWZmZWN0O1xuXG52YXIgaXNQcmltaXRpdmUgPSAodmFsdWUpID0+IGlzTnVsbE9yVW5kZWZpbmVkKHZhbHVlKSB8fCAhaXNPYmplY3RUeXBlKHZhbHVlKTtcblxuY29uc3QgaXNFbXB0eU9iamVjdFdpdGhDdXN0b21Qcm90b3R5cGUgPSAob2JqZWN0LCBrZXlzKSA9PiBrZXlzLmxlbmd0aCA9PT0gMCAmJiAhQXJyYXkuaXNBcnJheShvYmplY3QpICYmICFpc1BsYWluT2JqZWN0KG9iamVjdCk7XG5mdW5jdGlvbiBkZWVwRXF1YWwob2JqZWN0MSwgb2JqZWN0MiwgdmlzaXRlZCA9IG5ldyBXZWFrTWFwKCkpIHtcbiAgICBpZiAob2JqZWN0MSA9PT0gb2JqZWN0Mikge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKGlzUHJpbWl0aXZlKG9iamVjdDEpIHx8IGlzUHJpbWl0aXZlKG9iamVjdDIpKSB7XG4gICAgICAgIHJldHVybiBPYmplY3QuaXMob2JqZWN0MSwgb2JqZWN0Mik7XG4gICAgfVxuICAgIGlmIChpc0RhdGVPYmplY3Qob2JqZWN0MSkgJiYgaXNEYXRlT2JqZWN0KG9iamVjdDIpKSB7XG4gICAgICAgIHJldHVybiBPYmplY3QuaXMob2JqZWN0MS5nZXRUaW1lKCksIG9iamVjdDIuZ2V0VGltZSgpKTtcbiAgICB9XG4gICAgY29uc3Qga2V5czEgPSBPYmplY3Qua2V5cyhvYmplY3QxKTtcbiAgICBjb25zdCBrZXlzMiA9IE9iamVjdC5rZXlzKG9iamVjdDIpO1xuICAgIGlmIChrZXlzMS5sZW5ndGggIT09IGtleXMyLmxlbmd0aCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlmIChpc0VtcHR5T2JqZWN0V2l0aEN1c3RvbVByb3RvdHlwZShvYmplY3QxLCBrZXlzMSkgfHxcbiAgICAgICAgaXNFbXB0eU9iamVjdFdpdGhDdXN0b21Qcm90b3R5cGUob2JqZWN0Miwga2V5czIpKSB7XG4gICAgICAgIHJldHVybiBPYmplY3QuaXMob2JqZWN0MSwgb2JqZWN0Mik7XG4gICAgfVxuICAgIGlmICgha2V5czEubGVuZ3RoICYmIEFycmF5LmlzQXJyYXkob2JqZWN0MSkgIT09IEFycmF5LmlzQXJyYXkob2JqZWN0MikpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCB2aXNpdGVkUGFpcnMgPSB2aXNpdGVkLmdldChvYmplY3QxKTtcbiAgICBpZiAodmlzaXRlZFBhaXJzICYmIHZpc2l0ZWRQYWlycy5oYXMob2JqZWN0MikpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGlmICh2aXNpdGVkUGFpcnMpIHtcbiAgICAgICAgdmlzaXRlZFBhaXJzLmFkZChvYmplY3QyKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGNvbnN0IHdzID0gbmV3IFdlYWtTZXQoKTtcbiAgICAgICAgd3MuYWRkKG9iamVjdDIpO1xuICAgICAgICB2aXNpdGVkLnNldChvYmplY3QxLCB3cyk7XG4gICAgfVxuICAgIGZvciAoY29uc3Qga2V5IG9mIGtleXMxKSB7XG4gICAgICAgIGNvbnN0IHZhbDEgPSBvYmplY3QxW2tleV07XG4gICAgICAgIGlmICghKGtleSBpbiBvYmplY3QyKSkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChrZXkgIT09ICdyZWYnKSB7XG4gICAgICAgICAgICBjb25zdCB2YWwyID0gb2JqZWN0MltrZXldO1xuICAgICAgICAgICAgaWYgKChpc0RhdGVPYmplY3QodmFsMSkgJiYgaXNEYXRlT2JqZWN0KHZhbDIpKSB8fFxuICAgICAgICAgICAgICAgICgoaXNPYmplY3QodmFsMSkgfHwgQXJyYXkuaXNBcnJheSh2YWwxKSkgJiZcbiAgICAgICAgICAgICAgICAgICAgKGlzT2JqZWN0KHZhbDIpIHx8IEFycmF5LmlzQXJyYXkodmFsMikpKVxuICAgICAgICAgICAgICAgID8gIWRlZXBFcXVhbCh2YWwxLCB2YWwyLCB2aXNpdGVkKVxuICAgICAgICAgICAgICAgIDogIU9iamVjdC5pcyh2YWwxLCB2YWwyKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbn1cblxuZnVuY3Rpb24gdXNlUmVzeW5jT25SZWNvbm5lY3QoKSB7XG4gICAgY29uc3QgX2Nvbm5lY3RlZCA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gICAgY29uc3QgX3ByZXZWYWx1ZSA9IFJlYWN0LnVzZVJlZih1bmRlZmluZWQpO1xuICAgIGNvbnN0IHJlc3luY0lmTmVlZGVkID0gUmVhY3QudXNlQ2FsbGJhY2soKGVuYWJsZWQsIGdldEN1cnJlbnRWYWx1ZSwgc2V0VmFsdWUpID0+IHtcbiAgICAgICAgaWYgKGVuYWJsZWQgJiYgX2Nvbm5lY3RlZC5jdXJyZW50KSB7XG4gICAgICAgICAgICBjb25zdCBjdXJyZW50VmFsdWUgPSBnZXRDdXJyZW50VmFsdWUoKTtcbiAgICAgICAgICAgIGlmICghZGVlcEVxdWFsKF9wcmV2VmFsdWUuY3VycmVudCwgY3VycmVudFZhbHVlKSkge1xuICAgICAgICAgICAgICAgIHNldFZhbHVlKGN1cnJlbnRWYWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgX2Nvbm5lY3RlZC5jdXJyZW50ID0gdHJ1ZTtcbiAgICB9LCBbXSk7XG4gICAgY29uc3Qgc25hcHNob3QgPSBSZWFjdC51c2VDYWxsYmFjaygoZW5hYmxlZCwgZ2V0Q3VycmVudFZhbHVlKSA9PiB7XG4gICAgICAgIGlmIChlbmFibGVkKSB7XG4gICAgICAgICAgICBfcHJldlZhbHVlLmN1cnJlbnQgPSBjbG9uZU9iamVjdChnZXRDdXJyZW50VmFsdWUoKSk7XG4gICAgICAgIH1cbiAgICB9LCBbXSk7XG4gICAgcmV0dXJuIHsgcmVzeW5jSWZOZWVkZWQsIHNuYXBzaG90IH07XG59XG5cbi8qKlxuICogU3Vic2NyaWJlcyB0byBlYWNoIGZvcm0gc3RhdGUgYW5kIGlzb2xhdGVzIHJlLXJlbmRlcnMgYXQgdGhlIGN1c3RvbSBob29rIGxldmVsLiBJdCBoYXMgaXRzIG93biBzY29wZSBmb3IgZm9ybSBzdGF0ZSBzdWJzY3JpcHRpb25zLCBzbyBpdCB3aWxsIG5vdCBhZmZlY3Qgb3RoZXIgdXNlRm9ybVN0YXRlIG9yIHVzZUZvcm0gaW5zdGFuY2VzLiBVc2luZyB0aGlzIGhvb2sgY2FuIHJlZHVjZSB0aGUgcmUtcmVuZGVyIGltcGFjdCBvbiBsYXJnZSBhbmQgY29tcGxleCBmb3JtIGFwcGxpY2F0aW9ucy5cbiAqXG4gKiBAcmVtYXJrc1xuICogW0FQSV0oaHR0cHM6Ly9yZWFjdC1ob29rLWZvcm0uY29tL2RvY3MvdXNlZm9ybXN0YXRlKSDigKIgW0RlbW9dKGh0dHBzOi8vY29kZXNhbmRib3guaW8vcy91c2Vmb3Jtc3RhdGUtNzV4bHkpXG4gKlxuICogQHBhcmFtIHByb3BzIC0gSW5jbHVkZSBvcHRpb25zIHRvIHNwZWNpZnkgZmllbGRzIHRvIHN1YnNjcmliZSB0by4ge0BsaW5rIFVzZUZvcm1TdGF0ZVJldHVybn1cbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiBmdW5jdGlvbiBBcHAoKSB7XG4gKiAgIGNvbnN0IHsgcmVnaXN0ZXIsIGhhbmRsZVN1Ym1pdCwgY29udHJvbCB9ID0gdXNlRm9ybSh7XG4gKiAgICAgZGVmYXVsdFZhbHVlczoge1xuICogICAgIGZpcnN0TmFtZTogXCJmaXJzdE5hbWVcIlxuICogICB9fSk7XG4gKiAgIGNvbnN0IHsgZGlydHlGaWVsZHMgfSA9IHVzZUZvcm1TdGF0ZSh7XG4gKiAgICAgY29udHJvbFxuICogICB9KTtcbiAqICAgY29uc3Qgb25TdWJtaXQgPSAoZGF0YSkgPT4gY29uc29sZS5sb2coZGF0YSk7XG4gKlxuICogICByZXR1cm4gKFxuICogICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXQob25TdWJtaXQpfT5cbiAqICAgICAgIDxpbnB1dCB7Li4ucmVnaXN0ZXIoXCJmaXJzdE5hbWVcIil9IHBsYWNlaG9sZGVyPVwiRmlyc3QgTmFtZVwiIC8+XG4gKiAgICAgICB7ZGlydHlGaWVsZHMuZmlyc3ROYW1lICYmIDxwPkZpZWxkIGlzIGRpcnR5LjwvcD59XG4gKiAgICAgICA8aW5wdXQgdHlwZT1cInN1Ym1pdFwiIC8+XG4gKiAgICAgPC9mb3JtPlxuICogICApO1xuICogfVxuICogYGBgXG4gKi9cbmZ1bmN0aW9uIHVzZUZvcm1TdGF0ZShwcm9wcykge1xuICAgIGNvbnN0IGZvcm1Db250cm9sID0gdXNlRm9ybUNvbnRyb2xDb250ZXh0KCk7XG4gICAgY29uc3QgeyBjb250cm9sID0gZm9ybUNvbnRyb2wsIGRpc2FibGVkLCBuYW1lLCBleGFjdCB9ID0gcHJvcHMgfHwge307XG4gICAgY29uc3QgW2Zvcm1TdGF0ZSwgdXBkYXRlRm9ybVN0YXRlXSA9IFJlYWN0LnVzZVN0YXRlKCgpID0+ICh7XG4gICAgICAgIC4uLmNvbnRyb2wuX2Zvcm1TdGF0ZSxcbiAgICAgICAgZGVmYXVsdFZhbHVlczogY29udHJvbC5fZGVmYXVsdFZhbHVlcyxcbiAgICB9KSk7XG4gICAgY29uc3QgX2xvY2FsUHJveHlGb3JtU3RhdGUgPSBSZWFjdC51c2VSZWYoe1xuICAgICAgICBpc0RpcnR5OiBmYWxzZSxcbiAgICAgICAgaXNMb2FkaW5nOiBmYWxzZSxcbiAgICAgICAgZGlydHlGaWVsZHM6IGZhbHNlLFxuICAgICAgICB0b3VjaGVkRmllbGRzOiBmYWxzZSxcbiAgICAgICAgdmFsaWRhdGluZ0ZpZWxkczogZmFsc2UsXG4gICAgICAgIGlzVmFsaWRhdGluZzogZmFsc2UsXG4gICAgICAgIGlzVmFsaWQ6IGZhbHNlLFxuICAgICAgICBlcnJvcnM6IGZhbHNlLFxuICAgIH0pO1xuICAgIGNvbnN0IHsgcmVzeW5jSWZOZWVkZWQsIHNuYXBzaG90IH0gPSB1c2VSZXN5bmNPblJlY29ubmVjdCgpO1xuICAgIHVzZUlzb21vcnBoaWNMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBnZXRDdXJyZW50Rm9ybVN0YXRlID0gKCkgPT4gKHtcbiAgICAgICAgICAgIC4uLmNvbnRyb2wuX2Zvcm1TdGF0ZSxcbiAgICAgICAgICAgIGRlZmF1bHRWYWx1ZXM6IGNvbnRyb2wuX2RlZmF1bHRWYWx1ZXMsXG4gICAgICAgIH0pO1xuICAgICAgICByZXN5bmNJZk5lZWRlZCghZGlzYWJsZWQsIGdldEN1cnJlbnRGb3JtU3RhdGUsIHVwZGF0ZUZvcm1TdGF0ZSk7XG4gICAgICAgIGNvbnN0IHVuc3Vic2NyaWJlID0gY29udHJvbC5fc3Vic2NyaWJlKHtcbiAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICBmb3JtU3RhdGU6IF9sb2NhbFByb3h5Rm9ybVN0YXRlLmN1cnJlbnQsXG4gICAgICAgICAgICBleGFjdCxcbiAgICAgICAgICAgIGNhbGxiYWNrOiAoZm9ybVN0YXRlKSA9PiB7XG4gICAgICAgICAgICAgICAgIWRpc2FibGVkICYmXG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1TdGF0ZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5jb250cm9sLl9mb3JtU3RhdGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtU3RhdGUsXG4gICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWVzOiBjb250cm9sLl9kZWZhdWx0VmFsdWVzLFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgdW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgIHNuYXBzaG90KCFkaXNhYmxlZCwgZ2V0Q3VycmVudEZvcm1TdGF0ZSk7XG4gICAgICAgIH07XG4gICAgfSwgW25hbWUsIGRpc2FibGVkLCBleGFjdCwgcmVzeW5jSWZOZWVkZWQsIHNuYXBzaG90XSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgX2xvY2FsUHJveHlGb3JtU3RhdGUuY3VycmVudC5pc1ZhbGlkICYmIGNvbnRyb2wuX3NldFZhbGlkKHRydWUpO1xuICAgIH0sIFtjb250cm9sXSk7XG4gICAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4gZ2V0UHJveHlGb3JtU3RhdGUoZm9ybVN0YXRlLCBjb250cm9sLCBfbG9jYWxQcm94eUZvcm1TdGF0ZS5jdXJyZW50LCBmYWxzZSksIFtmb3JtU3RhdGUsIGNvbnRyb2xdKTtcbn1cblxudmFyIGlzU3RyaW5nID0gKHZhbHVlKSA9PiB0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnO1xuXG52YXIgZ2VuZXJhdGVXYXRjaE91dHB1dCA9IChuYW1lcywgX25hbWVzLCBmb3JtVmFsdWVzLCBpc0dsb2JhbCwgZGVmYXVsdFZhbHVlKSA9PiB7XG4gICAgaWYgKGlzU3RyaW5nKG5hbWVzKSkge1xuICAgICAgICBpc0dsb2JhbCAmJiBfbmFtZXMud2F0Y2guYWRkKG5hbWVzKTtcbiAgICAgICAgcmV0dXJuIGdldChmb3JtVmFsdWVzLCBuYW1lcywgZGVmYXVsdFZhbHVlKTtcbiAgICB9XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobmFtZXMpKSB7XG4gICAgICAgIHJldHVybiBuYW1lcy5tYXAoKGZpZWxkTmFtZSkgPT4gKGlzR2xvYmFsICYmIF9uYW1lcy53YXRjaC5hZGQoZmllbGROYW1lKSxcbiAgICAgICAgICAgIGdldChmb3JtVmFsdWVzLCBmaWVsZE5hbWUpKSk7XG4gICAgfVxuICAgIGlzR2xvYmFsICYmIChfbmFtZXMud2F0Y2hBbGwgPSB0cnVlKTtcbiAgICByZXR1cm4gZm9ybVZhbHVlcztcbn07XG5cbi8qKlxuICogQ3VzdG9tIGhvb2sgdG8gc3Vic2NyaWJlIHRvIGZpZWxkIGNoYW5nZXMgYW5kIGlzb2xhdGUgcmUtcmVuZGVyaW5nIGF0IHRoZSBjb21wb25lbnQgbGV2ZWwuXG4gKlxuICogQHJlbWFya3NcbiAqXG4gKiBbQVBJXShodHRwczovL3JlYWN0LWhvb2stZm9ybS5jb20vZG9jcy91c2V3YXRjaCkg4oCiIFtEZW1vXShodHRwczovL2NvZGVzYW5kYm94LmlvL3MvcmVhY3QtaG9vay1mb3JtLXY3LXRzLXVzZXdhdGNoLWg5aTVlKVxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0c3hcbiAqIGNvbnN0IHsgY29udHJvbCB9ID0gdXNlRm9ybSgpO1xuICogY29uc3QgdmFsdWVzID0gdXNlV2F0Y2goe1xuICogICBuYW1lOiBcImZpZWxkTmFtZVwiLFxuICogICBjb250cm9sLFxuICogfSlcbiAqIGBgYFxuICovXG5mdW5jdGlvbiB1c2VXYXRjaChwcm9wcykge1xuICAgIGNvbnN0IGZvcm1Db250cm9sID0gdXNlRm9ybUNvbnRyb2xDb250ZXh0KCk7XG4gICAgY29uc3QgeyBjb250cm9sID0gZm9ybUNvbnRyb2wsIG5hbWUsIGRlZmF1bHRWYWx1ZSwgZGlzYWJsZWQsIGV4YWN0LCBjb21wdXRlLCB9ID0gcHJvcHMgfHwge307XG4gICAgY29uc3QgX2RlZmF1bHRWYWx1ZSA9IFJlYWN0LnVzZVJlZihkZWZhdWx0VmFsdWUpO1xuICAgIGNvbnN0IF9jb21wdXRlID0gUmVhY3QudXNlUmVmKGNvbXB1dGUpO1xuICAgIGNvbnN0IF9jb21wdXRlRm9ybVZhbHVlcyA9IFJlYWN0LnVzZVJlZih1bmRlZmluZWQpO1xuICAgIGNvbnN0IF9wcmV2Q29udHJvbCA9IFJlYWN0LnVzZVJlZihjb250cm9sKTtcbiAgICBjb25zdCBfcHJldk5hbWUgPSBSZWFjdC51c2VSZWYobmFtZSk7XG4gICAgX2NvbXB1dGUuY3VycmVudCA9IGNvbXB1dGU7XG4gICAgY29uc3QgW3ZhbHVlLCB1cGRhdGVWYWx1ZV0gPSBSZWFjdC51c2VTdGF0ZSgoKSA9PiB7XG4gICAgICAgIGNvbnN0IGRlZmF1bHRWYWx1ZSA9IGNvbnRyb2wuX2dldFdhdGNoKG5hbWUsIF9kZWZhdWx0VmFsdWUuY3VycmVudCk7XG4gICAgICAgIHJldHVybiBfY29tcHV0ZS5jdXJyZW50ID8gX2NvbXB1dGUuY3VycmVudChkZWZhdWx0VmFsdWUpIDogZGVmYXVsdFZhbHVlO1xuICAgIH0pO1xuICAgIGNvbnN0IGdldEN1cnJlbnRPdXRwdXQgPSBSZWFjdC51c2VDYWxsYmFjaygodmFsdWVzKSA9PiB7XG4gICAgICAgIGNvbnN0IGZvcm1WYWx1ZXMgPSBnZW5lcmF0ZVdhdGNoT3V0cHV0KG5hbWUsIGNvbnRyb2wuX25hbWVzLCB2YWx1ZXMgfHwgY29udHJvbC5fZm9ybVZhbHVlcywgZmFsc2UsIF9kZWZhdWx0VmFsdWUuY3VycmVudCk7XG4gICAgICAgIHJldHVybiBfY29tcHV0ZS5jdXJyZW50ID8gX2NvbXB1dGUuY3VycmVudChmb3JtVmFsdWVzKSA6IGZvcm1WYWx1ZXM7XG4gICAgfSwgW2NvbnRyb2wuX2Zvcm1WYWx1ZXMsIGNvbnRyb2wuX25hbWVzLCBuYW1lXSk7XG4gICAgY29uc3QgcmVmcmVzaFZhbHVlID0gUmVhY3QudXNlQ2FsbGJhY2soKHZhbHVlcykgPT4ge1xuICAgICAgICBpZiAoIWRpc2FibGVkKSB7XG4gICAgICAgICAgICBjb25zdCBmb3JtVmFsdWVzID0gZ2VuZXJhdGVXYXRjaE91dHB1dChuYW1lLCBjb250cm9sLl9uYW1lcywgdmFsdWVzIHx8IGNvbnRyb2wuX2Zvcm1WYWx1ZXMsIGZhbHNlLCBfZGVmYXVsdFZhbHVlLmN1cnJlbnQpO1xuICAgICAgICAgICAgaWYgKF9jb21wdXRlLmN1cnJlbnQpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBjb21wdXRlZEZvcm1WYWx1ZXMgPSBfY29tcHV0ZS5jdXJyZW50KGZvcm1WYWx1ZXMpO1xuICAgICAgICAgICAgICAgIGlmICghZGVlcEVxdWFsKGNvbXB1dGVkRm9ybVZhbHVlcywgX2NvbXB1dGVGb3JtVmFsdWVzLmN1cnJlbnQpKSB7XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZVZhbHVlKGNvbXB1dGVkRm9ybVZhbHVlcyk7XG4gICAgICAgICAgICAgICAgICAgIF9jb21wdXRlRm9ybVZhbHVlcy5jdXJyZW50ID0gY29tcHV0ZWRGb3JtVmFsdWVzO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHVwZGF0ZVZhbHVlKGZvcm1WYWx1ZXMpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSwgW2NvbnRyb2wuX2Zvcm1WYWx1ZXMsIGNvbnRyb2wuX25hbWVzLCBkaXNhYmxlZCwgbmFtZV0pO1xuICAgIGNvbnN0IHsgcmVzeW5jSWZOZWVkZWQsIHNuYXBzaG90IH0gPSB1c2VSZXN5bmNPblJlY29ubmVjdCgpO1xuICAgIGNvbnN0IF9yZWZyZXNoVmFsdWUgPSBSZWFjdC51c2VSZWYocmVmcmVzaFZhbHVlKTtcbiAgICBfcmVmcmVzaFZhbHVlLmN1cnJlbnQgPSByZWZyZXNoVmFsdWU7XG4gICAgY29uc3QgX2dldEN1cnJlbnRPdXRwdXQgPSBSZWFjdC51c2VSZWYoZ2V0Q3VycmVudE91dHB1dCk7XG4gICAgX2dldEN1cnJlbnRPdXRwdXQuY3VycmVudCA9IGdldEN1cnJlbnRPdXRwdXQ7XG4gICAgdXNlSXNvbW9ycGhpY0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChfcHJldkNvbnRyb2wuY3VycmVudCAhPT0gY29udHJvbCB8fFxuICAgICAgICAgICAgIWRlZXBFcXVhbChfcHJldk5hbWUuY3VycmVudCwgbmFtZSkpIHtcbiAgICAgICAgICAgIF9wcmV2Q29udHJvbC5jdXJyZW50ID0gY29udHJvbDtcbiAgICAgICAgICAgIF9wcmV2TmFtZS5jdXJyZW50ID0gbmFtZTtcbiAgICAgICAgICAgIF9yZWZyZXNoVmFsdWUuY3VycmVudCgpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgcmVzeW5jSWZOZWVkZWQoIWRpc2FibGVkLCAoKSA9PiBfZ2V0Q3VycmVudE91dHB1dC5jdXJyZW50KCksIChjdXJyZW50VmFsdWUpID0+IHtcbiAgICAgICAgICAgICAgICB1cGRhdGVWYWx1ZShjdXJyZW50VmFsdWUpO1xuICAgICAgICAgICAgICAgIF9jb21wdXRlRm9ybVZhbHVlcy5jdXJyZW50ID0gY3VycmVudFZhbHVlO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdW5zdWJzY3JpYmUgPSBjb250cm9sLl9zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgIGZvcm1TdGF0ZToge1xuICAgICAgICAgICAgICAgIHZhbHVlczogdHJ1ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBleGFjdCxcbiAgICAgICAgICAgIGNhbGxiYWNrOiAoZm9ybVN0YXRlKSA9PiB7XG4gICAgICAgICAgICAgICAgX3JlZnJlc2hWYWx1ZS5jdXJyZW50KGZvcm1TdGF0ZS52YWx1ZXMpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICB1bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgc25hcHNob3QoIWRpc2FibGVkLCAoKSA9PiBfZ2V0Q3VycmVudE91dHB1dC5jdXJyZW50KCkpO1xuICAgICAgICB9O1xuICAgIH0sIFtjb250cm9sLCBleGFjdCwgbmFtZSwgZGlzYWJsZWQsIHJlc3luY0lmTmVlZGVkLCBzbmFwc2hvdF0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiBjb250cm9sLl9yZW1vdmVVbm1vdW50ZWQoKSk7XG4gICAgLy8gSWYgbmFtZSBvciBjb250cm9sIGNoYW5nZWQgZm9yIHRoaXMgcmVuZGVyLCBzeW5jaHJvbm91c2x5IHJlZmxlY3QgdGhlXG4gICAgLy8gbGF0ZXN0IHZhbHVlIHNvIGNhbGxlcnMgKGxpa2UgdXNlQ29udHJvbGxlcikgc2VlIHRoZSBjb3JyZWN0IHZhbHVlXG4gICAgLy8gaW1tZWRpYXRlbHkgb24gdGhlIHNhbWUgcmVuZGVyLlxuICAgIC8vIE9wdGltaXplOiBDaGVjayBjb250cm9sIHJlZmVyZW5jZSBmaXJzdCBiZWZvcmUgZXhwZW5zaXZlIGRlZXBFcXVhbFxuICAgIGNvbnN0IGNvbnRyb2xDaGFuZ2VkID0gX3ByZXZDb250cm9sLmN1cnJlbnQgIT09IGNvbnRyb2w7XG4gICAgY29uc3QgcHJldk5hbWUgPSBfcHJldk5hbWUuY3VycmVudDtcbiAgICAvLyBDYWNoZSB0aGUgY29tcHV0ZWQgb3V0cHV0IHRvIGF2b2lkIGR1cGxpY2F0ZSBjYWxscyB3aXRoaW4gdGhlIHNhbWUgcmVuZGVyXG4gICAgLy8gV2UgaW5jbHVkZSBzaG91bGRSZXR1cm5JbW1lZGlhdGUgaW4gZGVwcyB0byBlbnN1cmUgcHJvcGVyIHJlY29tcHV0YXRpb25cbiAgICBjb25zdCBjb21wdXRlZE91dHB1dCA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG5hbWVDaGFuZ2VkID0gIWNvbnRyb2xDaGFuZ2VkICYmICFkZWVwRXF1YWwocHJldk5hbWUsIG5hbWUpO1xuICAgICAgICBjb25zdCBzaG91bGRSZXR1cm5JbW1lZGlhdGUgPSBjb250cm9sQ2hhbmdlZCB8fCBuYW1lQ2hhbmdlZDtcbiAgICAgICAgcmV0dXJuIHNob3VsZFJldHVybkltbWVkaWF0ZSA/IGdldEN1cnJlbnRPdXRwdXQoKSA6IG51bGw7XG4gICAgfSwgW2Rpc2FibGVkLCBjb250cm9sQ2hhbmdlZCwgbmFtZSwgcHJldk5hbWUsIGdldEN1cnJlbnRPdXRwdXRdKTtcbiAgICByZXR1cm4gY29tcHV0ZWRPdXRwdXQgIT09IG51bGwgPyBjb21wdXRlZE91dHB1dCA6IHZhbHVlO1xufVxuXG4vKipcbiAqIEN1c3RvbSBob29rIHRvIHdvcmsgd2l0aCBjb250cm9sbGVkIGNvbXBvbmVudCwgdGhpcyBmdW5jdGlvbiBwcm92aWRlIHlvdSB3aXRoIGJvdGggZm9ybSBhbmQgZmllbGQgbGV2ZWwgc3RhdGUuIFJlLXJlbmRlciBpcyBpc29sYXRlZCBhdCB0aGUgaG9vayBsZXZlbC5cbiAqXG4gKiBAcmVtYXJrc1xuICogW0FQSV0oaHR0cHM6Ly9yZWFjdC1ob29rLWZvcm0uY29tL2RvY3MvdXNlY29udHJvbGxlcikg4oCiIFtEZW1vXShodHRwczovL2NvZGVzYW5kYm94LmlvL3MvdXNlY29udHJvbGxlci0wbzhweClcbiAqXG4gKiBAcGFyYW0gcHJvcHMgLSB0aGUgcGF0aCBuYW1lIHRvIHRoZSBmb3JtIGZpZWxkIHZhbHVlLCBhbmQgdmFsaWRhdGlvbiBydWxlcy5cbiAqXG4gKiBAcmV0dXJucyBmaWVsZCBwcm9wZXJ0aWVzLCBmaWVsZCBhbmQgZm9ybSBzdGF0ZS4ge0BsaW5rIFVzZUNvbnRyb2xsZXJSZXR1cm59XG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogZnVuY3Rpb24gSW5wdXQocHJvcHMpIHtcbiAqICAgY29uc3QgeyBmaWVsZCwgZmllbGRTdGF0ZSwgZm9ybVN0YXRlIH0gPSB1c2VDb250cm9sbGVyKHByb3BzKTtcbiAqICAgcmV0dXJuIChcbiAqICAgICA8ZGl2PlxuICogICAgICAgPGlucHV0IHsuLi5maWVsZH0gcGxhY2Vob2xkZXI9e3Byb3BzLm5hbWV9IC8+XG4gKiAgICAgICA8cD57ZmllbGRTdGF0ZS5pc1RvdWNoZWQgJiYgXCJUb3VjaGVkXCJ9PC9wPlxuICogICAgICAgPHA+e2Zvcm1TdGF0ZS5pc1N1Ym1pdHRlZCA/IFwic3VibWl0dGVkXCIgOiBcIlwifTwvcD5cbiAqICAgICA8L2Rpdj5cbiAqICAgKTtcbiAqIH1cbiAqIGBgYFxuICovXG5mdW5jdGlvbiB1c2VDb250cm9sbGVyKHByb3BzKSB7XG4gICAgY29uc3QgZm9ybUNvbnRyb2wgPSB1c2VGb3JtQ29udHJvbENvbnRleHQoKTtcbiAgICBjb25zdCB7IG5hbWUsIGRpc2FibGVkLCBjb250cm9sID0gZm9ybUNvbnRyb2wsIHNob3VsZFVucmVnaXN0ZXIsIGRlZmF1bHRWYWx1ZSwgZXhhY3QgPSB0cnVlLCB9ID0gcHJvcHM7XG4gICAgY29uc3QgaXNBcnJheUZpZWxkID0gaXNOYW1lSW5GaWVsZEFycmF5KGNvbnRyb2wuX25hbWVzLmFycmF5LCBuYW1lKTtcbiAgICBjb25zdCBkZWZhdWx0VmFsdWVNZW1vID0gUmVhY3QudXNlTWVtbygoKSA9PiBnZXQoY29udHJvbC5fZm9ybVZhbHVlcywgbmFtZSwgZ2V0KGNvbnRyb2wuX2RlZmF1bHRWYWx1ZXMsIG5hbWUsIGRlZmF1bHRWYWx1ZSkpLCBbY29udHJvbCwgbmFtZSwgZGVmYXVsdFZhbHVlXSk7XG4gICAgY29uc3QgdmFsdWUgPSB1c2VXYXRjaCh7XG4gICAgICAgIGNvbnRyb2wsXG4gICAgICAgIG5hbWUsXG4gICAgICAgIGRlZmF1bHRWYWx1ZTogZGVmYXVsdFZhbHVlTWVtbyxcbiAgICAgICAgZXhhY3QsXG4gICAgfSk7XG4gICAgY29uc3QgZm9ybVN0YXRlID0gdXNlRm9ybVN0YXRlKHtcbiAgICAgICAgY29udHJvbCxcbiAgICAgICAgbmFtZSxcbiAgICAgICAgZXhhY3QsXG4gICAgfSk7XG4gICAgY29uc3QgX3Byb3BzID0gUmVhY3QudXNlUmVmKHByb3BzKTtcbiAgICBjb25zdCBfcHJveHlSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gICAgY29uc3QgX3JlZ2lzdGVyUHJvcHMgPSBSZWFjdC51c2VSZWYoY29udHJvbC5yZWdpc3RlcihuYW1lLCB7XG4gICAgICAgIC4uLnByb3BzLnJ1bGVzLFxuICAgICAgICB2YWx1ZSxcbiAgICAgICAgLi4uKGlzQm9vbGVhbihwcm9wcy5kaXNhYmxlZCkgPyB7IGRpc2FibGVkOiBwcm9wcy5kaXNhYmxlZCB9IDoge30pLFxuICAgIH0pKTtcbiAgICBfcHJvcHMuY3VycmVudCA9IHByb3BzO1xuICAgIGNvbnN0IGZpZWxkU3RhdGUgPSBSZWFjdC51c2VNZW1vKCgpID0+IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKHt9LCB7XG4gICAgICAgIGludmFsaWQ6IHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBnZXQ6ICgpID0+ICEhZ2V0KGZvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpLFxuICAgICAgICB9LFxuICAgICAgICBpc0RpcnR5OiB7XG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgZ2V0OiAoKSA9PiAhIWdldChmb3JtU3RhdGUuZGlydHlGaWVsZHMsIG5hbWUpLFxuICAgICAgICB9LFxuICAgICAgICBpc1RvdWNoZWQ6IHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBnZXQ6ICgpID0+ICEhZ2V0KGZvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCBuYW1lKSxcbiAgICAgICAgfSxcbiAgICAgICAgaXNWYWxpZGF0aW5nOiB7XG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgZ2V0OiAoKSA9PiAhIWdldChmb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcywgbmFtZSksXG4gICAgICAgIH0sXG4gICAgICAgIGVycm9yOiB7XG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgZ2V0OiAoKSA9PiBnZXQoZm9ybVN0YXRlLmVycm9ycywgbmFtZSksXG4gICAgICAgIH0sXG4gICAgfSksIFtmb3JtU3RhdGUsIG5hbWVdKTtcbiAgICBjb25zdCBvbkNoYW5nZSA9IFJlYWN0LnVzZUNhbGxiYWNrKChldmVudCkgPT4ge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGdldEV2ZW50VmFsdWUoZXZlbnQpO1xuICAgICAgICBpZiAoIWdldChjb250cm9sLl9maWVsZHMsIG5hbWUpKSB7XG4gICAgICAgICAgICBfcmVnaXN0ZXJQcm9wcy5jdXJyZW50ID0gY29udHJvbC5yZWdpc3RlcihuYW1lLCB7XG4gICAgICAgICAgICAgICAgLi4uX3Byb3BzLmN1cnJlbnQucnVsZXMsXG4gICAgICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gX3JlZ2lzdGVyUHJvcHMuY3VycmVudC5vbkNoYW5nZSh7XG4gICAgICAgICAgICB0YXJnZXQ6IHtcbiAgICAgICAgICAgICAgICB2YWx1ZTogZ2V0RXZlbnRWYWx1ZShldmVudCksXG4gICAgICAgICAgICAgICAgbmFtZTogbmFtZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB0eXBlOiBFVkVOVFMuQ0hBTkdFLFxuICAgICAgICB9KTtcbiAgICB9LCBbbmFtZSwgY29udHJvbF0pO1xuICAgIGNvbnN0IG9uQmx1ciA9IFJlYWN0LnVzZUNhbGxiYWNrKCgpID0+IF9yZWdpc3RlclByb3BzLmN1cnJlbnQub25CbHVyKHtcbiAgICAgICAgdGFyZ2V0OiB7XG4gICAgICAgICAgICB2YWx1ZTogZ2V0KGNvbnRyb2wuX2Zvcm1WYWx1ZXMsIG5hbWUpLFxuICAgICAgICAgICAgbmFtZTogbmFtZSxcbiAgICAgICAgfSxcbiAgICAgICAgdHlwZTogRVZFTlRTLkJMVVIsXG4gICAgfSksIFtuYW1lLCBjb250cm9sLl9mb3JtVmFsdWVzXSk7XG4gICAgY29uc3QgcmVmID0gUmVhY3QudXNlQ2FsbGJhY2soKGVsbSkgPT4ge1xuICAgICAgICBpZiAoZWxtKSB7XG4gICAgICAgICAgICBfcHJveHlSZWYuY3VycmVudCA9IHtcbiAgICAgICAgICAgICAgICBmb2N1czogKCkgPT4gaXNGdW5jdGlvbihlbG0uZm9jdXMpICYmIGVsbS5mb2N1cygpLFxuICAgICAgICAgICAgICAgIHNlbGVjdDogKCkgPT4gaXNGdW5jdGlvbihlbG0uc2VsZWN0KSAmJiBlbG0uc2VsZWN0KCksXG4gICAgICAgICAgICAgICAgc2V0Q3VzdG9tVmFsaWRpdHk6IChtZXNzYWdlKSA9PiBpc0Z1bmN0aW9uKGVsbS5zZXRDdXN0b21WYWxpZGl0eSkgJiYgZWxtLnNldEN1c3RvbVZhbGlkaXR5KG1lc3NhZ2UpLFxuICAgICAgICAgICAgICAgIHJlcG9ydFZhbGlkaXR5OiAoKSA9PiBpc0Z1bmN0aW9uKGVsbS5yZXBvcnRWYWxpZGl0eSkgJiYgZWxtLnJlcG9ydFZhbGlkaXR5KCksXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KGNvbnRyb2wuX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgIGlmIChmaWVsZCAmJiBmaWVsZC5fZiAmJiBlbG0pIHtcbiAgICAgICAgICAgIGZpZWxkLl9mLnJlZiA9IF9wcm94eVJlZi5jdXJyZW50O1xuICAgICAgICB9XG4gICAgfSwgW2NvbnRyb2wuX2ZpZWxkcywgbmFtZV0pO1xuICAgIGNvbnN0IGZpZWxkID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgICAgICBuYW1lLFxuICAgICAgICB2YWx1ZSxcbiAgICAgICAgLi4uKGlzQm9vbGVhbihkaXNhYmxlZCkgfHwgZm9ybVN0YXRlLmRpc2FibGVkXG4gICAgICAgICAgICA/IHsgZGlzYWJsZWQ6IGZvcm1TdGF0ZS5kaXNhYmxlZCB8fCBkaXNhYmxlZCB9XG4gICAgICAgICAgICA6IHt9KSxcbiAgICAgICAgb25DaGFuZ2UsXG4gICAgICAgIG9uQmx1cixcbiAgICAgICAgcmVmLFxuICAgIH0pLCBbbmFtZSwgZGlzYWJsZWQsIGZvcm1TdGF0ZS5kaXNhYmxlZCwgb25DaGFuZ2UsIG9uQmx1ciwgcmVmLCB2YWx1ZV0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IF9zaG91bGRVbnJlZ2lzdGVyRmllbGQgPSBjb250cm9sLl9vcHRpb25zLnNob3VsZFVucmVnaXN0ZXIgfHwgc2hvdWxkVW5yZWdpc3RlcjtcbiAgICAgICAgX3JlZ2lzdGVyUHJvcHMuY3VycmVudCA9IGNvbnRyb2wucmVnaXN0ZXIobmFtZSwge1xuICAgICAgICAgICAgLi4uX3Byb3BzLmN1cnJlbnQucnVsZXMsXG4gICAgICAgICAgICAuLi4oaXNCb29sZWFuKF9wcm9wcy5jdXJyZW50LmRpc2FibGVkKVxuICAgICAgICAgICAgICAgID8geyBkaXNhYmxlZDogX3Byb3BzLmN1cnJlbnQuZGlzYWJsZWQgfVxuICAgICAgICAgICAgICAgIDoge30pLFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgdXBkYXRlTW91bnRlZCA9IChuYW1lLCB2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoY29udHJvbC5fZmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgIGlmIChmaWVsZCAmJiBmaWVsZC5fZikge1xuICAgICAgICAgICAgICAgIGZpZWxkLl9mLm1vdW50ID0gdmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIHVwZGF0ZU1vdW50ZWQobmFtZSwgdHJ1ZSk7XG4gICAgICAgIGlmIChfc2hvdWxkVW5yZWdpc3RlckZpZWxkKSB7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGNsb25lT2JqZWN0KGdldChzaG91bGRVbnJlZ2lzdGVyXG4gICAgICAgICAgICAgICAgPyBjb250cm9sLl9kZWZhdWx0VmFsdWVzXG4gICAgICAgICAgICAgICAgOiBjb250cm9sLl9vcHRpb25zLnZhbHVlcyB8fCBjb250cm9sLl9kZWZhdWx0VmFsdWVzLCBuYW1lLCBnZXQoY29udHJvbC5fb3B0aW9ucy5kZWZhdWx0VmFsdWVzLCBuYW1lLCBfcHJvcHMuY3VycmVudC5kZWZhdWx0VmFsdWUpKSk7XG4gICAgICAgICAgICBzZXQoY29udHJvbC5fZGVmYXVsdFZhbHVlcywgbmFtZSwgdmFsdWUpO1xuICAgICAgICAgICAgaWYgKGlzVW5kZWZpbmVkKGdldChjb250cm9sLl9mb3JtVmFsdWVzLCBuYW1lKSkpIHtcbiAgICAgICAgICAgICAgICBzZXQoY29udHJvbC5fZm9ybVZhbHVlcywgbmFtZSwgdmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgICFpc0FycmF5RmllbGQgJiYgY29udHJvbC5yZWdpc3RlcihuYW1lKTtcbiAgICAgICAgaWYgKF9wcm94eVJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICBjb25zdCBmaWVsZCA9IGdldChjb250cm9sLl9maWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgaWYgKGZpZWxkICYmIGZpZWxkLl9mKSB7XG4gICAgICAgICAgICAgICAgZmllbGQuX2YucmVmID0gX3Byb3h5UmVmLmN1cnJlbnQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIChpc0FycmF5RmllbGRcbiAgICAgICAgICAgICAgICA/IF9zaG91bGRVbnJlZ2lzdGVyRmllbGQgJiYgIWNvbnRyb2wuX3N0YXRlLmFjdGlvblxuICAgICAgICAgICAgICAgIDogX3Nob3VsZFVucmVnaXN0ZXJGaWVsZClcbiAgICAgICAgICAgICAgICA/IGNvbnRyb2wudW5yZWdpc3RlcihuYW1lKVxuICAgICAgICAgICAgICAgIDogdXBkYXRlTW91bnRlZChuYW1lLCBmYWxzZSk7XG4gICAgICAgIH07XG4gICAgfSwgW25hbWUsIGNvbnRyb2wsIGlzQXJyYXlGaWVsZCwgc2hvdWxkVW5yZWdpc3Rlcl0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnRyb2wuX3NldERpc2FibGVkRmllbGQoe1xuICAgICAgICAgICAgZGlzYWJsZWQsXG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICB9KTtcbiAgICB9LCBbZGlzYWJsZWQsIG5hbWUsIGNvbnRyb2xdKTtcbiAgICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgICAgICBmaWVsZCxcbiAgICAgICAgZm9ybVN0YXRlLFxuICAgICAgICBmaWVsZFN0YXRlLFxuICAgIH0pLCBbZmllbGQsIGZvcm1TdGF0ZSwgZmllbGRTdGF0ZV0pO1xufVxuXG4vKipcbiAqIENvbXBvbmVudCBiYXNlZCBvbiBgdXNlQ29udHJvbGxlcmAgaG9vayB0byB3b3JrIHdpdGggY29udHJvbGxlZCBjb21wb25lbnQuXG4gKlxuICogQHJlbWFya3NcbiAqIFtBUEldKGh0dHBzOi8vcmVhY3QtaG9vay1mb3JtLmNvbS9kb2NzL3VzZWNvbnRyb2xsZXIvY29udHJvbGxlcikg4oCiIFtEZW1vXShodHRwczovL2NvZGVzYW5kYm94LmlvL3MvcmVhY3QtaG9vay1mb3JtLXY2LWNvbnRyb2xsZXItdHMtand5encpIOKAoiBbVmlkZW9dKGh0dHBzOi8vd3d3LnlvdXR1YmUuY29tL3dhdGNoP3Y9TjJVTmtfVUNWeUEpXG4gKlxuICogQHBhcmFtIHByb3BzIC0gdGhlIHBhdGggbmFtZSB0byB0aGUgZm9ybSBmaWVsZCB2YWx1ZSwgYW5kIHZhbGlkYXRpb24gcnVsZXMuXG4gKlxuICogQHJldHVybnMgcHJvdmlkZSBmaWVsZCBoYW5kbGVyIGZ1bmN0aW9ucywgZmllbGQgYW5kIGZvcm0gc3RhdGUuXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogZnVuY3Rpb24gQXBwKCkge1xuICogICBjb25zdCB7IGNvbnRyb2wgfSA9IHVzZUZvcm08Rm9ybVZhbHVlcz4oe1xuICogICAgIGRlZmF1bHRWYWx1ZXM6IHtcbiAqICAgICAgIHRlc3Q6IFwiXCJcbiAqICAgICB9XG4gKiAgIH0pO1xuICpcbiAqICAgcmV0dXJuIChcbiAqICAgICA8Zm9ybT5cbiAqICAgICAgIDxDb250cm9sbGVyXG4gKiAgICAgICAgIGNvbnRyb2w9e2NvbnRyb2x9XG4gKiAgICAgICAgIG5hbWU9XCJ0ZXN0XCJcbiAqICAgICAgICAgcmVuZGVyPXsoeyBmaWVsZDogeyBvbkNoYW5nZSwgb25CbHVyLCB2YWx1ZSwgcmVmIH0sIGZvcm1TdGF0ZSwgZmllbGRTdGF0ZSB9KSA9PiAoXG4gKiAgICAgICAgICAgPD5cbiAqICAgICAgICAgICAgIDxpbnB1dFxuICogICAgICAgICAgICAgICBvbkNoYW5nZT17b25DaGFuZ2V9IC8vIHNlbmQgdmFsdWUgdG8gaG9vayBmb3JtXG4gKiAgICAgICAgICAgICAgIG9uQmx1cj17b25CbHVyfSAvLyBub3RpZnkgd2hlbiBpbnB1dCBpcyB0b3VjaGVkXG4gKiAgICAgICAgICAgICAgIHZhbHVlPXt2YWx1ZX0gLy8gcmV0dXJuIHVwZGF0ZWQgdmFsdWVcbiAqICAgICAgICAgICAgICAgcmVmPXtyZWZ9IC8vIHNldCByZWYgZm9yIGZvY3VzIG1hbmFnZW1lbnRcbiAqICAgICAgICAgICAgIC8+XG4gKiAgICAgICAgICAgICA8cD57Zm9ybVN0YXRlLmlzU3VibWl0dGVkID8gXCJzdWJtaXR0ZWRcIiA6IFwiXCJ9PC9wPlxuICogICAgICAgICAgICAgPHA+e2ZpZWxkU3RhdGUuaXNUb3VjaGVkID8gXCJ0b3VjaGVkXCIgOiBcIlwifTwvcD5cbiAqICAgICAgICAgICA8Lz5cbiAqICAgICAgICAgKX1cbiAqICAgICAgIC8+XG4gKiAgICAgPC9mb3JtPlxuICogICApO1xuICogfVxuICogYGBgXG4gKi9cbmNvbnN0IENvbnRyb2xsZXIgPSAocHJvcHMpID0+IHByb3BzLnJlbmRlcih1c2VDb250cm9sbGVyKHByb3BzKSk7XG5cbnZhciBnZW5lcmF0ZUlkID0gKCkgPT4ge1xuICAgIGlmICh0eXBlb2YgY3J5cHRvICE9PSAndW5kZWZpbmVkJyAmJiBjcnlwdG8ucmFuZG9tVVVJRCkge1xuICAgICAgICByZXR1cm4gY3J5cHRvLnJhbmRvbVVVSUQoKTtcbiAgICB9XG4gICAgY29uc3QgZCA9IHR5cGVvZiBwZXJmb3JtYW5jZSA9PT0gJ3VuZGVmaW5lZCcgPyBEYXRlLm5vdygpIDogcGVyZm9ybWFuY2Uubm93KCkgKiAxMDAwO1xuICAgIHJldHVybiAneHh4eHh4eHgteHh4eC00eHh4LXl4eHgteHh4eHh4eHh4eHh4Jy5yZXBsYWNlKC9beHldL2csIChjKSA9PiB7XG4gICAgICAgIGNvbnN0IHIgPSAoKE1hdGgucmFuZG9tKCkgKiAxNiArIGQpICUgMTYpIHwgMDtcbiAgICAgICAgcmV0dXJuIChjID09ICd4JyA/IHIgOiAociAmIDB4MykgfCAweDgpLnRvU3RyaW5nKDE2KTtcbiAgICB9KTtcbn07XG5cbnZhciBnZXRGb2N1c0ZpZWxkTmFtZSA9IChuYW1lLCBpbmRleCwgb3B0aW9ucyA9IHt9KSA9PiBvcHRpb25zLnNob3VsZEZvY3VzIHx8IGlzVW5kZWZpbmVkKG9wdGlvbnMuc2hvdWxkRm9jdXMpXG4gICAgPyBvcHRpb25zLmZvY3VzTmFtZSB8fFxuICAgICAgICBgJHtuYW1lfS4ke2lzVW5kZWZpbmVkKG9wdGlvbnMuZm9jdXNJbmRleCkgPyBpbmRleCA6IG9wdGlvbnMuZm9jdXNJbmRleH0uYFxuICAgIDogJyc7XG5cbnZhciBnZXRWYWxpZGF0aW9uTW9kZXMgPSAobW9kZSkgPT4gKHtcbiAgICBpc09uU3VibWl0OiAhbW9kZSB8fCBtb2RlID09PSBWQUxJREFUSU9OX01PREUub25TdWJtaXQsXG4gICAgaXNPbkJsdXI6IG1vZGUgPT09IFZBTElEQVRJT05fTU9ERS5vbkJsdXIsXG4gICAgaXNPbkNoYW5nZTogbW9kZSA9PT0gVkFMSURBVElPTl9NT0RFLm9uQ2hhbmdlLFxuICAgIGlzT25BbGw6IG1vZGUgPT09IFZBTElEQVRJT05fTU9ERS5hbGwsXG4gICAgaXNPblRvdWNoOiBtb2RlID09PSBWQUxJREFUSU9OX01PREUub25Ub3VjaGVkLFxufSk7XG5cbnZhciBpc1dhdGNoZWQgPSAobmFtZSwgX25hbWVzLCBpc0JsdXJFdmVudCkgPT4ge1xuICAgIGlmIChpc0JsdXJFdmVudClcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIGlmIChfbmFtZXMud2F0Y2hBbGwgfHwgX25hbWVzLndhdGNoLmhhcyhuYW1lKSlcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgZm9yIChjb25zdCB3YXRjaE5hbWUgb2YgX25hbWVzLndhdGNoKSB7XG4gICAgICAgIGlmIChuYW1lLnN0YXJ0c1dpdGgod2F0Y2hOYW1lKSAmJiBuYW1lLmNoYXJBdCh3YXRjaE5hbWUubGVuZ3RoKSA9PT0gJy4nKVxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbn07XG5cbmNvbnN0IGl0ZXJhdGVGaWVsZHNCeUFjdGlvbiA9IChmaWVsZHMsIGFjdGlvbiwgZmllbGRzTmFtZXMsIGFib3J0RWFybHkpID0+IHtcbiAgICBmb3IgKGNvbnN0IGtleSBvZiBmaWVsZHNOYW1lcyB8fCBPYmplY3Qua2V5cyhmaWVsZHMpKSB7XG4gICAgICAgIGlmIChrZXkgPT09ICdfZicpIHtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGZpZWxkID0gZmllbGRzTmFtZXMgPyBnZXQoZmllbGRzLCBrZXkpIDogZmllbGRzW2tleV07XG4gICAgICAgIGlmIChmaWVsZCkge1xuICAgICAgICAgICAgY29uc3QgeyBfZiB9ID0gZmllbGQ7XG4gICAgICAgICAgICBpZiAoX2YpIHtcbiAgICAgICAgICAgICAgICBpZiAoX2YucmVmcyAmJiBfZi5yZWZzWzBdICYmIGFjdGlvbihfZi5yZWZzWzBdLCBrZXkpICYmICFhYm9ydEVhcmx5KSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChfZi5yZWYgJiYgYWN0aW9uKF9mLnJlZiwgX2YubmFtZSkgJiYgIWFib3J0RWFybHkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBpZiAoaXRlcmF0ZUZpZWxkc0J5QWN0aW9uKGZpZWxkLCBhY3Rpb24pKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGlzT2JqZWN0KGZpZWxkKSB8fCBBcnJheS5pc0FycmF5KGZpZWxkKSkge1xuICAgICAgICAgICAgICAgIGlmIChpdGVyYXRlRmllbGRzQnlBY3Rpb24oZmllbGQsIGFjdGlvbikpIHtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybjtcbn07XG5cbnZhciB1cGRhdGVGaWVsZEFycmF5Um9vdEVycm9yID0gKGVycm9ycywgZXJyb3IsIG5hbWUpID0+IHtcbiAgICBjb25zdCBleGlzdGluZ0Vycm9ycyA9IGdldChlcnJvcnMsIG5hbWUpO1xuICAgIGNvbnN0IGZpZWxkQXJyYXlFcnJvcnMgPSBBcnJheS5pc0FycmF5KGV4aXN0aW5nRXJyb3JzKSA/IGV4aXN0aW5nRXJyb3JzIDogW107XG4gICAgc2V0KGZpZWxkQXJyYXlFcnJvcnMsIFJPT1RfRVJST1JfVFlQRSwgZXJyb3JbbmFtZV0pO1xuICAgIHNldChlcnJvcnMsIG5hbWUsIGZpZWxkQXJyYXlFcnJvcnMpO1xuICAgIHJldHVybiBlcnJvcnM7XG59O1xuXG52YXIgaXNFbXB0eU9iamVjdCA9ICh2YWx1ZSkgPT4gaXNPYmplY3QodmFsdWUpICYmICFPYmplY3Qua2V5cyh2YWx1ZSkubGVuZ3RoO1xuXG52YXIgaXNIVE1MRWxlbWVudCA9ICh2YWx1ZSkgPT4ge1xuICAgIGlmICghaXNXZWIpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBvd25lciA9IHZhbHVlID8gdmFsdWUub3duZXJEb2N1bWVudCA6IDA7XG4gICAgcmV0dXJuICh2YWx1ZSBpbnN0YW5jZW9mXG4gICAgICAgIChvd25lciAmJiBvd25lci5kZWZhdWx0VmlldyA/IG93bmVyLmRlZmF1bHRWaWV3LkhUTUxFbGVtZW50IDogSFRNTEVsZW1lbnQpKTtcbn07XG5cbnZhciBpc1JhZGlvSW5wdXQgPSAoZWxlbWVudCkgPT4gZWxlbWVudC50eXBlID09PSAncmFkaW8nO1xuXG52YXIgaXNSZWdleCA9ICh2YWx1ZSkgPT4gdmFsdWUgaW5zdGFuY2VvZiBSZWdFeHA7XG5cbnZhciBhcHBlbmRFcnJvcnMgPSAobmFtZSwgdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhLCBlcnJvcnMsIHR5cGUsIG1lc3NhZ2UpID0+IHZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYVxuICAgID8ge1xuICAgICAgICAuLi5lcnJvcnNbbmFtZV0sXG4gICAgICAgIHR5cGVzOiB7XG4gICAgICAgICAgICAuLi4oZXJyb3JzW25hbWVdICYmIGVycm9yc1tuYW1lXS50eXBlcyA/IGVycm9yc1tuYW1lXS50eXBlcyA6IHt9KSxcbiAgICAgICAgICAgIFt0eXBlXTogbWVzc2FnZSB8fCB0cnVlLFxuICAgICAgICB9LFxuICAgIH1cbiAgICA6IHt9O1xuXG5jb25zdCBkZWZhdWx0UmVzdWx0ID0ge1xuICAgIHZhbHVlOiBmYWxzZSxcbiAgICBpc1ZhbGlkOiBmYWxzZSxcbn07XG5jb25zdCB2YWxpZFJlc3VsdCA9IHsgdmFsdWU6IHRydWUsIGlzVmFsaWQ6IHRydWUgfTtcbnZhciBnZXRDaGVja2JveFZhbHVlID0gKG9wdGlvbnMpID0+IHtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShvcHRpb25zKSkge1xuICAgICAgICBpZiAob3B0aW9ucy5sZW5ndGggPiAxKSB7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZXMgPSBvcHRpb25zXG4gICAgICAgICAgICAgICAgLmZpbHRlcigob3B0aW9uKSA9PiBvcHRpb24gJiYgb3B0aW9uLmNoZWNrZWQgJiYgIW9wdGlvbi5kaXNhYmxlZClcbiAgICAgICAgICAgICAgICAubWFwKChvcHRpb24pID0+IG9wdGlvbi52YWx1ZSk7XG4gICAgICAgICAgICByZXR1cm4geyB2YWx1ZTogdmFsdWVzLCBpc1ZhbGlkOiAhIXZhbHVlcy5sZW5ndGggfTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gb3B0aW9uc1swXS5jaGVja2VkICYmICFvcHRpb25zWzBdLmRpc2FibGVkXG4gICAgICAgICAgICA/IC8vIEB0cy1leHBlY3QtZXJyb3IgZXhwZWN0ZWQgdG8gd29yayBpbiB0aGUgYnJvd3NlclxuICAgICAgICAgICAgICAgIG9wdGlvbnNbMF0uYXR0cmlidXRlcyAmJiAhaXNVbmRlZmluZWQob3B0aW9uc1swXS5hdHRyaWJ1dGVzLnZhbHVlKVxuICAgICAgICAgICAgICAgICAgICA/IGlzVW5kZWZpbmVkKG9wdGlvbnNbMF0udmFsdWUpIHx8IG9wdGlvbnNbMF0udmFsdWUgPT09ICcnXG4gICAgICAgICAgICAgICAgICAgICAgICA/IHZhbGlkUmVzdWx0XG4gICAgICAgICAgICAgICAgICAgICAgICA6IHsgdmFsdWU6IG9wdGlvbnNbMF0udmFsdWUsIGlzVmFsaWQ6IHRydWUgfVxuICAgICAgICAgICAgICAgICAgICA6IHZhbGlkUmVzdWx0XG4gICAgICAgICAgICA6IGRlZmF1bHRSZXN1bHQ7XG4gICAgfVxuICAgIHJldHVybiBkZWZhdWx0UmVzdWx0O1xufTtcblxuY29uc3QgZGVmYXVsdFJldHVybiA9IHtcbiAgICBpc1ZhbGlkOiBmYWxzZSxcbiAgICB2YWx1ZTogbnVsbCxcbn07XG52YXIgZ2V0UmFkaW9WYWx1ZSA9IChvcHRpb25zKSA9PiBBcnJheS5pc0FycmF5KG9wdGlvbnMpXG4gICAgPyBvcHRpb25zLnJlZHVjZSgocHJldmlvdXMsIG9wdGlvbikgPT4gb3B0aW9uICYmIG9wdGlvbi5jaGVja2VkICYmICFvcHRpb24uZGlzYWJsZWRcbiAgICAgICAgPyB7XG4gICAgICAgICAgICBpc1ZhbGlkOiB0cnVlLFxuICAgICAgICAgICAgdmFsdWU6IG9wdGlvbi52YWx1ZSxcbiAgICAgICAgfVxuICAgICAgICA6IHByZXZpb3VzLCBkZWZhdWx0UmV0dXJuKVxuICAgIDogZGVmYXVsdFJldHVybjtcblxuZnVuY3Rpb24gZ2V0VmFsaWRhdGVFcnJvcihyZXN1bHQsIHJlZiwgdHlwZSA9ICd2YWxpZGF0ZScpIHtcbiAgICBpZiAoaXNTdHJpbmcocmVzdWx0KSB8fFxuICAgICAgICAoQXJyYXkuaXNBcnJheShyZXN1bHQpICYmIHJlc3VsdC5ldmVyeShpc1N0cmluZykpIHx8XG4gICAgICAgIChpc0Jvb2xlYW4ocmVzdWx0KSAmJiAhcmVzdWx0KSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgdHlwZSxcbiAgICAgICAgICAgIG1lc3NhZ2U6IGlzU3RyaW5nKHJlc3VsdCkgPyByZXN1bHQgOiAnJyxcbiAgICAgICAgICAgIHJlZixcbiAgICAgICAgfTtcbiAgICB9XG59XG5cbnZhciBnZXRWYWx1ZUFuZE1lc3NhZ2UgPSAodmFsaWRhdGlvbkRhdGEpID0+IGlzT2JqZWN0KHZhbGlkYXRpb25EYXRhKSAmJiAhaXNSZWdleCh2YWxpZGF0aW9uRGF0YSlcbiAgICA/IHZhbGlkYXRpb25EYXRhXG4gICAgOiB7XG4gICAgICAgIHZhbHVlOiB2YWxpZGF0aW9uRGF0YSxcbiAgICAgICAgbWVzc2FnZTogJycsXG4gICAgfTtcblxudmFyIHZhbGlkYXRlRmllbGQgPSBhc3luYyAoZmllbGQsIGRpc2FibGVkRmllbGROYW1lcywgZm9ybVZhbHVlcywgdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhLCBzaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uLCBpc0ZpZWxkQXJyYXkpID0+IHtcbiAgICBjb25zdCB7IHJlZiwgcmVmcywgcmVxdWlyZWQsIG1heExlbmd0aCwgbWluTGVuZ3RoLCBtaW4sIG1heCwgcGF0dGVybiwgdmFsaWRhdGUsIG5hbWUsIHZhbHVlQXNOdW1iZXIsIG1vdW50LCB9ID0gZmllbGQuX2Y7XG4gICAgY29uc3QgaW5wdXRWYWx1ZSA9IGdldChmb3JtVmFsdWVzLCBuYW1lKTtcbiAgICBpZiAoIW1vdW50IHx8IGRpc2FibGVkRmllbGROYW1lcy5oYXMobmFtZSkpIHtcbiAgICAgICAgcmV0dXJuIHt9O1xuICAgIH1cbiAgICBjb25zdCBpbnB1dFJlZiA9IHJlZnMgPyByZWZzWzBdIDogcmVmO1xuICAgIGNvbnN0IHNldEN1c3RvbVZhbGlkaXR5ID0gKG1lc3NhZ2UpID0+IHtcbiAgICAgICAgaWYgKHNob3VsZFVzZU5hdGl2ZVZhbGlkYXRpb24gJiYgaW5wdXRSZWYucmVwb3J0VmFsaWRpdHkpIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbGlkaXR5TWVzc2FnZSA9IGlzQm9vbGVhbihtZXNzYWdlKSA/ICcnIDogbWVzc2FnZSB8fCAnJztcbiAgICAgICAgICAgIGlmIChyZWZzKSB7XG4gICAgICAgICAgICAgICAgcmVmcy5mb3JFYWNoKChyZWYpID0+IHJlZi5zZXRDdXN0b21WYWxpZGl0eSh2YWxpZGl0eU1lc3NhZ2UpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGlucHV0UmVmLnNldEN1c3RvbVZhbGlkaXR5KHZhbGlkaXR5TWVzc2FnZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpbnB1dFJlZi5yZXBvcnRWYWxpZGl0eSgpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBlcnJvciA9IHt9O1xuICAgIGNvbnN0IGlzUmFkaW8gPSBpc1JhZGlvSW5wdXQocmVmKTtcbiAgICBjb25zdCBpc0NoZWNrQm94ID0gaXNDaGVja0JveElucHV0KHJlZik7XG4gICAgY29uc3QgaXNSYWRpb09yQ2hlY2tib3ggPSBpc1JhZGlvIHx8IGlzQ2hlY2tCb3g7XG4gICAgY29uc3QgaXNFbXB0eSA9ICgodmFsdWVBc051bWJlciB8fCBpc0ZpbGVJbnB1dChyZWYpKSAmJlxuICAgICAgICBpc1VuZGVmaW5lZChyZWYudmFsdWUpICYmXG4gICAgICAgIGlzVW5kZWZpbmVkKGlucHV0VmFsdWUpKSB8fFxuICAgICAgICAoaXNIVE1MRWxlbWVudChyZWYpICYmIHJlZi52YWx1ZSA9PT0gJycpIHx8XG4gICAgICAgIGlucHV0VmFsdWUgPT09ICcnIHx8XG4gICAgICAgIChBcnJheS5pc0FycmF5KGlucHV0VmFsdWUpICYmICFpbnB1dFZhbHVlLmxlbmd0aCk7XG4gICAgY29uc3QgYXBwZW5kRXJyb3JzQ3VycnkgPSBhcHBlbmRFcnJvcnMuYmluZChudWxsLCBuYW1lLCB2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEsIGVycm9yKTtcbiAgICBjb25zdCBnZXRNaW5NYXhNZXNzYWdlID0gKGV4Y2VlZE1heCwgbWF4TGVuZ3RoTWVzc2FnZSwgbWluTGVuZ3RoTWVzc2FnZSwgbWF4VHlwZSA9IElOUFVUX1ZBTElEQVRJT05fUlVMRVMubWF4TGVuZ3RoLCBtaW5UeXBlID0gSU5QVVRfVkFMSURBVElPTl9SVUxFUy5taW5MZW5ndGgpID0+IHtcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IGV4Y2VlZE1heCA/IG1heExlbmd0aE1lc3NhZ2UgOiBtaW5MZW5ndGhNZXNzYWdlO1xuICAgICAgICBlcnJvcltuYW1lXSA9IHtcbiAgICAgICAgICAgIHR5cGU6IGV4Y2VlZE1heCA/IG1heFR5cGUgOiBtaW5UeXBlLFxuICAgICAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgICAgIHJlZixcbiAgICAgICAgICAgIC4uLmFwcGVuZEVycm9yc0N1cnJ5KGV4Y2VlZE1heCA/IG1heFR5cGUgOiBtaW5UeXBlLCBtZXNzYWdlKSxcbiAgICAgICAgfTtcbiAgICB9O1xuICAgIGlmIChpc0ZpZWxkQXJyYXlcbiAgICAgICAgPyAhQXJyYXkuaXNBcnJheShpbnB1dFZhbHVlKSB8fCAhaW5wdXRWYWx1ZS5sZW5ndGhcbiAgICAgICAgOiByZXF1aXJlZCAmJlxuICAgICAgICAgICAgKCghaXNSYWRpb09yQ2hlY2tib3ggJiYgKGlzRW1wdHkgfHwgaXNOdWxsT3JVbmRlZmluZWQoaW5wdXRWYWx1ZSkpKSB8fFxuICAgICAgICAgICAgICAgIChpc0Jvb2xlYW4oaW5wdXRWYWx1ZSkgJiYgIWlucHV0VmFsdWUpIHx8XG4gICAgICAgICAgICAgICAgKGlzQ2hlY2tCb3ggJiYgIWdldENoZWNrYm94VmFsdWUocmVmcykuaXNWYWxpZCkgfHxcbiAgICAgICAgICAgICAgICAoaXNSYWRpbyAmJiAhZ2V0UmFkaW9WYWx1ZShyZWZzKS5pc1ZhbGlkKSkpIHtcbiAgICAgICAgY29uc3QgeyB2YWx1ZSwgbWVzc2FnZSB9ID0gaXNTdHJpbmcocmVxdWlyZWQpXG4gICAgICAgICAgICA/IHsgdmFsdWU6ICEhcmVxdWlyZWQsIG1lc3NhZ2U6IHJlcXVpcmVkIH1cbiAgICAgICAgICAgIDogZ2V0VmFsdWVBbmRNZXNzYWdlKHJlcXVpcmVkKTtcbiAgICAgICAgaWYgKHZhbHVlKSB7XG4gICAgICAgICAgICBlcnJvcltuYW1lXSA9IHtcbiAgICAgICAgICAgICAgICB0eXBlOiBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLnJlcXVpcmVkLFxuICAgICAgICAgICAgICAgIG1lc3NhZ2UsXG4gICAgICAgICAgICAgICAgcmVmOiBpbnB1dFJlZixcbiAgICAgICAgICAgICAgICAuLi5hcHBlbmRFcnJvcnNDdXJyeShJTlBVVF9WQUxJREFUSU9OX1JVTEVTLnJlcXVpcmVkLCBtZXNzYWdlKSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBpZiAoIXZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYSkge1xuICAgICAgICAgICAgICAgIHNldEN1c3RvbVZhbGlkaXR5KG1lc3NhZ2UpO1xuICAgICAgICAgICAgICAgIHJldHVybiBlcnJvcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAoIWlzRW1wdHkgJiYgKCFpc051bGxPclVuZGVmaW5lZChtaW4pIHx8ICFpc051bGxPclVuZGVmaW5lZChtYXgpKSkge1xuICAgICAgICBsZXQgZXhjZWVkTWF4O1xuICAgICAgICBsZXQgZXhjZWVkTWluO1xuICAgICAgICBjb25zdCBtYXhPdXRwdXQgPSBnZXRWYWx1ZUFuZE1lc3NhZ2UobWF4KTtcbiAgICAgICAgY29uc3QgbWluT3V0cHV0ID0gZ2V0VmFsdWVBbmRNZXNzYWdlKG1pbik7XG4gICAgICAgIGlmICghaXNOdWxsT3JVbmRlZmluZWQoaW5wdXRWYWx1ZSkgJiZcbiAgICAgICAgICAgICFpc0RhdGVPYmplY3QoaW5wdXRWYWx1ZSkgJiZcbiAgICAgICAgICAgICFpc05hTihpbnB1dFZhbHVlKSkge1xuICAgICAgICAgICAgY29uc3QgdmFsdWVOdW1iZXIgPSByZWYudmFsdWVBc051bWJlciB8fFxuICAgICAgICAgICAgICAgIChpbnB1dFZhbHVlID8gK2lucHV0VmFsdWUgOiBpbnB1dFZhbHVlKTtcbiAgICAgICAgICAgIGlmICghaXNOdWxsT3JVbmRlZmluZWQobWF4T3V0cHV0LnZhbHVlKSkge1xuICAgICAgICAgICAgICAgIGV4Y2VlZE1heCA9IHZhbHVlTnVtYmVyID4gbWF4T3V0cHV0LnZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCFpc051bGxPclVuZGVmaW5lZChtaW5PdXRwdXQudmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgZXhjZWVkTWluID0gdmFsdWVOdW1iZXIgPCBtaW5PdXRwdXQudmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZURhdGUgPSByZWYudmFsdWVBc0RhdGUgfHwgbmV3IERhdGUoaW5wdXRWYWx1ZSk7XG4gICAgICAgICAgICBjb25zdCBjb252ZXJ0VGltZVRvRGF0ZSA9ICh0aW1lKSA9PiBuZXcgRGF0ZShuZXcgRGF0ZSgpLnRvRGF0ZVN0cmluZygpICsgJyAnICsgdGltZSk7XG4gICAgICAgICAgICBjb25zdCBpc1RpbWUgPSByZWYudHlwZSA9PSAndGltZSc7XG4gICAgICAgICAgICBjb25zdCBpc1dlZWsgPSByZWYudHlwZSA9PSAnd2Vlayc7XG4gICAgICAgICAgICBpZiAoaXNTdHJpbmcobWF4T3V0cHV0LnZhbHVlKSAmJiBpbnB1dFZhbHVlKSB7XG4gICAgICAgICAgICAgICAgZXhjZWVkTWF4ID0gaXNUaW1lXG4gICAgICAgICAgICAgICAgICAgID8gY29udmVydFRpbWVUb0RhdGUoaW5wdXRWYWx1ZSkgPiBjb252ZXJ0VGltZVRvRGF0ZShtYXhPdXRwdXQudmFsdWUpXG4gICAgICAgICAgICAgICAgICAgIDogaXNXZWVrXG4gICAgICAgICAgICAgICAgICAgICAgICA/IGlucHV0VmFsdWUgPiBtYXhPdXRwdXQudmFsdWVcbiAgICAgICAgICAgICAgICAgICAgICAgIDogdmFsdWVEYXRlID4gbmV3IERhdGUobWF4T3V0cHV0LnZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpc1N0cmluZyhtaW5PdXRwdXQudmFsdWUpICYmIGlucHV0VmFsdWUpIHtcbiAgICAgICAgICAgICAgICBleGNlZWRNaW4gPSBpc1RpbWVcbiAgICAgICAgICAgICAgICAgICAgPyBjb252ZXJ0VGltZVRvRGF0ZShpbnB1dFZhbHVlKSA8IGNvbnZlcnRUaW1lVG9EYXRlKG1pbk91dHB1dC52YWx1ZSlcbiAgICAgICAgICAgICAgICAgICAgOiBpc1dlZWtcbiAgICAgICAgICAgICAgICAgICAgICAgID8gaW5wdXRWYWx1ZSA8IG1pbk91dHB1dC52YWx1ZVxuICAgICAgICAgICAgICAgICAgICAgICAgOiB2YWx1ZURhdGUgPCBuZXcgRGF0ZShtaW5PdXRwdXQudmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChleGNlZWRNYXggfHwgZXhjZWVkTWluKSB7XG4gICAgICAgICAgICBnZXRNaW5NYXhNZXNzYWdlKCEhZXhjZWVkTWF4LCBtYXhPdXRwdXQubWVzc2FnZSwgbWluT3V0cHV0Lm1lc3NhZ2UsIElOUFVUX1ZBTElEQVRJT05fUlVMRVMubWF4LCBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1pbik7XG4gICAgICAgICAgICBpZiAoIXZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYSkge1xuICAgICAgICAgICAgICAgIHNldEN1c3RvbVZhbGlkaXR5KGVycm9yW25hbWVdLm1lc3NhZ2UpO1xuICAgICAgICAgICAgICAgIHJldHVybiBlcnJvcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAoKG1heExlbmd0aCB8fCBtaW5MZW5ndGgpICYmXG4gICAgICAgICFpc0VtcHR5ICYmXG4gICAgICAgIChpc1N0cmluZyhpbnB1dFZhbHVlKSB8fCAoaXNGaWVsZEFycmF5ICYmIEFycmF5LmlzQXJyYXkoaW5wdXRWYWx1ZSkpKSkge1xuICAgICAgICBjb25zdCBtYXhMZW5ndGhPdXRwdXQgPSBnZXRWYWx1ZUFuZE1lc3NhZ2UobWF4TGVuZ3RoKTtcbiAgICAgICAgY29uc3QgbWluTGVuZ3RoT3V0cHV0ID0gZ2V0VmFsdWVBbmRNZXNzYWdlKG1pbkxlbmd0aCk7XG4gICAgICAgIGNvbnN0IGV4Y2VlZE1heCA9ICFpc051bGxPclVuZGVmaW5lZChtYXhMZW5ndGhPdXRwdXQudmFsdWUpICYmXG4gICAgICAgICAgICBpbnB1dFZhbHVlLmxlbmd0aCA+ICttYXhMZW5ndGhPdXRwdXQudmFsdWU7XG4gICAgICAgIGNvbnN0IGV4Y2VlZE1pbiA9ICFpc051bGxPclVuZGVmaW5lZChtaW5MZW5ndGhPdXRwdXQudmFsdWUpICYmXG4gICAgICAgICAgICBpbnB1dFZhbHVlLmxlbmd0aCA8ICttaW5MZW5ndGhPdXRwdXQudmFsdWU7XG4gICAgICAgIGlmIChleGNlZWRNYXggfHwgZXhjZWVkTWluKSB7XG4gICAgICAgICAgICBnZXRNaW5NYXhNZXNzYWdlKGV4Y2VlZE1heCwgbWF4TGVuZ3RoT3V0cHV0Lm1lc3NhZ2UsIG1pbkxlbmd0aE91dHB1dC5tZXNzYWdlKTtcbiAgICAgICAgICAgIGlmICghdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhKSB7XG4gICAgICAgICAgICAgICAgc2V0Q3VzdG9tVmFsaWRpdHkoZXJyb3JbbmFtZV0ubWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGVycm9yO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGlmIChwYXR0ZXJuICYmICFpc0VtcHR5ICYmIGlzU3RyaW5nKGlucHV0VmFsdWUpKSB7XG4gICAgICAgIGNvbnN0IHsgdmFsdWU6IHBhdHRlcm5WYWx1ZSwgbWVzc2FnZSB9ID0gZ2V0VmFsdWVBbmRNZXNzYWdlKHBhdHRlcm4pO1xuICAgICAgICBpZiAoaXNSZWdleChwYXR0ZXJuVmFsdWUpICYmICFpbnB1dFZhbHVlLm1hdGNoKHBhdHRlcm5WYWx1ZSkpIHtcbiAgICAgICAgICAgIGVycm9yW25hbWVdID0ge1xuICAgICAgICAgICAgICAgIHR5cGU6IElOUFVUX1ZBTElEQVRJT05fUlVMRVMucGF0dGVybixcbiAgICAgICAgICAgICAgICBtZXNzYWdlLFxuICAgICAgICAgICAgICAgIHJlZixcbiAgICAgICAgICAgICAgICAuLi5hcHBlbmRFcnJvcnNDdXJyeShJTlBVVF9WQUxJREFUSU9OX1JVTEVTLnBhdHRlcm4sIG1lc3NhZ2UpLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGlmICghdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhKSB7XG4gICAgICAgICAgICAgICAgc2V0Q3VzdG9tVmFsaWRpdHkobWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGVycm9yO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGlmICh2YWxpZGF0ZSkge1xuICAgICAgICBpZiAoaXNGdW5jdGlvbih2YWxpZGF0ZSkpIHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHZhbGlkYXRlKGlucHV0VmFsdWUsIGZvcm1WYWx1ZXMpO1xuICAgICAgICAgICAgY29uc3QgdmFsaWRhdGVFcnJvciA9IGdldFZhbGlkYXRlRXJyb3IocmVzdWx0LCBpbnB1dFJlZik7XG4gICAgICAgICAgICBpZiAodmFsaWRhdGVFcnJvcikge1xuICAgICAgICAgICAgICAgIGVycm9yW25hbWVdID0ge1xuICAgICAgICAgICAgICAgICAgICAuLi52YWxpZGF0ZUVycm9yLFxuICAgICAgICAgICAgICAgICAgICAuLi5hcHBlbmRFcnJvcnNDdXJyeShJTlBVVF9WQUxJREFUSU9OX1JVTEVTLnZhbGlkYXRlLCB2YWxpZGF0ZUVycm9yLm1lc3NhZ2UpLFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgaWYgKCF2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEpIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0Q3VzdG9tVmFsaWRpdHkodmFsaWRhdGVFcnJvci5tZXNzYWdlKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGVycm9yO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChpc09iamVjdCh2YWxpZGF0ZSkpIHtcbiAgICAgICAgICAgIGxldCB2YWxpZGF0aW9uUmVzdWx0ID0ge307XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGtleSBpbiB2YWxpZGF0ZSkge1xuICAgICAgICAgICAgICAgIGlmICghaXNFbXB0eU9iamVjdCh2YWxpZGF0aW9uUmVzdWx0KSAmJiAhdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhKSB7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCB2YWxpZGF0ZUVycm9yID0gZ2V0VmFsaWRhdGVFcnJvcihhd2FpdCB2YWxpZGF0ZVtrZXldKGlucHV0VmFsdWUsIGZvcm1WYWx1ZXMpLCBpbnB1dFJlZiwga2V5KTtcbiAgICAgICAgICAgICAgICBpZiAodmFsaWRhdGVFcnJvcikge1xuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0aW9uUmVzdWx0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgLi4udmFsaWRhdGVFcnJvcixcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmFwcGVuZEVycm9yc0N1cnJ5KGtleSwgdmFsaWRhdGVFcnJvci5tZXNzYWdlKSxcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgc2V0Q3VzdG9tVmFsaWRpdHkodmFsaWRhdGVFcnJvci5tZXNzYWdlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3JbbmFtZV0gPSB2YWxpZGF0aW9uUmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCFpc0VtcHR5T2JqZWN0KHZhbGlkYXRpb25SZXN1bHQpKSB7XG4gICAgICAgICAgICAgICAgZXJyb3JbbmFtZV0gPSB7XG4gICAgICAgICAgICAgICAgICAgIHJlZjogaW5wdXRSZWYsXG4gICAgICAgICAgICAgICAgICAgIC4uLnZhbGlkYXRpb25SZXN1bHQsXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBpZiAoIXZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHNldEN1c3RvbVZhbGlkaXR5KHRydWUpO1xuICAgIHJldHVybiBlcnJvcjtcbn07XG5cbnZhciBjb252ZXJ0VG9BcnJheVBheWxvYWQgPSAodmFsdWUpID0+IChBcnJheS5pc0FycmF5KHZhbHVlKSA/IHZhbHVlIDogW3ZhbHVlXSk7XG5cbnZhciBhcHBlbmRBdCA9IChkYXRhLCB2YWx1ZSkgPT4gW1xuICAgIC4uLmRhdGEsXG4gICAgLi4uY29udmVydFRvQXJyYXlQYXlsb2FkKHZhbHVlKSxcbl07XG5cbnZhciBmaWxsRW1wdHlBcnJheSA9ICh2YWx1ZSkgPT4gQXJyYXkuaXNBcnJheSh2YWx1ZSkgPyB2YWx1ZS5tYXAoKCkgPT4gdW5kZWZpbmVkKSA6IHVuZGVmaW5lZDtcblxuZnVuY3Rpb24gaW5zZXJ0KGRhdGEsIGluZGV4LCB2YWx1ZSkge1xuICAgIHJldHVybiBbXG4gICAgICAgIC4uLmRhdGEuc2xpY2UoMCwgaW5kZXgpLFxuICAgICAgICAuLi5jb252ZXJ0VG9BcnJheVBheWxvYWQodmFsdWUpLFxuICAgICAgICAuLi5kYXRhLnNsaWNlKGluZGV4KSxcbiAgICBdO1xufVxuXG52YXIgbW92ZUFycmF5QXQgPSAoZGF0YSwgZnJvbSwgdG8pID0+IHtcbiAgICBpZiAoIUFycmF5LmlzQXJyYXkoZGF0YSkpIHtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbiAgICBpZiAoaXNVbmRlZmluZWQoZGF0YVt0b10pKSB7XG4gICAgICAgIGRhdGFbdG9dID0gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBkYXRhLnNwbGljZSh0bywgMCwgZGF0YS5zcGxpY2UoZnJvbSwgMSlbMF0pO1xuICAgIHJldHVybiBkYXRhO1xufTtcblxudmFyIHByZXBlbmRBdCA9IChkYXRhLCB2YWx1ZSkgPT4gW1xuICAgIC4uLmNvbnZlcnRUb0FycmF5UGF5bG9hZCh2YWx1ZSksXG4gICAgLi4uY29udmVydFRvQXJyYXlQYXlsb2FkKGRhdGEpLFxuXTtcblxudmFyIGNvbXBhY3QgPSAodmFsdWUpID0+IEFycmF5LmlzQXJyYXkodmFsdWUpID8gdmFsdWUuZmlsdGVyKEJvb2xlYW4pIDogW107XG5cbmZ1bmN0aW9uIHJlbW92ZUF0SW5kZXhlcyhkYXRhLCBpbmRleGVzKSB7XG4gICAgbGV0IGkgPSAwO1xuICAgIGNvbnN0IHRlbXAgPSBbLi4uZGF0YV07XG4gICAgZm9yIChjb25zdCBpbmRleCBvZiBpbmRleGVzKSB7XG4gICAgICAgIHRlbXAuc3BsaWNlKGluZGV4IC0gaSwgMSk7XG4gICAgICAgIGkrKztcbiAgICB9XG4gICAgcmV0dXJuIGNvbXBhY3QodGVtcCkubGVuZ3RoID8gdGVtcCA6IFtdO1xufVxudmFyIHJlbW92ZUFycmF5QXQgPSAoZGF0YSwgaW5kZXgpID0+IGlzVW5kZWZpbmVkKGluZGV4KVxuICAgID8gW11cbiAgICA6IHJlbW92ZUF0SW5kZXhlcyhkYXRhLCBjb252ZXJ0VG9BcnJheVBheWxvYWQoaW5kZXgpLnNvcnQoKGEsIGIpID0+IGEgLSBiKSk7XG5cbnZhciBzd2FwQXJyYXlBdCA9IChkYXRhLCBpbmRleEEsIGluZGV4QikgPT4ge1xuICAgIFtkYXRhW2luZGV4QV0sIGRhdGFbaW5kZXhCXV0gPSBbZGF0YVtpbmRleEJdLCBkYXRhW2luZGV4QV1dO1xufTtcblxuZnVuY3Rpb24gYmFzZUdldChvYmplY3QsIHVwZGF0ZVBhdGgpIHtcbiAgICBjb25zdCBsZW5ndGggPSB1cGRhdGVQYXRoLmxlbmd0aCAtIDE7XG4gICAgbGV0IGluZGV4ID0gMDtcbiAgICB3aGlsZSAoaW5kZXggPCBsZW5ndGgpIHtcbiAgICAgICAgaWYgKGlzTnVsbE9yVW5kZWZpbmVkKG9iamVjdCkpIHtcbiAgICAgICAgICAgIG9iamVjdCA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIG9iamVjdCA9IG9iamVjdFt1cGRhdGVQYXRoW2luZGV4XV07XG4gICAgICAgIGluZGV4Kys7XG4gICAgfVxuICAgIHJldHVybiBvYmplY3Q7XG59XG5mdW5jdGlvbiBpc0VtcHR5QXJyYXkob2JqKSB7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gb2JqKSB7XG4gICAgICAgIGlmIChvYmouaGFzT3duUHJvcGVydHkoa2V5KSAmJiAhaXNVbmRlZmluZWQob2JqW2tleV0pKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiB1bnNldChvYmplY3QsIHBhdGgpIHtcbiAgICBpZiAoaXNTdHJpbmcocGF0aCkgJiYgT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcGF0aCkpIHtcbiAgICAgICAgZGVsZXRlIG9iamVjdFtwYXRoXTtcbiAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICB9XG4gICAgY29uc3QgcGF0aHMgPSBBcnJheS5pc0FycmF5KHBhdGgpXG4gICAgICAgID8gcGF0aFxuICAgICAgICA6IGlzS2V5KHBhdGgpXG4gICAgICAgICAgICA/IFtwYXRoXVxuICAgICAgICAgICAgOiBzdHJpbmdUb1BhdGgocGF0aCk7XG4gICAgaWYgKHBhdGhzLnNvbWUoKHNlZ21lbnQpID0+IFBST1RPVFlQRV9LRVlXT1JEUy5pbmNsdWRlcyhTdHJpbmcoc2VnbWVudCkpKSkge1xuICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgIH1cbiAgICBjb25zdCBjaGlsZE9iamVjdCA9IHBhdGhzLmxlbmd0aCA9PT0gMSA/IG9iamVjdCA6IGJhc2VHZXQob2JqZWN0LCBwYXRocyk7XG4gICAgY29uc3QgaW5kZXggPSBwYXRocy5sZW5ndGggLSAxO1xuICAgIGNvbnN0IGtleSA9IHBhdGhzW2luZGV4XTtcbiAgICBpZiAoY2hpbGRPYmplY3QpIHtcbiAgICAgICAgZGVsZXRlIGNoaWxkT2JqZWN0W2tleV07XG4gICAgfVxuICAgIGlmIChpbmRleCAhPT0gMCAmJlxuICAgICAgICAoKGlzT2JqZWN0KGNoaWxkT2JqZWN0KSAmJiBpc0VtcHR5T2JqZWN0KGNoaWxkT2JqZWN0KSkgfHxcbiAgICAgICAgICAgIChBcnJheS5pc0FycmF5KGNoaWxkT2JqZWN0KSAmJiBpc0VtcHR5QXJyYXkoY2hpbGRPYmplY3QpKSkpIHtcbiAgICAgICAgdW5zZXQob2JqZWN0LCBwYXRocy5zbGljZSgwLCAtMSkpO1xuICAgIH1cbiAgICByZXR1cm4gb2JqZWN0O1xufVxuXG52YXIgdXBkYXRlQXQgPSAoZmllbGRWYWx1ZXMsIGluZGV4LCB2YWx1ZSkgPT4ge1xuICAgIGZpZWxkVmFsdWVzW2luZGV4XSA9IHZhbHVlO1xuICAgIHJldHVybiBmaWVsZFZhbHVlcztcbn07XG5cbi8qKlxuICogQSBjdXN0b20gaG9vayB0aGF0IGV4cG9zZXMgY29udmVuaWVudCBtZXRob2RzIHRvIHBlcmZvcm0gb3BlcmF0aW9ucyB3aXRoIGEgbGlzdCBvZiBkeW5hbWljIGlucHV0cyB0aGF0IG5lZWQgdG8gYmUgYXBwZW5kZWQsIHVwZGF0ZWQsIHJlbW92ZWQgZXRjLiDigKIgW0RlbW9dKGh0dHBzOi8vY29kZXNhbmRib3guaW8vcy9yZWFjdC1ob29rLWZvcm0tdXNlZmllbGRhcnJheS1zc3Vnbikg4oCiIFtWaWRlb10oaHR0cHM6Ly95b3V0dS5iZS80TXJiZkdTRlkyQSlcbiAqXG4gKiBAcmVtYXJrc1xuICogW0FQSV0oaHR0cHM6Ly9yZWFjdC1ob29rLWZvcm0uY29tL2RvY3MvdXNlZmllbGRhcnJheSkg4oCiIFtEZW1vXShodHRwczovL2NvZGVzYW5kYm94LmlvL3MvcmVhY3QtaG9vay1mb3JtLXVzZWZpZWxkYXJyYXktc3N1Z24pXG4gKlxuICogQHBhcmFtIHByb3BzIC0gdXNlRmllbGRBcnJheSBwcm9wc1xuICpcbiAqIEByZXR1cm5zIG1ldGhvZHMgLSBmdW5jdGlvbnMgdG8gbWFuaXB1bGF0ZSB3aXRoIHRoZSBGaWVsZCBBcnJheXMgKGR5bmFtaWMgaW5wdXRzKSB7QGxpbmsgVXNlRmllbGRBcnJheVJldHVybn1cbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiBmdW5jdGlvbiBBcHAoKSB7XG4gKiAgIGNvbnN0IHsgcmVnaXN0ZXIsIGNvbnRyb2wsIGhhbmRsZVN1Ym1pdCwgcmVzZXQsIHRyaWdnZXIsIHNldEVycm9yIH0gPSB1c2VGb3JtKHtcbiAqICAgICBkZWZhdWx0VmFsdWVzOiB7XG4gKiAgICAgICB0ZXN0OiBbXVxuICogICAgIH1cbiAqICAgfSk7XG4gKiAgIGNvbnN0IHsgZmllbGRzLCBhcHBlbmQgfSA9IHVzZUZpZWxkQXJyYXkoe1xuICogICAgIGNvbnRyb2wsXG4gKiAgICAgbmFtZTogXCJ0ZXN0XCJcbiAqICAgfSk7XG4gKlxuICogICByZXR1cm4gKFxuICogICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXQoZGF0YSA9PiBjb25zb2xlLmxvZyhkYXRhKSl9PlxuICogICAgICAge2ZpZWxkcy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXG4gKiAgICAgICAgICA8aW5wdXQga2V5PXtpdGVtLmlkfSB7Li4ucmVnaXN0ZXIoYHRlc3QuJHtpbmRleH0uZmlyc3ROYW1lYCl9ICAvPlxuICogICAgICAgKSl9XG4gKiAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBhcHBlbmQoeyBmaXJzdE5hbWU6IFwiYmlsbFwiIH0pfT5cbiAqICAgICAgICAgYXBwZW5kXG4gKiAgICAgICA8L2J1dHRvbj5cbiAqICAgICAgIDxpbnB1dCB0eXBlPVwic3VibWl0XCIgLz5cbiAqICAgICA8L2Zvcm0+XG4gKiAgICk7XG4gKiB9XG4gKiBgYGBcbiAqL1xuZnVuY3Rpb24gdXNlRmllbGRBcnJheShwcm9wcykge1xuICAgIGNvbnN0IGZvcm1Db250cm9sID0gdXNlRm9ybUNvbnRyb2xDb250ZXh0KCk7XG4gICAgY29uc3QgeyBjb250cm9sID0gZm9ybUNvbnRyb2wsIG5hbWUsIGtleU5hbWUgPSAnaWQnLCBkaXNhYmxlZCwgc2hvdWxkVW5yZWdpc3RlciwgcnVsZXMsIH0gPSBwcm9wcztcbiAgICBjb25zdCBbZmllbGRzLCBzZXRGaWVsZHNdID0gUmVhY3QudXNlU3RhdGUoY29udHJvbC5fZ2V0RmllbGRBcnJheShuYW1lKSk7XG4gICAgY29uc3QgaWRzID0gUmVhY3QudXNlUmVmKGNvbnRyb2wuX2dldEZpZWxkQXJyYXkobmFtZSkubWFwKGdlbmVyYXRlSWQpKTtcbiAgICBjb25zdCBfYWN0aW9uZWQgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICAgIGlmICghZGlzYWJsZWQpIHtcbiAgICAgICAgY29udHJvbC5fbmFtZXMuYXJyYXkuYWRkKG5hbWUpO1xuICAgIH1cbiAgICBSZWFjdC51c2VNZW1vKCgpID0+ICFkaXNhYmxlZCAmJlxuICAgICAgICBydWxlcyAmJlxuICAgICAgICBmaWVsZHMubGVuZ3RoID49IDAgJiZcbiAgICAgICAgY29udHJvbC5yZWdpc3RlcihuYW1lLCBydWxlcyksIFtjb250cm9sLCBuYW1lLCBmaWVsZHMubGVuZ3RoLCBydWxlcywgZGlzYWJsZWRdKTtcbiAgICB1c2VJc29tb3JwaGljTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGRpc2FibGVkKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGNvbnRyb2wuX3N1YmplY3RzLmFycmF5LnN1YnNjcmliZSh7XG4gICAgICAgICAgICBuZXh0OiAoeyB2YWx1ZXMsIG5hbWU6IGZpZWxkQXJyYXlOYW1lLCB9KSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGZpZWxkQXJyYXlOYW1lID09PSBuYW1lIHx8ICFmaWVsZEFycmF5TmFtZSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWVsZFZhbHVlcyA9IGdldCh2YWx1ZXMsIG5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShmaWVsZFZhbHVlcykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEZpZWxkcyhmaWVsZFZhbHVlcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZHMuY3VycmVudCA9IGZpZWxkVmFsdWVzLm1hcChnZW5lcmF0ZUlkKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmICghZmllbGRBcnJheU5hbWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEZpZWxkcyhbXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZHMuY3VycmVudCA9IFtdO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSkudW5zdWJzY3JpYmU7XG4gICAgfSwgW2NvbnRyb2wsIG5hbWUsIGRpc2FibGVkXSk7XG4gICAgY29uc3QgdXBkYXRlVmFsdWVzID0gUmVhY3QudXNlQ2FsbGJhY2soKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKSA9PiB7XG4gICAgICAgIF9hY3Rpb25lZC5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgY29udHJvbC5fc2V0RmllbGRBcnJheShuYW1lLCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcyk7XG4gICAgfSwgW2NvbnRyb2wsIG5hbWVdKTtcbiAgICBjb25zdCBhcHBlbmQgPSAodmFsdWUsIG9wdGlvbnMpID0+IHtcbiAgICAgICAgaWYgKGRpc2FibGVkKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgYXBwZW5kVmFsdWUgPSBjb252ZXJ0VG9BcnJheVBheWxvYWQoY2xvbmVPYmplY3QodmFsdWUpKTtcbiAgICAgICAgY29uc3QgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMgPSBhcHBlbmRBdChjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpLCBhcHBlbmRWYWx1ZSk7XG4gICAgICAgIGNvbnRyb2wuX25hbWVzLmZvY3VzID0gZ2V0Rm9jdXNGaWVsZE5hbWUobmFtZSwgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMubGVuZ3RoIC0gMSwgb3B0aW9ucyk7XG4gICAgICAgIGlkcy5jdXJyZW50ID0gYXBwZW5kQXQoaWRzLmN1cnJlbnQsIGFwcGVuZFZhbHVlLm1hcChnZW5lcmF0ZUlkKSk7XG4gICAgICAgIHVwZGF0ZVZhbHVlcyh1cGRhdGVkRmllbGRBcnJheVZhbHVlcyk7XG4gICAgICAgIHNldEZpZWxkcyh1cGRhdGVkRmllbGRBcnJheVZhbHVlcyk7XG4gICAgICAgIGNvbnRyb2wuX3NldEZpZWxkQXJyYXkobmFtZSwgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMsIGFwcGVuZEF0LCB7XG4gICAgICAgICAgICBhcmdBOiBmaWxsRW1wdHlBcnJheSh2YWx1ZSksXG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3QgcHJlcGVuZCA9ICh2YWx1ZSwgb3B0aW9ucykgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwcmVwZW5kVmFsdWUgPSBjb252ZXJ0VG9BcnJheVBheWxvYWQoY2xvbmVPYmplY3QodmFsdWUpKTtcbiAgICAgICAgY29uc3QgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMgPSBwcmVwZW5kQXQoY29udHJvbC5fZ2V0RmllbGRBcnJheShuYW1lKSwgcHJlcGVuZFZhbHVlKTtcbiAgICAgICAgY29udHJvbC5fbmFtZXMuZm9jdXMgPSBnZXRGb2N1c0ZpZWxkTmFtZShuYW1lLCAwLCBvcHRpb25zKTtcbiAgICAgICAgaWRzLmN1cnJlbnQgPSBwcmVwZW5kQXQoaWRzLmN1cnJlbnQsIHByZXBlbmRWYWx1ZS5tYXAoZ2VuZXJhdGVJZCkpO1xuICAgICAgICB1cGRhdGVWYWx1ZXModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBzZXRGaWVsZHModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLCBwcmVwZW5kQXQsIHtcbiAgICAgICAgICAgIGFyZ0E6IGZpbGxFbXB0eUFycmF5KHZhbHVlKSxcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCByZW1vdmUgPSAoaW5kZXgpID0+IHtcbiAgICAgICAgaWYgKGRpc2FibGVkKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMgPSByZW1vdmVBcnJheUF0KGNvbnRyb2wuX2dldEZpZWxkQXJyYXkobmFtZSksIGluZGV4KTtcbiAgICAgICAgaWRzLmN1cnJlbnQgPSByZW1vdmVBcnJheUF0KGlkcy5jdXJyZW50LCBpbmRleCk7XG4gICAgICAgIHVwZGF0ZVZhbHVlcyh1cGRhdGVkRmllbGRBcnJheVZhbHVlcyk7XG4gICAgICAgIHNldEZpZWxkcyh1cGRhdGVkRmllbGRBcnJheVZhbHVlcyk7XG4gICAgICAgICFBcnJheS5pc0FycmF5KGdldChjb250cm9sLl9maWVsZHMsIG5hbWUpKSAmJlxuICAgICAgICAgICAgc2V0KGNvbnRyb2wuX2ZpZWxkcywgbmFtZSwgdW5kZWZpbmVkKTtcbiAgICAgICAgY29udHJvbC5fc2V0RmllbGRBcnJheShuYW1lLCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcywgcmVtb3ZlQXJyYXlBdCwge1xuICAgICAgICAgICAgYXJnQTogaW5kZXgsXG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3QgaW5zZXJ0JDEgPSAoaW5kZXgsIHZhbHVlLCBvcHRpb25zKSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGluc2VydFZhbHVlID0gY29udmVydFRvQXJyYXlQYXlsb2FkKGNsb25lT2JqZWN0KHZhbHVlKSk7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzID0gaW5zZXJ0KGNvbnRyb2wuX2dldEZpZWxkQXJyYXkobmFtZSksIGluZGV4LCBpbnNlcnRWYWx1ZSk7XG4gICAgICAgIGNvbnRyb2wuX25hbWVzLmZvY3VzID0gZ2V0Rm9jdXNGaWVsZE5hbWUobmFtZSwgaW5kZXgsIG9wdGlvbnMpO1xuICAgICAgICBpZHMuY3VycmVudCA9IGluc2VydChpZHMuY3VycmVudCwgaW5kZXgsIGluc2VydFZhbHVlLm1hcChnZW5lcmF0ZUlkKSk7XG4gICAgICAgIHVwZGF0ZVZhbHVlcyh1cGRhdGVkRmllbGRBcnJheVZhbHVlcyk7XG4gICAgICAgIHNldEZpZWxkcyh1cGRhdGVkRmllbGRBcnJheVZhbHVlcyk7XG4gICAgICAgIGNvbnRyb2wuX3NldEZpZWxkQXJyYXkobmFtZSwgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMsIGluc2VydCwge1xuICAgICAgICAgICAgYXJnQTogaW5kZXgsXG4gICAgICAgICAgICBhcmdCOiBmaWxsRW1wdHlBcnJheSh2YWx1ZSksXG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3Qgc3dhcCA9IChpbmRleEEsIGluZGV4QikgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcyA9IGNvbnRyb2wuX2dldEZpZWxkQXJyYXkobmFtZSk7XG4gICAgICAgIHN3YXBBcnJheUF0KHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLCBpbmRleEEsIGluZGV4Qik7XG4gICAgICAgIHN3YXBBcnJheUF0KGlkcy5jdXJyZW50LCBpbmRleEEsIGluZGV4Qik7XG4gICAgICAgIHVwZGF0ZVZhbHVlcyh1cGRhdGVkRmllbGRBcnJheVZhbHVlcyk7XG4gICAgICAgIHNldEZpZWxkcyh1cGRhdGVkRmllbGRBcnJheVZhbHVlcyk7XG4gICAgICAgIGNvbnRyb2wuX3NldEZpZWxkQXJyYXkobmFtZSwgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMsIHN3YXBBcnJheUF0LCB7XG4gICAgICAgICAgICBhcmdBOiBpbmRleEEsXG4gICAgICAgICAgICBhcmdCOiBpbmRleEIsXG4gICAgICAgIH0sIGZhbHNlKTtcbiAgICB9O1xuICAgIGNvbnN0IG1vdmUgPSAoZnJvbSwgdG8pID0+IHtcbiAgICAgICAgaWYgKGRpc2FibGVkKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMgPSBjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpO1xuICAgICAgICBtb3ZlQXJyYXlBdCh1cGRhdGVkRmllbGRBcnJheVZhbHVlcywgZnJvbSwgdG8pO1xuICAgICAgICBtb3ZlQXJyYXlBdChpZHMuY3VycmVudCwgZnJvbSwgdG8pO1xuICAgICAgICB1cGRhdGVWYWx1ZXModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBzZXRGaWVsZHModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLCBtb3ZlQXJyYXlBdCwge1xuICAgICAgICAgICAgYXJnQTogZnJvbSxcbiAgICAgICAgICAgIGFyZ0I6IHRvLFxuICAgICAgICB9LCBmYWxzZSk7XG4gICAgfTtcbiAgICBjb25zdCB1cGRhdGUgPSAoaW5kZXgsIHZhbHVlKSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHVwZGF0ZVZhbHVlID0gY2xvbmVPYmplY3QodmFsdWUpO1xuICAgICAgICBjb25zdCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcyA9IHVwZGF0ZUF0KGNvbnRyb2wuX2dldEZpZWxkQXJyYXkobmFtZSksIGluZGV4LCB1cGRhdGVWYWx1ZSk7XG4gICAgICAgIGlkcy5jdXJyZW50ID0gWy4uLnVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzXS5tYXAoKGl0ZW0sIGkpID0+ICFpdGVtIHx8IGkgPT09IGluZGV4ID8gZ2VuZXJhdGVJZCgpIDogaWRzLmN1cnJlbnRbaV0pO1xuICAgICAgICB1cGRhdGVWYWx1ZXModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBzZXRGaWVsZHMoWy4uLnVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzXSk7XG4gICAgICAgIGNvbnRyb2wuX3NldEZpZWxkQXJyYXkobmFtZSwgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMsIHVwZGF0ZUF0LCB7XG4gICAgICAgICAgICBhcmdBOiBpbmRleCxcbiAgICAgICAgICAgIGFyZ0I6IHVwZGF0ZVZhbHVlLFxuICAgICAgICB9LCB0cnVlLCBmYWxzZSk7XG4gICAgfTtcbiAgICBjb25zdCByZXBsYWNlID0gKHZhbHVlKSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzID0gY29udmVydFRvQXJyYXlQYXlsb2FkKGNsb25lT2JqZWN0KHZhbHVlKSk7XG4gICAgICAgIGlkcy5jdXJyZW50ID0gdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMubWFwKGdlbmVyYXRlSWQpO1xuICAgICAgICB1cGRhdGVWYWx1ZXMoWy4uLnVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzXSk7XG4gICAgICAgIHNldEZpZWxkcyhbLi4udXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXNdKTtcbiAgICAgICAgY29udHJvbC5fc2V0RmllbGRBcnJheShuYW1lLCBbLi4udXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXNdLCAoZGF0YSkgPT4gZGF0YSwge30sIHRydWUsIGZhbHNlKTtcbiAgICB9O1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgY29udHJvbC5fc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLmRlbGV0ZShuYW1lKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb250cm9sLl9zdGF0ZS5hY3Rpb24gPSBmYWxzZTtcbiAgICAgICAgY29udHJvbC5fc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLmRlbGV0ZShuYW1lKTtcbiAgICAgICAgaXNXYXRjaGVkKG5hbWUsIGNvbnRyb2wuX25hbWVzKSAmJlxuICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgLi4uY29udHJvbC5fZm9ybVN0YXRlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IHZhbGlkYXRpb25Nb2RlcyA9IGdldFZhbGlkYXRpb25Nb2Rlcyhjb250cm9sLl9vcHRpb25zLm1vZGUpO1xuICAgICAgICBpZiAoX2FjdGlvbmVkLmN1cnJlbnQgJiZcbiAgICAgICAgICAgICghdmFsaWRhdGlvbk1vZGVzLmlzT25TdWJtaXQgfHwgY29udHJvbC5fZm9ybVN0YXRlLmlzU3VibWl0dGVkKSAmJlxuICAgICAgICAgICAgIWdldFZhbGlkYXRpb25Nb2Rlcyhjb250cm9sLl9vcHRpb25zLnJlVmFsaWRhdGVNb2RlKS5pc09uU3VibWl0ICYmXG4gICAgICAgICAgICAhdmFsaWRhdGlvbk1vZGVzLmlzT25CbHVyKSB7XG4gICAgICAgICAgICBpZiAoY29udHJvbC5fb3B0aW9ucy5yZXNvbHZlcikge1xuICAgICAgICAgICAgICAgIGNvbnRyb2wuX3J1blNjaGVtYShbbmFtZV0pLnRoZW4oKHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB2YXIgX2EsIF9iO1xuICAgICAgICAgICAgICAgICAgICBjb250cm9sLl91cGRhdGVJc1ZhbGlkYXRpbmcoW25hbWVdKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXJyb3IgPSBnZXQocmVzdWx0LmVycm9ycywgbmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGV4aXN0aW5nRXJyb3IgPSBnZXQoY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycywgbmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGV4aXN0aW5nRXJyb3JUeXBlID0gZXhpc3RpbmdFcnJvciAmJiAoZXhpc3RpbmdFcnJvci50eXBlIHx8ICgoX2EgPSBleGlzdGluZ0Vycm9yLnJvb3QpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS50eXBlKSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGV4aXN0aW5nRXJyb3JNZXNzYWdlID0gZXhpc3RpbmdFcnJvciAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgKGV4aXN0aW5nRXJyb3IubWVzc2FnZSB8fCAoKF9iID0gZXhpc3RpbmdFcnJvci5yb290KSA9PT0gbnVsbCB8fCBfYiA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2IubWVzc2FnZSkpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXhpc3RpbmdFcnJvclxuICAgICAgICAgICAgICAgICAgICAgICAgPyAoIWVycm9yICYmIGV4aXN0aW5nRXJyb3JUeXBlKSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChlcnJvciAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZXhpc3RpbmdFcnJvclR5cGUgIT09IGVycm9yLnR5cGUgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nRXJyb3JNZXNzYWdlICE9PSBlcnJvci5tZXNzYWdlKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIDogZXJyb3IgJiYgZXJyb3IudHlwZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNPYmplY3QoZXJyb3IpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICFPYmplY3Qua2V5cyhlcnJvcikuc29tZSgoa2V5KSA9PiAhTnVtYmVyLmlzTmFOKCtrZXkpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHVwZGF0ZUZpZWxkQXJyYXlSb290RXJyb3IoY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycywgeyBbbmFtZV06IGVycm9yIH0sIG5hbWUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogc2V0KGNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUsIGVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVuc2V0KGNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3JzOiBjb250cm9sLl9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KGNvbnRyb2wuX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICAgICAgaWYgKGZpZWxkICYmXG4gICAgICAgICAgICAgICAgICAgIGZpZWxkLl9mICYmXG4gICAgICAgICAgICAgICAgICAgICEoZ2V0VmFsaWRhdGlvbk1vZGVzKGNvbnRyb2wuX29wdGlvbnMucmVWYWxpZGF0ZU1vZGUpLmlzT25TdWJtaXQgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIGdldFZhbGlkYXRpb25Nb2Rlcyhjb250cm9sLl9vcHRpb25zLm1vZGUpLmlzT25TdWJtaXQpKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRlRmllbGQoZmllbGQsIGNvbnRyb2wuX25hbWVzLmRpc2FibGVkLCBjb250cm9sLl9mb3JtVmFsdWVzLCBjb250cm9sLl9vcHRpb25zLmNyaXRlcmlhTW9kZSA9PT0gVkFMSURBVElPTl9NT0RFLmFsbCwgY29udHJvbC5fb3B0aW9ucy5zaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uLCB0cnVlKS50aGVuKChlcnJvcikgPT4gIWlzRW1wdHlPYmplY3QoZXJyb3IpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sLl9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlcnJvcnM6IHVwZGF0ZUZpZWxkQXJyYXlSb290RXJyb3IoY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycywgZXJyb3IsIG5hbWUpLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBFeHRlcm5hbCB1cGRhdGVzIHRoYXQgY2hhbmdlIGBmaWVsZHNgIChlLmcuIHJlc2V0KCkgb3Igc2V0VmFsdWUoKSBvblxuICAgICAgICAvLyB0aGUgYXJyYXkpIGFscmVhZHkgbm90aWZ5IHN1YnNjcmliZXJzIHdpdGggdGhlIHVwLXRvLWRhdGUgdmFsdWVzXG4gICAgICAgIC8vIHRoZW1zZWx2ZXMsIHNvIG9ubHkgcmUtYnJvYWRjYXN0IGhlcmUgZm9yIGdlbnVpbmUgYXJyYXkgbWV0aG9kIGNhbGxzLlxuICAgICAgICBfYWN0aW9uZWQuY3VycmVudCAmJlxuICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICB2YWx1ZXM6IGNsb25lT2JqZWN0KGNvbnRyb2wuX2Zvcm1WYWx1ZXMpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIGNvbnRyb2wuX25hbWVzLmZvY3VzICYmXG4gICAgICAgICAgICBpdGVyYXRlRmllbGRzQnlBY3Rpb24oY29udHJvbC5fZmllbGRzLCAocmVmLCBrZXkpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoY29udHJvbC5fbmFtZXMuZm9jdXMgJiZcbiAgICAgICAgICAgICAgICAgICAga2V5LnN0YXJ0c1dpdGgoY29udHJvbC5fbmFtZXMuZm9jdXMpICYmXG4gICAgICAgICAgICAgICAgICAgIHJlZi5mb2N1cykge1xuICAgICAgICAgICAgICAgICAgICByZWYuZm9jdXMoKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDE7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICBjb250cm9sLl9uYW1lcy5mb2N1cyA9ICcnO1xuICAgICAgICBjb250cm9sLl9zZXRWYWxpZCgpO1xuICAgICAgICBfYWN0aW9uZWQuY3VycmVudCA9IGZhbHNlO1xuICAgIH0sIFtmaWVsZHMsIG5hbWUsIGNvbnRyb2wsIGRpc2FibGVkXSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKCFkaXNhYmxlZCkge1xuICAgICAgICAgICAgIWdldChjb250cm9sLl9mb3JtVmFsdWVzLCBuYW1lKSAmJiBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICBjb250cm9sLl9zdGF0ZS5hY3Rpb25BcnJheUxlbmd0aHMuZGVsZXRlKG5hbWUpO1xuICAgICAgICAgICAgaWYgKGRpc2FibGVkKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3Qgc2hvdWxkS2VlcEZpZWxkQXJyYXlWYWx1ZXMgPSAhKGNvbnRyb2wuX29wdGlvbnMuc2hvdWxkVW5yZWdpc3RlciB8fCBzaG91bGRVbnJlZ2lzdGVyKTtcbiAgICAgICAgICAgIGNvbnN0IHVwZGF0ZU1vdW50ZWQgPSAobmFtZSwgdmFsdWUpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBmaWVsZCA9IGdldChjb250cm9sLl9maWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIGlmIChmaWVsZCAmJiBmaWVsZC5fZikge1xuICAgICAgICAgICAgICAgICAgICBmaWVsZC5fZi5tb3VudCA9IHZhbHVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBpZiAoX2FjdGlvbmVkLmN1cnJlbnQgJiYgc2hvdWxkS2VlcEZpZWxkQXJyYXlWYWx1ZXMpIHtcbiAgICAgICAgICAgICAgICBjb250cm9sLl9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICAgICAgdmFsdWVzOiBjbG9uZU9iamVjdChjb250cm9sLl9mb3JtVmFsdWVzKSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHNob3VsZEtlZXBGaWVsZEFycmF5VmFsdWVzXG4gICAgICAgICAgICAgICAgPyB1cGRhdGVNb3VudGVkKG5hbWUsIGZhbHNlKVxuICAgICAgICAgICAgICAgIDogY29udHJvbC51bnJlZ2lzdGVyKG5hbWUpO1xuICAgICAgICB9O1xuICAgIH0sIFtuYW1lLCBjb250cm9sLCBrZXlOYW1lLCBzaG91bGRVbnJlZ2lzdGVyLCBkaXNhYmxlZF0pO1xuICAgIHJldHVybiB7XG4gICAgICAgIHN3YXA6IFJlYWN0LnVzZUNhbGxiYWNrKHN3YXAsIFt1cGRhdGVWYWx1ZXMsIG5hbWUsIGNvbnRyb2wsIGRpc2FibGVkXSksXG4gICAgICAgIG1vdmU6IFJlYWN0LnVzZUNhbGxiYWNrKG1vdmUsIFt1cGRhdGVWYWx1ZXMsIG5hbWUsIGNvbnRyb2wsIGRpc2FibGVkXSksXG4gICAgICAgIHByZXBlbmQ6IFJlYWN0LnVzZUNhbGxiYWNrKHByZXBlbmQsIFtcbiAgICAgICAgICAgIHVwZGF0ZVZhbHVlcyxcbiAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICBjb250cm9sLFxuICAgICAgICAgICAgZGlzYWJsZWQsXG4gICAgICAgIF0pLFxuICAgICAgICBhcHBlbmQ6IFJlYWN0LnVzZUNhbGxiYWNrKGFwcGVuZCwgW3VwZGF0ZVZhbHVlcywgbmFtZSwgY29udHJvbCwgZGlzYWJsZWRdKSxcbiAgICAgICAgcmVtb3ZlOiBSZWFjdC51c2VDYWxsYmFjayhyZW1vdmUsIFt1cGRhdGVWYWx1ZXMsIG5hbWUsIGNvbnRyb2wsIGRpc2FibGVkXSksXG4gICAgICAgIGluc2VydDogUmVhY3QudXNlQ2FsbGJhY2soaW5zZXJ0JDEsIFt1cGRhdGVWYWx1ZXMsIG5hbWUsIGNvbnRyb2wsIGRpc2FibGVkXSksXG4gICAgICAgIHVwZGF0ZTogUmVhY3QudXNlQ2FsbGJhY2sodXBkYXRlLCBbdXBkYXRlVmFsdWVzLCBuYW1lLCBjb250cm9sLCBkaXNhYmxlZF0pLFxuICAgICAgICByZXBsYWNlOiBSZWFjdC51c2VDYWxsYmFjayhyZXBsYWNlLCBbXG4gICAgICAgICAgICB1cGRhdGVWYWx1ZXMsXG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgY29udHJvbCxcbiAgICAgICAgICAgIGRpc2FibGVkLFxuICAgICAgICBdKSxcbiAgICAgICAgZmllbGRzOiBSZWFjdC51c2VNZW1vKCgpID0+IGZpZWxkcy5tYXAoKGZpZWxkLCBpbmRleCkgPT4gKHtcbiAgICAgICAgICAgIC4uLmZpZWxkLFxuICAgICAgICAgICAgLi4uKGlzQm9vbGVhbihkaXNhYmxlZCkgPyB7IGRpc2FibGVkIH0gOiB7fSksXG4gICAgICAgICAgICBba2V5TmFtZV06IGlkcy5jdXJyZW50W2luZGV4XSB8fCBnZW5lcmF0ZUlkKCksXG4gICAgICAgIH0pKSwgW2ZpZWxkcywga2V5TmFtZSwgZGlzYWJsZWRdKSxcbiAgICB9O1xufVxuXG4vKipcbiAqIENvbXBvbmVudCBiYXNlZCBvbiBgdXNlRmllbGRBcnJheWAgaG9vayB0byB3b3JrIHdpdGggY29udHJvbGxlZCBjb21wb25lbnQuXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogZnVuY3Rpb24gQXBwKCkge1xuICogICBjb25zdCB7IGNvbnRyb2wsIHJlZ2lzdGVyIH0gPSB1c2VGb3JtPEZvcm1WYWx1ZXM+KHtcbiAqICAgICBkZWZhdWx0VmFsdWVzOiB7XG4gKiAgICAgICB0ZXN0OiBbXG4gKiAgICAgICAgIHtcbiAqICAgICAgICAgICB2YWx1ZTogJycsXG4gKiAgICAgICAgIH0sXG4gKiAgICAgICBdLFxuICogICAgIH0sXG4gKiAgIH0pO1xuICpcbiAqICAgcmV0dXJuIChcbiAqICAgICA8Zm9ybT5cbiAqICAgICAgIDxGaWVsZEFycmF5XG4gKiAgICAgICAgIGNvbnRyb2w9e2NvbnRyb2x9XG4gKiAgICAgICAgIG5hbWU9XCJ0ZXN0XCJcbiAqICAgICAgICAgcmVuZGVyPXsoeyBmaWVsZHMgfSkgPT5cbiAqICAgICAgICAgICBmaWVsZHMubWFwKChmaWVsZCwgaW5kZXgpID0+IChcbiAqICAgICAgICAgICAgIDxpbnB1dCBrZXk9e2ZpZWxkLmlkfSB7Li4ucmVnaXN0ZXIoYHRlc3QuJHtpbmRleH0udmFsdWVgKX0gLz5cbiAqICAgICAgICAgICApKVxuICogICAgICAgICB9XG4gKiAgICAgICAvPlxuICogICAgIDwvZm9ybT5cbiAqICAgKTtcbiAqIH1cbiAqIGBgYFxuICovXG5jb25zdCBGaWVsZEFycmF5ID0gKHByb3BzKSA9PiBwcm9wcy5yZW5kZXIodXNlRmllbGRBcnJheShwcm9wcykpO1xuXG5jb25zdCBmbGF0dGVuID0gKG9iaikgPT4ge1xuICAgIGNvbnN0IG91dHB1dCA9IHt9O1xuICAgIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKG9iaikpIHtcbiAgICAgICAgaWYgKGlzT2JqZWN0VHlwZShvYmpba2V5XSkgJiZcbiAgICAgICAgICAgIG9ialtrZXldICE9PSBudWxsICYmXG4gICAgICAgICAgICAhaXNEYXRlT2JqZWN0KG9ialtrZXldKSkge1xuICAgICAgICAgICAgY29uc3QgbmVzdGVkID0gZmxhdHRlbihvYmpba2V5XSk7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IG5lc3RlZEtleSBvZiBPYmplY3Qua2V5cyhuZXN0ZWQpKSB7XG4gICAgICAgICAgICAgICAgb3V0cHV0W2Ake2tleX0uJHtuZXN0ZWRLZXl9YF0gPSBuZXN0ZWRbbmVzdGVkS2V5XTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIG91dHB1dFtrZXldID0gb2JqW2tleV07XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG91dHB1dDtcbn07XG5cbmZ1bmN0aW9uIGpzb25Ub0Zvcm1EYXRhKGpzb24pIHtcbiAgICBjb25zdCByZXN1bHQgPSBuZXcgRm9ybURhdGEoKTtcbiAgICBjb25zdCBmbGF0dGVuRm9ybVZhbHVlcyA9IGZsYXR0ZW4oanNvbik7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZmxhdHRlbkZvcm1WYWx1ZXMpIHtcbiAgICAgICAgcmVzdWx0LmFwcGVuZChrZXksIGZsYXR0ZW5Gb3JtVmFsdWVzW2tleV0pO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuXG5mdW5jdGlvbiBzYWZlSlNPTlN0cmluZ2lmeSh2YWx1ZSkge1xuICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBKU09OLnN0cmluZ2lmeSh2YWx1ZSk7XG4gICAgfVxuICAgIGNhdGNoIChfYSkge1xuICAgICAgICByZXR1cm4gJyc7XG4gICAgfVxufVxuXG5mdW5jdGlvbiBub29wKCkgeyB9XG5cbmNvbnN0IEhvb2tGb3JtQ29udGV4dCA9IFJlYWN0LmNyZWF0ZUNvbnRleHQobnVsbCk7XG5Ib29rRm9ybUNvbnRleHQuZGlzcGxheU5hbWUgPSAnSG9va0Zvcm1Db250ZXh0Jztcbi8qKlxuICogVGhpcyBjdXN0b20gaG9vayBhbGxvd3MgeW91IHRvIGFjY2VzcyB0aGUgZm9ybSBjb250ZXh0LiB1c2VGb3JtQ29udGV4dCBpcyBpbnRlbmRlZCB0byBiZSB1c2VkIGluIGRlZXBseSBuZXN0ZWQgc3RydWN0dXJlcywgd2hlcmUgaXQgd291bGQgYmVjb21lIGluY29udmVuaWVudCB0byBwYXNzIHRoZSBjb250ZXh0IGFzIGEgcHJvcC4gVG8gYmUgdXNlZCB3aXRoIHtAbGluayBGb3JtUHJvdmlkZXJ9LlxuICpcbiAqIEByZW1hcmtzXG4gKiBbQVBJXShodHRwczovL3JlYWN0LWhvb2stZm9ybS5jb20vZG9jcy91c2Vmb3JtY29udGV4dCkg4oCiIFtEZW1vXShodHRwczovL2NvZGVzYW5kYm94LmlvL3MvcmVhY3QtaG9vay1mb3JtLXY3LWZvcm0tY29udGV4dC15dHVkaSlcbiAqXG4gKiBAcmV0dXJucyByZXR1cm4gYWxsIHVzZUZvcm0gbWV0aG9kc1xuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0c3hcbiAqIGZ1bmN0aW9uIEFwcCgpIHtcbiAqICAgY29uc3QgbWV0aG9kcyA9IHVzZUZvcm0oKTtcbiAqICAgY29uc3Qgb25TdWJtaXQgPSBkYXRhID0+IGNvbnNvbGUubG9nKGRhdGEpO1xuICpcbiAqICAgcmV0dXJuIChcbiAqICAgICA8Rm9ybVByb3ZpZGVyIHsuLi5tZXRob2RzfSA+XG4gKiAgICAgICA8Zm9ybSBvblN1Ym1pdD17bWV0aG9kcy5oYW5kbGVTdWJtaXQob25TdWJtaXQpfT5cbiAqICAgICAgICAgPE5lc3RlZElucHV0IC8+XG4gKiAgICAgICAgIDxpbnB1dCB0eXBlPVwic3VibWl0XCIgLz5cbiAqICAgICAgIDwvZm9ybT5cbiAqICAgICA8L0Zvcm1Qcm92aWRlcj5cbiAqICAgKTtcbiAqIH1cbiAqXG4gKiAgZnVuY3Rpb24gTmVzdGVkSW5wdXQoKSB7XG4gKiAgIGNvbnN0IHsgcmVnaXN0ZXIgfSA9IHVzZUZvcm1Db250ZXh0KCk7IC8vIHJldHJpZXZlIGFsbCBob29rIG1ldGhvZHNcbiAqICAgcmV0dXJuIDxpbnB1dCB7Li4ucmVnaXN0ZXIoXCJ0ZXN0XCIpfSAvPjtcbiAqIH1cbiAqIGBgYFxuICovXG5jb25zdCB1c2VGb3JtQ29udGV4dCA9ICgpID0+IFJlYWN0LnVzZUNvbnRleHQoSG9va0Zvcm1Db250ZXh0KTtcbi8qKlxuICogQSBwcm92aWRlciBjb21wb25lbnQgdGhhdCBwcm9wYWdhdGVzIHRoZSBgdXNlRm9ybWAgbWV0aG9kcyB0byBhbGwgY2hpbGRyZW4gY29tcG9uZW50cyB2aWEgW1JlYWN0IENvbnRleHRdKGh0dHBzOi8vcmVhY3QuZGV2L3JlZmVyZW5jZS9yZWFjdC91c2VDb250ZXh0KSBBUEkuIFRvIGJlIHVzZWQgd2l0aCB7QGxpbmsgdXNlRm9ybUNvbnRleHR9LlxuICpcbiAqIEByZW1hcmtzXG4gKiBbQVBJXShodHRwczovL3JlYWN0LWhvb2stZm9ybS5jb20vZG9jcy91c2Vmb3JtY29udGV4dCkg4oCiIFtEZW1vXShodHRwczovL2NvZGVzYW5kYm94LmlvL3MvcmVhY3QtaG9vay1mb3JtLXY3LWZvcm0tY29udGV4dC15dHVkaSlcbiAqXG4gKiBAcGFyYW0gcHJvcHMgLSBhbGwgdXNlRm9ybSBtZXRob2RzXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogZnVuY3Rpb24gQXBwKCkge1xuICogICBjb25zdCBtZXRob2RzID0gdXNlRm9ybSgpO1xuICogICBjb25zdCBvblN1Ym1pdCA9IGRhdGEgPT4gY29uc29sZS5sb2coZGF0YSk7XG4gKlxuICogICByZXR1cm4gKFxuICogICAgIDxGb3JtUHJvdmlkZXIgey4uLm1ldGhvZHN9ID5cbiAqICAgICAgIDxmb3JtIG9uU3VibWl0PXttZXRob2RzLmhhbmRsZVN1Ym1pdChvblN1Ym1pdCl9PlxuICogICAgICAgICA8TmVzdGVkSW5wdXQgLz5cbiAqICAgICAgICAgPGlucHV0IHR5cGU9XCJzdWJtaXRcIiAvPlxuICogICAgICAgPC9mb3JtPlxuICogICAgIDwvRm9ybVByb3ZpZGVyPlxuICogICApO1xuICogfVxuICpcbiAqICBmdW5jdGlvbiBOZXN0ZWRJbnB1dCgpIHtcbiAqICAgY29uc3QgeyByZWdpc3RlciB9ID0gdXNlRm9ybUNvbnRleHQoKTsgLy8gcmV0cmlldmUgYWxsIGhvb2sgbWV0aG9kc1xuICogICByZXR1cm4gPGlucHV0IHsuLi5yZWdpc3RlcihcInRlc3RcIil9IC8+O1xuICogfVxuICogYGBgXG4gKi9cbmNvbnN0IEZvcm1Qcm92aWRlciA9ICh7IGNoaWxkcmVuLCB3YXRjaCwgZ2V0VmFsdWVzLCBnZXRGaWVsZFN0YXRlLCBzZXRFcnJvciwgY2xlYXJFcnJvcnMsIHNldFZhbHVlLCBzZXRWYWx1ZXMsIHRyaWdnZXIsIGZvcm1TdGF0ZSwgcmVzZXRGaWVsZCwgcmVzZXQsIHJlc2V0RGVmYXVsdFZhbHVlcywgaGFuZGxlU3VibWl0LCB1bnJlZ2lzdGVyLCBjb250cm9sLCByZWdpc3Rlciwgc2V0Rm9jdXMsIHN1YnNjcmliZSwgfSkgPT4ge1xuICAgIGNvbnN0IG1lbW9pemVkVmFsdWUgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgICAgIHdhdGNoLFxuICAgICAgICBnZXRWYWx1ZXMsXG4gICAgICAgIGdldEZpZWxkU3RhdGUsXG4gICAgICAgIHNldEVycm9yLFxuICAgICAgICBjbGVhckVycm9ycyxcbiAgICAgICAgc2V0VmFsdWUsXG4gICAgICAgIHNldFZhbHVlcyxcbiAgICAgICAgdHJpZ2dlcixcbiAgICAgICAgZm9ybVN0YXRlLFxuICAgICAgICByZXNldEZpZWxkLFxuICAgICAgICByZXNldCxcbiAgICAgICAgcmVzZXREZWZhdWx0VmFsdWVzLFxuICAgICAgICBoYW5kbGVTdWJtaXQsXG4gICAgICAgIHVucmVnaXN0ZXIsXG4gICAgICAgIGNvbnRyb2wsXG4gICAgICAgIHJlZ2lzdGVyLFxuICAgICAgICBzZXRGb2N1cyxcbiAgICAgICAgc3Vic2NyaWJlLFxuICAgIH0pLCBbXG4gICAgICAgIGNsZWFyRXJyb3JzLFxuICAgICAgICBjb250cm9sLFxuICAgICAgICBmb3JtU3RhdGUsXG4gICAgICAgIGdldEZpZWxkU3RhdGUsXG4gICAgICAgIGdldFZhbHVlcyxcbiAgICAgICAgaGFuZGxlU3VibWl0LFxuICAgICAgICByZWdpc3RlcixcbiAgICAgICAgcmVzZXQsXG4gICAgICAgIHJlc2V0RGVmYXVsdFZhbHVlcyxcbiAgICAgICAgcmVzZXRGaWVsZCxcbiAgICAgICAgc2V0RXJyb3IsXG4gICAgICAgIHNldEZvY3VzLFxuICAgICAgICBzZXRWYWx1ZSxcbiAgICAgICAgc2V0VmFsdWVzLFxuICAgICAgICBzdWJzY3JpYmUsXG4gICAgICAgIHRyaWdnZXIsXG4gICAgICAgIHVucmVnaXN0ZXIsXG4gICAgICAgIHdhdGNoLFxuICAgIF0pO1xuICAgIHJldHVybiAoUmVhY3QuY3JlYXRlRWxlbWVudChIb29rRm9ybUNvbnRleHQuUHJvdmlkZXIsIHsgdmFsdWU6IG1lbW9pemVkVmFsdWUgfSxcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChIb29rRm9ybUNvbnRyb2xDb250ZXh0LlByb3ZpZGVyLCB7IHZhbHVlOiBtZW1vaXplZFZhbHVlLmNvbnRyb2wgfSwgY2hpbGRyZW4pKSk7XG59O1xuXG5jb25zdCBQT1NUX1JFUVVFU1QgPSAncG9zdCc7XG5mdW5jdGlvbiBkZWZhdWx0VmFsaWRhdGVTdGF0dXMoc3RhdHVzKSB7XG4gICAgcmV0dXJuIHN0YXR1cyA+PSAyMDAgJiYgc3RhdHVzIDwgMzAwO1xufVxuLyoqXG4gKiBGb3JtIGNvbXBvbmVudCB0byBtYW5hZ2Ugc3VibWlzc2lvbi5cbiAqXG4gKiBAcGFyYW0gcHJvcHMgLSB0byBzZXR1cCBzdWJtaXNzaW9uIGRldGFpbC4ge0BsaW5rIEZvcm1Qcm9wc31cbiAqXG4gKiBAcmV0dXJucyBmb3JtIGNvbXBvbmVudCBvciBoZWFkbGVzcyByZW5kZXIgcHJvcC5cbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiBmdW5jdGlvbiBBcHAoKSB7XG4gKiAgIGNvbnN0IHsgY29udHJvbCwgZm9ybVN0YXRlOiB7IGVycm9ycyB9IH0gPSB1c2VGb3JtKCk7XG4gKlxuICogICByZXR1cm4gKFxuICogICAgIDxGb3JtIGFjdGlvbj1cIi9hcGlcIiBjb250cm9sPXtjb250cm9sfT5cbiAqICAgICAgIDxpbnB1dCB7Li4ucmVnaXN0ZXIoXCJuYW1lXCIpfSAvPlxuICogICAgICAgPHA+e2Vycm9ycz8ucm9vdD8uc2VydmVyICYmICdTZXJ2ZXIgZXJyb3InfTwvcD5cbiAqICAgICAgIDxidXR0b24+U3VibWl0PC9idXR0b24+XG4gKiAgICAgPC9Gb3JtPlxuICogICApO1xuICogfVxuICogYGBgXG4gKi9cbmZ1bmN0aW9uIEZvcm0ocHJvcHMpIHtcbiAgICBjb25zdCBtZXRob2RzID0gdXNlRm9ybUNvbnRleHQoKTtcbiAgICBjb25zdCBbbW91bnRlZCwgc2V0TW91bnRlZF0gPSBSZWFjdC51c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgeyBjb250cm9sID0gbWV0aG9kcy5jb250cm9sLCBvblN1Ym1pdCA9IG5vb3AsIGNoaWxkcmVuLCBhY3Rpb24sIG1ldGhvZCA9IFBPU1RfUkVRVUVTVCwgaGVhZGVycywgZW5jVHlwZSwgb25FcnJvciA9IG5vb3AsIHJlbmRlciwgb25TdWNjZXNzID0gbm9vcCwgdmFsaWRhdGVTdGF0dXMgPSBkZWZhdWx0VmFsaWRhdGVTdGF0dXMsIC4uLnJlc3QgfSA9IHByb3BzO1xuICAgIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgICAgICByZXR1cm4gY29udHJvbC5oYW5kbGVTdWJtaXQoYXN5bmMgKGRhdGEsIGV2ZW50KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBmb3JtRGF0YSA9IGpzb25Ub0Zvcm1EYXRhKGRhdGEpO1xuICAgICAgICAgICAgY29uc3QgZm9ybURhdGFKc29uID0gc2FmZUpTT05TdHJpbmdpZnkoZGF0YSk7XG4gICAgICAgICAgICBpZiAob25TdWJtaXQpIHtcbiAgICAgICAgICAgICAgICBhd2FpdCBvblN1Ym1pdCh7XG4gICAgICAgICAgICAgICAgICAgIGRhdGEsXG4gICAgICAgICAgICAgICAgICAgIGV2ZW50LFxuICAgICAgICAgICAgICAgICAgICBtZXRob2QsXG4gICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLFxuICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YUpzb24sXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaXNTdHJpbmcoYWN0aW9uKSkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHNob3VsZFN0cmluZ2lmeVN1Ym1pc3Npb25EYXRhID0gKGhlYWRlcnMgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlYWRlcnNbJ0NvbnRlbnQtVHlwZSddICYmXG4gICAgICAgICAgICAgICAgICAgICAgICBoZWFkZXJzWydDb250ZW50LVR5cGUnXS5pbmNsdWRlcygnanNvbicpKSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgKGVuY1R5cGUgJiYgZW5jVHlwZS5pbmNsdWRlcygnanNvbicpKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChhY3Rpb24sIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5oZWFkZXJzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLihlbmNUeXBlICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVuY1R5cGUgIT09ICdtdWx0aXBhcnQvZm9ybS1kYXRhJyAmJiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiBlbmNUeXBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvZHk6IHNob3VsZFN0cmluZ2lmeVN1Ym1pc3Npb25EYXRhID8gZm9ybURhdGFKc29uIDogZm9ybURhdGEsXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UgJiYgIXZhbGlkYXRlU3RhdHVzKHJlc3BvbnNlLnN0YXR1cykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uRXJyb3IoeyByZXNwb25zZSB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7IHR5cGU6IFN0cmluZyhyZXNwb25zZS5zdGF0dXMpIH07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBvblN1Y2Nlc3MoeyByZXNwb25zZSB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgb25FcnJvcih7IGVycm9yIH0pO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4geyB0eXBlOiAnJyB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpc0Z1bmN0aW9uKGFjdGlvbikpIHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBhd2FpdCBhY3Rpb24oZm9ybURhdGEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgb25FcnJvcih7IGVycm9yIH0pO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4geyB0eXBlOiAnJyB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIFJldHVybiBub3RoaW5nIHdoZW4gc3VjY2Vzc2Z1bC5cbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfSk7XG4gICAgfSwgW1xuICAgICAgICBjb250cm9sLFxuICAgICAgICBvblN1Ym1pdCxcbiAgICAgICAgbWV0aG9kLFxuICAgICAgICBhY3Rpb24sXG4gICAgICAgIGhlYWRlcnMsXG4gICAgICAgIGVuY1R5cGUsXG4gICAgICAgIHZhbGlkYXRlU3RhdHVzLFxuICAgICAgICBvbkVycm9yLFxuICAgICAgICBvblN1Y2Nlc3MsXG4gICAgXSk7XG4gICAgY29uc3Qgc3VibWl0ID0gUmVhY3QudXNlQ2FsbGJhY2soYXN5bmMgKGV2ZW50KSA9PiB7XG4gICAgICAgIGNvbnN0IGVyciA9IGF3YWl0IGhhbmRsZVN1Ym1pdChldmVudCk7XG4gICAgICAgIGlmIChlcnIgJiYgY29udHJvbCkge1xuICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7IGlzU3VibWl0U3VjY2Vzc2Z1bDogZmFsc2UgfSk7XG4gICAgICAgICAgICBjb250cm9sLnNldEVycm9yKCdyb290LnNlcnZlcicsIGVycik7XG4gICAgICAgIH1cbiAgICB9LCBbaGFuZGxlU3VibWl0LCBjb250cm9sXSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgc2V0TW91bnRlZCh0cnVlKTtcbiAgICB9LCBbXSk7XG4gICAgaWYgKHJlbmRlcikge1xuICAgICAgICByZXR1cm4gcmVuZGVyKHsgc3VibWl0IH0pO1xuICAgIH1cbiAgICAvLyBSZWFjdCBmb3JiaWRzIHBhc3NpbmcgYG1ldGhvZGAvYGVuY1R5cGVgIGFsb25nc2lkZSBhIGZ1bmN0aW9uIGBhY3Rpb25gXG4gICAgLy8gKGEgU2VydmVyLUFjdGlvbi1zdHlsZSBzdWJtaXNzaW9uKSAtLSBpdCBtYW5hZ2VzIHRob3NlIGl0c2VsZiBhbmQgd2FybnNcbiAgICAvLyBpZiB0aGV5J3JlIHByZXNlbnQsIHNvIHRoZXkncmUgb25seSByZW5kZXJlZCBmb3Igc3RyaW5nL1VSTCBhY3Rpb25zLlxuICAgIHJldHVybiAoUmVhY3QuY3JlYXRlRWxlbWVudChcImZvcm1cIiwgeyBub1ZhbGlkYXRlOiBtb3VudGVkLCBhY3Rpb246IGFjdGlvbiwgLi4uKCFpc0Z1bmN0aW9uKGFjdGlvbikgJiYgeyBtZXRob2QsIGVuY1R5cGUgfSksIG9uU3VibWl0OiBzdWJtaXQsIC4uLnJlc3QgfSwgY2hpbGRyZW4pKTtcbn1cblxuY29uc3QgRm9ybVN0YXRlID0gKHsgY29udHJvbCwgZGlzYWJsZWQsIGV4YWN0LCBuYW1lLCByZW5kZXIsIH0pID0+IHJlbmRlcih1c2VGb3JtU3RhdGUoeyBjb250cm9sLCBuYW1lLCBkaXNhYmxlZCwgZXhhY3QgfSkpO1xuLyoqIEBkZXByZWNhdGVkIFVzZSBgRm9ybVN0YXRlYCBpbnN0ZWFkLiBLZXB0IGFzIGFuIGFsaWFzIGZvciBiYWNrd2FyZCBjb21wYXRpYmlsaXR5LiAqL1xuY29uc3QgRm9ybVN0YXRlU3Vic2NyaWJlID0gRm9ybVN0YXRlO1xuXG52YXIgY3JlYXRlU3ViamVjdCA9ICgpID0+IHtcbiAgICBsZXQgX29ic2VydmVycyA9IFtdO1xuICAgIGNvbnN0IG5leHQgPSAodmFsdWUpID0+IHtcbiAgICAgICAgZm9yIChjb25zdCBvYnNlcnZlciBvZiBfb2JzZXJ2ZXJzKSB7XG4gICAgICAgICAgICBvYnNlcnZlci5uZXh0ICYmIG9ic2VydmVyLm5leHQodmFsdWUpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBzdWJzY3JpYmUgPSAob2JzZXJ2ZXIpID0+IHtcbiAgICAgICAgX29ic2VydmVycy5wdXNoKG9ic2VydmVyKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHVuc3Vic2NyaWJlOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgX29ic2VydmVycyA9IF9vYnNlcnZlcnMuZmlsdGVyKChvKSA9PiBvICE9PSBvYnNlcnZlcik7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgIH07XG4gICAgY29uc3QgdW5zdWJzY3JpYmUgPSAoKSA9PiB7XG4gICAgICAgIF9vYnNlcnZlcnMgPSBbXTtcbiAgICB9O1xuICAgIHJldHVybiB7XG4gICAgICAgIGdldCBvYnNlcnZlcnMoKSB7XG4gICAgICAgICAgICByZXR1cm4gX29ic2VydmVycztcbiAgICAgICAgfSxcbiAgICAgICAgbmV4dCxcbiAgICAgICAgc3Vic2NyaWJlLFxuICAgICAgICB1bnN1YnNjcmliZSxcbiAgICB9O1xufTtcblxuZnVuY3Rpb24gZXh0cmFjdEZvcm1WYWx1ZXMoZmllbGRzU3RhdGUsIGZvcm1WYWx1ZXMpIHtcbiAgICBjb25zdCB2YWx1ZXMgPSB7fTtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBmaWVsZHNTdGF0ZSkge1xuICAgICAgICBpZiAoZmllbGRzU3RhdGUuaGFzT3duUHJvcGVydHkoa2V5KSkge1xuICAgICAgICAgICAgY29uc3QgZmllbGRTdGF0ZSA9IGZpZWxkc1N0YXRlW2tleV07XG4gICAgICAgICAgICBjb25zdCBmaWVsZFZhbHVlID0gZm9ybVZhbHVlc1trZXldO1xuICAgICAgICAgICAgaWYgKGZpZWxkU3RhdGUgJiYgaXNPYmplY3QoZmllbGRTdGF0ZSkgJiYgZmllbGRWYWx1ZSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IG5lc3RlZEZpZWxkc1N0YXRlID0gZXh0cmFjdEZvcm1WYWx1ZXMoZmllbGRTdGF0ZSwgZmllbGRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgaWYgKGlzT2JqZWN0KG5lc3RlZEZpZWxkc1N0YXRlKSkge1xuICAgICAgICAgICAgICAgICAgICB2YWx1ZXNba2V5XSA9IG5lc3RlZEZpZWxkc1N0YXRlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGZpZWxkc1N0YXRlW2tleV0pIHtcbiAgICAgICAgICAgICAgICB2YWx1ZXNba2V5XSA9IGZpZWxkVmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHZhbHVlcztcbn1cblxudmFyIGlzTXVsdGlwbGVTZWxlY3QgPSAoZWxlbWVudCkgPT4gZWxlbWVudC50eXBlID09PSBgc2VsZWN0LW11bHRpcGxlYDtcblxudmFyIGlzUmFkaW9PckNoZWNrYm94ID0gKHJlZikgPT4gaXNSYWRpb0lucHV0KHJlZikgfHwgaXNDaGVja0JveElucHV0KHJlZik7XG5cbnZhciBsaXZlID0gKHJlZikgPT4gaXNIVE1MRWxlbWVudChyZWYpICYmIHJlZi5pc0Nvbm5lY3RlZDtcblxuZnVuY3Rpb24gaXNEaXJ0eUNvbnRhaW5lcih2YWx1ZSkge1xuICAgIHJldHVybiBBcnJheS5pc0FycmF5KHZhbHVlKSB8fCBpc09iamVjdCh2YWx1ZSk7XG59XG5mdW5jdGlvbiBjb2xsZWN0RGlydHlGaWVsZE5hbWVzKGRpcnR5VHJlZSwgY2FjaGVkRGlydHlGaWVsZHMsIHByZWZpeCA9ICcnLCBuYW1lcyA9IFtdKSB7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZGlydHlUcmVlKSB7XG4gICAgICAgIGNvbnN0IHBhdGggPSBwcmVmaXggPyBgJHtwcmVmaXh9LiR7a2V5fWAgOiBrZXk7XG4gICAgICAgIGNvbnN0IHZhbHVlID0gZGlydHlUcmVlW2tleV07XG4gICAgICAgIGlmIChpc0RpcnR5Q29udGFpbmVyKHZhbHVlKSAmJlxuICAgICAgICAgICAgaXNEaXJ0eUNvbnRhaW5lcihnZXQoY2FjaGVkRGlydHlGaWVsZHMsIHBhdGgpKSkge1xuICAgICAgICAgICAgY29sbGVjdERpcnR5RmllbGROYW1lcyh2YWx1ZSwgY2FjaGVkRGlydHlGaWVsZHMsIHBhdGgsIG5hbWVzKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIG5hbWVzLnB1c2gocGF0aCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG5hbWVzO1xufVxuXG52YXIgb2JqZWN0SGFzRnVuY3Rpb24gPSAoZGF0YSkgPT4ge1xuICAgIGZvciAoY29uc3Qga2V5IGluIGRhdGEpIHtcbiAgICAgICAgaWYgKGlzRnVuY3Rpb24oZGF0YVtrZXldKSkge1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xufTtcblxuZnVuY3Rpb24gaXNUcmF2ZXJzYWJsZSh2YWx1ZSkge1xuICAgIHJldHVybiBBcnJheS5pc0FycmF5KHZhbHVlKSB8fCAoaXNPYmplY3QodmFsdWUpICYmICFvYmplY3RIYXNGdW5jdGlvbih2YWx1ZSkpO1xufVxuZnVuY3Rpb24gaXNSZWdpc3RlcmVkTGVhZihmaWVsZFJlZikge1xuICAgIHJldHVybiAhIShmaWVsZFJlZiAmJiAnX2YnIGluIGZpZWxkUmVmKTtcbn1cbmZ1bmN0aW9uIGlzRW1wdHlEaXJ0eUNvbnRhaW5lcih2YWx1ZSkge1xuICAgIHJldHVybiBBcnJheS5pc0FycmF5KHZhbHVlKVxuICAgICAgICA/ICF2YWx1ZS5zb21lKChpdGVtKSA9PiAhaXNVbmRlZmluZWQoaXRlbSkpXG4gICAgICAgIDogIU9iamVjdC5rZXlzKHZhbHVlKS5sZW5ndGg7XG59XG5mdW5jdGlvbiBjbGVhckRpcnR5RmllbGQoY29udGFpbmVyLCBrZXkpIHtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShjb250YWluZXIpKSB7XG4gICAgICAgIGNvbnRhaW5lcltrZXldID0gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgZGVsZXRlIGNvbnRhaW5lcltrZXldO1xuICAgIH1cbn1cbmZ1bmN0aW9uIG1hcmtGaWVsZHNEaXJ0eShkYXRhLCBmaWVsZHMgPSB7fSwgZmllbGRSZWZzKSB7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZGF0YSkge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGRhdGFba2V5XTtcbiAgICAgICAgY29uc3QgZmllbGRSZWYgPSBmaWVsZFJlZnMgJiYgZmllbGRSZWZzW2tleV07XG4gICAgICAgIGlmIChpc1RyYXZlcnNhYmxlKHZhbHVlKSAmJlxuICAgICAgICAgICAgKCFBcnJheS5pc0FycmF5KHZhbHVlKSB8fCAhaXNSZWdpc3RlcmVkTGVhZihmaWVsZFJlZikpKSB7XG4gICAgICAgICAgICBmaWVsZHNba2V5XSA9IEFycmF5LmlzQXJyYXkodmFsdWUpID8gW10gOiB7fTtcbiAgICAgICAgICAgIG1hcmtGaWVsZHNEaXJ0eSh2YWx1ZSwgZmllbGRzW2tleV0sIGZpZWxkUmVmKTtcbiAgICAgICAgICAgIGlmIChpc0VtcHR5RGlydHlDb250YWluZXIoZmllbGRzW2tleV0pKSB7XG4gICAgICAgICAgICAgICAgY2xlYXJEaXJ0eUZpZWxkKGZpZWxkcywga2V5KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICghaXNVbmRlZmluZWQodmFsdWUpKSB7XG4gICAgICAgICAgICBmaWVsZHNba2V5XSA9IHRydWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZpZWxkcztcbn1cbmZ1bmN0aW9uIGdldERpcnR5RmllbGRzKGRhdGEsIGZvcm1WYWx1ZXMsIGRpcnR5RmllbGRzRnJvbVZhbHVlcywgZmllbGRSZWZzKSB7XG4gICAgaWYgKCFkaXJ0eUZpZWxkc0Zyb21WYWx1ZXMpIHtcbiAgICAgICAgZGlydHlGaWVsZHNGcm9tVmFsdWVzID0gbWFya0ZpZWxkc0RpcnR5KGZvcm1WYWx1ZXMsIHt9LCBmaWVsZFJlZnMpO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IGtleSBpbiBkYXRhKSB7XG4gICAgICAgIGNvbnN0IHZhbHVlID0gZGF0YVtrZXldO1xuICAgICAgICBjb25zdCBmaWVsZFJlZiA9IGZpZWxkUmVmcyAmJiBmaWVsZFJlZnNba2V5XTtcbiAgICAgICAgaWYgKGlzVHJhdmVyc2FibGUodmFsdWUpICYmXG4gICAgICAgICAgICAoIUFycmF5LmlzQXJyYXkodmFsdWUpIHx8ICFpc1JlZ2lzdGVyZWRMZWFmKGZpZWxkUmVmKSkpIHtcbiAgICAgICAgICAgIGlmIChpc1VuZGVmaW5lZChmb3JtVmFsdWVzKSB8fCBpc1ByaW1pdGl2ZShkaXJ0eUZpZWxkc0Zyb21WYWx1ZXNba2V5XSkpIHtcbiAgICAgICAgICAgICAgICBkaXJ0eUZpZWxkc0Zyb21WYWx1ZXNba2V5XSA9IG1hcmtGaWVsZHNEaXJ0eSh2YWx1ZSwgQXJyYXkuaXNBcnJheSh2YWx1ZSkgPyBbXSA6IHt9LCBmaWVsZFJlZik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBnZXREaXJ0eUZpZWxkcyh2YWx1ZSwgaXNOdWxsT3JVbmRlZmluZWQoZm9ybVZhbHVlcykgPyB7fSA6IGZvcm1WYWx1ZXNba2V5XSwgZGlydHlGaWVsZHNGcm9tVmFsdWVzW2tleV0sIGZpZWxkUmVmKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpc0VtcHR5RGlydHlDb250YWluZXIoZGlydHlGaWVsZHNGcm9tVmFsdWVzW2tleV0pKSB7XG4gICAgICAgICAgICAgICAgY2xlYXJEaXJ0eUZpZWxkKGRpcnR5RmllbGRzRnJvbVZhbHVlcywga2V5KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChkZWVwRXF1YWwodmFsdWUsIGZvcm1WYWx1ZXNba2V5XSkpIHtcbiAgICAgICAgICAgIGNsZWFyRGlydHlGaWVsZChkaXJ0eUZpZWxkc0Zyb21WYWx1ZXMsIGtleSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBkaXJ0eUZpZWxkc0Zyb21WYWx1ZXNba2V5XSA9IHRydWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGRpcnR5RmllbGRzRnJvbVZhbHVlcztcbn1cblxudmFyIGdldEZpZWxkVmFsdWVBcyA9ICh2YWx1ZSwgeyB2YWx1ZUFzTnVtYmVyLCB2YWx1ZUFzRGF0ZSwgc2V0VmFsdWVBcyB9KSA9PiBpc1VuZGVmaW5lZCh2YWx1ZSlcbiAgICA/IHZhbHVlXG4gICAgOiB2YWx1ZUFzTnVtYmVyXG4gICAgICAgID8gdmFsdWUgPT09ICcnXG4gICAgICAgICAgICA/IE5hTlxuICAgICAgICAgICAgOiB2YWx1ZVxuICAgICAgICAgICAgICAgID8gK3ZhbHVlXG4gICAgICAgICAgICAgICAgOiB2YWx1ZVxuICAgICAgICA6IHZhbHVlQXNEYXRlICYmIGlzU3RyaW5nKHZhbHVlKVxuICAgICAgICAgICAgPyBuZXcgRGF0ZSh2YWx1ZSlcbiAgICAgICAgICAgIDogc2V0VmFsdWVBc1xuICAgICAgICAgICAgICAgID8gc2V0VmFsdWVBcyh2YWx1ZSlcbiAgICAgICAgICAgICAgICA6IHZhbHVlO1xuXG5mdW5jdGlvbiBnZXRGaWVsZFZhbHVlKF9mKSB7XG4gICAgY29uc3QgcmVmID0gX2YucmVmO1xuICAgIGlmIChpc0ZpbGVJbnB1dChyZWYpKSB7XG4gICAgICAgIHJldHVybiByZWYuZmlsZXM7XG4gICAgfVxuICAgIGlmIChpc1JhZGlvSW5wdXQocmVmKSkge1xuICAgICAgICByZXR1cm4gZ2V0UmFkaW9WYWx1ZShfZi5yZWZzKS52YWx1ZTtcbiAgICB9XG4gICAgaWYgKGlzTXVsdGlwbGVTZWxlY3QocmVmKSkge1xuICAgICAgICByZXR1cm4gWy4uLnJlZi5zZWxlY3RlZE9wdGlvbnNdLm1hcCgoeyB2YWx1ZSB9KSA9PiB2YWx1ZSk7XG4gICAgfVxuICAgIGlmIChpc0NoZWNrQm94SW5wdXQocmVmKSkge1xuICAgICAgICByZXR1cm4gZ2V0Q2hlY2tib3hWYWx1ZShfZi5yZWZzKS52YWx1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGdldEZpZWxkVmFsdWVBcyhyZWYudmFsdWUsIF9mKTtcbn1cblxudmFyIGdldFJlc29sdmVyT3B0aW9ucyA9IChmaWVsZHNOYW1lcywgX2ZpZWxkcywgY3JpdGVyaWFNb2RlLCBzaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uKSA9PiB7XG4gICAgY29uc3QgZmllbGRzID0ge307XG4gICAgZm9yIChjb25zdCBuYW1lIG9mIGZpZWxkc05hbWVzKSB7XG4gICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICBmaWVsZCAmJiBzZXQoZmllbGRzLCBuYW1lLCBmaWVsZC5fZik7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIGNyaXRlcmlhTW9kZSxcbiAgICAgICAgbmFtZXM6IFsuLi5maWVsZHNOYW1lc10sXG4gICAgICAgIGZpZWxkcyxcbiAgICAgICAgc2hvdWxkVXNlTmF0aXZlVmFsaWRhdGlvbixcbiAgICB9O1xufTtcblxudmFyIGdldFJ1bGVWYWx1ZSA9IChydWxlKSA9PiBpc1VuZGVmaW5lZChydWxlKVxuICAgID8gcnVsZVxuICAgIDogaXNSZWdleChydWxlKVxuICAgICAgICA/IHJ1bGUuc291cmNlXG4gICAgICAgIDogaXNPYmplY3QocnVsZSlcbiAgICAgICAgICAgID8gaXNSZWdleChydWxlLnZhbHVlKVxuICAgICAgICAgICAgICAgID8gcnVsZS52YWx1ZS5zb3VyY2VcbiAgICAgICAgICAgICAgICA6IHJ1bGUudmFsdWVcbiAgICAgICAgICAgIDogcnVsZTtcblxuY29uc3QgQVNZTkNfRlVOQ1RJT04gPSAnQXN5bmNGdW5jdGlvbic7XG52YXIgaGFzUHJvbWlzZVZhbGlkYXRpb24gPSAoZmllbGRSZWZlcmVuY2UpID0+IHtcbiAgICBpZiAoIWZpZWxkUmVmZXJlbmNlIHx8ICFmaWVsZFJlZmVyZW5jZS52YWxpZGF0ZSlcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIGlmIChpc0Z1bmN0aW9uKGZpZWxkUmVmZXJlbmNlLnZhbGlkYXRlKSkge1xuICAgICAgICByZXR1cm4gZmllbGRSZWZlcmVuY2UudmFsaWRhdGUuY29uc3RydWN0b3IubmFtZSA9PT0gQVNZTkNfRlVOQ1RJT047XG4gICAgfVxuICAgIGlmIChpc09iamVjdChmaWVsZFJlZmVyZW5jZS52YWxpZGF0ZSkpIHtcbiAgICAgICAgZm9yIChjb25zdCBrZXkgaW4gZmllbGRSZWZlcmVuY2UudmFsaWRhdGUpIHtcbiAgICAgICAgICAgIGlmIChmaWVsZFJlZmVyZW5jZS52YWxpZGF0ZVtrZXldLmNvbnN0cnVjdG9yXG4gICAgICAgICAgICAgICAgLm5hbWUgPT09IEFTWU5DX0ZVTkNUSU9OKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xufTtcblxudmFyIGhhc1ZhbGlkYXRpb24gPSAob3B0aW9ucykgPT4gb3B0aW9ucy5tb3VudCAmJlxuICAgIChvcHRpb25zLnJlcXVpcmVkIHx8XG4gICAgICAgIG9wdGlvbnMubWluIHx8XG4gICAgICAgIG9wdGlvbnMubWF4IHx8XG4gICAgICAgIG9wdGlvbnMubWF4TGVuZ3RoIHx8XG4gICAgICAgIG9wdGlvbnMubWluTGVuZ3RoIHx8XG4gICAgICAgIG9wdGlvbnMucGF0dGVybiB8fFxuICAgICAgICBvcHRpb25zLnZhbGlkYXRlKTtcblxuZnVuY3Rpb24gc2NoZW1hRXJyb3JMb29rdXAoZXJyb3JzLCBfZmllbGRzLCBuYW1lKSB7XG4gICAgY29uc3QgZXJyb3IgPSBnZXQoZXJyb3JzLCBuYW1lKTtcbiAgICBpZiAoZXJyb3IgfHwgaXNLZXkobmFtZSkpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGVycm9yLFxuICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgY29uc3QgbmFtZXMgPSBuYW1lLnNwbGl0KCcuJyk7XG4gICAgd2hpbGUgKG5hbWVzLmxlbmd0aCkge1xuICAgICAgICBjb25zdCBmaWVsZE5hbWUgPSBuYW1lcy5qb2luKCcuJyk7XG4gICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIGZpZWxkTmFtZSk7XG4gICAgICAgIGNvbnN0IGZvdW5kRXJyb3IgPSBnZXQoZXJyb3JzLCBmaWVsZE5hbWUpO1xuICAgICAgICBpZiAoZmllbGQgJiYgIUFycmF5LmlzQXJyYXkoZmllbGQpICYmIG5hbWUgIT09IGZpZWxkTmFtZSkge1xuICAgICAgICAgICAgcmV0dXJuIHsgbmFtZSB9O1xuICAgICAgICB9XG4gICAgICAgIGlmIChmb3VuZEVycm9yICYmIGZvdW5kRXJyb3IudHlwZSkge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBuYW1lOiBmaWVsZE5hbWUsXG4gICAgICAgICAgICAgICAgZXJyb3I6IGZvdW5kRXJyb3IsXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGlmIChmb3VuZEVycm9yICYmIGZvdW5kRXJyb3Iucm9vdCAmJiBmb3VuZEVycm9yLnJvb3QudHlwZSkge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBuYW1lOiBgJHtmaWVsZE5hbWV9LnJvb3RgLFxuICAgICAgICAgICAgICAgIGVycm9yOiBmb3VuZEVycm9yLnJvb3QsXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIG5hbWVzLnBvcCgpO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBuYW1lLFxuICAgIH07XG59XG5cbnZhciBzaG91bGRSZW5kZXJGb3JtU3RhdGUgPSAoZm9ybVN0YXRlRGF0YSwgX3Byb3h5Rm9ybVN0YXRlLCB1cGRhdGVGb3JtU3RhdGUsIGlzUm9vdCkgPT4ge1xuICAgIHVwZGF0ZUZvcm1TdGF0ZShmb3JtU3RhdGVEYXRhKTtcbiAgICBjb25zdCBrZXlzID0gT2JqZWN0LmtleXMoZm9ybVN0YXRlRGF0YSkuZmlsdGVyKChrZXkpID0+IGtleSAhPT0gJ25hbWUnKTtcbiAgICByZXR1cm4gKCFrZXlzLmxlbmd0aCB8fFxuICAgICAgICAoaXNSb290ICYmIGtleXMubGVuZ3RoID49IE9iamVjdC5rZXlzKF9wcm94eUZvcm1TdGF0ZSkubGVuZ3RoKSB8fFxuICAgICAgICBrZXlzLmZpbmQoKGtleSkgPT4gX3Byb3h5Rm9ybVN0YXRlW2tleV0gPT09XG4gICAgICAgICAgICAoIWlzUm9vdCB8fCBWQUxJREFUSU9OX01PREUuYWxsKSkpO1xufTtcblxudmFyIHNob3VsZFN1YnNjcmliZUJ5TmFtZSA9IChuYW1lLCBzaWduYWxOYW1lLCBleGFjdCkgPT4gIW5hbWUgfHxcbiAgICAhc2lnbmFsTmFtZSB8fFxuICAgIG5hbWUgPT09IHNpZ25hbE5hbWUgfHxcbiAgICBjb252ZXJ0VG9BcnJheVBheWxvYWQobmFtZSkuc29tZSgoY3VycmVudE5hbWUpID0+IGN1cnJlbnROYW1lICYmXG4gICAgICAgIChleGFjdFxuICAgICAgICAgICAgPyBjdXJyZW50TmFtZSA9PT0gc2lnbmFsTmFtZSB8fCBjdXJyZW50TmFtZS5zdGFydHNXaXRoKHNpZ25hbE5hbWUgKyAnLicpXG4gICAgICAgICAgICA6IGN1cnJlbnROYW1lLnN0YXJ0c1dpdGgoc2lnbmFsTmFtZSkgfHxcbiAgICAgICAgICAgICAgICBzaWduYWxOYW1lLnN0YXJ0c1dpdGgoY3VycmVudE5hbWUpKSk7XG5cbnZhciBza2lwVmFsaWRhdGlvbiA9IChpc0JsdXJFdmVudCwgaXNUb3VjaGVkLCBpc1N1Ym1pdHRlZCwgcmVWYWxpZGF0ZU1vZGUsIG1vZGUpID0+IHtcbiAgICBpZiAobW9kZS5pc09uQWxsKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgZWxzZSBpZiAoIWlzU3VibWl0dGVkICYmIG1vZGUuaXNPblRvdWNoKSB7XG4gICAgICAgIHJldHVybiAhKGlzVG91Y2hlZCB8fCBpc0JsdXJFdmVudCk7XG4gICAgfVxuICAgIGVsc2UgaWYgKGlzU3VibWl0dGVkID8gcmVWYWxpZGF0ZU1vZGUuaXNPbkJsdXIgOiBtb2RlLmlzT25CbHVyKSB7XG4gICAgICAgIHJldHVybiAhaXNCbHVyRXZlbnQ7XG4gICAgfVxuICAgIGVsc2UgaWYgKGlzU3VibWl0dGVkID8gcmVWYWxpZGF0ZU1vZGUuaXNPbkNoYW5nZSA6IG1vZGUuaXNPbkNoYW5nZSkge1xuICAgICAgICByZXR1cm4gaXNCbHVyRXZlbnQ7XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xufTtcblxudmFyIHVuc2V0RW1wdHlBcnJheSA9IChyZWYsIG5hbWUpID0+IHtcbiAgICBjb25zdCBhcnJheSA9IGdldChyZWYsIG5hbWUpO1xuICAgICFjb21wYWN0KGFycmF5KS5sZW5ndGggJiZcbiAgICAgICAgIShhcnJheSA9PT0gbnVsbCB8fCBhcnJheSA9PT0gdm9pZCAwID8gdm9pZCAwIDogYXJyYXkucm9vdCkgJiZcbiAgICAgICAgdW5zZXQocmVmLCBuYW1lKTtcbn07XG5cbmNvbnN0IGRlZmF1bHRPcHRpb25zID0ge1xuICAgIG1vZGU6IFZBTElEQVRJT05fTU9ERS5vblN1Ym1pdCxcbiAgICByZVZhbGlkYXRlTW9kZTogVkFMSURBVElPTl9NT0RFLm9uQ2hhbmdlLFxuICAgIHNob3VsZEZvY3VzRXJyb3I6IHRydWUsXG59O1xuY29uc3QgRk9STV9FUlJPUl9UWVBFID0gJ2Zvcm0nO1xuY29uc3QgdXBkYXRlRGlydHlGaWVsZHMgPSAoZGlydHlGaWVsZHMsIG5leHREaXJ0eUZpZWxkcykgPT4ge1xuICAgIGZvciAoY29uc3Qga2V5IGluIGRpcnR5RmllbGRzKSB7XG4gICAgICAgIGlmICghKGtleSBpbiBuZXh0RGlydHlGaWVsZHMpKSB7XG4gICAgICAgICAgICBkZWxldGUgZGlydHlGaWVsZHNba2V5XTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBPYmplY3QuYXNzaWduKGRpcnR5RmllbGRzLCBuZXh0RGlydHlGaWVsZHMpO1xufTtcbmNvbnN0IERFRkFVTFRfRk9STV9TVEFURSA9IHtcbiAgICBzdWJtaXRDb3VudDogMCxcbiAgICBpc0RpcnR5OiBmYWxzZSxcbiAgICBpc1JlYWR5OiBmYWxzZSxcbiAgICBpc1ZhbGlkYXRpbmc6IGZhbHNlLFxuICAgIGlzU3VibWl0dGVkOiBmYWxzZSxcbiAgICBpc1N1Ym1pdHRpbmc6IGZhbHNlLFxuICAgIGlzU3VibWl0U3VjY2Vzc2Z1bDogZmFsc2UsXG4gICAgaXNWYWxpZDogZmFsc2UsXG4gICAgdG91Y2hlZEZpZWxkczoge30sXG4gICAgZGlydHlGaWVsZHM6IHt9LFxuICAgIHZhbGlkYXRpbmdGaWVsZHM6IHt9LFxufTtcbmZ1bmN0aW9uIGNyZWF0ZUZvcm1Db250cm9sKHByb3BzID0ge30pIHtcbiAgICBsZXQgX29wdGlvbnMgPSB7XG4gICAgICAgIC4uLmRlZmF1bHRPcHRpb25zLFxuICAgICAgICAuLi5wcm9wcyxcbiAgICB9O1xuICAgIGxldCBfZm9ybVN0YXRlID0ge1xuICAgICAgICAuLi5jbG9uZU9iamVjdChERUZBVUxUX0ZPUk1fU1RBVEUpLFxuICAgICAgICBpc0xvYWRpbmc6IGlzRnVuY3Rpb24oX29wdGlvbnMuZGVmYXVsdFZhbHVlcyksXG4gICAgICAgIGVycm9yczogX29wdGlvbnMuZXJyb3JzIHx8IHt9LFxuICAgICAgICBkaXNhYmxlZDogX29wdGlvbnMuZGlzYWJsZWQgfHwgZmFsc2UsXG4gICAgfTtcbiAgICBsZXQgX2ZpZWxkcyA9IHt9O1xuICAgIGxldCBfZGVmYXVsdFZhbHVlcyA9IGlzT2JqZWN0KF9vcHRpb25zLmRlZmF1bHRWYWx1ZXMpIHx8IGlzT2JqZWN0KF9vcHRpb25zLnZhbHVlcylcbiAgICAgICAgPyBjbG9uZU9iamVjdChfb3B0aW9ucy5kZWZhdWx0VmFsdWVzIHx8IF9vcHRpb25zLnZhbHVlcykgfHwge31cbiAgICAgICAgOiB7fTtcbiAgICBsZXQgX2Zvcm1WYWx1ZXMgPSBfb3B0aW9ucy5zaG91bGRVbnJlZ2lzdGVyXG4gICAgICAgID8ge31cbiAgICAgICAgOiBjbG9uZU9iamVjdChfZGVmYXVsdFZhbHVlcyk7XG4gICAgbGV0IF9zdGF0ZSA9IHtcbiAgICAgICAgYWN0aW9uOiBmYWxzZSxcbiAgICAgICAgYWN0aW9uQXJyYXlMZW5ndGhzOiBuZXcgTWFwKCksXG4gICAgICAgIG1vdW50OiBmYWxzZSxcbiAgICAgICAgd2F0Y2g6IGZhbHNlLFxuICAgICAgICBrZWVwSXNWYWxpZDogZmFsc2UsXG4gICAgfTtcbiAgICBsZXQgX25hbWVzID0ge1xuICAgICAgICBtb3VudDogbmV3IFNldCgpLFxuICAgICAgICBkaXNhYmxlZDogbmV3IFNldCgpLFxuICAgICAgICB1bk1vdW50OiBuZXcgU2V0KCksXG4gICAgICAgIGFycmF5OiBuZXcgU2V0KCksXG4gICAgICAgIHdhdGNoOiBuZXcgU2V0KCksXG4gICAgICAgIHJlZ2lzdGVyTmFtZTogbmV3IFNldCgpLFxuICAgIH07XG4gICAgY29uc3QgZGVsYXlFcnJvckNhbGxiYWNrcyA9IHt9O1xuICAgIGNvbnN0IHRpbWVycyA9IHt9O1xuICAgIGxldCBfdmFsdWVzU3Vic2NyaWJlckNvdW50ID0gMDtcbiAgICBsZXQgX3ZhbGlkYXRpb25Nb2RlQmVmb3JlU3VibWl0ID0gZ2V0VmFsaWRhdGlvbk1vZGVzKF9vcHRpb25zLm1vZGUpO1xuICAgIGxldCBfdmFsaWRhdGlvbk1vZGVBZnRlclN1Ym1pdCA9IGdldFZhbGlkYXRpb25Nb2Rlcyhfb3B0aW9ucy5yZVZhbGlkYXRlTW9kZSk7XG4gICAgY29uc3QgZGVmYXVsdFByb3h5Rm9ybVN0YXRlID0ge1xuICAgICAgICBpc0RpcnR5OiBmYWxzZSxcbiAgICAgICAgZGlydHlGaWVsZHM6IGZhbHNlLFxuICAgICAgICB2YWxpZGF0aW5nRmllbGRzOiBmYWxzZSxcbiAgICAgICAgdG91Y2hlZEZpZWxkczogZmFsc2UsXG4gICAgICAgIGlzVmFsaWRhdGluZzogZmFsc2UsXG4gICAgICAgIGlzVmFsaWQ6IGZhbHNlLFxuICAgICAgICBlcnJvcnM6IGZhbHNlLFxuICAgIH07XG4gICAgY29uc3QgX3Byb3h5Rm9ybVN0YXRlID0ge1xuICAgICAgICAuLi5kZWZhdWx0UHJveHlGb3JtU3RhdGUsXG4gICAgfTtcbiAgICBsZXQgX3Byb3h5U3Vic2NyaWJlRm9ybVN0YXRlID0ge1xuICAgICAgICAuLi5fcHJveHlGb3JtU3RhdGUsXG4gICAgfTtcbiAgICBjb25zdCBfc3ViamVjdHMgPSB7XG4gICAgICAgIGFycmF5OiBjcmVhdGVTdWJqZWN0KCksXG4gICAgICAgIHN0YXRlOiBjcmVhdGVTdWJqZWN0KCksXG4gICAgfTtcbiAgICBsZXQgX3NldFZhbGlkQ2FsbElkID0gMDtcbiAgICBjb25zdCBzaG91bGREaXNwbGF5QWxsQXNzb2NpYXRlZEVycm9ycyA9IF9vcHRpb25zLmNyaXRlcmlhTW9kZSA9PT0gVkFMSURBVElPTl9NT0RFLmFsbDtcbiAgICBjb25zdCBkZWJvdW5jZSA9IChuYW1lLCBjYWxsYmFjaykgPT4gKHdhaXQpID0+IHtcbiAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVyc1tuYW1lXSk7XG4gICAgICAgIHRpbWVyc1tuYW1lXSA9IHNldFRpbWVvdXQoY2FsbGJhY2ssIHdhaXQpO1xuICAgIH07XG4gICAgY29uc3QgX3NldFZhbGlkID0gYXN5bmMgKHNob3VsZFVwZGF0ZVZhbGlkKSA9PiB7XG4gICAgICAgIGlmIChfc3RhdGUua2VlcElzVmFsaWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIV9vcHRpb25zLmRpc2FibGVkICYmXG4gICAgICAgICAgICAoX3Byb3h5Rm9ybVN0YXRlLmlzVmFsaWQgfHxcbiAgICAgICAgICAgICAgICBfcHJveHlTdWJzY3JpYmVGb3JtU3RhdGUuaXNWYWxpZCB8fFxuICAgICAgICAgICAgICAgIHNob3VsZFVwZGF0ZVZhbGlkKSkge1xuICAgICAgICAgICAgY29uc3QgY2FsbElkID0gKytfc2V0VmFsaWRDYWxsSWQ7XG4gICAgICAgICAgICBsZXQgaXNWYWxpZDtcbiAgICAgICAgICAgIGlmIChfb3B0aW9ucy5yZXNvbHZlcikge1xuICAgICAgICAgICAgICAgIGlzVmFsaWQgPSBpc0VtcHR5T2JqZWN0KChhd2FpdCBfcnVuU2NoZW1hKCkpLmVycm9ycyk7XG4gICAgICAgICAgICAgICAgY2FsbElkID09PSBfc2V0VmFsaWRDYWxsSWQgJiYgX3VwZGF0ZUlzVmFsaWRhdGluZygpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgaXNWYWxpZCA9IGF3YWl0IGV4ZWN1dGVCdWlsdEluVmFsaWRhdGlvbih7XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkczogX2ZpZWxkcyxcbiAgICAgICAgICAgICAgICAgICAgb25seUNoZWNrVmFsaWQ6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIGV2ZW50VHlwZTogRVZFTlRTLlZBTElELFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGNhbGxJZCA9PT0gX3NldFZhbGlkQ2FsbElkICYmIGlzVmFsaWQgIT09IF9mb3JtU3RhdGUuaXNWYWxpZCkge1xuICAgICAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAgICAgaXNWYWxpZCxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgX3VwZGF0ZUlzVmFsaWRhdGluZyA9IChuYW1lcywgaXNWYWxpZGF0aW5nKSA9PiB7XG4gICAgICAgIGlmICghX29wdGlvbnMuZGlzYWJsZWQgJiZcbiAgICAgICAgICAgIChfcHJveHlGb3JtU3RhdGUuaXNWYWxpZGF0aW5nIHx8XG4gICAgICAgICAgICAgICAgX3Byb3h5Rm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMgfHxcbiAgICAgICAgICAgICAgICBfcHJveHlTdWJzY3JpYmVGb3JtU3RhdGUuaXNWYWxpZGF0aW5nIHx8XG4gICAgICAgICAgICAgICAgX3Byb3h5U3Vic2NyaWJlRm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMpKSB7XG4gICAgICAgICAgICAobmFtZXMgfHwgQXJyYXkuZnJvbShfbmFtZXMubW91bnQpKS5mb3JFYWNoKChuYW1lKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKG5hbWUpIHtcbiAgICAgICAgICAgICAgICAgICAgaXNWYWxpZGF0aW5nXG4gICAgICAgICAgICAgICAgICAgICAgICA/IHNldChfZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMsIG5hbWUsIGlzVmFsaWRhdGluZylcbiAgICAgICAgICAgICAgICAgICAgICAgIDogdW5zZXQoX2Zvcm1TdGF0ZS52YWxpZGF0aW5nRmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICB2YWxpZGF0aW5nRmllbGRzOiBfZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMsXG4gICAgICAgICAgICAgICAgaXNWYWxpZGF0aW5nOiAhaXNFbXB0eU9iamVjdChfZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IF91cGRhdGVEaXJ0eUZpZWxkcyA9ICgpID0+IHtcbiAgICAgICAgX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcyA9IGdldERpcnR5RmllbGRzKF9kZWZhdWx0VmFsdWVzLCBfZm9ybVZhbHVlcywgdW5kZWZpbmVkLCBfZmllbGRzKTtcbiAgICB9O1xuICAgIGNvbnN0IF9zZXRGaWVsZEFycmF5ID0gKG5hbWUsIHZhbHVlcyA9IFtdLCBtZXRob2QsIGFyZ3MsIHNob3VsZFNldFZhbHVlcyA9IHRydWUsIHNob3VsZFVwZGF0ZUZpZWxkc0FuZFN0YXRlID0gdHJ1ZSkgPT4ge1xuICAgICAgICBpZiAoYXJncyAmJiBtZXRob2QgJiYgIV9vcHRpb25zLmRpc2FibGVkKSB7XG4gICAgICAgICAgICBfc3RhdGUuYWN0aW9uID0gdHJ1ZTtcbiAgICAgICAgICAgIGlmICghX3N0YXRlLmFjdGlvbkFycmF5TGVuZ3Rocy5oYXMobmFtZSkpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBwcmVBY3Rpb25GaWVsZHMgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICAgICAgX3N0YXRlLmFjdGlvbkFycmF5TGVuZ3Rocy5zZXQobmFtZSwgQXJyYXkuaXNBcnJheShwcmVBY3Rpb25GaWVsZHMpID8gcHJlQWN0aW9uRmllbGRzLmxlbmd0aCA6IDApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHNob3VsZFVwZGF0ZUZpZWxkc0FuZFN0YXRlICYmIEFycmF5LmlzQXJyYXkoZ2V0KF9maWVsZHMsIG5hbWUpKSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkVmFsdWVzID0gbWV0aG9kKGdldChfZmllbGRzLCBuYW1lKSwgYXJncy5hcmdBLCBhcmdzLmFyZ0IpO1xuICAgICAgICAgICAgICAgIHNob3VsZFNldFZhbHVlcyAmJiBzZXQoX2ZpZWxkcywgbmFtZSwgZmllbGRWYWx1ZXMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHNob3VsZFVwZGF0ZUZpZWxkc0FuZFN0YXRlICYmXG4gICAgICAgICAgICAgICAgQXJyYXkuaXNBcnJheShnZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpKSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkQXJyYXlFcnJvcnMgPSBnZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHJvb3RFcnJvciA9IGZpZWxkQXJyYXlFcnJvcnMucm9vdDtcbiAgICAgICAgICAgICAgICBjb25zdCBlcnJvcnMgPSBtZXRob2QoZmllbGRBcnJheUVycm9ycywgYXJncy5hcmdBLCBhcmdzLmFyZ0IpIHx8IGZpZWxkQXJyYXlFcnJvcnM7XG4gICAgICAgICAgICAgICAgaWYgKHJvb3RFcnJvcikge1xuICAgICAgICAgICAgICAgICAgICBlcnJvcnMucm9vdCA9IHJvb3RFcnJvcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgc2hvdWxkU2V0VmFsdWVzICYmIHNldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSwgZXJyb3JzKTtcbiAgICAgICAgICAgICAgICB1bnNldEVtcHR5QXJyYXkoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKChfcHJveHlGb3JtU3RhdGUudG91Y2hlZEZpZWxkcyB8fFxuICAgICAgICAgICAgICAgIF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZS50b3VjaGVkRmllbGRzKSAmJlxuICAgICAgICAgICAgICAgIHNob3VsZFVwZGF0ZUZpZWxkc0FuZFN0YXRlICYmXG4gICAgICAgICAgICAgICAgQXJyYXkuaXNBcnJheShnZXQoX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCBuYW1lKSkpIHtcbiAgICAgICAgICAgICAgICBjb25zdCB0b3VjaGVkRmllbGRzID0gbWV0aG9kKGdldChfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIG5hbWUpLCBhcmdzLmFyZ0EsIGFyZ3MuYXJnQik7XG4gICAgICAgICAgICAgICAgc2hvdWxkU2V0VmFsdWVzICYmIHNldChfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIG5hbWUsIHRvdWNoZWRGaWVsZHMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKF9wcm94eUZvcm1TdGF0ZS5kaXJ0eUZpZWxkcyB8fCBfcHJveHlTdWJzY3JpYmVGb3JtU3RhdGUuZGlydHlGaWVsZHMpIHtcbiAgICAgICAgICAgICAgICBfdXBkYXRlRGlydHlGaWVsZHMoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgIGlzRGlydHk6IF9nZXREaXJ0eShuYW1lLCB2YWx1ZXMpLFxuICAgICAgICAgICAgICAgIGRpcnR5RmllbGRzOiBfZm9ybVN0YXRlLmRpcnR5RmllbGRzLFxuICAgICAgICAgICAgICAgIGVycm9yczogX2Zvcm1TdGF0ZS5lcnJvcnMsXG4gICAgICAgICAgICAgICAgaXNWYWxpZDogX2Zvcm1TdGF0ZS5pc1ZhbGlkLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBzZXQoX2Zvcm1WYWx1ZXMsIG5hbWUsIHZhbHVlcyk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHVwZGF0ZUVycm9ycyA9IChuYW1lLCBlcnJvcikgPT4ge1xuICAgICAgICBzZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUsIGVycm9yKTtcbiAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7IC4uLl9mb3JtU3RhdGUuZXJyb3JzIH07XG4gICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgIGVycm9yczogX2Zvcm1TdGF0ZS5lcnJvcnMsXG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3QgX3NldEVycm9ycyA9IChlcnJvcnMpID0+IHtcbiAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSBlcnJvcnM7XG4gICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgIGVycm9yczogX2Zvcm1TdGF0ZS5lcnJvcnMsXG4gICAgICAgICAgICBpc1ZhbGlkOiBmYWxzZSxcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCBoYXNFeHBsaWNpdE51bGxJbnRlcm1lZGlhdGUgPSAobmFtZSkgPT4ge1xuICAgICAgICBjb25zdCBzZWdtZW50cyA9IGlzS2V5KG5hbWUpID8gW25hbWVdIDogc3RyaW5nVG9QYXRoKG5hbWUpO1xuICAgICAgICBsZXQgZm9ybVZhbHVlcyA9IF9mb3JtVmFsdWVzO1xuICAgICAgICBsZXQgZGVmYXVsdFZhbHVlcyA9IF9kZWZhdWx0VmFsdWVzO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNlZ21lbnRzLmxlbmd0aCAtIDE7IGkrKykge1xuICAgICAgICAgICAgY29uc3Qga2V5ID0gc2VnbWVudHNbaV07XG4gICAgICAgICAgICBmb3JtVmFsdWVzID0gaXNOdWxsT3JVbmRlZmluZWQoZm9ybVZhbHVlcykgPyBmb3JtVmFsdWVzIDogZm9ybVZhbHVlc1trZXldO1xuICAgICAgICAgICAgZGVmYXVsdFZhbHVlcyA9IGlzTnVsbE9yVW5kZWZpbmVkKGRlZmF1bHRWYWx1ZXMpXG4gICAgICAgICAgICAgICAgPyBkZWZhdWx0VmFsdWVzXG4gICAgICAgICAgICAgICAgOiBkZWZhdWx0VmFsdWVzW2tleV07XG4gICAgICAgICAgICBpZiAoZm9ybVZhbHVlcyA9PT0gbnVsbCAmJiBkZWZhdWx0VmFsdWVzICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH07XG4gICAgY29uc3QgaXNTdGFsZUFycmF5SW5kZXggPSAobmFtZSkgPT4ge1xuICAgICAgICBpZiAoIV9zdGF0ZS5hY3Rpb25BcnJheUxlbmd0aHMuc2l6ZSkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHNlZ21lbnRzID0gaXNLZXkobmFtZSkgPyBbbmFtZV0gOiBzdHJpbmdUb1BhdGgobmFtZSk7XG4gICAgICAgIGxldCBub2RlID0gX2Zvcm1WYWx1ZXM7XG4gICAgICAgIGxldCBwYXRoID0gJyc7XG4gICAgICAgIGxldCBvd25lckRlcHRoID0gLTE7XG4gICAgICAgIGxldCBvd25lclByZUFjdGlvbkxlbmd0aCA9IDA7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2VnbWVudHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGlmIChpc051bGxPclVuZGVmaW5lZChub2RlKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGtleSA9IHNlZ21lbnRzW2ldO1xuICAgICAgICAgICAgcGF0aCA9IHBhdGggPyBgJHtwYXRofS4ke2tleX1gIDoga2V5O1xuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkobm9kZSkgJiYgK2tleSA+PSBub2RlLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBvd25lckRlcHRoID09PSAtMVxuICAgICAgICAgICAgICAgICAgICA/IGZhbHNlXG4gICAgICAgICAgICAgICAgICAgIDogaSA9PT0gb3duZXJEZXB0aFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAra2V5IDwgb3duZXJQcmVBY3Rpb25MZW5ndGhcbiAgICAgICAgICAgICAgICAgICAgICAgIDogdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChfc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLmhhcyhwYXRoKSkge1xuICAgICAgICAgICAgICAgIG93bmVyRGVwdGggPSBpICsgMTtcbiAgICAgICAgICAgICAgICBvd25lclByZUFjdGlvbkxlbmd0aCA9IF9zdGF0ZS5hY3Rpb25BcnJheUxlbmd0aHMuZ2V0KHBhdGgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbm9kZSA9IG5vZGVba2V5XTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfTtcbiAgICBjb25zdCB1cGRhdGVWYWxpZEFuZFZhbHVlID0gKG5hbWUsIHNob3VsZFNraXBTZXRWYWx1ZUFzLCB2YWx1ZSwgcmVmKSA9PiB7XG4gICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICBpZiAoZmllbGQpIHtcbiAgICAgICAgICAgIGlmIChoYXNFeHBsaWNpdE51bGxJbnRlcm1lZGlhdGUobmFtZSkgfHwgaXNTdGFsZUFycmF5SW5kZXgobmFtZSkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCB3YXNVbnNldEluRm9ybVZhbHVlcyA9IGlzVW5kZWZpbmVkKGdldChfZm9ybVZhbHVlcywgbmFtZSkpO1xuICAgICAgICAgICAgY29uc3QgZGVmYXVsdFZhbHVlID0gZ2V0KF9mb3JtVmFsdWVzLCBuYW1lLCBpc1VuZGVmaW5lZCh2YWx1ZSkgPyBnZXQoX2RlZmF1bHRWYWx1ZXMsIG5hbWUpIDogdmFsdWUpO1xuICAgICAgICAgICAgaXNVbmRlZmluZWQoZGVmYXVsdFZhbHVlKSB8fFxuICAgICAgICAgICAgICAgIChyZWYgJiYgcmVmLmRlZmF1bHRDaGVja2VkKSB8fFxuICAgICAgICAgICAgICAgIHNob3VsZFNraXBTZXRWYWx1ZUFzXG4gICAgICAgICAgICAgICAgPyBzZXQoX2Zvcm1WYWx1ZXMsIG5hbWUsIHNob3VsZFNraXBTZXRWYWx1ZUFzID8gZGVmYXVsdFZhbHVlIDogZ2V0RmllbGRWYWx1ZShmaWVsZC5fZikpXG4gICAgICAgICAgICAgICAgOiBzZXRGaWVsZFZhbHVlKG5hbWUsIGRlZmF1bHRWYWx1ZSk7XG4gICAgICAgICAgICBpZiAoX3N0YXRlLm1vdW50ICYmICFfc3RhdGUuYWN0aW9uKSB7XG4gICAgICAgICAgICAgICAgX3NldFZhbGlkKCk7XG4gICAgICAgICAgICAgICAgaWYgKHdhc1Vuc2V0SW5Gb3JtVmFsdWVzICYmXG4gICAgICAgICAgICAgICAgICAgIF9mb3JtU3RhdGUuaXNEaXJ0eSAmJlxuICAgICAgICAgICAgICAgICAgICAoX3Byb3h5Rm9ybVN0YXRlLmlzRGlydHkgfHwgX3Byb3h5U3Vic2NyaWJlRm9ybVN0YXRlLmlzRGlydHkpKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzRGlydHkgPSBfZ2V0RGlydHkoKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFpc0RpcnR5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBfZm9ybVN0YXRlLmlzRGlydHkgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHsgLi4uX2Zvcm1TdGF0ZSB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAocHJvcHMuc2hvdWxkVW5yZWdpc3RlciAmJlxuICAgICAgICAgICAgICAgICAgICB3YXNVbnNldEluRm9ybVZhbHVlcyAmJlxuICAgICAgICAgICAgICAgICAgICAhaXNVbmRlZmluZWQoZ2V0KF9mb3JtVmFsdWVzLCBuYW1lKSkgJiZcbiAgICAgICAgICAgICAgICAgICAgaXNXYXRjaGVkKG5hbWUsIF9uYW1lcykpIHtcbiAgICAgICAgICAgICAgICAgICAgX3N0YXRlLndhdGNoID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHVwZGF0ZVRvdWNoQW5kRGlydHkgPSAobmFtZSwgZmllbGRWYWx1ZSwgaXNCbHVyRXZlbnQsIHNob3VsZERpcnR5LCBzaG91bGRSZW5kZXIpID0+IHtcbiAgICAgICAgbGV0IHNob3VsZFVwZGF0ZUZpZWxkID0gZmFsc2U7XG4gICAgICAgIGxldCBpc1ByZXZpb3VzRGlydHkgPSBmYWxzZTtcbiAgICAgICAgY29uc3Qgb3V0cHV0ID0ge1xuICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgfTtcbiAgICAgICAgLy8gYW4gZXhwbGljaXQgcHJvZ3JhbW1hdGljIHVwZGF0ZSAoZS5nLiBzZXRWYWx1ZSB3aXRoIHNob3VsZERpcnR5OiB0cnVlKVxuICAgICAgICAvLyBvcHRzIGludG8gZGlydHkgdHJhY2tpbmcgZXZlbiB3aGVuIHRoZSBmb3JtIGlzIGRpc2FibGVkXG4gICAgICAgIGlmICghX29wdGlvbnMuZGlzYWJsZWQgfHwgc2hvdWxkRGlydHkgPT09IHRydWUpIHtcbiAgICAgICAgICAgIGlmICghaXNCbHVyRXZlbnQgfHwgc2hvdWxkRGlydHkpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBpc0N1cnJlbnRGaWVsZFByaXN0aW5lID0gZGVlcEVxdWFsKGdldChfZGVmYXVsdFZhbHVlcywgbmFtZSksIGZpZWxkVmFsdWUpO1xuICAgICAgICAgICAgICAgIGlmIChfcHJveHlGb3JtU3RhdGUuaXNEaXJ0eSB8fCBfcHJveHlTdWJzY3JpYmVGb3JtU3RhdGUuaXNEaXJ0eSkge1xuICAgICAgICAgICAgICAgICAgICBpc1ByZXZpb3VzRGlydHkgPSBfZm9ybVN0YXRlLmlzRGlydHk7XG4gICAgICAgICAgICAgICAgICAgIF9mb3JtU3RhdGUuaXNEaXJ0eSA9IG91dHB1dC5pc0RpcnR5ID1cbiAgICAgICAgICAgICAgICAgICAgICAgICFpc0N1cnJlbnRGaWVsZFByaXN0aW5lIHx8IF9nZXREaXJ0eSgpO1xuICAgICAgICAgICAgICAgICAgICBzaG91bGRVcGRhdGVGaWVsZCA9IGlzUHJldmlvdXNEaXJ0eSAhPT0gb3V0cHV0LmlzRGlydHk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlzUHJldmlvdXNEaXJ0eSA9ICEhZ2V0KF9mb3JtU3RhdGUuZGlydHlGaWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIGlmIChpc0N1cnJlbnRGaWVsZFByaXN0aW5lICE9PSBfZm9ybVN0YXRlLmlzRGlydHkpIHtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlRGlydHlGaWVsZHMoX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcywgZ2V0RGlydHlGaWVsZHMoX2RlZmF1bHRWYWx1ZXMsIF9mb3JtVmFsdWVzLCB1bmRlZmluZWQsIF9maWVsZHMpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGlzQ3VycmVudEZpZWxkUHJpc3RpbmVcbiAgICAgICAgICAgICAgICAgICAgICAgID8gdW5zZXQoX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcywgbmFtZSlcbiAgICAgICAgICAgICAgICAgICAgICAgIDogc2V0KF9mb3JtU3RhdGUuZGlydHlGaWVsZHMsIG5hbWUsIHRydWUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBvdXRwdXQuZGlydHlGaWVsZHMgPSBfZm9ybVN0YXRlLmRpcnR5RmllbGRzO1xuICAgICAgICAgICAgICAgIHNob3VsZFVwZGF0ZUZpZWxkID1cbiAgICAgICAgICAgICAgICAgICAgc2hvdWxkVXBkYXRlRmllbGQgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICgoX3Byb3h5Rm9ybVN0YXRlLmRpcnR5RmllbGRzIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3Byb3h5U3Vic2NyaWJlRm9ybVN0YXRlLmRpcnR5RmllbGRzKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzUHJldmlvdXNEaXJ0eSAhPT0gIWlzQ3VycmVudEZpZWxkUHJpc3RpbmUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGlzQmx1ckV2ZW50KSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaXNQcmV2aW91c0ZpZWxkVG91Y2hlZCA9IGdldChfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIGlmICghaXNQcmV2aW91c0ZpZWxkVG91Y2hlZCkge1xuICAgICAgICAgICAgICAgICAgICBzZXQoX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCBuYW1lLCBpc0JsdXJFdmVudCk7XG4gICAgICAgICAgICAgICAgICAgIG91dHB1dC50b3VjaGVkRmllbGRzID0gX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzO1xuICAgICAgICAgICAgICAgICAgICBzaG91bGRVcGRhdGVGaWVsZCA9XG4gICAgICAgICAgICAgICAgICAgICAgICBzaG91bGRVcGRhdGVGaWVsZCB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICgoX3Byb3h5Rm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3Byb3h5U3Vic2NyaWJlRm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzUHJldmlvdXNGaWVsZFRvdWNoZWQgIT09IGlzQmx1ckV2ZW50KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzaG91bGRVcGRhdGVGaWVsZCAmJiBzaG91bGRSZW5kZXIgJiYgX3N1YmplY3RzLnN0YXRlLm5leHQob3V0cHV0KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc2hvdWxkVXBkYXRlRmllbGQgPyBvdXRwdXQgOiB7fTtcbiAgICB9O1xuICAgIGNvbnN0IHNob3VsZFJlbmRlckJ5RXJyb3IgPSAobmFtZSwgaXNWYWxpZCwgZXJyb3IsIGZpZWxkU3RhdGUpID0+IHtcbiAgICAgICAgY29uc3QgcHJldmlvdXNGaWVsZEVycm9yID0gZ2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgY29uc3Qgc2hvdWxkVXBkYXRlVmFsaWQgPSAoX3Byb3h5Rm9ybVN0YXRlLmlzVmFsaWQgfHwgX3Byb3h5U3Vic2NyaWJlRm9ybVN0YXRlLmlzVmFsaWQpICYmXG4gICAgICAgICAgICBpc0Jvb2xlYW4oaXNWYWxpZCkgJiZcbiAgICAgICAgICAgIF9mb3JtU3RhdGUuaXNWYWxpZCAhPT0gaXNWYWxpZDtcbiAgICAgICAgaWYgKF9vcHRpb25zLmRlbGF5RXJyb3IgJiYgZXJyb3IpIHtcbiAgICAgICAgICAgIGRlbGF5RXJyb3JDYWxsYmFja3NbbmFtZV0gPSBkZWJvdW5jZShuYW1lLCAoKSA9PiB1cGRhdGVFcnJvcnMobmFtZSwgZXJyb3IpKTtcbiAgICAgICAgICAgIGRlbGF5RXJyb3JDYWxsYmFja3NbbmFtZV0oX29wdGlvbnMuZGVsYXlFcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjbGVhclRpbWVvdXQodGltZXJzW25hbWVdKTtcbiAgICAgICAgICAgIGRlbGV0ZSBkZWxheUVycm9yQ2FsbGJhY2tzW25hbWVdO1xuICAgICAgICAgICAgZXJyb3JcbiAgICAgICAgICAgICAgICA/IHNldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSwgZXJyb3IpXG4gICAgICAgICAgICAgICAgOiB1bnNldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSk7XG4gICAgICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IHsgLi4uX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoKGVycm9yID8gIWRlZXBFcXVhbChwcmV2aW91c0ZpZWxkRXJyb3IsIGVycm9yKSA6IHByZXZpb3VzRmllbGRFcnJvcikgfHxcbiAgICAgICAgICAgICFpc0VtcHR5T2JqZWN0KGZpZWxkU3RhdGUpIHx8XG4gICAgICAgICAgICBzaG91bGRVcGRhdGVWYWxpZCkge1xuICAgICAgICAgICAgY29uc3QgdXBkYXRlZEZvcm1TdGF0ZSA9IHtcbiAgICAgICAgICAgICAgICAuLi5maWVsZFN0YXRlLFxuICAgICAgICAgICAgICAgIC4uLihzaG91bGRVcGRhdGVWYWxpZCAmJiBpc0Jvb2xlYW4oaXNWYWxpZCkgPyB7IGlzVmFsaWQgfSA6IHt9KSxcbiAgICAgICAgICAgICAgICBlcnJvcnM6IF9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZSA9IHtcbiAgICAgICAgICAgICAgICAuLi5fZm9ybVN0YXRlLFxuICAgICAgICAgICAgICAgIC4uLnVwZGF0ZWRGb3JtU3RhdGUsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQodXBkYXRlZEZvcm1TdGF0ZSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IF9ydW5TY2hlbWEgPSBhc3luYyAobmFtZSkgPT4ge1xuICAgICAgICBfdXBkYXRlSXNWYWxpZGF0aW5nKG5hbWUsIHRydWUpO1xuICAgICAgICByZXR1cm4gYXdhaXQgX29wdGlvbnMucmVzb2x2ZXIoX2Zvcm1WYWx1ZXMsIF9vcHRpb25zLmNvbnRleHQsIGdldFJlc29sdmVyT3B0aW9ucyhuYW1lIHx8IF9uYW1lcy5tb3VudCwgX2ZpZWxkcywgX29wdGlvbnMuY3JpdGVyaWFNb2RlLCBfb3B0aW9ucy5zaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uKSk7XG4gICAgfTtcbiAgICBjb25zdCBleGVjdXRlU2NoZW1hQW5kVXBkYXRlU3RhdGUgPSBhc3luYyAobmFtZXMpID0+IHtcbiAgICAgICAgY29uc3QgeyBlcnJvcnMgfSA9IGF3YWl0IF9ydW5TY2hlbWEobmFtZXMpO1xuICAgICAgICBfdXBkYXRlSXNWYWxpZGF0aW5nKG5hbWVzKTtcbiAgICAgICAgaWYgKG5hbWVzKSB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IG5hbWUgb2YgbmFtZXMpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBlcnJvciA9IGdldChlcnJvcnMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIGVycm9yXG4gICAgICAgICAgICAgICAgICAgID8gX25hbWVzLmFycmF5LmhhcyhuYW1lKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgaXNPYmplY3QoZXJyb3IpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAhT2JqZWN0LmtleXMoZXJyb3IpLnNvbWUoKGtleSkgPT4gIU51bWJlci5pc05hTihOdW1iZXIoa2V5KSkpXG4gICAgICAgICAgICAgICAgICAgICAgICA/IHVwZGF0ZUZpZWxkQXJyYXlSb290RXJyb3IoX2Zvcm1TdGF0ZS5lcnJvcnMsIHsgW25hbWVdOiBlcnJvciB9LCBuYW1lKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBzZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUsIGVycm9yKVxuICAgICAgICAgICAgICAgICAgICA6IHVuc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIF9mb3JtU3RhdGUuZXJyb3JzID0geyAuLi5fZm9ybVN0YXRlLmVycm9ycyB9O1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSBlcnJvcnM7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGVycm9ycztcbiAgICB9O1xuICAgIGNvbnN0IHZhbGlkYXRlRm9ybSA9IGFzeW5jICh7IG5hbWUsIGV2ZW50VHlwZSwgfSkgPT4ge1xuICAgICAgICBpZiAocHJvcHMudmFsaWRhdGUpIHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHByb3BzLnZhbGlkYXRlKHtcbiAgICAgICAgICAgICAgICBmb3JtVmFsdWVzOiBfZm9ybVZhbHVlcyxcbiAgICAgICAgICAgICAgICBmb3JtU3RhdGU6IF9mb3JtU3RhdGUsXG4gICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICBldmVudFR5cGUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmIChpc09iamVjdChyZXN1bHQpKSB7XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCBrZXkgaW4gcmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGVycm9yID0gcmVzdWx0W2tleV07XG4gICAgICAgICAgICAgICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3IoYCR7Rk9STV9FUlJPUl9UWVBFfS4ke2tleX1gLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogaXNTdHJpbmcoZXJyb3IubWVzc2FnZSkgPyBlcnJvci5tZXNzYWdlIDogJycsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogZXJyb3IudHlwZSB8fCBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLnZhbGlkYXRlLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChpc1N0cmluZyhyZXN1bHQpIHx8ICFyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICBzZXRFcnJvcihGT1JNX0VSUk9SX1RZUEUsIHtcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzdWx0IHx8ICcnLFxuICAgICAgICAgICAgICAgICAgICB0eXBlOiBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLnZhbGlkYXRlLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgY2xlYXJFcnJvcnMoRk9STV9FUlJPUl9UWVBFKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfTtcbiAgICBjb25zdCBleGVjdXRlQnVpbHRJblZhbGlkYXRpb24gPSBhc3luYyAoeyBmaWVsZHMsIG9ubHlDaGVja1ZhbGlkLCBuYW1lLCBldmVudFR5cGUsIGNvbnRleHQgPSB7XG4gICAgICAgIHZhbGlkOiB0cnVlLFxuICAgICAgICBydW5Sb290VmFsaWRhdGlvbjogZmFsc2UsXG4gICAgfSwgfSkgPT4ge1xuICAgICAgICBpZiAocHJvcHMudmFsaWRhdGUpIHtcbiAgICAgICAgICAgIGNvbnRleHQucnVuUm9vdFZhbGlkYXRpb24gPSB0cnVlO1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdmFsaWRhdGVGb3JtKHtcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgIGV2ZW50VHlwZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKCFyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICBjb250ZXh0LnZhbGlkID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgaWYgKG9ubHlDaGVja1ZhbGlkKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBjb250ZXh0LnZhbGlkO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBmb3IgKGNvbnN0IG5hbWUgaW4gZmllbGRzKSB7XG4gICAgICAgICAgICBjb25zdCBmaWVsZCA9IGZpZWxkc1tuYW1lXTtcbiAgICAgICAgICAgIGlmIChmaWVsZCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHsgX2YsIC4uLmZpZWxkVmFsdWUgfSA9IGZpZWxkO1xuICAgICAgICAgICAgICAgIGlmIChfZikge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0ZpZWxkQXJyYXlSb290ID0gX25hbWVzLmFycmF5LmhhcyhfZi5uYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNQcm9taXNlRnVuY3Rpb24gPSBmaWVsZC5fZiAmJiBoYXNQcm9taXNlVmFsaWRhdGlvbihmaWVsZC5fZik7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHNob3VsZFRyYWNrSXNWYWxpZGF0aW5nU3RhdGUgPSBfcHJveHlGb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcyB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgX3Byb3h5Rm9ybVN0YXRlLmlzVmFsaWRhdGluZyB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgX3Byb3h5U3Vic2NyaWJlRm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZS5pc1ZhbGlkYXRpbmc7XG4gICAgICAgICAgICAgICAgICAgIGlmIChpc1Byb21pc2VGdW5jdGlvbiAmJiBzaG91bGRUcmFja0lzVmFsaWRhdGluZ1N0YXRlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBfdXBkYXRlSXNWYWxpZGF0aW5nKFtfZi5uYW1lXSwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZmllbGRFcnJvciA9IGF3YWl0IHZhbGlkYXRlRmllbGQoZmllbGQsIF9uYW1lcy5kaXNhYmxlZCwgX2Zvcm1WYWx1ZXMsIHNob3VsZERpc3BsYXlBbGxBc3NvY2lhdGVkRXJyb3JzLCBfb3B0aW9ucy5zaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uICYmICFvbmx5Q2hlY2tWYWxpZCwgaXNGaWVsZEFycmF5Um9vdCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChpc1Byb21pc2VGdW5jdGlvbiAmJiBzaG91bGRUcmFja0lzVmFsaWRhdGluZ1N0YXRlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBfdXBkYXRlSXNWYWxpZGF0aW5nKFtfZi5uYW1lXSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKGZpZWxkRXJyb3JbX2YubmFtZV0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHQudmFsaWQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChvbmx5Q2hlY2tWYWxpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICFvbmx5Q2hlY2tWYWxpZCAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgKGdldChmaWVsZEVycm9yLCBfZi5uYW1lKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gaXNGaWVsZEFycmF5Um9vdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHVwZGF0ZUZpZWxkQXJyYXlSb290RXJyb3IoX2Zvcm1TdGF0ZS5lcnJvcnMsIGZpZWxkRXJyb3IsIF9mLm5hbWUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBfZi5uYW1lLCBmaWVsZEVycm9yW19mLm5hbWVdKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogdW5zZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIF9mLm5hbWUpKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByb3BzLnNob3VsZFVzZU5hdGl2ZVZhbGlkYXRpb24gJiYgZmllbGRFcnJvcltfZi5uYW1lXSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgIWlzRW1wdHlPYmplY3QoZmllbGRWYWx1ZSkgJiZcbiAgICAgICAgICAgICAgICAgICAgKGF3YWl0IGV4ZWN1dGVCdWlsdEluVmFsaWRhdGlvbih7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgICAgICAgICAgICAgICAgb25seUNoZWNrVmFsaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWVsZHM6IGZpZWxkVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBuYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgZXZlbnRUeXBlLFxuICAgICAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGNvbnRleHQudmFsaWQ7XG4gICAgfTtcbiAgICBjb25zdCBfcmVtb3ZlVW5tb3VudGVkID0gKCkgPT4ge1xuICAgICAgICBmb3IgKGNvbnN0IG5hbWUgb2YgX25hbWVzLnVuTW91bnQpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgZmllbGQgJiZcbiAgICAgICAgICAgICAgICAoZmllbGQuX2YucmVmc1xuICAgICAgICAgICAgICAgICAgICA/IGZpZWxkLl9mLnJlZnMuZXZlcnkoKHJlZikgPT4gIWxpdmUocmVmKSlcbiAgICAgICAgICAgICAgICAgICAgOiAhbGl2ZShmaWVsZC5fZi5yZWYpKSAmJlxuICAgICAgICAgICAgICAgIHVucmVnaXN0ZXIobmFtZSk7XG4gICAgICAgIH1cbiAgICAgICAgX25hbWVzLnVuTW91bnQgPSBuZXcgU2V0KCk7XG4gICAgfTtcbiAgICBjb25zdCBfZ2V0RGlydHkgPSAobmFtZSwgZGF0YSkgPT4gKG5hbWUgJiYgZGF0YSAmJiBzZXQoX2Zvcm1WYWx1ZXMsIG5hbWUsIGRhdGEpLFxuICAgICAgICAhZGVlcEVxdWFsKF9zdGF0ZS5tb3VudCA/IF9mb3JtVmFsdWVzIDogX2RlZmF1bHRWYWx1ZXMsIF9kZWZhdWx0VmFsdWVzKSk7XG4gICAgY29uc3QgX2dldFdhdGNoID0gKG5hbWVzLCBkZWZhdWx0VmFsdWUsIGlzR2xvYmFsKSA9PiBnZW5lcmF0ZVdhdGNoT3V0cHV0KG5hbWVzLCBfbmFtZXMsIHtcbiAgICAgICAgLi4uKF9zdGF0ZS5tb3VudFxuICAgICAgICAgICAgPyBfZm9ybVZhbHVlc1xuICAgICAgICAgICAgOiBpc1VuZGVmaW5lZChkZWZhdWx0VmFsdWUpIHx8IGlzU3RyaW5nKG5hbWVzKVxuICAgICAgICAgICAgICAgID8gX2RlZmF1bHRWYWx1ZXNcbiAgICAgICAgICAgICAgICA6IGRlZmF1bHRWYWx1ZSksXG4gICAgfSwgaXNHbG9iYWwsIGRlZmF1bHRWYWx1ZSk7XG4gICAgY29uc3QgX2dldEZpZWxkQXJyYXkgPSAobmFtZSkgPT4gY29tcGFjdChnZXQoX3N0YXRlLm1vdW50ID8gX2Zvcm1WYWx1ZXMgOiBfZGVmYXVsdFZhbHVlcywgbmFtZSwgX29wdGlvbnMuc2hvdWxkVW5yZWdpc3RlciA/IGdldChfZGVmYXVsdFZhbHVlcywgbmFtZSwgW10pIDogW10pKTtcbiAgICBjb25zdCBzZXRGaWVsZFZhbHVlID0gKG5hbWUsIHZhbHVlLCBvcHRpb25zID0ge30sIHNraXBDbG9uZSA9IGZhbHNlLCBza2lwUmVuZGVyID0gZmFsc2UsIHNraXBWYWx1ZVJlbmRlciA9IGZhbHNlKSA9PiB7XG4gICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICBsZXQgZmllbGRWYWx1ZSA9IHZhbHVlO1xuICAgICAgICBpZiAoZmllbGQpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkUmVmZXJlbmNlID0gZmllbGQuX2Y7XG4gICAgICAgICAgICBpZiAoZmllbGRSZWZlcmVuY2UpIHtcbiAgICAgICAgICAgICAgICAhZmllbGRSZWZlcmVuY2UuZGlzYWJsZWQgJiZcbiAgICAgICAgICAgICAgICAgICAgc2V0KF9mb3JtVmFsdWVzLCBuYW1lLCBnZXRGaWVsZFZhbHVlQXModmFsdWUsIGZpZWxkUmVmZXJlbmNlKSk7XG4gICAgICAgICAgICAgICAgZmllbGRWYWx1ZSA9XG4gICAgICAgICAgICAgICAgICAgIGlzSFRNTEVsZW1lbnQoZmllbGRSZWZlcmVuY2UucmVmKSAmJiBpc051bGxPclVuZGVmaW5lZCh2YWx1ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJydcbiAgICAgICAgICAgICAgICAgICAgICAgIDogdmFsdWU7XG4gICAgICAgICAgICAgICAgaWYgKGlzTXVsdGlwbGVTZWxlY3QoZmllbGRSZWZlcmVuY2UucmVmKSkge1xuICAgICAgICAgICAgICAgICAgICBbLi4uZmllbGRSZWZlcmVuY2UucmVmLm9wdGlvbnNdLmZvckVhY2goKG9wdGlvblJlZikgPT4gKG9wdGlvblJlZi5zZWxlY3RlZCA9IGZpZWxkVmFsdWUuaW5jbHVkZXMob3B0aW9uUmVmLnZhbHVlKSkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChmaWVsZFJlZmVyZW5jZS5yZWZzKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChpc0NoZWNrQm94SW5wdXQoZmllbGRSZWZlcmVuY2UucmVmKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmllbGRSZWZlcmVuY2UucmVmcy5mb3JFYWNoKChjaGVja2JveFJlZikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghY2hlY2tib3hSZWYuZGVmYXVsdENoZWNrZWQgfHwgIWNoZWNrYm94UmVmLmRpc2FibGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGZpZWxkVmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2JveFJlZi5jaGVja2VkID0gISFmaWVsZFZhbHVlLmZpbmQoKGRhdGEpID0+IGRhdGEgPT09IGNoZWNrYm94UmVmLnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrYm94UmVmLmNoZWNrZWQgPVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkVmFsdWUgPT09IGNoZWNrYm94UmVmLnZhbHVlIHx8ICEhZmllbGRWYWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmllbGRSZWZlcmVuY2UucmVmcy5mb3JFYWNoKChyYWRpb1JlZikgPT4gKHJhZGlvUmVmLmNoZWNrZWQgPSByYWRpb1JlZi52YWx1ZSA9PT0gZmllbGRWYWx1ZSkpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGlzRmlsZUlucHV0KGZpZWxkUmVmZXJlbmNlLnJlZikpIHtcbiAgICAgICAgICAgICAgICAgICAgZmllbGRSZWZlcmVuY2UucmVmLnZhbHVlID0gJyc7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBmaWVsZFJlZmVyZW5jZS5yZWYudmFsdWUgPSBmaWVsZFZhbHVlO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWZpZWxkUmVmZXJlbmNlLnJlZi50eXBlICYmICFza2lwUmVuZGVyICYmICFza2lwVmFsdWVSZW5kZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlczogc2tpcENsb25lID8gX2Zvcm1WYWx1ZXMgOiBjbG9uZU9iamVjdChfZm9ybVZhbHVlcyksXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAob3B0aW9ucy5zaG91bGREaXJ0eSB8fCBvcHRpb25zLnNob3VsZFRvdWNoKSAmJlxuICAgICAgICAgICAgdXBkYXRlVG91Y2hBbmREaXJ0eShuYW1lLCBmaWVsZFZhbHVlLCBvcHRpb25zLnNob3VsZFRvdWNoLCBvcHRpb25zLnNob3VsZERpcnR5LCAhc2tpcFJlbmRlcik7XG4gICAgICAgIG9wdGlvbnMuc2hvdWxkVmFsaWRhdGUgJiZcbiAgICAgICAgICAgIHRyaWdnZXIobmFtZSwge1xuICAgICAgICAgICAgICAgIGRlbGF5RXJyb3I6IG9wdGlvbnMuZGVsYXlFcnJvcixcbiAgICAgICAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3Qgc2V0RmllbGRWYWx1ZXMgPSAobmFtZSwgdmFsdWUsIG9wdGlvbnMsIHNraXBDbG9uZSA9IGZhbHNlLCBza2lwUmVuZGVyID0gZmFsc2UsIHNraXBWYWx1ZVJlbmRlciA9IGZhbHNlKSA9PiB7XG4gICAgICAgIGlmIChfbmFtZXMuYXJyYXkuaGFzKG5hbWUpKSB7XG4gICAgICAgICAgICBfc3ViamVjdHMuYXJyYXkubmV4dCh7XG4gICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICB2YWx1ZXM6IHNraXBDbG9uZSA/IF9mb3JtVmFsdWVzIDogY2xvbmVPYmplY3QoX2Zvcm1WYWx1ZXMpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChjb25zdCBmaWVsZEtleSBpbiB2YWx1ZSkge1xuICAgICAgICAgICAgaWYgKCF2YWx1ZS5oYXNPd25Qcm9wZXJ0eShmaWVsZEtleSkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBmaWVsZFZhbHVlID0gdmFsdWVbZmllbGRLZXldO1xuICAgICAgICAgICAgY29uc3QgZmllbGROYW1lID0gbmFtZSArICcuJyArIGZpZWxkS2V5O1xuICAgICAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgZmllbGROYW1lKTtcbiAgICAgICAgICAgIChfbmFtZXMuYXJyYXkuaGFzKG5hbWUpIHx8XG4gICAgICAgICAgICAgICAgaXNPYmplY3QoZmllbGRWYWx1ZSkgfHxcbiAgICAgICAgICAgICAgICAoZmllbGQgJiYgIWZpZWxkLl9mKSkgJiZcbiAgICAgICAgICAgICAgICAhaXNEYXRlT2JqZWN0KGZpZWxkVmFsdWUpXG4gICAgICAgICAgICAgICAgPyBzZXRGaWVsZFZhbHVlcyhmaWVsZE5hbWUsIGZpZWxkVmFsdWUsIG9wdGlvbnMsIHNraXBDbG9uZSwgc2tpcFJlbmRlciwgc2tpcFZhbHVlUmVuZGVyKVxuICAgICAgICAgICAgICAgIDogc2V0RmllbGRWYWx1ZShmaWVsZE5hbWUsIGZpZWxkVmFsdWUsIG9wdGlvbnMsIHNraXBDbG9uZSwgc2tpcFJlbmRlciwgc2tpcFZhbHVlUmVuZGVyKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgX3NldFZhbHVlID0gKG5hbWUsIHZhbHVlLCBvcHRpb25zLCBza2lwQ2xvbmUsIHNraXBTdGF0ZUVtaXQgPSBmYWxzZSkgPT4ge1xuICAgICAgICBjb25zdCBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgY29uc3QgaXNGaWVsZEFycmF5ID0gX25hbWVzLmFycmF5LmhhcyhuYW1lKTtcbiAgICAgICAgY29uc3QgY2xvbmVWYWx1ZSA9IHNraXBDbG9uZSA/IHZhbHVlIDogY2xvbmVPYmplY3QodmFsdWUpO1xuICAgICAgICBjb25zdCBwcmV2aW91c1ZhbHVlID0gZ2V0KF9mb3JtVmFsdWVzLCBuYW1lKTtcbiAgICAgICAgY29uc3QgaXNWYWx1ZVVuY2hhbmdlZCA9IGRlZXBFcXVhbChwcmV2aW91c1ZhbHVlLCBjbG9uZVZhbHVlKTtcbiAgICAgICAgaWYgKCFpc1ZhbHVlVW5jaGFuZ2VkKSB7XG4gICAgICAgICAgICBzZXQoX2Zvcm1WYWx1ZXMsIG5hbWUsIGNsb25lVmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0ZpZWxkQXJyYXkpIHtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5hcnJheS5uZXh0KHtcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgIHZhbHVlczogc2tpcENsb25lID8gX2Zvcm1WYWx1ZXMgOiBjbG9uZU9iamVjdChfZm9ybVZhbHVlcyksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmICgoX3Byb3h5Rm9ybVN0YXRlLmlzRGlydHkgfHxcbiAgICAgICAgICAgICAgICBfcHJveHlGb3JtU3RhdGUuZGlydHlGaWVsZHMgfHxcbiAgICAgICAgICAgICAgICBfcHJveHlTdWJzY3JpYmVGb3JtU3RhdGUuaXNEaXJ0eSB8fFxuICAgICAgICAgICAgICAgIF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZS5kaXJ0eUZpZWxkcykgJiZcbiAgICAgICAgICAgICAgICBvcHRpb25zLnNob3VsZERpcnR5KSB7XG4gICAgICAgICAgICAgICAgX3VwZGF0ZURpcnR5RmllbGRzKCk7XG4gICAgICAgICAgICAgICAgaWYgKCFza2lwU3RhdGVFbWl0KSB7XG4gICAgICAgICAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXJ0eUZpZWxkczogX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzRGlydHk6IF9nZXREaXJ0eShuYW1lLCBjbG9uZVZhbHVlKSxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgaXNFbXB0eSA9IChBcnJheS5pc0FycmF5KGNsb25lVmFsdWUpICYmICFjbG9uZVZhbHVlLmxlbmd0aCkgfHxcbiAgICAgICAgICAgICAgICBpc0VtcHR5T2JqZWN0KGNsb25lVmFsdWUpO1xuICAgICAgICAgICAgY29uc3Qgc2tpcFZhbHVlUmVuZGVyID0gIWlzVmFsdWVVbmNoYW5nZWQgJiYgIXNraXBTdGF0ZUVtaXQ7XG4gICAgICAgICAgICBpZiAoIWZpZWxkIHx8IGZpZWxkLl9mIHx8IGlzTnVsbE9yVW5kZWZpbmVkKGNsb25lVmFsdWUpIHx8IGlzRW1wdHkpIHtcbiAgICAgICAgICAgICAgICBzZXRGaWVsZFZhbHVlKG5hbWUsIGNsb25lVmFsdWUsIG9wdGlvbnMsIHNraXBDbG9uZSwgc2tpcFN0YXRlRW1pdCwgc2tpcFZhbHVlUmVuZGVyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHNldEZpZWxkVmFsdWVzKG5hbWUsIGNsb25lVmFsdWUsIG9wdGlvbnMsIHNraXBDbG9uZSwgc2tpcFN0YXRlRW1pdCwgc2tpcFZhbHVlUmVuZGVyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIWlzVmFsdWVVbmNoYW5nZWQgJiYgIXNraXBTdGF0ZUVtaXQpIHtcbiAgICAgICAgICAgIGNvbnN0IHdhdGNoZWQgPSBpc1dhdGNoZWQobmFtZSwgX25hbWVzKTtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlcyA9IHNraXBDbG9uZSA/IF9mb3JtVmFsdWVzIDogY2xvbmVPYmplY3QoX2Zvcm1WYWx1ZXMpO1xuICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIC4uLih3YXRjaGVkICYmIF9mb3JtU3RhdGUpLFxuICAgICAgICAgICAgICAgIG5hbWU6IF9zdGF0ZS5tb3VudCB8fCB3YXRjaGVkID8gbmFtZSA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICB2YWx1ZXMsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3Qgc2V0VmFsdWUgPSAobmFtZSwgdmFsdWUsIG9wdGlvbnMgPSB7fSkgPT4gX3NldFZhbHVlKG5hbWUsIHZhbHVlLCBvcHRpb25zLCBmYWxzZSk7XG4gICAgY29uc3Qgc2V0VmFsdWVzID0gKGZvcm1WYWx1ZXMsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgICAgICBjb25zdCB1cGRhdGVkRm9ybVZhbHVlcyA9IGlzRnVuY3Rpb24oZm9ybVZhbHVlcylcbiAgICAgICAgICAgID8gZm9ybVZhbHVlcyhfZm9ybVZhbHVlcylcbiAgICAgICAgICAgIDogZm9ybVZhbHVlcztcbiAgICAgICAgaWYgKCFkZWVwRXF1YWwoX2Zvcm1WYWx1ZXMsIHVwZGF0ZWRGb3JtVmFsdWVzKSkge1xuICAgICAgICAgICAgX2Zvcm1WYWx1ZXMgPSB7XG4gICAgICAgICAgICAgICAgLi4uX2Zvcm1WYWx1ZXMsXG4gICAgICAgICAgICAgICAgLi4udXBkYXRlZEZvcm1WYWx1ZXMsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgY29uc3QgZmxhdHRlbmVkVXBkYXRlcyA9IGZsYXR0ZW4odXBkYXRlZEZvcm1WYWx1ZXMpO1xuICAgICAgICAgICAgZm9yIChjb25zdCBmaWVsZE5hbWUgb2YgX25hbWVzLm1vdW50KSB7XG4gICAgICAgICAgICAgICAgaWYgKGZpZWxkTmFtZSBpbiBmbGF0dGVuZWRVcGRhdGVzKSB7XG4gICAgICAgICAgICAgICAgICAgIF9zZXRWYWx1ZShmaWVsZE5hbWUsIGZsYXR0ZW5lZFVwZGF0ZXNbZmllbGROYW1lXSwgb3B0aW9ucywgdHJ1ZSwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIC4uLl9mb3JtU3RhdGUsXG4gICAgICAgICAgICAgICAgbmFtZTogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAuLi4oX3ZhbHVlc1N1YnNjcmliZXJDb3VudCA/IHsgdmFsdWVzOiBfZm9ybVZhbHVlcyB9IDoge30pLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5zaG91bGRWYWxpZGF0ZSkge1xuICAgICAgICAgICAgICAgIF9zZXRWYWxpZCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBvbkNoYW5nZSA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgICAgICBfc3RhdGUubW91bnQgPSB0cnVlO1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC50YXJnZXQ7XG4gICAgICAgIGxldCBuYW1lID0gdGFyZ2V0Lm5hbWU7XG4gICAgICAgIGxldCBpc0ZpZWxkVmFsdWVVcGRhdGVkID0gdHJ1ZTtcbiAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgIGNvbnN0IF91cGRhdGVJc0ZpZWxkVmFsdWVVcGRhdGVkID0gKGZpZWxkVmFsdWUpID0+IHtcbiAgICAgICAgICAgIGlzRmllbGRWYWx1ZVVwZGF0ZWQgPVxuICAgICAgICAgICAgICAgIE51bWJlci5pc05hTihmaWVsZFZhbHVlKSB8fFxuICAgICAgICAgICAgICAgICAgICAoaXNEYXRlT2JqZWN0KGZpZWxkVmFsdWUpICYmIGlzTmFOKGZpZWxkVmFsdWUuZ2V0VGltZSgpKSkgfHxcbiAgICAgICAgICAgICAgICAgICAgZGVlcEVxdWFsKGZpZWxkVmFsdWUsIGdldChfZm9ybVZhbHVlcywgbmFtZSwgZmllbGRWYWx1ZSkpO1xuICAgICAgICB9O1xuICAgICAgICBpZiAoZmllbGQpIHtcbiAgICAgICAgICAgIGxldCBlcnJvcjtcbiAgICAgICAgICAgIGxldCBpc1ZhbGlkO1xuICAgICAgICAgICAgY29uc3QgZmllbGRWYWx1ZSA9IHRhcmdldC50eXBlXG4gICAgICAgICAgICAgICAgPyBnZXRGaWVsZFZhbHVlKGZpZWxkLl9mKVxuICAgICAgICAgICAgICAgIDogZ2V0RXZlbnRWYWx1ZShldmVudCk7XG4gICAgICAgICAgICBjb25zdCBpc0JsdXJFdmVudCA9IGV2ZW50LnR5cGUgPT09IEVWRU5UUy5CTFVSIHx8IGV2ZW50LnR5cGUgPT09IEVWRU5UUy5GT0NVU19PVVQ7XG4gICAgICAgICAgICBjb25zdCBoYXNOb1ZhbGlkYXRpb25FZmZlY3QgPSAhaGFzVmFsaWRhdGlvbihmaWVsZC5fZikgJiZcbiAgICAgICAgICAgICAgICAhcHJvcHMudmFsaWRhdGUgJiZcbiAgICAgICAgICAgICAgICAhX29wdGlvbnMucmVzb2x2ZXIgJiZcbiAgICAgICAgICAgICAgICAhZ2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKSAmJlxuICAgICAgICAgICAgICAgICFmaWVsZC5fZi5kZXBzO1xuICAgICAgICAgICAgY29uc3Qgc2hvdWxkU2tpcFZhbGlkYXRpb24gPSBoYXNOb1ZhbGlkYXRpb25FZmZlY3QgfHxcbiAgICAgICAgICAgICAgICBza2lwVmFsaWRhdGlvbihpc0JsdXJFdmVudCwgZ2V0KF9mb3JtU3RhdGUudG91Y2hlZEZpZWxkcywgbmFtZSksIF9mb3JtU3RhdGUuaXNTdWJtaXR0ZWQsIF92YWxpZGF0aW9uTW9kZUFmdGVyU3VibWl0LCBfdmFsaWRhdGlvbk1vZGVCZWZvcmVTdWJtaXQpO1xuICAgICAgICAgICAgY29uc3Qgd2F0Y2hlZCA9IGlzV2F0Y2hlZChuYW1lLCBfbmFtZXMsIGlzQmx1ckV2ZW50KTtcbiAgICAgICAgICAgIHNldChfZm9ybVZhbHVlcywgbmFtZSwgZmllbGRWYWx1ZSk7XG4gICAgICAgICAgICBpZiAoaXNCbHVyRXZlbnQpIHtcbiAgICAgICAgICAgICAgICBpZiAoIXRhcmdldCB8fCAhdGFyZ2V0LnJlYWRPbmx5KSB7XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkLl9mLm9uQmx1ciAmJiBmaWVsZC5fZi5vbkJsdXIoZXZlbnQpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwZW5kaW5nRGVsYXlFcnJvciA9IGRlbGF5RXJyb3JDYWxsYmFja3NbbmFtZV07XG4gICAgICAgICAgICAgICAgICAgIHBlbmRpbmdEZWxheUVycm9yICYmIHBlbmRpbmdEZWxheUVycm9yKDApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGZpZWxkLl9mLm9uQ2hhbmdlKSB7XG4gICAgICAgICAgICAgICAgZmllbGQuX2Yub25DaGFuZ2UoZXZlbnQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgZmllbGRTdGF0ZSA9IHVwZGF0ZVRvdWNoQW5kRGlydHkobmFtZSwgZmllbGRWYWx1ZSwgaXNCbHVyRXZlbnQpO1xuICAgICAgICAgICAgY29uc3Qgc2hvdWxkUmVuZGVyID0gIWlzRW1wdHlPYmplY3QoZmllbGRTdGF0ZSkgfHwgd2F0Y2hlZDtcbiAgICAgICAgICAgICFpc0JsdXJFdmVudCAmJlxuICAgICAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogZXZlbnQudHlwZSxcbiAgICAgICAgICAgICAgICAgICAgLi4uKF92YWx1ZXNTdWJzY3JpYmVyQ291bnRcbiAgICAgICAgICAgICAgICAgICAgICAgID8geyB2YWx1ZXM6IGNsb25lT2JqZWN0KF9mb3JtVmFsdWVzKSB9XG4gICAgICAgICAgICAgICAgICAgICAgICA6IHt9KSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmIChzaG91bGRTa2lwVmFsaWRhdGlvbikge1xuICAgICAgICAgICAgICAgIGlmICgoIWhhc05vVmFsaWRhdGlvbkVmZmVjdCB8fCAhX2Zvcm1TdGF0ZS5pc1ZhbGlkKSAmJlxuICAgICAgICAgICAgICAgICAgICAoX3Byb3h5Rm9ybVN0YXRlLmlzVmFsaWQgfHwgX3Byb3h5U3Vic2NyaWJlRm9ybVN0YXRlLmlzVmFsaWQpKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChfb3B0aW9ucy5tb2RlID09PSAnb25CbHVyJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlzQmx1ckV2ZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3NldFZhbGlkKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoIWlzQmx1ckV2ZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBfc2V0VmFsaWQoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gKHNob3VsZFJlbmRlciAmJlxuICAgICAgICAgICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7IG5hbWUsIC4uLih3YXRjaGVkID8ge30gOiBmaWVsZFN0YXRlKSB9KSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIV9vcHRpb25zLnJlc29sdmVyICYmIHByb3BzLnZhbGlkYXRlKSB7XG4gICAgICAgICAgICAgICAgYXdhaXQgdmFsaWRhdGVGb3JtKHtcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogbmFtZSxcbiAgICAgICAgICAgICAgICAgICAgZXZlbnRUeXBlOiBldmVudC50eXBlLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgIWlzQmx1ckV2ZW50ICYmIHdhdGNoZWQgJiYgX3N1YmplY3RzLnN0YXRlLm5leHQoeyAuLi5fZm9ybVN0YXRlIH0pO1xuICAgICAgICAgICAgaWYgKF9vcHRpb25zLnJlc29sdmVyKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgeyBlcnJvcnMgfSA9IGF3YWl0IF9ydW5TY2hlbWEoW25hbWVdKTtcbiAgICAgICAgICAgICAgICBfdXBkYXRlSXNWYWxpZGF0aW5nKFtuYW1lXSk7XG4gICAgICAgICAgICAgICAgX3VwZGF0ZUlzRmllbGRWYWx1ZVVwZGF0ZWQoZmllbGRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgaWYgKCFpc0ZpZWxkVmFsdWVVcGRhdGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICFpc0VtcHR5T2JqZWN0KGZpZWxkU3RhdGUpICYmIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KGZpZWxkU3RhdGUpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IHByZXZpb3VzRXJyb3JMb29rdXBSZXN1bHQgPSBzY2hlbWFFcnJvckxvb2t1cChfZm9ybVN0YXRlLmVycm9ycywgX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICAgICAgY29uc3QgZXJyb3JMb29rdXBSZXN1bHQgPSBzY2hlbWFFcnJvckxvb2t1cChlcnJvcnMsIF9maWVsZHMsIHByZXZpb3VzRXJyb3JMb29rdXBSZXN1bHQubmFtZSB8fCBuYW1lKTtcbiAgICAgICAgICAgICAgICBlcnJvciA9IGVycm9yTG9va3VwUmVzdWx0LmVycm9yO1xuICAgICAgICAgICAgICAgIG5hbWUgPSBlcnJvckxvb2t1cFJlc3VsdC5uYW1lO1xuICAgICAgICAgICAgICAgIGlzVmFsaWQgPSBpc0VtcHR5T2JqZWN0KGVycm9ycyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBfdXBkYXRlSXNWYWxpZGF0aW5nKFtuYW1lXSwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgZXJyb3IgPSAoYXdhaXQgdmFsaWRhdGVGaWVsZChmaWVsZCwgX25hbWVzLmRpc2FibGVkLCBfZm9ybVZhbHVlcywgc2hvdWxkRGlzcGxheUFsbEFzc29jaWF0ZWRFcnJvcnMsIF9vcHRpb25zLnNob3VsZFVzZU5hdGl2ZVZhbGlkYXRpb24pKVtuYW1lXTtcbiAgICAgICAgICAgICAgICBfdXBkYXRlSXNWYWxpZGF0aW5nKFtuYW1lXSk7XG4gICAgICAgICAgICAgICAgX3VwZGF0ZUlzRmllbGRWYWx1ZVVwZGF0ZWQoZmllbGRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgaWYgKGlzRmllbGRWYWx1ZVVwZGF0ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc1ZhbGlkID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoX3Byb3h5Rm9ybVN0YXRlLmlzVmFsaWQgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZS5pc1ZhbGlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc1ZhbGlkID0gYXdhaXQgZXhlY3V0ZUJ1aWx0SW5WYWxpZGF0aW9uKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWVsZHM6IF9maWVsZHMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25seUNoZWNrVmFsaWQ6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogbmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBldmVudFR5cGU6IGV2ZW50LnR5cGUsXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpc0ZpZWxkVmFsdWVVcGRhdGVkKSB7XG4gICAgICAgICAgICAgICAgZmllbGQuX2YuZGVwcyAmJlxuICAgICAgICAgICAgICAgICAgICAoIUFycmF5LmlzQXJyYXkoZmllbGQuX2YuZGVwcykgfHwgZmllbGQuX2YuZGVwcy5sZW5ndGggPiAwKSAmJlxuICAgICAgICAgICAgICAgICAgICB0cmlnZ2VyKGZpZWxkLl9mLmRlcHMpO1xuICAgICAgICAgICAgICAgIHNob3VsZFJlbmRlckJ5RXJyb3IobmFtZSwgaXNWYWxpZCwgZXJyb3IsIGZpZWxkU3RhdGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBfZm9jdXNJbnB1dCA9IChyZWYsIGtleSkgPT4ge1xuICAgICAgICBpZiAoZ2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBrZXkpICYmIHJlZi5mb2N1cykge1xuICAgICAgICAgICAgcmVmLmZvY3VzKCk7XG4gICAgICAgICAgICByZXR1cm4gMTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm47XG4gICAgfTtcbiAgICBjb25zdCB0cmlnZ2VyID0gYXN5bmMgKG5hbWUsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgICAgICBsZXQgaXNWYWxpZDtcbiAgICAgICAgbGV0IHZhbGlkYXRpb25SZXN1bHQ7XG4gICAgICAgIGNvbnN0IGZpZWxkTmFtZXMgPSBjb252ZXJ0VG9BcnJheVBheWxvYWQobmFtZSk7XG4gICAgICAgIGlmIChfb3B0aW9ucy5yZXNvbHZlcikge1xuICAgICAgICAgICAgY29uc3QgZXJyb3JzID0gYXdhaXQgZXhlY3V0ZVNjaGVtYUFuZFVwZGF0ZVN0YXRlKGlzVW5kZWZpbmVkKG5hbWUpID8gbmFtZSA6IGZpZWxkTmFtZXMpO1xuICAgICAgICAgICAgaXNWYWxpZCA9IGlzRW1wdHlPYmplY3QoZXJyb3JzKTtcbiAgICAgICAgICAgIHZhbGlkYXRpb25SZXN1bHQgPSBuYW1lXG4gICAgICAgICAgICAgICAgPyAhZmllbGROYW1lcy5zb21lKChuYW1lKSA9PiBnZXQoZXJyb3JzLCBuYW1lKSlcbiAgICAgICAgICAgICAgICA6IGlzVmFsaWQ7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobmFtZSkge1xuICAgICAgICAgICAgdmFsaWRhdGlvblJlc3VsdCA9IChhd2FpdCBQcm9taXNlLmFsbChmaWVsZE5hbWVzLm1hcChhc3luYyAoZmllbGROYW1lKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgZmllbGROYW1lKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gYXdhaXQgZXhlY3V0ZUJ1aWx0SW5WYWxpZGF0aW9uKHtcbiAgICAgICAgICAgICAgICAgICAgZmllbGRzOiBmaWVsZCAmJiBmaWVsZC5fZiA/IHsgW2ZpZWxkTmFtZV06IGZpZWxkIH0gOiBmaWVsZCxcbiAgICAgICAgICAgICAgICAgICAgZXZlbnRUeXBlOiBFVkVOVFMuVFJJR0dFUixcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pKSkuZXZlcnkoQm9vbGVhbik7XG4gICAgICAgICAgICAhKCF2YWxpZGF0aW9uUmVzdWx0ICYmICFfZm9ybVN0YXRlLmlzVmFsaWQpICYmIF9zZXRWYWxpZCgpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdmFsaWRhdGlvblJlc3VsdCA9IGlzVmFsaWQgPSBhd2FpdCBleGVjdXRlQnVpbHRJblZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgIGZpZWxkczogX2ZpZWxkcyxcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgIGV2ZW50VHlwZTogRVZFTlRTLlRSSUdHRVIsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAob3B0aW9ucy5kZWxheUVycm9yICYmIF9vcHRpb25zLmRlbGF5RXJyb3IgJiYgaXNTdHJpbmcobmFtZSkpIHtcbiAgICAgICAgICAgIGNvbnN0IGVycm9yID0gZ2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgICAgICAgIHVuc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICBkZWxheUVycm9yQ2FsbGJhY2tzW25hbWVdID0gZGVib3VuY2UobmFtZSwgKCkgPT4gdXBkYXRlRXJyb3JzKG5hbWUsIGVycm9yKSk7XG4gICAgICAgICAgICAgICAgZGVsYXlFcnJvckNhbGxiYWNrc1tuYW1lXShfb3B0aW9ucy5kZWxheUVycm9yKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lcnNbbmFtZV0pO1xuICAgICAgICAgICAgICAgIGRlbGV0ZSBkZWxheUVycm9yQ2FsbGJhY2tzW25hbWVdO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgIC4uLighaXNTdHJpbmcobmFtZSkgfHxcbiAgICAgICAgICAgICAgICAoKF9wcm94eUZvcm1TdGF0ZS5pc1ZhbGlkIHx8IF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZS5pc1ZhbGlkKSAmJlxuICAgICAgICAgICAgICAgICAgICBpc1ZhbGlkICE9PSBfZm9ybVN0YXRlLmlzVmFsaWQpXG4gICAgICAgICAgICAgICAgPyB7fVxuICAgICAgICAgICAgICAgIDogeyBuYW1lIH0pLFxuICAgICAgICAgICAgLi4uKF9vcHRpb25zLnJlc29sdmVyIHx8ICFuYW1lID8geyBpc1ZhbGlkIH0gOiB7fSksXG4gICAgICAgICAgICBlcnJvcnM6IF9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICB9KTtcbiAgICAgICAgb3B0aW9ucy5zaG91bGRGb2N1cyAmJlxuICAgICAgICAgICAgIXZhbGlkYXRpb25SZXN1bHQgJiZcbiAgICAgICAgICAgIGl0ZXJhdGVGaWVsZHNCeUFjdGlvbihfZmllbGRzLCBfZm9jdXNJbnB1dCwgbmFtZSA/IGZpZWxkTmFtZXMgOiBfbmFtZXMubW91bnQpO1xuICAgICAgICByZXR1cm4gdmFsaWRhdGlvblJlc3VsdDtcbiAgICB9O1xuICAgIGNvbnN0IGdldFZhbHVlcyA9IChmaWVsZE5hbWVzLCBjb25maWcpID0+IHtcbiAgICAgICAgbGV0IHZhbHVlcyA9IHtcbiAgICAgICAgICAgIC4uLihfc3RhdGUubW91bnQgPyBfZm9ybVZhbHVlcyA6IF9kZWZhdWx0VmFsdWVzKSxcbiAgICAgICAgfTtcbiAgICAgICAgaWYgKGNvbmZpZykge1xuICAgICAgICAgICAgdmFsdWVzID0gZXh0cmFjdEZvcm1WYWx1ZXMoY29uZmlnLmRpcnR5RmllbGRzID8gX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcyA6IF9mb3JtU3RhdGUudG91Y2hlZEZpZWxkcywgdmFsdWVzKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gaXNVbmRlZmluZWQoZmllbGROYW1lcylcbiAgICAgICAgICAgID8gdmFsdWVzXG4gICAgICAgICAgICA6IGlzU3RyaW5nKGZpZWxkTmFtZXMpXG4gICAgICAgICAgICAgICAgPyBnZXQodmFsdWVzLCBmaWVsZE5hbWVzKVxuICAgICAgICAgICAgICAgIDogZmllbGROYW1lcy5tYXAoKG5hbWUpID0+IGdldCh2YWx1ZXMsIG5hbWUpKTtcbiAgICB9O1xuICAgIGNvbnN0IGdldEZpZWxkU3RhdGUgPSAobmFtZSwgZm9ybVN0YXRlKSA9PiAoe1xuICAgICAgICBpbnZhbGlkOiAhIWdldCgoZm9ybVN0YXRlIHx8IF9mb3JtU3RhdGUpLmVycm9ycywgbmFtZSksXG4gICAgICAgIGlzRGlydHk6ICEhZ2V0KChmb3JtU3RhdGUgfHwgX2Zvcm1TdGF0ZSkuZGlydHlGaWVsZHMsIG5hbWUpLFxuICAgICAgICBlcnJvcjogZ2V0KChmb3JtU3RhdGUgfHwgX2Zvcm1TdGF0ZSkuZXJyb3JzLCBuYW1lKSxcbiAgICAgICAgaXNWYWxpZGF0aW5nOiAhIWdldChfZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMsIG5hbWUpLFxuICAgICAgICBpc1RvdWNoZWQ6ICEhZ2V0KChmb3JtU3RhdGUgfHwgX2Zvcm1TdGF0ZSkudG91Y2hlZEZpZWxkcywgbmFtZSksXG4gICAgfSk7XG4gICAgY29uc3QgY2xlYXJFcnJvcnMgPSAobmFtZSkgPT4ge1xuICAgICAgICBjb25zdCBuYW1lcyA9IG5hbWUgPyBjb252ZXJ0VG9BcnJheVBheWxvYWQobmFtZSkgOiB1bmRlZmluZWQ7XG4gICAgICAgIG5hbWVzID09PSBudWxsIHx8IG5hbWVzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBuYW1lcy5mb3JFYWNoKChpbnB1dE5hbWUpID0+IHVuc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBpbnB1dE5hbWUpKTtcbiAgICAgICAgaWYgKG5hbWVzKSB7XG4gICAgICAgICAgICBuYW1lcy5mb3JFYWNoKChpbnB1dE5hbWUpID0+IHtcbiAgICAgICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgIG5hbWU6IGlucHV0TmFtZSxcbiAgICAgICAgICAgICAgICAgICAgZXJyb3JzOiBfZm9ybVN0YXRlLmVycm9ycyxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7fTtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICBlcnJvcnM6IF9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHNldEVycm9yID0gKG5hbWUsIGVycm9yLCBvcHRpb25zKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlZiA9IChnZXQoX2ZpZWxkcywgbmFtZSwgeyBfZjoge30gfSkuX2YgfHwge30pLnJlZjtcbiAgICAgICAgY29uc3QgY3VycmVudEVycm9yID0gZ2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKSB8fCB7fTtcbiAgICAgICAgY29uc3QgeyByZWY6IGN1cnJlbnRSZWYsIG1lc3NhZ2UsIHR5cGUsIC4uLnJlc3RPZkVycm9yVHJlZSB9ID0gY3VycmVudEVycm9yO1xuICAgICAgICBzZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUsIHtcbiAgICAgICAgICAgIC4uLnJlc3RPZkVycm9yVHJlZSxcbiAgICAgICAgICAgIC4uLmVycm9yLFxuICAgICAgICAgICAgcmVmLFxuICAgICAgICB9KTtcbiAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgIGVycm9yczogX2Zvcm1TdGF0ZS5lcnJvcnMsXG4gICAgICAgICAgICBpc1ZhbGlkOiBmYWxzZSxcbiAgICAgICAgfSk7XG4gICAgICAgIG9wdGlvbnMgJiYgb3B0aW9ucy5zaG91bGRGb2N1cyAmJiByZWYgJiYgcmVmLmZvY3VzICYmIHJlZi5mb2N1cygpO1xuICAgIH07XG4gICAgY29uc3Qgd2F0Y2ggPSAobmFtZSwgZGVmYXVsdFZhbHVlKSA9PiB7XG4gICAgICAgIGlmIChpc0Z1bmN0aW9uKG5hbWUpKSB7XG4gICAgICAgICAgICBfdmFsdWVzU3Vic2NyaWJlckNvdW50Kys7XG4gICAgICAgICAgICBjb25zdCB7IHVuc3Vic2NyaWJlIH0gPSBfc3ViamVjdHMuc3RhdGUuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgICAgICBuZXh0OiAocGF5bG9hZCkgPT4gJ3ZhbHVlcycgaW4gcGF5bG9hZCAmJlxuICAgICAgICAgICAgICAgICAgICBuYW1lKHBheWxvYWQudmFsdWVzIHx8IF9nZXRXYXRjaCh1bmRlZmluZWQsIGRlZmF1bHRWYWx1ZSksIHBheWxvYWQpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBsZXQgY2FsbGVkID0gZmFsc2U7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIHVuc3Vic2NyaWJlOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjYWxsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjYWxsZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICBfdmFsdWVzU3Vic2NyaWJlckNvdW50LS07XG4gICAgICAgICAgICAgICAgICAgIHVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIF9nZXRXYXRjaChuYW1lLCBkZWZhdWx0VmFsdWUsIHRydWUpO1xuICAgIH07XG4gICAgY29uc3QgX3N1YnNjcmliZSA9IChwcm9wcykgPT4ge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIGNvbnN0IG5lZWRzVmFsdWVzID0gISEoKF9hID0gcHJvcHMuZm9ybVN0YXRlKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EudmFsdWVzKTtcbiAgICAgICAgaWYgKG5lZWRzVmFsdWVzKSB7XG4gICAgICAgICAgICBfdmFsdWVzU3Vic2NyaWJlckNvdW50Kys7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgeyB1bnN1YnNjcmliZSB9ID0gX3N1YmplY3RzLnN0YXRlLnN1YnNjcmliZSh7XG4gICAgICAgICAgICBuZXh0OiAoZm9ybVN0YXRlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHNob3VsZFN1YnNjcmliZUJ5TmFtZShwcm9wcy5uYW1lLCBmb3JtU3RhdGUubmFtZSwgcHJvcHMuZXhhY3QpICYmXG4gICAgICAgICAgICAgICAgICAgIHNob3VsZFJlbmRlckZvcm1TdGF0ZShmb3JtU3RhdGUsIHByb3BzLmZvcm1TdGF0ZSB8fCBfcHJveHlGb3JtU3RhdGUsIF9zZXRGb3JtU3RhdGUsIHByb3BzLnJlUmVuZGVyUm9vdCkpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgc25hcHNob3QgPSB7IC4uLl9mb3JtVmFsdWVzIH07XG4gICAgICAgICAgICAgICAgICAgIHByb3BzLmNhbGxiYWNrKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlczogc25hcHNob3QsXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5fZm9ybVN0YXRlLFxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybVN0YXRlLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlczogX2RlZmF1bHRWYWx1ZXMsXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICBpZiAoIW5lZWRzVmFsdWVzKSB7XG4gICAgICAgICAgICByZXR1cm4gdW5zdWJzY3JpYmU7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGNhbGxlZCA9IGZhbHNlO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgaWYgKGNhbGxlZCkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhbGxlZCA9IHRydWU7XG4gICAgICAgICAgICBfdmFsdWVzU3Vic2NyaWJlckNvdW50LS07XG4gICAgICAgICAgICB1bnN1YnNjcmliZSgpO1xuICAgICAgICB9O1xuICAgIH07XG4gICAgY29uc3Qgc3Vic2NyaWJlID0gKHByb3BzKSA9PiB7XG4gICAgICAgIF9zdGF0ZS5tb3VudCA9IHRydWU7XG4gICAgICAgIF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZSA9IHtcbiAgICAgICAgICAgIC4uLl9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZSxcbiAgICAgICAgICAgIC4uLnByb3BzLmZvcm1TdGF0ZSxcbiAgICAgICAgfTtcbiAgICAgICAgcmV0dXJuIF9zdWJzY3JpYmUoe1xuICAgICAgICAgICAgLi4ucHJvcHMsXG4gICAgICAgICAgICBmb3JtU3RhdGU6IHtcbiAgICAgICAgICAgICAgICAuLi5kZWZhdWx0UHJveHlGb3JtU3RhdGUsXG4gICAgICAgICAgICAgICAgLi4ucHJvcHMuZm9ybVN0YXRlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCB1bnJlZ2lzdGVyID0gKG5hbWUsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgICAgICBmb3IgKGNvbnN0IGZpZWxkTmFtZSBvZiBuYW1lID8gY29udmVydFRvQXJyYXlQYXlsb2FkKG5hbWUpIDogX25hbWVzLm1vdW50KSB7XG4gICAgICAgICAgICBfbmFtZXMubW91bnQuZGVsZXRlKGZpZWxkTmFtZSk7XG4gICAgICAgICAgICBfbmFtZXMuYXJyYXkuZGVsZXRlKGZpZWxkTmFtZSk7XG4gICAgICAgICAgICBpZiAoIW9wdGlvbnMua2VlcFZhbHVlKSB7XG4gICAgICAgICAgICAgICAgdW5zZXQoX2ZpZWxkcywgZmllbGROYW1lKTtcbiAgICAgICAgICAgICAgICB1bnNldChfZm9ybVZhbHVlcywgZmllbGROYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgICFvcHRpb25zLmtlZXBFcnJvciAmJiB1bnNldChfZm9ybVN0YXRlLmVycm9ycywgZmllbGROYW1lKTtcbiAgICAgICAgICAgICFvcHRpb25zLmtlZXBEaXJ0eSAmJiB1bnNldChfZm9ybVN0YXRlLmRpcnR5RmllbGRzLCBmaWVsZE5hbWUpO1xuICAgICAgICAgICAgIW9wdGlvbnMua2VlcFRvdWNoZWQgJiYgdW5zZXQoX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCBmaWVsZE5hbWUpO1xuICAgICAgICAgICAgIW9wdGlvbnMua2VlcElzVmFsaWRhdGluZyAmJlxuICAgICAgICAgICAgICAgIHVuc2V0KF9mb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcywgZmllbGROYW1lKTtcbiAgICAgICAgICAgICFfb3B0aW9ucy5zaG91bGRVbnJlZ2lzdGVyICYmXG4gICAgICAgICAgICAgICAgIW9wdGlvbnMua2VlcERlZmF1bHRWYWx1ZSAmJlxuICAgICAgICAgICAgICAgIHVuc2V0KF9kZWZhdWx0VmFsdWVzLCBmaWVsZE5hbWUpO1xuICAgICAgICB9XG4gICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgIHZhbHVlczogY2xvbmVPYmplY3QoX2Zvcm1WYWx1ZXMpLFxuICAgICAgICB9KTtcbiAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgLi4uX2Zvcm1TdGF0ZSxcbiAgICAgICAgICAgIC4uLighb3B0aW9ucy5rZWVwRGlydHkgPyB7fSA6IHsgaXNEaXJ0eTogX2dldERpcnR5KCkgfSksXG4gICAgICAgIH0pO1xuICAgICAgICAhb3B0aW9ucy5rZWVwSXNWYWxpZCAmJiBfc2V0VmFsaWQoKTtcbiAgICB9O1xuICAgIGNvbnN0IF9zZXREaXNhYmxlZEZpZWxkID0gKHsgZGlzYWJsZWQsIG5hbWUsIH0pID0+IHtcbiAgICAgICAgaWYgKChpc0Jvb2xlYW4oZGlzYWJsZWQpICYmIF9zdGF0ZS5tb3VudCkgfHxcbiAgICAgICAgICAgICEhZGlzYWJsZWQgfHxcbiAgICAgICAgICAgIF9uYW1lcy5kaXNhYmxlZC5oYXMobmFtZSkpIHtcbiAgICAgICAgICAgIGNvbnN0IHdhc0Rpc2FibGVkID0gX25hbWVzLmRpc2FibGVkLmhhcyhuYW1lKTtcbiAgICAgICAgICAgIGNvbnN0IGlzRGlzYWJsZWQgPSAhIWRpc2FibGVkO1xuICAgICAgICAgICAgY29uc3QgZGlzYWJsZWRTdGF0ZUNoYW5nZWQgPSB3YXNEaXNhYmxlZCAhPT0gaXNEaXNhYmxlZDtcbiAgICAgICAgICAgIGRpc2FibGVkID8gX25hbWVzLmRpc2FibGVkLmFkZChuYW1lKSA6IF9uYW1lcy5kaXNhYmxlZC5kZWxldGUobmFtZSk7XG4gICAgICAgICAgICBkaXNhYmxlZFN0YXRlQ2hhbmdlZCAmJiBfc3RhdGUubW91bnQgJiYgIV9zdGF0ZS5hY3Rpb24gJiYgX3NldFZhbGlkKCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHJlZ2lzdGVyID0gKG5hbWUsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgICAgICBsZXQgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgIGNvbnN0IGRpc2FibGVkSXNEZWZpbmVkID0gaXNCb29sZWFuKG9wdGlvbnMuZGlzYWJsZWQpIHx8IGlzQm9vbGVhbihfb3B0aW9ucy5kaXNhYmxlZCk7XG4gICAgICAgIGNvbnN0IHNob3VsZFJldmFsaWRhdGVSZW1vdW50ID0gIV9uYW1lcy5yZWdpc3Rlck5hbWUuaGFzKG5hbWUpICYmIGZpZWxkICYmIGZpZWxkLl9mICYmICFmaWVsZC5fZi5tb3VudDtcbiAgICAgICAgc2V0KF9maWVsZHMsIG5hbWUsIHtcbiAgICAgICAgICAgIC4uLihmaWVsZCB8fCB7fSksXG4gICAgICAgICAgICBfZjoge1xuICAgICAgICAgICAgICAgIC4uLihmaWVsZCAmJiBmaWVsZC5fZiA/IGZpZWxkLl9mIDogeyByZWY6IHsgbmFtZSB9IH0pLFxuICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgbW91bnQ6IHRydWUsXG4gICAgICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICBfbmFtZXMubW91bnQuYWRkKG5hbWUpO1xuICAgICAgICBpZiAoZmllbGQgJiYgIXNob3VsZFJldmFsaWRhdGVSZW1vdW50KSB7XG4gICAgICAgICAgICBfc2V0RGlzYWJsZWRGaWVsZCh7XG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ6IGlzQm9vbGVhbihvcHRpb25zLmRpc2FibGVkKVxuICAgICAgICAgICAgICAgICAgICA/IG9wdGlvbnMuZGlzYWJsZWRcbiAgICAgICAgICAgICAgICAgICAgOiBfb3B0aW9ucy5kaXNhYmxlZCxcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB1cGRhdGVWYWxpZEFuZFZhbHVlKG5hbWUsIHRydWUsIG9wdGlvbnMudmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi4oZGlzYWJsZWRJc0RlZmluZWRcbiAgICAgICAgICAgICAgICA/IHsgZGlzYWJsZWQ6IG9wdGlvbnMuZGlzYWJsZWQgfHwgX29wdGlvbnMuZGlzYWJsZWQgfVxuICAgICAgICAgICAgICAgIDoge30pLFxuICAgICAgICAgICAgLi4uKF9vcHRpb25zLnByb2dyZXNzaXZlXG4gICAgICAgICAgICAgICAgPyB7XG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiAhIW9wdGlvbnMucmVxdWlyZWQsXG4gICAgICAgICAgICAgICAgICAgIG1pbjogZ2V0UnVsZVZhbHVlKG9wdGlvbnMubWluKSxcbiAgICAgICAgICAgICAgICAgICAgbWF4OiBnZXRSdWxlVmFsdWUob3B0aW9ucy5tYXgpLFxuICAgICAgICAgICAgICAgICAgICBtaW5MZW5ndGg6IGdldFJ1bGVWYWx1ZShvcHRpb25zLm1pbkxlbmd0aCksXG4gICAgICAgICAgICAgICAgICAgIG1heExlbmd0aDogZ2V0UnVsZVZhbHVlKG9wdGlvbnMubWF4TGVuZ3RoKSxcbiAgICAgICAgICAgICAgICAgICAgcGF0dGVybjogZ2V0UnVsZVZhbHVlKG9wdGlvbnMucGF0dGVybiksXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDoge30pLFxuICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgIG9uQ2hhbmdlLFxuICAgICAgICAgICAgb25CbHVyOiBvbkNoYW5nZSxcbiAgICAgICAgICAgIHJlZjogKHJlZikgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChyZWYpIHtcbiAgICAgICAgICAgICAgICAgICAgX25hbWVzLnJlZ2lzdGVyTmFtZS5hZGQobmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIHJlZ2lzdGVyKG5hbWUsIG9wdGlvbnMpO1xuICAgICAgICAgICAgICAgICAgICBfbmFtZXMucmVnaXN0ZXJOYW1lLmRlbGV0ZShuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkUmVmID0gaXNVbmRlZmluZWQocmVmLnZhbHVlKVxuICAgICAgICAgICAgICAgICAgICAgICAgPyByZWYucXVlcnlTZWxlY3RvckFsbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gcmVmLnF1ZXJ5U2VsZWN0b3JBbGwoJ2lucHV0LHNlbGVjdCx0ZXh0YXJlYScpWzBdIHx8IHJlZlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogcmVmXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHJlZjtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmFkaW9PckNoZWNrYm94ID0gaXNSYWRpb09yQ2hlY2tib3goZmllbGRSZWYpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCByZWZzID0gZmllbGQuX2YucmVmcyB8fCBbXTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJhZGlvT3JDaGVja2JveFxuICAgICAgICAgICAgICAgICAgICAgICAgPyByZWZzLmZpbmQoKG9wdGlvbikgPT4gb3B0aW9uID09PSBmaWVsZFJlZilcbiAgICAgICAgICAgICAgICAgICAgICAgIDogZmllbGRSZWYgPT09IGZpZWxkLl9mLnJlZikge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG5ld0ZpZWxkID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZmllbGQuX2YsXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIGlmIChyYWRpb09yQ2hlY2tib3gpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5ld0ZpZWxkLnJlZnMgPSBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucmVmcy5maWx0ZXIobGl2ZSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmllbGRSZWYsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uKEFycmF5LmlzQXJyYXkoZ2V0KF9kZWZhdWx0VmFsdWVzLCBuYW1lKSkgPyBbe31dIDogW10pLFxuICAgICAgICAgICAgICAgICAgICAgICAgXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5ld0ZpZWxkLnJlZiA9IHsgdHlwZTogZmllbGRSZWYudHlwZSwgbmFtZSB9O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmV3RmllbGQucmVmID0gZmllbGRSZWY7XG4gICAgICAgICAgICAgICAgICAgICAgICBkZWxldGUgbmV3RmllbGQucmVmcztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBzZXQoX2ZpZWxkcywgbmFtZSwge1xuICAgICAgICAgICAgICAgICAgICAgICAgX2Y6IG5ld0ZpZWxkLFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlVmFsaWRBbmRWYWx1ZShuYW1lLCBmYWxzZSwgdW5kZWZpbmVkLCBmaWVsZFJlZik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lLCB7fSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChmaWVsZC5fZikge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmllbGQuX2YubW91bnQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAoX29wdGlvbnMuc2hvdWxkVW5yZWdpc3RlciB8fCBvcHRpb25zLnNob3VsZFVucmVnaXN0ZXIpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAhKGlzTmFtZUluRmllbGRBcnJheShfbmFtZXMuYXJyYXksIG5hbWUpICYmIF9zdGF0ZS5hY3Rpb24pICYmXG4gICAgICAgICAgICAgICAgICAgICAgICBfbmFtZXMudW5Nb3VudC5hZGQobmFtZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfTtcbiAgICB9O1xuICAgIGNvbnN0IF9mb2N1c0Vycm9yID0gKCkgPT4gX29wdGlvbnMuc2hvdWxkRm9jdXNFcnJvciAmJlxuICAgICAgICAhX29wdGlvbnMuc2hvdWxkVXNlTmF0aXZlVmFsaWRhdGlvbiAmJlxuICAgICAgICBpdGVyYXRlRmllbGRzQnlBY3Rpb24oX2ZpZWxkcywgX2ZvY3VzSW5wdXQsIF9uYW1lcy5tb3VudCk7XG4gICAgY29uc3QgX2Rpc2FibGVGb3JtID0gKGRpc2FibGVkKSA9PiB7XG4gICAgICAgIGlmIChpc0Jvb2xlYW4oZGlzYWJsZWQpKSB7XG4gICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7IGRpc2FibGVkIH0pO1xuICAgICAgICAgICAgaXRlcmF0ZUZpZWxkc0J5QWN0aW9uKF9maWVsZHMsIChyZWYsIG5hbWUpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBjdXJyZW50RmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICAgICAgaWYgKGN1cnJlbnRGaWVsZCkge1xuICAgICAgICAgICAgICAgICAgICByZWYuZGlzYWJsZWQgPSBjdXJyZW50RmllbGQuX2YuZGlzYWJsZWQgfHwgZGlzYWJsZWQ7XG4gICAgICAgICAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGN1cnJlbnRGaWVsZC5fZi5yZWZzKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudEZpZWxkLl9mLnJlZnMuZm9yRWFjaCgoaW5wdXRSZWYpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbnB1dFJlZi5kaXNhYmxlZCA9IGN1cnJlbnRGaWVsZC5fZi5kaXNhYmxlZCB8fCBkaXNhYmxlZDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSwgMCwgZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBoYW5kbGVTdWJtaXQgPSAob25WYWxpZCwgb25JbnZhbGlkKSA9PiBhc3luYyAoZSkgPT4ge1xuICAgICAgICBsZXQgcmVzdWx0ID0gdW5kZWZpbmVkO1xuICAgICAgICBsZXQgb25WYWxpZEVycm9yID0gdW5kZWZpbmVkO1xuICAgICAgICBpZiAoZSkge1xuICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCAmJiBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgICBlLnBlcnNpc3QgJiZcbiAgICAgICAgICAgICAgICBlLnBlcnNpc3QoKTtcbiAgICAgICAgfVxuICAgICAgICBsZXQgZmllbGRWYWx1ZXMgPSBjbG9uZU9iamVjdChfZm9ybVZhbHVlcyk7XG4gICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgIGlzU3VibWl0dGluZzogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIGlmIChfb3B0aW9ucy5yZXNvbHZlcikge1xuICAgICAgICAgICAgY29uc3QgeyBlcnJvcnMsIHZhbHVlcyB9ID0gYXdhaXQgX3J1blNjaGVtYSgpO1xuICAgICAgICAgICAgX3VwZGF0ZUlzVmFsaWRhdGluZygpO1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSBlcnJvcnM7XG4gICAgICAgICAgICBmaWVsZFZhbHVlcyA9IGNsb25lT2JqZWN0KHZhbHVlcyk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBhd2FpdCBleGVjdXRlQnVpbHRJblZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgIGZpZWxkczogX2ZpZWxkcyxcbiAgICAgICAgICAgICAgICBldmVudFR5cGU6IEVWRU5UUy5TVUJNSVQsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoX25hbWVzLmRpc2FibGVkLnNpemUpIHtcbiAgICAgICAgICAgIGZvciAoY29uc3QgbmFtZSBvZiBfbmFtZXMuZGlzYWJsZWQpIHtcbiAgICAgICAgICAgICAgICB1bnNldChmaWVsZFZhbHVlcywgbmFtZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdW5zZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIFJPT1RfRVJST1JfVFlQRSk7XG4gICAgICAgIGlmIChpc0VtcHR5T2JqZWN0KF9mb3JtU3RhdGUuZXJyb3JzKSkge1xuICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIGVycm9yczoge30sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgb25WYWxpZChmaWVsZFZhbHVlcywgZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBvblZhbGlkRXJyb3IgPSBlcnJvcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGlmIChvbkludmFsaWQpIHtcbiAgICAgICAgICAgICAgICBhd2FpdCBvbkludmFsaWQoeyAuLi5fZm9ybVN0YXRlLmVycm9ycyB9LCBlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIF9mb2N1c0Vycm9yKCk7XG4gICAgICAgICAgICBzZXRUaW1lb3V0KF9mb2N1c0Vycm9yKTtcbiAgICAgICAgfVxuICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICBpc1N1Ym1pdHRlZDogdHJ1ZSxcbiAgICAgICAgICAgIGlzU3VibWl0dGluZzogZmFsc2UsXG4gICAgICAgICAgICBpc1N1Ym1pdFN1Y2Nlc3NmdWw6IGlzRW1wdHlPYmplY3QoX2Zvcm1TdGF0ZS5lcnJvcnMpICYmICFvblZhbGlkRXJyb3IsXG4gICAgICAgICAgICBzdWJtaXRDb3VudDogX2Zvcm1TdGF0ZS5zdWJtaXRDb3VudCArIDEsXG4gICAgICAgICAgICBlcnJvcnM6IF9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKG9uVmFsaWRFcnJvcikge1xuICAgICAgICAgICAgdGhyb3cgb25WYWxpZEVycm9yO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfTtcbiAgICBjb25zdCByZXNldEZpZWxkID0gKG5hbWUsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgICAgICBpZiAoZ2V0KF9maWVsZHMsIG5hbWUpKSB7XG4gICAgICAgICAgICBpZiAoaXNVbmRlZmluZWQob3B0aW9ucy5kZWZhdWx0VmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgc2V0VmFsdWUobmFtZSwgY2xvbmVPYmplY3QoZ2V0KF9kZWZhdWx0VmFsdWVzLCBuYW1lKSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgc2V0VmFsdWUobmFtZSwgb3B0aW9ucy5kZWZhdWx0VmFsdWUpO1xuICAgICAgICAgICAgICAgIHNldChfZGVmYXVsdFZhbHVlcywgbmFtZSwgY2xvbmVPYmplY3Qob3B0aW9ucy5kZWZhdWx0VmFsdWUpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghb3B0aW9ucy5rZWVwVG91Y2hlZCkge1xuICAgICAgICAgICAgICAgIHVuc2V0KF9mb3JtU3RhdGUudG91Y2hlZEZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIW9wdGlvbnMua2VlcERpcnR5KSB7XG4gICAgICAgICAgICAgICAgdW5zZXQoX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICAgICAgX2Zvcm1TdGF0ZS5pc0RpcnR5ID0gb3B0aW9ucy5kZWZhdWx0VmFsdWVcbiAgICAgICAgICAgICAgICAgICAgPyBfZ2V0RGlydHkobmFtZSwgY2xvbmVPYmplY3QoZ2V0KF9kZWZhdWx0VmFsdWVzLCBuYW1lKSkpXG4gICAgICAgICAgICAgICAgICAgIDogX2dldERpcnR5KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIW9wdGlvbnMua2VlcEVycm9yKSB7XG4gICAgICAgICAgICAgICAgdW5zZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIF9wcm94eUZvcm1TdGF0ZS5pc1ZhbGlkICYmIF9zZXRWYWxpZCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoeyAuLi5fZm9ybVN0YXRlIH0pO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBfcmVzZXQgPSAoZm9ybVZhbHVlcywga2VlcFN0YXRlT3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRWYWx1ZXMgPSBmb3JtVmFsdWVzID8gY2xvbmVPYmplY3QoZm9ybVZhbHVlcykgOiBfZGVmYXVsdFZhbHVlcztcbiAgICAgICAgY29uc3QgY2xvbmVVcGRhdGVkVmFsdWVzID0gY2xvbmVPYmplY3QodXBkYXRlZFZhbHVlcyk7XG4gICAgICAgIGNvbnN0IGlzRW1wdHlSZXNldFZhbHVlcyA9IGlzRW1wdHlPYmplY3QoZm9ybVZhbHVlcyk7XG4gICAgICAgIGNvbnN0IHZhbHVlcyA9IGNsb25lVXBkYXRlZFZhbHVlcztcbiAgICAgICAgY29uc3QgZmllbGRSZWZzID0gX2ZpZWxkcztcbiAgICAgICAgaWYgKCFrZWVwU3RhdGVPcHRpb25zLmtlZXBEZWZhdWx0VmFsdWVzKSB7XG4gICAgICAgICAgICBfZGVmYXVsdFZhbHVlcyA9IHVwZGF0ZWRWYWx1ZXM7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFrZWVwU3RhdGVPcHRpb25zLmtlZXBWYWx1ZXMpIHtcbiAgICAgICAgICAgIGlmIChrZWVwU3RhdGVPcHRpb25zLmtlZXBEaXJ0eVZhbHVlcykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkc1RvQ2hlY2sgPSBuZXcgU2V0KFtcbiAgICAgICAgICAgICAgICAgICAgLi4uX25hbWVzLm1vdW50LFxuICAgICAgICAgICAgICAgICAgICAuLi5jb2xsZWN0RGlydHlGaWVsZE5hbWVzKGdldERpcnR5RmllbGRzKF9kZWZhdWx0VmFsdWVzLCBfZm9ybVZhbHVlcywgdW5kZWZpbmVkLCBmaWVsZFJlZnMpLCBfZm9ybVN0YXRlLmRpcnR5RmllbGRzKSxcbiAgICAgICAgICAgICAgICBdKTtcbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGZpZWxkTmFtZSBvZiBBcnJheS5mcm9tKGZpZWxkc1RvQ2hlY2spKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzRGlydHkgPSBnZXQoX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcywgZmllbGROYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdWYWx1ZSA9IGdldChfZm9ybVZhbHVlcywgZmllbGROYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV3VmFsdWUgPSBnZXQodmFsdWVzLCBmaWVsZE5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoaXNEaXJ0eSAmJiAhaXNVbmRlZmluZWQoZXhpc3RpbmdWYWx1ZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldCh2YWx1ZXMsIGZpZWxkTmFtZSwgZXhpc3RpbmdWYWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoIWlzRGlydHkgJiYgIWlzVW5kZWZpbmVkKG5ld1ZhbHVlKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0VmFsdWUoZmllbGROYW1lLCBuZXdWYWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBpZiAoaXNXZWIgJiYgaXNVbmRlZmluZWQoZm9ybVZhbHVlcykpIHtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChjb25zdCBuYW1lIG9mIF9uYW1lcy5tb3VudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmllbGQgJiYgZmllbGQuX2YpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWVsZFJlZmVyZW5jZSA9IEFycmF5LmlzQXJyYXkoZmllbGQuX2YucmVmcylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBmaWVsZC5fZi5yZWZzWzBdXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogZmllbGQuX2YucmVmO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpc0hUTUxFbGVtZW50KGZpZWxkUmVmZXJlbmNlKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmb3JtID0gZmllbGRSZWZlcmVuY2UuY2xvc2VzdCgnZm9ybScpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZm9ybSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybS5yZXNldCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGtlZXBTdGF0ZU9wdGlvbnMua2VlcEZpZWxkc1JlZikge1xuICAgICAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGZpZWxkTmFtZSBvZiBfbmFtZXMubW91bnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFZhbHVlKGZpZWxkTmFtZSwgZ2V0KHZhbHVlcywgZmllbGROYW1lKSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIF9maWVsZHMgPSB7fTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoX29wdGlvbnMuc2hvdWxkVW5yZWdpc3Rlcikge1xuICAgICAgICAgICAgICAgIF9mb3JtVmFsdWVzID0ga2VlcFN0YXRlT3B0aW9ucy5rZWVwRGVmYXVsdFZhbHVlc1xuICAgICAgICAgICAgICAgICAgICA/IGNsb25lT2JqZWN0KF9kZWZhdWx0VmFsdWVzKVxuICAgICAgICAgICAgICAgICAgICA6IHt9O1xuICAgICAgICAgICAgICAgIGlmIChrZWVwU3RhdGVPcHRpb25zLmtlZXBGaWVsZHNSZWYpIHtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChjb25zdCBmaWVsZE5hbWUgb2YgX25hbWVzLm1vdW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXQoX2Zvcm1WYWx1ZXMsIGZpZWxkTmFtZSwgZ2V0KHZhbHVlcywgZmllbGROYW1lKSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBfZm9ybVZhbHVlcyA9IGNsb25lT2JqZWN0KHZhbHVlcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBfc3ViamVjdHMuYXJyYXkubmV4dCh7XG4gICAgICAgICAgICAgICAgdmFsdWVzOiB7IC4uLnZhbHVlcyB9LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgbmFtZTogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICB2YWx1ZXM6IHsgLi4udmFsdWVzIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBfbmFtZXMgPSB7XG4gICAgICAgICAgICBtb3VudDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwRGlydHlWYWx1ZXMgPyBfbmFtZXMubW91bnQgOiBuZXcgU2V0KCksXG4gICAgICAgICAgICB1bk1vdW50OiBuZXcgU2V0KCksXG4gICAgICAgICAgICBhcnJheTogbmV3IFNldCgpLFxuICAgICAgICAgICAgcmVnaXN0ZXJOYW1lOiBuZXcgU2V0KCksXG4gICAgICAgICAgICBkaXNhYmxlZDogbmV3IFNldCgpLFxuICAgICAgICAgICAgd2F0Y2g6IG5ldyBTZXQoKSxcbiAgICAgICAgICAgIHdhdGNoQWxsOiBmYWxzZSxcbiAgICAgICAgICAgIGZvY3VzOiAnJyxcbiAgICAgICAgfTtcbiAgICAgICAgX3N0YXRlLm1vdW50ID1cbiAgICAgICAgICAgICFfcHJveHlGb3JtU3RhdGUuaXNWYWxpZCB8fFxuICAgICAgICAgICAgICAgICEha2VlcFN0YXRlT3B0aW9ucy5rZWVwSXNWYWxpZCB8fFxuICAgICAgICAgICAgICAgICEha2VlcFN0YXRlT3B0aW9ucy5rZWVwRGlydHlWYWx1ZXMgfHxcbiAgICAgICAgICAgICAgICAoIV9vcHRpb25zLnNob3VsZFVucmVnaXN0ZXIgJiYgIWlzRW1wdHlPYmplY3QodmFsdWVzKSk7XG4gICAgICAgIF9zdGF0ZS53YXRjaCA9ICEhX29wdGlvbnMuc2hvdWxkVW5yZWdpc3RlcjtcbiAgICAgICAgX3N0YXRlLmtlZXBJc1ZhbGlkID0gISFrZWVwU3RhdGVPcHRpb25zLmtlZXBJc1ZhbGlkO1xuICAgICAgICBfc3RhdGUuYWN0aW9uID0gZmFsc2U7XG4gICAgICAgIF9zdGF0ZS5hY3Rpb25BcnJheUxlbmd0aHMuY2xlYXIoKTtcbiAgICAgICAgaWYgKCFrZWVwU3RhdGVPcHRpb25zLmtlZXBFcnJvcnMpIHtcbiAgICAgICAgICAgIF9mb3JtU3RhdGUuZXJyb3JzID0ge307XG4gICAgICAgIH1cbiAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgc3VibWl0Q291bnQ6IGtlZXBTdGF0ZU9wdGlvbnMua2VlcFN1Ym1pdENvdW50XG4gICAgICAgICAgICAgICAgPyBfZm9ybVN0YXRlLnN1Ym1pdENvdW50XG4gICAgICAgICAgICAgICAgOiAwLFxuICAgICAgICAgICAgaXNEaXJ0eTogaXNFbXB0eVJlc2V0VmFsdWVzXG4gICAgICAgICAgICAgICAgPyBmYWxzZVxuICAgICAgICAgICAgICAgIDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwRGlydHlcbiAgICAgICAgICAgICAgICAgICAgPyBfZm9ybVN0YXRlLmlzRGlydHlcbiAgICAgICAgICAgICAgICAgICAgOiBrZWVwU3RhdGVPcHRpb25zLmtlZXBWYWx1ZXNcbiAgICAgICAgICAgICAgICAgICAgICAgID8gX2dldERpcnR5KClcbiAgICAgICAgICAgICAgICAgICAgICAgIDogISEoa2VlcFN0YXRlT3B0aW9ucy5rZWVwRGVmYXVsdFZhbHVlcyAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICFkZWVwRXF1YWwoZm9ybVZhbHVlcywgX2RlZmF1bHRWYWx1ZXMpKSxcbiAgICAgICAgICAgIGlzU3VibWl0dGVkOiBrZWVwU3RhdGVPcHRpb25zLmtlZXBJc1N1Ym1pdHRlZFxuICAgICAgICAgICAgICAgID8gX2Zvcm1TdGF0ZS5pc1N1Ym1pdHRlZFxuICAgICAgICAgICAgICAgIDogZmFsc2UsXG4gICAgICAgICAgICBkaXJ0eUZpZWxkczogaXNFbXB0eVJlc2V0VmFsdWVzXG4gICAgICAgICAgICAgICAgPyB7fVxuICAgICAgICAgICAgICAgIDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwRGlydHlWYWx1ZXNcbiAgICAgICAgICAgICAgICAgICAgPyBrZWVwU3RhdGVPcHRpb25zLmtlZXBEZWZhdWx0VmFsdWVzICYmIF9mb3JtVmFsdWVzXG4gICAgICAgICAgICAgICAgICAgICAgICA/IGdldERpcnR5RmllbGRzKF9kZWZhdWx0VmFsdWVzLCBfZm9ybVZhbHVlcywgdW5kZWZpbmVkLCBmaWVsZFJlZnMpXG4gICAgICAgICAgICAgICAgICAgICAgICA6IF9mb3JtU3RhdGUuZGlydHlGaWVsZHNcbiAgICAgICAgICAgICAgICAgICAgOiBrZWVwU3RhdGVPcHRpb25zLmtlZXBEZWZhdWx0VmFsdWVzICYmIGZvcm1WYWx1ZXNcbiAgICAgICAgICAgICAgICAgICAgICAgID8gZ2V0RGlydHlGaWVsZHMoX2RlZmF1bHRWYWx1ZXMsIGZvcm1WYWx1ZXMsIHVuZGVmaW5lZCwgZmllbGRSZWZzKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBrZWVwU3RhdGVPcHRpb25zLmtlZXBEaXJ0eVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDoge30sXG4gICAgICAgICAgICB0b3VjaGVkRmllbGRzOiBrZWVwU3RhdGVPcHRpb25zLmtlZXBUb3VjaGVkXG4gICAgICAgICAgICAgICAgPyBfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHNcbiAgICAgICAgICAgICAgICA6IHt9LFxuICAgICAgICAgICAgZXJyb3JzOiBrZWVwU3RhdGVPcHRpb25zLmtlZXBFcnJvcnMgPyBfZm9ybVN0YXRlLmVycm9ycyA6IHt9LFxuICAgICAgICAgICAgaXNTdWJtaXRTdWNjZXNzZnVsOiBrZWVwU3RhdGVPcHRpb25zLmtlZXBJc1N1Ym1pdFN1Y2Nlc3NmdWxcbiAgICAgICAgICAgICAgICA/IF9mb3JtU3RhdGUuaXNTdWJtaXRTdWNjZXNzZnVsXG4gICAgICAgICAgICAgICAgOiBmYWxzZSxcbiAgICAgICAgICAgIGlzU3VibWl0dGluZzogZmFsc2UsXG4gICAgICAgICAgICBkZWZhdWx0VmFsdWVzOiBfZGVmYXVsdFZhbHVlcyxcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCByZXNldCA9IChmb3JtVmFsdWVzLCBrZWVwU3RhdGVPcHRpb25zKSA9PiBfcmVzZXQoaXNGdW5jdGlvbihmb3JtVmFsdWVzKVxuICAgICAgICA/IGZvcm1WYWx1ZXMoX2Zvcm1WYWx1ZXMpXG4gICAgICAgIDogZm9ybVZhbHVlcywgeyAuLi5fb3B0aW9ucy5yZXNldE9wdGlvbnMsIC4uLmtlZXBTdGF0ZU9wdGlvbnMgfSk7XG4gICAgY29uc3Qgc2V0Rm9jdXMgPSAobmFtZSwgb3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICBjb25zdCBmaWVsZFJlZmVyZW5jZSA9IGZpZWxkICYmIGZpZWxkLl9mO1xuICAgICAgICBpZiAoZmllbGRSZWZlcmVuY2UpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkUmVmID0gZmllbGRSZWZlcmVuY2UucmVmc1xuICAgICAgICAgICAgICAgID8gZmllbGRSZWZlcmVuY2UucmVmc1swXVxuICAgICAgICAgICAgICAgIDogZmllbGRSZWZlcmVuY2UucmVmO1xuICAgICAgICAgICAgaWYgKGZpZWxkUmVmLmZvY3VzKSB7XG4gICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkUmVmLmZvY3VzKCk7XG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbnMuc2hvdWxkU2VsZWN0ICYmXG4gICAgICAgICAgICAgICAgICAgICAgICBpc0Z1bmN0aW9uKGZpZWxkUmVmLnNlbGVjdCkgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkUmVmLnNlbGVjdCgpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBfc2V0Rm9ybVN0YXRlID0gKHVwZGF0ZWRGb3JtU3RhdGUpID0+IHtcbiAgICAgICAgLy8gYG5hbWVgLCBgdHlwZWAsIGFuZCBgdmFsdWVzYCBkZXNjcmliZSB0aGUgZXZlbnQgdGhhdCBwcm9kdWNlZCB0aGlzXG4gICAgICAgIC8vIHVwZGF0ZSwgbm90IHRoZSBmb3JtJ3MgcGVyc2lzdGVkIHN0YXRlICh0aGV5IGFyZW4ndCBwYXJ0IG9mXG4gICAgICAgIC8vIGBGb3JtU3RhdGVgKS4gTWVyZ2luZyB0aGVtIGluIHdvdWxkIGxlYWsgYSBzdGFsZSBgbmFtZWAvYHR5cGVgIGZyb21cbiAgICAgICAgLy8gb25lIGV2ZW50IGludG8gYSBsYXRlciwgdW5yZWxhdGVkIG5vdGlmaWNhdGlvbiB0aGF0IGRvZXNuJ3Qgc3BlY2lmeVxuICAgICAgICAvLyBpdHMgb3duLlxuICAgICAgICBjb25zdCB7IG5hbWUsIHR5cGUsIHZhbHVlcywgLi4uZm9ybVN0YXRlIH0gPSB1cGRhdGVkRm9ybVN0YXRlO1xuICAgICAgICBfZm9ybVN0YXRlID0ge1xuICAgICAgICAgICAgLi4uX2Zvcm1TdGF0ZSxcbiAgICAgICAgICAgIC4uLmZvcm1TdGF0ZSxcbiAgICAgICAgfTtcbiAgICB9O1xuICAgIF9zdWJqZWN0cy5zdGF0ZS5zdWJzY3JpYmUoeyBuZXh0OiBfc2V0Rm9ybVN0YXRlIH0pO1xuICAgIGNvbnN0IF9yZXNldERlZmF1bHRWYWx1ZXMgPSAoKSA9PiBpc0Z1bmN0aW9uKF9vcHRpb25zLmRlZmF1bHRWYWx1ZXMpICYmXG4gICAgICAgIF9vcHRpb25zLmRlZmF1bHRWYWx1ZXMoKS50aGVuKCh2YWx1ZXMpID0+IHtcbiAgICAgICAgICAgIHJlc2V0KHZhbHVlcywgX29wdGlvbnMucmVzZXRPcHRpb25zKTtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICBpc0xvYWRpbmc6IGZhbHNlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIGNvbnN0IHJlc2V0RGVmYXVsdFZhbHVlcyA9ICh2YWx1ZXMsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgICAgICBfZGVmYXVsdFZhbHVlcyA9IGNsb25lT2JqZWN0KHZhbHVlcyk7XG4gICAgICAgIGlmICghb3B0aW9ucy5rZWVwRGlydHkpIHtcbiAgICAgICAgICAgIGNvbnN0IG5ld0RpcnR5RmllbGRzID0gZ2V0RGlydHlGaWVsZHMoX2RlZmF1bHRWYWx1ZXMsIF9mb3JtVmFsdWVzLCB1bmRlZmluZWQsIF9maWVsZHMpO1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcyA9IG5ld0RpcnR5RmllbGRzO1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZS5pc0RpcnR5ID0gIWlzRW1wdHlPYmplY3QobmV3RGlydHlGaWVsZHMpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghb3B0aW9ucy5rZWVwSXNWYWxpZCkge1xuICAgICAgICAgICAgX3NldFZhbGlkKCk7XG4gICAgICAgIH1cbiAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgLi4uX2Zvcm1TdGF0ZSxcbiAgICAgICAgICAgIGRlZmF1bHRWYWx1ZXM6IF9kZWZhdWx0VmFsdWVzLFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IG1ldGhvZHMgPSB7XG4gICAgICAgIGNvbnRyb2w6IHtcbiAgICAgICAgICAgIHJlZ2lzdGVyLFxuICAgICAgICAgICAgdW5yZWdpc3RlcixcbiAgICAgICAgICAgIGdldEZpZWxkU3RhdGUsXG4gICAgICAgICAgICBoYW5kbGVTdWJtaXQsXG4gICAgICAgICAgICBzZXRFcnJvcixcbiAgICAgICAgICAgIF9zdWJzY3JpYmUsXG4gICAgICAgICAgICBfcnVuU2NoZW1hLFxuICAgICAgICAgICAgX3VwZGF0ZUlzVmFsaWRhdGluZyxcbiAgICAgICAgICAgIF9mb2N1c0Vycm9yLFxuICAgICAgICAgICAgX2dldFdhdGNoLFxuICAgICAgICAgICAgX2dldERpcnR5LFxuICAgICAgICAgICAgX3NldFZhbGlkLFxuICAgICAgICAgICAgX3NldEZpZWxkQXJyYXksXG4gICAgICAgICAgICBfc2V0RGlzYWJsZWRGaWVsZCxcbiAgICAgICAgICAgIF9zZXRFcnJvcnMsXG4gICAgICAgICAgICBfZ2V0RmllbGRBcnJheSxcbiAgICAgICAgICAgIF9yZXNldCxcbiAgICAgICAgICAgIF9yZXNldERlZmF1bHRWYWx1ZXMsXG4gICAgICAgICAgICBfcmVtb3ZlVW5tb3VudGVkLFxuICAgICAgICAgICAgX2Rpc2FibGVGb3JtLFxuICAgICAgICAgICAgX3N1YmplY3RzLFxuICAgICAgICAgICAgX3Byb3h5Rm9ybVN0YXRlLFxuICAgICAgICAgICAgZ2V0IF9maWVsZHMoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIF9maWVsZHM7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZ2V0IF9mb3JtVmFsdWVzKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBfZm9ybVZhbHVlcztcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBnZXQgX3N0YXRlKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBfc3RhdGU7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2V0IF9zdGF0ZSh2YWx1ZSkge1xuICAgICAgICAgICAgICAgIF9zdGF0ZSA9IHZhbHVlO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGdldCBfZGVmYXVsdFZhbHVlcygpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX2RlZmF1bHRWYWx1ZXM7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZ2V0IF9uYW1lcygpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX25hbWVzO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNldCBfbmFtZXModmFsdWUpIHtcbiAgICAgICAgICAgICAgICBfbmFtZXMgPSB2YWx1ZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBnZXQgX2Zvcm1TdGF0ZSgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX2Zvcm1TdGF0ZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBnZXQgX29wdGlvbnMoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIF9vcHRpb25zO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNldCBfb3B0aW9ucyh2YWx1ZSkge1xuICAgICAgICAgICAgICAgIF9vcHRpb25zID0ge1xuICAgICAgICAgICAgICAgICAgICAuLi5fb3B0aW9ucyxcbiAgICAgICAgICAgICAgICAgICAgLi4udmFsdWUsXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBfdmFsaWRhdGlvbk1vZGVCZWZvcmVTdWJtaXQgPSBnZXRWYWxpZGF0aW9uTW9kZXMoX29wdGlvbnMubW9kZSk7XG4gICAgICAgICAgICAgICAgX3ZhbGlkYXRpb25Nb2RlQWZ0ZXJTdWJtaXQgPSBnZXRWYWxpZGF0aW9uTW9kZXMoX29wdGlvbnMucmVWYWxpZGF0ZU1vZGUpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgc3Vic2NyaWJlLFxuICAgICAgICB0cmlnZ2VyLFxuICAgICAgICByZWdpc3RlcixcbiAgICAgICAgaGFuZGxlU3VibWl0LFxuICAgICAgICB3YXRjaCxcbiAgICAgICAgc2V0VmFsdWUsXG4gICAgICAgIHNldFZhbHVlcyxcbiAgICAgICAgZ2V0VmFsdWVzLFxuICAgICAgICByZXNldCxcbiAgICAgICAgcmVzZXRGaWVsZCxcbiAgICAgICAgcmVzZXREZWZhdWx0VmFsdWVzLFxuICAgICAgICBjbGVhckVycm9ycyxcbiAgICAgICAgdW5yZWdpc3RlcixcbiAgICAgICAgc2V0RXJyb3IsXG4gICAgICAgIHNldEZvY3VzLFxuICAgICAgICBnZXRGaWVsZFN0YXRlLFxuICAgIH07XG4gICAgcmV0dXJuIHtcbiAgICAgICAgLi4ubWV0aG9kcyxcbiAgICAgICAgZm9ybUNvbnRyb2w6IG1ldGhvZHMsXG4gICAgfTtcbn1cblxuLyoqXG4gKiBDdXN0b20gaG9vayB0byBtYW5hZ2UgdGhlIGVudGlyZSBmb3JtLlxuICpcbiAqIEByZW1hcmtzXG4gKiBbQVBJXShodHRwczovL3JlYWN0LWhvb2stZm9ybS5jb20vZG9jcy91c2Vmb3JtKSDigKIgW0RlbW9dKGh0dHBzOi8vY29kZXNhbmRib3guaW8vcy9yZWFjdC1ob29rLWZvcm0tZ2V0LXN0YXJ0ZWQtdHMtNWtzbW0pIOKAoiBbVmlkZW9dKGh0dHBzOi8vd3d3LnlvdXR1YmUuY29tL3dhdGNoP3Y9UmtYdjRBWFhDXzQpXG4gKlxuICogQHBhcmFtIHByb3BzIC0gZm9ybSBjb25maWd1cmF0aW9uIGFuZCB2YWxpZGF0aW9uIHBhcmFtZXRlcnMuXG4gKlxuICogQHJldHVybnMgbWV0aG9kcyAtIGluZGl2aWR1YWwgZnVuY3Rpb25zIHRvIG1hbmFnZSB0aGUgZm9ybSBzdGF0ZS4ge0BsaW5rIFVzZUZvcm1SZXR1cm59XG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogZnVuY3Rpb24gQXBwKCkge1xuICogICBjb25zdCB7IHJlZ2lzdGVyLCBoYW5kbGVTdWJtaXQsIHdhdGNoLCBmb3JtU3RhdGU6IHsgZXJyb3JzIH0gfSA9IHVzZUZvcm0oKTtcbiAqICAgY29uc3Qgb25TdWJtaXQgPSBkYXRhID0+IGNvbnNvbGUubG9nKGRhdGEpO1xuICpcbiAqICAgY29uc29sZS5sb2cod2F0Y2goXCJleGFtcGxlXCIpKTtcbiAqXG4gKiAgIHJldHVybiAoXG4gKiAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChvblN1Ym1pdCl9PlxuICogICAgICAgPGlucHV0IGRlZmF1bHRWYWx1ZT1cInRlc3RcIiB7Li4ucmVnaXN0ZXIoXCJleGFtcGxlXCIpfSAvPlxuICogICAgICAgPGlucHV0IHsuLi5yZWdpc3RlcihcImV4YW1wbGVSZXF1aXJlZFwiLCB7IHJlcXVpcmVkOiB0cnVlIH0pfSAvPlxuICogICAgICAge2Vycm9ycy5leGFtcGxlUmVxdWlyZWQgJiYgPHNwYW4+VGhpcyBmaWVsZCBpcyByZXF1aXJlZDwvc3Bhbj59XG4gKiAgICAgICA8YnV0dG9uPlN1Ym1pdDwvYnV0dG9uPlxuICogICAgIDwvZm9ybT5cbiAqICAgKTtcbiAqIH1cbiAqIGBgYFxuICovXG5mdW5jdGlvbiB1c2VGb3JtKHByb3BzID0ge30pIHtcbiAgICBjb25zdCBfZm9ybUNvbnRyb2wgPSBSZWFjdC51c2VSZWYodW5kZWZpbmVkKTtcbiAgICBjb25zdCBfdmFsdWVzID0gUmVhY3QudXNlUmVmKHVuZGVmaW5lZCk7XG4gICAgY29uc3QgX2Zvcm1Db250cm9sUHJvcCA9IFJlYWN0LnVzZVJlZihwcm9wcy5mb3JtQ29udHJvbCk7XG4gICAgY29uc3QgW2Zvcm1TdGF0ZSwgdXBkYXRlRm9ybVN0YXRlXSA9IFJlYWN0LnVzZVN0YXRlKCgpID0+ICh7XG4gICAgICAgIC4uLmNsb25lT2JqZWN0KERFRkFVTFRfRk9STV9TVEFURSksXG4gICAgICAgIGlzTG9hZGluZzogaXNGdW5jdGlvbihwcm9wcy5kZWZhdWx0VmFsdWVzKSxcbiAgICAgICAgZXJyb3JzOiBwcm9wcy5lcnJvcnMgfHwge30sXG4gICAgICAgIGRpc2FibGVkOiBwcm9wcy5kaXNhYmxlZCB8fCBmYWxzZSxcbiAgICAgICAgZGVmYXVsdFZhbHVlczogaXNGdW5jdGlvbihwcm9wcy5kZWZhdWx0VmFsdWVzKVxuICAgICAgICAgICAgPyB1bmRlZmluZWRcbiAgICAgICAgICAgIDogcHJvcHMuZGVmYXVsdFZhbHVlcyxcbiAgICB9KSk7XG4gICAgaWYgKCFfZm9ybUNvbnRyb2wuY3VycmVudCB8fFxuICAgICAgICAocHJvcHMuZm9ybUNvbnRyb2wgJiYgX2Zvcm1Db250cm9sUHJvcC5jdXJyZW50ICE9PSBwcm9wcy5mb3JtQ29udHJvbCkpIHtcbiAgICAgICAgX2Zvcm1Db250cm9sUHJvcC5jdXJyZW50ID0gcHJvcHMuZm9ybUNvbnRyb2w7XG4gICAgICAgIGlmIChwcm9wcy5mb3JtQ29udHJvbCkge1xuICAgICAgICAgICAgX2Zvcm1Db250cm9sLmN1cnJlbnQgPSB7XG4gICAgICAgICAgICAgICAgLi4ucHJvcHMuZm9ybUNvbnRyb2wsXG4gICAgICAgICAgICAgICAgZm9ybVN0YXRlLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGlmIChwcm9wcy5kZWZhdWx0VmFsdWVzICYmICFpc0Z1bmN0aW9uKHByb3BzLmRlZmF1bHRWYWx1ZXMpKSB7XG4gICAgICAgICAgICAgICAgcHJvcHMuZm9ybUNvbnRyb2wucmVzZXQocHJvcHMuZGVmYXVsdFZhbHVlcywgcHJvcHMucmVzZXRPcHRpb25zKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IHsgZm9ybUNvbnRyb2wsIC4uLnJlc3QgfSA9IGNyZWF0ZUZvcm1Db250cm9sKHByb3BzKTtcbiAgICAgICAgICAgIF9mb3JtQ29udHJvbC5jdXJyZW50ID0ge1xuICAgICAgICAgICAgICAgIC4uLnJlc3QsXG4gICAgICAgICAgICAgICAgZm9ybVN0YXRlLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBjb250cm9sID0gX2Zvcm1Db250cm9sLmN1cnJlbnQuY29udHJvbDtcbiAgICBjb250cm9sLl9vcHRpb25zID0gcHJvcHM7XG4gICAgY29uc3QgeyByZXN5bmNJZk5lZWRlZCwgc25hcHNob3QgfSA9IHVzZVJlc3luY09uUmVjb25uZWN0KCk7XG4gICAgdXNlSXNvbW9ycGhpY0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IGdldEN1cnJlbnRGb3JtU3RhdGUgPSAoKSA9PiAoe1xuICAgICAgICAgICAgLi4uY29udHJvbC5fZm9ybVN0YXRlLFxuICAgICAgICAgICAgZGVmYXVsdFZhbHVlczogY29udHJvbC5fZGVmYXVsdFZhbHVlcyxcbiAgICAgICAgfSk7XG4gICAgICAgIHJlc3luY0lmTmVlZGVkKHRydWUsIGdldEN1cnJlbnRGb3JtU3RhdGUsIHVwZGF0ZUZvcm1TdGF0ZSk7XG4gICAgICAgIGNvbnN0IHVuc3Vic2NyaWJlID0gY29udHJvbC5fc3Vic2NyaWJlKHtcbiAgICAgICAgICAgIGZvcm1TdGF0ZTogY29udHJvbC5fcHJveHlGb3JtU3RhdGUsXG4gICAgICAgICAgICBjYWxsYmFjazogKCkgPT4gdXBkYXRlRm9ybVN0YXRlKHtcbiAgICAgICAgICAgICAgICAuLi5jb250cm9sLl9mb3JtU3RhdGUsXG4gICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlczogY29udHJvbC5fZGVmYXVsdFZhbHVlcyxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgcmVSZW5kZXJSb290OiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgdXBkYXRlRm9ybVN0YXRlKChkYXRhKSA9PiAoe1xuICAgICAgICAgICAgLi4uZGF0YSxcbiAgICAgICAgICAgIGlzUmVhZHk6IHRydWUsXG4gICAgICAgIH0pKTtcbiAgICAgICAgY29udHJvbC5fZm9ybVN0YXRlLmlzUmVhZHkgPSB0cnVlO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgdW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgIHNuYXBzaG90KHRydWUsIGdldEN1cnJlbnRGb3JtU3RhdGUpO1xuICAgICAgICB9O1xuICAgIH0sIFtjb250cm9sLCByZXN5bmNJZk5lZWRlZCwgc25hcHNob3RdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4gY29udHJvbC5fZGlzYWJsZUZvcm0ocHJvcHMuZGlzYWJsZWQpLCBbY29udHJvbCwgcHJvcHMuZGlzYWJsZWRdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAocHJvcHMubW9kZSkge1xuICAgICAgICAgICAgY29udHJvbC5fb3B0aW9ucy5tb2RlID0gcHJvcHMubW9kZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocHJvcHMucmVWYWxpZGF0ZU1vZGUpIHtcbiAgICAgICAgICAgIGNvbnRyb2wuX29wdGlvbnMucmVWYWxpZGF0ZU1vZGUgPSBwcm9wcy5yZVZhbGlkYXRlTW9kZTtcbiAgICAgICAgfVxuICAgIH0sIFtjb250cm9sLCBwcm9wcy5tb2RlLCBwcm9wcy5yZVZhbGlkYXRlTW9kZV0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChwcm9wcy5lcnJvcnMpIHtcbiAgICAgICAgICAgIGNvbnRyb2wuX3NldEVycm9ycyhwcm9wcy5lcnJvcnMpO1xuICAgICAgICAgICAgY29udHJvbC5fZm9jdXNFcnJvcigpO1xuICAgICAgICB9XG4gICAgfSwgW2NvbnRyb2wsIHByb3BzLmVycm9yc10pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHByb3BzLnNob3VsZFVucmVnaXN0ZXIgJiZcbiAgICAgICAgICAgIGNvbnRyb2wuX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIHZhbHVlczogY29udHJvbC5fZ2V0V2F0Y2goKSxcbiAgICAgICAgICAgIH0pO1xuICAgIH0sIFtjb250cm9sLCBwcm9wcy5zaG91bGRVbnJlZ2lzdGVyXSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGNvbnRyb2wuX3Byb3h5Rm9ybVN0YXRlLmlzRGlydHkpIHtcbiAgICAgICAgICAgIGNvbnN0IGlzRGlydHkgPSBjb250cm9sLl9nZXREaXJ0eSgpO1xuICAgICAgICAgICAgaWYgKGlzRGlydHkgIT09IGZvcm1TdGF0ZS5pc0RpcnR5KSB7XG4gICAgICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgIGlzRGlydHksXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LCBbY29udHJvbCwgZm9ybVN0YXRlLmlzRGlydHldKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIGlmIChwcm9wcy52YWx1ZXMgJiYgIWRlZXBFcXVhbChwcm9wcy52YWx1ZXMsIF92YWx1ZXMuY3VycmVudCkpIHtcbiAgICAgICAgICAgIGNvbnRyb2wuX3Jlc2V0KHByb3BzLnZhbHVlcywge1xuICAgICAgICAgICAgICAgIGtlZXBGaWVsZHNSZWY6IHRydWUsXG4gICAgICAgICAgICAgICAgLi4uY29udHJvbC5fb3B0aW9ucy5yZXNldE9wdGlvbnMsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmICghKChfYSA9IGNvbnRyb2wuX29wdGlvbnMucmVzZXRPcHRpb25zKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2Eua2VlcElzVmFsaWQpKSB7XG4gICAgICAgICAgICAgICAgY29udHJvbC5fc2V0VmFsaWQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIF92YWx1ZXMuY3VycmVudCA9IHByb3BzLnZhbHVlcztcbiAgICAgICAgICAgIHVwZGF0ZUZvcm1TdGF0ZSgoc3RhdGUpID0+ICh7IC4uLnN0YXRlIH0pKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGNvbnRyb2wuX3Jlc2V0RGVmYXVsdFZhbHVlcygpO1xuICAgICAgICB9XG4gICAgfSwgW2NvbnRyb2wsIHByb3BzLnZhbHVlc10pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmICghY29udHJvbC5fc3RhdGUubW91bnQpIHtcbiAgICAgICAgICAgIGNvbnRyb2wuX3NldFZhbGlkKCk7XG4gICAgICAgICAgICBjb250cm9sLl9zdGF0ZS5tb3VudCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNvbnRyb2wuX3N0YXRlLndhdGNoKSB7XG4gICAgICAgICAgICBjb250cm9sLl9zdGF0ZS53YXRjaCA9IGZhbHNlO1xuICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7IC4uLmNvbnRyb2wuX2Zvcm1TdGF0ZSB9KTtcbiAgICAgICAgfVxuICAgICAgICBjb250cm9sLl9yZW1vdmVVbm1vdW50ZWQoKTtcbiAgICB9KTtcbiAgICBfZm9ybUNvbnRyb2wuY3VycmVudC5mb3JtU3RhdGUgPSBSZWFjdC51c2VNZW1vKCgpID0+IGdldFByb3h5Rm9ybVN0YXRlKGZvcm1TdGF0ZSwgY29udHJvbCksIFtjb250cm9sLCBmb3JtU3RhdGVdKTtcbiAgICByZXR1cm4gX2Zvcm1Db250cm9sLmN1cnJlbnQ7XG59XG5cbi8qKlxuICogV2F0Y2ggY29tcG9uZW50IHRoYXQgc3Vic2NyaWJlcyB0byBmb3JtIGZpZWxkIGNoYW5nZXMgYW5kIHJlLXJlbmRlcnMgd2hlbiB3YXRjaGVkIGZpZWxkcyB1cGRhdGUuXG4gKlxuICogQHBhcmFtIGNvbnRyb2wgLSBUaGUgZm9ybSBjb250cm9sIG9iamVjdCBmcm9tIHVzZUZvcm1cbiAqIEBwYXJhbSBuYW1lIC0gQ2FuIGJlIGZpZWxkIG5hbWUsIGFycmF5IG9mIGZpZWxkIG5hbWVzLCBvciB1bmRlZmluZWQgdG8gd2F0Y2ggdGhlIGVudGlyZSBmb3JtXG4gKiBAcGFyYW0gZGlzYWJsZWQgLSBEaXNhYmxlIHN1YnNjcmlwdGlvblxuICogQHBhcmFtIGV4YWN0IC0gV2hldGhlciB0byB3YXRjaCBleGFjdCBmaWVsZCBuYW1lcyBvciBub3RcbiAqIEBwYXJhbSBkZWZhdWx0VmFsdWUgLSBUaGUgZGVmYXVsdCB2YWx1ZSB0byB1c2UgaWYgdGhlIGZpZWxkIGlzIG5vdCB5ZXQgc2V0XG4gKiBAcGFyYW0gY29tcHV0ZSAtIEZ1bmN0aW9uIHRvIGNvbXB1dGUgZGVyaXZlZCB2YWx1ZXMgZnJvbSB3YXRjaGVkIGZpZWxkc1xuICogQHBhcmFtIHJlbmRlciAtIFRoZSBmdW5jdGlvbiB0aGF0IHJlY2VpdmVzIHdhdGNoZWQgdmFsdWVzIGFuZCByZXR1cm5zIFJlYWN0Tm9kZVxuICogQHJldHVybnMgVGhlIHJlc3VsdCBvZiBjYWxsaW5nIHJlbmRlciBmdW5jdGlvbiB3aXRoIHdhdGNoZWQgdmFsdWVzXG4gKlxuICogQGV4YW1wbGVcbiAqIFRoZSBgV2F0Y2hgIGNvbXBvbmVudCBvbmx5IHJlLXJlbmRlciB3aGVuIHRoZSB2YWx1ZXMgb2YgYGZvb2AsIGBiYXJgLCBhbmQgYGJhei5xdXhgIGNoYW5nZS5cbiAqIFRoZSB0eXBlcyBvZiBgZm9vYCwgYGJhcmAsIGFuZCBgYmF6LnF1eGAgYXJlIHByZWNpc2VseSBpbmZlcnJlZC5cbiAqXG4gKiBgYGB0c3hcbiAqIGNvbnN0IHsgY29udHJvbCB9ID0gdXNlRm9ybSgpO1xuICpcbiAqIDxXYXRjaFxuICogICBjb250cm9sPXtjb250cm9sfVxuICogICBuYW1lcz17Wydmb28nLCAnYmFyJywgJ2Jhei5xdXgnXX1cbiAqICAgcmVuZGVyPXsoW2ZvbywgYmFyLCBiYXpfcXV4XSkgPT4gPGRpdj57Zm9vfXtiYXJ9e2Jhel9xdXh9PC9kaXY+fVxuICogLz5cbiAqIGBgYFxuICovXG5jb25zdCBXYXRjaCA9IChwcm9wcykgPT4gcHJvcHMucmVuZGVyKHVzZVdhdGNoKHsgbmFtZTogcHJvcHMubmFtZXMsIC4uLnByb3BzIH0pKTtcblxuZXhwb3J0IHsgQ29udHJvbGxlciwgRmllbGRBcnJheSwgRm9ybSwgRm9ybVByb3ZpZGVyLCBGb3JtU3RhdGUsIEZvcm1TdGF0ZVN1YnNjcmliZSwgV2F0Y2gsIGFwcGVuZEVycm9ycywgY3JlYXRlRm9ybUNvbnRyb2wsIGdldCwgc2V0LCB1c2VDb250cm9sbGVyLCB1c2VGaWVsZEFycmF5LCB1c2VGb3JtLCB1c2VGb3JtQ29udGV4dCwgdXNlRm9ybVN0YXRlLCB1c2VXYXRjaCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguZXNtLm1qcy5tYXBcbiJdLCJtYXBwaW5ncyI6Ijs7OztBQUVBLElBQUksbUJBQW1CLFlBQVksUUFBUSxTQUFTO0FBRXBELElBQUksZUFBZSxZQUFZLFFBQVEsU0FBUztBQUVoRCxJQUFJLGdCQUFnQixVQUFVLGlCQUFpQjtBQUUvQyxJQUFJLHFCQUFxQixVQUFVLFNBQVM7QUFFNUMsSUFBTSxnQkFBZ0IsVUFBVSxPQUFPLFVBQVU7QUFDakQsSUFBSSxZQUFZLFVBQVUsQ0FBQyxrQkFBa0IsS0FBSyxLQUM5QyxDQUFDLE1BQU0sUUFBUSxLQUFLLEtBQ3BCLGFBQWEsS0FBSyxLQUNsQixDQUFDLGFBQWEsS0FBSztBQUV2QixJQUFJLGlCQUFpQixVQUFVLFNBQVMsS0FBSyxLQUFLLE1BQU0sU0FDbEQsZ0JBQWdCLE1BQU0sTUFBTSxJQUN4QixNQUFNLE9BQU8sVUFDYixZQUFZLE1BQU0sTUFBTSxJQUNwQixNQUFNLE9BQU8sUUFDYixNQUFNLE9BQU8sUUFDckI7QUFFTixJQUFJLHNCQUFzQixPQUFPLFNBQVMsS0FDckMsTUFBTSxHQUFHLENBQUMsQ0FDVixNQUFNLE1BQU0sT0FBTyxRQUFRLENBQUMsTUFBTSxPQUFPLElBQUksQ0FBQyxLQUFLLE1BQU0sSUFBSSxJQUFJLE1BQU0sR0FBRyxLQUFLLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO0FBRWhHLElBQUksaUJBQWlCLGVBQWU7Q0FDaEMsTUFBTSxnQkFBZ0IsV0FBVyxlQUFlLFdBQVcsWUFBWTtDQUN2RSxPQUFRLFNBQVMsYUFBYSxLQUFLLGNBQWMsZUFBZSxlQUFlO0FBQ25GO0FBRUEsSUFBSSxRQUFRLE9BQU8sV0FBVyxlQUMxQixPQUFPLE9BQU8sZ0JBQWdCLGVBQzlCLE9BQU8sYUFBYTtBQUV4QixTQUFTLFlBQVksTUFBTTtDQUN2QixJQUFJLGdCQUFnQixNQUNoQixPQUFPLElBQUksS0FBSyxJQUFJO0NBRXhCLE1BQU0scUJBQXFCLE9BQU8sYUFBYSxlQUFlLGdCQUFnQjtDQUM5RSxJQUFJLFVBQVUsZ0JBQWdCLFFBQVEscUJBQ2xDLE9BQU87Q0FFWCxNQUFNLFVBQVUsTUFBTSxRQUFRLElBQUk7Q0FDbEMsSUFBSSxDQUFDLFdBQVcsRUFBRSxTQUFTLElBQUksS0FBSyxjQUFjLElBQUksSUFDbEQsT0FBTztDQUVYLE1BQU0sT0FBTyxVQUFVLENBQUMsSUFBSSxPQUFPLE9BQU8sT0FBTyxlQUFlLElBQUksQ0FBQztDQUNyRSxLQUFLLE1BQU0sT0FBTyxNQUNkLElBQUksT0FBTyxVQUFVLGVBQWUsS0FBSyxNQUFNLEdBQUcsR0FDOUMsS0FBSyxPQUFPLFlBQVksS0FBSyxJQUFJO0NBR3pDLE9BQU87QUFDWDtBQUVBLElBQU0sU0FBUztDQUNYLE1BQU07Q0FDTixXQUFXO0NBQ1gsUUFBUTtDQUNSLFFBQVE7Q0FDUixTQUFTO0NBQ1QsT0FBTztBQUNYO0FBQ0EsSUFBTSxrQkFBa0I7Q0FDcEIsUUFBUTtDQUNSLFVBQVU7Q0FDVixVQUFVO0NBQ1YsV0FBVztDQUNYLEtBQUs7QUFDVDtBQUNBLElBQU0seUJBQXlCO0NBQzNCLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsV0FBVztDQUNYLFdBQVc7Q0FDWCxTQUFTO0NBQ1QsVUFBVTtDQUNWLFVBQVU7QUFDZDtBQUNBLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0scUJBQXFCO0NBQUM7Q0FBYTtDQUFlO0FBQVc7QUFFbkUsSUFBTSxZQUFZO0FBQ2xCLElBQUksU0FBUyxVQUFVLFVBQVUsS0FBSyxLQUFLO0FBRTNDLElBQUksZUFBZSxRQUFRLFFBQVEsS0FBQTtBQUVuQyxJQUFNLGdCQUFnQjtBQUN0QixJQUFJLGdCQUFnQixVQUFVLE1BQU0sTUFBTSxhQUFhLENBQUMsQ0FBQyxPQUFPLE9BQU87QUFFdkUsSUFBSSxPQUFPLFFBQVEsTUFBTSxpQkFBaUI7Q0FDdEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLE1BQU0sR0FDekIsT0FBTztDQUVYLE1BQU0sUUFBUSxNQUFNLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxhQUFhLElBQUk7Q0FDdEQsSUFBSSxNQUFNLE1BQU0sUUFBUSxtQkFBbUIsU0FBUyxHQUFHLENBQUMsR0FDcEQsT0FBTztDQUVYLE1BQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxRQUFRO0VBQ3pDLE9BQU8sa0JBQWtCLE1BQU0sSUFBSSxLQUFBLElBQVksT0FBTztDQUMxRCxHQUFHLE1BQU07Q0FDVCxPQUFPLFlBQVksTUFBTSxLQUFLLFdBQVcsU0FDbkMsWUFBWSxPQUFPLEtBQUssSUFDcEIsZUFDQSxPQUFPLFFBQ1g7QUFDVjtBQUVBLElBQUksYUFBYSxVQUFVLE9BQU8sVUFBVTtBQUU1QyxJQUFJLGNBQWMsVUFBVSxPQUFPLFVBQVU7QUFFN0MsSUFBSSxPQUFPLFFBQVEsTUFBTSxVQUFVO0NBQy9CLElBQUksUUFBUTtDQUNaLE1BQU0sV0FBVyxNQUFNLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxhQUFhLElBQUk7Q0FDekQsTUFBTSxTQUFTLFNBQVM7Q0FDeEIsTUFBTSxZQUFZLFNBQVM7Q0FDM0IsT0FBTyxFQUFFLFFBQVEsUUFBUTtFQUNyQixNQUFNLE1BQU0sU0FBUztFQUNyQixJQUFJLFdBQVc7RUFDZixJQUFJLFVBQVUsV0FBVztHQUNyQixNQUFNLFdBQVcsT0FBTztHQUN4QixXQUNJLFNBQVMsUUFBUSxLQUFLLE1BQU0sUUFBUSxRQUFRLElBQ3RDLFdBQ0EsQ0FBQyxNQUFNLENBQUMsU0FBUyxRQUFRLEVBQUUsSUFDdkIsQ0FBQyxJQUNELENBQUM7RUFDbkI7RUFDQSxJQUFJLG1CQUFtQixTQUFTLEdBQUcsR0FDL0I7RUFFSixPQUFPLE9BQU87RUFDZCxTQUFTLE9BQU87Q0FDcEI7QUFDSjs7Ozs7QUFNQSxJQUFNLHlCQUFBLGFBQStCLGNBQWMsSUFBSTtBQUN2RCx1QkFBdUIsY0FBYzs7OztBQUlyQyxJQUFNLDhCQUFBLGFBQW9DLFdBQVcsc0JBQXNCO0FBRTNFLElBQUkscUJBQXFCLFdBQVcsU0FBUyxxQkFBcUIsU0FBUyxTQUFTO0NBQ2hGLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLEtBQUssTUFBTSxPQUFPLFdBQ2QsT0FBTyxlQUFlLFFBQVEsS0FBSyxFQUMvQixXQUFXO0VBQ1AsTUFBTSxPQUFPO0VBQ2IsSUFBSSxRQUFRLGdCQUFnQixVQUFVLGdCQUFnQixLQUNsRCxRQUFRLGdCQUFnQixRQUFRLENBQUMsVUFBVSxnQkFBZ0I7RUFFL0Qsd0JBQXdCLG9CQUFvQixRQUFRO0VBQ3BELE9BQU8sVUFBVTtDQUNyQixFQUNKLENBQUM7Q0FFTCxPQUFPO0FBQ1g7QUFFQSxJQUFNLDRCQUE0QixRQUFBLGFBQ3RCLGtCQUFBLGFBQ0E7QUFFWixJQUFJLGVBQWUsVUFBVSxrQkFBa0IsS0FBSyxLQUFLLENBQUMsYUFBYSxLQUFLO0FBRTVFLElBQU0sb0NBQW9DLFFBQVEsU0FBUyxLQUFLLFdBQVcsS0FBSyxDQUFDLE1BQU0sUUFBUSxNQUFNLEtBQUssQ0FBQyxjQUFjLE1BQU07QUFDL0gsU0FBUyxVQUFVLFNBQVMsU0FBUywwQkFBVSxJQUFJLFFBQVEsR0FBRztDQUMxRCxJQUFJLFlBQVksU0FDWixPQUFPO0NBRVgsSUFBSSxZQUFZLE9BQU8sS0FBSyxZQUFZLE9BQU8sR0FDM0MsT0FBTyxPQUFPLEdBQUcsU0FBUyxPQUFPO0NBRXJDLElBQUksYUFBYSxPQUFPLEtBQUssYUFBYSxPQUFPLEdBQzdDLE9BQU8sT0FBTyxHQUFHLFFBQVEsUUFBUSxHQUFHLFFBQVEsUUFBUSxDQUFDO0NBRXpELE1BQU0sUUFBUSxPQUFPLEtBQUssT0FBTztDQUNqQyxNQUFNLFFBQVEsT0FBTyxLQUFLLE9BQU87Q0FDakMsSUFBSSxNQUFNLFdBQVcsTUFBTSxRQUN2QixPQUFPO0NBRVgsSUFBSSxpQ0FBaUMsU0FBUyxLQUFLLEtBQy9DLGlDQUFpQyxTQUFTLEtBQUssR0FDL0MsT0FBTyxPQUFPLEdBQUcsU0FBUyxPQUFPO0NBRXJDLElBQUksQ0FBQyxNQUFNLFVBQVUsTUFBTSxRQUFRLE9BQU8sTUFBTSxNQUFNLFFBQVEsT0FBTyxHQUNqRSxPQUFPO0NBRVgsTUFBTSxlQUFlLFFBQVEsSUFBSSxPQUFPO0NBQ3hDLElBQUksZ0JBQWdCLGFBQWEsSUFBSSxPQUFPLEdBQ3hDLE9BQU87Q0FFWCxJQUFJLGNBQ0EsYUFBYSxJQUFJLE9BQU87TUFFdkI7RUFDRCxNQUFNLHFCQUFLLElBQUksUUFBUTtFQUN2QixHQUFHLElBQUksT0FBTztFQUNkLFFBQVEsSUFBSSxTQUFTLEVBQUU7Q0FDM0I7Q0FDQSxLQUFLLE1BQU0sT0FBTyxPQUFPO0VBQ3JCLE1BQU0sT0FBTyxRQUFRO0VBQ3JCLElBQUksRUFBRSxPQUFPLFVBQ1QsT0FBTztFQUVYLElBQUksUUFBUSxPQUFPO0dBQ2YsTUFBTSxPQUFPLFFBQVE7R0FDckIsSUFBSyxhQUFhLElBQUksS0FBSyxhQUFhLElBQUksTUFDdEMsU0FBUyxJQUFJLEtBQUssTUFBTSxRQUFRLElBQUksT0FDakMsU0FBUyxJQUFJLEtBQUssTUFBTSxRQUFRLElBQUksS0FDdkMsQ0FBQyxVQUFVLE1BQU0sTUFBTSxPQUFPLElBQzlCLENBQUMsT0FBTyxHQUFHLE1BQU0sSUFBSSxHQUN2QixPQUFPO0VBRWY7Q0FDSjtDQUNBLE9BQU87QUFDWDtBQUVBLFNBQVMsdUJBQXVCO0NBQzVCLE1BQU0sYUFBQSxhQUFtQixPQUFPLEtBQUs7Q0FDckMsTUFBTSxhQUFBLGFBQW1CLE9BQU8sS0FBQSxDQUFTO0NBZXpDLE9BQU87RUFBRSxnQkFBQSxhQWRvQixhQUFhLFNBQVMsaUJBQWlCLGFBQWE7R0FDN0UsSUFBSSxXQUFXLFdBQVcsU0FBUztJQUMvQixNQUFNLGVBQWUsZ0JBQWdCO0lBQ3JDLElBQUksQ0FBQyxVQUFVLFdBQVcsU0FBUyxZQUFZLEdBQzNDLFNBQVMsWUFBWTtHQUU3QjtHQUNBLFdBQVcsVUFBVTtFQUN6QixHQUFHLENBQUMsQ0FNa0I7RUFBRyxVQUFBLGFBTEYsYUFBYSxTQUFTLG9CQUFvQjtHQUM3RCxJQUFJLFNBQ0EsV0FBVyxVQUFVLFlBQVksZ0JBQWdCLENBQUM7RUFFMUQsR0FBRyxDQUFDLENBQzRCO0NBQUU7QUFDdEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFnQ0EsU0FBUyxhQUFhLE9BQU87Q0FDekIsTUFBTSxjQUFjLHNCQUFzQjtDQUMxQyxNQUFNLEVBQUUsVUFBVSxhQUFhLFVBQVUsTUFBTSxVQUFVLFNBQVMsQ0FBQztDQUNuRSxNQUFNLENBQUMsV0FBVyxtQkFBQSxhQUF5QixnQkFBZ0I7RUFDdkQsR0FBRyxRQUFRO0VBQ1gsZUFBZSxRQUFRO0NBQzNCLEVBQUU7Q0FDRixNQUFNLHVCQUFBLGFBQTZCLE9BQU87RUFDdEMsU0FBUztFQUNULFdBQVc7RUFDWCxhQUFhO0VBQ2IsZUFBZTtFQUNmLGtCQUFrQjtFQUNsQixjQUFjO0VBQ2QsU0FBUztFQUNULFFBQVE7Q0FDWixDQUFDO0NBQ0QsTUFBTSxFQUFFLGdCQUFnQixhQUFhLHFCQUFxQjtDQUMxRCxnQ0FBZ0M7RUFDNUIsTUFBTSw2QkFBNkI7R0FDL0IsR0FBRyxRQUFRO0dBQ1gsZUFBZSxRQUFRO0VBQzNCO0VBQ0EsZUFBZSxDQUFDLFVBQVUscUJBQXFCLGVBQWU7RUFDOUQsTUFBTSxjQUFjLFFBQVEsV0FBVztHQUNuQztHQUNBLFdBQVcscUJBQXFCO0dBQ2hDO0dBQ0EsV0FBVyxjQUFjO0lBQ3JCLENBQUMsWUFDRyxnQkFBZ0I7S0FDWixHQUFHLFFBQVE7S0FDWCxHQUFHO0tBQ0gsZUFBZSxRQUFRO0lBQzNCLENBQUM7R0FDVDtFQUNKLENBQUM7RUFDRCxhQUFhO0dBQ1QsWUFBWTtHQUNaLFNBQVMsQ0FBQyxVQUFVLG1CQUFtQjtFQUMzQztDQUNKLEdBQUc7RUFBQztFQUFNO0VBQVU7RUFBTztFQUFnQjtDQUFRLENBQUM7Q0FDcEQsYUFBTSxnQkFBZ0I7RUFDbEIscUJBQXFCLFFBQVEsV0FBVyxRQUFRLFVBQVUsSUFBSTtDQUNsRSxHQUFHLENBQUMsT0FBTyxDQUFDO0NBQ1osT0FBQSxhQUFhLGNBQWMsa0JBQWtCLFdBQVcsU0FBUyxxQkFBcUIsU0FBUyxLQUFLLEdBQUcsQ0FBQyxXQUFXLE9BQU8sQ0FBQztBQUMvSDtBQUVBLElBQUksWUFBWSxVQUFVLE9BQU8sVUFBVTtBQUUzQyxJQUFJLHVCQUF1QixPQUFPLFFBQVEsWUFBWSxVQUFVLGlCQUFpQjtDQUM3RSxJQUFJLFNBQVMsS0FBSyxHQUFHO0VBQ2pCLFlBQVksT0FBTyxNQUFNLElBQUksS0FBSztFQUNsQyxPQUFPLElBQUksWUFBWSxPQUFPLFlBQVk7Q0FDOUM7Q0FDQSxJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQ25CLE9BQU8sTUFBTSxLQUFLLGVBQWUsWUFBWSxPQUFPLE1BQU0sSUFBSSxTQUFTLEdBQ25FLElBQUksWUFBWSxTQUFTLEVBQUU7Q0FFbkMsYUFBYSxPQUFPLFdBQVc7Q0FDL0IsT0FBTztBQUNYOzs7Ozs7Ozs7Ozs7Ozs7OztBQWtCQSxTQUFTLFNBQVMsT0FBTztDQUNyQixNQUFNLGNBQWMsc0JBQXNCO0NBQzFDLE1BQU0sRUFBRSxVQUFVLGFBQWEsTUFBTSxjQUFjLFVBQVUsT0FBTyxZQUFhLFNBQVMsQ0FBQztDQUMzRixNQUFNLGdCQUFBLGFBQXNCLE9BQU8sWUFBWTtDQUMvQyxNQUFNLFdBQUEsYUFBaUIsT0FBTyxPQUFPO0NBQ3JDLE1BQU0scUJBQUEsYUFBMkIsT0FBTyxLQUFBLENBQVM7Q0FDakQsTUFBTSxlQUFBLGFBQXFCLE9BQU8sT0FBTztDQUN6QyxNQUFNLFlBQUEsYUFBa0IsT0FBTyxJQUFJO0NBQ25DLFNBQVMsVUFBVTtDQUNuQixNQUFNLENBQUMsT0FBTyxlQUFBLGFBQXFCLGVBQWU7RUFDOUMsTUFBTSxlQUFlLFFBQVEsVUFBVSxNQUFNLGNBQWMsT0FBTztFQUNsRSxPQUFPLFNBQVMsVUFBVSxTQUFTLFFBQVEsWUFBWSxJQUFJO0NBQy9ELENBQUM7Q0FDRCxNQUFNLG1CQUFBLGFBQXlCLGFBQWEsV0FBVztFQUNuRCxNQUFNLGFBQWEsb0JBQW9CLE1BQU0sUUFBUSxRQUFRLFVBQVUsUUFBUSxhQUFhLE9BQU8sY0FBYyxPQUFPO0VBQ3hILE9BQU8sU0FBUyxVQUFVLFNBQVMsUUFBUSxVQUFVLElBQUk7Q0FDN0QsR0FBRztFQUFDLFFBQVE7RUFBYSxRQUFRO0VBQVE7Q0FBSSxDQUFDO0NBQzlDLE1BQU0sZUFBQSxhQUFxQixhQUFhLFdBQVc7RUFDL0MsSUFBSSxDQUFDLFVBQVU7R0FDWCxNQUFNLGFBQWEsb0JBQW9CLE1BQU0sUUFBUSxRQUFRLFVBQVUsUUFBUSxhQUFhLE9BQU8sY0FBYyxPQUFPO0dBQ3hILElBQUksU0FBUyxTQUFTO0lBQ2xCLE1BQU0scUJBQXFCLFNBQVMsUUFBUSxVQUFVO0lBQ3RELElBQUksQ0FBQyxVQUFVLG9CQUFvQixtQkFBbUIsT0FBTyxHQUFHO0tBQzVELFlBQVksa0JBQWtCO0tBQzlCLG1CQUFtQixVQUFVO0lBQ2pDO0dBQ0osT0FFSSxZQUFZLFVBQVU7RUFFOUI7Q0FDSixHQUFHO0VBQUMsUUFBUTtFQUFhLFFBQVE7RUFBUTtFQUFVO0NBQUksQ0FBQztDQUN4RCxNQUFNLEVBQUUsZ0JBQWdCLGFBQWEscUJBQXFCO0NBQzFELE1BQU0sZ0JBQUEsYUFBc0IsT0FBTyxZQUFZO0NBQy9DLGNBQWMsVUFBVTtDQUN4QixNQUFNLG9CQUFBLGFBQTBCLE9BQU8sZ0JBQWdCO0NBQ3ZELGtCQUFrQixVQUFVO0NBQzVCLGdDQUFnQztFQUM1QixJQUFJLGFBQWEsWUFBWSxXQUN6QixDQUFDLFVBQVUsVUFBVSxTQUFTLElBQUksR0FBRztHQUNyQyxhQUFhLFVBQVU7R0FDdkIsVUFBVSxVQUFVO0dBQ3BCLGNBQWMsUUFBUTtFQUMxQixPQUVJLGVBQWUsQ0FBQyxnQkFBZ0Isa0JBQWtCLFFBQVEsSUFBSSxpQkFBaUI7R0FDM0UsWUFBWSxZQUFZO0dBQ3hCLG1CQUFtQixVQUFVO0VBQ2pDLENBQUM7RUFFTCxNQUFNLGNBQWMsUUFBUSxXQUFXO0dBQ25DO0dBQ0EsV0FBVyxFQUNQLFFBQVEsS0FDWjtHQUNBO0dBQ0EsV0FBVyxjQUFjO0lBQ3JCLGNBQWMsUUFBUSxVQUFVLE1BQU07R0FDMUM7RUFDSixDQUFDO0VBQ0QsYUFBYTtHQUNULFlBQVk7R0FDWixTQUFTLENBQUMsZ0JBQWdCLGtCQUFrQixRQUFRLENBQUM7RUFDekQ7Q0FDSixHQUFHO0VBQUM7RUFBUztFQUFPO0VBQU07RUFBVTtFQUFnQjtDQUFRLENBQUM7Q0FDN0QsYUFBTSxnQkFBZ0IsUUFBUSxpQkFBaUIsQ0FBQztDQUtoRCxNQUFNLGlCQUFpQixhQUFhLFlBQVk7Q0FDaEQsTUFBTSxXQUFXLFVBQVU7Q0FHM0IsTUFBTSxpQkFBQSxhQUF1QixjQUFjO0VBQ3ZDLElBQUksVUFDQSxPQUFPO0VBRVgsTUFBTSxjQUFjLENBQUMsa0JBQWtCLENBQUMsVUFBVSxVQUFVLElBQUk7RUFFaEUsT0FEOEIsa0JBQWtCLGNBQ2pCLGlCQUFpQixJQUFJO0NBQ3hELEdBQUc7RUFBQztFQUFVO0VBQWdCO0VBQU07RUFBVTtDQUFnQixDQUFDO0NBQy9ELE9BQU8sbUJBQW1CLE9BQU8saUJBQWlCO0FBQ3REOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBMEJBLFNBQVMsY0FBYyxPQUFPO0NBQzFCLE1BQU0sY0FBYyxzQkFBc0I7Q0FDMUMsTUFBTSxFQUFFLE1BQU0sVUFBVSxVQUFVLGFBQWEsa0JBQWtCLGNBQWMsUUFBUSxTQUFVO0NBQ2pHLE1BQU0sZUFBZSxtQkFBbUIsUUFBUSxPQUFPLE9BQU8sSUFBSTtDQUVsRSxNQUFNLFFBQVEsU0FBUztFQUNuQjtFQUNBO0VBQ0EsY0FBQSxhQUoyQixjQUFjLElBQUksUUFBUSxhQUFhLE1BQU0sSUFBSSxRQUFRLGdCQUFnQixNQUFNLFlBQVksQ0FBQyxHQUFHO0dBQUM7R0FBUztHQUFNO0VBQVksQ0FJekg7RUFDN0I7Q0FDSixDQUFDO0NBQ0QsTUFBTSxZQUFZLGFBQWE7RUFDM0I7RUFDQTtFQUNBO0NBQ0osQ0FBQztDQUNELE1BQU0sU0FBQSxhQUFlLE9BQU8sS0FBSztDQUNqQyxNQUFNLFlBQUEsYUFBa0IsT0FBTyxJQUFJO0NBQ25DLE1BQU0saUJBQUEsYUFBdUIsT0FBTyxRQUFRLFNBQVMsTUFBTTtFQUN2RCxHQUFHLE1BQU07RUFDVDtFQUNBLEdBQUksVUFBVSxNQUFNLFFBQVEsSUFBSSxFQUFFLFVBQVUsTUFBTSxTQUFTLElBQUksQ0FBQztDQUNwRSxDQUFDLENBQUM7Q0FDRixPQUFPLFVBQVU7Q0FDakIsTUFBTSxhQUFBLGFBQW1CLGNBQWMsT0FBTyxpQkFBaUIsQ0FBQyxHQUFHO0VBQy9ELFNBQVM7R0FDTCxZQUFZO0dBQ1osV0FBVyxDQUFDLENBQUMsSUFBSSxVQUFVLFFBQVEsSUFBSTtFQUMzQztFQUNBLFNBQVM7R0FDTCxZQUFZO0dBQ1osV0FBVyxDQUFDLENBQUMsSUFBSSxVQUFVLGFBQWEsSUFBSTtFQUNoRDtFQUNBLFdBQVc7R0FDUCxZQUFZO0dBQ1osV0FBVyxDQUFDLENBQUMsSUFBSSxVQUFVLGVBQWUsSUFBSTtFQUNsRDtFQUNBLGNBQWM7R0FDVixZQUFZO0dBQ1osV0FBVyxDQUFDLENBQUMsSUFBSSxVQUFVLGtCQUFrQixJQUFJO0VBQ3JEO0VBQ0EsT0FBTztHQUNILFlBQVk7R0FDWixXQUFXLElBQUksVUFBVSxRQUFRLElBQUk7RUFDekM7Q0FDSixDQUFDLEdBQUcsQ0FBQyxXQUFXLElBQUksQ0FBQztDQUNyQixNQUFNLFdBQUEsYUFBaUIsYUFBYSxVQUFVO0VBQzFDLE1BQU0sUUFBUSxjQUFjLEtBQUs7RUFDakMsSUFBSSxDQUFDLElBQUksUUFBUSxTQUFTLElBQUksR0FDMUIsZUFBZSxVQUFVLFFBQVEsU0FBUyxNQUFNO0dBQzVDLEdBQUcsT0FBTyxRQUFRO0dBQ2xCO0VBQ0osQ0FBQztFQUVMLE9BQU8sZUFBZSxRQUFRLFNBQVM7R0FDbkMsUUFBUTtJQUNKLE9BQU8sY0FBYyxLQUFLO0lBQ3BCO0dBQ1Y7R0FDQSxNQUFNLE9BQU87RUFDakIsQ0FBQztDQUNMLEdBQUcsQ0FBQyxNQUFNLE9BQU8sQ0FBQztDQUNsQixNQUFNLFNBQUEsYUFBZSxrQkFBa0IsZUFBZSxRQUFRLE9BQU87RUFDakUsUUFBUTtHQUNKLE9BQU8sSUFBSSxRQUFRLGFBQWEsSUFBSTtHQUM5QjtFQUNWO0VBQ0EsTUFBTSxPQUFPO0NBQ2pCLENBQUMsR0FBRyxDQUFDLE1BQU0sUUFBUSxXQUFXLENBQUM7Q0FDL0IsTUFBTSxNQUFBLGFBQVksYUFBYSxRQUFRO0VBQ25DLElBQUksS0FDQSxVQUFVLFVBQVU7R0FDaEIsYUFBYSxXQUFXLElBQUksS0FBSyxLQUFLLElBQUksTUFBTTtHQUNoRCxjQUFjLFdBQVcsSUFBSSxNQUFNLEtBQUssSUFBSSxPQUFPO0dBQ25ELG9CQUFvQixZQUFZLFdBQVcsSUFBSSxpQkFBaUIsS0FBSyxJQUFJLGtCQUFrQixPQUFPO0dBQ2xHLHNCQUFzQixXQUFXLElBQUksY0FBYyxLQUFLLElBQUksZUFBZTtFQUMvRTtFQUVKLE1BQU0sUUFBUSxJQUFJLFFBQVEsU0FBUyxJQUFJO0VBQ3ZDLElBQUksU0FBUyxNQUFNLE1BQU0sS0FDckIsTUFBTSxHQUFHLE1BQU0sVUFBVTtDQUVqQyxHQUFHLENBQUMsUUFBUSxTQUFTLElBQUksQ0FBQztDQUMxQixNQUFNLFFBQUEsYUFBYyxlQUFlO0VBQy9CO0VBQ0E7RUFDQSxHQUFJLFVBQVUsUUFBUSxLQUFLLFVBQVUsV0FDL0IsRUFBRSxVQUFVLFVBQVUsWUFBWSxTQUFTLElBQzNDLENBQUM7RUFDUDtFQUNBO0VBQ0E7Q0FDSixJQUFJO0VBQUM7RUFBTTtFQUFVLFVBQVU7RUFBVTtFQUFVO0VBQVE7RUFBSztDQUFLLENBQUM7Q0FDdEUsYUFBTSxnQkFBZ0I7RUFDbEIsTUFBTSx5QkFBeUIsUUFBUSxTQUFTLG9CQUFvQjtFQUNwRSxlQUFlLFVBQVUsUUFBUSxTQUFTLE1BQU07R0FDNUMsR0FBRyxPQUFPLFFBQVE7R0FDbEIsR0FBSSxVQUFVLE9BQU8sUUFBUSxRQUFRLElBQy9CLEVBQUUsVUFBVSxPQUFPLFFBQVEsU0FBUyxJQUNwQyxDQUFDO0VBQ1gsQ0FBQztFQUNELE1BQU0saUJBQWlCLE1BQU0sVUFBVTtHQUNuQyxNQUFNLFFBQVEsSUFBSSxRQUFRLFNBQVMsSUFBSTtHQUN2QyxJQUFJLFNBQVMsTUFBTSxJQUNmLE1BQU0sR0FBRyxRQUFRO0VBRXpCO0VBQ0EsY0FBYyxNQUFNLElBQUk7RUFDeEIsSUFBSSx3QkFBd0I7R0FDeEIsTUFBTSxRQUFRLFlBQVksSUFBSSxtQkFDeEIsUUFBUSxpQkFDUixRQUFRLFNBQVMsVUFBVSxRQUFRLGdCQUFnQixNQUFNLElBQUksUUFBUSxTQUFTLGVBQWUsTUFBTSxPQUFPLFFBQVEsWUFBWSxDQUFDLENBQUM7R0FDdEksSUFBSSxRQUFRLGdCQUFnQixNQUFNLEtBQUs7R0FDdkMsSUFBSSxZQUFZLElBQUksUUFBUSxhQUFhLElBQUksQ0FBQyxHQUMxQyxJQUFJLFFBQVEsYUFBYSxNQUFNLEtBQUs7RUFFNUM7RUFDQSxDQUFDLGdCQUFnQixRQUFRLFNBQVMsSUFBSTtFQUN0QyxJQUFJLFVBQVUsU0FBUztHQUNuQixNQUFNLFFBQVEsSUFBSSxRQUFRLFNBQVMsSUFBSTtHQUN2QyxJQUFJLFNBQVMsTUFBTSxJQUNmLE1BQU0sR0FBRyxNQUFNLFVBQVU7RUFFakM7RUFDQSxhQUFhO0dBQ1QsQ0FBQyxlQUNLLDBCQUEwQixDQUFDLFFBQVEsT0FBTyxTQUMxQywwQkFDQSxRQUFRLFdBQVcsSUFBSSxJQUN2QixjQUFjLE1BQU0sS0FBSztFQUNuQztDQUNKLEdBQUc7RUFBQztFQUFNO0VBQVM7RUFBYztDQUFnQixDQUFDO0NBQ2xELGFBQU0sZ0JBQWdCO0VBQ2xCLFFBQVEsa0JBQWtCO0dBQ3RCO0dBQ0E7RUFDSixDQUFDO0NBQ0wsR0FBRztFQUFDO0VBQVU7RUFBTTtDQUFPLENBQUM7Q0FDNUIsT0FBQSxhQUFhLGVBQWU7RUFDeEI7RUFDQTtFQUNBO0NBQ0osSUFBSTtFQUFDO0VBQU87RUFBVztDQUFVLENBQUM7QUFDdEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE0Q0EsSUFBTSxjQUFjLFVBQVUsTUFBTSxPQUFPLGNBQWMsS0FBSyxDQUFDO0FBRS9ELElBQUksbUJBQW1CO0NBQ25CLElBQUksT0FBTyxXQUFXLGVBQWUsT0FBTyxZQUN4QyxPQUFPLE9BQU8sV0FBVztDQUU3QixNQUFNLElBQUksT0FBTyxnQkFBZ0IsY0FBYyxLQUFLLElBQUksSUFBSSxZQUFZLElBQUksSUFBSTtDQUNoRixPQUFPLHVDQUF1QyxRQUFRLFVBQVUsTUFBTTtFQUNsRSxNQUFNLEtBQU0sS0FBSyxPQUFPLElBQUksS0FBSyxLQUFLLEtBQU07RUFDNUMsUUFBUSxLQUFLLE1BQU0sSUFBSyxJQUFJLElBQU8sRUFBQSxDQUFLLFNBQVMsRUFBRTtDQUN2RCxDQUFDO0FBQ0w7QUFFQSxJQUFJLHFCQUFxQixNQUFNLE9BQU8sVUFBVSxDQUFDLE1BQU0sUUFBUSxlQUFlLFlBQVksUUFBUSxXQUFXLElBQ3ZHLFFBQVEsYUFDTixHQUFHLEtBQUssR0FBRyxZQUFZLFFBQVEsVUFBVSxJQUFJLFFBQVEsUUFBUSxXQUFXLEtBQzFFO0FBRU4sSUFBSSxzQkFBc0IsVUFBVTtDQUNoQyxZQUFZLENBQUMsUUFBUSxTQUFTLGdCQUFnQjtDQUM5QyxVQUFVLFNBQVMsZ0JBQWdCO0NBQ25DLFlBQVksU0FBUyxnQkFBZ0I7Q0FDckMsU0FBUyxTQUFTLGdCQUFnQjtDQUNsQyxXQUFXLFNBQVMsZ0JBQWdCO0FBQ3hDO0FBRUEsSUFBSSxhQUFhLE1BQU0sUUFBUSxnQkFBZ0I7Q0FDM0MsSUFBSSxhQUNBLE9BQU87Q0FDWCxJQUFJLE9BQU8sWUFBWSxPQUFPLE1BQU0sSUFBSSxJQUFJLEdBQ3hDLE9BQU87Q0FDWCxLQUFLLE1BQU0sYUFBYSxPQUFPLE9BQzNCLElBQUksS0FBSyxXQUFXLFNBQVMsS0FBSyxLQUFLLE9BQU8sVUFBVSxNQUFNLE1BQU0sS0FDaEUsT0FBTztDQUVmLE9BQU87QUFDWDtBQUVBLElBQU0seUJBQXlCLFFBQVEsUUFBUSxhQUFhLGVBQWU7Q0FDdkUsS0FBSyxNQUFNLE9BQU8sZUFBZSxPQUFPLEtBQUssTUFBTSxHQUFHO0VBQ2xELElBQUksUUFBUSxNQUNSO0VBRUosTUFBTSxRQUFRLGNBQWMsSUFBSSxRQUFRLEdBQUcsSUFBSSxPQUFPO0VBQ3RELElBQUksT0FBTztHQUNQLE1BQU0sRUFBRSxPQUFPO0dBQ2YsSUFBSSxJQUFJO0lBQ0osSUFBSSxHQUFHLFFBQVEsR0FBRyxLQUFLLE1BQU0sT0FBTyxHQUFHLEtBQUssSUFBSSxHQUFHLEtBQUssQ0FBQyxZQUNyRCxPQUFPO1NBRU4sSUFBSSxHQUFHLE9BQU8sT0FBTyxHQUFHLEtBQUssR0FBRyxJQUFJLEtBQUssQ0FBQyxZQUMzQyxPQUFPO1NBR1AsSUFBSSxzQkFBc0IsT0FBTyxNQUFNLEdBQ25DO0dBR1osT0FDSyxJQUFJLFNBQVMsS0FBSyxLQUFLLE1BQU0sUUFBUSxLQUFLLEdBQ3ZDO1FBQUEsc0JBQXNCLE9BQU8sTUFBTSxHQUNuQztHQUFBO0VBR1o7Q0FDSjtBQUVKO0FBRUEsSUFBSSw2QkFBNkIsUUFBUSxPQUFPLFNBQVM7Q0FDckQsTUFBTSxpQkFBaUIsSUFBSSxRQUFRLElBQUk7Q0FDdkMsTUFBTSxtQkFBbUIsTUFBTSxRQUFRLGNBQWMsSUFBSSxpQkFBaUIsQ0FBQztDQUMzRSxJQUFJLGtCQUFrQixpQkFBaUIsTUFBTSxLQUFLO0NBQ2xELElBQUksUUFBUSxNQUFNLGdCQUFnQjtDQUNsQyxPQUFPO0FBQ1g7QUFFQSxJQUFJLGlCQUFpQixVQUFVLFNBQVMsS0FBSyxLQUFLLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDO0FBRXRFLElBQUksaUJBQWlCLFVBQVU7Q0FDM0IsSUFBSSxDQUFDLE9BQ0QsT0FBTztDQUVYLE1BQU0sUUFBUSxRQUFRLE1BQU0sZ0JBQWdCO0NBQzVDLE9BQVEsa0JBQ0gsU0FBUyxNQUFNLGNBQWMsTUFBTSxZQUFZLGNBQWM7QUFDdEU7QUFFQSxJQUFJLGdCQUFnQixZQUFZLFFBQVEsU0FBUztBQUVqRCxJQUFJLFdBQVcsVUFBVSxpQkFBaUI7QUFFMUMsSUFBSSxnQkFBZ0IsTUFBTSwwQkFBMEIsUUFBUSxNQUFNLFlBQVksMkJBQ3hFO0NBQ0UsR0FBRyxPQUFPO0NBQ1YsT0FBTztFQUNILEdBQUksT0FBTyxTQUFTLE9BQU8sS0FBSyxDQUFDLFFBQVEsT0FBTyxLQUFLLENBQUMsUUFBUSxDQUFDO0dBQzlELE9BQU8sV0FBVztDQUN2QjtBQUNKLElBQ0UsQ0FBQztBQUVQLElBQU0sZ0JBQWdCO0NBQ2xCLE9BQU87Q0FDUCxTQUFTO0FBQ2I7QUFDQSxJQUFNLGNBQWM7Q0FBRSxPQUFPO0NBQU0sU0FBUztBQUFLO0FBQ2pELElBQUksb0JBQW9CLFlBQVk7Q0FDaEMsSUFBSSxNQUFNLFFBQVEsT0FBTyxHQUFHO0VBQ3hCLElBQUksUUFBUSxTQUFTLEdBQUc7R0FDcEIsTUFBTSxTQUFTLFFBQ1YsUUFBUSxXQUFXLFVBQVUsT0FBTyxXQUFXLENBQUMsT0FBTyxRQUFRLENBQUMsQ0FDaEUsS0FBSyxXQUFXLE9BQU8sS0FBSztHQUNqQyxPQUFPO0lBQUUsT0FBTztJQUFRLFNBQVMsQ0FBQyxDQUFDLE9BQU87R0FBTztFQUNyRDtFQUNBLE9BQU8sUUFBUSxFQUFFLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDLFdBRWpDLFFBQVEsRUFBRSxDQUFDLGNBQWMsQ0FBQyxZQUFZLFFBQVEsRUFBRSxDQUFDLFdBQVcsS0FBSyxJQUMzRCxZQUFZLFFBQVEsRUFBRSxDQUFDLEtBQUssS0FBSyxRQUFRLEVBQUUsQ0FBQyxVQUFVLEtBQ2xELGNBQ0E7R0FBRSxPQUFPLFFBQVEsRUFBRSxDQUFDO0dBQU8sU0FBUztFQUFLLElBQzdDLGNBQ1I7Q0FDVjtDQUNBLE9BQU87QUFDWDtBQUVBLElBQU0sZ0JBQWdCO0NBQ2xCLFNBQVM7Q0FDVCxPQUFPO0FBQ1g7QUFDQSxJQUFJLGlCQUFpQixZQUFZLE1BQU0sUUFBUSxPQUFPLElBQ2hELFFBQVEsUUFBUSxVQUFVLFdBQVcsVUFBVSxPQUFPLFdBQVcsQ0FBQyxPQUFPLFdBQ3JFO0NBQ0UsU0FBUztDQUNULE9BQU8sT0FBTztBQUNsQixJQUNFLFVBQVUsYUFBYSxJQUMzQjtBQUVOLFNBQVMsaUJBQWlCLFFBQVEsS0FBSyxPQUFPLFlBQVk7Q0FDdEQsSUFBSSxTQUFTLE1BQU0sS0FDZCxNQUFNLFFBQVEsTUFBTSxLQUFLLE9BQU8sTUFBTSxRQUFRLEtBQzlDLFVBQVUsTUFBTSxLQUFLLENBQUMsUUFDdkIsT0FBTztFQUNIO0VBQ0EsU0FBUyxTQUFTLE1BQU0sSUFBSSxTQUFTO0VBQ3JDO0NBQ0o7QUFFUjtBQUVBLElBQUksc0JBQXNCLG1CQUFtQixTQUFTLGNBQWMsS0FBSyxDQUFDLFFBQVEsY0FBYyxJQUMxRixpQkFDQTtDQUNFLE9BQU87Q0FDUCxTQUFTO0FBQ2I7QUFFSixJQUFJLGdCQUFnQixPQUFPLE9BQU8sb0JBQW9CLFlBQVksMEJBQTBCLDJCQUEyQixpQkFBaUI7Q0FDcEksTUFBTSxFQUFFLEtBQUssTUFBTSxVQUFVLFdBQVcsV0FBVyxLQUFLLEtBQUssU0FBUyxVQUFVLE1BQU0sZUFBZSxVQUFXLE1BQU07Q0FDdEgsTUFBTSxhQUFhLElBQUksWUFBWSxJQUFJO0NBQ3ZDLElBQUksQ0FBQyxTQUFTLG1CQUFtQixJQUFJLElBQUksR0FDckMsT0FBTyxDQUFDO0NBRVosTUFBTSxXQUFXLE9BQU8sS0FBSyxLQUFLO0NBQ2xDLE1BQU0scUJBQXFCLFlBQVk7RUFDbkMsSUFBSSw2QkFBNkIsU0FBUyxnQkFBZ0I7R0FDdEQsTUFBTSxrQkFBa0IsVUFBVSxPQUFPLElBQUksS0FBSyxXQUFXO0dBQzdELElBQUksTUFDQSxLQUFLLFNBQVMsUUFBUSxJQUFJLGtCQUFrQixlQUFlLENBQUM7UUFHNUQsU0FBUyxrQkFBa0IsZUFBZTtHQUU5QyxTQUFTLGVBQWU7RUFDNUI7Q0FDSjtDQUNBLE1BQU0sUUFBUSxDQUFDO0NBQ2YsTUFBTSxVQUFVLGFBQWEsR0FBRztDQUNoQyxNQUFNLGFBQWEsZ0JBQWdCLEdBQUc7Q0FDdEMsTUFBTSxvQkFBb0IsV0FBVztDQUNyQyxNQUFNLFdBQVksaUJBQWlCLFlBQVksR0FBRyxNQUM5QyxZQUFZLElBQUksS0FBSyxLQUNyQixZQUFZLFVBQVUsS0FDckIsY0FBYyxHQUFHLEtBQUssSUFBSSxVQUFVLE1BQ3JDLGVBQWUsTUFDZCxNQUFNLFFBQVEsVUFBVSxLQUFLLENBQUMsV0FBVztDQUM5QyxNQUFNLG9CQUFvQixhQUFhLEtBQUssTUFBTSxNQUFNLDBCQUEwQixLQUFLO0NBQ3ZGLE1BQU0sb0JBQW9CLFdBQVcsa0JBQWtCLGtCQUFrQixVQUFVLHVCQUF1QixXQUFXLFVBQVUsdUJBQXVCLGNBQWM7RUFDaEssTUFBTSxVQUFVLFlBQVksbUJBQW1CO0VBQy9DLE1BQU0sUUFBUTtHQUNWLE1BQU0sWUFBWSxVQUFVO0dBQzVCO0dBQ0E7R0FDQSxHQUFHLGtCQUFrQixZQUFZLFVBQVUsU0FBUyxPQUFPO0VBQy9EO0NBQ0o7Q0FDQSxJQUFJLGVBQ0UsQ0FBQyxNQUFNLFFBQVEsVUFBVSxLQUFLLENBQUMsV0FBVyxTQUMxQyxhQUNJLENBQUMsc0JBQXNCLFdBQVcsa0JBQWtCLFVBQVUsTUFDM0QsVUFBVSxVQUFVLEtBQUssQ0FBQyxjQUMxQixjQUFjLENBQUMsaUJBQWlCLElBQUksQ0FBQyxDQUFDLFdBQ3RDLFdBQVcsQ0FBQyxjQUFjLElBQUksQ0FBQyxDQUFDLFVBQVc7RUFDcEQsTUFBTSxFQUFFLE9BQU8sWUFBWSxTQUFTLFFBQVEsSUFDdEM7R0FBRSxPQUFPLENBQUMsQ0FBQztHQUFVLFNBQVM7RUFBUyxJQUN2QyxtQkFBbUIsUUFBUTtFQUNqQyxJQUFJLE9BQU87R0FDUCxNQUFNLFFBQVE7SUFDVixNQUFNLHVCQUF1QjtJQUM3QjtJQUNBLEtBQUs7SUFDTCxHQUFHLGtCQUFrQix1QkFBdUIsVUFBVSxPQUFPO0dBQ2pFO0dBQ0EsSUFBSSxDQUFDLDBCQUEwQjtJQUMzQixrQkFBa0IsT0FBTztJQUN6QixPQUFPO0dBQ1g7RUFDSjtDQUNKO0NBQ0EsSUFBSSxDQUFDLFlBQVksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUMsa0JBQWtCLEdBQUcsSUFBSTtFQUNsRSxJQUFJO0VBQ0osSUFBSTtFQUNKLE1BQU0sWUFBWSxtQkFBbUIsR0FBRztFQUN4QyxNQUFNLFlBQVksbUJBQW1CLEdBQUc7RUFDeEMsSUFBSSxDQUFDLGtCQUFrQixVQUFVLEtBQzdCLENBQUMsYUFBYSxVQUFVLEtBQ3hCLENBQUMsTUFBTSxVQUFVLEdBQUc7R0FDcEIsTUFBTSxjQUFjLElBQUksa0JBQ25CLGFBQWEsQ0FBQyxhQUFhO0dBQ2hDLElBQUksQ0FBQyxrQkFBa0IsVUFBVSxLQUFLLEdBQ2xDLFlBQVksY0FBYyxVQUFVO0dBRXhDLElBQUksQ0FBQyxrQkFBa0IsVUFBVSxLQUFLLEdBQ2xDLFlBQVksY0FBYyxVQUFVO0VBRTVDLE9BQ0s7R0FDRCxNQUFNLFlBQVksSUFBSSxlQUFlLElBQUksS0FBSyxVQUFVO0dBQ3hELE1BQU0scUJBQXFCLHlCQUFTLElBQUksc0JBQUssSUFBSSxLQUFLLEVBQUEsQ0FBRSxhQUFhLElBQUksTUFBTSxJQUFJO0dBQ25GLE1BQU0sU0FBUyxJQUFJLFFBQVE7R0FDM0IsTUFBTSxTQUFTLElBQUksUUFBUTtHQUMzQixJQUFJLFNBQVMsVUFBVSxLQUFLLEtBQUssWUFDN0IsWUFBWSxTQUNOLGtCQUFrQixVQUFVLElBQUksa0JBQWtCLFVBQVUsS0FBSyxJQUNqRSxTQUNJLGFBQWEsVUFBVSxRQUN2QixZQUFZLElBQUksS0FBSyxVQUFVLEtBQUs7R0FFbEQsSUFBSSxTQUFTLFVBQVUsS0FBSyxLQUFLLFlBQzdCLFlBQVksU0FDTixrQkFBa0IsVUFBVSxJQUFJLGtCQUFrQixVQUFVLEtBQUssSUFDakUsU0FDSSxhQUFhLFVBQVUsUUFDdkIsWUFBWSxJQUFJLEtBQUssVUFBVSxLQUFLO0VBRXREO0VBQ0EsSUFBSSxhQUFhLFdBQVc7R0FDeEIsaUJBQWlCLENBQUMsQ0FBQyxXQUFXLFVBQVUsU0FBUyxVQUFVLFNBQVMsdUJBQXVCLEtBQUssdUJBQXVCLEdBQUc7R0FDMUgsSUFBSSxDQUFDLDBCQUEwQjtJQUMzQixrQkFBa0IsTUFBTSxLQUFLLENBQUMsT0FBTztJQUNyQyxPQUFPO0dBQ1g7RUFDSjtDQUNKO0NBQ0EsS0FBSyxhQUFhLGNBQ2QsQ0FBQyxZQUNBLFNBQVMsVUFBVSxLQUFNLGdCQUFnQixNQUFNLFFBQVEsVUFBVSxJQUFLO0VBQ3ZFLE1BQU0sa0JBQWtCLG1CQUFtQixTQUFTO0VBQ3BELE1BQU0sa0JBQWtCLG1CQUFtQixTQUFTO0VBQ3BELE1BQU0sWUFBWSxDQUFDLGtCQUFrQixnQkFBZ0IsS0FBSyxLQUN0RCxXQUFXLFNBQVMsQ0FBQyxnQkFBZ0I7RUFDekMsTUFBTSxZQUFZLENBQUMsa0JBQWtCLGdCQUFnQixLQUFLLEtBQ3RELFdBQVcsU0FBUyxDQUFDLGdCQUFnQjtFQUN6QyxJQUFJLGFBQWEsV0FBVztHQUN4QixpQkFBaUIsV0FBVyxnQkFBZ0IsU0FBUyxnQkFBZ0IsT0FBTztHQUM1RSxJQUFJLENBQUMsMEJBQTBCO0lBQzNCLGtCQUFrQixNQUFNLEtBQUssQ0FBQyxPQUFPO0lBQ3JDLE9BQU87R0FDWDtFQUNKO0NBQ0o7Q0FDQSxJQUFJLFdBQVcsQ0FBQyxXQUFXLFNBQVMsVUFBVSxHQUFHO0VBQzdDLE1BQU0sRUFBRSxPQUFPLGNBQWMsWUFBWSxtQkFBbUIsT0FBTztFQUNuRSxJQUFJLFFBQVEsWUFBWSxLQUFLLENBQUMsV0FBVyxNQUFNLFlBQVksR0FBRztHQUMxRCxNQUFNLFFBQVE7SUFDVixNQUFNLHVCQUF1QjtJQUM3QjtJQUNBO0lBQ0EsR0FBRyxrQkFBa0IsdUJBQXVCLFNBQVMsT0FBTztHQUNoRTtHQUNBLElBQUksQ0FBQywwQkFBMEI7SUFDM0Isa0JBQWtCLE9BQU87SUFDekIsT0FBTztHQUNYO0VBQ0o7Q0FDSjtDQUNBLElBQUksVUFBVTtFQUNWLElBQUksV0FBVyxRQUFRLEdBQUc7R0FFdEIsTUFBTSxnQkFBZ0IsaUJBQWlCLE1BRGxCLFNBQVMsWUFBWSxVQUFVLEdBQ0wsUUFBUTtHQUN2RCxJQUFJLGVBQWU7SUFDZixNQUFNLFFBQVE7S0FDVixHQUFHO0tBQ0gsR0FBRyxrQkFBa0IsdUJBQXVCLFVBQVUsY0FBYyxPQUFPO0lBQy9FO0lBQ0EsSUFBSSxDQUFDLDBCQUEwQjtLQUMzQixrQkFBa0IsY0FBYyxPQUFPO0tBQ3ZDLE9BQU87SUFDWDtHQUNKO0VBQ0osT0FDSyxJQUFJLFNBQVMsUUFBUSxHQUFHO0dBQ3pCLElBQUksbUJBQW1CLENBQUM7R0FDeEIsS0FBSyxNQUFNLE9BQU8sVUFBVTtJQUN4QixJQUFJLENBQUMsY0FBYyxnQkFBZ0IsS0FBSyxDQUFDLDBCQUNyQztJQUVKLE1BQU0sZ0JBQWdCLGlCQUFpQixNQUFNLFNBQVMsSUFBSSxDQUFDLFlBQVksVUFBVSxHQUFHLFVBQVUsR0FBRztJQUNqRyxJQUFJLGVBQWU7S0FDZixtQkFBbUI7TUFDZixHQUFHO01BQ0gsR0FBRyxrQkFBa0IsS0FBSyxjQUFjLE9BQU87S0FDbkQ7S0FDQSxrQkFBa0IsY0FBYyxPQUFPO0tBQ3ZDLElBQUksMEJBQ0EsTUFBTSxRQUFRO0lBRXRCO0dBQ0o7R0FDQSxJQUFJLENBQUMsY0FBYyxnQkFBZ0IsR0FBRztJQUNsQyxNQUFNLFFBQVE7S0FDVixLQUFLO0tBQ0wsR0FBRztJQUNQO0lBQ0EsSUFBSSxDQUFDLDBCQUNELE9BQU87R0FFZjtFQUNKO0NBQ0o7Q0FDQSxrQkFBa0IsSUFBSTtDQUN0QixPQUFPO0FBQ1g7QUFFQSxJQUFJLHlCQUF5QixVQUFXLE1BQU0sUUFBUSxLQUFLLElBQUksUUFBUSxDQUFDLEtBQUs7QUFFN0UsSUFBSSxZQUFZLE1BQU0sVUFBVSxDQUM1QixHQUFHLE1BQ0gsR0FBRyxzQkFBc0IsS0FBSyxDQUNsQztBQUVBLElBQUksa0JBQWtCLFVBQVUsTUFBTSxRQUFRLEtBQUssSUFBSSxNQUFNLFVBQVUsS0FBQSxDQUFTLElBQUksS0FBQTtBQUVwRixTQUFTLE9BQU8sTUFBTSxPQUFPLE9BQU87Q0FDaEMsT0FBTztFQUNILEdBQUcsS0FBSyxNQUFNLEdBQUcsS0FBSztFQUN0QixHQUFHLHNCQUFzQixLQUFLO0VBQzlCLEdBQUcsS0FBSyxNQUFNLEtBQUs7Q0FDdkI7QUFDSjtBQUVBLElBQUksZUFBZSxNQUFNLE1BQU0sT0FBTztDQUNsQyxJQUFJLENBQUMsTUFBTSxRQUFRLElBQUksR0FDbkIsT0FBTyxDQUFDO0NBRVosSUFBSSxZQUFZLEtBQUssR0FBRyxHQUNwQixLQUFLLE1BQU0sS0FBQTtDQUVmLEtBQUssT0FBTyxJQUFJLEdBQUcsS0FBSyxPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRTtDQUMxQyxPQUFPO0FBQ1g7QUFFQSxJQUFJLGFBQWEsTUFBTSxVQUFVLENBQzdCLEdBQUcsc0JBQXNCLEtBQUssR0FDOUIsR0FBRyxzQkFBc0IsSUFBSSxDQUNqQztBQUVBLElBQUksV0FBVyxVQUFVLE1BQU0sUUFBUSxLQUFLLElBQUksTUFBTSxPQUFPLE9BQU8sSUFBSSxDQUFDO0FBRXpFLFNBQVMsZ0JBQWdCLE1BQU0sU0FBUztDQUNwQyxJQUFJLElBQUk7Q0FDUixNQUFNLE9BQU8sQ0FBQyxHQUFHLElBQUk7Q0FDckIsS0FBSyxNQUFNLFNBQVMsU0FBUztFQUN6QixLQUFLLE9BQU8sUUFBUSxHQUFHLENBQUM7RUFDeEI7Q0FDSjtDQUNBLE9BQU8sUUFBUSxJQUFJLENBQUMsQ0FBQyxTQUFTLE9BQU8sQ0FBQztBQUMxQztBQUNBLElBQUksaUJBQWlCLE1BQU0sVUFBVSxZQUFZLEtBQUssSUFDaEQsQ0FBQyxJQUNELGdCQUFnQixNQUFNLHNCQUFzQixLQUFLLENBQUMsQ0FBQyxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsQ0FBQztBQUU5RSxJQUFJLGVBQWUsTUFBTSxRQUFRLFdBQVc7Q0FDeEMsQ0FBQyxLQUFLLFNBQVMsS0FBSyxXQUFXLENBQUMsS0FBSyxTQUFTLEtBQUssT0FBTztBQUM5RDtBQUVBLFNBQVMsUUFBUSxRQUFRLFlBQVk7Q0FDakMsTUFBTSxTQUFTLFdBQVcsU0FBUztDQUNuQyxJQUFJLFFBQVE7Q0FDWixPQUFPLFFBQVEsUUFBUTtFQUNuQixJQUFJLGtCQUFrQixNQUFNLEdBQUc7R0FDM0IsU0FBUyxLQUFBO0dBQ1Q7RUFDSjtFQUNBLFNBQVMsT0FBTyxXQUFXO0VBQzNCO0NBQ0o7Q0FDQSxPQUFPO0FBQ1g7QUFDQSxTQUFTLGFBQWEsS0FBSztDQUN2QixLQUFLLE1BQU0sT0FBTyxLQUNkLElBQUksSUFBSSxlQUFlLEdBQUcsS0FBSyxDQUFDLFlBQVksSUFBSSxJQUFJLEdBQ2hELE9BQU87Q0FHZixPQUFPO0FBQ1g7QUFDQSxTQUFTLE1BQU0sUUFBUSxNQUFNO0NBQ3pCLElBQUksU0FBUyxJQUFJLEtBQUssT0FBTyxVQUFVLGVBQWUsS0FBSyxRQUFRLElBQUksR0FBRztFQUN0RSxPQUFPLE9BQU87RUFDZCxPQUFPO0NBQ1g7Q0FDQSxNQUFNLFFBQVEsTUFBTSxRQUFRLElBQUksSUFDMUIsT0FDQSxNQUFNLElBQUksSUFDTixDQUFDLElBQUksSUFDTCxhQUFhLElBQUk7Q0FDM0IsSUFBSSxNQUFNLE1BQU0sWUFBWSxtQkFBbUIsU0FBUyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEdBQ3BFLE9BQU87Q0FFWCxNQUFNLGNBQWMsTUFBTSxXQUFXLElBQUksU0FBUyxRQUFRLFFBQVEsS0FBSztDQUN2RSxNQUFNLFFBQVEsTUFBTSxTQUFTO0NBQzdCLE1BQU0sTUFBTSxNQUFNO0NBQ2xCLElBQUksYUFDQSxPQUFPLFlBQVk7Q0FFdkIsSUFBSSxVQUFVLE1BQ1IsU0FBUyxXQUFXLEtBQUssY0FBYyxXQUFXLEtBQy9DLE1BQU0sUUFBUSxXQUFXLEtBQUssYUFBYSxXQUFXLElBQzNELE1BQU0sUUFBUSxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7Q0FFcEMsT0FBTztBQUNYO0FBRUEsSUFBSSxZQUFZLGFBQWEsT0FBTyxVQUFVO0NBQzFDLFlBQVksU0FBUztDQUNyQixPQUFPO0FBQ1g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdUNBLFNBQVMsY0FBYyxPQUFPO0NBQzFCLE1BQU0sY0FBYyxzQkFBc0I7Q0FDMUMsTUFBTSxFQUFFLFVBQVUsYUFBYSxNQUFNLFVBQVUsTUFBTSxVQUFVLGtCQUFrQixVQUFXO0NBQzVGLE1BQU0sQ0FBQyxRQUFRLGFBQUEsYUFBbUIsU0FBUyxRQUFRLGVBQWUsSUFBSSxDQUFDO0NBQ3ZFLE1BQU0sTUFBQSxhQUFZLE9BQU8sUUFBUSxlQUFlLElBQUksQ0FBQyxDQUFDLElBQUksVUFBVSxDQUFDO0NBQ3JFLE1BQU0sWUFBQSxhQUFrQixPQUFPLEtBQUs7Q0FDcEMsSUFBSSxDQUFDLFVBQ0QsUUFBUSxPQUFPLE1BQU0sSUFBSSxJQUFJO0NBRWpDLGFBQU0sY0FBYyxDQUFDLFlBQ2pCLFNBQ0EsT0FBTyxVQUFVLEtBQ2pCLFFBQVEsU0FBUyxNQUFNLEtBQUssR0FBRztFQUFDO0VBQVM7RUFBTSxPQUFPO0VBQVE7RUFBTztDQUFRLENBQUM7Q0FDbEYsZ0NBQWdDO0VBQzVCLElBQUksVUFDQTtFQUVKLE9BQU8sUUFBUSxVQUFVLE1BQU0sVUFBVSxFQUNyQyxPQUFPLEVBQUUsUUFBUSxNQUFNLHFCQUFzQjtHQUN6QyxJQUFJLG1CQUFtQixRQUFRLENBQUMsZ0JBQWdCO0lBQzVDLE1BQU0sY0FBYyxJQUFJLFFBQVEsSUFBSTtJQUNwQyxJQUFJLE1BQU0sUUFBUSxXQUFXLEdBQUc7S0FDNUIsVUFBVSxXQUFXO0tBQ3JCLElBQUksVUFBVSxZQUFZLElBQUksVUFBVTtJQUM1QyxPQUNLLElBQUksQ0FBQyxnQkFBZ0I7S0FDdEIsVUFBVSxDQUFDLENBQUM7S0FDWixJQUFJLFVBQVUsQ0FBQztJQUNuQjtHQUNKO0VBQ0osRUFDSixDQUFDLENBQUMsQ0FBQztDQUNQLEdBQUc7RUFBQztFQUFTO0VBQU07Q0FBUSxDQUFDO0NBQzVCLE1BQU0sZUFBQSxhQUFxQixhQUFhLDRCQUE0QjtFQUNoRSxVQUFVLFVBQVU7RUFDcEIsUUFBUSxlQUFlLE1BQU0sdUJBQXVCO0NBQ3hELEdBQUcsQ0FBQyxTQUFTLElBQUksQ0FBQztDQUNsQixNQUFNLFVBQVUsT0FBTyxZQUFZO0VBQy9CLElBQUksVUFDQTtFQUVKLE1BQU0sY0FBYyxzQkFBc0IsWUFBWSxLQUFLLENBQUM7RUFDNUQsTUFBTSwwQkFBMEIsU0FBUyxRQUFRLGVBQWUsSUFBSSxHQUFHLFdBQVc7RUFDbEYsUUFBUSxPQUFPLFFBQVEsa0JBQWtCLE1BQU0sd0JBQXdCLFNBQVMsR0FBRyxPQUFPO0VBQzFGLElBQUksVUFBVSxTQUFTLElBQUksU0FBUyxZQUFZLElBQUksVUFBVSxDQUFDO0VBQy9ELGFBQWEsdUJBQXVCO0VBQ3BDLFVBQVUsdUJBQXVCO0VBQ2pDLFFBQVEsZUFBZSxNQUFNLHlCQUF5QixVQUFVLEVBQzVELE1BQU0sZUFBZSxLQUFLLEVBQzlCLENBQUM7Q0FDTDtDQUNBLE1BQU0sV0FBVyxPQUFPLFlBQVk7RUFDaEMsSUFBSSxVQUNBO0VBRUosTUFBTSxlQUFlLHNCQUFzQixZQUFZLEtBQUssQ0FBQztFQUM3RCxNQUFNLDBCQUEwQixVQUFVLFFBQVEsZUFBZSxJQUFJLEdBQUcsWUFBWTtFQUNwRixRQUFRLE9BQU8sUUFBUSxrQkFBa0IsTUFBTSxHQUFHLE9BQU87RUFDekQsSUFBSSxVQUFVLFVBQVUsSUFBSSxTQUFTLGFBQWEsSUFBSSxVQUFVLENBQUM7RUFDakUsYUFBYSx1QkFBdUI7RUFDcEMsVUFBVSx1QkFBdUI7RUFDakMsUUFBUSxlQUFlLE1BQU0seUJBQXlCLFdBQVcsRUFDN0QsTUFBTSxlQUFlLEtBQUssRUFDOUIsQ0FBQztDQUNMO0NBQ0EsTUFBTSxVQUFVLFVBQVU7RUFDdEIsSUFBSSxVQUNBO0VBRUosTUFBTSwwQkFBMEIsY0FBYyxRQUFRLGVBQWUsSUFBSSxHQUFHLEtBQUs7RUFDakYsSUFBSSxVQUFVLGNBQWMsSUFBSSxTQUFTLEtBQUs7RUFDOUMsYUFBYSx1QkFBdUI7RUFDcEMsVUFBVSx1QkFBdUI7RUFDakMsQ0FBQyxNQUFNLFFBQVEsSUFBSSxRQUFRLFNBQVMsSUFBSSxDQUFDLEtBQ3JDLElBQUksUUFBUSxTQUFTLE1BQU0sS0FBQSxDQUFTO0VBQ3hDLFFBQVEsZUFBZSxNQUFNLHlCQUF5QixlQUFlLEVBQ2pFLE1BQU0sTUFDVixDQUFDO0NBQ0w7Q0FDQSxNQUFNLFlBQVksT0FBTyxPQUFPLFlBQVk7RUFDeEMsSUFBSSxVQUNBO0VBRUosTUFBTSxjQUFjLHNCQUFzQixZQUFZLEtBQUssQ0FBQztFQUM1RCxNQUFNLDBCQUEwQixPQUFPLFFBQVEsZUFBZSxJQUFJLEdBQUcsT0FBTyxXQUFXO0VBQ3ZGLFFBQVEsT0FBTyxRQUFRLGtCQUFrQixNQUFNLE9BQU8sT0FBTztFQUM3RCxJQUFJLFVBQVUsT0FBTyxJQUFJLFNBQVMsT0FBTyxZQUFZLElBQUksVUFBVSxDQUFDO0VBQ3BFLGFBQWEsdUJBQXVCO0VBQ3BDLFVBQVUsdUJBQXVCO0VBQ2pDLFFBQVEsZUFBZSxNQUFNLHlCQUF5QixRQUFRO0dBQzFELE1BQU07R0FDTixNQUFNLGVBQWUsS0FBSztFQUM5QixDQUFDO0NBQ0w7Q0FDQSxNQUFNLFFBQVEsUUFBUSxXQUFXO0VBQzdCLElBQUksVUFDQTtFQUVKLE1BQU0sMEJBQTBCLFFBQVEsZUFBZSxJQUFJO0VBQzNELFlBQVkseUJBQXlCLFFBQVEsTUFBTTtFQUNuRCxZQUFZLElBQUksU0FBUyxRQUFRLE1BQU07RUFDdkMsYUFBYSx1QkFBdUI7RUFDcEMsVUFBVSx1QkFBdUI7RUFDakMsUUFBUSxlQUFlLE1BQU0seUJBQXlCLGFBQWE7R0FDL0QsTUFBTTtHQUNOLE1BQU07RUFDVixHQUFHLEtBQUs7Q0FDWjtDQUNBLE1BQU0sUUFBUSxNQUFNLE9BQU87RUFDdkIsSUFBSSxVQUNBO0VBRUosTUFBTSwwQkFBMEIsUUFBUSxlQUFlLElBQUk7RUFDM0QsWUFBWSx5QkFBeUIsTUFBTSxFQUFFO0VBQzdDLFlBQVksSUFBSSxTQUFTLE1BQU0sRUFBRTtFQUNqQyxhQUFhLHVCQUF1QjtFQUNwQyxVQUFVLHVCQUF1QjtFQUNqQyxRQUFRLGVBQWUsTUFBTSx5QkFBeUIsYUFBYTtHQUMvRCxNQUFNO0dBQ04sTUFBTTtFQUNWLEdBQUcsS0FBSztDQUNaO0NBQ0EsTUFBTSxVQUFVLE9BQU8sVUFBVTtFQUM3QixJQUFJLFVBQ0E7RUFFSixNQUFNLGNBQWMsWUFBWSxLQUFLO0VBQ3JDLE1BQU0sMEJBQTBCLFNBQVMsUUFBUSxlQUFlLElBQUksR0FBRyxPQUFPLFdBQVc7RUFDekYsSUFBSSxVQUFVLENBQUMsR0FBRyx1QkFBdUIsQ0FBQyxDQUFDLEtBQUssTUFBTSxNQUFNLENBQUMsUUFBUSxNQUFNLFFBQVEsV0FBVyxJQUFJLElBQUksUUFBUSxFQUFFO0VBQ2hILGFBQWEsdUJBQXVCO0VBQ3BDLFVBQVUsQ0FBQyxHQUFHLHVCQUF1QixDQUFDO0VBQ3RDLFFBQVEsZUFBZSxNQUFNLHlCQUF5QixVQUFVO0dBQzVELE1BQU07R0FDTixNQUFNO0VBQ1YsR0FBRyxNQUFNLEtBQUs7Q0FDbEI7Q0FDQSxNQUFNLFdBQVcsVUFBVTtFQUN2QixJQUFJLFVBQ0E7RUFFSixNQUFNLDBCQUEwQixzQkFBc0IsWUFBWSxLQUFLLENBQUM7RUFDeEUsSUFBSSxVQUFVLHdCQUF3QixJQUFJLFVBQVU7RUFDcEQsYUFBYSxDQUFDLEdBQUcsdUJBQXVCLENBQUM7RUFDekMsVUFBVSxDQUFDLEdBQUcsdUJBQXVCLENBQUM7RUFDdEMsUUFBUSxlQUFlLE1BQU0sQ0FBQyxHQUFHLHVCQUF1QixJQUFJLFNBQVMsTUFBTSxDQUFDLEdBQUcsTUFBTSxLQUFLO0NBQzlGO0NBQ0EsYUFBTSxnQkFBZ0I7RUFDbEIsSUFBSSxVQUFVO0dBQ1YsUUFBUSxPQUFPLG1CQUFtQixPQUFPLElBQUk7R0FDN0M7RUFDSjtFQUNBLFFBQVEsT0FBTyxTQUFTO0VBQ3hCLFFBQVEsT0FBTyxtQkFBbUIsT0FBTyxJQUFJO0VBQzdDLFVBQVUsTUFBTSxRQUFRLE1BQU0sS0FDMUIsUUFBUSxVQUFVLE1BQU0sS0FBSyxFQUN6QixHQUFHLFFBQVEsV0FDZixDQUFDO0VBQ0wsTUFBTSxrQkFBa0IsbUJBQW1CLFFBQVEsU0FBUyxJQUFJO0VBQ2hFLElBQUksVUFBVSxZQUNULENBQUMsZ0JBQWdCLGNBQWMsUUFBUSxXQUFXLGdCQUNuRCxDQUFDLG1CQUFtQixRQUFRLFNBQVMsY0FBYyxDQUFDLENBQUMsY0FDckQsQ0FBQyxnQkFBZ0IsVUFBVTtHQUMzQixJQUFJLFFBQVEsU0FBUyxVQUNqQixRQUFRLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sV0FBVztJQUN4QyxJQUFJLElBQUk7SUFDUixRQUFRLG9CQUFvQixDQUFDLElBQUksQ0FBQztJQUNsQyxNQUFNLFFBQVEsSUFBSSxPQUFPLFFBQVEsSUFBSTtJQUNyQyxNQUFNLGdCQUFnQixJQUFJLFFBQVEsV0FBVyxRQUFRLElBQUk7SUFDekQsTUFBTSxvQkFBb0Isa0JBQWtCLGNBQWMsVUFBVSxLQUFLLGNBQWMsVUFBVSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUssSUFBSSxHQUFHO0lBQ3JJLE1BQU0sdUJBQXVCLGtCQUN4QixjQUFjLGFBQWEsS0FBSyxjQUFjLFVBQVUsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRztJQUNqRyxJQUFJLGdCQUNHLENBQUMsU0FBUyxxQkFDUixVQUNJLHNCQUFzQixNQUFNLFFBQ3pCLHlCQUF5QixNQUFNLFdBQ3pDLFNBQVMsTUFBTSxNQUFNO0tBQ3ZCLElBQUksT0FDQSxTQUFTLEtBQUssS0FDVixDQUFDLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQyxNQUFNLFFBQVEsQ0FBQyxPQUFPLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFDbkQsMEJBQTBCLFFBQVEsV0FBVyxRQUFRLEdBQUcsT0FBTyxNQUFNLEdBQUcsSUFBSSxJQUM1RSxJQUFJLFFBQVEsV0FBVyxRQUFRLE1BQU0sS0FBSztVQUdoRCxNQUFNLFFBQVEsV0FBVyxRQUFRLElBQUk7S0FFekMsUUFBUSxVQUFVLE1BQU0sS0FBSyxFQUN6QixRQUFRLFFBQVEsV0FBVyxPQUMvQixDQUFDO0lBQ0w7R0FDSixDQUFDO1FBRUE7SUFDRCxNQUFNLFFBQVEsSUFBSSxRQUFRLFNBQVMsSUFBSTtJQUN2QyxJQUFJLFNBQ0EsTUFBTSxNQUNOLEVBQUUsbUJBQW1CLFFBQVEsU0FBUyxjQUFjLENBQUMsQ0FBQyxjQUNsRCxtQkFBbUIsUUFBUSxTQUFTLElBQUksQ0FBQyxDQUFDLGFBQzlDLGNBQWMsT0FBTyxRQUFRLE9BQU8sVUFBVSxRQUFRLGFBQWEsUUFBUSxTQUFTLGlCQUFpQixnQkFBZ0IsS0FBSyxRQUFRLFNBQVMsMkJBQTJCLElBQUksQ0FBQyxDQUFDLE1BQU0sVUFBVSxDQUFDLGNBQWMsS0FBSyxLQUM1TSxRQUFRLFVBQVUsTUFBTSxLQUFLLEVBQ3pCLFFBQVEsMEJBQTBCLFFBQVEsV0FBVyxRQUFRLE9BQU8sSUFBSSxFQUM1RSxDQUFDLENBQUM7R0FFZDtFQUNKO0VBSUEsVUFBVSxXQUNOLFFBQVEsVUFBVSxNQUFNLEtBQUs7R0FDekI7R0FDQSxRQUFRLFlBQVksUUFBUSxXQUFXO0VBQzNDLENBQUM7RUFDTCxRQUFRLE9BQU8sU0FDWCxzQkFBc0IsUUFBUSxVQUFVLEtBQUssUUFBUTtHQUNqRCxJQUFJLFFBQVEsT0FBTyxTQUNmLElBQUksV0FBVyxRQUFRLE9BQU8sS0FBSyxLQUNuQyxJQUFJLE9BQU87SUFDWCxJQUFJLE1BQU07SUFDVixPQUFPO0dBQ1g7RUFFSixDQUFDO0VBQ0wsUUFBUSxPQUFPLFFBQVE7RUFDdkIsUUFBUSxVQUFVO0VBQ2xCLFVBQVUsVUFBVTtDQUN4QixHQUFHO0VBQUM7RUFBUTtFQUFNO0VBQVM7Q0FBUSxDQUFDO0NBQ3BDLGFBQU0sZ0JBQWdCO0VBQ2xCLElBQUksQ0FBQyxVQUNELENBQUMsSUFBSSxRQUFRLGFBQWEsSUFBSSxLQUFLLFFBQVEsZUFBZSxJQUFJO0VBRWxFLGFBQWE7R0FDVCxRQUFRLE9BQU8sbUJBQW1CLE9BQU8sSUFBSTtHQUM3QyxJQUFJLFVBQ0E7R0FFSixNQUFNLDZCQUE2QixFQUFFLFFBQVEsU0FBUyxvQkFBb0I7R0FDMUUsTUFBTSxpQkFBaUIsTUFBTSxVQUFVO0lBQ25DLE1BQU0sUUFBUSxJQUFJLFFBQVEsU0FBUyxJQUFJO0lBQ3ZDLElBQUksU0FBUyxNQUFNLElBQ2YsTUFBTSxHQUFHLFFBQVE7R0FFekI7R0FDQSxJQUFJLFVBQVUsV0FBVyw0QkFDckIsUUFBUSxVQUFVLE1BQU0sS0FBSztJQUN6QjtJQUNBLFFBQVEsWUFBWSxRQUFRLFdBQVc7R0FDM0MsQ0FBQztHQUVMLDZCQUNNLGNBQWMsTUFBTSxLQUFLLElBQ3pCLFFBQVEsV0FBVyxJQUFJO0VBQ2pDO0NBQ0osR0FBRztFQUFDO0VBQU07RUFBUztFQUFTO0VBQWtCO0NBQVEsQ0FBQztDQUN2RCxPQUFPO0VBQ0gsTUFBQSxhQUFZLFlBQVksTUFBTTtHQUFDO0dBQWM7R0FBTTtHQUFTO0VBQVEsQ0FBQztFQUNyRSxNQUFBLGFBQVksWUFBWSxNQUFNO0dBQUM7R0FBYztHQUFNO0dBQVM7RUFBUSxDQUFDO0VBQ3JFLFNBQUEsYUFBZSxZQUFZLFNBQVM7R0FDaEM7R0FDQTtHQUNBO0dBQ0E7RUFDSixDQUFDO0VBQ0QsUUFBQSxhQUFjLFlBQVksUUFBUTtHQUFDO0dBQWM7R0FBTTtHQUFTO0VBQVEsQ0FBQztFQUN6RSxRQUFBLGFBQWMsWUFBWSxRQUFRO0dBQUM7R0FBYztHQUFNO0dBQVM7RUFBUSxDQUFDO0VBQ3pFLFFBQUEsYUFBYyxZQUFZLFVBQVU7R0FBQztHQUFjO0dBQU07R0FBUztFQUFRLENBQUM7RUFDM0UsUUFBQSxhQUFjLFlBQVksUUFBUTtHQUFDO0dBQWM7R0FBTTtHQUFTO0VBQVEsQ0FBQztFQUN6RSxTQUFBLGFBQWUsWUFBWSxTQUFTO0dBQ2hDO0dBQ0E7R0FDQTtHQUNBO0VBQ0osQ0FBQztFQUNELFFBQUEsYUFBYyxjQUFjLE9BQU8sS0FBSyxPQUFPLFdBQVc7R0FDdEQsR0FBRztHQUNILEdBQUksVUFBVSxRQUFRLElBQUksRUFBRSxTQUFTLElBQUksQ0FBQztJQUN6QyxVQUFVLElBQUksUUFBUSxVQUFVLFdBQVc7RUFDaEQsRUFBRSxHQUFHO0dBQUM7R0FBUTtHQUFTO0VBQVEsQ0FBQztDQUNwQztBQUNKOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFrQ0EsSUFBTSxjQUFjLFVBQVUsTUFBTSxPQUFPLGNBQWMsS0FBSyxDQUFDO0FBRS9ELElBQU0sV0FBVyxRQUFRO0NBQ3JCLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLEtBQUssTUFBTSxPQUFPLE9BQU8sS0FBSyxHQUFHLEdBQzdCLElBQUksYUFBYSxJQUFJLElBQUksS0FDckIsSUFBSSxTQUFTLFFBQ2IsQ0FBQyxhQUFhLElBQUksSUFBSSxHQUFHO0VBQ3pCLE1BQU0sU0FBUyxRQUFRLElBQUksSUFBSTtFQUMvQixLQUFLLE1BQU0sYUFBYSxPQUFPLEtBQUssTUFBTSxHQUN0QyxPQUFPLEdBQUcsSUFBSSxHQUFHLGVBQWUsT0FBTztDQUUvQyxPQUVJLE9BQU8sT0FBTyxJQUFJO0NBRzFCLE9BQU87QUFDWDtBQUVBLFNBQVMsZUFBZSxNQUFNO0NBQzFCLE1BQU0sU0FBUyxJQUFJLFNBQVM7Q0FDNUIsTUFBTSxvQkFBb0IsUUFBUSxJQUFJO0NBQ3RDLEtBQUssTUFBTSxPQUFPLG1CQUNkLE9BQU8sT0FBTyxLQUFLLGtCQUFrQixJQUFJO0NBRTdDLE9BQU87QUFDWDtBQUVBLFNBQVMsa0JBQWtCLE9BQU87Q0FDOUIsSUFBSTtFQUNBLE9BQU8sS0FBSyxVQUFVLEtBQUs7Q0FDL0IsU0FDTyxJQUFJO0VBQ1AsT0FBTztDQUNYO0FBQ0o7QUFFQSxTQUFTLE9BQU8sQ0FBRTtBQUVsQixJQUFNLGtCQUFBLGFBQXdCLGNBQWMsSUFBSTtBQUNoRCxnQkFBZ0IsY0FBYzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQStCOUIsSUFBTSx1QkFBQSxhQUE2QixXQUFXLGVBQWU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUErQjdELElBQU0sZ0JBQWdCLEVBQUUsVUFBVSxPQUFPLFdBQVcsZUFBZSxVQUFVLGFBQWEsVUFBVSxXQUFXLFNBQVMsV0FBVyxZQUFZLE9BQU8sb0JBQW9CLGNBQWMsWUFBWSxTQUFTLFVBQVUsVUFBVSxnQkFBaUI7Q0FDOU8sTUFBTSxnQkFBQSxhQUFzQixlQUFlO0VBQ3ZDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNKLElBQUk7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDSixDQUFDO0NBQ0QsT0FBQSxhQUFjLGNBQWMsZ0JBQWdCLFVBQVUsRUFBRSxPQUFPLGNBQWMsR0FBQSxhQUNuRSxjQUFjLHVCQUF1QixVQUFVLEVBQUUsT0FBTyxjQUFjLFFBQVEsR0FBRyxRQUFRLENBQUM7QUFDeEc7QUFFQSxJQUFNLGVBQWU7QUFDckIsU0FBUyxzQkFBc0IsUUFBUTtDQUNuQyxPQUFPLFVBQVUsT0FBTyxTQUFTO0FBQ3JDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXVCQSxTQUFTLEtBQUssT0FBTztDQUNqQixNQUFNLFVBQVUsZUFBZTtDQUMvQixNQUFNLENBQUMsU0FBUyxjQUFBLGFBQW9CLFNBQVMsS0FBSztDQUNsRCxNQUFNLEVBQUUsVUFBVSxRQUFRLFNBQVMsV0FBVyxNQUFNLFVBQVUsUUFBUSxTQUFTLGNBQWMsU0FBUyxTQUFTLFVBQVUsTUFBTSxRQUFRLFlBQVksTUFBTSxpQkFBaUIsdUJBQXVCLEdBQUcsU0FBUztDQUM3TSxNQUFNLGVBQUEsYUFBcUIsY0FBYztFQUNyQyxPQUFPLFFBQVEsYUFBYSxPQUFPLE1BQU0sVUFBVTtHQUMvQyxNQUFNLFdBQVcsZUFBZSxJQUFJO0dBQ3BDLE1BQU0sZUFBZSxrQkFBa0IsSUFBSTtHQUMzQyxJQUFJLFVBQ0EsTUFBTSxTQUFTO0lBQ1g7SUFDQTtJQUNBO0lBQ0E7SUFDQTtHQUNKLENBQUM7R0FFTCxJQUFJLFNBQVMsTUFBTSxHQUNmLElBQUk7SUFDQSxNQUFNLGdDQUFpQyxXQUNuQyxRQUFRLG1CQUNSLFFBQVEsZUFBZSxDQUFDLFNBQVMsTUFBTSxLQUN0QyxXQUFXLFFBQVEsU0FBUyxNQUFNO0lBQ3ZDLE1BQU0sV0FBVyxNQUFNLE1BQU0sUUFBUTtLQUNqQztLQUNBLFNBQVM7TUFDTCxHQUFHO01BQ0gsR0FBSSxXQUNBLFlBQVkseUJBQXlCLEVBQ3JDLGdCQUFnQixRQUNwQjtLQUNKO0tBQ0EsTUFBTSxnQ0FBZ0MsZUFBZTtJQUN6RCxDQUFDO0lBQ0QsSUFBSSxZQUFZLENBQUMsZUFBZSxTQUFTLE1BQU0sR0FBRztLQUM5QyxRQUFRLEVBQUUsU0FBUyxDQUFDO0tBQ3BCLE9BQU8sRUFBRSxNQUFNLE9BQU8sU0FBUyxNQUFNLEVBQUU7SUFDM0MsT0FFSSxVQUFVLEVBQUUsU0FBUyxDQUFDO0dBRTlCLFNBQ08sT0FBTztJQUNWLFFBQVEsRUFBRSxNQUFNLENBQUM7SUFDakIsT0FBTyxFQUFFLE1BQU0sR0FBRztHQUN0QjtHQUVKLElBQUksV0FBVyxNQUFNLEdBQ2pCLElBQUk7SUFDQSxNQUFNLE9BQU8sUUFBUTtHQUN6QixTQUNPLE9BQU87SUFDVixRQUFRLEVBQUUsTUFBTSxDQUFDO0lBQ2pCLE9BQU8sRUFBRSxNQUFNLEdBQUc7R0FDdEI7RUFJUixDQUFDO0NBQ0wsR0FBRztFQUNDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNKLENBQUM7Q0FDRCxNQUFNLFNBQUEsYUFBZSxZQUFZLE9BQU8sVUFBVTtFQUM5QyxNQUFNLE1BQU0sTUFBTSxhQUFhLEtBQUs7RUFDcEMsSUFBSSxPQUFPLFNBQVM7R0FDaEIsUUFBUSxVQUFVLE1BQU0sS0FBSyxFQUFFLG9CQUFvQixNQUFNLENBQUM7R0FDMUQsUUFBUSxTQUFTLGVBQWUsR0FBRztFQUN2QztDQUNKLEdBQUcsQ0FBQyxjQUFjLE9BQU8sQ0FBQztDQUMxQixhQUFNLGdCQUFnQjtFQUNsQixXQUFXLElBQUk7Q0FDbkIsR0FBRyxDQUFDLENBQUM7Q0FDTCxJQUFJLFFBQ0EsT0FBTyxPQUFPLEVBQUUsT0FBTyxDQUFDO0NBSzVCLE9BQUEsYUFBYyxjQUFjLFFBQVE7RUFBRSxZQUFZO0VBQWlCO0VBQVEsR0FBSSxDQUFDLFdBQVcsTUFBTSxLQUFLO0dBQUU7R0FBUTtFQUFRO0VBQUksVUFBVTtFQUFRLEdBQUc7Q0FBSyxHQUFHLFFBQVE7QUFDcks7QUFFQSxJQUFNLGFBQWEsRUFBRSxTQUFTLFVBQVUsT0FBTyxNQUFNLGFBQWMsT0FBTyxhQUFhO0NBQUU7Q0FBUztDQUFNO0NBQVU7QUFBTSxDQUFDLENBQUM7O0FBRTFILElBQU0scUJBQXFCO0FBRTNCLElBQUksc0JBQXNCO0NBQ3RCLElBQUksYUFBYSxDQUFDO0NBQ2xCLE1BQU0sUUFBUSxVQUFVO0VBQ3BCLEtBQUssTUFBTSxZQUFZLFlBQ25CLFNBQVMsUUFBUSxTQUFTLEtBQUssS0FBSztDQUU1QztDQUNBLE1BQU0sYUFBYSxhQUFhO0VBQzVCLFdBQVcsS0FBSyxRQUFRO0VBQ3hCLE9BQU8sRUFDSCxtQkFBbUI7R0FDZixhQUFhLFdBQVcsUUFBUSxNQUFNLE1BQU0sUUFBUTtFQUN4RCxFQUNKO0NBQ0o7Q0FDQSxNQUFNLG9CQUFvQjtFQUN0QixhQUFhLENBQUM7Q0FDbEI7Q0FDQSxPQUFPO0VBQ0gsSUFBSSxZQUFZO0dBQ1osT0FBTztFQUNYO0VBQ0E7RUFDQTtFQUNBO0NBQ0o7QUFDSjtBQUVBLFNBQVMsa0JBQWtCLGFBQWEsWUFBWTtDQUNoRCxNQUFNLFNBQVMsQ0FBQztDQUNoQixLQUFLLE1BQU0sT0FBTyxhQUNkLElBQUksWUFBWSxlQUFlLEdBQUcsR0FBRztFQUNqQyxNQUFNLGFBQWEsWUFBWTtFQUMvQixNQUFNLGFBQWEsV0FBVztFQUM5QixJQUFJLGNBQWMsU0FBUyxVQUFVLEtBQUssWUFBWTtHQUNsRCxNQUFNLG9CQUFvQixrQkFBa0IsWUFBWSxVQUFVO0dBQ2xFLElBQUksU0FBUyxpQkFBaUIsR0FDMUIsT0FBTyxPQUFPO0VBRXRCLE9BQ0ssSUFBSSxZQUFZLE1BQ2pCLE9BQU8sT0FBTztDQUV0QjtDQUVKLE9BQU87QUFDWDtBQUVBLElBQUksb0JBQW9CLFlBQVksUUFBUSxTQUFTO0FBRXJELElBQUkscUJBQXFCLFFBQVEsYUFBYSxHQUFHLEtBQUssZ0JBQWdCLEdBQUc7QUFFekUsSUFBSSxRQUFRLFFBQVEsY0FBYyxHQUFHLEtBQUssSUFBSTtBQUU5QyxTQUFTLGlCQUFpQixPQUFPO0NBQzdCLE9BQU8sTUFBTSxRQUFRLEtBQUssS0FBSyxTQUFTLEtBQUs7QUFDakQ7QUFDQSxTQUFTLHVCQUF1QixXQUFXLG1CQUFtQixTQUFTLElBQUksUUFBUSxDQUFDLEdBQUc7Q0FDbkYsS0FBSyxNQUFNLE9BQU8sV0FBVztFQUN6QixNQUFNLE9BQU8sU0FBUyxHQUFHLE9BQU8sR0FBRyxRQUFRO0VBQzNDLE1BQU0sUUFBUSxVQUFVO0VBQ3hCLElBQUksaUJBQWlCLEtBQUssS0FDdEIsaUJBQWlCLElBQUksbUJBQW1CLElBQUksQ0FBQyxHQUM3Qyx1QkFBdUIsT0FBTyxtQkFBbUIsTUFBTSxLQUFLO09BRzVELE1BQU0sS0FBSyxJQUFJO0NBRXZCO0NBQ0EsT0FBTztBQUNYO0FBRUEsSUFBSSxxQkFBcUIsU0FBUztDQUM5QixLQUFLLE1BQU0sT0FBTyxNQUNkLElBQUksV0FBVyxLQUFLLElBQUksR0FDcEIsT0FBTztDQUdmLE9BQU87QUFDWDtBQUVBLFNBQVMsY0FBYyxPQUFPO0NBQzFCLE9BQU8sTUFBTSxRQUFRLEtBQUssS0FBTSxTQUFTLEtBQUssS0FBSyxDQUFDLGtCQUFrQixLQUFLO0FBQy9FO0FBQ0EsU0FBUyxpQkFBaUIsVUFBVTtDQUNoQyxPQUFPLENBQUMsRUFBRSxZQUFZLFFBQVE7QUFDbEM7QUFDQSxTQUFTLHNCQUFzQixPQUFPO0NBQ2xDLE9BQU8sTUFBTSxRQUFRLEtBQUssSUFDcEIsQ0FBQyxNQUFNLE1BQU0sU0FBUyxDQUFDLFlBQVksSUFBSSxDQUFDLElBQ3hDLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDO0FBQzlCO0FBQ0EsU0FBUyxnQkFBZ0IsV0FBVyxLQUFLO0NBQ3JDLElBQUksTUFBTSxRQUFRLFNBQVMsR0FDdkIsVUFBVSxPQUFPLEtBQUE7TUFHakIsT0FBTyxVQUFVO0FBRXpCO0FBQ0EsU0FBUyxnQkFBZ0IsTUFBTSxTQUFTLENBQUMsR0FBRyxXQUFXO0NBQ25ELEtBQUssTUFBTSxPQUFPLE1BQU07RUFDcEIsTUFBTSxRQUFRLEtBQUs7RUFDbkIsTUFBTSxXQUFXLGFBQWEsVUFBVTtFQUN4QyxJQUFJLGNBQWMsS0FBSyxNQUNsQixDQUFDLE1BQU0sUUFBUSxLQUFLLEtBQUssQ0FBQyxpQkFBaUIsUUFBUSxJQUFJO0dBQ3hELE9BQU8sT0FBTyxNQUFNLFFBQVEsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDO0dBQzNDLGdCQUFnQixPQUFPLE9BQU8sTUFBTSxRQUFRO0dBQzVDLElBQUksc0JBQXNCLE9BQU8sSUFBSSxHQUNqQyxnQkFBZ0IsUUFBUSxHQUFHO0VBRW5DLE9BQ0ssSUFBSSxDQUFDLFlBQVksS0FBSyxHQUN2QixPQUFPLE9BQU87Q0FFdEI7Q0FDQSxPQUFPO0FBQ1g7QUFDQSxTQUFTLGVBQWUsTUFBTSxZQUFZLHVCQUF1QixXQUFXO0NBQ3hFLElBQUksQ0FBQyx1QkFDRCx3QkFBd0IsZ0JBQWdCLFlBQVksQ0FBQyxHQUFHLFNBQVM7Q0FFckUsS0FBSyxNQUFNLE9BQU8sTUFBTTtFQUNwQixNQUFNLFFBQVEsS0FBSztFQUNuQixNQUFNLFdBQVcsYUFBYSxVQUFVO0VBQ3hDLElBQUksY0FBYyxLQUFLLE1BQ2xCLENBQUMsTUFBTSxRQUFRLEtBQUssS0FBSyxDQUFDLGlCQUFpQixRQUFRLElBQUk7R0FDeEQsSUFBSSxZQUFZLFVBQVUsS0FBSyxZQUFZLHNCQUFzQixJQUFJLEdBQ2pFLHNCQUFzQixPQUFPLGdCQUFnQixPQUFPLE1BQU0sUUFBUSxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxRQUFRO1FBRzVGLGVBQWUsT0FBTyxrQkFBa0IsVUFBVSxJQUFJLENBQUMsSUFBSSxXQUFXLE1BQU0sc0JBQXNCLE1BQU0sUUFBUTtHQUVwSCxJQUFJLHNCQUFzQixzQkFBc0IsSUFBSSxHQUNoRCxnQkFBZ0IsdUJBQXVCLEdBQUc7RUFFbEQsT0FDSyxJQUFJLFVBQVUsT0FBTyxXQUFXLElBQUksR0FDckMsZ0JBQWdCLHVCQUF1QixHQUFHO09BRzFDLHNCQUFzQixPQUFPO0NBRXJDO0NBQ0EsT0FBTztBQUNYO0FBRUEsSUFBSSxtQkFBbUIsT0FBTyxFQUFFLGVBQWUsYUFBYSxpQkFBaUIsWUFBWSxLQUFLLElBQ3hGLFFBQ0EsZ0JBQ0ksVUFBVSxLQUNOLE1BQ0EsUUFDSSxDQUFDLFFBQ0QsUUFDUixlQUFlLFNBQVMsS0FBSyxJQUN6QixJQUFJLEtBQUssS0FBSyxJQUNkLGFBQ0ksV0FBVyxLQUFLLElBQ2hCO0FBRWxCLFNBQVMsY0FBYyxJQUFJO0NBQ3ZCLE1BQU0sTUFBTSxHQUFHO0NBQ2YsSUFBSSxZQUFZLEdBQUcsR0FDZixPQUFPLElBQUk7Q0FFZixJQUFJLGFBQWEsR0FBRyxHQUNoQixPQUFPLGNBQWMsR0FBRyxJQUFJLENBQUMsQ0FBQztDQUVsQyxJQUFJLGlCQUFpQixHQUFHLEdBQ3BCLE9BQU8sQ0FBQyxHQUFHLElBQUksZUFBZSxDQUFDLENBQUMsS0FBSyxFQUFFLFlBQVksS0FBSztDQUU1RCxJQUFJLGdCQUFnQixHQUFHLEdBQ25CLE9BQU8saUJBQWlCLEdBQUcsSUFBSSxDQUFDLENBQUM7Q0FFckMsT0FBTyxnQkFBZ0IsSUFBSSxPQUFPLEVBQUU7QUFDeEM7QUFFQSxJQUFJLHNCQUFzQixhQUFhLFNBQVMsY0FBYyw4QkFBOEI7Q0FDeEYsTUFBTSxTQUFTLENBQUM7Q0FDaEIsS0FBSyxNQUFNLFFBQVEsYUFBYTtFQUM1QixNQUFNLFFBQVEsSUFBSSxTQUFTLElBQUk7RUFDL0IsU0FBUyxJQUFJLFFBQVEsTUFBTSxNQUFNLEVBQUU7Q0FDdkM7Q0FDQSxPQUFPO0VBQ0g7RUFDQSxPQUFPLENBQUMsR0FBRyxXQUFXO0VBQ3RCO0VBQ0E7Q0FDSjtBQUNKO0FBRUEsSUFBSSxnQkFBZ0IsU0FBUyxZQUFZLElBQUksSUFDdkMsT0FDQSxRQUFRLElBQUksSUFDUixLQUFLLFNBQ0wsU0FBUyxJQUFJLElBQ1QsUUFBUSxLQUFLLEtBQUssSUFDZCxLQUFLLE1BQU0sU0FDWCxLQUFLLFFBQ1Q7QUFFZCxJQUFNLGlCQUFpQjtBQUN2QixJQUFJLHdCQUF3QixtQkFBbUI7Q0FDM0MsSUFBSSxDQUFDLGtCQUFrQixDQUFDLGVBQWUsVUFDbkMsT0FBTztDQUNYLElBQUksV0FBVyxlQUFlLFFBQVEsR0FDbEMsT0FBTyxlQUFlLFNBQVMsWUFBWSxTQUFTO0NBRXhELElBQUksU0FBUyxlQUFlLFFBQVEsR0FDM0I7T0FBQSxNQUFNLE9BQU8sZUFBZSxVQUM3QixJQUFJLGVBQWUsU0FBUyxJQUFJLENBQUMsWUFDNUIsU0FBUyxnQkFDVixPQUFPO0NBQUE7Q0FJbkIsT0FBTztBQUNYO0FBRUEsSUFBSSxpQkFBaUIsWUFBWSxRQUFRLFVBQ3BDLFFBQVEsWUFDTCxRQUFRLE9BQ1IsUUFBUSxPQUNSLFFBQVEsYUFDUixRQUFRLGFBQ1IsUUFBUSxXQUNSLFFBQVE7QUFFaEIsU0FBUyxrQkFBa0IsUUFBUSxTQUFTLE1BQU07Q0FDOUMsTUFBTSxRQUFRLElBQUksUUFBUSxJQUFJO0NBQzlCLElBQUksU0FBUyxNQUFNLElBQUksR0FDbkIsT0FBTztFQUNIO0VBQ0E7Q0FDSjtDQUVKLE1BQU0sUUFBUSxLQUFLLE1BQU0sR0FBRztDQUM1QixPQUFPLE1BQU0sUUFBUTtFQUNqQixNQUFNLFlBQVksTUFBTSxLQUFLLEdBQUc7RUFDaEMsTUFBTSxRQUFRLElBQUksU0FBUyxTQUFTO0VBQ3BDLE1BQU0sYUFBYSxJQUFJLFFBQVEsU0FBUztFQUN4QyxJQUFJLFNBQVMsQ0FBQyxNQUFNLFFBQVEsS0FBSyxLQUFLLFNBQVMsV0FDM0MsT0FBTyxFQUFFLEtBQUs7RUFFbEIsSUFBSSxjQUFjLFdBQVcsTUFDekIsT0FBTztHQUNILE1BQU07R0FDTixPQUFPO0VBQ1g7RUFFSixJQUFJLGNBQWMsV0FBVyxRQUFRLFdBQVcsS0FBSyxNQUNqRCxPQUFPO0dBQ0gsTUFBTSxHQUFHLFVBQVU7R0FDbkIsT0FBTyxXQUFXO0VBQ3RCO0VBRUosTUFBTSxJQUFJO0NBQ2Q7Q0FDQSxPQUFPLEVBQ0gsS0FDSjtBQUNKO0FBRUEsSUFBSSx5QkFBeUIsZUFBZSxpQkFBaUIsaUJBQWlCLFdBQVc7Q0FDckYsZ0JBQWdCLGFBQWE7Q0FDN0IsTUFBTSxPQUFPLE9BQU8sS0FBSyxhQUFhLENBQUMsQ0FBQyxRQUFRLFFBQVEsUUFBUSxNQUFNO0NBQ3RFLE9BQVEsQ0FBQyxLQUFLLFVBQ1QsVUFBVSxLQUFLLFVBQVUsT0FBTyxLQUFLLGVBQWUsQ0FBQyxDQUFDLFVBQ3ZELEtBQUssTUFBTSxRQUFRLGdCQUFnQixVQUM5QixDQUFDLFVBQVUsZ0JBQWdCLElBQUk7QUFDNUM7QUFFQSxJQUFJLHlCQUF5QixNQUFNLFlBQVksVUFBVSxDQUFDLFFBQ3RELENBQUMsY0FDRCxTQUFTLGNBQ1Qsc0JBQXNCLElBQUksQ0FBQyxDQUFDLE1BQU0sZ0JBQWdCLGdCQUM3QyxRQUNLLGdCQUFnQixjQUFjLFlBQVksV0FBVyxhQUFhLEdBQUcsSUFDckUsWUFBWSxXQUFXLFVBQVUsS0FDL0IsV0FBVyxXQUFXLFdBQVcsRUFBRTtBQUVuRCxJQUFJLGtCQUFrQixhQUFhLFdBQVcsYUFBYSxnQkFBZ0IsU0FBUztDQUNoRixJQUFJLEtBQUssU0FDTCxPQUFPO01BRU4sSUFBSSxDQUFDLGVBQWUsS0FBSyxXQUMxQixPQUFPLEVBQUUsYUFBYTtNQUVyQixJQUFJLGNBQWMsZUFBZSxXQUFXLEtBQUssVUFDbEQsT0FBTyxDQUFDO01BRVAsSUFBSSxjQUFjLGVBQWUsYUFBYSxLQUFLLFlBQ3BELE9BQU87Q0FFWCxPQUFPO0FBQ1g7QUFFQSxJQUFJLG1CQUFtQixLQUFLLFNBQVM7Q0FDakMsTUFBTSxRQUFRLElBQUksS0FBSyxJQUFJO0NBQzNCLENBQUMsUUFBUSxLQUFLLENBQUMsQ0FBQyxVQUNaLEVBQUUsVUFBVSxRQUFRLFVBQVUsS0FBSyxLQUFhLE1BQU0sU0FDdEQsTUFBTSxLQUFLLElBQUk7QUFDdkI7QUFFQSxJQUFNLGlCQUFpQjtDQUNuQixNQUFNLGdCQUFnQjtDQUN0QixnQkFBZ0IsZ0JBQWdCO0NBQ2hDLGtCQUFrQjtBQUN0QjtBQUNBLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0scUJBQXFCLGFBQWEsb0JBQW9CO0NBQ3hELEtBQUssTUFBTSxPQUFPLGFBQ2QsSUFBSSxFQUFFLE9BQU8sa0JBQ1QsT0FBTyxZQUFZO0NBRzNCLE9BQU8sT0FBTyxhQUFhLGVBQWU7QUFDOUM7QUFDQSxJQUFNLHFCQUFxQjtDQUN2QixhQUFhO0NBQ2IsU0FBUztDQUNULFNBQVM7Q0FDVCxjQUFjO0NBQ2QsYUFBYTtDQUNiLGNBQWM7Q0FDZCxvQkFBb0I7Q0FDcEIsU0FBUztDQUNULGVBQWUsQ0FBQztDQUNoQixhQUFhLENBQUM7Q0FDZCxrQkFBa0IsQ0FBQztBQUN2QjtBQUNBLFNBQVMsa0JBQWtCLFFBQVEsQ0FBQyxHQUFHO0NBQ25DLElBQUksV0FBVztFQUNYLEdBQUc7RUFDSCxHQUFHO0NBQ1A7Q0FDQSxJQUFJLGFBQWE7RUFDYixHQUFHLFlBQVksa0JBQWtCO0VBQ2pDLFdBQVcsV0FBVyxTQUFTLGFBQWE7RUFDNUMsUUFBUSxTQUFTLFVBQVUsQ0FBQztFQUM1QixVQUFVLFNBQVMsWUFBWTtDQUNuQztDQUNBLElBQUksVUFBVSxDQUFDO0NBQ2YsSUFBSSxpQkFBaUIsU0FBUyxTQUFTLGFBQWEsS0FBSyxTQUFTLFNBQVMsTUFBTSxJQUMzRSxZQUFZLFNBQVMsaUJBQWlCLFNBQVMsTUFBTSxLQUFLLENBQUMsSUFDM0QsQ0FBQztDQUNQLElBQUksY0FBYyxTQUFTLG1CQUNyQixDQUFDLElBQ0QsWUFBWSxjQUFjO0NBQ2hDLElBQUksU0FBUztFQUNULFFBQVE7RUFDUixvQ0FBb0IsSUFBSSxJQUFJO0VBQzVCLE9BQU87RUFDUCxPQUFPO0VBQ1AsYUFBYTtDQUNqQjtDQUNBLElBQUksU0FBUztFQUNULHVCQUFPLElBQUksSUFBSTtFQUNmLDBCQUFVLElBQUksSUFBSTtFQUNsQix5QkFBUyxJQUFJLElBQUk7RUFDakIsdUJBQU8sSUFBSSxJQUFJO0VBQ2YsdUJBQU8sSUFBSSxJQUFJO0VBQ2YsOEJBQWMsSUFBSSxJQUFJO0NBQzFCO0NBQ0EsTUFBTSxzQkFBc0IsQ0FBQztDQUM3QixNQUFNLFNBQVMsQ0FBQztDQUNoQixJQUFJLHlCQUF5QjtDQUM3QixJQUFJLDhCQUE4QixtQkFBbUIsU0FBUyxJQUFJO0NBQ2xFLElBQUksNkJBQTZCLG1CQUFtQixTQUFTLGNBQWM7Q0FDM0UsTUFBTSx3QkFBd0I7RUFDMUIsU0FBUztFQUNULGFBQWE7RUFDYixrQkFBa0I7RUFDbEIsZUFBZTtFQUNmLGNBQWM7RUFDZCxTQUFTO0VBQ1QsUUFBUTtDQUNaO0NBQ0EsTUFBTSxrQkFBa0IsRUFDcEIsR0FBRyxzQkFDUDtDQUNBLElBQUksMkJBQTJCLEVBQzNCLEdBQUcsZ0JBQ1A7Q0FDQSxNQUFNLFlBQVk7RUFDZCxPQUFPLGNBQWM7RUFDckIsT0FBTyxjQUFjO0NBQ3pCO0NBQ0EsSUFBSSxrQkFBa0I7Q0FDdEIsTUFBTSxtQ0FBbUMsU0FBUyxpQkFBaUIsZ0JBQWdCO0NBQ25GLE1BQU0sWUFBWSxNQUFNLGNBQWMsU0FBUztFQUMzQyxhQUFhLE9BQU8sS0FBSztFQUN6QixPQUFPLFFBQVEsV0FBVyxVQUFVLElBQUk7Q0FDNUM7Q0FDQSxNQUFNLFlBQVksT0FBTyxzQkFBc0I7RUFDM0MsSUFBSSxPQUFPLGFBQ1A7RUFFSixJQUFJLENBQUMsU0FBUyxhQUNULGdCQUFnQixXQUNiLHlCQUF5QixXQUN6QixvQkFBb0I7R0FDeEIsTUFBTSxTQUFTLEVBQUU7R0FDakIsSUFBSTtHQUNKLElBQUksU0FBUyxVQUFVO0lBQ25CLFVBQVUsZUFBZSxNQUFNLFdBQVcsRUFBQSxDQUFHLE1BQU07SUFDbkQsV0FBVyxtQkFBbUIsb0JBQW9CO0dBQ3RELE9BRUksVUFBVSxNQUFNLHlCQUF5QjtJQUNyQyxRQUFRO0lBQ1IsZ0JBQWdCO0lBQ2hCLFdBQVcsT0FBTztHQUN0QixDQUFDO0dBRUwsSUFBSSxXQUFXLG1CQUFtQixZQUFZLFdBQVcsU0FDckQsVUFBVSxNQUFNLEtBQUssRUFDakIsUUFDSixDQUFDO0VBRVQ7Q0FDSjtDQUNBLE1BQU0sdUJBQXVCLE9BQU8saUJBQWlCO0VBQ2pELElBQUksQ0FBQyxTQUFTLGFBQ1QsZ0JBQWdCLGdCQUNiLGdCQUFnQixvQkFDaEIseUJBQXlCLGdCQUN6Qix5QkFBeUIsbUJBQW1CO0dBQ2hELENBQUMsU0FBUyxNQUFNLEtBQUssT0FBTyxLQUFLLEVBQUEsQ0FBRyxTQUFTLFNBQVM7SUFDbEQsSUFBSSxNQUNBLGVBQ00sSUFBSSxXQUFXLGtCQUFrQixNQUFNLFlBQVksSUFDbkQsTUFBTSxXQUFXLGtCQUFrQixJQUFJO0dBRXJELENBQUM7R0FDRCxVQUFVLE1BQU0sS0FBSztJQUNqQixrQkFBa0IsV0FBVztJQUM3QixjQUFjLENBQUMsY0FBYyxXQUFXLGdCQUFnQjtHQUM1RCxDQUFDO0VBQ0w7Q0FDSjtDQUNBLE1BQU0sMkJBQTJCO0VBQzdCLFdBQVcsY0FBYyxlQUFlLGdCQUFnQixhQUFhLEtBQUEsR0FBVyxPQUFPO0NBQzNGO0NBQ0EsTUFBTSxrQkFBa0IsTUFBTSxTQUFTLENBQUMsR0FBRyxRQUFRLE1BQU0sa0JBQWtCLE1BQU0sNkJBQTZCLFNBQVM7RUFDbkgsSUFBSSxRQUFRLFVBQVUsQ0FBQyxTQUFTLFVBQVU7R0FDdEMsT0FBTyxTQUFTO0dBQ2hCLElBQUksQ0FBQyxPQUFPLG1CQUFtQixJQUFJLElBQUksR0FBRztJQUN0QyxNQUFNLGtCQUFrQixJQUFJLFNBQVMsSUFBSTtJQUN6QyxPQUFPLG1CQUFtQixJQUFJLE1BQU0sTUFBTSxRQUFRLGVBQWUsSUFBSSxnQkFBZ0IsU0FBUyxDQUFDO0dBQ25HO0dBQ0EsSUFBSSw4QkFBOEIsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJLENBQUMsR0FBRztJQUNqRSxNQUFNLGNBQWMsT0FBTyxJQUFJLFNBQVMsSUFBSSxHQUFHLEtBQUssTUFBTSxLQUFLLElBQUk7SUFDbkUsbUJBQW1CLElBQUksU0FBUyxNQUFNLFdBQVc7R0FDckQ7R0FDQSxJQUFJLDhCQUNBLE1BQU0sUUFBUSxJQUFJLFdBQVcsUUFBUSxJQUFJLENBQUMsR0FBRztJQUM3QyxNQUFNLG1CQUFtQixJQUFJLFdBQVcsUUFBUSxJQUFJO0lBQ3BELE1BQU0sWUFBWSxpQkFBaUI7SUFDbkMsTUFBTSxTQUFTLE9BQU8sa0JBQWtCLEtBQUssTUFBTSxLQUFLLElBQUksS0FBSztJQUNqRSxJQUFJLFdBQ0EsT0FBTyxPQUFPO0lBRWxCLG1CQUFtQixJQUFJLFdBQVcsUUFBUSxNQUFNLE1BQU07SUFDdEQsZ0JBQWdCLFdBQVcsUUFBUSxJQUFJO0dBQzNDO0dBQ0EsS0FBSyxnQkFBZ0IsaUJBQ2pCLHlCQUF5QixrQkFDekIsOEJBQ0EsTUFBTSxRQUFRLElBQUksV0FBVyxlQUFlLElBQUksQ0FBQyxHQUFHO0lBQ3BELE1BQU0sZ0JBQWdCLE9BQU8sSUFBSSxXQUFXLGVBQWUsSUFBSSxHQUFHLEtBQUssTUFBTSxLQUFLLElBQUk7SUFDdEYsbUJBQW1CLElBQUksV0FBVyxlQUFlLE1BQU0sYUFBYTtHQUN4RTtHQUNBLElBQUksZ0JBQWdCLGVBQWUseUJBQXlCLGFBQ3hELG1CQUFtQjtHQUV2QixVQUFVLE1BQU0sS0FBSztJQUNqQjtJQUNBLFNBQVMsVUFBVSxNQUFNLE1BQU07SUFDL0IsYUFBYSxXQUFXO0lBQ3hCLFFBQVEsV0FBVztJQUNuQixTQUFTLFdBQVc7R0FDeEIsQ0FBQztFQUNMLE9BRUksSUFBSSxhQUFhLE1BQU0sTUFBTTtDQUVyQztDQUNBLE1BQU0sZ0JBQWdCLE1BQU0sVUFBVTtFQUNsQyxJQUFJLFdBQVcsUUFBUSxNQUFNLEtBQUs7RUFDbEMsV0FBVyxTQUFTLEVBQUUsR0FBRyxXQUFXLE9BQU87RUFDM0MsVUFBVSxNQUFNLEtBQUssRUFDakIsUUFBUSxXQUFXLE9BQ3ZCLENBQUM7Q0FDTDtDQUNBLE1BQU0sY0FBYyxXQUFXO0VBQzNCLFdBQVcsU0FBUztFQUNwQixVQUFVLE1BQU0sS0FBSztHQUNqQixRQUFRLFdBQVc7R0FDbkIsU0FBUztFQUNiLENBQUM7Q0FDTDtDQUNBLE1BQU0sK0JBQStCLFNBQVM7RUFDMUMsTUFBTSxXQUFXLE1BQU0sSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLGFBQWEsSUFBSTtFQUN6RCxJQUFJLGFBQWE7RUFDakIsSUFBSSxnQkFBZ0I7RUFDcEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsU0FBUyxHQUFHLEtBQUs7R0FDMUMsTUFBTSxNQUFNLFNBQVM7R0FDckIsYUFBYSxrQkFBa0IsVUFBVSxJQUFJLGFBQWEsV0FBVztHQUNyRSxnQkFBZ0Isa0JBQWtCLGFBQWEsSUFDekMsZ0JBQ0EsY0FBYztHQUNwQixJQUFJLGVBQWUsUUFBUSxrQkFBa0IsTUFDekMsT0FBTztFQUVmO0VBQ0EsT0FBTztDQUNYO0NBQ0EsTUFBTSxxQkFBcUIsU0FBUztFQUNoQyxJQUFJLENBQUMsT0FBTyxtQkFBbUIsTUFDM0IsT0FBTztFQUVYLE1BQU0sV0FBVyxNQUFNLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxhQUFhLElBQUk7RUFDekQsSUFBSSxPQUFPO0VBQ1gsSUFBSSxPQUFPO0VBQ1gsSUFBSSxhQUFhO0VBQ2pCLElBQUksdUJBQXVCO0VBQzNCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSztHQUN0QyxJQUFJLGtCQUFrQixJQUFJLEdBQ3RCLE9BQU87R0FFWCxNQUFNLE1BQU0sU0FBUztHQUNyQixPQUFPLE9BQU8sR0FBRyxLQUFLLEdBQUcsUUFBUTtHQUNqQyxJQUFJLE1BQU0sUUFBUSxJQUFJLEtBQUssQ0FBQyxPQUFPLEtBQUssUUFDcEMsT0FBTyxlQUFlLEtBQ2hCLFFBQ0EsTUFBTSxhQUNGLENBQUMsTUFBTSx1QkFDUDtHQUVkLElBQUksT0FBTyxtQkFBbUIsSUFBSSxJQUFJLEdBQUc7SUFDckMsYUFBYSxJQUFJO0lBQ2pCLHVCQUF1QixPQUFPLG1CQUFtQixJQUFJLElBQUk7R0FDN0Q7R0FDQSxPQUFPLEtBQUs7RUFDaEI7RUFDQSxPQUFPO0NBQ1g7Q0FDQSxNQUFNLHVCQUF1QixNQUFNLHNCQUFzQixPQUFPLFFBQVE7RUFDcEUsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJO0VBQy9CLElBQUksT0FBTztHQUNQLElBQUksNEJBQTRCLElBQUksS0FBSyxrQkFBa0IsSUFBSSxHQUMzRDtHQUVKLE1BQU0sdUJBQXVCLFlBQVksSUFBSSxhQUFhLElBQUksQ0FBQztHQUMvRCxNQUFNLGVBQWUsSUFBSSxhQUFhLE1BQU0sWUFBWSxLQUFLLElBQUksSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLEtBQUs7R0FDbEcsWUFBWSxZQUFZLEtBQ25CLE9BQU8sSUFBSSxrQkFDWix1QkFDRSxJQUFJLGFBQWEsTUFBTSx1QkFBdUIsZUFBZSxjQUFjLE1BQU0sRUFBRSxDQUFDLElBQ3BGLGNBQWMsTUFBTSxZQUFZO0dBQ3RDLElBQUksT0FBTyxTQUFTLENBQUMsT0FBTyxRQUFRO0lBQ2hDLFVBQVU7SUFDVixJQUFJLHdCQUNBLFdBQVcsWUFDVixnQkFBZ0IsV0FBVyx5QkFBeUIsVUFFakQ7U0FBQSxDQURZLFVBQ0wsR0FBRztNQUNWLFdBQVcsVUFBVTtNQUNyQixVQUFVLE1BQU0sS0FBSyxFQUFFLEdBQUcsV0FBVyxDQUFDO0tBQzFDOztJQUVKLElBQUksTUFBTSxvQkFDTix3QkFDQSxDQUFDLFlBQVksSUFBSSxhQUFhLElBQUksQ0FBQyxLQUNuQyxVQUFVLE1BQU0sTUFBTSxHQUN0QixPQUFPLFFBQVE7R0FFdkI7RUFDSjtDQUNKO0NBQ0EsTUFBTSx1QkFBdUIsTUFBTSxZQUFZLGFBQWEsYUFBYSxpQkFBaUI7RUFDdEYsSUFBSSxvQkFBb0I7RUFDeEIsSUFBSSxrQkFBa0I7RUFDdEIsTUFBTSxTQUFTLEVBQ1gsS0FDSjtFQUdBLElBQUksQ0FBQyxTQUFTLFlBQVksZ0JBQWdCLE1BQU07R0FDNUMsSUFBSSxDQUFDLGVBQWUsYUFBYTtJQUM3QixNQUFNLHlCQUF5QixVQUFVLElBQUksZ0JBQWdCLElBQUksR0FBRyxVQUFVO0lBQzlFLElBQUksZ0JBQWdCLFdBQVcseUJBQXlCLFNBQVM7S0FDN0Qsa0JBQWtCLFdBQVc7S0FDN0IsV0FBVyxVQUFVLE9BQU8sVUFDeEIsQ0FBQywwQkFBMEIsVUFBVTtLQUN6QyxvQkFBb0Isb0JBQW9CLE9BQU87SUFDbkQ7SUFDQSxrQkFBa0IsQ0FBQyxDQUFDLElBQUksV0FBVyxhQUFhLElBQUk7SUFDcEQsSUFBSSwyQkFBMkIsV0FBVyxTQUN0QyxrQkFBa0IsV0FBVyxhQUFhLGVBQWUsZ0JBQWdCLGFBQWEsS0FBQSxHQUFXLE9BQU8sQ0FBQztTQUd6Ryx5QkFDTSxNQUFNLFdBQVcsYUFBYSxJQUFJLElBQ2xDLElBQUksV0FBVyxhQUFhLE1BQU0sSUFBSTtJQUVoRCxPQUFPLGNBQWMsV0FBVztJQUNoQyxvQkFDSSxzQkFDTSxnQkFBZ0IsZUFDZCx5QkFBeUIsZ0JBQ3pCLG9CQUFvQixDQUFDO0dBQ3JDO0dBQ0EsSUFBSSxhQUFhO0lBQ2IsTUFBTSx5QkFBeUIsSUFBSSxXQUFXLGVBQWUsSUFBSTtJQUNqRSxJQUFJLENBQUMsd0JBQXdCO0tBQ3pCLElBQUksV0FBVyxlQUFlLE1BQU0sV0FBVztLQUMvQyxPQUFPLGdCQUFnQixXQUFXO0tBQ2xDLG9CQUNJLHNCQUNNLGdCQUFnQixpQkFDZCx5QkFBeUIsa0JBQ3pCLDJCQUEyQjtJQUMzQztHQUNKO0dBQ0EscUJBQXFCLGdCQUFnQixVQUFVLE1BQU0sS0FBSyxNQUFNO0VBQ3BFO0VBQ0EsT0FBTyxvQkFBb0IsU0FBUyxDQUFDO0NBQ3pDO0NBQ0EsTUFBTSx1QkFBdUIsTUFBTSxTQUFTLE9BQU8sZUFBZTtFQUM5RCxNQUFNLHFCQUFxQixJQUFJLFdBQVcsUUFBUSxJQUFJO0VBQ3RELE1BQU0scUJBQXFCLGdCQUFnQixXQUFXLHlCQUF5QixZQUMzRSxVQUFVLE9BQU8sS0FDakIsV0FBVyxZQUFZO0VBQzNCLElBQUksU0FBUyxjQUFjLE9BQU87R0FDOUIsb0JBQW9CLFFBQVEsU0FBUyxZQUFZLGFBQWEsTUFBTSxLQUFLLENBQUM7R0FDMUUsb0JBQW9CLEtBQUssQ0FBQyxTQUFTLFVBQVU7RUFDakQsT0FDSztHQUNELGFBQWEsT0FBTyxLQUFLO0dBQ3pCLE9BQU8sb0JBQW9CO0dBQzNCLFFBQ00sSUFBSSxXQUFXLFFBQVEsTUFBTSxLQUFLLElBQ2xDLE1BQU0sV0FBVyxRQUFRLElBQUk7R0FDbkMsV0FBVyxTQUFTLEVBQUUsR0FBRyxXQUFXLE9BQU87RUFDL0M7RUFDQSxLQUFLLFFBQVEsQ0FBQyxVQUFVLG9CQUFvQixLQUFLLElBQUksdUJBQ2pELENBQUMsY0FBYyxVQUFVLEtBQ3pCLG1CQUFtQjtHQUNuQixNQUFNLG1CQUFtQjtJQUNyQixHQUFHO0lBQ0gsR0FBSSxxQkFBcUIsVUFBVSxPQUFPLElBQUksRUFBRSxRQUFRLElBQUksQ0FBQztJQUM3RCxRQUFRLFdBQVc7SUFDbkI7R0FDSjtHQUNBLGFBQWE7SUFDVCxHQUFHO0lBQ0gsR0FBRztHQUNQO0dBQ0EsVUFBVSxNQUFNLEtBQUssZ0JBQWdCO0VBQ3pDO0NBQ0o7Q0FDQSxNQUFNLGFBQWEsT0FBTyxTQUFTO0VBQy9CLG9CQUFvQixNQUFNLElBQUk7RUFDOUIsT0FBTyxNQUFNLFNBQVMsU0FBUyxhQUFhLFNBQVMsU0FBUyxtQkFBbUIsUUFBUSxPQUFPLE9BQU8sU0FBUyxTQUFTLGNBQWMsU0FBUyx5QkFBeUIsQ0FBQztDQUM5SztDQUNBLE1BQU0sOEJBQThCLE9BQU8sVUFBVTtFQUNqRCxNQUFNLEVBQUUsV0FBVyxNQUFNLFdBQVcsS0FBSztFQUN6QyxvQkFBb0IsS0FBSztFQUN6QixJQUFJLE9BQU87R0FDUCxLQUFLLE1BQU0sUUFBUSxPQUFPO0lBQ3RCLE1BQU0sUUFBUSxJQUFJLFFBQVEsSUFBSTtJQUM5QixRQUNNLE9BQU8sTUFBTSxJQUFJLElBQUksS0FDbkIsU0FBUyxLQUFLLEtBQ2QsQ0FBQyxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsTUFBTSxRQUFRLENBQUMsT0FBTyxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsSUFDMUQsMEJBQTBCLFdBQVcsUUFBUSxHQUFHLE9BQU8sTUFBTSxHQUFHLElBQUksSUFDcEUsSUFBSSxXQUFXLFFBQVEsTUFBTSxLQUFLLElBQ3RDLE1BQU0sV0FBVyxRQUFRLElBQUk7R0FDdkM7R0FDQSxXQUFXLFNBQVMsRUFBRSxHQUFHLFdBQVcsT0FBTztFQUMvQyxPQUVJLFdBQVcsU0FBUztFQUV4QixPQUFPO0NBQ1g7Q0FDQSxNQUFNLGVBQWUsT0FBTyxFQUFFLE1BQU0sZ0JBQWlCO0VBQ2pELElBQUksTUFBTSxVQUFVO0dBQ2hCLE1BQU0sU0FBUyxNQUFNLE1BQU0sU0FBUztJQUNoQyxZQUFZO0lBQ1osV0FBVztJQUNYO0lBQ0E7R0FDSixDQUFDO0dBQ0QsSUFBSSxTQUFTLE1BQU0sR0FDZixLQUFLLE1BQU0sT0FBTyxRQUFRO0lBQ3RCLE1BQU0sUUFBUSxPQUFPO0lBQ3JCLElBQUksT0FDQSxTQUFTLEdBQUcsZ0JBQWdCLEdBQUcsT0FBTztLQUNsQyxTQUFTLFNBQVMsTUFBTSxPQUFPLElBQUksTUFBTSxVQUFVO0tBQ25ELE1BQU0sTUFBTSxRQUFRLHVCQUF1QjtJQUMvQyxDQUFDO0dBRVQ7UUFFQyxJQUFJLFNBQVMsTUFBTSxLQUFLLENBQUMsUUFDMUIsU0FBUyxpQkFBaUI7SUFDdEIsU0FBUyxVQUFVO0lBQ25CLE1BQU0sdUJBQXVCO0dBQ2pDLENBQUM7UUFHRCxZQUFZLGVBQWU7R0FFL0IsT0FBTztFQUNYO0VBQ0EsT0FBTztDQUNYO0NBQ0EsTUFBTSwyQkFBMkIsT0FBTyxFQUFFLFFBQVEsZ0JBQWdCLE1BQU0sV0FBVyxVQUFVO0VBQ3pGLE9BQU87RUFDUCxtQkFBbUI7Q0FDdkIsUUFBUztFQUNMLElBQUksTUFBTSxVQUFVO0dBQ2hCLFFBQVEsb0JBQW9CO0dBSzVCLElBQUksQ0FBQyxNQUpnQixhQUFhO0lBQzlCO0lBQ0E7R0FDSixDQUFDLEdBQ1k7SUFDVCxRQUFRLFFBQVE7SUFDaEIsSUFBSSxnQkFDQSxPQUFPLFFBQVE7R0FFdkI7RUFDSjtFQUNBLEtBQUssTUFBTSxRQUFRLFFBQVE7R0FDdkIsTUFBTSxRQUFRLE9BQU87R0FDckIsSUFBSSxPQUFPO0lBQ1AsTUFBTSxFQUFFLElBQUksR0FBRyxlQUFlO0lBQzlCLElBQUksSUFBSTtLQUNKLE1BQU0sbUJBQW1CLE9BQU8sTUFBTSxJQUFJLEdBQUcsSUFBSTtLQUNqRCxNQUFNLG9CQUFvQixNQUFNLE1BQU0scUJBQXFCLE1BQU0sRUFBRTtLQUNuRSxNQUFNLCtCQUErQixnQkFBZ0Isb0JBQ2pELGdCQUFnQixnQkFDaEIseUJBQXlCLG9CQUN6Qix5QkFBeUI7S0FDN0IsSUFBSSxxQkFBcUIsOEJBQ3JCLG9CQUFvQixDQUFDLEdBQUcsSUFBSSxHQUFHLElBQUk7S0FFdkMsTUFBTSxhQUFhLE1BQU0sY0FBYyxPQUFPLE9BQU8sVUFBVSxhQUFhLGtDQUFrQyxTQUFTLDZCQUE2QixDQUFDLGdCQUFnQixnQkFBZ0I7S0FDckwsSUFBSSxxQkFBcUIsOEJBQ3JCLG9CQUFvQixDQUFDLEdBQUcsSUFBSSxDQUFDO0tBRWpDLElBQUksV0FBVyxHQUFHLE9BQU87TUFDckIsUUFBUSxRQUFRO01BQ2hCLElBQUksZ0JBQ0E7S0FFUjtLQUNBLENBQUMsbUJBQ0ksSUFBSSxZQUFZLEdBQUcsSUFBSSxJQUNsQixtQkFDSSwwQkFBMEIsV0FBVyxRQUFRLFlBQVksR0FBRyxJQUFJLElBQ2hFLElBQUksV0FBVyxRQUFRLEdBQUcsTUFBTSxXQUFXLEdBQUcsS0FBSyxJQUN2RCxNQUFNLFdBQVcsUUFBUSxHQUFHLElBQUk7S0FDMUMsSUFBSSxNQUFNLDZCQUE2QixXQUFXLEdBQUcsT0FDakQ7SUFFUjtJQUNBLENBQUMsY0FBYyxVQUFVLEtBQ3BCLE1BQU0seUJBQXlCO0tBQzVCO0tBQ0E7S0FDQSxRQUFRO0tBQ0Y7S0FDTjtJQUNKLENBQUM7R0FDVDtFQUNKO0VBQ0EsT0FBTyxRQUFRO0NBQ25CO0NBQ0EsTUFBTSx5QkFBeUI7RUFDM0IsS0FBSyxNQUFNLFFBQVEsT0FBTyxTQUFTO0dBQy9CLE1BQU0sUUFBUSxJQUFJLFNBQVMsSUFBSTtHQUMvQixVQUNLLE1BQU0sR0FBRyxPQUNKLE1BQU0sR0FBRyxLQUFLLE9BQU8sUUFBUSxDQUFDLEtBQUssR0FBRyxDQUFDLElBQ3ZDLENBQUMsS0FBSyxNQUFNLEdBQUcsR0FBRyxNQUN4QixXQUFXLElBQUk7RUFDdkI7RUFDQSxPQUFPLDBCQUFVLElBQUksSUFBSTtDQUM3QjtDQUNBLE1BQU0sYUFBYSxNQUFNLFVBQVUsUUFBUSxRQUFRLElBQUksYUFBYSxNQUFNLElBQUksR0FDMUUsQ0FBQyxVQUFVLE9BQU8sUUFBUSxjQUFjLGdCQUFnQixjQUFjO0NBQzFFLE1BQU0sYUFBYSxPQUFPLGNBQWMsYUFBYSxvQkFBb0IsT0FBTyxRQUFRLEVBQ3BGLEdBQUksT0FBTyxRQUNMLGNBQ0EsWUFBWSxZQUFZLEtBQUssU0FBUyxLQUFLLElBQ3ZDLGlCQUNBLGFBQ2QsR0FBRyxVQUFVLFlBQVk7Q0FDekIsTUFBTSxrQkFBa0IsU0FBUyxRQUFRLElBQUksT0FBTyxRQUFRLGNBQWMsZ0JBQWdCLE1BQU0sU0FBUyxtQkFBbUIsSUFBSSxnQkFBZ0IsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztDQUMvSixNQUFNLGlCQUFpQixNQUFNLE9BQU8sVUFBVSxDQUFDLEdBQUcsWUFBWSxPQUFPLGFBQWEsT0FBTyxrQkFBa0IsVUFBVTtFQUNqSCxNQUFNLFFBQVEsSUFBSSxTQUFTLElBQUk7RUFDL0IsSUFBSSxhQUFhO0VBQ2pCLElBQUksT0FBTztHQUNQLE1BQU0saUJBQWlCLE1BQU07R0FDN0IsSUFBSSxnQkFBZ0I7SUFDaEIsQ0FBQyxlQUFlLFlBQ1osSUFBSSxhQUFhLE1BQU0sZ0JBQWdCLE9BQU8sY0FBYyxDQUFDO0lBQ2pFLGFBQ0ksY0FBYyxlQUFlLEdBQUcsS0FBSyxrQkFBa0IsS0FBSyxJQUN0RCxLQUNBO0lBQ1YsSUFBSSxpQkFBaUIsZUFBZSxHQUFHLEdBQ25DLENBQUMsR0FBRyxlQUFlLElBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxjQUFlLFVBQVUsV0FBVyxXQUFXLFNBQVMsVUFBVSxLQUFLLENBQUU7U0FFakgsSUFBSSxlQUFlLE1BQU07S0FDMUIsSUFBSSxnQkFBZ0IsZUFBZSxHQUFHLEdBQ2xDLGVBQWUsS0FBSyxTQUFTLGdCQUFnQjtNQUN6QyxJQUFJLENBQUMsWUFBWSxrQkFBa0IsQ0FBQyxZQUFZLFVBQVU7T0FDdEQsSUFBSSxNQUFNLFFBQVEsVUFBVSxHQUN4QixZQUFZLFVBQVUsQ0FBQyxDQUFDLFdBQVcsTUFBTSxTQUFTLFNBQVMsWUFBWSxLQUFLO1lBRzVFLFlBQVksVUFDUixlQUFlLFlBQVksU0FBUyxDQUFDLENBQUM7TUFFbEQ7S0FDSixDQUFDO1VBR0QsZUFBZSxLQUFLLFNBQVMsYUFBYyxTQUFTLFVBQVUsU0FBUyxVQUFVLFVBQVc7SUFFcEcsT0FDSyxJQUFJLFlBQVksZUFBZSxHQUFHLEdBQ25DLGVBQWUsSUFBSSxRQUFRO1NBRTFCO0tBQ0QsZUFBZSxJQUFJLFFBQVE7S0FDM0IsSUFBSSxDQUFDLGVBQWUsSUFBSSxRQUFRLENBQUMsY0FBYyxDQUFDLGlCQUM1QyxVQUFVLE1BQU0sS0FBSztNQUNqQjtNQUNBLFFBQVEsWUFBWSxjQUFjLFlBQVksV0FBVztLQUM3RCxDQUFDO0lBRVQ7R0FDSjtFQUNKO0VBQ0EsQ0FBQyxRQUFRLGVBQWUsUUFBUSxnQkFDNUIsb0JBQW9CLE1BQU0sWUFBWSxRQUFRLGFBQWEsUUFBUSxhQUFhLENBQUMsVUFBVTtFQUMvRixRQUFRLGtCQUNKLFFBQVEsTUFBTSxFQUNWLFlBQVksUUFBUSxXQUN4QixDQUFDO0NBQ1Q7Q0FDQSxNQUFNLGtCQUFrQixNQUFNLE9BQU8sU0FBUyxZQUFZLE9BQU8sYUFBYSxPQUFPLGtCQUFrQixVQUFVO0VBQzdHLElBQUksT0FBTyxNQUFNLElBQUksSUFBSSxHQUNyQixVQUFVLE1BQU0sS0FBSztHQUNqQjtHQUNBLFFBQVEsWUFBWSxjQUFjLFlBQVksV0FBVztFQUM3RCxDQUFDO0VBRUwsS0FBSyxNQUFNLFlBQVksT0FBTztHQUMxQixJQUFJLENBQUMsTUFBTSxlQUFlLFFBQVEsR0FDOUI7R0FFSixNQUFNLGFBQWEsTUFBTTtHQUN6QixNQUFNLFlBQVksT0FBTyxNQUFNO0dBQy9CLE1BQU0sUUFBUSxJQUFJLFNBQVMsU0FBUztHQUNwQyxDQUFDLE9BQU8sTUFBTSxJQUFJLElBQUksS0FDbEIsU0FBUyxVQUFVLEtBQ2xCLFNBQVMsQ0FBQyxNQUFNLE9BQ2pCLENBQUMsYUFBYSxVQUFVLElBQ3RCLGVBQWUsV0FBVyxZQUFZLFNBQVMsV0FBVyxZQUFZLGVBQWUsSUFDckYsY0FBYyxXQUFXLFlBQVksU0FBUyxXQUFXLFlBQVksZUFBZTtFQUM5RjtDQUNKO0NBQ0EsTUFBTSxhQUFhLE1BQU0sT0FBTyxTQUFTLFdBQVcsZ0JBQWdCLFVBQVU7RUFDMUUsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJO0VBQy9CLE1BQU0sZUFBZSxPQUFPLE1BQU0sSUFBSSxJQUFJO0VBQzFDLE1BQU0sYUFBYSxZQUFZLFFBQVEsWUFBWSxLQUFLO0VBRXhELE1BQU0sbUJBQW1CLFVBREgsSUFBSSxhQUFhLElBQ1EsR0FBRyxVQUFVO0VBQzVELElBQUksQ0FBQyxrQkFDRCxJQUFJLGFBQWEsTUFBTSxVQUFVO0VBRXJDLElBQUksY0FBYztHQUNkLFVBQVUsTUFBTSxLQUFLO0lBQ2pCO0lBQ0EsUUFBUSxZQUFZLGNBQWMsWUFBWSxXQUFXO0dBQzdELENBQUM7R0FDRCxLQUFLLGdCQUFnQixXQUNqQixnQkFBZ0IsZUFDaEIseUJBQXlCLFdBQ3pCLHlCQUF5QixnQkFDekIsUUFBUSxhQUFhO0lBQ3JCLG1CQUFtQjtJQUNuQixJQUFJLENBQUMsZUFDRCxVQUFVLE1BQU0sS0FBSztLQUNqQjtLQUNBLGFBQWEsV0FBVztLQUN4QixTQUFTLFVBQVUsTUFBTSxVQUFVO0lBQ3ZDLENBQUM7R0FFVDtFQUNKLE9BQ0s7R0FDRCxNQUFNLFVBQVcsTUFBTSxRQUFRLFVBQVUsS0FBSyxDQUFDLFdBQVcsVUFDdEQsY0FBYyxVQUFVO0dBQzVCLE1BQU0sa0JBQWtCLENBQUMsb0JBQW9CLENBQUM7R0FDOUMsSUFBSSxDQUFDLFNBQVMsTUFBTSxNQUFNLGtCQUFrQixVQUFVLEtBQUssU0FDdkQsY0FBYyxNQUFNLFlBQVksU0FBUyxXQUFXLGVBQWUsZUFBZTtRQUdsRixlQUFlLE1BQU0sWUFBWSxTQUFTLFdBQVcsZUFBZSxlQUFlO0VBRTNGO0VBQ0EsSUFBSSxDQUFDLG9CQUFvQixDQUFDLGVBQWU7R0FDckMsTUFBTSxVQUFVLFVBQVUsTUFBTSxNQUFNO0dBQ3RDLE1BQU0sU0FBUyxZQUFZLGNBQWMsWUFBWSxXQUFXO0dBQ2hFLFVBQVUsTUFBTSxLQUFLO0lBQ2pCLEdBQUksV0FBVztJQUNmLE1BQU0sT0FBTyxTQUFTLFVBQVUsT0FBTyxLQUFBO0lBQ3ZDO0dBQ0osQ0FBQztFQUNMO0NBQ0o7Q0FDQSxNQUFNLFlBQVksTUFBTSxPQUFPLFVBQVUsQ0FBQyxNQUFNLFVBQVUsTUFBTSxPQUFPLFNBQVMsS0FBSztDQUNyRixNQUFNLGFBQWEsWUFBWSxVQUFVLENBQUMsTUFBTTtFQUM1QyxNQUFNLG9CQUFvQixXQUFXLFVBQVUsSUFDekMsV0FBVyxXQUFXLElBQ3RCO0VBQ04sSUFBSSxDQUFDLFVBQVUsYUFBYSxpQkFBaUIsR0FBRztHQUM1QyxjQUFjO0lBQ1YsR0FBRztJQUNILEdBQUc7R0FDUDtHQUNBLE1BQU0sbUJBQW1CLFFBQVEsaUJBQWlCO0dBQ2xELEtBQUssTUFBTSxhQUFhLE9BQU8sT0FDM0IsSUFBSSxhQUFhLGtCQUNiLFVBQVUsV0FBVyxpQkFBaUIsWUFBWSxTQUFTLE1BQU0sSUFBSTtHQUc3RSxVQUFVLE1BQU0sS0FBSztJQUNqQixHQUFHO0lBQ0gsTUFBTSxLQUFBO0lBQ04sTUFBTSxLQUFBO0lBQ04sR0FBSSx5QkFBeUIsRUFBRSxRQUFRLFlBQVksSUFBSSxDQUFDO0dBQzVELENBQUM7R0FDRCxJQUFJLFFBQVEsZ0JBQ1IsVUFBVTtFQUVsQjtDQUNKO0NBQ0EsTUFBTSxXQUFXLE9BQU8sVUFBVTtFQUM5QixPQUFPLFFBQVE7RUFDZixNQUFNLFNBQVMsTUFBTTtFQUNyQixJQUFJLE9BQU8sT0FBTztFQUNsQixJQUFJLHNCQUFzQjtFQUMxQixNQUFNLFFBQVEsSUFBSSxTQUFTLElBQUk7RUFDL0IsTUFBTSw4QkFBOEIsZUFBZTtHQUMvQyxzQkFDSSxPQUFPLE1BQU0sVUFBVSxLQUNsQixhQUFhLFVBQVUsS0FBSyxNQUFNLFdBQVcsUUFBUSxDQUFDLEtBQ3ZELFVBQVUsWUFBWSxJQUFJLGFBQWEsTUFBTSxVQUFVLENBQUM7RUFDcEU7RUFDQSxJQUFJLE9BQU87R0FDUCxJQUFJO0dBQ0osSUFBSTtHQUNKLE1BQU0sYUFBYSxPQUFPLE9BQ3BCLGNBQWMsTUFBTSxFQUFFLElBQ3RCLGNBQWMsS0FBSztHQUN6QixNQUFNLGNBQWMsTUFBTSxTQUFTLE9BQU8sUUFBUSxNQUFNLFNBQVMsT0FBTztHQUN4RSxNQUFNLHdCQUF3QixDQUFDLGNBQWMsTUFBTSxFQUFFLEtBQ2pELENBQUMsTUFBTSxZQUNQLENBQUMsU0FBUyxZQUNWLENBQUMsSUFBSSxXQUFXLFFBQVEsSUFBSSxLQUM1QixDQUFDLE1BQU0sR0FBRztHQUNkLE1BQU0sdUJBQXVCLHlCQUN6QixlQUFlLGFBQWEsSUFBSSxXQUFXLGVBQWUsSUFBSSxHQUFHLFdBQVcsYUFBYSw0QkFBNEIsMkJBQTJCO0dBQ3BKLE1BQU0sVUFBVSxVQUFVLE1BQU0sUUFBUSxXQUFXO0dBQ25ELElBQUksYUFBYSxNQUFNLFVBQVU7R0FDakMsSUFBSSxhQUNJO1FBQUEsQ0FBQyxVQUFVLENBQUMsT0FBTyxVQUFVO0tBQzdCLE1BQU0sR0FBRyxVQUFVLE1BQU0sR0FBRyxPQUFPLEtBQUs7S0FDeEMsTUFBTSxvQkFBb0Isb0JBQW9CO0tBQzlDLHFCQUFxQixrQkFBa0IsQ0FBQztJQUM1QztVQUVDLElBQUksTUFBTSxHQUFHLFVBQ2QsTUFBTSxHQUFHLFNBQVMsS0FBSztHQUUzQixNQUFNLGFBQWEsb0JBQW9CLE1BQU0sWUFBWSxXQUFXO0dBQ3BFLE1BQU0sZUFBZSxDQUFDLGNBQWMsVUFBVSxLQUFLO0dBQ25ELENBQUMsZUFDRyxVQUFVLE1BQU0sS0FBSztJQUNqQjtJQUNBLE1BQU0sTUFBTTtJQUNaLEdBQUkseUJBQ0UsRUFBRSxRQUFRLFlBQVksV0FBVyxFQUFFLElBQ25DLENBQUM7R0FDWCxDQUFDO0dBQ0wsSUFBSSxzQkFBc0I7SUFDdEIsS0FBSyxDQUFDLHlCQUF5QixDQUFDLFdBQVcsYUFDdEMsZ0JBQWdCLFdBQVcseUJBQXlCLFVBQVU7S0FDL0QsSUFBSSxTQUFTLFNBQVMsVUFDZDtVQUFBLGFBQ0EsVUFBVTtLQUFBLE9BR2IsSUFBSSxDQUFDLGFBQ04sVUFBVTtJQUVsQjtJQUNBLE9BQVEsZ0JBQ0osVUFBVSxNQUFNLEtBQUs7S0FBRTtLQUFNLEdBQUksVUFBVSxDQUFDLElBQUk7SUFBWSxDQUFDO0dBQ3JFO0dBQ0EsSUFBSSxDQUFDLFNBQVMsWUFBWSxNQUFNLFVBQzVCLE1BQU0sYUFBYTtJQUNUO0lBQ04sV0FBVyxNQUFNO0dBQ3JCLENBQUM7R0FFTCxDQUFDLGVBQWUsV0FBVyxVQUFVLE1BQU0sS0FBSyxFQUFFLEdBQUcsV0FBVyxDQUFDO0dBQ2pFLElBQUksU0FBUyxVQUFVO0lBQ25CLE1BQU0sRUFBRSxXQUFXLE1BQU0sV0FBVyxDQUFDLElBQUksQ0FBQztJQUMxQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUM7SUFDMUIsMkJBQTJCLFVBQVU7SUFDckMsSUFBSSxDQUFDLHFCQUFxQjtLQUN0QixDQUFDLGNBQWMsVUFBVSxLQUFLLFVBQVUsTUFBTSxLQUFLLFVBQVU7S0FDN0Q7SUFDSjtJQUNBLE1BQU0sNEJBQTRCLGtCQUFrQixXQUFXLFFBQVEsU0FBUyxJQUFJO0lBQ3BGLE1BQU0sb0JBQW9CLGtCQUFrQixRQUFRLFNBQVMsMEJBQTBCLFFBQVEsSUFBSTtJQUNuRyxRQUFRLGtCQUFrQjtJQUMxQixPQUFPLGtCQUFrQjtJQUN6QixVQUFVLGNBQWMsTUFBTTtHQUNsQyxPQUNLO0lBQ0Qsb0JBQW9CLENBQUMsSUFBSSxHQUFHLElBQUk7SUFDaEMsU0FBUyxNQUFNLGNBQWMsT0FBTyxPQUFPLFVBQVUsYUFBYSxrQ0FBa0MsU0FBUyx5QkFBeUIsRUFBQSxDQUFHO0lBQ3pJLG9CQUFvQixDQUFDLElBQUksQ0FBQztJQUMxQiwyQkFBMkIsVUFBVTtJQUNyQyxJQUFJLHFCQUFxQjtLQUNyQixJQUFJLE9BQ0EsVUFBVTtVQUVULElBQUksZ0JBQWdCLFdBQ3JCLHlCQUF5QixTQUN6QixVQUFVLE1BQU0seUJBQXlCO01BQ3JDLFFBQVE7TUFDUixnQkFBZ0I7TUFDVjtNQUNOLFdBQVcsTUFBTTtLQUNyQixDQUFDO0lBRVQ7R0FDSjtHQUNBLElBQUkscUJBQXFCO0lBQ3JCLE1BQU0sR0FBRyxTQUNKLENBQUMsTUFBTSxRQUFRLE1BQU0sR0FBRyxJQUFJLEtBQUssTUFBTSxHQUFHLEtBQUssU0FBUyxNQUN6RCxRQUFRLE1BQU0sR0FBRyxJQUFJO0lBQ3pCLG9CQUFvQixNQUFNLFNBQVMsT0FBTyxVQUFVO0dBQ3hEO0VBQ0o7Q0FDSjtDQUNBLE1BQU0sZUFBZSxLQUFLLFFBQVE7RUFDOUIsSUFBSSxJQUFJLFdBQVcsUUFBUSxHQUFHLEtBQUssSUFBSSxPQUFPO0dBQzFDLElBQUksTUFBTTtHQUNWLE9BQU87RUFDWDtDQUVKO0NBQ0EsTUFBTSxVQUFVLE9BQU8sTUFBTSxVQUFVLENBQUMsTUFBTTtFQUMxQyxJQUFJO0VBQ0osSUFBSTtFQUNKLE1BQU0sYUFBYSxzQkFBc0IsSUFBSTtFQUM3QyxJQUFJLFNBQVMsVUFBVTtHQUNuQixNQUFNLFNBQVMsTUFBTSw0QkFBNEIsWUFBWSxJQUFJLElBQUksT0FBTyxVQUFVO0dBQ3RGLFVBQVUsY0FBYyxNQUFNO0dBQzlCLG1CQUFtQixPQUNiLENBQUMsV0FBVyxNQUFNLFNBQVMsSUFBSSxRQUFRLElBQUksQ0FBQyxJQUM1QztFQUNWLE9BQ0ssSUFBSSxNQUFNO0dBQ1gsb0JBQW9CLE1BQU0sUUFBUSxJQUFJLFdBQVcsSUFBSSxPQUFPLGNBQWM7SUFDdEUsTUFBTSxRQUFRLElBQUksU0FBUyxTQUFTO0lBQ3BDLE9BQU8sTUFBTSx5QkFBeUI7S0FDbEMsUUFBUSxTQUFTLE1BQU0sS0FBSyxHQUFHLFlBQVksTUFBTSxJQUFJO0tBQ3JELFdBQVcsT0FBTztJQUN0QixDQUFDO0dBQ0wsQ0FBQyxDQUFDLEVBQUEsQ0FBRyxNQUFNLE9BQU87R0FDbEIsRUFBRSxDQUFDLG9CQUFvQixDQUFDLFdBQVcsWUFBWSxVQUFVO0VBQzdELE9BRUksbUJBQW1CLFVBQVUsTUFBTSx5QkFBeUI7R0FDeEQsUUFBUTtHQUNSO0dBQ0EsV0FBVyxPQUFPO0VBQ3RCLENBQUM7RUFFTCxJQUFJLFFBQVEsY0FBYyxTQUFTLGNBQWMsU0FBUyxJQUFJLEdBQUc7R0FDN0QsTUFBTSxRQUFRLElBQUksV0FBVyxRQUFRLElBQUk7R0FDekMsSUFBSSxPQUFPO0lBQ1AsTUFBTSxXQUFXLFFBQVEsSUFBSTtJQUM3QixvQkFBb0IsUUFBUSxTQUFTLFlBQVksYUFBYSxNQUFNLEtBQUssQ0FBQztJQUMxRSxvQkFBb0IsS0FBSyxDQUFDLFNBQVMsVUFBVTtHQUNqRCxPQUNLO0lBQ0QsYUFBYSxPQUFPLEtBQUs7SUFDekIsT0FBTyxvQkFBb0I7R0FDL0I7RUFDSjtFQUNBLFVBQVUsTUFBTSxLQUFLO0dBQ2pCLEdBQUksQ0FBQyxTQUFTLElBQUksTUFDWixnQkFBZ0IsV0FBVyx5QkFBeUIsWUFDbEQsWUFBWSxXQUFXLFVBQ3pCLENBQUMsSUFDRCxFQUFFLEtBQUs7R0FDYixHQUFJLFNBQVMsWUFBWSxDQUFDLE9BQU8sRUFBRSxRQUFRLElBQUksQ0FBQztHQUNoRCxRQUFRLFdBQVc7RUFDdkIsQ0FBQztFQUNELFFBQVEsZUFDSixDQUFDLG9CQUNELHNCQUFzQixTQUFTLGFBQWEsT0FBTyxhQUFhLE9BQU8sS0FBSztFQUNoRixPQUFPO0NBQ1g7Q0FDQSxNQUFNLGFBQWEsWUFBWSxXQUFXO0VBQ3RDLElBQUksU0FBUyxFQUNULEdBQUksT0FBTyxRQUFRLGNBQWMsZUFDckM7RUFDQSxJQUFJLFFBQ0EsU0FBUyxrQkFBa0IsT0FBTyxjQUFjLFdBQVcsY0FBYyxXQUFXLGVBQWUsTUFBTTtFQUU3RyxPQUFPLFlBQVksVUFBVSxJQUN2QixTQUNBLFNBQVMsVUFBVSxJQUNmLElBQUksUUFBUSxVQUFVLElBQ3RCLFdBQVcsS0FBSyxTQUFTLElBQUksUUFBUSxJQUFJLENBQUM7Q0FDeEQ7Q0FDQSxNQUFNLGlCQUFpQixNQUFNLGVBQWU7RUFDeEMsU0FBUyxDQUFDLENBQUMsS0FBSyxhQUFhLFdBQUEsQ0FBWSxRQUFRLElBQUk7RUFDckQsU0FBUyxDQUFDLENBQUMsS0FBSyxhQUFhLFdBQUEsQ0FBWSxhQUFhLElBQUk7RUFDMUQsT0FBTyxLQUFLLGFBQWEsV0FBQSxDQUFZLFFBQVEsSUFBSTtFQUNqRCxjQUFjLENBQUMsQ0FBQyxJQUFJLFdBQVcsa0JBQWtCLElBQUk7RUFDckQsV0FBVyxDQUFDLENBQUMsS0FBSyxhQUFhLFdBQUEsQ0FBWSxlQUFlLElBQUk7Q0FDbEU7Q0FDQSxNQUFNLGVBQWUsU0FBUztFQUMxQixNQUFNLFFBQVEsT0FBTyxzQkFBc0IsSUFBSSxJQUFJLEtBQUE7RUFDbkQsVUFBVSxRQUFRLFVBQVUsS0FBSyxLQUFhLE1BQU0sU0FBUyxjQUFjLE1BQU0sV0FBVyxRQUFRLFNBQVMsQ0FBQztFQUM5RyxJQUFJLE9BQ0EsTUFBTSxTQUFTLGNBQWM7R0FDekIsVUFBVSxNQUFNLEtBQUs7SUFDakIsTUFBTTtJQUNOLFFBQVEsV0FBVztHQUN2QixDQUFDO0VBQ0wsQ0FBQztPQUVBO0dBQ0QsV0FBVyxTQUFTLENBQUM7R0FDckIsVUFBVSxNQUFNLEtBQUssRUFDakIsUUFBUSxXQUFXLE9BQ3ZCLENBQUM7RUFDTDtDQUNKO0NBQ0EsTUFBTSxZQUFZLE1BQU0sT0FBTyxZQUFZO0VBQ3ZDLE1BQU0sT0FBTyxJQUFJLFNBQVMsTUFBTSxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFBLENBQUc7RUFFdEQsTUFBTSxFQUFFLEtBQUssWUFBWSxTQUFTLE1BQU0sR0FBRyxvQkFEdEIsSUFBSSxXQUFXLFFBQVEsSUFBSSxLQUFLLENBQUM7RUFFdEQsSUFBSSxXQUFXLFFBQVEsTUFBTTtHQUN6QixHQUFHO0dBQ0gsR0FBRztHQUNIO0VBQ0osQ0FBQztFQUNELFVBQVUsTUFBTSxLQUFLO0dBQ2pCO0dBQ0EsUUFBUSxXQUFXO0dBQ25CLFNBQVM7RUFDYixDQUFDO0VBQ0QsV0FBVyxRQUFRLGVBQWUsT0FBTyxJQUFJLFNBQVMsSUFBSSxNQUFNO0NBQ3BFO0NBQ0EsTUFBTSxTQUFTLE1BQU0saUJBQWlCO0VBQ2xDLElBQUksV0FBVyxJQUFJLEdBQUc7R0FDbEI7R0FDQSxNQUFNLEVBQUUsZ0JBQWdCLFVBQVUsTUFBTSxVQUFVLEVBQzlDLE9BQU8sWUFBWSxZQUFZLFdBQzNCLEtBQUssUUFBUSxVQUFVLFVBQVUsS0FBQSxHQUFXLFlBQVksR0FBRyxPQUFPLEVBQzFFLENBQUM7R0FDRCxJQUFJLFNBQVM7R0FDYixPQUFPLEVBQ0gsbUJBQW1CO0lBQ2YsSUFBSSxRQUNBO0lBRUosU0FBUztJQUNUO0lBQ0EsWUFBWTtHQUNoQixFQUNKO0VBQ0o7RUFDQSxPQUFPLFVBQVUsTUFBTSxjQUFjLElBQUk7Q0FDN0M7Q0FDQSxNQUFNLGNBQWMsVUFBVTtFQUMxQixJQUFJO0VBQ0osTUFBTSxjQUFjLENBQUMsR0FBRyxLQUFLLE1BQU0sZUFBZSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUssSUFBSSxHQUFHO0VBQ3RGLElBQUksYUFDQTtFQUVKLE1BQU0sRUFBRSxnQkFBZ0IsVUFBVSxNQUFNLFVBQVUsRUFDOUMsT0FBTyxjQUFjO0dBQ2pCLElBQUksc0JBQXNCLE1BQU0sTUFBTSxVQUFVLE1BQU0sTUFBTSxLQUFLLEtBQzdELHNCQUFzQixXQUFXLE1BQU0sYUFBYSxpQkFBaUIsZUFBZSxNQUFNLFlBQVksR0FBRztJQUN6RyxNQUFNLFdBQVcsRUFBRSxHQUFHLFlBQVk7SUFDbEMsTUFBTSxTQUFTO0tBQ1gsUUFBUTtLQUNSLEdBQUc7S0FDSCxHQUFHO0tBQ0gsZUFBZTtJQUNuQixDQUFDO0dBQ0w7RUFDSixFQUNKLENBQUM7RUFDRCxJQUFJLENBQUMsYUFDRCxPQUFPO0VBRVgsSUFBSSxTQUFTO0VBQ2IsYUFBYTtHQUNULElBQUksUUFDQTtHQUVKLFNBQVM7R0FDVDtHQUNBLFlBQVk7RUFDaEI7Q0FDSjtDQUNBLE1BQU0sYUFBYSxVQUFVO0VBQ3pCLE9BQU8sUUFBUTtFQUNmLDJCQUEyQjtHQUN2QixHQUFHO0dBQ0gsR0FBRyxNQUFNO0VBQ2I7RUFDQSxPQUFPLFdBQVc7R0FDZCxHQUFHO0dBQ0gsV0FBVztJQUNQLEdBQUc7SUFDSCxHQUFHLE1BQU07R0FDYjtFQUNKLENBQUM7Q0FDTDtDQUNBLE1BQU0sY0FBYyxNQUFNLFVBQVUsQ0FBQyxNQUFNO0VBQ3ZDLEtBQUssTUFBTSxhQUFhLE9BQU8sc0JBQXNCLElBQUksSUFBSSxPQUFPLE9BQU87R0FDdkUsT0FBTyxNQUFNLE9BQU8sU0FBUztHQUM3QixPQUFPLE1BQU0sT0FBTyxTQUFTO0dBQzdCLElBQUksQ0FBQyxRQUFRLFdBQVc7SUFDcEIsTUFBTSxTQUFTLFNBQVM7SUFDeEIsTUFBTSxhQUFhLFNBQVM7R0FDaEM7R0FDQSxDQUFDLFFBQVEsYUFBYSxNQUFNLFdBQVcsUUFBUSxTQUFTO0dBQ3hELENBQUMsUUFBUSxhQUFhLE1BQU0sV0FBVyxhQUFhLFNBQVM7R0FDN0QsQ0FBQyxRQUFRLGVBQWUsTUFBTSxXQUFXLGVBQWUsU0FBUztHQUNqRSxDQUFDLFFBQVEsb0JBQ0wsTUFBTSxXQUFXLGtCQUFrQixTQUFTO0dBQ2hELENBQUMsU0FBUyxvQkFDTixDQUFDLFFBQVEsb0JBQ1QsTUFBTSxnQkFBZ0IsU0FBUztFQUN2QztFQUNBLFVBQVUsTUFBTSxLQUFLLEVBQ2pCLFFBQVEsWUFBWSxXQUFXLEVBQ25DLENBQUM7RUFDRCxVQUFVLE1BQU0sS0FBSztHQUNqQixHQUFHO0dBQ0gsR0FBSSxDQUFDLFFBQVEsWUFBWSxDQUFDLElBQUksRUFBRSxTQUFTLFVBQVUsRUFBRTtFQUN6RCxDQUFDO0VBQ0QsQ0FBQyxRQUFRLGVBQWUsVUFBVTtDQUN0QztDQUNBLE1BQU0scUJBQXFCLEVBQUUsVUFBVSxXQUFZO0VBQy9DLElBQUssVUFBVSxRQUFRLEtBQUssT0FBTyxTQUMvQixDQUFDLENBQUMsWUFDRixPQUFPLFNBQVMsSUFBSSxJQUFJLEdBQUc7R0FHM0IsTUFBTSx1QkFGYyxPQUFPLFNBQVMsSUFBSSxJQUVELE1BQU0sQ0FEekIsQ0FBQztHQUVyQixXQUFXLE9BQU8sU0FBUyxJQUFJLElBQUksSUFBSSxPQUFPLFNBQVMsT0FBTyxJQUFJO0dBQ2xFLHdCQUF3QixPQUFPLFNBQVMsQ0FBQyxPQUFPLFVBQVUsVUFBVTtFQUN4RTtDQUNKO0NBQ0EsTUFBTSxZQUFZLE1BQU0sVUFBVSxDQUFDLE1BQU07RUFDckMsSUFBSSxRQUFRLElBQUksU0FBUyxJQUFJO0VBQzdCLE1BQU0sb0JBQW9CLFVBQVUsUUFBUSxRQUFRLEtBQUssVUFBVSxTQUFTLFFBQVE7RUFDcEYsTUFBTSwwQkFBMEIsQ0FBQyxPQUFPLGFBQWEsSUFBSSxJQUFJLEtBQUssU0FBUyxNQUFNLE1BQU0sQ0FBQyxNQUFNLEdBQUc7RUFDakcsSUFBSSxTQUFTLE1BQU07R0FDZixHQUFJLFNBQVMsQ0FBQztHQUNkLElBQUk7SUFDQSxHQUFJLFNBQVMsTUFBTSxLQUFLLE1BQU0sS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUU7SUFDbkQ7SUFDQSxPQUFPO0lBQ1AsR0FBRztHQUNQO0VBQ0osQ0FBQztFQUNELE9BQU8sTUFBTSxJQUFJLElBQUk7RUFDckIsSUFBSSxTQUFTLENBQUMseUJBQ1Ysa0JBQWtCO0dBQ2QsVUFBVSxVQUFVLFFBQVEsUUFBUSxJQUM5QixRQUFRLFdBQ1IsU0FBUztHQUNmO0VBQ0osQ0FBQztPQUdELG9CQUFvQixNQUFNLE1BQU0sUUFBUSxLQUFLO0VBRWpELE9BQU87R0FDSCxHQUFJLG9CQUNFLEVBQUUsVUFBVSxRQUFRLFlBQVksU0FBUyxTQUFTLElBQ2xELENBQUM7R0FDUCxHQUFJLFNBQVMsY0FDUDtJQUNFLFVBQVUsQ0FBQyxDQUFDLFFBQVE7SUFDcEIsS0FBSyxhQUFhLFFBQVEsR0FBRztJQUM3QixLQUFLLGFBQWEsUUFBUSxHQUFHO0lBQzdCLFdBQVcsYUFBYSxRQUFRLFNBQVM7SUFDekMsV0FBVyxhQUFhLFFBQVEsU0FBUztJQUN6QyxTQUFTLGFBQWEsUUFBUSxPQUFPO0dBQ3pDLElBQ0UsQ0FBQztHQUNQO0dBQ0E7R0FDQSxRQUFRO0dBQ1IsTUFBTSxRQUFRO0lBQ1YsSUFBSSxLQUFLO0tBQ0wsT0FBTyxhQUFhLElBQUksSUFBSTtLQUM1QixTQUFTLE1BQU0sT0FBTztLQUN0QixPQUFPLGFBQWEsT0FBTyxJQUFJO0tBQy9CLFFBQVEsSUFBSSxTQUFTLElBQUk7S0FDekIsTUFBTSxXQUFXLFlBQVksSUFBSSxLQUFLLElBQ2hDLElBQUksbUJBQ0EsSUFBSSxpQkFBaUIsdUJBQXVCLENBQUMsQ0FBQyxNQUFNLE1BQ3BELE1BQ0o7S0FDTixNQUFNLGtCQUFrQixrQkFBa0IsUUFBUTtLQUNsRCxNQUFNLE9BQU8sTUFBTSxHQUFHLFFBQVEsQ0FBQztLQUMvQixJQUFJLGtCQUNFLEtBQUssTUFBTSxXQUFXLFdBQVcsUUFBUSxJQUN6QyxhQUFhLE1BQU0sR0FBRyxLQUN4QjtLQUVKLE1BQU0sV0FBVyxFQUNiLEdBQUcsTUFBTSxHQUNiO0tBQ0EsSUFBSSxpQkFBaUI7TUFDakIsU0FBUyxPQUFPO09BQ1osR0FBRyxLQUFLLE9BQU8sSUFBSTtPQUNuQjtPQUNBLEdBQUksTUFBTSxRQUFRLElBQUksZ0JBQWdCLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztNQUMzRDtNQUNBLFNBQVMsTUFBTTtPQUFFLE1BQU0sU0FBUztPQUFNO01BQUs7S0FDL0MsT0FDSztNQUNELFNBQVMsTUFBTTtNQUNmLE9BQU8sU0FBUztLQUNwQjtLQUNBLElBQUksU0FBUyxNQUFNLEVBQ2YsSUFBSSxTQUNSLENBQUM7S0FDRCxvQkFBb0IsTUFBTSxPQUFPLEtBQUEsR0FBVyxRQUFRO0lBQ3hELE9BQ0s7S0FDRCxRQUFRLElBQUksU0FBUyxNQUFNLENBQUMsQ0FBQztLQUM3QixJQUFJLE1BQU0sSUFDTixNQUFNLEdBQUcsUUFBUTtLQUVyQixDQUFDLFNBQVMsb0JBQW9CLFFBQVEscUJBQ2xDLEVBQUUsbUJBQW1CLE9BQU8sT0FBTyxJQUFJLEtBQUssT0FBTyxXQUNuRCxPQUFPLFFBQVEsSUFBSSxJQUFJO0lBQy9CO0dBQ0o7RUFDSjtDQUNKO0NBQ0EsTUFBTSxvQkFBb0IsU0FBUyxvQkFDL0IsQ0FBQyxTQUFTLDZCQUNWLHNCQUFzQixTQUFTLGFBQWEsT0FBTyxLQUFLO0NBQzVELE1BQU0sZ0JBQWdCLGFBQWE7RUFDL0IsSUFBSSxVQUFVLFFBQVEsR0FBRztHQUNyQixVQUFVLE1BQU0sS0FBSyxFQUFFLFNBQVMsQ0FBQztHQUNqQyxzQkFBc0IsVUFBVSxLQUFLLFNBQVM7SUFDMUMsTUFBTSxlQUFlLElBQUksU0FBUyxJQUFJO0lBQ3RDLElBQUksY0FBYztLQUNkLElBQUksV0FBVyxhQUFhLEdBQUcsWUFBWTtLQUMzQyxJQUFJLE1BQU0sUUFBUSxhQUFhLEdBQUcsSUFBSSxHQUNsQyxhQUFhLEdBQUcsS0FBSyxTQUFTLGFBQWE7TUFDdkMsU0FBUyxXQUFXLGFBQWEsR0FBRyxZQUFZO0tBQ3BELENBQUM7SUFFVDtHQUNKLEdBQUcsR0FBRyxLQUFLO0VBQ2Y7Q0FDSjtDQUNBLE1BQU0sZ0JBQWdCLFNBQVMsY0FBYyxPQUFPLE1BQU07RUFDdEQsSUFBSSxTQUFTLEtBQUE7RUFDYixJQUFJLGVBQWUsS0FBQTtFQUNuQixJQUFJLEdBQUc7R0FDSCxFQUFFLGtCQUFrQixFQUFFLGVBQWU7R0FDckMsRUFBRSxXQUNFLEVBQUUsUUFBUTtFQUNsQjtFQUNBLElBQUksY0FBYyxZQUFZLFdBQVc7RUFDekMsVUFBVSxNQUFNLEtBQUssRUFDakIsY0FBYyxLQUNsQixDQUFDO0VBQ0QsSUFBSSxTQUFTLFVBQVU7R0FDbkIsTUFBTSxFQUFFLFFBQVEsV0FBVyxNQUFNLFdBQVc7R0FDNUMsb0JBQW9CO0dBQ3BCLFdBQVcsU0FBUztHQUNwQixjQUFjLFlBQVksTUFBTTtFQUNwQyxPQUVJLE1BQU0seUJBQXlCO0dBQzNCLFFBQVE7R0FDUixXQUFXLE9BQU87RUFDdEIsQ0FBQztFQUVMLElBQUksT0FBTyxTQUFTLE1BQ2hCLEtBQUssTUFBTSxRQUFRLE9BQU8sVUFDdEIsTUFBTSxhQUFhLElBQUk7RUFHL0IsTUFBTSxXQUFXLFFBQVEsZUFBZTtFQUN4QyxJQUFJLGNBQWMsV0FBVyxNQUFNLEdBQUc7R0FDbEMsVUFBVSxNQUFNLEtBQUssRUFDakIsUUFBUSxDQUFDLEVBQ2IsQ0FBQztHQUNELElBQUk7SUFDQSxTQUFTLE1BQU0sUUFBUSxhQUFhLENBQUM7R0FDekMsU0FDTyxPQUFPO0lBQ1YsZUFBZTtHQUNuQjtFQUNKLE9BQ0s7R0FDRCxJQUFJLFdBQ0EsTUFBTSxVQUFVLEVBQUUsR0FBRyxXQUFXLE9BQU8sR0FBRyxDQUFDO0dBRS9DLFlBQVk7R0FDWixXQUFXLFdBQVc7RUFDMUI7RUFDQSxVQUFVLE1BQU0sS0FBSztHQUNqQixhQUFhO0dBQ2IsY0FBYztHQUNkLG9CQUFvQixjQUFjLFdBQVcsTUFBTSxLQUFLLENBQUM7R0FDekQsYUFBYSxXQUFXLGNBQWM7R0FDdEMsUUFBUSxXQUFXO0VBQ3ZCLENBQUM7RUFDRCxJQUFJLGNBQ0EsTUFBTTtFQUVWLE9BQU87Q0FDWDtDQUNBLE1BQU0sY0FBYyxNQUFNLFVBQVUsQ0FBQyxNQUFNO0VBQ3ZDLElBQUksSUFBSSxTQUFTLElBQUksR0FBRztHQUNwQixJQUFJLFlBQVksUUFBUSxZQUFZLEdBQ2hDLFNBQVMsTUFBTSxZQUFZLElBQUksZ0JBQWdCLElBQUksQ0FBQyxDQUFDO1FBRXBEO0lBQ0QsU0FBUyxNQUFNLFFBQVEsWUFBWTtJQUNuQyxJQUFJLGdCQUFnQixNQUFNLFlBQVksUUFBUSxZQUFZLENBQUM7R0FDL0Q7R0FDQSxJQUFJLENBQUMsUUFBUSxhQUNULE1BQU0sV0FBVyxlQUFlLElBQUk7R0FFeEMsSUFBSSxDQUFDLFFBQVEsV0FBVztJQUNwQixNQUFNLFdBQVcsYUFBYSxJQUFJO0lBQ2xDLFdBQVcsVUFBVSxRQUFRLGVBQ3ZCLFVBQVUsTUFBTSxZQUFZLElBQUksZ0JBQWdCLElBQUksQ0FBQyxDQUFDLElBQ3RELFVBQVU7R0FDcEI7R0FDQSxJQUFJLENBQUMsUUFBUSxXQUFXO0lBQ3BCLE1BQU0sV0FBVyxRQUFRLElBQUk7SUFDN0IsZ0JBQWdCLFdBQVcsVUFBVTtHQUN6QztHQUNBLFVBQVUsTUFBTSxLQUFLLEVBQUUsR0FBRyxXQUFXLENBQUM7RUFDMUM7Q0FDSjtDQUNBLE1BQU0sVUFBVSxZQUFZLG1CQUFtQixDQUFDLE1BQU07RUFDbEQsTUFBTSxnQkFBZ0IsYUFBYSxZQUFZLFVBQVUsSUFBSTtFQUM3RCxNQUFNLHFCQUFxQixZQUFZLGFBQWE7RUFDcEQsTUFBTSxxQkFBcUIsY0FBYyxVQUFVO0VBQ25ELE1BQU0sU0FBUztFQUNmLE1BQU0sWUFBWTtFQUNsQixJQUFJLENBQUMsaUJBQWlCLG1CQUNsQixpQkFBaUI7RUFFckIsSUFBSSxDQUFDLGlCQUFpQixZQUFZO0dBQzlCLElBQUksaUJBQWlCLGlCQUFpQjtJQUNsQyxNQUFNLGdDQUFnQixJQUFJLElBQUksQ0FDMUIsR0FBRyxPQUFPLE9BQ1YsR0FBRyx1QkFBdUIsZUFBZSxnQkFBZ0IsYUFBYSxLQUFBLEdBQVcsU0FBUyxHQUFHLFdBQVcsV0FBVyxDQUN2SCxDQUFDO0lBQ0QsS0FBSyxNQUFNLGFBQWEsTUFBTSxLQUFLLGFBQWEsR0FBRztLQUMvQyxNQUFNLFVBQVUsSUFBSSxXQUFXLGFBQWEsU0FBUztLQUNyRCxNQUFNLGdCQUFnQixJQUFJLGFBQWEsU0FBUztLQUNoRCxNQUFNLFdBQVcsSUFBSSxRQUFRLFNBQVM7S0FDdEMsSUFBSSxXQUFXLENBQUMsWUFBWSxhQUFhLEdBQ3JDLElBQUksUUFBUSxXQUFXLGFBQWE7VUFFbkMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLFFBQVEsR0FDdEMsU0FBUyxXQUFXLFFBQVE7SUFFcEM7R0FDSixPQUNLO0lBQ0QsSUFBSSxTQUFTLFlBQVksVUFBVSxHQUMvQixLQUFLLE1BQU0sUUFBUSxPQUFPLE9BQU87S0FDN0IsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJO0tBQy9CLElBQUksU0FBUyxNQUFNLElBQUk7TUFDbkIsTUFBTSxpQkFBaUIsTUFBTSxRQUFRLE1BQU0sR0FBRyxJQUFJLElBQzVDLE1BQU0sR0FBRyxLQUFLLEtBQ2QsTUFBTSxHQUFHO01BQ2YsSUFBSSxjQUFjLGNBQWMsR0FBRztPQUMvQixNQUFNLE9BQU8sZUFBZSxRQUFRLE1BQU07T0FDMUMsSUFBSSxNQUFNO1FBQ04sS0FBSyxNQUFNO1FBQ1g7T0FDSjtNQUNKO0tBQ0o7SUFDSjtJQUVKLElBQUksaUJBQWlCLGVBQ2pCLEtBQUssTUFBTSxhQUFhLE9BQU8sT0FDM0IsU0FBUyxXQUFXLElBQUksUUFBUSxTQUFTLENBQUM7U0FJOUMsVUFBVSxDQUFDO0dBRW5CO0dBQ0EsSUFBSSxTQUFTLGtCQUFrQjtJQUMzQixjQUFjLGlCQUFpQixvQkFDekIsWUFBWSxjQUFjLElBQzFCLENBQUM7SUFDUCxJQUFJLGlCQUFpQixlQUNqQixLQUFLLE1BQU0sYUFBYSxPQUFPLE9BQzNCLElBQUksYUFBYSxXQUFXLElBQUksUUFBUSxTQUFTLENBQUM7R0FHOUQsT0FFSSxjQUFjLFlBQVksTUFBTTtHQUVwQyxVQUFVLE1BQU0sS0FBSyxFQUNqQixRQUFRLEVBQUUsR0FBRyxPQUFPLEVBQ3hCLENBQUM7R0FDRCxVQUFVLE1BQU0sS0FBSztJQUNqQixNQUFNLEtBQUE7SUFDTixNQUFNLEtBQUE7SUFDTixRQUFRLEVBQUUsR0FBRyxPQUFPO0dBQ3hCLENBQUM7RUFDTDtFQUNBLFNBQVM7R0FDTCxPQUFPLGlCQUFpQixrQkFBa0IsT0FBTyx3QkFBUSxJQUFJLElBQUk7R0FDakUseUJBQVMsSUFBSSxJQUFJO0dBQ2pCLHVCQUFPLElBQUksSUFBSTtHQUNmLDhCQUFjLElBQUksSUFBSTtHQUN0QiwwQkFBVSxJQUFJLElBQUk7R0FDbEIsdUJBQU8sSUFBSSxJQUFJO0dBQ2YsVUFBVTtHQUNWLE9BQU87RUFDWDtFQUNBLE9BQU8sUUFDSCxDQUFDLGdCQUFnQixXQUNiLENBQUMsQ0FBQyxpQkFBaUIsZUFDbkIsQ0FBQyxDQUFDLGlCQUFpQixtQkFDbEIsQ0FBQyxTQUFTLG9CQUFvQixDQUFDLGNBQWMsTUFBTTtFQUM1RCxPQUFPLFFBQVEsQ0FBQyxDQUFDLFNBQVM7RUFDMUIsT0FBTyxjQUFjLENBQUMsQ0FBQyxpQkFBaUI7RUFDeEMsT0FBTyxTQUFTO0VBQ2hCLE9BQU8sbUJBQW1CLE1BQU07RUFDaEMsSUFBSSxDQUFDLGlCQUFpQixZQUNsQixXQUFXLFNBQVMsQ0FBQztFQUV6QixVQUFVLE1BQU0sS0FBSztHQUNqQixhQUFhLGlCQUFpQixrQkFDeEIsV0FBVyxjQUNYO0dBQ04sU0FBUyxxQkFDSCxRQUNBLGlCQUFpQixZQUNiLFdBQVcsVUFDWCxpQkFBaUIsYUFDYixVQUFVLElBQ1YsQ0FBQyxFQUFFLGlCQUFpQixxQkFDbEIsQ0FBQyxVQUFVLFlBQVksY0FBYztHQUNyRCxhQUFhLGlCQUFpQixrQkFDeEIsV0FBVyxjQUNYO0dBQ04sYUFBYSxxQkFDUCxDQUFDLElBQ0QsaUJBQWlCLGtCQUNiLGlCQUFpQixxQkFBcUIsY0FDbEMsZUFBZSxnQkFBZ0IsYUFBYSxLQUFBLEdBQVcsU0FBUyxJQUNoRSxXQUFXLGNBQ2YsaUJBQWlCLHFCQUFxQixhQUNsQyxlQUFlLGdCQUFnQixZQUFZLEtBQUEsR0FBVyxTQUFTLElBQy9ELGlCQUFpQixZQUNiLFdBQVcsY0FDWCxDQUFDO0dBQ25CLGVBQWUsaUJBQWlCLGNBQzFCLFdBQVcsZ0JBQ1gsQ0FBQztHQUNQLFFBQVEsaUJBQWlCLGFBQWEsV0FBVyxTQUFTLENBQUM7R0FDM0Qsb0JBQW9CLGlCQUFpQix5QkFDL0IsV0FBVyxxQkFDWDtHQUNOLGNBQWM7R0FDZCxlQUFlO0VBQ25CLENBQUM7Q0FDTDtDQUNBLE1BQU0sU0FBUyxZQUFZLHFCQUFxQixPQUFPLFdBQVcsVUFBVSxJQUN0RSxXQUFXLFdBQVcsSUFDdEIsWUFBWTtFQUFFLEdBQUcsU0FBUztFQUFjLEdBQUc7Q0FBaUIsQ0FBQztDQUNuRSxNQUFNLFlBQVksTUFBTSxVQUFVLENBQUMsTUFBTTtFQUNyQyxNQUFNLFFBQVEsSUFBSSxTQUFTLElBQUk7RUFDL0IsTUFBTSxpQkFBaUIsU0FBUyxNQUFNO0VBQ3RDLElBQUksZ0JBQWdCO0dBQ2hCLE1BQU0sV0FBVyxlQUFlLE9BQzFCLGVBQWUsS0FBSyxLQUNwQixlQUFlO0dBQ3JCLElBQUksU0FBUyxPQUNULGlCQUFpQjtJQUNiLFNBQVMsTUFBTTtJQUNmLFFBQVEsZ0JBQ0osV0FBVyxTQUFTLE1BQU0sS0FDMUIsU0FBUyxPQUFPO0dBQ3hCLENBQUM7RUFFVDtDQUNKO0NBQ0EsTUFBTSxpQkFBaUIscUJBQXFCO0VBTXhDLE1BQU0sRUFBRSxNQUFNLE1BQU0sUUFBUSxHQUFHLGNBQWM7RUFDN0MsYUFBYTtHQUNULEdBQUc7R0FDSCxHQUFHO0VBQ1A7Q0FDSjtDQUNBLFVBQVUsTUFBTSxVQUFVLEVBQUUsTUFBTSxjQUFjLENBQUM7Q0FDakQsTUFBTSw0QkFBNEIsV0FBVyxTQUFTLGFBQWEsS0FDL0QsU0FBUyxjQUFjLENBQUMsQ0FBQyxNQUFNLFdBQVc7RUFDdEMsTUFBTSxRQUFRLFNBQVMsWUFBWTtFQUNuQyxVQUFVLE1BQU0sS0FBSyxFQUNqQixXQUFXLE1BQ2YsQ0FBQztDQUNMLENBQUM7Q0FDTCxNQUFNLHNCQUFzQixRQUFRLFVBQVUsQ0FBQyxNQUFNO0VBQ2pELGlCQUFpQixZQUFZLE1BQU07RUFDbkMsSUFBSSxDQUFDLFFBQVEsV0FBVztHQUNwQixNQUFNLGlCQUFpQixlQUFlLGdCQUFnQixhQUFhLEtBQUEsR0FBVyxPQUFPO0dBQ3JGLFdBQVcsY0FBYztHQUN6QixXQUFXLFVBQVUsQ0FBQyxjQUFjLGNBQWM7RUFDdEQ7RUFDQSxJQUFJLENBQUMsUUFBUSxhQUNULFVBQVU7RUFFZCxVQUFVLE1BQU0sS0FBSztHQUNqQixHQUFHO0dBQ0gsZUFBZTtFQUNuQixDQUFDO0NBQ0w7Q0FDQSxNQUFNLFVBQVU7RUFDWixTQUFTO0dBQ0w7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQSxJQUFJLFVBQVU7SUFDVixPQUFPO0dBQ1g7R0FDQSxJQUFJLGNBQWM7SUFDZCxPQUFPO0dBQ1g7R0FDQSxJQUFJLFNBQVM7SUFDVCxPQUFPO0dBQ1g7R0FDQSxJQUFJLE9BQU8sT0FBTztJQUNkLFNBQVM7R0FDYjtHQUNBLElBQUksaUJBQWlCO0lBQ2pCLE9BQU87R0FDWDtHQUNBLElBQUksU0FBUztJQUNULE9BQU87R0FDWDtHQUNBLElBQUksT0FBTyxPQUFPO0lBQ2QsU0FBUztHQUNiO0dBQ0EsSUFBSSxhQUFhO0lBQ2IsT0FBTztHQUNYO0dBQ0EsSUFBSSxXQUFXO0lBQ1gsT0FBTztHQUNYO0dBQ0EsSUFBSSxTQUFTLE9BQU87SUFDaEIsV0FBVztLQUNQLEdBQUc7S0FDSCxHQUFHO0lBQ1A7SUFDQSw4QkFBOEIsbUJBQW1CLFNBQVMsSUFBSTtJQUM5RCw2QkFBNkIsbUJBQW1CLFNBQVMsY0FBYztHQUMzRTtFQUNKO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDSjtDQUNBLE9BQU87RUFDSCxHQUFHO0VBQ0gsYUFBYTtDQUNqQjtBQUNKOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUErQkEsU0FBUyxRQUFRLFFBQVEsQ0FBQyxHQUFHO0NBQ3pCLE1BQU0sZUFBQSxhQUFxQixPQUFPLEtBQUEsQ0FBUztDQUMzQyxNQUFNLFVBQUEsYUFBZ0IsT0FBTyxLQUFBLENBQVM7Q0FDdEMsTUFBTSxtQkFBQSxhQUF5QixPQUFPLE1BQU0sV0FBVztDQUN2RCxNQUFNLENBQUMsV0FBVyxtQkFBQSxhQUF5QixnQkFBZ0I7RUFDdkQsR0FBRyxZQUFZLGtCQUFrQjtFQUNqQyxXQUFXLFdBQVcsTUFBTSxhQUFhO0VBQ3pDLFFBQVEsTUFBTSxVQUFVLENBQUM7RUFDekIsVUFBVSxNQUFNLFlBQVk7RUFDNUIsZUFBZSxXQUFXLE1BQU0sYUFBYSxJQUN2QyxLQUFBLElBQ0EsTUFBTTtDQUNoQixFQUFFO0NBQ0YsSUFBSSxDQUFDLGFBQWEsV0FDYixNQUFNLGVBQWUsaUJBQWlCLFlBQVksTUFBTSxhQUFjO0VBQ3ZFLGlCQUFpQixVQUFVLE1BQU07RUFDakMsSUFBSSxNQUFNLGFBQWE7R0FDbkIsYUFBYSxVQUFVO0lBQ25CLEdBQUcsTUFBTTtJQUNUO0dBQ0o7R0FDQSxJQUFJLE1BQU0saUJBQWlCLENBQUMsV0FBVyxNQUFNLGFBQWEsR0FDdEQsTUFBTSxZQUFZLE1BQU0sTUFBTSxlQUFlLE1BQU0sWUFBWTtFQUV2RSxPQUNLO0dBQ0QsTUFBTSxFQUFFLGFBQWEsR0FBRyxTQUFTLGtCQUFrQixLQUFLO0dBQ3hELGFBQWEsVUFBVTtJQUNuQixHQUFHO0lBQ0g7R0FDSjtFQUNKO0NBQ0o7Q0FDQSxNQUFNLFVBQVUsYUFBYSxRQUFRO0NBQ3JDLFFBQVEsV0FBVztDQUNuQixNQUFNLEVBQUUsZ0JBQWdCLGFBQWEscUJBQXFCO0NBQzFELGdDQUFnQztFQUM1QixNQUFNLDZCQUE2QjtHQUMvQixHQUFHLFFBQVE7R0FDWCxlQUFlLFFBQVE7RUFDM0I7RUFDQSxlQUFlLE1BQU0scUJBQXFCLGVBQWU7RUFDekQsTUFBTSxjQUFjLFFBQVEsV0FBVztHQUNuQyxXQUFXLFFBQVE7R0FDbkIsZ0JBQWdCLGdCQUFnQjtJQUM1QixHQUFHLFFBQVE7SUFDWCxlQUFlLFFBQVE7R0FDM0IsQ0FBQztHQUNELGNBQWM7RUFDbEIsQ0FBQztFQUNELGlCQUFpQixVQUFVO0dBQ3ZCLEdBQUc7R0FDSCxTQUFTO0VBQ2IsRUFBRTtFQUNGLFFBQVEsV0FBVyxVQUFVO0VBQzdCLGFBQWE7R0FDVCxZQUFZO0dBQ1osU0FBUyxNQUFNLG1CQUFtQjtFQUN0QztDQUNKLEdBQUc7RUFBQztFQUFTO0VBQWdCO0NBQVEsQ0FBQztDQUN0QyxhQUFNLGdCQUFnQixRQUFRLGFBQWEsTUFBTSxRQUFRLEdBQUcsQ0FBQyxTQUFTLE1BQU0sUUFBUSxDQUFDO0NBQ3JGLGFBQU0sZ0JBQWdCO0VBQ2xCLElBQUksTUFBTSxNQUNOLFFBQVEsU0FBUyxPQUFPLE1BQU07RUFFbEMsSUFBSSxNQUFNLGdCQUNOLFFBQVEsU0FBUyxpQkFBaUIsTUFBTTtDQUVoRCxHQUFHO0VBQUM7RUFBUyxNQUFNO0VBQU0sTUFBTTtDQUFjLENBQUM7Q0FDOUMsYUFBTSxnQkFBZ0I7RUFDbEIsSUFBSSxNQUFNLFFBQVE7R0FDZCxRQUFRLFdBQVcsTUFBTSxNQUFNO0dBQy9CLFFBQVEsWUFBWTtFQUN4QjtDQUNKLEdBQUcsQ0FBQyxTQUFTLE1BQU0sTUFBTSxDQUFDO0NBQzFCLGFBQU0sZ0JBQWdCO0VBQ2xCLE1BQU0sb0JBQ0YsUUFBUSxVQUFVLE1BQU0sS0FBSyxFQUN6QixRQUFRLFFBQVEsVUFBVSxFQUM5QixDQUFDO0NBQ1QsR0FBRyxDQUFDLFNBQVMsTUFBTSxnQkFBZ0IsQ0FBQztDQUNwQyxhQUFNLGdCQUFnQjtFQUNsQixJQUFJLFFBQVEsZ0JBQWdCLFNBQVM7R0FDakMsTUFBTSxVQUFVLFFBQVEsVUFBVTtHQUNsQyxJQUFJLFlBQVksVUFBVSxTQUN0QixRQUFRLFVBQVUsTUFBTSxLQUFLLEVBQ3pCLFFBQ0osQ0FBQztFQUVUO0NBQ0osR0FBRyxDQUFDLFNBQVMsVUFBVSxPQUFPLENBQUM7Q0FDL0IsYUFBTSxnQkFBZ0I7RUFDbEIsSUFBSTtFQUNKLElBQUksTUFBTSxVQUFVLENBQUMsVUFBVSxNQUFNLFFBQVEsUUFBUSxPQUFPLEdBQUc7R0FDM0QsUUFBUSxPQUFPLE1BQU0sUUFBUTtJQUN6QixlQUFlO0lBQ2YsR0FBRyxRQUFRLFNBQVM7R0FDeEIsQ0FBQztHQUNELElBQUksR0FBRyxLQUFLLFFBQVEsU0FBUyxrQkFBa0IsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxjQUMvRSxRQUFRLFVBQVU7R0FFdEIsUUFBUSxVQUFVLE1BQU07R0FDeEIsaUJBQWlCLFdBQVcsRUFBRSxHQUFHLE1BQU0sRUFBRTtFQUM3QyxPQUVJLFFBQVEsb0JBQW9CO0NBRXBDLEdBQUcsQ0FBQyxTQUFTLE1BQU0sTUFBTSxDQUFDO0NBQzFCLGFBQU0sZ0JBQWdCO0VBQ2xCLElBQUksQ0FBQyxRQUFRLE9BQU8sT0FBTztHQUN2QixRQUFRLFVBQVU7R0FDbEIsUUFBUSxPQUFPLFFBQVE7RUFDM0I7RUFDQSxJQUFJLFFBQVEsT0FBTyxPQUFPO0dBQ3RCLFFBQVEsT0FBTyxRQUFRO0dBQ3ZCLFFBQVEsVUFBVSxNQUFNLEtBQUssRUFBRSxHQUFHLFFBQVEsV0FBVyxDQUFDO0VBQzFEO0VBQ0EsUUFBUSxpQkFBaUI7Q0FDN0IsQ0FBQztDQUNELGFBQWEsUUFBUSxZQUFBLGFBQWtCLGNBQWMsa0JBQWtCLFdBQVcsT0FBTyxHQUFHLENBQUMsU0FBUyxTQUFTLENBQUM7Q0FDaEgsT0FBTyxhQUFhO0FBQ3hCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE0QkEsSUFBTSxTQUFTLFVBQVUsTUFBTSxPQUFPLFNBQVM7Q0FBRSxNQUFNLE1BQU07Q0FBTyxHQUFHO0FBQU0sQ0FBQyxDQUFDIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==