import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/public/Login/index.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2ae0ea78";
import { Link } from "/node_modules/.vite/deps/react-router.js?v=10fd912d";
import { useAuth } from "/src/hooks/auth.tsx";
import { ApiRequestError } from "/src/services/api.ts";
import { ErrorMessage, Field, Form, HeaderGroup, LoginPanel, PageShell, SwitchAuthText } from "/src/pages/public/Login/styles.ts";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/public/Login/index.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2ae0ea78";
var _s = $RefreshSig$();
const Login = () => {
	_s();
	const { signIn } = useAuth();
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [error, setError] = useState("");
	const [isSubmitting, setIsSubmitting] = useState(false);
	async function handleSubmit(event) {
		event.preventDefault();
		setError("");
		setIsSubmitting(true);
		try {
			await signIn({
				email,
				password
			});
		} catch (err) {
			const message = err instanceof ApiRequestError ? err.message : "Nao foi possivel realizar o login.";
			setError(message);
		} finally {
			setIsSubmitting(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV(PageShell, { children: /* @__PURE__ */ _jsxDEV(LoginPanel, { children: [
		/* @__PURE__ */ _jsxDEV(HeaderGroup, { children: /* @__PURE__ */ _jsxDEV("span", { children: "Mini Task Manager" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 34,
			columnNumber: 11
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(Form, {
			onSubmit: handleSubmit,
			children: [
				/* @__PURE__ */ _jsxDEV(Field, { children: [/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: "email",
					children: "E-mail"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("input", {
					id: "email",
					name: "email",
					type: "email",
					autoComplete: "email",
					value: email,
					onChange: (event_0) => setEmail(event_0.target.value),
					required: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(Field, { children: [/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: "password",
					children: "Senha"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("input", {
					id: "password",
					name: "password",
					type: "password",
					autoComplete: "current-password",
					value: password,
					onChange: (event_1) => setPassword(event_1.target.value),
					required: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 11
				}, this),
				error ? /* @__PURE__ */ _jsxDEV(ErrorMessage, {
					role: "alert",
					children: error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 20
				}, this) : null,
				/* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					disabled: isSubmitting,
					children: isSubmitting ? "Entrando..." : "Entrar"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(SwitchAuthText, { children: ["Nao possui uma conta? ", /* @__PURE__ */ _jsxDEV(Link, {
			to: "/register",
			children: "Cadastre-se"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 56,
			columnNumber: 33
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 9
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 32,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 10
	}, this);
};
_s(Login, "q2FaYeVAogikxggBaIlce61oWFY=", false, function() {
	return [useAuth];
});
_c = Login;
export default Login;
var _c;
$RefreshReg$(_c, "Login");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/public/Login/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/public/Login/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/public/Login/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/public/Login/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsU0FBU0EsZ0JBQWdCO0FBRXpCLFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyx1QkFBdUI7QUFDaEMsU0FDRUMsY0FDQUMsT0FDQUMsTUFDQUMsYUFDQUMsWUFDQUMsV0FDQUMsc0JBQ0s7Ozs7QUFFUCxNQUFNQyxjQUFjOztDQUNsQixNQUFNLEVBQUVDLFdBQVdWLFFBQVE7Q0FDM0IsTUFBTSxDQUFDVyxPQUFPQyxZQUFZZCxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDZSxVQUFVQyxlQUFlaEIsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQ2lCLE9BQU9DLFlBQVlsQixTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDbUIsY0FBY0MsbUJBQW1CcEIsU0FBUyxLQUFLO0NBRXRELGVBQWVxQixhQUFhQyxPQUFtQztFQUM3REEsTUFBTUMsZUFBZTtFQUNyQkwsU0FBUyxFQUFFO0VBQ1hFLGdCQUFnQixJQUFJO0VBRXBCLElBQUk7R0FDRixNQUFNUixPQUFPO0lBQUVDO0lBQU9FO0dBQVMsQ0FBQztFQUNsQyxTQUFTUyxLQUFLO0dBQ1osTUFBTUMsVUFDSkQsZUFBZXJCLGtCQUNYcUIsSUFBSUMsVUFDSjtHQUNOUCxTQUFTTyxPQUFPO0VBQ2xCLFVBQVU7R0FDUkwsZ0JBQWdCLEtBQUs7RUFDdkI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsV0FBRCxZQUNFLHdCQUFDLFlBQUQ7RUFDRSx3QkFBQyxhQUFELFlBQ0Usd0JBQUMsUUFBRCxZQUFNLG9CQUF1Qjs7OztXQUNsQjs7Ozs7RUFFYix3QkFBQyxNQUFEO0dBQU0sVUFBVUM7YUFBaEI7SUFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtLQUFPLFNBQVE7ZUFBUTtJQUFhOzs7O2NBQ3BDLHdCQUFDLFNBQUQ7S0FDRSxJQUFHO0tBQ0gsTUFBSztLQUNMLE1BQUs7S0FDTCxjQUFhO0tBQ2IsT0FBT1I7S0FDUCxXQUFXUyxZQUFVUixTQUFTUSxRQUFNSSxPQUFPQyxLQUFLO0tBQ2hEO0lBQVE7Ozs7WUFFTDs7Ozs7SUFFUCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtLQUFPLFNBQVE7ZUFBVztJQUFZOzs7O2NBQ3RDLHdCQUFDLFNBQUQ7S0FDRSxJQUFHO0tBQ0gsTUFBSztLQUNMLE1BQUs7S0FDTCxjQUFhO0tBQ2IsT0FBT1o7S0FDUCxXQUFXTyxZQUFVTixZQUFZTSxRQUFNSSxPQUFPQyxLQUFLO0tBQ25EO0lBQVE7Ozs7WUFFTDs7Ozs7SUFFTlYsUUFBUSx3QkFBQyxjQUFEO0tBQWMsTUFBSztlQUFTQTtJQUFvQjs7OztlQUFJO0lBRTdELHdCQUFDLFVBQUQ7S0FBUSxNQUFLO0tBQVMsVUFBVUU7ZUFDN0JBLGVBQWUsZ0JBQWdCO0lBQzFCOzs7OztHQUNKOzs7Ozs7RUFFTix3QkFBQyxnQkFBRCxhQUFlLDBCQUNTLHdCQUFDLE1BQUQ7R0FBTSxJQUFHO2FBQVk7RUFBaUI7Ozs7VUFDOUM7Ozs7O0NBQ047Ozs7VUFDSDs7Ozs7QUFFZjs7Ozs7QUFFQSxlQUFlUiIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTGluayIsInVzZUF1dGgiLCJBcGlSZXF1ZXN0RXJyb3IiLCJFcnJvck1lc3NhZ2UiLCJGaWVsZCIsIkZvcm0iLCJIZWFkZXJHcm91cCIsIkxvZ2luUGFuZWwiLCJQYWdlU2hlbGwiLCJTd2l0Y2hBdXRoVGV4dCIsIkxvZ2luIiwic2lnbkluIiwiZW1haWwiLCJzZXRFbWFpbCIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJlcnJvciIsInNldEVycm9yIiwiaXNTdWJtaXR0aW5nIiwic2V0SXNTdWJtaXR0aW5nIiwiaGFuZGxlU3VibWl0IiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImVyciIsIm1lc3NhZ2UiLCJ0YXJnZXQiLCJ2YWx1ZSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB0eXBlIHsgRm9ybUV2ZW50IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlclwiO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCIuLi8uLi8uLi9ob29rcy9hdXRoXCI7XG5pbXBvcnQgeyBBcGlSZXF1ZXN0RXJyb3IgfSBmcm9tIFwiLi4vLi4vLi4vc2VydmljZXMvYXBpXCI7XG5pbXBvcnQge1xuICBFcnJvck1lc3NhZ2UsXG4gIEZpZWxkLFxuICBGb3JtLFxuICBIZWFkZXJHcm91cCxcbiAgTG9naW5QYW5lbCxcbiAgUGFnZVNoZWxsLFxuICBTd2l0Y2hBdXRoVGV4dCxcbn0gZnJvbSBcIi4vc3R5bGVzXCI7XG5cbmNvbnN0IExvZ2luID0gKCkgPT4ge1xuICBjb25zdCB7IHNpZ25JbiB9ID0gdXNlQXV0aCgpO1xuICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbaXNTdWJtaXR0aW5nLCBzZXRJc1N1Ym1pdHRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChldmVudDogRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD4pIHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIHNldEVycm9yKFwiXCIpO1xuICAgIHNldElzU3VibWl0dGluZyh0cnVlKTtcblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCBzaWduSW4oeyBlbWFpbCwgcGFzc3dvcmQgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zdCBtZXNzYWdlID1cbiAgICAgICAgZXJyIGluc3RhbmNlb2YgQXBpUmVxdWVzdEVycm9yXG4gICAgICAgICAgPyBlcnIubWVzc2FnZVxuICAgICAgICAgIDogXCJOYW8gZm9pIHBvc3NpdmVsIHJlYWxpemFyIG8gbG9naW4uXCI7XG4gICAgICBzZXRFcnJvcihtZXNzYWdlKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNTdWJtaXR0aW5nKGZhbHNlKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxQYWdlU2hlbGw+XG4gICAgICA8TG9naW5QYW5lbD5cbiAgICAgICAgPEhlYWRlckdyb3VwPlxuICAgICAgICAgIDxzcGFuPk1pbmkgVGFzayBNYW5hZ2VyPC9zcGFuPlxuICAgICAgICA8L0hlYWRlckdyb3VwPlxuXG4gICAgICAgIDxGb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxuICAgICAgICAgIDxGaWVsZD5cbiAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiZW1haWxcIj5FLW1haWw8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIGlkPVwiZW1haWxcIlxuICAgICAgICAgICAgICBuYW1lPVwiZW1haWxcIlxuICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtlbWFpbH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0RW1haWwoZXZlbnQudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9GaWVsZD5cblxuICAgICAgICAgIDxGaWVsZD5cbiAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicGFzc3dvcmRcIj5TZW5oYTwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgaWQ9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgIG5hbWU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cImN1cnJlbnQtcGFzc3dvcmRcIlxuICAgICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFBhc3N3b3JkKGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvRmllbGQ+XG5cbiAgICAgICAgICB7ZXJyb3IgPyA8RXJyb3JNZXNzYWdlIHJvbGU9XCJhbGVydFwiPntlcnJvcn08L0Vycm9yTWVzc2FnZT4gOiBudWxsfVxuXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ30+XG4gICAgICAgICAgICB7aXNTdWJtaXR0aW5nID8gXCJFbnRyYW5kby4uLlwiIDogXCJFbnRyYXJcIn1cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9Gb3JtPlxuXG4gICAgICAgIDxTd2l0Y2hBdXRoVGV4dD5cbiAgICAgICAgICBOYW8gcG9zc3VpIHVtYSBjb250YT8gPExpbmsgdG89XCIvcmVnaXN0ZXJcIj5DYWRhc3RyZS1zZTwvTGluaz5cbiAgICAgICAgPC9Td2l0Y2hBdXRoVGV4dD5cbiAgICAgIDwvTG9naW5QYW5lbD5cbiAgICA8L1BhZ2VTaGVsbD5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IExvZ2luO1xuIl0sImZpbGUiOiJDOi9Vc2Vycy93YWxsYS9EZXNrdG9wL1Byb2pldG9zLXBlc3NvYWlzL3Byb3ZhLXRlY25pY2EvZnJvbnQtbWluaS10YXNrLW1hbmFnZXIvc3JjL3BhZ2VzL3B1YmxpYy9Mb2dpbi9pbmRleC50c3gifQ==