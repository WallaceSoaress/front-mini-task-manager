import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/teams/TeamStates.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];const _c = __vite__cjsImport0_react_compilerRuntime["c"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=2ae0ea78";
import { Button, StateBox } from "/src/components/tasks/styles.ts";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/teams/TeamStates.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2ae0ea78";
export function EmptyTeamsState(t0) {
	const $ = _c(5);
	if ($[0] !== "9c5cc820bc918a979519c5d26cfc0c7381c8993d19af79af5ab509af48f0b059") {
		for (let $i = 0; $i < 5; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "9c5cc820bc918a979519c5d26cfc0c7381c8993d19af79af5ab509af48f0b059";
	}
	const { onCreate } = t0;
	let t1;
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = /* @__PURE__ */ _jsxDEV("strong", { children: "Nenhum time cadastrado." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 10
		}, this);
		t2 = /* @__PURE__ */ _jsxDEV("span", { children: "Crie o primeiro time para organizar as demandas por equipe." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 10
		}, this);
		$[1] = t1;
		$[2] = t2;
	} else {
		t1 = $[1];
		t2 = $[2];
	}
	let t3;
	if ($[3] !== onCreate) {
		t3 = /* @__PURE__ */ _jsxDEV(StateBox, { children: [
			t1,
			t2,
			/* @__PURE__ */ _jsxDEV(Button, {
				type: "button",
				onClick: onCreate,
				children: "Novo Time"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 28
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 30,
			columnNumber: 10
		}, this);
		$[3] = onCreate;
		$[4] = t3;
	} else {
		t3 = $[4];
	}
	return t3;
}
_c2 = EmptyTeamsState;
var _c2;
$RefreshReg$(_c2, "EmptyTeamsState");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/teams/TeamStates.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/teams/TeamStates.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/teams/TeamStates.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/components/teams/TeamStates.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLFFBQVFDLGdCQUFnQjs7O0FBTWpDLE9BQU8sU0FBQUMsZ0JBQUFDLElBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBeUIsUUFBQUssYUFBQU47Q0FBa0MsSUFBQU87Q0FBQSxJQUFBQztDQUFBLElBQUFQLEVBQUEsT0FBQUcsT0FBQUMsSUFBQTtFQUc1REUsS0FBQSw4Q0FBUSwwQkFBZ0M7Ozs7O0VBQ3hDQyxLQUFBLDRDQUFNLDhEQUFrRTs7Ozs7RUFBQVAsRUFBQSxLQUFBTTtFQUFBTixFQUFBLEtBQUFPO0NBQUE7RUFBQUQsS0FBQU4sRUFBQTtFQUFBTyxLQUFBUCxFQUFBO0NBQUE7Q0FBQSxJQUFBUTtDQUFBLElBQUFSLEVBQUEsT0FBQUssVUFBQTtFQUYxRUcsS0FBQSx3QkFBQyxVQUFEO0dBQ0VGO0dBQ0FDO0dBQ0Esd0JBQUMsUUFBRDtJQUFhO0lBQWtCRjtjQUFVO0dBQWxDOzs7OztFQUhBOzs7OztFQU1FTCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQVE7Q0FBQTtFQUFBQSxLQUFBUixFQUFBO0NBQUE7Q0FBQSxPQU5YUTtBQU1XIiwibmFtZXMiOlsiQnV0dG9uIiwiU3RhdGVCb3giLCJFbXB0eVRlYW1zU3RhdGUiLCJ0MCIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwib25DcmVhdGUiLCJ0MSIsInQyIiwidDMiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVGVhbVN0YXRlcy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQnV0dG9uLCBTdGF0ZUJveCB9IGZyb20gXCIuLi90YXNrcy9zdHlsZXNcIjtcblxudHlwZSBFbXB0eVRlYW1zU3RhdGVQcm9wcyA9IHtcbiAgb25DcmVhdGU6ICgpID0+IHZvaWQ7XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gRW1wdHlUZWFtc1N0YXRlKHsgb25DcmVhdGUgfTogRW1wdHlUZWFtc1N0YXRlUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8U3RhdGVCb3g+XG4gICAgICA8c3Ryb25nPk5lbmh1bSB0aW1lIGNhZGFzdHJhZG8uPC9zdHJvbmc+XG4gICAgICA8c3Bhbj5DcmllIG8gcHJpbWVpcm8gdGltZSBwYXJhIG9yZ2FuaXphciBhcyBkZW1hbmRhcyBwb3IgZXF1aXBlLjwvc3Bhbj5cbiAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e29uQ3JlYXRlfT5cbiAgICAgICAgTm92byBUaW1lXG4gICAgICA8L0J1dHRvbj5cbiAgICA8L1N0YXRlQm94PlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy93YWxsYS9EZXNrdG9wL1Byb2pldG9zLXBlc3NvYWlzL3Byb3ZhLXRlY25pY2EvZnJvbnQtbWluaS10YXNrLW1hbmFnZXIvc3JjL2NvbXBvbmVudHMvdGVhbXMvVGVhbVN0YXRlcy50c3gifQ==