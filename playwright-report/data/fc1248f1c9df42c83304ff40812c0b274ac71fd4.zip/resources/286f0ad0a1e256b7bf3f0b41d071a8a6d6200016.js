import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/private/Tasks/index.tsx");const useMemo = __vite__cjsImport0_react["useMemo"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport13_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport13_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2ae0ea78";
import { ApiRequestError } from "/src/services/api.ts";
import { useAuth } from "/src/hooks/auth.tsx";
import { useCreateTask, useDeleteTask, useTasks, useTeams, useUpdateTask, useUsers } from "/src/hooks/tasks/useTasks.ts";
import { Button, Pagination } from "/src/components/tasks/styles.ts";
import { ConfirmDialog } from "/src/components/tasks/ConfirmDialog.tsx";
import { EmptyState, ErrorState, LoadingState } from "/src/components/tasks/TaskStates.tsx";
import { PrivateNavigation } from "/src/components/layout/PrivateNavigation.tsx";
import { TaskBoard } from "/src/components/tasks/TaskBoard.tsx";
import { TaskDetailsModal } from "/src/components/tasks/TaskDetailsModal.tsx";
import { TaskFilters } from "/src/components/tasks/TaskFilters.tsx";
import { TaskFormModal } from "/src/components/tasks/TaskFormModal.tsx";
import { TasksShell, TopBar, UserInfo } from "/src/pages/private/Tasks/styles.ts";
var _jsxFileName = "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/private/Tasks/index.tsx";
import __vite__cjsImport13_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2ae0ea78";
var _s = $RefreshSig$();
const PAGE_SIZE = 12;
function getErrorMessage(error) {
	if (error instanceof ApiRequestError) {
		return error.message;
	}
	return "Nao foi possivel concluir a operacao.";
}
function taskToRequest(task, status = task.status) {
	return {
		title: task.title,
		description: task.description ?? null,
		status,
		priority: task.priority,
		responsibleId: task.responsible?.id ?? null,
		teamId: task.team.id,
		dueDate: task.dueDate ?? null
	};
}
const Tasks = () => {
	_s();
	const { signOut, user } = useAuth();
	const [filters, setFilters] = useState({});
	const [page, setPage] = useState(0);
	const [formMode, setFormMode] = useState(null);
	const [selectedTask, setSelectedTask] = useState(null);
	const [taskToDelete, setTaskToDelete] = useState(null);
	const [formError, setFormError] = useState("");
	const [boardError, setBoardError] = useState("");
	const taskParams = useMemo(() => ({
		...filters,
		page,
		size: PAGE_SIZE
	}), [filters, page]);
	const tasksQuery = useTasks(taskParams);
	const usersQuery = useUsers();
	const teamsQuery = useTeams();
	const createTask = useCreateTask();
	const updateTask = useUpdateTask();
	const deleteTask = useDeleteTask();
	const users = usersQuery.data ?? [];
	const teams = teamsQuery.data ?? [];
	const taskPage = tasksQuery.data;
	const tasks = taskPage?.content ?? [];
	function handleFilterChange(nextFilters) {
		setFilters(nextFilters);
		setPage(0);
	}
	async function handleSubmitTask(payload) {
		setFormError("");
		try {
			if (formMode?.type === "edit") {
				await updateTask.mutateAsync({
					id: formMode.task.id,
					payload
				});
			} else {
				await createTask.mutateAsync(payload);
			}
			setBoardError("");
			setFormMode(null);
		} catch (error) {
			setFormError(getErrorMessage(error));
		}
	}
	async function handleMoveTask(task, status) {
		setBoardError("");
		try {
			await updateTask.mutateAsync({
				id: task.id,
				payload: taskToRequest(task, status)
			});
		} catch (error_0) {
			setBoardError(getErrorMessage(error_0));
		}
	}
	async function handleDeleteTask() {
		if (!taskToDelete) {
			return;
		}
		await deleteTask.mutateAsync(taskToDelete.id);
		setTaskToDelete(null);
		setSelectedTask(null);
	}
	const isFormLoading = createTask.isPending || updateTask.isPending;
	return /* @__PURE__ */ _jsxDEV(TasksShell, { children: [
		/* @__PURE__ */ _jsxDEV(TopBar, { children: [
			/* @__PURE__ */ _jsxDEV(UserInfo, { children: [/* @__PURE__ */ _jsxDEV("strong", { children: user?.name }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 110,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: user?.email }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 111,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 109,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(PrivateNavigation, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 113,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(Button, {
				type: "button",
				$variant: "ghost",
				onClick: signOut,
				children: "Sair"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 114,
				columnNumber: 9
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 108,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(TaskFilters, {
			filters,
			users,
			isLoadingUsers: usersQuery.isLoading,
			onChange: handleFilterChange,
			onCreate: () => {
				setFormError("");
				setFormMode({ type: "create" });
			}
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 119,
			columnNumber: 7
		}, this),
		teamsQuery.isSuccess && !teams.length ? /* @__PURE__ */ _jsxDEV(ErrorState, { message: "Cadastre um time antes de criar tarefas." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 126,
			columnNumber: 48
		}, this) : null,
		tasksQuery.isLoading ? /* @__PURE__ */ _jsxDEV(LoadingState, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 128,
			columnNumber: 31
		}, this) : null,
		tasksQuery.isError ? /* @__PURE__ */ _jsxDEV(ErrorState, {
			message: getErrorMessage(tasksQuery.error),
			onRetry: () => tasksQuery.refetch()
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 130,
			columnNumber: 29
		}, this) : null,
		boardError ? /* @__PURE__ */ _jsxDEV(ErrorState, { message: boardError }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 132,
			columnNumber: 21
		}, this) : null,
		tasksQuery.isSuccess && tasks.length === 0 ? /* @__PURE__ */ _jsxDEV(EmptyState, { onCreate: () => {
			setFormError("");
			setFormMode({ type: "create" });
		} }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 134,
			columnNumber: 53
		}, this) : null,
		tasksQuery.isSuccess && tasks.length > 0 ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(TaskBoard, {
			tasks,
			onOpenTask: setSelectedTask,
			onMoveTask: handleMoveTask
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 142,
			columnNumber: 11
		}, this), /* @__PURE__ */ _jsxDEV(Pagination, {
			"aria-label": "Paginacao de tarefas",
			children: [
				/* @__PURE__ */ _jsxDEV("span", { children: [
					"Pagina ",
					page + 1,
					" de ",
					taskPage?.totalPages || 1,
					" · ",
					taskPage?.totalElements ?? 0,
					" tarefas"
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 145,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV(Button, {
					type: "button",
					$variant: "ghost",
					onClick: () => setPage((current) => Math.max(0, current - 1)),
					disabled: page === 0,
					children: "Anterior"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 148,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV(Button, {
					type: "button",
					$variant: "ghost",
					onClick: () => setPage((current_0) => current_0 + 1),
					disabled: !taskPage || taskPage.last,
					children: "Proxima"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 151,
					columnNumber: 13
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 144,
			columnNumber: 11
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 141,
			columnNumber: 51
		}, this) : null,
		formMode ? /* @__PURE__ */ _jsxDEV(TaskFormModal, {
			task: formMode.type === "edit" ? formMode.task : null,
			teams,
			apiError: formError,
			isLoading: isFormLoading,
			onClose: () => setFormMode(null),
			onSubmit: handleSubmitTask
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 157,
			columnNumber: 19
		}, this) : null,
		selectedTask ? /* @__PURE__ */ _jsxDEV(TaskDetailsModal, {
			task: selectedTask,
			onClose: () => setSelectedTask(null),
			onEdit: (task_0) => {
				setFormError("");
				setSelectedTask(null);
				setFormMode({
					type: "edit",
					task: task_0
				});
			},
			onDelete: (task_1) => setTaskToDelete(task_1)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 159,
			columnNumber: 23
		}, this) : null,
		taskToDelete ? /* @__PURE__ */ _jsxDEV(ConfirmDialog, {
			title: "Excluir tarefa",
			message: `Tem certeza que deseja excluir "${taskToDelete.title}"?`,
			confirmLabel: "Excluir",
			isLoading: deleteTask.isPending,
			onCancel: () => setTaskToDelete(null),
			onConfirm: handleDeleteTask
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 168,
			columnNumber: 23
		}, this) : null
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 107,
		columnNumber: 10
	}, this);
};
_s(Tasks, "BGU3yLJox7H7O6FIqOWaIx3Vu8E=", false, function() {
	return [
		useAuth,
		useTasks,
		useUsers,
		useTeams,
		useCreateTask,
		useUpdateTask,
		useDeleteTask
	];
});
_c = Tasks;
export default Tasks;
var _c;
$RefreshReg$(_c, "Tasks");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/private/Tasks/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/private/Tasks/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/private/Tasks/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/walla/Desktop/Projetos-pessoais/prova-tecnica/front-mini-task-manager/src/pages/private/Tasks/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsU0FBU0EsU0FBU0MsZ0JBQWdCO0FBQ2xDLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQ0VDLGVBQ0FDLGVBQ0FDLFVBQ0FDLFVBQ0FDLGVBQ0FDLGdCQUNLO0FBRVAsU0FBU0MsUUFBUUMsa0JBQWtCO0FBQ25DLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxZQUFZQyxZQUFZQyxvQkFBb0I7QUFDckQsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxZQUFZQyxRQUFRQyxnQkFBZ0I7Ozs7QUFFN0MsTUFBTUMsWUFBWTtBQU1sQixTQUFTQyxnQkFBZ0JDLE9BQWdCO0NBQ3ZDLElBQUlBLGlCQUFpQnhCLGlCQUFpQjtFQUNwQyxPQUFPd0IsTUFBTUM7Q0FDZjtDQUVBLE9BQU87QUFDVDtBQUVBLFNBQVNDLGNBQWNDLE1BQVlDLFNBQXFCRCxLQUFLQyxRQUFxQjtDQUNoRixPQUFPO0VBQ0xDLE9BQU9GLEtBQUtFO0VBQ1pDLGFBQWFILEtBQUtHLGVBQWU7RUFDakNGO0VBQ0FHLFVBQVVKLEtBQUtJO0VBQ2ZDLGVBQWVMLEtBQUtNLGFBQWFDLE1BQU07RUFDdkNDLFFBQVFSLEtBQUtTLEtBQUtGO0VBQ2xCRyxTQUFTVixLQUFLVSxXQUFXO0NBQzNCO0FBQ0Y7QUFFQSxNQUFNQyxjQUFjOztDQUNsQixNQUFNLEVBQUVDLFNBQVNDLFNBQVN2QyxRQUFRO0NBQ2xDLE1BQU0sQ0FBQ3dDLFNBQVNDLGNBQWMzQyxTQUEwQixDQUFDLENBQUM7Q0FDMUQsTUFBTSxDQUFDNEMsTUFBTUMsV0FBVzdDLFNBQVMsQ0FBQztDQUNsQyxNQUFNLENBQUM4QyxVQUFVQyxlQUFlL0MsU0FBMEIsSUFBSTtDQUM5RCxNQUFNLENBQUNnRCxjQUFjQyxtQkFBbUJqRCxTQUFzQixJQUFJO0NBQ2xFLE1BQU0sQ0FBQ2tELGNBQWNDLG1CQUFtQm5ELFNBQXNCLElBQUk7Q0FDbEUsTUFBTSxDQUFDb0QsV0FBV0MsZ0JBQWdCckQsU0FBUyxFQUFFO0NBQzdDLE1BQU0sQ0FBQ3NELFlBQVlDLGlCQUFpQnZELFNBQVMsRUFBRTtDQUUvQyxNQUFNd0QsYUFBYXpELGVBQ1Y7RUFDTCxHQUFHMkM7RUFDSEU7RUFDQWEsTUFBTWxDO0NBQ1IsSUFDQSxDQUFDbUIsU0FBU0UsSUFBSSxDQUNoQjtDQUVBLE1BQU1jLGFBQWFyRCxTQUFTbUQsVUFBVTtDQUN0QyxNQUFNRyxhQUFhbkQsU0FBUztDQUM1QixNQUFNb0QsYUFBYXRELFNBQVM7Q0FDNUIsTUFBTXVELGFBQWExRCxjQUFjO0NBQ2pDLE1BQU0yRCxhQUFhdkQsY0FBYztDQUNqQyxNQUFNd0QsYUFBYTNELGNBQWM7Q0FFakMsTUFBTTRELFFBQVFMLFdBQVdNLFFBQVE7Q0FDakMsTUFBTUMsUUFBUU4sV0FBV0ssUUFBUTtDQUNqQyxNQUFNRSxXQUFXVCxXQUFXTztDQUM1QixNQUFNRyxRQUFRRCxVQUFVRSxXQUFXO0NBRW5DLFNBQVNDLG1CQUFtQkMsYUFBOEI7RUFDeEQ1QixXQUFXNEIsV0FBVztFQUN0QjFCLFFBQVEsQ0FBQztDQUNYO0NBRUEsZUFBZTJCLGlCQUFpQkMsU0FBc0I7RUFDcERwQixhQUFhLEVBQUU7RUFFZixJQUFJO0dBQ0YsSUFBSVAsVUFBVTRCLFNBQVMsUUFBUTtJQUM3QixNQUFNWixXQUFXYSxZQUFZO0tBQUV4QyxJQUFJVyxTQUFTbEIsS0FBS087S0FBSXNDO0lBQVEsQ0FBQztHQUNoRSxPQUFPO0lBQ0wsTUFBTVosV0FBV2MsWUFBWUYsT0FBTztHQUN0QztHQUNBbEIsY0FBYyxFQUFFO0dBQ2hCUixZQUFZLElBQUk7RUFDbEIsU0FBU3RCLE9BQU87R0FDZDRCLGFBQWE3QixnQkFBZ0JDLEtBQUssQ0FBQztFQUNyQztDQUNGO0NBRUEsZUFBZW1ELGVBQWVoRCxNQUFZQyxRQUFvQjtFQUM1RDBCLGNBQWMsRUFBRTtFQUVoQixJQUFJO0dBQ0YsTUFBTU8sV0FBV2EsWUFBWTtJQUFFeEMsSUFBSVAsS0FBS087SUFBSXNDLFNBQVM5QyxjQUFjQyxNQUFNQyxNQUFNO0dBQUUsQ0FBQztFQUNwRixTQUFTSixTQUFPO0dBQ2Q4QixjQUFjL0IsZ0JBQWdCQyxPQUFLLENBQUM7RUFDdEM7Q0FDRjtDQUVBLGVBQWVvRCxtQkFBbUI7RUFDaEMsSUFBSSxDQUFDM0IsY0FBYztHQUNqQjtFQUNGO0VBRUEsTUFBTWEsV0FBV1ksWUFBWXpCLGFBQWFmLEVBQUU7RUFDNUNnQixnQkFBZ0IsSUFBSTtFQUNwQkYsZ0JBQWdCLElBQUk7Q0FDdEI7Q0FFQSxNQUFNNkIsZ0JBQWdCakIsV0FBV2tCLGFBQWFqQixXQUFXaUI7Q0FFekQsT0FDRSx3QkFBQyxZQUFEO0VBQ0Usd0JBQUMsUUFBRDtHQUNFLHdCQUFDLFVBQUQsYUFDRSx3QkFBQyxVQUFELFlBQVN0QyxNQUFNdUMsS0FBYTs7OzthQUM1Qix3QkFBQyxRQUFELFlBQU92QyxNQUFNd0MsTUFBWTs7OztXQUNqQjs7Ozs7R0FDVix3QkFBQyxtQkFBRCxDQUFrQjs7Ozs7R0FDbEIsd0JBQUMsUUFBRDtJQUFRLE1BQUs7SUFBUyxVQUFTO0lBQVEsU0FBU3pDO2NBQVE7R0FFaEQ7Ozs7O0VBQ0Y7Ozs7O0VBRVIsd0JBQUMsYUFBRDtHQUNXRTtHQUNGc0I7R0FDUCxnQkFBZ0JMLFdBQVd1QjtHQUMzQixVQUFVWjtHQUNWLGdCQUFnQjtJQUNkakIsYUFBYSxFQUFFO0lBQ2ZOLFlBQVksRUFBRTJCLE1BQU0sU0FBUyxDQUFDO0dBQ2hDO0VBQUU7Ozs7O0VBR0hkLFdBQVd1QixhQUFhLENBQUNqQixNQUFNa0IsU0FDOUIsd0JBQUMsWUFBRCxFQUFZLFNBQVEsMkNBQTBDOzs7O2FBQzVEO0VBRUgxQixXQUFXd0IsWUFBWSx3QkFBQyxjQUFELENBQWE7Ozs7YUFBTTtFQUUxQ3hCLFdBQVcyQixVQUNWLHdCQUFDLFlBQUQ7R0FBWSxTQUFTN0QsZ0JBQWdCa0MsV0FBV2pDLEtBQUs7R0FBRyxlQUFlaUMsV0FBVzRCLFFBQVE7RUFBRTs7OzthQUMxRjtFQUVIaEMsYUFBYSx3QkFBQyxZQUFELEVBQVksU0FBU0EsV0FBVzs7OzthQUFNO0VBRW5ESSxXQUFXeUIsYUFBYWYsTUFBTWdCLFdBQVcsSUFDeEMsd0JBQUMsWUFBRCxFQUNFLGdCQUFnQjtHQUNkL0IsYUFBYSxFQUFFO0dBQ2ZOLFlBQVksRUFBRTJCLE1BQU0sU0FBUyxDQUFDO0VBQ2hDLEVBQUU7Ozs7YUFFRjtFQUVIaEIsV0FBV3lCLGFBQWFmLE1BQU1nQixTQUFTLElBQ3RDLGdEQUNFLHdCQUFDLFdBQUQ7R0FBa0JoQjtHQUFPLFlBQVluQjtHQUFpQixZQUFZMkI7RUFBZTs7OztZQUVqRix3QkFBQyxZQUFEO0dBQVksY0FBVzthQUF2QjtJQUNFLHdCQUFDLFFBQUQ7S0FBSztLQUNLaEMsT0FBTztLQUFFO0tBQUt1QixVQUFVb0IsY0FBYztLQUFFO0tBQUlwQixVQUFVcUIsaUJBQWlCO0tBQUU7SUFDN0U7Ozs7O0lBQ04sd0JBQUMsUUFBRDtLQUFRLE1BQUs7S0FBUyxVQUFTO0tBQVEsZUFBZTNDLFNBQVM0QyxZQUFZQyxLQUFLQyxJQUFJLEdBQUdGLFVBQVUsQ0FBQyxDQUFDO0tBQUcsVUFBVTdDLFNBQVM7ZUFBRTtJQUVuSDs7Ozs7SUFDUix3QkFBQyxRQUFEO0tBQ0UsTUFBSztLQUNMLFVBQVM7S0FDVCxlQUFlQyxTQUFTNEMsY0FBWUEsWUFBVSxDQUFDO0tBQy9DLFVBQVUsQ0FBQ3RCLFlBQVlBLFNBQVN5QjtlQUFLO0lBRy9COzs7OztHQUNFOzs7OztVQUNkOzs7O2FBQ0U7RUFFSDlDLFdBQ0Msd0JBQUMsZUFBRDtHQUNFLE1BQU1BLFNBQVM0QixTQUFTLFNBQVM1QixTQUFTbEIsT0FBTztHQUMxQ3NDO0dBQ1AsVUFBVWQ7R0FDVixXQUFXMEI7R0FDWCxlQUFlL0IsWUFBWSxJQUFJO0dBQy9CLFVBQVV5QjtFQUFpQjs7OzthQUUzQjtFQUVIeEIsZUFDQyx3QkFBQyxrQkFBRDtHQUNFLE1BQU1BO0dBQ04sZUFBZUMsZ0JBQWdCLElBQUk7R0FDbkMsU0FBU3JCLFdBQVM7SUFDaEJ5QixhQUFhLEVBQUU7SUFDZkosZ0JBQWdCLElBQUk7SUFDcEJGLFlBQVk7S0FBRTJCLE1BQU07S0FBUTlDO0lBQUssQ0FBQztHQUNwQztHQUNBLFdBQVdBLFdBQVN1QixnQkFBZ0J2QixNQUFJO0VBQUU7Ozs7YUFFMUM7RUFFSHNCLGVBQ0Msd0JBQUMsZUFBRDtHQUNFLE9BQU07R0FDTixTQUFTLG1DQUFtQ0EsYUFBYXBCLE1BQUs7R0FDOUQsY0FBYTtHQUNiLFdBQVdpQyxXQUFXZ0I7R0FDdEIsZ0JBQWdCNUIsZ0JBQWdCLElBQUk7R0FDcEMsV0FBVzBCO0VBQWlCOzs7O2FBRTVCO0NBQ007Ozs7O0FBRWhCOzs7Ozs7Ozs7Ozs7O0FBRUEsZUFBZXRDIiwibmFtZXMiOlsidXNlTWVtbyIsInVzZVN0YXRlIiwiQXBpUmVxdWVzdEVycm9yIiwidXNlQXV0aCIsInVzZUNyZWF0ZVRhc2siLCJ1c2VEZWxldGVUYXNrIiwidXNlVGFza3MiLCJ1c2VUZWFtcyIsInVzZVVwZGF0ZVRhc2siLCJ1c2VVc2VycyIsIkJ1dHRvbiIsIlBhZ2luYXRpb24iLCJDb25maXJtRGlhbG9nIiwiRW1wdHlTdGF0ZSIsIkVycm9yU3RhdGUiLCJMb2FkaW5nU3RhdGUiLCJQcml2YXRlTmF2aWdhdGlvbiIsIlRhc2tCb2FyZCIsIlRhc2tEZXRhaWxzTW9kYWwiLCJUYXNrRmlsdGVycyIsIlRhc2tGb3JtTW9kYWwiLCJUYXNrc1NoZWxsIiwiVG9wQmFyIiwiVXNlckluZm8iLCJQQUdFX1NJWkUiLCJnZXRFcnJvck1lc3NhZ2UiLCJlcnJvciIsIm1lc3NhZ2UiLCJ0YXNrVG9SZXF1ZXN0IiwidGFzayIsInN0YXR1cyIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJwcmlvcml0eSIsInJlc3BvbnNpYmxlSWQiLCJyZXNwb25zaWJsZSIsImlkIiwidGVhbUlkIiwidGVhbSIsImR1ZURhdGUiLCJUYXNrcyIsInNpZ25PdXQiLCJ1c2VyIiwiZmlsdGVycyIsInNldEZpbHRlcnMiLCJwYWdlIiwic2V0UGFnZSIsImZvcm1Nb2RlIiwic2V0Rm9ybU1vZGUiLCJzZWxlY3RlZFRhc2siLCJzZXRTZWxlY3RlZFRhc2siLCJ0YXNrVG9EZWxldGUiLCJzZXRUYXNrVG9EZWxldGUiLCJmb3JtRXJyb3IiLCJzZXRGb3JtRXJyb3IiLCJib2FyZEVycm9yIiwic2V0Qm9hcmRFcnJvciIsInRhc2tQYXJhbXMiLCJzaXplIiwidGFza3NRdWVyeSIsInVzZXJzUXVlcnkiLCJ0ZWFtc1F1ZXJ5IiwiY3JlYXRlVGFzayIsInVwZGF0ZVRhc2siLCJkZWxldGVUYXNrIiwidXNlcnMiLCJkYXRhIiwidGVhbXMiLCJ0YXNrUGFnZSIsInRhc2tzIiwiY29udGVudCIsImhhbmRsZUZpbHRlckNoYW5nZSIsIm5leHRGaWx0ZXJzIiwiaGFuZGxlU3VibWl0VGFzayIsInBheWxvYWQiLCJ0eXBlIiwibXV0YXRlQXN5bmMiLCJoYW5kbGVNb3ZlVGFzayIsImhhbmRsZURlbGV0ZVRhc2siLCJpc0Zvcm1Mb2FkaW5nIiwiaXNQZW5kaW5nIiwibmFtZSIsImVtYWlsIiwiaXNMb2FkaW5nIiwiaXNTdWNjZXNzIiwibGVuZ3RoIiwiaXNFcnJvciIsInJlZmV0Y2giLCJ0b3RhbFBhZ2VzIiwidG90YWxFbGVtZW50cyIsImN1cnJlbnQiLCJNYXRoIiwibWF4IiwibGFzdCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEFwaVJlcXVlc3RFcnJvciB9IGZyb20gXCIuLi8uLi8uLi9zZXJ2aWNlcy9hcGlcIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vLi4vLi4vaG9va3MvYXV0aFwiO1xuaW1wb3J0IHtcbiAgdXNlQ3JlYXRlVGFzayxcbiAgdXNlRGVsZXRlVGFzayxcbiAgdXNlVGFza3MsXG4gIHVzZVRlYW1zLFxuICB1c2VVcGRhdGVUYXNrLFxuICB1c2VVc2Vycyxcbn0gZnJvbSBcIi4uLy4uLy4uL2hvb2tzL3Rhc2tzL3VzZVRhc2tzXCI7XG5pbXBvcnQgdHlwZSB7IFRhc2ssIFRhc2tGaWx0ZXJzIGFzIFRhc2tGaWx0ZXJzRGF0YSwgVGFza1JlcXVlc3QsIFRhc2tTdGF0dXMgfSBmcm9tIFwiLi4vLi4vLi4vaW50ZXJmYWNlcy90YXNrcy90YXNrXCI7XG5pbXBvcnQgeyBCdXR0b24sIFBhZ2luYXRpb24gfSBmcm9tIFwiLi4vLi4vLi4vY29tcG9uZW50cy90YXNrcy9zdHlsZXNcIjtcbmltcG9ydCB7IENvbmZpcm1EaWFsb2cgfSBmcm9tIFwiLi4vLi4vLi4vY29tcG9uZW50cy90YXNrcy9Db25maXJtRGlhbG9nXCI7XG5pbXBvcnQgeyBFbXB0eVN0YXRlLCBFcnJvclN0YXRlLCBMb2FkaW5nU3RhdGUgfSBmcm9tIFwiLi4vLi4vLi4vY29tcG9uZW50cy90YXNrcy9UYXNrU3RhdGVzXCI7XG5pbXBvcnQgeyBQcml2YXRlTmF2aWdhdGlvbiB9IGZyb20gXCIuLi8uLi8uLi9jb21wb25lbnRzL2xheW91dC9Qcml2YXRlTmF2aWdhdGlvblwiO1xuaW1wb3J0IHsgVGFza0JvYXJkIH0gZnJvbSBcIi4uLy4uLy4uL2NvbXBvbmVudHMvdGFza3MvVGFza0JvYXJkXCI7XG5pbXBvcnQgeyBUYXNrRGV0YWlsc01vZGFsIH0gZnJvbSBcIi4uLy4uLy4uL2NvbXBvbmVudHMvdGFza3MvVGFza0RldGFpbHNNb2RhbFwiO1xuaW1wb3J0IHsgVGFza0ZpbHRlcnMgfSBmcm9tIFwiLi4vLi4vLi4vY29tcG9uZW50cy90YXNrcy9UYXNrRmlsdGVyc1wiO1xuaW1wb3J0IHsgVGFza0Zvcm1Nb2RhbCB9IGZyb20gXCIuLi8uLi8uLi9jb21wb25lbnRzL3Rhc2tzL1Rhc2tGb3JtTW9kYWxcIjtcbmltcG9ydCB7IFRhc2tzU2hlbGwsIFRvcEJhciwgVXNlckluZm8gfSBmcm9tIFwiLi9zdHlsZXNcIjtcblxuY29uc3QgUEFHRV9TSVpFID0gMTI7XG5cbnR5cGUgRm9ybU1vZGUgPVxuICB8IHsgdHlwZTogXCJjcmVhdGVcIiB9XG4gIHwgeyB0eXBlOiBcImVkaXRcIjsgdGFzazogVGFzayB9O1xuXG5mdW5jdGlvbiBnZXRFcnJvck1lc3NhZ2UoZXJyb3I6IHVua25vd24pIHtcbiAgaWYgKGVycm9yIGluc3RhbmNlb2YgQXBpUmVxdWVzdEVycm9yKSB7XG4gICAgcmV0dXJuIGVycm9yLm1lc3NhZ2U7XG4gIH1cblxuICByZXR1cm4gXCJOYW8gZm9pIHBvc3NpdmVsIGNvbmNsdWlyIGEgb3BlcmFjYW8uXCI7XG59XG5cbmZ1bmN0aW9uIHRhc2tUb1JlcXVlc3QodGFzazogVGFzaywgc3RhdHVzOiBUYXNrU3RhdHVzID0gdGFzay5zdGF0dXMpOiBUYXNrUmVxdWVzdCB7XG4gIHJldHVybiB7XG4gICAgdGl0bGU6IHRhc2sudGl0bGUsXG4gICAgZGVzY3JpcHRpb246IHRhc2suZGVzY3JpcHRpb24gPz8gbnVsbCxcbiAgICBzdGF0dXMsXG4gICAgcHJpb3JpdHk6IHRhc2sucHJpb3JpdHksXG4gICAgcmVzcG9uc2libGVJZDogdGFzay5yZXNwb25zaWJsZT8uaWQgPz8gbnVsbCxcbiAgICB0ZWFtSWQ6IHRhc2sudGVhbS5pZCxcbiAgICBkdWVEYXRlOiB0YXNrLmR1ZURhdGUgPz8gbnVsbCxcbiAgfTtcbn1cblxuY29uc3QgVGFza3MgPSAoKSA9PiB7XG4gIGNvbnN0IHsgc2lnbk91dCwgdXNlciB9ID0gdXNlQXV0aCgpO1xuICBjb25zdCBbZmlsdGVycywgc2V0RmlsdGVyc10gPSB1c2VTdGF0ZTxUYXNrRmlsdGVyc0RhdGE+KHt9KTtcbiAgY29uc3QgW3BhZ2UsIHNldFBhZ2VdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtmb3JtTW9kZSwgc2V0Rm9ybU1vZGVdID0gdXNlU3RhdGU8Rm9ybU1vZGUgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3NlbGVjdGVkVGFzaywgc2V0U2VsZWN0ZWRUYXNrXSA9IHVzZVN0YXRlPFRhc2sgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3Rhc2tUb0RlbGV0ZSwgc2V0VGFza1RvRGVsZXRlXSA9IHVzZVN0YXRlPFRhc2sgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2Zvcm1FcnJvciwgc2V0Rm9ybUVycm9yXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbYm9hcmRFcnJvciwgc2V0Qm9hcmRFcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcblxuICBjb25zdCB0YXNrUGFyYW1zID0gdXNlTWVtbyhcbiAgICAoKSA9PiAoe1xuICAgICAgLi4uZmlsdGVycyxcbiAgICAgIHBhZ2UsXG4gICAgICBzaXplOiBQQUdFX1NJWkUsXG4gICAgfSksXG4gICAgW2ZpbHRlcnMsIHBhZ2VdLFxuICApO1xuXG4gIGNvbnN0IHRhc2tzUXVlcnkgPSB1c2VUYXNrcyh0YXNrUGFyYW1zKTtcbiAgY29uc3QgdXNlcnNRdWVyeSA9IHVzZVVzZXJzKCk7XG4gIGNvbnN0IHRlYW1zUXVlcnkgPSB1c2VUZWFtcygpO1xuICBjb25zdCBjcmVhdGVUYXNrID0gdXNlQ3JlYXRlVGFzaygpO1xuICBjb25zdCB1cGRhdGVUYXNrID0gdXNlVXBkYXRlVGFzaygpO1xuICBjb25zdCBkZWxldGVUYXNrID0gdXNlRGVsZXRlVGFzaygpO1xuXG4gIGNvbnN0IHVzZXJzID0gdXNlcnNRdWVyeS5kYXRhID8/IFtdO1xuICBjb25zdCB0ZWFtcyA9IHRlYW1zUXVlcnkuZGF0YSA/PyBbXTtcbiAgY29uc3QgdGFza1BhZ2UgPSB0YXNrc1F1ZXJ5LmRhdGE7XG4gIGNvbnN0IHRhc2tzID0gdGFza1BhZ2U/LmNvbnRlbnQgPz8gW107XG5cbiAgZnVuY3Rpb24gaGFuZGxlRmlsdGVyQ2hhbmdlKG5leHRGaWx0ZXJzOiBUYXNrRmlsdGVyc0RhdGEpIHtcbiAgICBzZXRGaWx0ZXJzKG5leHRGaWx0ZXJzKTtcbiAgICBzZXRQYWdlKDApO1xuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlU3VibWl0VGFzayhwYXlsb2FkOiBUYXNrUmVxdWVzdCkge1xuICAgIHNldEZvcm1FcnJvcihcIlwiKTtcblxuICAgIHRyeSB7XG4gICAgICBpZiAoZm9ybU1vZGU/LnR5cGUgPT09IFwiZWRpdFwiKSB7XG4gICAgICAgIGF3YWl0IHVwZGF0ZVRhc2subXV0YXRlQXN5bmMoeyBpZDogZm9ybU1vZGUudGFzay5pZCwgcGF5bG9hZCB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGF3YWl0IGNyZWF0ZVRhc2subXV0YXRlQXN5bmMocGF5bG9hZCk7XG4gICAgICB9XG4gICAgICBzZXRCb2FyZEVycm9yKFwiXCIpO1xuICAgICAgc2V0Rm9ybU1vZGUobnVsbCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHNldEZvcm1FcnJvcihnZXRFcnJvck1lc3NhZ2UoZXJyb3IpKTtcbiAgICB9XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVNb3ZlVGFzayh0YXNrOiBUYXNrLCBzdGF0dXM6IFRhc2tTdGF0dXMpIHtcbiAgICBzZXRCb2FyZEVycm9yKFwiXCIpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHVwZGF0ZVRhc2subXV0YXRlQXN5bmMoeyBpZDogdGFzay5pZCwgcGF5bG9hZDogdGFza1RvUmVxdWVzdCh0YXNrLCBzdGF0dXMpIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBzZXRCb2FyZEVycm9yKGdldEVycm9yTWVzc2FnZShlcnJvcikpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZURlbGV0ZVRhc2soKSB7XG4gICAgaWYgKCF0YXNrVG9EZWxldGUpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBhd2FpdCBkZWxldGVUYXNrLm11dGF0ZUFzeW5jKHRhc2tUb0RlbGV0ZS5pZCk7XG4gICAgc2V0VGFza1RvRGVsZXRlKG51bGwpO1xuICAgIHNldFNlbGVjdGVkVGFzayhudWxsKTtcbiAgfVxuXG4gIGNvbnN0IGlzRm9ybUxvYWRpbmcgPSBjcmVhdGVUYXNrLmlzUGVuZGluZyB8fCB1cGRhdGVUYXNrLmlzUGVuZGluZztcblxuICByZXR1cm4gKFxuICAgIDxUYXNrc1NoZWxsPlxuICAgICAgPFRvcEJhcj5cbiAgICAgICAgPFVzZXJJbmZvPlxuICAgICAgICAgIDxzdHJvbmc+e3VzZXI/Lm5hbWV9PC9zdHJvbmc+XG4gICAgICAgICAgPHNwYW4+e3VzZXI/LmVtYWlsfTwvc3Bhbj5cbiAgICAgICAgPC9Vc2VySW5mbz5cbiAgICAgICAgPFByaXZhdGVOYXZpZ2F0aW9uIC8+XG4gICAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiICR2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXtzaWduT3V0fT5cbiAgICAgICAgICBTYWlyXG4gICAgICAgIDwvQnV0dG9uPlxuICAgICAgPC9Ub3BCYXI+XG5cbiAgICAgIDxUYXNrRmlsdGVyc1xuICAgICAgICBmaWx0ZXJzPXtmaWx0ZXJzfVxuICAgICAgICB1c2Vycz17dXNlcnN9XG4gICAgICAgIGlzTG9hZGluZ1VzZXJzPXt1c2Vyc1F1ZXJ5LmlzTG9hZGluZ31cbiAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbHRlckNoYW5nZX1cbiAgICAgICAgb25DcmVhdGU9eygpID0+IHtcbiAgICAgICAgICBzZXRGb3JtRXJyb3IoXCJcIik7XG4gICAgICAgICAgc2V0Rm9ybU1vZGUoeyB0eXBlOiBcImNyZWF0ZVwiIH0pO1xuICAgICAgICB9fVxuICAgICAgLz5cblxuICAgICAge3RlYW1zUXVlcnkuaXNTdWNjZXNzICYmICF0ZWFtcy5sZW5ndGggPyAoXG4gICAgICAgIDxFcnJvclN0YXRlIG1lc3NhZ2U9XCJDYWRhc3RyZSB1bSB0aW1lIGFudGVzIGRlIGNyaWFyIHRhcmVmYXMuXCIgLz5cbiAgICAgICkgOiBudWxsfVxuXG4gICAgICB7dGFza3NRdWVyeS5pc0xvYWRpbmcgPyA8TG9hZGluZ1N0YXRlIC8+IDogbnVsbH1cblxuICAgICAge3Rhc2tzUXVlcnkuaXNFcnJvciA/IChcbiAgICAgICAgPEVycm9yU3RhdGUgbWVzc2FnZT17Z2V0RXJyb3JNZXNzYWdlKHRhc2tzUXVlcnkuZXJyb3IpfSBvblJldHJ5PXsoKSA9PiB0YXNrc1F1ZXJ5LnJlZmV0Y2goKX0gLz5cbiAgICAgICkgOiBudWxsfVxuXG4gICAgICB7Ym9hcmRFcnJvciA/IDxFcnJvclN0YXRlIG1lc3NhZ2U9e2JvYXJkRXJyb3J9IC8+IDogbnVsbH1cblxuICAgICAge3Rhc2tzUXVlcnkuaXNTdWNjZXNzICYmIHRhc2tzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgPEVtcHR5U3RhdGVcbiAgICAgICAgICBvbkNyZWF0ZT17KCkgPT4ge1xuICAgICAgICAgICAgc2V0Rm9ybUVycm9yKFwiXCIpO1xuICAgICAgICAgICAgc2V0Rm9ybU1vZGUoeyB0eXBlOiBcImNyZWF0ZVwiIH0pO1xuICAgICAgICAgIH19XG4gICAgICAgIC8+XG4gICAgICApIDogbnVsbH1cblxuICAgICAge3Rhc2tzUXVlcnkuaXNTdWNjZXNzICYmIHRhc2tzLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgIDw+XG4gICAgICAgICAgPFRhc2tCb2FyZCB0YXNrcz17dGFza3N9IG9uT3BlblRhc2s9e3NldFNlbGVjdGVkVGFza30gb25Nb3ZlVGFzaz17aGFuZGxlTW92ZVRhc2t9IC8+XG5cbiAgICAgICAgICA8UGFnaW5hdGlvbiBhcmlhLWxhYmVsPVwiUGFnaW5hY2FvIGRlIHRhcmVmYXNcIj5cbiAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICBQYWdpbmEge3BhZ2UgKyAxfSBkZSB7dGFza1BhZ2U/LnRvdGFsUGFnZXMgfHwgMX0gwrcge3Rhc2tQYWdlPy50b3RhbEVsZW1lbnRzID8/IDB9IHRhcmVmYXNcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiICR2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXsoKSA9PiBzZXRQYWdlKChjdXJyZW50KSA9PiBNYXRoLm1heCgwLCBjdXJyZW50IC0gMSkpfSBkaXNhYmxlZD17cGFnZSA9PT0gMH0+XG4gICAgICAgICAgICAgIEFudGVyaW9yXG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICR2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRQYWdlKChjdXJyZW50KSA9PiBjdXJyZW50ICsgMSl9XG4gICAgICAgICAgICAgIGRpc2FibGVkPXshdGFza1BhZ2UgfHwgdGFza1BhZ2UubGFzdH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgUHJveGltYVxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9QYWdpbmF0aW9uPlxuICAgICAgICA8Lz5cbiAgICAgICkgOiBudWxsfVxuXG4gICAgICB7Zm9ybU1vZGUgPyAoXG4gICAgICAgIDxUYXNrRm9ybU1vZGFsXG4gICAgICAgICAgdGFzaz17Zm9ybU1vZGUudHlwZSA9PT0gXCJlZGl0XCIgPyBmb3JtTW9kZS50YXNrIDogbnVsbH1cbiAgICAgICAgICB0ZWFtcz17dGVhbXN9XG4gICAgICAgICAgYXBpRXJyb3I9e2Zvcm1FcnJvcn1cbiAgICAgICAgICBpc0xvYWRpbmc9e2lzRm9ybUxvYWRpbmd9XG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0Rm9ybU1vZGUobnVsbCl9XG4gICAgICAgICAgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdFRhc2t9XG4gICAgICAgIC8+XG4gICAgICApIDogbnVsbH1cblxuICAgICAge3NlbGVjdGVkVGFzayA/IChcbiAgICAgICAgPFRhc2tEZXRhaWxzTW9kYWxcbiAgICAgICAgICB0YXNrPXtzZWxlY3RlZFRhc2t9XG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2VsZWN0ZWRUYXNrKG51bGwpfVxuICAgICAgICAgIG9uRWRpdD17KHRhc2spID0+IHtcbiAgICAgICAgICAgIHNldEZvcm1FcnJvcihcIlwiKTtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkVGFzayhudWxsKTtcbiAgICAgICAgICAgIHNldEZvcm1Nb2RlKHsgdHlwZTogXCJlZGl0XCIsIHRhc2sgfSk7XG4gICAgICAgICAgfX1cbiAgICAgICAgICBvbkRlbGV0ZT17KHRhc2spID0+IHNldFRhc2tUb0RlbGV0ZSh0YXNrKX1cbiAgICAgICAgLz5cbiAgICAgICkgOiBudWxsfVxuXG4gICAgICB7dGFza1RvRGVsZXRlID8gKFxuICAgICAgICA8Q29uZmlybURpYWxvZ1xuICAgICAgICAgIHRpdGxlPVwiRXhjbHVpciB0YXJlZmFcIlxuICAgICAgICAgIG1lc3NhZ2U9e2BUZW0gY2VydGV6YSBxdWUgZGVzZWphIGV4Y2x1aXIgXCIke3Rhc2tUb0RlbGV0ZS50aXRsZX1cIj9gfVxuICAgICAgICAgIGNvbmZpcm1MYWJlbD1cIkV4Y2x1aXJcIlxuICAgICAgICAgIGlzTG9hZGluZz17ZGVsZXRlVGFzay5pc1BlbmRpbmd9XG4gICAgICAgICAgb25DYW5jZWw9eygpID0+IHNldFRhc2tUb0RlbGV0ZShudWxsKX1cbiAgICAgICAgICBvbkNvbmZpcm09e2hhbmRsZURlbGV0ZVRhc2t9XG4gICAgICAgIC8+XG4gICAgICApIDogbnVsbH1cbiAgICA8L1Rhc2tzU2hlbGw+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBUYXNrcztcbiJdLCJmaWxlIjoiQzovVXNlcnMvd2FsbGEvRGVza3RvcC9Qcm9qZXRvcy1wZXNzb2Fpcy9wcm92YS10ZWNuaWNhL2Zyb250LW1pbmktdGFzay1tYW5hZ2VyL3NyYy9wYWdlcy9wcml2YXRlL1Rhc2tzL2luZGV4LnRzeCJ9