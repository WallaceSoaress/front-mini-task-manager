import styled from "/node_modules/.vite/deps/styled-components.js?v=85d7ad7c";
export const PageShell = styled.main`
  min-height: 100svh;
  width: 100%;
  display: grid;
  place-items: center;
  padding: 32px 16px;
  box-sizing: border-box;
  background:
    linear-gradient(135deg, rgba(67, 190, 198, 0.12), rgba(21, 119, 67, 0.08)),
    ${({ theme }) => theme.colors.background};
`;
export const LoginPanel = styled.section`
  width: min(100%, 420px);
  border: 1px solid ${({ theme }) => theme.colors.border};
  border-radius: 8px;
  padding: 32px;
  box-sizing: border-box;
  background: ${({ theme }) => theme.colors.white};
  box-shadow: 0 18px 50px rgba(41, 67, 78, 0.12);
  text-align: left;
`;
export const HeaderGroup = styled.header`
  display: grid;
  gap: 8px;
  margin-bottom: 28px;

  span {
    color: ${({ theme }) => theme.colors.primary_dark};
    font-size: ${({ theme }) => theme.fonts.size.small};
    font-weight: 700;
    text-transform: uppercase;
  }

  h1 {
    margin: 0;
  }
`;
export const Form = styled.form`
  display: grid;
  gap: 18px;

  button {
    min-height: 48px;
    border: 0;
    border-radius: 8px;
    background: ${({ theme }) => theme.colors.primary_dark};
    color: ${({ theme }) => theme.colors.text_white};
    cursor: pointer;
    font: inherit;
    font-weight: 700;
  }

  button:disabled {
    cursor: not-allowed;
    opacity: 0.65;
  }
`;
export const Field = styled.div`
  display: grid;
  gap: 8px;

  label {
    color: ${({ theme }) => theme.colors.text_black};
    font-size: ${({ theme }) => theme.fonts.size.small};
    font-weight: 700;
  }

  input {
    min-height: 46px;
    border: 1px solid ${({ theme }) => theme.colors.border};
    border-radius: 8px;
    padding: 0 14px;
    color: ${({ theme }) => theme.colors.text_black};
    background: ${({ theme }) => theme.colors.white};
    font: inherit;
    box-sizing: border-box;
  }

  input:focus {
    border-color: ${({ theme }) => theme.colors.primary_dark};
    outline: 3px solid rgba(67, 190, 198, 0.18);
  }
`;
export const ErrorMessage = styled.p`
  border-radius: 8px;
  padding: 12px 14px;
  margin: 0;
  color: ${({ theme }) => theme.colors.danger};
  background: ${({ theme }) => theme.colors.error_light};
  font-size: ${({ theme }) => theme.fonts.size.small};
`;
export const SuccessMessage = styled.p`
  border-radius: 8px;
  padding: 12px 14px;
  margin: 0;
  color: ${({ theme }) => theme.colors.success};
  background: ${({ theme }) => theme.colors.success_light};
  font-size: ${({ theme }) => theme.fonts.size.small};
`;
export const SwitchAuthText = styled.p`
  margin: 18px 0 0;
  color: ${({ theme }) => theme.colors.dark};
  font-size: ${({ theme }) => theme.fonts.size.small};
  text-align: center;

  a {
    color: ${({ theme }) => theme.colors.primary_dark};
    font-weight: 700;
    text-decoration: none;
  }

  a:focus,
  a:hover {
    text-decoration: underline;
  }
`;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsT0FBT0EsWUFBWTtBQUVuQixPQUFPLE1BQU1DLFlBQVlELE9BQU9FLElBQUk7Ozs7Ozs7OztPQVM3QixFQUFFQyxZQUFZQSxNQUFNQyxPQUFPQyxXQUFVOztBQUc1QyxPQUFPLE1BQU1DLGFBQWFOLE9BQU9PLE9BQU87O3VCQUVqQixFQUFFSixZQUFZQSxNQUFNQyxPQUFPSSxPQUFNOzs7O2lCQUl2QyxFQUFFTCxZQUFZQSxNQUFNQyxPQUFPSyxNQUFLOzs7O0FBS2pELE9BQU8sTUFBTUMsY0FBY1YsT0FBT1csTUFBTTs7Ozs7O2NBTTFCLEVBQUVSLFlBQVlBLE1BQU1DLE9BQU9RLGFBQVk7a0JBQ25DLEVBQUVULFlBQVlBLE1BQU1VLE1BQU1DLEtBQUtDLE1BQUs7Ozs7Ozs7OztBQVV0RCxPQUFPLE1BQU1DLE9BQU9oQixPQUFPaUIsSUFBSTs7Ozs7Ozs7bUJBUVosRUFBRWQsWUFBWUEsTUFBTUMsT0FBT1EsYUFBWTtjQUM1QyxFQUFFVCxZQUFZQSxNQUFNQyxPQUFPYyxXQUFVOzs7Ozs7Ozs7OztBQVluRCxPQUFPLE1BQU1DLFFBQVFuQixPQUFPb0IsR0FBRzs7Ozs7Y0FLakIsRUFBRWpCLFlBQVlBLE1BQU1DLE9BQU9pQixXQUFVO2tCQUNqQyxFQUFFbEIsWUFBWUEsTUFBTVUsTUFBTUMsS0FBS0MsTUFBSzs7Ozs7O3lCQU03QixFQUFFWixZQUFZQSxNQUFNQyxPQUFPSSxPQUFNOzs7Y0FHNUMsRUFBRUwsWUFBWUEsTUFBTUMsT0FBT2lCLFdBQVU7bUJBQ2hDLEVBQUVsQixZQUFZQSxNQUFNQyxPQUFPSyxNQUFLOzs7Ozs7cUJBTTlCLEVBQUVOLFlBQVlBLE1BQU1DLE9BQU9RLGFBQVk7Ozs7QUFLNUQsT0FBTyxNQUFNVSxlQUFldEIsT0FBT3VCLENBQUM7Ozs7WUFJeEIsRUFBRXBCLFlBQVlBLE1BQU1DLE9BQU9vQixPQUFNO2lCQUM1QixFQUFFckIsWUFBWUEsTUFBTUMsT0FBT3FCLFlBQVc7Z0JBQ3ZDLEVBQUV0QixZQUFZQSxNQUFNVSxNQUFNQyxLQUFLQyxNQUFLOztBQUdwRCxPQUFPLE1BQU1XLGlCQUFpQjFCLE9BQU91QixDQUFDOzs7O1lBSTFCLEVBQUVwQixZQUFZQSxNQUFNQyxPQUFPdUIsUUFBTztpQkFDN0IsRUFBRXhCLFlBQVlBLE1BQU1DLE9BQU93QixjQUFhO2dCQUN6QyxFQUFFekIsWUFBWUEsTUFBTVUsTUFBTUMsS0FBS0MsTUFBSzs7QUFHcEQsT0FBTyxNQUFNYyxpQkFBaUI3QixPQUFPdUIsQ0FBQzs7WUFFMUIsRUFBRXBCLFlBQVlBLE1BQU1DLE9BQU8wQixLQUFJO2dCQUMzQixFQUFFM0IsWUFBWUEsTUFBTVUsTUFBTUMsS0FBS0MsTUFBSzs7OztjQUl0QyxFQUFFWixZQUFZQSxNQUFNQyxPQUFPUSxhQUFZIiwibmFtZXMiOlsic3R5bGVkIiwiUGFnZVNoZWxsIiwibWFpbiIsInRoZW1lIiwiY29sb3JzIiwiYmFja2dyb3VuZCIsIkxvZ2luUGFuZWwiLCJzZWN0aW9uIiwiYm9yZGVyIiwid2hpdGUiLCJIZWFkZXJHcm91cCIsImhlYWRlciIsInByaW1hcnlfZGFyayIsImZvbnRzIiwic2l6ZSIsInNtYWxsIiwiRm9ybSIsImZvcm0iLCJ0ZXh0X3doaXRlIiwiRmllbGQiLCJkaXYiLCJ0ZXh0X2JsYWNrIiwiRXJyb3JNZXNzYWdlIiwicCIsImRhbmdlciIsImVycm9yX2xpZ2h0IiwiU3VjY2Vzc01lc3NhZ2UiLCJzdWNjZXNzIiwic3VjY2Vzc19saWdodCIsIlN3aXRjaEF1dGhUZXh0IiwiZGFyayJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJzdHlsZXMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcblxuZXhwb3J0IGNvbnN0IFBhZ2VTaGVsbCA9IHN0eWxlZC5tYWluYFxuICBtaW4taGVpZ2h0OiAxMDBzdmg7XG4gIHdpZHRoOiAxMDAlO1xuICBkaXNwbGF5OiBncmlkO1xuICBwbGFjZS1pdGVtczogY2VudGVyO1xuICBwYWRkaW5nOiAzMnB4IDE2cHg7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIGJhY2tncm91bmQ6XG4gICAgbGluZWFyLWdyYWRpZW50KDEzNWRlZywgcmdiYSg2NywgMTkwLCAxOTgsIDAuMTIpLCByZ2JhKDIxLCAxMTksIDY3LCAwLjA4KSksXG4gICAgJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMuYmFja2dyb3VuZH07XG5gO1xuXG5leHBvcnQgY29uc3QgTG9naW5QYW5lbCA9IHN0eWxlZC5zZWN0aW9uYFxuICB3aWR0aDogbWluKDEwMCUsIDQyMHB4KTtcbiAgYm9yZGVyOiAxcHggc29saWQgJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMuYm9yZGVyfTtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBwYWRkaW5nOiAzMnB4O1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBiYWNrZ3JvdW5kOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy53aGl0ZX07XG4gIGJveC1zaGFkb3c6IDAgMThweCA1MHB4IHJnYmEoNDEsIDY3LCA3OCwgMC4xMik7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG5gO1xuXG5leHBvcnQgY29uc3QgSGVhZGVyR3JvdXAgPSBzdHlsZWQuaGVhZGVyYFxuICBkaXNwbGF5OiBncmlkO1xuICBnYXA6IDhweDtcbiAgbWFyZ2luLWJvdHRvbTogMjhweDtcblxuICBzcGFuIHtcbiAgICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMucHJpbWFyeV9kYXJrfTtcbiAgICBmb250LXNpemU6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuZm9udHMuc2l6ZS5zbWFsbH07XG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICB9XG5cbiAgaDEge1xuICAgIG1hcmdpbjogMDtcbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IEZvcm0gPSBzdHlsZWQuZm9ybWBcbiAgZGlzcGxheTogZ3JpZDtcbiAgZ2FwOiAxOHB4O1xuXG4gIGJ1dHRvbiB7XG4gICAgbWluLWhlaWdodDogNDhweDtcbiAgICBib3JkZXI6IDA7XG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xuICAgIGJhY2tncm91bmQ6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLnByaW1hcnlfZGFya307XG4gICAgY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLnRleHRfd2hpdGV9O1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICBmb250OiBpbmhlcml0O1xuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIH1cblxuICBidXR0b246ZGlzYWJsZWQge1xuICAgIGN1cnNvcjogbm90LWFsbG93ZWQ7XG4gICAgb3BhY2l0eTogMC42NTtcbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IEZpZWxkID0gc3R5bGVkLmRpdmBcbiAgZGlzcGxheTogZ3JpZDtcbiAgZ2FwOiA4cHg7XG5cbiAgbGFiZWwge1xuICAgIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy50ZXh0X2JsYWNrfTtcbiAgICBmb250LXNpemU6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuZm9udHMuc2l6ZS5zbWFsbH07XG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgfVxuXG4gIGlucHV0IHtcbiAgICBtaW4taGVpZ2h0OiA0NnB4O1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLmJvcmRlcn07XG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xuICAgIHBhZGRpbmc6IDAgMTRweDtcbiAgICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMudGV4dF9ibGFja307XG4gICAgYmFja2dyb3VuZDogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMud2hpdGV9O1xuICAgIGZvbnQ6IGluaGVyaXQ7XG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgfVxuXG4gIGlucHV0OmZvY3VzIHtcbiAgICBib3JkZXItY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLnByaW1hcnlfZGFya307XG4gICAgb3V0bGluZTogM3B4IHNvbGlkIHJnYmEoNjcsIDE5MCwgMTk4LCAwLjE4KTtcbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IEVycm9yTWVzc2FnZSA9IHN0eWxlZC5wYFxuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIHBhZGRpbmc6IDEycHggMTRweDtcbiAgbWFyZ2luOiAwO1xuICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMuZGFuZ2VyfTtcbiAgYmFja2dyb3VuZDogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMuZXJyb3JfbGlnaHR9O1xuICBmb250LXNpemU6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuZm9udHMuc2l6ZS5zbWFsbH07XG5gO1xuXG5leHBvcnQgY29uc3QgU3VjY2Vzc01lc3NhZ2UgPSBzdHlsZWQucGBcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBwYWRkaW5nOiAxMnB4IDE0cHg7XG4gIG1hcmdpbjogMDtcbiAgY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLnN1Y2Nlc3N9O1xuICBiYWNrZ3JvdW5kOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy5zdWNjZXNzX2xpZ2h0fTtcbiAgZm9udC1zaXplOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmZvbnRzLnNpemUuc21hbGx9O1xuYDtcblxuZXhwb3J0IGNvbnN0IFN3aXRjaEF1dGhUZXh0ID0gc3R5bGVkLnBgXG4gIG1hcmdpbjogMThweCAwIDA7XG4gIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy5kYXJrfTtcbiAgZm9udC1zaXplOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmZvbnRzLnNpemUuc21hbGx9O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG5cbiAgYSB7XG4gICAgY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLnByaW1hcnlfZGFya307XG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gIH1cblxuICBhOmZvY3VzLFxuICBhOmhvdmVyIHtcbiAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgfVxuYDtcbiJdLCJmaWxlIjoiQzovVXNlcnMvd2FsbGEvRGVza3RvcC9Qcm9qZXRvcy1wZXNzb2Fpcy9wcm92YS10ZWNuaWNhL2Zyb250LW1pbmktdGFzay1tYW5hZ2VyL3NyYy9wYWdlcy9wdWJsaWMvTG9naW4vc3R5bGVzLnRzIn0=